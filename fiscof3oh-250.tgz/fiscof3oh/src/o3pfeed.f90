!----------------------------------------------------------------------
! Observe 3D Particle Fast Electron Energy Distribution Function
!                            /
      subroutine o3pfeed ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!                  4 = output footer
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 20/12/23
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use observe
      use fpprm
      use particle
      use field
      use laserprf
      include "implicit.h"
      integer, parameter :: lgprx = 200, lgpmx = 37, lgpnx = 36, &
                            lgpxyz = 10,  lgpmx1 = lgpmx + 1
      integer :: kflag, i, ii, im, in, ir, irl,ilu,ixpm, iypm,izpm, &
                 iflg, il, ilx, idrlx,idlux
      real*8  :: wzero=1.0d-6, womg, wdomg, wdomg2, wintt, wm, wn, wr, wrld, wlud, &
                 wnpnc, wpxe, wpxs, wpys, wpye, wpzs, wpze, wrang, &
                 wpx,wpy,wpz,wxd(lopfeedx),wyd(lopfeedx),wzd(lopfeedx)
      real*8, allocatable :: wmue(:), wpedsn(:,:,:,:,:,:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o3pfeed', 0 )
!....
      if( kflag .eq. 4 ) then
         if( lresto .eq. 0 ) then
            lopfeedc = lopfeedc + 1
            if( iflg .le. 2 ) then
               do il = 1, ilx
                 write(49+il,1400) il,ilx
                 flush(49+il)
 1400            format( '------- end ',i1,'/',i1,' --------')
               end do
            end if
         end if
         return
      end if
!....
      if( kflag .ge. 2 ) then
#ifdef OHHELP
         if( oh_pevflag .ne. 0 ) then
            call c3pev
            oh_pevflag = 0 
         end if
!..
         do ips = 1, 2
         if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
         do i = lnoes, lnoee
           do il = 1, ilx
             if( lopfeedty(il) .eq. 1 )then
               if( (sze(i)-sopfeedpo(5,il))*(sze(i)+svze(i)-sopfeedpo(5,il)) &
                                                     .gt. s0o1 ) cycle
               if( sxe(i).lt.sopfeedpo(1,il).or.sxe(i).gt.sopfeedpo(3,il) ) &
                                                                 cycle
               if( sye(i).lt.sopfeedpo(2,il).or.sye(i).gt.sopfeedpo(4,il) ) &
                                                                 cycle
             else if( lopfeedty(il) .eq. 2 )then
               if( (sxe(i)-sopfeedpo(5,il))*(sxe(i)+svxe(i)-sopfeedpo(5,il)) &
                                                     .gt. s0o1 ) cycle
               if( sye(i).lt.sopfeedpo(1,il).or.sye(i).gt.sopfeedpo(3,il) ) &
                                                                 cycle
               if( sze(i).lt.sopfeedpo(2,il).or.sze(i).gt.sopfeedpo(4,il) ) &
                                                                 cycle               
             else if( lopfeedty(il) .eq. 3 )then
               if( (sye(i)-sopfeedpo(5,il))*(sye(i)+svye(i)-sopfeedpo(5,il)) &
                                                    .gt. s0o1 ) cycle
               if( sxe(i).lt.sopfeedpo(1,il).or.sxe(i).gt.sopfeedpo(3,il) ) &
                                                                 cycle
               if( sze(i).lt.sopfeedpo(2,il).or.sze(i).gt.sopfeedpo(4,il) ) &
                                                                 cycle               
             end if
!.
             wr = suue(i)
             wm = suxe(i) / wr
             wr = wr * scflinv * sopfeedr
             ir = int( wr ) + 1
             ir = min( ir, lopfeedrl )
             do ii = 1, lopfeedml
                if( (wm-wmue(ii)) * (wm-wmue(ii+1)) .le. s0o1 ) then
                   im = ii
                   go to 1
                end if
             end do
             if( lrank .le. 0 ) &
             write(0,*) '### WARNING: mue', wm
             im = 1
    1        continue
             if( suye(i)**2 + suze(i)**2 .lt. wzero ) then
                in = 1
             else
                womg = atan2( suze(i), suye(i) ) + wdomg2
                if( womg .lt. s0o1 ) womg = womg + s2pi
                in = int( womg / wdomg ) + 1
             end if
             if( lopfeedty(il) .eq. 1 )then
               irl = int( (sxe(i)-sopfeedpo(1,il))/wxd(il) ) + 1
               ilu = int( (sye(i)-sopfeedpo(2,il))/wyd(il) ) + 1
             else if( lopfeedty(il) .eq. 2 )then
               irl = int( (sye(i)-sopfeedpo(1,il))/wyd(il) ) + 1
               ilu = int( (sze(i)-sopfeedpo(2,il))/wzd(il) ) + 1
             else if( lopfeedty(il) .eq. 3 )then
               irl = int( (sxe(i)-sopfeedpo(1,il))/wxd(il) ) + 1
               ilu = int( (sze(i)-sopfeedpo(2,il))/wzd(il) ) + 1
             end if
             wpedsn(ir,im,in,irl,ilu,il) = wpedsn(ir,im,in,irl,ilu,il) + spfe(i)
           end do
         end do
#ifdef OHHELP
         end do
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
            lopfeedc = lopfeedc + 1
            do il = 1, ilx
              write(49+il,1100) sstcur
 1100         format( '------------------------'/' time = ', f12.3 )
              wn = s0o1
              do ilu = 1, idlux
                do irl = 1, idrlx
                  do in = 1, lopfeednl
                    do im = 1, lopfeedml
                      do ir = 1, lopfeedrl
                        if( kflag .eq. 2 ) &
                          wpedsn(ir,im,in,irl,ilu,il) = &
                            wpedsn(ir,im,in,irl,ilu,il) * lopfeeda
                        if( wpedsn(ir,im,in,irl,ilu,il) .ge. sopfeedm ) then
                          wn = wn + wpedsn(ir,im,in,irl,ilu,il)
                          write(49+il,1200) ir,im,in,irl,ilu,&
                                            wpedsn(ir,im,in,irl,ilu,il)
                          flush(49+il)
 1200                     format( 5i4, f12.3 )
                        end if
                      end do
                    end do
                  end do
                end do
              end do
              write(49+il,1300) wn
 1300         format( 'total = ', f12.3 )
              flush(49+il)
            end do
!....
         else
!....
            iflg = mod( lopfeed, 10 )
            ilx = lopfeed / 10
!..
            if( lopfeedrl .lt. 1 .or. lopfeedrl .gt. lgprx ) then
               write(0,*) '### ERROR: lopfeedrl out of range!',  &
                          1,lopfeedrl,lgprx
               call s3ext_abort
            end if
            if( .not. allocated(wmue) ) allocate( wmue(lgpmx1) )
              if( lopfeedml .lt. 2 .or. lopfeedml .gt. lgpmx ) then
                write(0,*) '### ERROR: lopfeedml out of range!', &
                         2,lopfeedml,lgpmx
                call s3ext_abort
              else
                wdomg2 = spi / ( (lopfeedml-2)*2 + 2 )
                wdomg  = wdomg2 * s2o1
                wmue(1) = 1.0d0
                do im = 2, lopfeedml
                   wmue(im) = cos( wdomg2 + wdomg * (im-2) )
                end do
                wmue(lopfeedml+1) = -1.0d0
              end if
            if( lopfeednl .lt. 1 .or. lopfeednl .gt. lgpnx ) then
               write(0,*) '### ERROR: lopfeednl out of range!', &
                         1,lopfeednl,lgpnx
               call s3ext_abort
            end if
            idrlx = 0
            idlux = 0
            do il = 1, ilx
               if( lopfeeddl(1,il) .gt. lgpxyz .or. &
                   lopfeeddl(2,il) .gt. lgpxyz ) then
                  write(0,*) '### ERROR: lopfeeddl overflow!',  &
                         il,lopfeeddl(1,il),lopfeeddl(2,il),lgpxyz
                 call s3ext_abort
               end if
               idrlx = max( idrlx, lopfeeddl(1,il) )
               idlux = max( idlux, lopfeeddl(2,il) )
            end do
!
            if( .not. allocated(wpedsn) ) allocate( &
                wpedsn(lopfeedrl,lopfeedml,lopfeednl,idrlx,idlux,ilx) )
!
            wdomg  = s2pi / lopfeednl
            wdomg2 = wdomg / s2o1
!
            wrang = s1o1 / sopfeedr
            wintt = lopfeeda * sdtfs
!..
            do il = 1, ilx
!
            wrld = ( sopfeedpo(3,il) - sopfeedpo(1,il) ) / lopfeeddl(1,il)
            wlud = ( sopfeedpo(4,il) - sopfeedpo(2,il) ) / lopfeeddl(2,il)
            if( lopfeedty(il).eq. 1 )then
               wxd(il) = wrld
               wyd(il) = wlud
            else if( lopfeedty(il) .eq. 2 )then
               wyd(il) = wrld
               wzd(il) = wlud
            else if( lopfeedty(il) .eq. 3 )then
               wxd(il) = wrld
               wzd(il) = wlud
            end if
!
            if( ilx .eq. 1 ) then
              call fntpcnv ( bfpfntpe, lrank,-1, bident,'pfeed', bfile )
            else
              call fntpcnv ( bfpfntpe, lrank,il, bident,'pfeed', bfile )
            end if
            open(49+il, file=trim(bfile), &
                                   form='FORMATTED', status='UNKNOWN')
!.
            if( lresti .eq. 0 ) then
              if( lcfde .eq. 0 ) call c3fde
              if( lopfeedty(il) .eq. 1 )then
                 wpxs = ( sopfeedpo(1,il) - loxp0 ) * slmicinv
                 wpys = ( sopfeedpo(2,il) - loyp0 ) * slmicinv
                 wpxe = ( sopfeedpo(3,il) - loxp0 ) * slmicinv
                 wpye = ( sopfeedpo(4,il) - loyp0 ) * slmicinv
                 wpz  = ( sopfeedpo(5,il) - lozp0 ) * slmicinv
                 ixpm = ( sopfeedpo(1,il) + sopfeedpo(3,il) ) / s2o1
                 iypm = ( sopfeedpo(2,il) + sopfeedpo(4,il) ) / s2o1
                 izpm = floor(sopfeedpo(5,il))
              else if( lopfeedty(il) .eq. 2 )then
                 wpys = ( sopfeedpo(1,il) - loyp0 ) * slmicinv
                 wpzs = ( sopfeedpo(2,il) - lozp0 ) * slmicinv
                 wpye = ( sopfeedpo(3,il) - loyp0 ) * slmicinv
                 wpze = ( sopfeedpo(4,il) - lozp0 ) * slmicinv
                 wpx  = ( sopfeedpo(5,il) - loxp0 ) * slmicinv
                 ixpm = floor(sopfeedpo(5,il))
                 iypm = ( sopfeedpo(1,il) + sopfeedpo(3,il) ) / s2o1
                 izpm = ( sopfeedpo(2,il) + sopfeedpo(4,il) ) / s2o1
              else if( lopfeedty(il) .eq. 3 )then
                 wpxs = ( sopfeedpo(1,il) - loxp0 ) * slmicinv
                 wpzs = ( sopfeedpo(2,il) - lozp0 ) * slmicinv
                 wpxe = ( sopfeedpo(3,il) - loxp0 ) * slmicinv
                 wpze = ( sopfeedpo(4,il) - lozp0 ) * slmicinv
                 wpy  = ( sopfeedpo(5,il) - loyp0 ) * slmicinv
                 ixpm = ( sopfeedpo(1,il) + sopfeedpo(3,il) ) / s2o1
                 iypm = floor(sopfeedpo(5,il))
                 izpm = ( sopfeedpo(2,il) + sopfeedpo(4,il) ) / s2o1
              end if
#ifndef OHHELP
              wnpnc = sde(ixpm,iypm,izpm) / snepm1
#else
              ips = 1
              if( ixpm .ge. oh_sdoms(1,1,oh_sdid(ips)+1) .and. &
                  ixpm .lt. oh_sdoms(2,1,oh_sdid(ips)+1) .and. &
                  iypm .ge. oh_sdoms(1,2,oh_sdid(ips)+1) .and. &
                  iypm .lt. oh_sdoms(2,2,oh_sdid(ips)+1) .and. &
                  izpm .ge. oh_sdoms(1,3,oh_sdid(ips)+1) .and. &
                  izpm .lt. oh_sdoms(2,3,oh_sdid(ips)+1) ) then
                 ixpm = ixpm - oh_sdoms(1,1,oh_sdid(ips)+1) + 1
                 iypm = iypm - oh_sdoms(1,2,oh_sdid(ips)+1) + 1
                 izpm = izpm - oh_sdoms(1,3,oh_sdid(ips)+1) + 1
                 wnpnc = sde(ixpm,iypm,izpm) / snepm1
              else
                 wnpnc = s0o1
              end if
#endif
              write(49+il,1001) il, ilx, bident, lopfeedml
              write(49+il,1002) lopfeednl,lopfeedrl,wrang,wintt,sotint
              if( lopfeedty(il) .eq. 1 )then
                 write(49+il,1003) wpz ,wpxs,wpxe,wpys,wpye, lopfeeddl(1,il),lopfeeddl(2,il)
              else if( lopfeedty(il) .eq. 2 )then
                 write(49+il,1004) wpx ,wpys,wpye,wpzs,wpze, lopfeeddl(1,il),lopfeeddl(2,il)
              else if( lopfeedty(il) .eq. 3 )then
                 write(49+il,1005) wpy ,wpxs,wpxe,wpzs,wpze, lopfeeddl(1,il),lopfeeddl(2,il)
              end if
              
              write(49+il,1006) snepm1,wnpnc,slramm,slram,sgrid,slpwr
 1001         format( '------ start ',i1,'/',i1,' -------'/ &
            'ident character             = ', a16 / &
            'Equal Division              = ', i7 )
 1002         format( &
            '# of mesh for omega         = ', i7 / &
            '# of mesh for momentum      = ', i7 / &
            'range                       = ', e11.4 / &
            'integration time            = ', f11.3, ' [fsec]' / &
            'observation interval        = ', f11.3, ' [fsec]' )
 1003         format( &
            'observation position of z   = ', f11.3, ' [micron]'/ &
            'observation position of xs  = ', f11.3, ' [micron]'/ &
            'observation position of xe  = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            '# of division for xy        = ', 2i7 )
 1004         format( &
            'observation position of x   = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            'observation position of zs  = ', f11.3, ' [micron]'/ &
            'observation position of ze  = ', f11.3, ' [micron]'/ &
            '# of division for yz        = ', 2i7 )
 1005         format( &
            'observation position of y   = ', f11.3, ' [micron]'/ &
            'observation position of xs  = ', f11.3, ' [micron]'/ &
            'observation position of xe  = ', f11.3, ' [micron]'/ &
            'observation position of zs  = ', f11.3, ' [micron]'/ &
            'observation position of ze  = ', f11.3, ' [micron]'/ &
            '# of division for xz        = ', 2i7 )
 1006         format( &
            '# of particle/mesh at nc    = ', f11.3 / &
            'density at center           = ', f11.3 / &
            'laser wavelength            = ', f11.3,' [micron]'/ &
            'laser wavelength/mesh size  = ', f11.3 / &
            'Debye length/mesh size      = ', f11.3 / &
            'laser peak intensity        = ', e11.4, &
                                           ' [W/cm^2-micron^2]')
!
              if( llsrty .eq. 1 ) then
                 write(49+il,1010) slsrle, slsrwd, slsrtr
 1010            format( &
               'laser pulse shape           =  LINEAR + FLAT' / &
               'laser pulse (up,width,down) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 2 ) then
                 write(49+il,1020) slsrle, slsrwd, slsrtr
 1020            format( &
               'laser pulse shape           =  GAUSSIAN + FLAT' / &
               'laser pulse (HWHM,WID,HWHM) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 3 ) then
                 write(49+il,1030) slsrwd
 1030            format( &
               'laser pulse shape           = GAUSSIAN' / &
               'laser pulse (FWHM)          = ',f11.3,' [fsec]' )
              else if( llsrty .eq. 4 ) then
                 write(49+il,1040) slsrwd, slsrle
 1040            format( &
               'laser pulse shape           = SUPERGAUSSIAN' / &
               'laser pulse (FWHM,alpha)    = ',f11.3,' [fsec] (', &
                                                    f4.1, ')' )
              else
                 write(49+il,1050) llsrty, slsrle, slsrwd, slsrtr
 1050            format( &
               'laser pulse shape (TYPE)    = ', i7 / &
               'laser pulse parameters      = ', 3f11.3 )
              end if
!
              flush(49+il)
!
            end if
            end do
         end if
!...
         do il = 1, ilx
         do ilu = 1, idlux
           do irl = 1, idrlx
             do in = 1, lopfeednl
               do im = 1, lopfeedml
                 do ir = 1, lopfeedrl
                   wpedsn(ir,im,in,irl,ilu,il) = s0o1
                 end do
               end do
             end do
           end do
         end do
         end do
!....
      end if
!....
      call fdebug ( 'o3pfeed', 1 )
!....
      return
      end
