!----------------------------------------------------------------------
      implicit none
      integer :: i
      real(8) :: atime, ahw, att
      real(8) :: dbempd, dbempl, dbempw, dbempn
      real(8) :: dtime(401), drayam(401)
      save
!....
      write(*,*) 'dbempd, dbempl, dbempw, dbempn'
      read(*,*) dbempd, dbempl, dbempw, dbempn
!....
      do i = 1, 401
        ahw = ( dbempl - dbempw ) / 2.0d0
        att = ahw * sqrt( - log(dbempn)/log(2.0d0) )
        dtime(i) = ( i - 1 ) * (att+dbempw+att+dbempd) / 400.0d0
        atime = dtime(i) - dbempd
        if( atime .gt. 0.0d0 ) then
          if( atime .lt. att ) then
            drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
          else
            if( atime .le. att+dbempw ) then
              drayam(i) = 1.0d0
            else
              if( atime .lt. att+dbempw+att ) then
                att = att + dbempw
                drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
              else
                drayam(i) = 0.0d0
              end if
            end if
          end if
        else
          drayam(i) = 0.0d0
        end if
      end do
!....
      call fr_ginit 
      call fr_opencanvas( 1, 'pulse', 10 )
      call fr_gclear
      call fr_graph2d ( dtime, drayam, 401, 2, 1 )
      call fr_gend
!....
      stop
      end
