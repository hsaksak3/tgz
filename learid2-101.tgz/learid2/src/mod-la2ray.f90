!----------------------------------------------------------------------
! ray
!
module la2ray
      use la2parameter
      integer :: ltsmode, lraynr(llsrbl)
      real(8) :: drayam(llsrbl), draycn(llsrbl), draydx(llsrbl), &
                 drayn2(llsrbl)
      real(8) :: draybpx(4), draybpy(4), draybvx(4), draybvy(4), &
                 draybpl(4)
!dbg
      integer :: ldbgnr, ldbgbr(llsrbl), ldbgtl(lraynt)
      real(8) :: ddbgry(3,0:lraytx,lraynt)
!dbg
end module la2ray
