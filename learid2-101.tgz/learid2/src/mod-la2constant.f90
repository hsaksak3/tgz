!----------------------------------------------------------------------
! constants
!
module la2constant
      integer :: llsrbn
      real(8) :: dnuecr, drhocr, ddbncr, dp2te, &
                 dlsrwl, dtime, ddltx, dkappa, dkappa2
      real(8), parameter :: &
                 dundef  = -1.0d20, &
                 dundeff = -1.1d20, &
                 dzero  = 1.0d-3, &
                 dzero2 = 1.0d-6, &
                 dpi  = acos( -1.0d0 ), &
                 dpi2 = dpi / 2.0d0, &
                 d2pi = 2.0d0 * dpi, &
                 dd2r = dpi / 180.0d0, &
                 dce  = 4.80320d-10, & ! esu
                 dcc  = 2.99792d10, &  ! cm/s
                 dcme = 9.10938d-28, & ! g
                 dcmu = 1.66054d-24, & ! g
                 dkev2erg = 1.60218d-9, & ! keV -> erg
                 dkev2j   = 1.60218d-16   ! keV -> J
end module la2constant
