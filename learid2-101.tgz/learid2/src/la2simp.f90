!----------------------------------------------------------------------
! set 2D SIMulation Parameters
!
      subroutine la2simp
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/24
!----------------------------------------------------------------------
      use la2parameter
      use la2constant
      use la2laser
      use la2beam
      use la2ray
      implicit none
      integer :: i
      real(8) :: atmp
      save
!....
      namelist /laser/ dtime, ddltx, dlsrwl, llsrbn, llsrnrpm, &
                       dlsrxr, dlsryr, dlsrd, dlsrf, dlsrdd, dlsrin, &
                       dlsral, dlsrpl, dlsrpw, dlsrpn
      namelist /beam/ lbemnrpm, &
                      dbemxr, dbemyr, dbemd, dbemf, dbemdd, dbemin, &
                      dbemal, dbempl, dbempw, dbempn, dbempd, &
                      dbemnx, dbemny
      namelist /ray/ ltsmode, dkappa, ldbgnr
!....                                              * laser parameters *
      dtime  = 0.0d0
      ddltx  = 1.0d0
      dlsrwl = 1.06d0
      llsrbn = 1
      llsrnrpm = 5
      dlsrxr = 0.0d0
      dlsryr = 0.0d0
      dlsrd  = 0.0d0
      dlsrf  = 3.0d0
      dlsrdd = 100.0d0
      dlsrin = 1.0d14
      dlsral = 2.0d0
      dlsrpl = 3.0d0
      dlsrpw = 2.0d0
      dlsrpn = 0.005d0
!.
      read(*,nml=laser)
!..
      if( llsrbn .eq. 0 ) then
         write(*,*) '@@@ no laser beam @@@'
         stop
      else if( llsrbn .gt. llsrbl ) then
         write(*,*) '### ERROR: laser beam number overflow', &
                    llsrbn, llsrbl
         stop
      end if
!....                                               * beam parameters *
      do i = 1, llsrbn
         lbemnrpm(i) = -1
         dbemxr(i) = dundeff
         dbemyr(i) = dundeff
         dbemd(i)  = dundeff
         dbemf(i)  = dundeff
         dbemdd(i) = dundeff
         dbemin(i) = dundeff
         dbemal(i) = dundeff
         dbempl(i) = dundeff
         dbempw(i) = dundeff
         dbempn(i) = dundeff
         dbempd(i) = 0.0d0
         dbemnx(i) = dundeff
         dbemny(i) = dundeff
      end do
!.
      read(*,nml=beam)
!..
      do i = 1, llsrbn
        if( lbemnrpm(i) .le. 0 ) lbemnrpm(i) = llsrnrpm
        if( dbemxr(i) .le. dundef ) dbemxr(i) = dlsrxr
        if( dbemyr(i) .le. dundef ) dbemyr(i) = dlsryr
        if( dbemd(i)  .le. dundef ) dbemd(i)  = dlsrd
        if( dbemf(i)  .le. dundef ) dbemf(i)  = dlsrf
        if( dbemdd(i) .le. dundef ) dbemdd(i) = dlsrdd
        if( dbemin(i) .le. dundef ) dbemin(i) = dlsrin
        if( dbemal(i) .le. dundef ) dbemal(i) = dlsral
        if( dbempl(i) .le. dundef ) dbempl(i) = dlsrpl
        if( dbempw(i) .le. dundef ) dbempw(i) = dlsrpw
        if( dbempn(i) .le. dundef ) dbempn(i) = dlsrpn
        if( dbemnx(i) .le. dundef ) then
          write(*,*) '### ERROR: beam nx not specified ', i
          stop
        end if
        if( dbemny(i) .le. dundef ) then
          write(*,*) '### ERROR: beam ny not specified ', i
          stop
        end if
      end do
!..
      do i = 1, llsrbn
        atmp = sqrt( dbemnx(i)**2 + dbemny(i)**2 )
        if( atmp .le. dzero ) then
          write(*,*) '### ERROR: invalid beam n', i,atmp
          stop
        end if
        dbemnx(i) = dbemnx(i) / atmp
        dbemny(i) = dbemny(i) / atmp
        if( dbempl(i) .lt. dbempw(i) ) then
          write(*,*) '### ERROR: invalid pulse length or width', &
                     i,dbempl(i),dbempw(i)
          stop
        end if
      end do
!....                                                * ray parameters *
      ltsmode = 0
      dkappa = 0.2d0
      ldbgnr = 20
!.
      read(*,nml=ray)
!....
      write(*,1000) llsrbl, lraynt, lraytx, lx, ly
 1000 format('parameter start' / &
            ' llsrbl = ', i10 / ' lraynt = ', i10 / &
            ' lraytx = ', i10 /  &
            ' lx     = ', i10 / ' ly     = ', i10 / &
            'parameter  end' )
      write(*,nml=laser)
      write(*,nml=beam)
      write(*,nml=ray)
!....
      return
      end
