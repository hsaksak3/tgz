!----------------------------------------------------------------------
! parameter
!
module la2parameter
      integer, parameter :: llsrbl = 6
      integer, parameter :: lraynt = 8
      integer, parameter :: lraytx = 3000
!
      integer, parameter :: lx = 201
      integer, parameter :: ly = 201
      real(8), parameter :: dxo = ( lx + 1.0d0 ) / 2.0d0
      real(8), parameter :: dyo = ( ly + 1.0d0 ) / 2.0d0
      integer, parameter :: lx1 = lx - 1
      integer, parameter :: lx2 = lx - 2
      integer, parameter :: ly1 = ly - 1
      integer, parameter :: ly2 = ly - 2
end module la2parameter
