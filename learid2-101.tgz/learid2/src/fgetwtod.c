/* #include <sys/time.h> */
#include <time.h>
#include <stdio.h>

double fgetwtod_ ()
{
/*   static double wtod;
     static long time0;
     static int init=0;
     static struct timeval tod;
     static struct timezone tz;
     gettimeofday( &tod, &tz );
     if ( init == 0 ) {
        init = 1;
        time0 = tod.tv_sec;
     }
     wtod = ( tod.tv_sec - time0 ) + tod.tv_usec * 1.0e-6; */

     static double wtod;
     static struct timespec clk;
#ifdef CLOCK_MONOTONIC_COARSE
     clock_gettime(CLOCK_MONOTONIC_COARSE, &clk);
#else
     clock_gettime(CLOCK_MONOTONIC, &clk);
#endif
     wtod = clk.tv_sec + clk.tv_nsec * 1.0e-9; 

     return( wtod );
}
