!----------------------------------------------------------------------
! set 2D CoNSTants
!
      subroutine la2cnst
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/25
!----------------------------------------------------------------------
      use la2constant
      use la2beam
      use la2ray
      implicit none
      integer :: i, inr
      real(8) :: ar, atime, ahw, att
      save
!....
      do i = 1, llsrbn
        dbemxf(i) = dbemxr(i) + dbemd(i) * dbemnx(i)
        dbemyf(i) = dbemyr(i) + dbemd(i) * dbemny(i)
        dbemxd(i) = dbemxr(i) + dbemdd(i) * dbemnx(i)
        dbemyd(i) = dbemyr(i) + dbemdd(i) * dbemny(i)
        ar        = ( dbemdd(i) - dbemd(i) ) / dbemf(i)
        dbemw(i)  = ar * 4.0d0**(1.0d0/dbemal(i)) / 2.0d0
        dbemtx(i) = -dbemny(i)
        dbemty(i) =  dbemnx(i)
        draydx(i) = ddltx / lbemnrpm(i)
        atime = dtime - dbempd(i)
        if( atime .gt. 0.0d0 ) then
          ahw = ( dbempl(i) - dbempw(i) ) / 2.0d0
          att = ahw * sqrt( - log(dbempn(i))/log(2.0d0) )
          if( atime .lt. att ) then
            drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
          else
            if( atime .le. att+dbempw(i) ) then
              drayam(i) = 1.0d0
            else
              if( atime .lt. att+dbempw(i)+att ) then
                att = att + dbempw(i)
                drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
              else
                drayam(i) = 0.0d0
              end if
            end if
          end if
        else
          drayam(i) = 0.0d0
        end if
!       draycn(i) = 1.0d-4 * ddltx / lbemnrpm(i) * dbemin(i) * &
!                   1.0d-7 / ( ddltx**2 )
        draycn(i) = 1.0d0 / lbemnrpm(i)
        inr = ar / draydx(i)
        inr = inr / lraynt
        lraynr(i) = inr * lraynt
        drayn2(i) = ( lraynr(i) + 1 ) / 2.0d0
        ldbgbr(i) = lraynr(i) / ldbgnr
      end do
!..                   * convert micron-coordinate to mesh-coordinate *
      do i = 1, llsrbn
        dbemxr(i) = dbemxr(i) / ddltx + dxo
        dbemyr(i) = dbemyr(i) / ddltx + dyo
        dbemxf(i) = dbemxf(i) / ddltx + dxo
        dbemyf(i) = dbemyf(i) / ddltx + dyo
        dbemxd(i) = dbemxd(i) / ddltx + dxo
        dbemyd(i) = dbemyd(i) / ddltx + dyo
        draydx(i) = draydx(i) / ddltx 
      end do  
!....
      draybpx(1) = 3
      draybpy(1) = 3
      draybpl(1) = lx2 - 3
      draybvx(1) = 1
      draybvy(1) = 0
      draybpx(2) = lx2
      draybpy(2) = 3
      draybpl(2) = ly2 - 3
      draybvx(2) = 0
      draybvy(2) = 1
      draybpx(3) = lx2
      draybpy(3) = ly2
      draybpl(3) = lx2 - 3
      draybvx(3) = -1
      draybvy(3) = 0
      draybpx(4) = 3
      draybpy(4) = ly2
      draybpl(4) = ly2 - 3
      draybvx(4) = 0
      draybvy(4) = -1
!....
      dkappa2 = dkappa / 2.0d0
!....
      return
      end
