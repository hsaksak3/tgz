!----------------------------------------------------------------------
! hydro
!
module la2hydro
      use la2parameter
      real(8) :: dden(lx,ly), ddendx(lx,ly), ddendy(lx,ly), &
                 dtem(lx,ly), dabs(lx,ly)
      real(8) :: dte, daz, daa
end module la2hydro
