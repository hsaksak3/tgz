!----------------------------------------------------------------------
! beam
!
module la2beam
      use la2parameter
      integer :: lbemnrpm(llsrbl)
      real(8) :: dbemxr(llsrbl), dbemyr(llsrbl), dbemd(llsrbl), &
                 dbemf(llsrbl), dbemdd(llsrbl), dbemin(llsrbl), &
                 dbemal(llsrbl), dbempl(llsrbl), dbempw(llsrbl), &
                 dbempn(llsrbl), dbempd(llsrbl), dbemnx(llsrbl), &
                 dbemny(llsrbl), dbemxf(llsrbl), dbemyf(llsrbl), &
                 dbemxd(llsrbl), dbemyd(llsrbl), dbemw(llsrbl), &
                 dbemtx(llsrbl), dbemty(llsrbl)
end module la2beam
