!----------------------------------------------------------------------
! laser
!
module la2laser
      integer :: llsrnrpm
      real(8) :: dlsrxr, dlsryr, dlsrd, dlsrf, dlsrdd, dlsrin, &
                 dlsral, dlsrpl, dlsrpw, dlsrpn
end module la2laser
