!----------------------------------------------------------------------
! Laser Energy Absorption code using Ray tracing and Inverse 
! bremsstrahlung energy Deposition
! 2 dimension
!
!    coded by Sakagami,H. (NIFS) 20/03/24
!----------------------------------------------------------------------
      use la2parameter
      implicit none
      integer :: istat
      real(8) :: ats, fgetwtod
      character :: cvers*14, cdata*32, cfile*64
!$    integer :: OMP_GET_MAX_THREADS, itx
!....
      cvers = 'learid2 V1.R01'
!..
      call fdate ( cdata ) 
      write(*,*) '+++++ ',cvers,' started at ',cdata(1:24),' +++++'
!$    itx = OMP_GET_MAX_THREADS()
!$    write(*,*) '+++++ OMP_GET_MAX_THREADS = ', itx
!$    cdata = ' '
!$    call get_environment_variable ( 'OMP_STACKSIZE', cdata )
!$    if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$    write(*,*) '+++++ OMP_STACKSIZE = ', trim(cdata)
!$    if( itx .gt. lraynt ) then
!$      write(*,*) '### ERROR MAX_THREADS > lraynt', lraynt
!$      stop
!$    end if
!....
      call get_environment_variable ( 'LEARID2_STDIN_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 5, file=cfile, status='OLD', err=998, iostat=istat )
         write(0,*) '@@@ input is read from "', trim(cfile), '"'
      else
         write(0,*) '@@@ input is connected with STDIN'
      end if
!
      call get_environment_variable ( 'LEARID2_STDOUT_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 6, file=cfile, err=999, iostat=istat )
         write(0,*) '@@@ output is written to "', trim(cfile), '"'
      else
         write(0,*) '@@@ output is connected with STDOUT'
      end if
!....
      call la2simp
      call la2cnst
      call la2init
      ats = fgetwtod()
      call la2main
      write(*,*) '@@@ elapsed time of la2main:', fgetwtod() - ats
!....
      call fdate ( cdata ) 
      write(*,*) '+++++ ',cvers,'  ended  at ',cdata(1:24),' +++++'
      stop
!....
  998 continue
      write(0,*) '### ERROR: stdin file not found. file="', &
                 trim(cfile), '"', istat
      stop
!..
  999 continue
      write(0,*) '### ERROR: can not open stdout file. file="', &
                 trim(cfile), '"', istat
      stop
      end
