!----------------------------------------------------------------------
! 2D MAIN
!
      subroutine la2main
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/25
!----------------------------------------------------------------------
      use la2parameter
      use la2constant
      use la2beam
      use la2ray
      use la2hydro
      implicit none
      integer :: ib, i, it, in, irn, irer, inside, isc, iraytl, itn, &
                 imx, imy, imx2, imy2, ittl, iovst
      real(8) :: arr, apx, apy, avx, avy, avv, at, as, att(2), afac
      real(8) :: adx, ady, adx2, ady2, adrdx, adrdy, aden, atem, &
                 anueo, anuen, apwri, apwra, apwrd, &
                 araypx, araypy, arayvx, arayvy, arayna, araypr
!$    integer :: OMP_GET_THREAD_NUM
      save
!dbg
      write(20) lx, ly, llsrbn, lraytx, ldbgnr, dxo, dyo, ddltx
      write(20) dtime, dden
!dbg
      afac = 1.0d0
!....
      do ib = 1, llsrbn
!                               * check focus point is inside or not *
      inside = 0
      if( dbemxf(ib) .le. draybpx(1) .or. &
          dbemxf(ib) .ge. draybpx(3) .or. &
          dbemyf(ib) .le. draybpy(1) .or. &
          dbemyf(ib) .ge. draybpy(3) ) then
        inside = 1
      end if
      irn   = 0
      irer  = 0
      apwri = 0.0d0
      apwra = 0.0d0
      itn   = 1
      ittl  = 0
      iovst = 0
!....
!$OMP PARALLEL DO SCHEDULE(DYNAMIC,1) &
!$OMP   REDUCTION(+:irn,irer,ittl,iovst,apwri,apwra,dabs),&
!$OMP   FIRSTPRIVATE(afac), &
!$OMP   PRIVATE(isc,in,itn,imx,imy,imx2,imy2,iraytl, &
!$OMP     adx,ady,adx2,ady2,apx,apy,avx,avy,avv,at,as,att, &
!$OMP     aden,atem,apwrd,arr,araypx,araypy,arayvx,arayvy, &
!$OMP     arayna,araypr,anueo,anuen)
        do i = 1, lraynr(ib)
!$        itn = OMP_GET_THREAD_NUM() + 1
!...                                                    * initialize *
!.                                   * find start point and velocity *
          arr = draydx(ib) * ( i - drayn2(ib) )
          apx = dbemxd(ib) + arr * dbemtx(ib)
          apy = dbemyd(ib) + arr * dbemty(ib)
          arr = exp( - 8.0d0 * abs(arr/dbemw(ib))**dbemal(ib) ) * &
                drayam(ib)
          avx = apx - dbemxf(ib)
          avy = apy - dbemyf(ib)
          avv = sqrt( avx**2 + avy**2 )
          avx = avx / avv
          avy = avy / avv
!                            * find intersection with boundary lines *
!                                        * inside = one intersection *
!                               * outside = two or zero intersection *
          isc = 0
          do in = 1, 4
            avv = avx * draybvx(in) + avy * draybvy(in)
            if( 1.0d0 - avv .lt. dzero ) cycle
            at = ( (draybpx(in)-dbemxf(ib))*(avx-avv*draybvx(in)) + &
                   (draybpy(in)-dbemyf(ib))*(avy-avv*draybvy(in)) ) / &
                 ( 1.0d0 - avv**2 )
            if( at .le. 0.0d0 ) cycle
            as = ( (draybpx(in)-dbemxf(ib))*(avv*avx-draybvx(in)) + &
                   (draybpy(in)-dbemyf(ib))*(avv*avy-draybvy(in)) ) / &
                 ( 1.0d0 - avv**2 )
            if( as .lt. 0.0d0 .or. as .ge. draybpl(in) ) cycle
!
            isc = isc + 1
            att(isc) = at
          end do
!                                                             * check *
          if( inside .eq. 0 ) then
            if( isc .ne. 1 ) then
              write(*,*) '### ERROR: inside, but not 1', ib, i, isc
              write(*,*) dbemxf(ib),dbemyf(ib),dbemxd(ib),dbemyd(ib), &
                         apx, apy, avx, avy
              stop
            end if
          else
            if( isc .ne. 0 .and. isc .ne. 2 ) then
              write(*,*) '### ERROR: outside, but not 0 or 2', &
                         ib, isc, i
              write(*,*) dbemxf(ib),dbemyf(ib),dbemxd(ib),dbemyd(ib), &
                         apx, apy, avx, avy
              stop
            end if
            if( att(2) .gt. att(1) ) then
              att(1) = att(2)
            end if
          end if
!
          if( isc .gt. 0 ) then
            araypx = dbemxf(ib) + avx * att(1)
            araypy = dbemyf(ib) + avy * att(1)
            imx = araypx
            imy = araypy
            adx = araypx - imx
            ady = araypy - imy
            aden = (1.0d0-adx)*(1.0d0-ady) * dden(imx  ,imy  ) + &
                          adx *(1.0d0-ady) * dden(imx+1,imy  ) + &
                   (1.0d0-adx)*       ady  * dden(imx  ,imy+1) + &
                          adx *       ady  * dden(imx+1,imy+1)
            atem = ( (1.0d0-adx)*(1.0d0-ady) * dtem(imx  ,imy  ) + &
                            adx *(1.0d0-ady) * dtem(imx+1,imy  ) + &
                     (1.0d0-adx)*       ady  * dtem(imx  ,imy+1) + &
                            adx *       ady  * dtem(imx+1,imy+1) ) ** &
                   ( 3.0d0/2.0d0 )
            arayvx  = -avx * sqrt( 1.0d0 - aden )
            arayvy  = -avy * sqrt( 1.0d0 - aden )
!
            anueo = dnuecr/atem * log(ddbncr*atem/sqrt(aden)) * aden**2
            apwrd = arr * ( 1.0d0 - exp( -anueo ) )
            araypr = arr - apwrd
!
            if( araypr .lt. dbempn(ib) ) then
              cycle
            end if
!                                                            * 1point *
            apwrd = apwrd * draycn(ib)
!1point     imx = araypx + 0.5d0
!1point     imy = araypy + 0.5d0
!1point     dabs(imx  ,imy  ) = dabs(imx  ,imy  ) + apwrd
!                                                           * 4points *
            dabs(imx  ,imy  ) = dabs(imx  ,imy  ) + &
                                (1.0d0-adx)*(1.0d0-ady) * apwrd
            dabs(imx+1,imy  ) = dabs(imx+1,imy  ) + &
                                       adx *(1.0d0-ady) * apwrd
            dabs(imx  ,imy+1) = dabs(imx  ,imy+1) + &
                                (1.0d0-adx)*       ady  * apwrd
            dabs(imx+1,imy+1) = dabs(imx+1,imy+1) + &
                                       adx *       ady  * apwrd
            apwri = apwri + arr
            irn = irn + 1
!dbg
            if( mod(i,ldbgbr(ib)) .eq. 0 ) then
              ddbgry(1,0,itn) = araypx
              ddbgry(2,0,itn) = araypy
              ddbgry(3,0,itn) = araypr
            end if
!dbg
          else
            cycle
          end if
!...
          iraytl = lraytx+1
          do it = 1, lraytx
!.                                           * advance one time step *
          imx = araypx
          imy = araypy
          adx = araypx - imx
          ady = araypy - imy
          adrdx = (1.0d0-adx)*(1.0d0-ady) * ddendx(imx  ,imy  ) + &
                         adx *(1.0d0-ady) * ddendx(imx+1,imy  ) + &
                  (1.0d0-adx)*       ady  * ddendx(imx  ,imy+1) + &
                         adx *       ady  * ddendx(imx+1,imy+1)
          adrdy = (1.0d0-adx)*(1.0d0-ady) * ddendy(imx  ,imy  ) + &
                         adx *(1.0d0-ady) * ddendy(imx+1,imy  ) + &
                  (1.0d0-adx)*       ady  * ddendy(imx  ,imy+1) + &
                         adx *       ady  * ddendy(imx+1,imy+1)
!
          if( ltsmode .eq. 1 ) then
            afac = 1.0d0 / sqrt( arayvx**2 + arayvy**2 )
          end if
!
          arayvx = arayvx - ( dkappa2 * afac ) * adrdx
          arayvy = arayvy - ( dkappa2 * afac ) * adrdy
!
          araypx = araypx + ( dkappa2 * afac ) * arayvx
          araypy = araypy + ( dkappa2 * afac ) * arayvy
!
          imx2 = araypx
          imy2 = araypy
          adx2 = araypx - imx2
          ady2 = araypy - imy2
!
          araypx = araypx + ( dkappa2 * afac ) * arayvx
          araypy = araypy + ( dkappa2 * afac ) * arayvy
!
          imx = araypx
          imy = araypy
          adx = araypx - imx
          ady = araypy - imy
          aden = (1.0d0-adx)*(1.0d0-ady) * dden(imx  ,imy  ) + &
                        adx *(1.0d0-ady) * dden(imx+1,imy  ) + &
                 (1.0d0-adx)*       ady  * dden(imx  ,imy+1) + &
                        adx *       ady  * dden(imx+1,imy+1)
          atem = ( (1.0d0-adx)*(1.0d0-ady) * dtem(imx  ,imy  ) + &
                          adx *(1.0d0-ady) * dtem(imx+1,imy  ) + &
                   (1.0d0-adx)*       ady  * dtem(imx  ,imy+1) + &
                          adx *       ady  * dtem(imx+1,imy+1) ) ** &
                 ( 3.0d0/2.0d0 )
!!$$$
          anuen = dnuecr/atem * log(ddbncr*atem/sqrt(aden)) * aden**2
          apwrd = araypr * ( 1.0d0 - exp( -(anueo+anuen)*afac ) )
          apwra = apwra + apwrd
          anueo = anuen
          araypr = araypr - apwrd
!                                                            * 1point *
          apwrd = apwrd * draycn(ib)
!1point   dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + apwrd
!                                                           * 4points *
          dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + &
                              (1.0d0-adx2)*(1.0d0-ady2) * apwrd
          dabs(imx2+1,imy2  ) = dabs(imx2+1,imy2  ) + &
                                     adx2 *(1.0d0-ady2) * apwrd
          dabs(imx2  ,imy2+1) = dabs(imx2  ,imy2+1) + &
                              (1.0d0-adx2)*       ady2  * apwrd
          dabs(imx2+1,imy2+1) = dabs(imx2+1,imy2+1) + &
                                     adx2 *       ady2  * apwrd
!dbg
          if( mod(i,ldbgbr(ib)) .eq. 0 ) then
            ddbgry(1,it,itn) = araypx
            ddbgry(2,it,itn) = araypy
            ddbgry(3,it,itn) = araypr
          end if
!dbg
!
          if( araypr .lt. dbempn(ib) .or. &
              araypx .le. draybpx(1) .or. &
              araypx .ge. draybpx(3) .or. &
              araypy .le. draybpy(1) .or. &
              araypy .ge. draybpy(3) ) then
            iraytl = it
!dbg
            if( mod(i,ldbgbr(ib)) .eq. 0 ) then
              ldbgtl(itn) = it
            else
              ldbgtl(itn) = 0
            end if
!dbg
            exit
          end if
          end do
!.
          ittl = ittl + iraytl
          if( iraytl .eq. lraytx+1 ) irer = irer + 1
!dbg
          if( ldbgtl(itn) .gt. 0 ) then
!$OMP CRITICAL
            write(20) ib,ldbgtl(itn)+1,ddbgry(1:3,0:ldbgtl(itn),itn)
!$OMP END CRITICAL
          end if
!dbg
!..
        end do
!
        if( apwri .eq. 0.0d0 ) apwri = 1.0d0
        if( irn .eq. 0 ) irn = 1
        write(*,'(1x,a,i2,i6,f6.1,i6,i6)') &
          '@@@ beam#, #ray, abs%, a#tl, #ovst:', &
          ib,irn,apwra/apwri*100,ittl/irn,iovst
        if( irer .gt. 0 ) &
          write(*,*) '### WARNING: not enough lraytx', irer,lraytx
!....
      end do
!....
      write(20) -1,1,ddbgry(1:3,0,1)
      write(20) dtime, dabs
!....
      return
      end
