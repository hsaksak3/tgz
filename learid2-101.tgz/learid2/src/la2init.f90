!----------------------------------------------------------------------
! set 2D INITial values
!
      subroutine la2init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/25
!----------------------------------------------------------------------
      use la2parameter
      use la2constant
      use la2beam
      use la2ray
      use la2hydro
      implicit none
      integer :: i, ix, iy, itype
      real(8) :: ax, ay, ar, arhox, ar0, al, ancr
      namelist /profile/ itype, arhox, ar0, al, daz, daa, dte
      save
!....
      itype = 0
      arhox = 1.5d0
      ar0   = 15.0d0
      al    = 10.0d0
      daz   = 3.5d0
      daa   = 6.5d0
      dte   = 0.1d0
!.
      read(*,nml=profile)
      write(*,nml=profile)
!....
!     drayc1 = 25.0d0 * daz / ( dlsrwl**2 * dte**(3.0d0/2.0d0) ) * &
!              ddltx * 1.0d-4 * dkappa* 0.5d0
      ancr = dcme * dpi * dcc**2 / ( dce**2 * (dlsrwl*1.0d-4)**2 )
      drhocr = ancr * dcmu * daa / daz
      drhocr = 1.0d0 / drhocr
      dp2te  = 1.0d11 * dcmu / ( 1.0d6 * dkev2j ) * &
               daa / ( daz + 1 )
      dnuecr = (4.0d0/3.0d0) * sqrt(d2pi/dcme) * ancr * dce**4 / &
               ( dcc * dkev2erg**(3.0d0/2.0d0) ) * daz * &
               ddltx * 1.0d-4 * dkappa* 0.5d0
      ddbncr = 3.0d0/(2.0d0*dce**3) * sqrt(dkev2erg**3/(dpi*ancr)) / &
               daz
!     write(*,*) dnuecr, drhocr, ddbncr, dp2te
!....                            * calculate temperature [keV] in la2 *
!.                                                 * now test version *
      do iy = 1, ly
        do ix = 1, lx
          dtem(ix,iy) = dte
        end do
      end do
!....      * convert rho [g/cm^3] in hydro to density [n/n_cr] in la2 *
!.                                                 * now test version *
      if( itype .eq. 0 ) then
        do iy = 1, ly
          ay = ( iy - dyo ) * ddltx
          do ix = 1, lx
            ax = ( ix - dxo ) * ddltx
            ar = sqrt( ax**2 + ay**2 )
            if( ar .le. ar0 ) then
              dden(ix,iy) = arhox
            else
              dden(ix,iy) = arhox * exp( - (ar-ar0)/al )
            end if
          end do
        end do
      else
        do iy = 1, ly
          do ix = 1, lx
            ax = ( ix - dxo ) * ddltx
            if( ax .le. ar0 ) then
              dden(ix,iy) = arhox
            else
              dden(ix,iy) = arhox * exp( - (ax-ar0)/al )
            end if
          end do
        end do
      end if
!..                                              * calculate gradient *
      do iy = 2, ly1
        do ix = 2, lx1
          ddendx(ix,iy) = ( dden(ix+1,iy) - dden(ix-1,iy) ) * 0.5d0
          ddendy(ix,iy) = ( dden(ix,iy+1) - dden(ix,iy-1) ) * 0.5d0
        end do
      end do
!....                                                    * clear dabs *
      do iy = 1, ly
        do ix = 1, lx
          dabs(ix,iy) = 0.0d0
        end do
      end do
!....
      return
      end
