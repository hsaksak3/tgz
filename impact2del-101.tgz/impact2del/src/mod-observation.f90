module observation
      use parameter
      integer :: loxs, loxe, loys, loye, lodl, &
                 lobsr, lobsp, lobsu, lobsv, lobste, lobsry
      real(8) :: dstr, dint, dtot, ddltt, dram
      character :: bident*16
end module observation
