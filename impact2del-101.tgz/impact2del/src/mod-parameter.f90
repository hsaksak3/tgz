module parameter
      integer :: lx, ly, lx1, lx2, ly1, ly2, lx3, ly3, lbndc, &
                 litrx, litrn, lvisf, lsrabs, lcheck, ldebug
      real(8) :: dxo, dyo, ddltx, dmue, dan, daz, dgam, &
                 deps, domga, dzero, dzero2, dcnvx, dcnvxn, dcnvun, &
                 dvisw, dp2te
!
      integer, parameter :: llsrbl=6, lraynt=8, lraytx=3000
      integer :: llsrbn
      real(8) :: dnuecr, drhocr, ddbncr, dlsrwl, dkappa, dkappa2
!
      real(8), parameter :: &
                 dpi  = acos( -1.0d0 ), &
                 dpi2 = dpi / 2.0d0, &
                 d2pi = 2.0d0 * dpi, &
                 dd2r = dpi / 180.0d0, &
                 dce  = 4.80320d-10, & ! esu 
                 dcc  = 2.99792d10, &  ! cm/s  
                 dcme = 9.10938d-28, & ! g
                 dcmu = 1.66054d-24, & ! g
                 dkev2erg = 1.60218d-9, & ! keV -> erg
                 dkev2j   = 1.60218d-16   ! keV -> J
end module parameter
