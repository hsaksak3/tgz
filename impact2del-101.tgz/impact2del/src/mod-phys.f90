module phys
      real(8), allocatable :: &
         dr(:,:), de(:,:), dm(:,:), dn(:,:), &
         drf(:,:), def(:,:), dmf(:,:), dnf(:,:)
      real(8), allocatable :: &
         dr2(:,:), de2(:,:), dm2(:,:), dn2(:,:)
      real(8), allocatable :: &
         dr3(:,:), de3(:,:), dm3(:,:), dn3(:,:)
      real(8), allocatable :: &
         dp(:,:), du(:,:), dv(:,:), dte(:,:), &
         dabs(:,:)
end module phys
