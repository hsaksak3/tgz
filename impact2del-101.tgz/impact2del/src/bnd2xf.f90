!----------------------------------------------------------------------
! free bomndary condition x
!
      subroutine bnd2xf
!
!   <argmments>
!     none
!
!   <remarks>
!     none
!
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do iy = 1, ly
        dr(1,iy) = dr(3,iy)
        de(1,iy) = de(3,iy)
        dm(1,iy) = dm(3,iy)
        dn(1,iy) = dn(3,iy)
!.
        dr(2,iy) = dr(3,iy)
        de(2,iy) = de(3,iy)
        dm(2,iy) = dm(3,iy)
        dn(2,iy) = dn(3,iy)
!..
        dr(lx1,iy) = dr(lx2,iy)
        de(lx1,iy) = de(lx2,iy)
        dm(lx1,iy) = dm(lx2,iy)
        dn(lx1,iy) = dn(lx2,iy)
!.
        dr(lx,iy) = dr(lx2,iy)
        de(lx,iy) = de(lx2,iy)
        dm(lx,iy) = dm(lx2,iy)
        dn(lx,iy) = dn(lx2,iy)
      end do
!....
      return
      end
