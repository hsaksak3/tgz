!----------------------------------------------------------------------
! compute boundary condition
!
      subroutine cmp2bc
!
!  <argments>
!    none
!
!  <remarks>
!    lbndc = -1 : cylindrical free
!          = mnmn : if 1112, apply y first and then apply x.
!                 : so 1112 is different from 1211.
!                   m = 0 : nothing
!                     = 1 : x
!                     = 2 : y
!                   n = 0 : nothing
!                     = 1 : free
!                     = 2 : periodic
!                     = 3 : reflect
!
!   coded by Sakagami,H. ( NIFS ) 20/05/27
!----------------------------------------------------------------------
      use parameter
      include "implicit.h"
!....
      call fprint( 'cmp2bc', 0, ldebug )
!....
      if( lbndc .eq. -1 ) then
        call bnd2cf
        goto 9
      end if
!....
      ibnd = lbndc
!..
      do i = 1, 2
        imn = mod( ibnd, 100 )
        im = imn / 10
        in = mod( imn, 10 )
        ibnd = ibnd / 100
!..
        if( im .eq. 1 ) then
          if( in .eq. 1 )then
            call bnd2xf
          else if( in .eq. 2 )then
            call bnd2xp
          else if( in .eq. 3 )then
            call bnd2xr
          end if
        else if( im .eq. 2 ) then
          if( in .eq. 1 )then
            call bnd2yf
          else if( in .eq. 2 )then
            call bnd2yp
          else if( in .eq. 3 )then
            call bnd2yr
          end if
        end if
      end do
!...
    9 continue
      call fprint( 'cmp2bc', 1, ldebug )
!....      
      return
      end
