!----------------------------------------------------------------------
! computer maximum error
!                           /      /
      subroutine cmp2er ( rval1, rval2, rerxr, rerxa, rerur, rerua )
!                                         /      /      /      /
!   <arguments>
!     rval1 : value1
!     rval2 : value2
!     rerxr : mamimum relative error
!     rerxa : mamimum absolute error
!     rerur : Euclid relative error
!     rerua : Euclid absolute error
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
! modified by Sakagami,H. ( NIFS ) 20/05/28
!----------------------------------------------------------------------
      use parameter
      include "implicit.h"
      real(8), dimension(lx,ly) :: rval1, rval2
!.... 
      call fprint( 'cmp2er', 0, ldebug )
!.... 
      avax = -999.0d0
      aerxr = -999.0d0
      aerxa = -999.0d0
      asumr = 0.0d0
      asuma = 0.0d0
!..
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix) &
!$OMP REDUCTION(MAX:avax,aerxr,aerxa) REDUCTION(+:asumr,asuma)
      do iy = 3, ly2
      do ix = 3, lx2
         adif  = abs( rval1(ix,iy) - rval2(ix,iy) )
         avax  = max( avax, rval1(ix,iy) )
         aerxr = max( aerxr, adif / rval1(ix,iy) )
         aerxa = max( aerxa, adif )
         asumr = asumr + (adif/rval1(ix,iy))**2
         asuma = asuma + adif**2
      end do
      end do
!..
      aerxa = aerxa / avax
      aerur = sqrt( asumr/((lx2-2)*(ly2-2)) )
      aerua = sqrt( asuma/((lx2-2)*(ly2-2)) ) / avax
!....
      if( ldebug .ge. 4 ) then
         write(*,*) '+++ cmp2er ---', aerxr, aerxa, aerur, aerua
      end if
!....
      rerxr = aerxr
      rerxa = aerxa
      rerur = aerur
      rerua = aerua
!....
      call fprint( 'cmp2er', 1, ldebug )
!....
      return
      end
