!----------------------------------------------------------------------
! boundary condition
!
      subroutine bnd2cf
!
!   <arguments>
!     none
!
!   <remarks>
!     free boundary is set by (1,1) direction values.
!
!    coded by Sakagami,H. ( NIFS ) 19/12/04
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
      dimension ix1(2), ix2(2), ix3(2), iy1(2), iy2(2), iy3(2)
!     data ix1, ix2, ix3 / 2, lx1,   1, lx,   3, lx2 /
!     data iy1, iy2, iy3 / 2, ly1,   1, ly,   3, ly2 /
      integer :: init = 0
      save 
!.... 
      if( init .eq. 0 ) then
         ix1(1) = 2
         ix1(2) = lx1
         ix2(1) = 1
         ix2(2) = lx
         ix3(1) = 3
         ix3(2) = lx2
         iy1(1) = 2
         iy1(2) = ly1
         iy2(1) = 1
         iy2(2) = ly
         iy3(1) = 3
         iy3(2) = ly2
         init = 1
      end if
!....
      do iy = 1, 2
      do ix = 1, 2
         dr(ix1(ix),iy1(iy)) = dr(ix3(ix),iy3(iy))
         dr(ix2(ix),iy2(iy)) = dr(ix3(ix),iy3(iy))
         dm(ix1(ix),iy1(iy)) = dm(ix3(ix),iy3(iy))
         dm(ix2(ix),iy2(iy)) = dm(ix3(ix),iy3(iy))
         dn(ix1(ix),iy1(iy)) = dn(ix3(ix),iy3(iy))
         dn(ix2(ix),iy2(iy)) = dn(ix3(ix),iy3(iy))
         de(ix1(ix),iy1(iy)) = de(ix3(ix),iy3(iy))
         de(ix2(ix),iy2(iy)) = de(ix3(ix),iy3(iy))
      end do
      end do
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix,idd, &
!$OMP          arad,add,ad1,ad2,ar1,ar2,au1,au2,aruu1,aruu2,ae1,ae2, &
!$OMP          avel,athe,auu)
      do iy = 1, ly
      do ix = 1, lx
!..
         if( ( ix .ge. 3 .and. ix .le. lx2 ) .and. &
             ( iy .ge. 3 .and. iy .le. ly2 ) ) cycle
!.
         if( ix .eq. iy ) cycle
         if( ix .eq. ( ly - iy + 1 ) ) cycle
!..
         arad = sqrt( ( ix - dxo )**2 + ( iy - dyo )**2 )
         add = arad / sqrt( 2.0d0 ) + dxo
         idd = add
         ad2 = add - idd
         ad1 = 1.0d0 - ad2
!..
         ar1 = dr(idd,idd)
         ar2 = dr(idd+1,idd+1)
         au1 = ( ( dm(idd,idd) + dn(idd,idd) ) / dr(idd,idd) &
               ) / 2.0d0 * sqrt( 2.0d0 )
         au2 = ( ( dm(idd+1,idd+1)+dn(idd+1,idd+1) ) / dr(idd+1,idd+1) &
               ) / 2.0d0 * sqrt( 2.0d0 )
         aruu1 = ar1 * au1 ** 2
         aruu2 = ar2 * au2 ** 2
         ae1 = de(idd,idd)
         ae2 = de(idd+1,idd+1)
!..
         dr(ix,iy) = ar1*ad1 + ar2*ad2
!.
         de(ix,iy) = ae1*ad1 + ae2*ad2
!.
         if( ix - dxo .eq. 0.0d0 .and. iy - dyo .eq. 0.0d0 ) then
            avel = 0.0
            athe = 0.0
         else
            auu = au1*ad1 + au2*ad2
!           if( (aruu1*ad1+aruu2*ad2)/dr(ix,iy) .lt. 0.0d0 ) then
!              write(*,*) idd, ar1, ar2, au1, au2
!              write(*,*) ix,iy,aruu1,ad1,aruu2,ad2,dr(ix,iy)
!           end if
            avel = sqrt( ( aruu1*ad1 + aruu2*ad2 ) / dr(ix,iy) )
            avel = sign( avel, auu )
            if( ix - dxo .eq. 0.0d0 .and. iy - dyo .eq. 0.0d0 ) then
               athe = 0.0d0
            else
               athe = atan2( iy - dyo, ix - dxo )
            end if
         end if
         dm(ix,iy) = avel * cos( athe ) * dr(ix,iy)
         dn(ix,iy) = avel * sin( athe ) * dr(ix,iy)
      end do
      end do
!....
      return
      end
