!----------------------------------------------------------------------
! set 2D SIMulation Parameters
!
      subroutine la2simp
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/24
!----------------------------------------------------------------------
      use parameter
      use laserabs
      implicit none
      integer :: i
      real(8) :: atmp
      real(8), parameter :: aundef  = -1.0d20, aundeff = -1.1d20
      save
!....
      namelist /laser/ dlsrwl, llsrbn, llsrnrpm, &
                       dlsrxr, dlsryr, dlsrd, dlsrf, dlsrdd, dlsrin, &
                       dlsral, dlsrpl, dlsrpw, dlsrpn
      namelist /beam/ lbemnrpm, &
                      dbemxr, dbemyr, dbemd, dbemf, dbemdd, dbemin, &
                      dbemal, dbempl, dbempw, dbempn, dbempd, &
                      dbemnx, dbemny
      namelist /ray/ ltsmode, dkappa, lolanr
!....                                              * laser parameters *
      dlsrwl = 1.06d0
      llsrbn = 1
      llsrnrpm = 5
      dlsrxr = 0.0d0
      dlsryr = 0.0d0
      dlsrd  = 0.0d0
      dlsrf  = 3.0d0
      dlsrdd = 100.0d0
      dlsrin = 1.0d12
      dlsral = 2.0d0
      dlsrpl = 3.0d0
      dlsrpw = 2.0d0
      dlsrpn = 0.005d0
!.
      read(*,nml=laser)
!..
      if( llsrbn .eq. 0 ) then
         write(*,*) '@@@ no laser beam @@@'
         call exit
      else if( llsrbn .gt. llsrbl ) then
         write(*,*) '### ERROR: laser beam number overflow', &
                    llsrbn, llsrbl
         call exit
      end if
!....                                               * beam parameters *
      do i = 1, llsrbn
         lbemnrpm(i) = -1
         dbemxr(i) = aundeff
         dbemyr(i) = aundeff
         dbemd(i)  = aundeff
         dbemf(i)  = aundeff
         dbemdd(i) = aundeff
         dbemin(i) = aundeff
         dbemal(i) = aundeff
         dbempl(i) = aundeff
         dbempw(i) = aundeff
         dbempn(i) = aundeff
         dbempd(i) = 0.0d0
         dbemnx(i) = aundeff
         dbemny(i) = aundeff
      end do
!.
      read(*,nml=beam)
!..
      do i = 1, llsrbn
        if( lbemnrpm(i) .le. 0 ) lbemnrpm(i) = llsrnrpm
        if( dbemxr(i) .le. aundef ) dbemxr(i) = dlsrxr
        if( dbemyr(i) .le. aundef ) dbemyr(i) = dlsryr
        if( dbemd(i)  .le. aundef ) dbemd(i)  = dlsrd
        if( dbemf(i)  .le. aundef ) dbemf(i)  = dlsrf
        if( dbemdd(i) .le. aundef ) dbemdd(i) = dlsrdd
        if( dbemin(i) .le. aundef ) dbemin(i) = dlsrin
        if( dbemal(i) .le. aundef ) dbemal(i) = dlsral
        if( dbempl(i) .le. aundef ) dbempl(i) = dlsrpl
        if( dbempw(i) .le. aundef ) dbempw(i) = dlsrpw
        if( dbempn(i) .le. aundef ) dbempn(i) = dlsrpn
        if( dbemnx(i) .le. aundef ) then
          write(*,*) '### ERROR: beam nx not specified ', i
          stop
        end if
        if( dbemny(i) .le. aundef ) then
          write(*,*) '### ERROR: beam ny not specified ', i
          stop
        end if
      end do
!..
      do i = 1, llsrbn
        atmp = sqrt( dbemnx(i)**2 + dbemny(i)**2 )
        if( atmp .le. dzero ) then
          write(*,*) '### ERROR: invalid beam n', i,atmp
          call exit
        end if
        dbemnx(i) = dbemnx(i) / atmp
        dbemny(i) = dbemny(i) / atmp
        if( dbempl(i) .lt. dbempw(i) ) then
          write(*,*) '### ERROR: invalid pulse length or width', &
                     i,dbempl(i),dbempw(i)
          call exit
        end if
      end do
!....                                                * ray parameters *
      ltsmode = 0
      dkappa = 0.2d0
      lolanr = 20
!.
      read(*,nml=ray)
!....
      write(*,1000) llsrbl, lraynt, lraytx
 1000 format('parameter start' / &
            ' llsrbl = ', i10 / ' lraynt = ', i10 / &
            ' lraytx = ', i10 /  &
            'parameter  end' )
      write(*,nml=laser)
      write(*,nml=beam)
      write(*,nml=ray)
!....
      allocate( dden(lx,ly), ddendx(lx,ly), ddendy(lx,ly) )
!nue  allocate( dnue(lx,ly) )
!....
      return
      end
