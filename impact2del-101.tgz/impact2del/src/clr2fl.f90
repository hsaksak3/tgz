!----------------------------------------------------------------------
! clear flux
!
      subroutine clr2fl
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
!....
      call fprint( 'clr2fl', 0, ldebug )
!.... 
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly
      do ix = 1, lx
         drf(ix,iy) = 0.0d0
         dmf(ix,iy) = 0.0d0
         dnf(ix,iy) = 0.0d0
         def(ix,iy) = 0.0d0
      end do
      end do
!....
      call fprint( 'clr2fl', 1, ldebug )
!.... 
      return
      end
