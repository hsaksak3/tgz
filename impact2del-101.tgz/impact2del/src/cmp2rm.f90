!----------------------------------------------------------------------
! compute rambda
!
      subroutine cmp2rm
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use observation
      use phys
      include "implicit.h"
!.... 
      call fprint( 'cmp2rm', 0, ldebug )
!....                                                     * set ramda *
      dram = 0.0d0
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix,acc) REDUCTION(max:dram)
      do iy = 1, ly
      do ix = 1, lx
         acc = sqrt( dgam * dp(ix,iy) / dr(ix,iy) )
         dram = max( dram, abs(du(ix,iy))+acc, abs(dv(ix,iy))+acc )
      end do
      end do
!..
      if( dram .le. 0.0d0 ) then
         write(*,*) '### ERROR in dram', dram
         call exit
      end if
!...
      dram = dmue / dram
!....
      call fprint( 'cmp2rm', 1, ldebug )
!.... 
      return
      end
