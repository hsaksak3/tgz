!----------------------------------------------------------------------
! preset simulation parameters
!
      subroutine preset
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use observation
      include "implicit.h"
!....
      namelist /param/ lx, ly, dxo, dyo, ddltx, dan, daz
      namelist /cntrl/ bident, lbndc, dmue, dgam, deps, &
                       domga, dzero, dzero2, dcnvx, dcnvxn, dcnvun, &
                       litrx, litrn, lvisf, dvisw, lsrabs, &
                       lcheck, ldebug
      namelist /observ/ dstr, dint, dtot, loxs, loxe, loys, loye, lodl,&
                        lobsr, lobsp, lobsu, lobsv, lobste, lobsry
!....
!     lx = 401
!     ly = 401
!     dxo = 1.0d100
!     dyo = 1.0d100
!     ddltx  = 1.0d0
!     dan = 6.5d0
!     daz = 3.5d0
      read( 8 ) lx,ly,dxo,dyo,ddltx,dan,daz
      write(*,nml=param)
!.
      bident = 'test00'
      lbndc = -1
      dmue = 0.95d0
      dgam = 5.0d0 / 3.0d0
!.
      deps = 0.2d0
      domga = 2.0d0
      dzero = 1.0d-6
      dzero2 = 1.0d-12
      dcnvx  = 1.0d-2
      dcnvxn = 1.0d-1
      dcnvun = 1.0d-3
!.
      litrx = 20
      litrn = 10
!.
      lvisf = 1
      dvisw = 1.15d0
!.
      lsrabs = 0
!.
      lcheck = 0
      ldebug = 0
!..
      read(*,nml=cntrl)
      write(*,nml=cntrl)
!..
      lx1 = lx - 1
      lx2 = lx - 2
      lx3 = lx - 3
      ly1 = ly - 1
      ly2 = ly - 2
      ly3 = ly - 3
      dp2te = 1.0d11 * dcmu / ( 1.0d6 * dkev2j ) * dan / ( daz + 1 )
!....
      dstr   = 0.0d0
      dint   = 1.0d0
      dtot   = 10.0d0
!.
      loxs = 1
      loxe = lx
      loys = 1
      loye = ly
      lodl = 1
      lobsr = 1
      lobsp = 0
      lobsu = 0
      lobsv = 0
      lobste= 0
      lobsry= 0
!..
      read(*,nml=observ)
      write(*,nml=observ)
!..
      ddltt = 0.1d0 * ddltx
!....
      return
      end
