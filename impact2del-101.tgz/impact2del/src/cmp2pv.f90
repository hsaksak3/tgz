!----------------------------------------------------------------------
! compute pressure and velocity
!
      subroutine cmp2pv
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
!.... 
      call fprint( 'cmp2pv', 0, ldebug )
!.... 
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly
      do ix = 1, lx
         du(ix,iy) = dm(ix,iy) / dr(ix,iy)
         dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
         dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) - &
             0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
         dte(ix,iy) = dp2te * dp(ix,iy) / dr(ix,iy)
      end do
      end do
!....
      call fprint( 'cmp2pv', 1, ldebug )
!.... 
      return
      end
