!----------------------------------------------------------------------
module laserabs
      use parameter
! laser
      integer :: llsrnrpm
      real(8) :: dlsrxr, dlsryr, dlsrd, dlsrf, dlsrdd, dlsrin, &
                 dlsral, dlsrpl, dlsrpw, dlsrpn
! beam
      integer :: lbemnrpm(llsrbl)
      real(8) :: dbemxr(llsrbl), dbemyr(llsrbl), dbemd(llsrbl), &
                 dbemf(llsrbl), dbemdd(llsrbl), dbemin(llsrbl), &
                 dbemal(llsrbl), dbempl(llsrbl), dbempw(llsrbl), &
                 dbempn(llsrbl), dbempd(llsrbl), dbemnx(llsrbl), &
                 dbemny(llsrbl), dbemxf(llsrbl), dbemyf(llsrbl), &
                 dbemxd(llsrbl), dbemyd(llsrbl), dbemw(llsrbl), &
                 dbemtx(llsrbl), dbemty(llsrbl)
! ray
      integer :: ltsmode, lraynr(llsrbl)
      real(8) :: drayam(llsrbl), draycn(llsrbl), draydx(llsrbl), &
                 drayn2(llsrbl)
      real(8) :: draybpx(4), draybpy(4), draybvx(4), draybvy(4), &
                 draybpl(4)
! hydro
      real(8), allocatable :: dden(:,:), ddendx(:,:), ddendy(:,:)
!nue  real(8), allocatable :: dnue(:,:)
! observation
      integer :: lolanr, lolabr(llsrbl), lolatl(lraynt)
      real(8) :: dolary(3,0:lraytx,lraynt)
end module laserabs
