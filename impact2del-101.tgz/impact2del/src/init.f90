!----------------------------------------------------------------------
! initialize physical values
!
      subroutine init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use phys
      use work
      include "implicit.h"
      character :: chead*4
!....
      allocate( &
         dr(lx,ly), de(lx,ly), dm(lx,ly), dn(lx,ly), &
         drf(lx,ly), def(lx,ly), dmf(lx,ly), dnf(lx,ly) )
      allocate( &
         dr2(lx,ly), de2(lx,ly), dm2(lx,ly), dn2(lx,ly) )
      allocate( &
         dr3(lx,ly), de3(lx,ly), dm3(lx,ly), dn3(lx,ly) )
      allocate( &
         dp(lx,ly), du(lx,ly), dv(lx,ly), dte(lx,ly), dabs(lx,ly) )
      allocate( &
         auu(lx,ly), avv(lx,ly), acc(lx,ly), ahh(lx,ly), &
         alfa1(lx,ly), alfa2(lx,ly), alfa3(lx,ly), alfa4(lx,ly), &
         abet1(lx,ly), abet2(lx,ly), abet3(lx,ly), abet4(lx,ly), &
         anue1(lx,ly), anue2(lx,ly), anue3(lx,ly), anue4(lx,ly), &
         arfg(lx,ly), amfg(lx,ly), anfg(lx,ly), aefg(lx,ly), &
         afg1(lx,ly), afg2(lx,ly), afg3(lx,ly), afg4(lx,ly), &
         ag1(lx,ly), ag2(lx,ly), ag3(lx,ly), ag4(lx,ly) )
!...                                                    * initial read *
      ir = 0
      ip = 0
      iu = 0
      iv = 0
    1 continue
        read( 8, end=2 ) chead, de
        if( chead .eq. 'i2r ' ) then
          do iy = 1, ly 
          do ix = 1, lx 
            dr(ix,iy) = de(ix,iy)
          end do
          end do
          ir = ir + 1
        else if( chead .eq. 'i2p ' ) then
          do iy = 1, ly 
          do ix = 1, lx 
            dp(ix,iy) = de(ix,iy)
          end do
          end do
          ip = ip + 1
        else if( chead .eq. 'i2u ' ) then
          do iy = 1, ly 
          do ix = 1, lx 
            du(ix,iy) = de(ix,iy)
          end do
          end do
          iu = iu + 1
        else if( chead .eq. 'i2v ' ) then
          do iy = 1, ly 
          do ix = 1, lx 
            dv(ix,iy) = de(ix,iy)
          end do
          end do
          iv = iv + 1
        end if
      go to 1
    2 continue
!.            * r and p must exist. u and v are optional, if not zero *
      if( ir .ne. 1 .or. ip .ne. 1 ) then
        write(*,*) '### ERROR in fort.8. r and p must exist.',ir,ip
        call exit
      end if
      if( iu .eq. 0 ) then
        do iy = 1, ly 
        do ix = 1, lx 
          du(ix,iy) = 0.0d0
        end do
        end do
      end if
      if( iv .eq. 0 ) then
        do iy = 1, ly 
        do ix = 1, lx 
          dv(ix,iy) = 0.0d0
        end do
        end do
      end if
!...
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly 
      do ix = 1, lx 
         dm(ix,iy) = du(ix,iy) * dr(ix,iy)
         dn(ix,iy) = dv(ix,iy) * dr(ix,iy)
         de(ix,iy) = dp(ix,iy) / ( dgam - 1.0d0 ) + &
              0.5d0 * ( dm(ix,iy) * du(ix,iy) + dn(ix,iy) * dv(ix,iy) )
         dte(ix,iy) = dp2te * dp(ix,iy) / dr(ix,iy)
      end do
      end do
!....
      return
      end
