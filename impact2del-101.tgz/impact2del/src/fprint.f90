!----------------------------------------------------------------------
! print elapse time, etc
!                           /      /       /
      subroutine fprint ( ename, kmode, kdebug )
!
!   <arguments>
!     ename : subroutine name
!     kmode :  0 = entry, 1 = exit, 2 = entry/exit
!           : -1 = start, -2 = end, -3 = cputime write
!     kdebug: 1 = elapse time measurement mode
!             >=5 = check write mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/04/07
!----------------------------------------------------------------------
!$    use parameter, only: lraynt
      implicit none
      integer, parameter :: isubx = 10
      integer :: kmode, kdebug, i, isubn, isubcn(isubx)
      real(8) :: fgetwtod, asum, asump, atot, atotst, alapst, &
                 asubst(isubx), asubsm(isubx)
      character :: cdata*32, cname*8, csubnm(isubx)*8, ename*(*)
!$    integer OMP_GET_MAX_THREADS, itx
      save
!....
      if( kmode .eq. -1 ) then
        call fdate ( cdata )
        write(*,*) '+++++ ',ename,' started at ',cdata(1:24),' +++++'
#ifndef DIST9
        write(*,*) '+++++ 4 points distribution'
#endif
#ifdef DIST9
        write(*,*) '+++++ 9 points distribution'
#endif
!$      itx = OMP_GET_MAX_THREADS()
!$      write(*,*) '+++++ OMP_GET_MAX_THREADS = ', itx
!$      cdata = ' '
!$      call get_environment_variable ( 'OMP_STACKSIZE', cdata ) 
!$      if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$      write(*,*) '+++++ OMP_STACKSIZE = ', trim(cdata)
!$      if( itx .gt. lraynt ) then
!$        write(*,*) '### ERROR MAX_THREADS > lraynt', lraynt
!$        call exit    
!$      end if  
!.
        atotst = fgetwtod()
        alapst = atotst
        csubnm(01) = 'advnc2'
        csubnm(02) = 'cmp2bc'
        csubnm(03) = 'clr2fl'
        csubnm(04) = 'cmp2er'
        csubnm(05) = 'cmp2fx'
        csubnm(06) = 'cmp2fy'
        csubnm(07) = 'cmp2pv'
        csubnm(08) = 'cmp2rm'
        csubnm(09) = 'la2init'
        csubnm(10) = 'la2main'
        do i = 1, isubx
          asubsm(i) = 0.0d0
          isubcn(i) = 0
        end do
!..
      else if( kmode .eq. -2 ) then
         call fdate ( cdata )
         write(*,*) '----- ',ename,' ended at ',cdata(1:24),' -----'
         write(*,*) '      elapse time =', fgetwtod() - atotst
         if ( kdebug .eq. 1 ) then
            atot = fgetwtod() - atotst
            asum = 0.0d0
            asump = 0.0d0
            write(*,1000)
            do i = 1, isubx
               asum = asum + asubsm(i)
               asump = asump + asubsm(i)/atot*100.0d0
               write(*,1100) csubnm(i), asubsm(i), &
                            asubsm(i)/atot*100.0d0, isubcn(i)
            end do
            write(*,1000)
            write(*,1100) 'sum', asum, asump, 0
            write(*,1000)
            write(*,1100) 'total', atot, 100.0, 0
            write(*,1000)
         end if
!..
      else if( kmode .eq. -3 ) then
         atot = fgetwtod()
         write(*,*) '    lap, elapse time =', &
                                        atot - alapst, atot - atotst
         alapst = atot
      end if
!...
      if ( kdebug .eq. 1 ) then
         cname = ename
         isubn = 0
         do i = 1, isubx
            if( cname .eq. csubnm(i) ) then
               isubn = i
               exit
            end if
         end do
         if( kmode .eq. 0 ) then
            if( isubn .ne. 0 ) then
               asubst(isubn) = fgetwtod()
            end if
         else if( kmode .eq. 1 ) then
            if( isubn .ne. 0 ) then
               asubsm(isubn) = asubsm(isubn) + &
                                        fgetwtod() - asubst(isubn)
               isubcn(isubn) = isubcn(isubn) + 1
            end if
         end if
      end if
!...
      if ( kdebug .ge. 5 ) then
         cname = ename
         if( kmode .eq. 0 ) then
            write(*,*) '+++ ', cname, ' +++'
         else if( kmode .eq. 1 ) then
            write(*,*) '--- ', cname, ' ---'
         else if( kmode .eq. 2 ) then
            write(*,*) '+++ ', cname, ' ---'
         end if
      end if
!....
      return
 1000 format( ' +----------+--------------+--------+------------+' )
 1100 format( ' | ', a8, ' | ', f12.2, ' | ', f6.2, ' | ', i10, ' |' )
      end
