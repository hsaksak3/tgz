!----------------------------------------------------------------------
! advance in all directions in half value
!                          /    /    /    /
      subroutine advnc2 ( rr1, rm1, rn1, re1, &
                          rr2, rm2, rn2, re2 )
!                          /    /    /    /
!
!   <arguments>
!     rr[12]: rho
!     rm[12]: x momentum
!     rn[12]: y momentum
!     re[12]: energy
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
      real(8), dimension(lx,ly) :: rr1,rm1,rn1,re1,rr2,rm2,rn2,re2
!.... 
      call fprint( 'advnc2', 0, ldebug )
!.... 
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 3, ly2
      do ix = 3, lx2
         rr2(ix,iy) = rr1(ix,iy) + drf(ix,iy) * 0.5d0
         rm2(ix,iy) = rm1(ix,iy) + dmf(ix,iy) * 0.5d0
         rn2(ix,iy) = rn1(ix,iy) + dnf(ix,iy) * 0.5d0
         re2(ix,iy) = re1(ix,iy) + def(ix,iy) * 0.5d0
      end do
      end do
!.... 
      call fprint( 'advnc2', 1, ldebug )
!....
      return
      end
