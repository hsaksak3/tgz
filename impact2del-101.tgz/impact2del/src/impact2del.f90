!----------------------------------------------------------------------
! main program of impact-2d enhanced precision with laser absorption
! (impact-2del)
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 20/04/07
!----------------------------------------------------------------------
      use parameter
      use observation
      use laserabs
      use phys
      include "implicit.h"
      character :: cvers*18
!....
      cvers = 'impact-2del V1.R01'
      call fprint( cvers, -1, ldebug )
!....
      call preset
      if( lsrabs .gt. 0 ) then
         call la2simp
         call la2cnst
      end if
!....
      call init
!....
      atime = 0.0d0
      dtot  = dtot - dzero
      if( astr - dzero .gt. 0.0d0 ) then
         alapt = dint - dstr
      else
         alapt = 0.0d0
      end if
      istep = 0
      ilaps = 0
      ilapi = 0
      iobs = 0
      ioxl = ( loxe - loxs ) / lodl + 1
      ioyl = ( loye - loys ) / lodl + 1
      iocn = 0
      amesh = lodl * ddltx
      axp0m = ( dxo - loxs ) * ddltx
      ayp0m = ( dyo - loys ) * ddltx
!....
      write(6,*) '@@@ time = ', atime
      if( lobsr .ne. 0 ) then
         write(10) 'i2r ', bident, ioxl, ioyl, amesh, axp0m, ayp0m
         write(10) atime, &
               ( ( dr(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
         flush(10)
      end if
      if( lobsp .ne. 0 ) then
         write(11) 'i2p ', bident, ioxl, ioyl, amesh, axp0m, ayp0m
         write(11) atime, &
               ( ( dp(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
         flush(11)
      end if
      if( lobsu .ne. 0 ) then
         write(12) 'i2u ', bident, ioxl, ioyl, amesh, axp0m, ayp0m
         write(12) atime, &
               ( ( du(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
         flush(12)
      end if
      if( lobsv .ne. 0 ) then
         write(13) 'i2v ', bident, ioxl, ioyl, amesh, axp0m, ayp0m
         write(13) atime, &
               ( ( dv(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
         flush(13)
      end if
      if( lobste .ne. 0 ) then
         write(14) 'i2te', bident, ioxl, ioyl, amesh, axp0m, ayp0m
         write(14) atime, &
               ( ( dte(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
         flush(14)
      end if
      if( lsrabs .gt. 0 ) then
        if( lobsry .ne. 0 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
          do iy = loys,loye,lodl
          do ix = loxs,loxe,lodl 
            dden(ix,iy) = dr(ix,iy) * drhocr
            dabs(ix,iy) = 0.0d0
          end do
          end do 
          write(20) 'i2RY', bident, ioxl, ioyl, amesh, axp0m, ayp0m
          write(20) atime, &
               ( ( dden(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
          write(20) atime, &
               ( ( dabs(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
          flush(20)
          write(21) 'i2ry', bident, llsrbn, lraytx, lolanr, &
                    dxo, dyo, ddltx
          write(21) -1,1,atime,atime,atime
          flush(21)
        end if
      end if
      iocn = iocn + 1
!....
   90 continue
!..
      call cmp2rm
      alapt = alapt + dram * ddltt
      if( alapt .gt. dint ) then
         dram = ( dint - ( alapt - dram * ddltt ) ) / ddltt
         iobs = 1
      end if
!..                                                 * compute flux(n) *
      call clr2fl
      call cmp2fx
      call cmp2fy
!.                                                      * advance t/2 *
      call advnc2 ( dr, dm, dn, de, dr2, dm2, dn2, de2 )
!.                                      * advance t/2 to compute U(*) *
      call advnc2 ( dr2, dm2, dn2, de2, dr, dm, dn, de )
!..
      itrex = 0
      do iter = 1, litrx
!.                                                * compute flux(n+1) *
         call cmp2bc
         call cmp2pv
         if( lcheck .ge. 1 ) call check ( ldebug )
         call clr2fl
         call cmp2fx
         call cmp2fy
!.                                    * advance t/2 to compute U(n+1) *
         call advnc2 ( dr2, dm2, dn2, de2, dr3, dm3, dn3, de3 )
!.                                            * compute maximum error * 
         call cmp2er ( dr3, dr, aerxr, aerxa, aerur, aerua ) 
!.
         if( ( aerxr .le. dcnvx ) .or. &
             ( aerxr .le. dcnvxn .and. iter .ge. litrn ) .or. &
             ( aerur .le. dcnvun .and. iter .ge. litrn ) ) then
            call cmp2bc
            call cmp2pv
            if( lcheck .ge. 1 ) call check ( ldebug )
            itrex = iter
            exit
         end if
!..
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = 3, ly2
         do ix = 3, lx2
            dr(ix,iy) = ( dr3(ix,iy) + dr(ix,iy) ) * 0.5d0
            dm(ix,iy) = ( dm3(ix,iy) + dm(ix,iy) ) * 0.5d0
            dn(ix,iy) = ( dn3(ix,iy) + dn(ix,iy) ) * 0.5d0
            de(ix,iy) = ( de3(ix,iy) + de(ix,iy) ) * 0.5d0
         end do
         end do
!.
      end do
!..
      if( itrex .eq. 0 ) then
         write(*,*) '### ERROR:not converge ***', &
                    aerxr, aerxa, aerur, aerua
         write(*,*) '    atime, istep, iocn = ', atime, istep, iocn
         call fprint( cvers, -3, ldebug )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = 3, ly2
         do ix = 3, lx2
            dr(ix,iy) = 2.0d0 * dr(ix,iy) - dr3(ix,iy)
            dm(ix,iy) = 2.0d0 * dm(ix,iy) - dm3(ix,iy)
            dn(ix,iy) = 2.0d0 * dn(ix,iy) - dn3(ix,iy)
            de(ix,iy) = 2.0d0 * de(ix,iy) - de3(ix,iy)
         end do
         end do
         write(90) lx,ly
         write(90) dr
         write(90) dm
         write(90) dn
         write(90) de
         write(90) dr3
         write(90) dm3
         write(90) dn3
         write(90) de3
         call exit
      end if
!...
      atime = atime + dram * ddltt
      istep = istep + 1
      ilaps = ilaps + 1
      ilapi = ilapi + itrex
      if( ldebug .ge. 2 ) write(*,*) 'debug2:', &
                            atime,istep,itrex,aerxr,dram
      if( iobs .eq. 1 ) &
         write(*,'(a,f6.3,3i6)') &
         '@@@ time, istep, ilaps, ilapi = ', atime, istep, ilaps, ilapi
!
      if( lsrabs .gt. 0 ) then
         if( mod(istep,lsrabs) .eq. 0 .or. lobsry*iobs .ne. 0 ) then
            call la2init ( atime )
            call la2main ( atime, lobsry*iobs )
         end if
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = 3, ly2
         do ix = 3, lx2
            de(ix,iy) = de(ix,iy) + dabs(ix,iy) * dram
         end do
         end do
      end if
!...
      if( iobs .eq. 1 ) then
         call fprint( cvers, -3, ldebug )
         if( lobsr .ne. 0 ) then
            write(10) atime, &
               ( ( dr(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
            flush(10)
         end if
         if( lobsp .ne. 0 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = loys,loye,lodl
            do ix = loxs,loxe,lodl
               dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) - &
                0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
            end do
            end do
            write(11) atime, &
               ( ( dp(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
            flush(11)
         end if
         if( lobsu .ne. 0 ) then
            write(12) atime, &
               ( ( du(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
            flush(12)
         end if
         if( lobsv .ne. 0 ) then
            write(13) atime, &
               ( ( dv(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
            flush(13)
         end if
         if( lobste .ne. 0 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = loys,loye,lodl
            do ix = loxs,loxe,lodl
               dte(ix,iy) = dp2te * dp(ix,iy) / dr(ix,iy)
            end do
            end do
            write(14) atime, &
               ( ( dte(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
            flush(14)
         end if
         if( lsrabs .gt. 0 ) then
           if( lobsry .ne. 0 ) then
             write(20) atime, &
               ( ( dden(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
             write(20) atime, &
               ( ( dabs(ix,iy),ix=loxs,loxe,lodl ),iy=loys,loye,lodl )
             flush(20)
           end if
         end if
         iocn = iocn + 1
         alapt = 0.0d0
         ilaps = 0
         ilapi = 0
         iobs = 0
      end if
!....
      if( atime .le. dtot ) go to 90
!....
      write(6,*) '@@@ total step        = ', istep
      write(6,*) '@@@ output data count = ', iocn
      call fprint ( cvers, -2, ldebug )
!....
      stop
      end
