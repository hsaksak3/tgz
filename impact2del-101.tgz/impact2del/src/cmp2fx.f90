!----------------------------------------------------------------------
! compute flux in x-advance
!
      subroutine cmp2fx
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/05
!----------------------------------------------------------------------
      use parameter
      use observation
      use phys
      use work
      include "implicit.h"
!.... 
      call fprint( 'cmp2fx', 0, ldebug )
!....                     * set u^(j+1/2,k), v^(j+1/2,k), c^(j+1/2,k) *
!$OMP PARALLEL PRIVATE(ix,ah0,ah1,adr,adm,adn,ade,ac1,ac2,aq,agg)
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 1, lx1
         ah0 = ( de(ix  ,iy) + dp(ix  ,iy) ) / dr(ix  ,iy)
         ah1 = ( de(ix+1,iy) + dp(ix+1,iy) ) / dr(ix+1,iy)
!..
         auu(ix,iy) = ( sqrt( dr(ix  ,iy) ) * du(ix  ,iy) + &
                       sqrt( dr(ix+1,iy) ) * du(ix+1,iy) ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         avv(ix,iy) = ( sqrt( dr(ix  ,iy) ) * dv(ix  ,iy) + &
                       sqrt( dr(ix+1,iy) ) * dv(ix+1,iy) ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         ahh(ix,iy) = ( sqrt( dr(ix  ,iy) ) * ah0 + &
                       sqrt( dr(ix+1,iy) ) * ah1 ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         acc(ix,iy) = sqrt( ( dgam - 1.0d0 ) * &
          ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) ) )
      end do
      end do
!....                                          * set alfa(l)(j+1/2,k) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 1, lx1
         adr = dr(ix+1,iy) - dr(ix,iy)
         adm = dm(ix+1,iy) - dm(ix,iy)
         adn = dn(ix+1,iy) - dn(ix,iy)
         ade = de(ix+1,iy) - de(ix,iy)
!..
         if( acc(ix,iy)  .gt. dzero ) then
            ac1 = ( dgam - 1.0d0 ) * &
              ( ade + 0.5d0 * adr * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) &
          - ( adm * auu(ix,iy) + adn * avv(ix,iy) ) ) / acc(ix,iy)**2
            ac2 = ( adm - adr * auu(ix,iy) ) / acc(ix,iy)
!..
            alfa1(ix,iy) = 0.5d0 * ( ac1 - ac2 )
            alfa2(ix,iy) = adr - ac1
            alfa3(ix,iy) = adn - adr * avv(ix,iy)
            alfa4(ix,iy) = 0.5d0 * ( ac1 + ac2 )
         else
            alfa1(ix,iy) = 0.d0
            alfa2(ix,iy) = adr
            alfa3(ix,iy) = adn - adr * avv(ix,iy)
            alfa4(ix,iy) = 0.d0
         end if
      end do
      end do
!....                                               * nue(l)(j+1/2,k) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 1, lx1
         anue1(ix,iy) = auu(ix,iy) - acc(ix,iy)
         anue2(ix,iy) = auu(ix,iy)
         anue3(ix,iy) = auu(ix,iy)
         anue4(ix,iy) = auu(ix,iy) + acc(ix,iy)
      end do
      end do
!.
      if( lvisf .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = 1, ly
         do ix = 1, lx1
            anue3(ix,iy) = dvisw * &
                  sign( sqrt(auu(ix,iy)**2+avv(ix,iy)**2), auu(ix,iy) )
         end do
         end do
      end if
!.
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 1, lx1
         anue1(ix,iy) = anue1(ix,iy) * dram
         anue2(ix,iy) = anue2(ix,iy) * dram
         anue3(ix,iy) = anue3(ix,iy) * dram
         anue4(ix,iy) = anue4(ix,iy) * dram
      end do
      end do
!....                                     * set g(l)(j+1/2,k),l=1,2,3 *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 2, lx1
!..                                                           * l = 1 *
         if( alfa1(ix-1,iy) * alfa1(ix,iy) .gt. dzero2 ) then
            if( alfa1(ix,iy) .gt. 0.0d0 ) then
               ag1(ix,iy) = min( alfa1(ix-1,iy), alfa1(ix,iy) )
            else
               ag1(ix,iy) = max( alfa1(ix-1,iy), alfa1(ix,iy) )
            end if
         else
            ag1(ix,iy) = 0.0d0
         end if
!..                                                           * l = 2 *
         if( alfa2(ix-1,iy) * alfa2(ix,iy) .gt. dzero2 ) then
            if( alfa2(ix,iy) .gt. 0.0d0 ) then
               ag2(ix,iy) = min( alfa2(ix-1,iy), alfa2(ix,iy) )
            else
               ag2(ix,iy) = max( alfa2(ix-1,iy), alfa2(ix,iy) )
            end if
            afg2(ix,iy) = domga * abs( alfa2(ix,iy) - alfa2(ix-1,iy) ) &
                     / ( abs( alfa2(ix,iy) ) + abs( alfa2(ix-1,iy) ) )
         else
            ag2(ix,iy)   = 0.0d0
            afg2(ix,iy) = 0.0d0
         end if
!..                                                           * l = 3 *
         if( alfa3(ix-1,iy) * alfa3(ix,iy) .gt. dzero2 ) then
            if( alfa3(ix,iy) .gt. 0.0d0 ) then
               ag3(ix,iy) = min( alfa3(ix-1,iy), alfa3(ix,iy) )
            else
               ag3(ix,iy) = max( alfa3(ix-1,iy), alfa3(ix,iy) )
            end if
            afg3(ix,iy) = domga * abs( alfa3(ix,iy) - alfa3(ix-1,iy) ) &
                     / ( abs( alfa3(ix,iy) ) + abs( alfa3(ix-1,iy) ) )
         else
            ag3(ix,iy)   = 0.0d0
            afg3(ix,iy) = 0.0d0
         end if
!..                                                           * l = 4 *
         if( alfa4(ix-1,iy) * alfa4(ix,iy) .gt. dzero2 ) then
            if( alfa4(ix,iy) .gt. 0.0d0 ) then
               ag4(ix,iy) = min( alfa4(ix-1,iy), alfa4(ix,iy) )
            else
               ag4(ix,iy) = max( alfa4(ix-1,iy), alfa4(ix,iy) )
            end if
         else
            ag4(ix,iy) = 0.0d0
         end if
      end do
      end do
!....                       * set nue(l)(j+1/2,k) + gamma(l)(j+1/2,k) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 2, lx2
!.
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue1(ix,iy)**2 )
         abet1(ix,iy) = agg * ( ag1(ix+1,iy) + ag1(ix,iy) )
         if( abs( alfa1(ix,iy) ) .ge. dzero ) then
            anue1(ix,iy) = anue1(ix,iy) + &
                    agg * ( ag1(ix+1,iy) - ag1(ix,iy) ) / alfa1(ix,iy)
         end if
!.
         aq  = abs( anue2(ix,iy) )
         agg = 0.5d0 * ( aq - anue2(ix,iy)**2 ) &
                     * ( 1.0d0 + max( afg2(ix+1,iy), afg2(ix,iy) ) )
         abet2(ix,iy) = agg * ( ag2(ix+1,iy) + ag2(ix,iy) )
         if( abs( alfa2(ix,iy) ) .ge. dzero ) then
            anue2(ix,iy) = anue2(ix,iy) + &
                    agg * ( ag2(ix+1,iy) - ag2(ix,iy) ) / alfa2(ix,iy)
         end if
!.
         aq  = abs( anue3(ix,iy) )
         agg = 0.5d0 * ( aq - anue3(ix,iy)**2 ) &
                     * ( 1.0d0 + max( afg3(ix+1,iy), afg3(ix,iy) ) )
         abet3(ix,iy) = agg * ( ag3(ix+1,iy) + ag3(ix,iy) )
         if( abs( alfa3(ix,iy) ) .ge. dzero ) then
            anue3(ix,iy) = anue3(ix,iy) + &
                    agg * ( ag3(ix+1,iy) - ag3(ix,iy) ) / alfa3(ix,iy)
         end if
!.
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue4(ix,iy)**2 )
         abet4(ix,iy) = agg * ( ag4(ix+1,iy) + ag4(ix,iy) )
         if( abs( alfa4(ix,iy) ) .ge. dzero ) then
            anue4(ix,iy) = anue4(ix,iy) + &
                    agg * ( ag4(ix+1,iy) - ag4(ix,iy) ) / alfa4(ix,iy)
         end if
      end do
      end do
!....                                          * set beta(l)(j+1/2,k) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 2, lx2
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet1(ix,iy) = abet1(ix,iy) - aq * alfa1(ix,iy)
         aq = abs( anue2(ix,iy) )
         abet2(ix,iy) = abet2(ix,iy) - aq * alfa2(ix,iy)
         aq = abs( anue3(ix,iy) )
         abet3(ix,iy) = abet3(ix,iy) - aq * alfa3(ix,iy)
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet4(ix,iy) = abet4(ix,iy) - aq * alfa4(ix,iy)
      end do
      end do
!....                                  * set modified flux f(j+1/2,k) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly 
      do ix = 1, lx 
         arfg(ix,iy) = dm(ix,iy)
         amfg(ix,iy) = dm(ix,iy) * du(ix,iy) + dp(ix,iy)
         anfg(ix,iy) = dm(ix,iy) * dv(ix,iy)
         aefg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * du(ix,iy)
      end do  
      end do  
!..
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 2, lx2
         afg1(ix,iy) = 0.5d0 * ( arfg(ix,iy) + arfg(ix+1,iy) + &
               ( abet1(ix,iy) + abet2(ix,iy) + abet4(ix,iy) ) / dram )
         afg2(ix,iy) = 0.5d0 * ( amfg(ix,iy) + amfg(ix+1,iy) + &
               ( abet1(ix,iy) * ( auu(ix,iy) - acc(ix,iy) ) + &
                 abet2(ix,iy) *   auu(ix,iy)                + &
                 abet4(ix,iy) * ( auu(ix,iy) + acc(ix,iy) ) ) / dram )
         afg3(ix,iy) = 0.5d0 * ( anfg(ix,iy) + anfg(ix+1,iy) + &
         ( ( abet1(ix,iy)+abet2(ix,iy)+abet4(ix,iy) ) * avv(ix,iy) + &
             abet3(ix,iy) ) / dram )
         afg4(ix,iy) = 0.5d0 * ( aefg(ix,iy) + aefg(ix+1,iy) + &
      ( abet1(ix,iy) * ( ahh(ix,iy)-auu(ix,iy)*acc(ix,iy) ) + &
        abet2(ix,iy) * 0.5d0 * ( auu(ix,iy)**2+avv(ix,iy)**2 ) + &
        abet3(ix,iy) * avv(ix,iy)                              + &
        abet4(ix,iy) * ( ahh(ix,iy)+auu(ix,iy)*acc(ix,iy) ) ) / dram )
      end do
      end do
!....                                                 * set flux *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 3, lx2
         drf(ix,iy) = drf(ix,iy) + dram * ( afg1(ix-1,iy)-afg1(ix,iy) )
         dmf(ix,iy) = dmf(ix,iy) + dram * ( afg2(ix-1,iy)-afg2(ix,iy) )
         dnf(ix,iy) = dnf(ix,iy) + dram * ( afg3(ix-1,iy)-afg3(ix,iy) )
         def(ix,iy) = def(ix,iy) + dram * ( afg4(ix-1,iy)-afg4(ix,iy) )
      end do
      end do
!$OMP END PARALLEL
!.... 
      call fprint( 'cmp2fx', 1, ldebug )
!....
      return
      end
