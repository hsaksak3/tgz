!----------------------------------------------------------------------
! 2D MAIN
!                            /      /
      subroutine la2main ( rtime, kobs )
!
!   <arguments>
!     rtime : time (nsec)
!     kobs :: observation flag
!
!   <remarks>
!     if DIST9 is defined, 9 points distribution is used.
!     Otherwise, 4 points distribution is used.
!
!    coded by Sakagami,H. (NIFS) 20/03/25
!----------------------------------------------------------------------
      use parameter
      use laserabs
      use phys
      implicit none
      integer :: ib, i, it, in, irn, irer, inside, isc, iraytl, itn, &
                 imx, imy, imx2, imy2, ittl, iovst, kobs
      real(8) :: arr, apx, apy, avx, avy, avv, at, as, att(2), afac
      real(8) :: adx, ady, adx2, ady2, adrdx, adrdy, aden, atem, &
                 anueo, anuen, apwri, apwra, apwrd, &
                 araypx, araypy, arayvx, arayvy, arayna, araypr, rtime
!$    integer :: OMP_GET_THREAD_NUM
      save
!....
      call fprint( 'la2main', 0, ldebug )
!....
      afac = 1.0d0
!....
      do ib = 1, llsrbn
!                               * check focus point is inside or not *
      inside = 0
      if( dbemxf(ib) .le. draybpx(1) .or. &
          dbemxf(ib) .ge. draybpx(3) .or. &
          dbemyf(ib) .le. draybpy(1) .or. &
          dbemyf(ib) .ge. draybpy(3) ) then
        inside = 1
      end if
      irn   = 0
      irer  = 0
      apwri = 0.0d0
      apwra = 0.0d0
      itn   = 1
      ittl  = 0
      iovst = 0
!....
!$OMP PARALLEL DO SCHEDULE(DYNAMIC,1) &
!$OMP   REDUCTION(+:irn,irer,ittl,iovst,apwri,apwra,dabs),&
!$OMP   FIRSTPRIVATE(afac), &
!$OMP   PRIVATE(isc,in,itn,imx,imy,imx2,imy2,iraytl, &
!$OMP     adx,ady,adx2,ady2,apx,apy,avx,avy,avv,at,as,att, &
!$OMP     aden,atem,apwrd,arr,araypx,araypy,arayvx,arayvy, &
!$OMP     arayna,araypr,anueo,anuen)
        do i = 1, lraynr(ib)
!$        itn = OMP_GET_THREAD_NUM() + 1
!...                                                    * initialize *
!.                                   * find start point and velocity *
          arr = draydx(ib) * ( i - drayn2(ib) )
          apx = dbemxd(ib) + arr * dbemtx(ib)
          apy = dbemyd(ib) + arr * dbemty(ib)
          arr = exp( - 8.0d0 * abs(arr/dbemw(ib))**dbemal(ib) ) * &
                drayam(ib)
          avx = apx - dbemxf(ib)
          avy = apy - dbemyf(ib)
          avv = sqrt( avx**2 + avy**2 )
          avx = avx / avv
          avy = avy / avv
!                            * find intersection with boundary lines *
!                                        * inside = one intersection *
!                               * outside = two or zero intersection *
          isc = 0
          do in = 1, 4
            avv = avx * draybvx(in) + avy * draybvy(in)
            if( 1.0d0 - avv .lt. dzero ) cycle
            at = ( (draybpx(in)-dbemxf(ib))*(avx-avv*draybvx(in)) + &
                   (draybpy(in)-dbemyf(ib))*(avy-avv*draybvy(in)) ) / &
                 ( 1.0d0 - avv**2 )
            if( at .le. 0.0d0 ) cycle
            as = ( (draybpx(in)-dbemxf(ib))*(avv*avx-draybvx(in)) + &
                   (draybpy(in)-dbemyf(ib))*(avv*avy-draybvy(in)) ) / &
                 ( 1.0d0 - avv**2 )
            if( as .lt. 0.0d0 .or. as .ge. draybpl(in) ) cycle
!
            isc = isc + 1
            att(isc) = at
          end do
!                                                             * check *
          if( inside .eq. 0 ) then
            if( isc .ne. 1 ) then
              write(*,*) '### ERROR: inside, but not 1', ib, i, isc
              write(*,*) dbemxf(ib),dbemyf(ib),dbemxd(ib),dbemyd(ib), &
                         apx, apy, avx, avy
              call exit
            end if
          else
            if( isc .ne. 0 .and. isc .ne. 2 ) then
              write(*,*) '### ERROR: outside, but not 0 or 2', &
                         ib, i, isc
              write(*,*) dbemxf(ib),dbemyf(ib),dbemxd(ib),dbemyd(ib), &
                         apx, apy, avx, avy
              call exit
            end if
            if( att(2) .gt. att(1) ) then
              att(1) = att(2)
            end if
          end if
!
          if( isc .gt. 0 ) then
            araypx = dbemxf(ib) + avx * att(1)
            araypy = dbemyf(ib) + avy * att(1)
            imx = araypx
            imy = araypy
            adx = araypx - imx
            ady = araypy - imy
!
            aden = (1.0d0-adx)*(1.0d0-ady) * dden(imx  ,imy  ) + &
                          adx *(1.0d0-ady) * dden(imx+1,imy  ) + &
                   (1.0d0-adx)*       ady  * dden(imx  ,imy+1) + &
                          adx *       ady  * dden(imx+1,imy+1)
            if( aden .ge. 1.0d0 ) then
              write(*,*) '### ERROR: overdense!', ib, i, aden
              call exit
            end if
            atem = ( (1.0d0-adx)*(1.0d0-ady) * dte(imx  ,imy  ) + &
                            adx *(1.0d0-ady) * dte(imx+1,imy  ) + &
                     (1.0d0-adx)*       ady  * dte(imx  ,imy+1) + &
                            adx *       ady  * dte(imx+1,imy+1) ) ** &
                   ( 3.0d0/2.0d0 )
            arayvx  = -avx * sqrt( 1.0d0 - aden )
            arayvy  = -avy * sqrt( 1.0d0 - aden )
!
!low Te     anueo = dnuecr/atem * log(ddbncr*atem/sqrt(aden)) * aden**2
            anueo=dnuecr/atem*log(1.0d0+ddbncr*atem/sqrt(aden))*aden**2
!nue        anueo = (1.0d0-adx)*(1.0d0-ady) * dnue(imx  ,imy  ) + &
!nue                       adx *(1.0d0-ady) * dnue(imx+1,imy  ) + &
!nue                (1.0d0-adx)*       ady  * dnue(imx  ,imy+1) + &
!nue                       adx *       ady  * dnue(imx+1,imy+1)
            apwrd = arr * ( 1.0d0 - exp( -anueo ) )
            araypr = arr - apwrd
!
            if( araypr .lt. dbempn(ib) ) then
              cycle
            end if
            apwrd = apwrd * draycn(ib)
!                                                            * 1point *
!1point     imx2 = arayxy + 0.5d0
!1point     imy2 = araypy + 0.5d0
!1point     dabs(imx2 ,imy2 ) = dabs(imx2 ,imy2 ) + apwrd
!                                                           * 4points *
#ifndef DIST9
            dabs(imx  ,imy  ) = dabs(imx  ,imy  ) + &
                                (1.0d0-adx)*(1.0d0-ady) * apwrd
            dabs(imx+1,imy  ) = dabs(imx+1,imy  ) + &
                                       adx *(1.0d0-ady) * apwrd
            dabs(imx  ,imy+1) = dabs(imx  ,imy+1) + &
                                (1.0d0-adx)*       ady  * apwrd
            dabs(imx+1,imy+1) = dabs(imx+1,imy+1) + &
                                       adx *       ady  * apwrd
#endif
!                                                           * 9points *
#ifdef DIST9
            imx2 = araypx + 0.5d0
            imy2 = araypy + 0.5d0
            adx2 = araypx - imx2
            ady2 = araypy - imy2
            dabs(imx2-1,imy2-1) = dabs(imx2-1,imy2-1) + &
                  0.5d0*(0.5d0-adx2)**2 * 0.5d0*(0.5d0-ady2)**2 * apwrd
            dabs(imx2  ,imy2-1) = dabs(imx2  ,imy2-1) + &
                     ( 0.75d0-adx2**2 ) * 0.5d0*(0.5d0-ady2)**2 * apwrd
            dabs(imx2+1,imy2-1) = dabs(imx2+1,imy2-1) + &
                  0.5d0*(0.5d0+adx2)**2 * 0.5d0*(0.5d0-ady2)**2 * apwrd
            dabs(imx2-1,imy2  ) = dabs(imx2-1,imy2  ) + &
                  0.5d0*(0.5d0-adx2)**2 *    ( 0.75d0-ady2**2 ) * apwrd
            dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + &
                     ( 0.75d0-adx2**2 ) *    ( 0.75d0-ady2**2 ) * apwrd
            dabs(imx2+1,imy2  ) = dabs(imx2+1,imy2  ) + &
                  0.5d0*(0.5d0+adx2)**2 *    ( 0.75d0-ady2**2 ) * apwrd
            dabs(imx2-1,imy2+1) = dabs(imx2-1,imy2+1) + &
                  0.5d0*(0.5d0-adx2)**2 * 0.5d0*(0.5d0+ady2)**2 * apwrd
            dabs(imx2  ,imy2+1) = dabs(imx2  ,imy2+1) + &
                     ( 0.75d0-adx2**2 ) * 0.5d0*(0.5d0+ady2)**2 * apwrd
            dabs(imx2+1,imy2+1) = dabs(imx2+1,imy2+1) + &
                  0.5d0*(0.5d0+adx2)**2 * 0.5d0*(0.5d0+ady2)**2 * apwrd
#endif
            apwri = apwri + arr
            irn = irn + 1
!ola
            if( kobs .ne. 0 ) then
              if( mod(i,lolabr(ib)) .eq. 0 ) then
                dolary(1,0,itn) = araypx
                dolary(2,0,itn) = araypy
                dolary(3,0,itn) = araypr
              end if
            end if
!ola
          else
            cycle
          end if
!...
          iraytl = lraytx+1
          do it = 1, lraytx
!.                                           * advance one time step *
          imx = araypx
          imy = araypy
          adx = araypx - imx
          ady = araypy - imy
          adrdx = (1.0d0-adx)*(1.0d0-ady) * ddendx(imx  ,imy  ) + &
                         adx *(1.0d0-ady) * ddendx(imx+1,imy  ) + &
                  (1.0d0-adx)*       ady  * ddendx(imx  ,imy+1) + &
                         adx *       ady  * ddendx(imx+1,imy+1)
          adrdy = (1.0d0-adx)*(1.0d0-ady) * ddendy(imx  ,imy  ) + &
                         adx *(1.0d0-ady) * ddendy(imx+1,imy  ) + &
                  (1.0d0-adx)*       ady  * ddendy(imx  ,imy+1) + &
                         adx *       ady  * ddendy(imx+1,imy+1)
!
          if( ltsmode .eq. 1 ) then
            afac = 1.0d0 / sqrt( arayvx**2 + arayvy**2 )
          end if
!
          arayvx = arayvx - ( dkappa2 * afac ) * adrdx
          arayvy = arayvy - ( dkappa2 * afac ) * adrdy
!
          araypx = araypx + ( dkappa2 * afac ) * arayvx
          araypy = araypy + ( dkappa2 * afac ) * arayvy
!                                                            * 1point *
!1point   imx2 = araypx + 0.5d0
!1point   imy2 = araypy + 0.5d0
!                                                           * 4points *
#ifndef DIST9
          imx2 = araypx
          imy2 = araypy
          adx2 = araypx - imx2
          ady2 = araypy - imy2
#endif
!                                                           * 9points *
#ifdef DIST9
          imx2 = araypx + 0.5d0
          imy2 = araypy + 0.5d0
          adx2 = araypx - imx2
          ady2 = araypy - imy2
#endif
!
          araypx = araypx + ( dkappa2 * afac ) * arayvx
          araypy = araypy + ( dkappa2 * afac ) * arayvy
!
          imx = araypx
          imy = araypy
          adx = araypx - imx
          ady = araypy - imy
          aden = (1.0d0-adx)*(1.0d0-ady) * dden(imx  ,imy  ) + &
                        adx *(1.0d0-ady) * dden(imx+1,imy  ) + &
                 (1.0d0-adx)*       ady  * dden(imx  ,imy+1) + &
                        adx *       ady  * dden(imx+1,imy+1)
          atem = ( (1.0d0-adx)*(1.0d0-ady) * dte(imx  ,imy  ) + &
                          adx *(1.0d0-ady) * dte(imx+1,imy  ) + &
                   (1.0d0-adx)*       ady  * dte(imx  ,imy+1) + &
                          adx *       ady  * dte(imx+1,imy+1) ) ** &
                 ( 3.0d0/2.0d0 )
!
!LowTe    anuen = dnuecr/atem * log(ddbncr*atem/sqrt(aden)) * aden**2
          anuen=dnuecr/atem*log(1.0d0+ddbncr*atem/sqrt(aden))*aden**2
!nue      anuen = (1.0d0-adx)*(1.0d0-ady) * dnue(imx  ,imy  ) + &
!nue                     adx *(1.0d0-ady) * dnue(imx+1,imy  ) + &
!nue              (1.0d0-adx)*       ady  * dnue(imx  ,imy+1) + &
!nue                     adx *       ady  * dnue(imx+1,imy+1)
          apwrd = araypr * ( 1.0d0 - exp( -(anueo+anuen)*afac ) )
          apwra = apwra + apwrd
          anueo = anuen
          araypr = araypr - apwrd
          apwrd = apwrd * draycn(ib)
!                                                            * 1point *
!1point   dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + apwrd
!                                                           * 4points *
#ifndef DIST9
          dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + &
                              (1.0d0-adx2)*(1.0d0-ady2) * apwrd
          dabs(imx2+1,imy2  ) = dabs(imx2+1,imy2  ) + &
                                     adx2 *(1.0d0-ady2) * apwrd
          dabs(imx2  ,imy2+1) = dabs(imx2  ,imy2+1) + &
                              (1.0d0-adx2)*       ady2  * apwrd
          dabs(imx2+1,imy2+1) = dabs(imx2+1,imy2+1) + &
                                     adx2 *       ady2  * apwrd
#endif
!                                                           * 9points *
#ifdef DIST9
          dabs(imx2-1,imy2-1) = dabs(imx2-1,imy2-1) + &
                  0.5d0*(0.5d0-adx2)**2 * 0.5d0*(0.5d0-ady2)**2 * apwrd
          dabs(imx2  ,imy2-1) = dabs(imx2  ,imy2-1) + &
                     ( 0.75d0-adx2**2 ) * 0.5d0*(0.5d0-ady2)**2 * apwrd
          dabs(imx2+1,imy2-1) = dabs(imx2+1,imy2-1) + &
                  0.5d0*(0.5d0+adx2)**2 * 0.5d0*(0.5d0-ady2)**2 * apwrd
          dabs(imx2-1,imy2  ) = dabs(imx2-1,imy2  ) + &
                  0.5d0*(0.5d0-adx2)**2 *    ( 0.75d0-ady2**2 ) * apwrd
          dabs(imx2  ,imy2  ) = dabs(imx2  ,imy2  ) + &
                     ( 0.75d0-adx2**2 ) *    ( 0.75d0-ady2**2 ) * apwrd
          dabs(imx2+1,imy2  ) = dabs(imx2+1,imy2  ) + &
                  0.5d0*(0.5d0+adx2)**2 *    ( 0.75d0-ady2**2 ) * apwrd
          dabs(imx2-1,imy2+1) = dabs(imx2-1,imy2+1) + &
                  0.5d0*(0.5d0-adx2)**2 * 0.5d0*(0.5d0+ady2)**2 * apwrd
          dabs(imx2  ,imy2+1) = dabs(imx2  ,imy2+1) + &
                     ( 0.75d0-adx2**2 ) * 0.5d0*(0.5d0+ady2)**2 * apwrd
          dabs(imx2+1,imy2+1) = dabs(imx2+1,imy2+1) + &
                  0.5d0*(0.5d0+adx2)**2 * 0.5d0*(0.5d0+ady2)**2 * apwrd
#endif
!ola
          if( kobs .ne. 0 ) then
            if( mod(i,lolabr(ib)) .eq. 0 ) then
              dolary(1,it,itn) = araypx
              dolary(2,it,itn) = araypy
              dolary(3,it,itn) = araypr
            end if
          end if
!ola
!
          if( araypr .lt. dbempn(ib) .or. &
              araypx .le. draybpx(1) .or. &
              araypx .ge. draybpx(3) .or. &
              araypy .le. draybpy(1) .or. &
              araypy .ge. draybpy(3) ) then
            iraytl = it
!ola
            if( kobs .ne. 0 ) then
              if( mod(i,lolabr(ib)) .eq. 0 ) then
                lolatl(itn) = it
              else
                lolatl(itn) = 0
              end if
            end if
!ola
            exit
          end if
          end do
!.
          ittl = ittl + iraytl
          if( iraytl .eq. lraytx+1 ) irer = irer + 1
!ola
          if( kobs .ne. 0 ) then
            if( lolatl(itn) .gt. 0 ) then
!$OMP CRITICAL
              write(21) ib,lolatl(itn)+1,dolary(1:3,0:lolatl(itn),itn)
!$OMP END CRITICAL
            end if
          end if
!ola
!..
        end do
!
        if( kobs .ne. 0 ) then
          if( apwri .eq. 0.0d0 ) apwri = 1.0d0
          write(*,'(1x,a,i2,i6,f6.1,i6,i6)') &
            '    beam#, #ray, abs%, a#tl, #ovst:', &
            ib,irn,apwra/apwri*100,ittl/max(1,irn),iovst
          if( irer .gt. 0 ) &
            write(*,*) '### WARNING: not enough lraytx', irer,lraytx
        end if
!....
      end do
!....
      if( kobs .ne. 0 ) then
        write(21) -1,1,rtime,rtime,rtime
        flush(21)
      end if
!debug
      if( lcheck .ge. 1 ) then
        do ib = 1, ly
          do it = 1, lx
            if( dabs(it,ib) .lt. 0.0d0 ) &
              write(*,*) 'dabs .lt. 0 ', it, ib, dabs(it,ib)
          end do
        end do
      end if
!debug
!....
      call fprint( 'la2main', 1, ldebug )
!....
      return
      end
