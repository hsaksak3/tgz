!----------------------------------------------------------------------
! set 2D INItial values
!                            /
      subroutine la2init ( rtime )
!
!   <arguments>
!     rtime : time (nsec)
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/03/25
!----------------------------------------------------------------------
      use parameter
      use laserabs
      use phys
      implicit none
      integer :: i, ix, iy, itype
      real(8) :: rtime, atime, ahw, att, atem
      save
!....
      call fprint( 'la2init', 0, ldebug )
!....
      do i = 1, llsrbn
        atime = rtime - dbempd(i)
        if( atime .gt. 0.0d0 ) then
          ahw = ( dbempl(i) - dbempw(i) ) / 2.0d0 
          att = ahw * sqrt( - log(dbempn(i))/log(2.0d0) )
          if( atime .lt. att ) then
            drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
          else
            if( atime .le. att+dbempw(i) ) then
              drayam(i) = 1.0d0 
            else
              if( atime .lt. att+dbempw(i)+att ) then
                att = att + dbempw(i)
                drayam(i) = exp( - log(2.0d0) * ((atime-att)/ahw)**2 )
              else
                drayam(i) = 0.0d0 
              end if
            end if
          end if
        else
          drayam(i) = 0.0d0 
        end if
      end do
!....      * convert rho [g/cm^3] in hydro to density [n/n_cr] in la2 *
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly
        do ix = 1, lx
          dden(ix,iy) = dr(ix,iy) * drhocr
        end do
      end do
!....                                            * calculate gradient *
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 2, ly1
        do ix = 2, lx1
          ddendx(ix,iy) = ( dden(ix+1,iy) - dden(ix-1,iy) ) * 0.5d0
          ddendy(ix,iy) = ( dden(ix,iy+1) - dden(ix,iy-1) ) * 0.5d0
        end do
      end do
!....                                                 * calculate nue *
!nue  do iy = 1, ly
!nue    do ix = 1, lx
!nue      atem = dte(ix,iy)**( 3.0d0/2.0d0 )
!nue      dnue(ix,iy) = dnuecr/atem * &
!nue               log(ddbncr*atem/sqrt(dden(ix,iy))) * dden(ix,iy)**2
!nue    end do
!nue  end do
!....                                                    * clear dabs *
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly
        do ix = 1, lx
          dabs(ix,iy) = 0.0d0
        end do
      end do
!....
      call fprint( 'la2init', 1, ldebug )
!....
      return
      end
