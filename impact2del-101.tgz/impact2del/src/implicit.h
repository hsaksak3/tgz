      implicit real*8(g, q, p), real*8(a, d, r), real*4(w, s, f), &
               integer(i, l, k)
!char implicit character(c, b, e)
