!----------------------------------------------------------------------
! free bomndary condition y
!
      subroutine bnd2yf
!
!   <argmments>
!     none
!
!   <remarks>
!     none
!
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do ix = 1, lx
        dr(ix,1) = dr(ix,3)
        de(ix,1) = de(ix,3)
        dm(ix,1) = dm(ix,3)
        dn(ix,1) = dn(ix,3)
!.
        dr(ix,2) = dr(ix,3)
        de(ix,2) = de(ix,3)
        dm(ix,2) = dm(ix,3)
        dn(ix,2) = dn(ix,3)
!..
        dr(ix,ly1) = dr(ix,ly2)
        de(ix,ly1) = de(ix,ly2)
        dm(ix,ly1) = dm(ix,ly2)
        dn(ix,ly1) = dn(ix,ly2)
!.
        dr(ix,ly) = dr(ix,ly2)
        de(ix,ly) = de(ix,ly2)
        dm(ix,ly) = dm(ix,ly2)
        dn(ix,ly) = dn(ix,ly2)
      end do
!....
      return
      end
