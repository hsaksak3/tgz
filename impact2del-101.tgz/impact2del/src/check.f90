
!----------------------------------------------------------------------
! check density
!                          /
      subroutine check ( kdebug )
!
!   <arguments>
!     kdebug : debug flag
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/04
!----------------------------------------------------------------------
      use parameter
      use phys
      include "implicit.h"
!....
      call fprint( 'check', 2, kdebug )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = 1, ly
      do ix = 1, lx
         if( dr(ix,iy) .le. 0.0d0 ) then
            if( kdebug .ge. 3 ) then
!$OMP CRITICAL
               write(*,*) 'dr .lt. 0 ', kdebug, ix, iy, dr(ix,iy)
!$OMP END CRITICAL
            end if
            dr(ix,iy) = 1.0d-12
            dm(ix,iy) = 0.0d0
            dn(ix,iy) = 0.0d0
            de(ix,iy) = 0.0d0
         end if
         if( dp(ix,iy) .lt. 0.0d0 ) then
            if( kdebug .ge. 3 ) then
!$OMP CRITICAL
               write(*,*) 'dp .lt. 0 ', kdebug, ix, iy, dp(ix,iy)
!$OMP END CRITICAL
            end if
            dp(ix,iy) = 1.0d-12
            de(ix,iy) = dp(ix,iy) / ( dgam - 1.0d0 ) + &
             0.5d0 * ( dm(ix,iy) * du(ix,iy) + dn(ix,iy) * dv(ix,iy) )
         end if
         if( de(ix,iy) .lt. 0.0d0 ) then
            if( kdebug .ge. 3 ) then
!$OMP CRITICAL
               write(*,*) 'de .lt. 0 ', kdebug, ix, iy, de(ix,iy)
!$OMP END CRITICAL
            end if
         end if
      end do
      end do
!....
      return
      end
