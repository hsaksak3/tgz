!----------------------------------------------------------------------
! compute flux in y-advance
!
      subroutine cmp2fy
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 19/12/04
!----------------------------------------------------------------------
      use parameter
      use observation
      use phys
      use work
      include "implicit.h"
!.... 
      call fprint( 'cmp2fy', 0, ldebug )
!....                     * set u^(j,k+1/2), v^(j,k+1/2), c^(j,k+1/2) *
!$OMP PARALLEL PRIVATE(ix,ah0,ah1,adr,adm,adn,ade,ac1,ac2,aq,agg)
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly1
      do ix = 1, lx
         ah0 = ( de(ix,iy  ) + dp(ix,iy  ) ) / dr(ix,iy)
         ah1 = ( de(ix,iy+1) + dp(ix,iy+1) ) / dr(ix,iy+1)
!..
         auu(ix,iy) = ( sqrt( dr(ix,iy  ) ) * du(ix,iy  ) + &
                       sqrt( dr(ix,iy+1) ) * du(ix,iy+1) ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         avv(ix,iy) = ( sqrt( dr(ix,iy  ) ) * dv(ix,iy  ) + &
                       sqrt( dr(ix,iy+1) ) * dv(ix,iy+1) ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         ahh(ix,iy) = ( sqrt( dr(ix,iy  ) ) * ah0 + &
                       sqrt( dr(ix,iy+1) ) * ah1 ) &
                        / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         acc(ix,iy) = sqrt( ( dgam - 1.0d0 ) * &
          ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) ) )
      end do
      end do
!....                                          * set alfa(l)(j,k+1/2) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly1
      do ix = 1, lx
         adr = dr(ix,iy+1) - dr(ix,iy)
         adm = dm(ix,iy+1) - dm(ix,iy)
         adn = dn(ix,iy+1) - dn(ix,iy)
         ade = de(ix,iy+1) - de(ix,iy)
!..
         if( acc(ix,iy)  .gt. dzero ) then
            ac1 = ( dgam - 1.0d0 ) * &
              ( ade + 0.5d0 * adr * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) &
          - ( adm * auu(ix,iy) + adn * avv(ix,iy) ) ) / acc(ix,iy)**2
            ac2 = ( adn - adr * avv(ix,iy) ) / acc(ix,iy)
!..
            alfa1(ix,iy) = 0.5d0 * ( ac1 - ac2 )
            alfa2(ix,iy) = adr - ac1
            alfa3(ix,iy) = adm - adr * auu(ix,iy)
            alfa4(ix,iy) = 0.5d0 * ( ac1 + ac2 )
         else
            alfa1(ix,iy) = 0.d0
            alfa2(ix,iy) = adr
            alfa3(ix,iy) = adm - adr * auu(ix,iy)
            alfa4(ix,iy) = 0.d0
         end if
      end do
      end do
!....                                               * nue(l)(j,k+1/2) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly1
      do ix = 1, lx
         anue1(ix,iy) = avv(ix,iy) - acc(ix,iy)
         anue2(ix,iy) = avv(ix,iy)
         anue3(ix,iy) = avv(ix,iy)
         anue4(ix,iy) = avv(ix,iy) + acc(ix,iy)
      end do
      end do
!.
      if( lvisf .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = 1, ly
         do ix = 1, lx1
            anue3(ix,iy) = dvisw * &
                  sign( sqrt(auu(ix,iy)**2+avv(ix,iy)**2), avv(ix,iy) )
         end do
         end do
      end if
!.
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly
      do ix = 1, lx1
         anue1(ix,iy) = anue1(ix,iy) * dram
         anue2(ix,iy) = anue2(ix,iy) * dram
         anue3(ix,iy) = anue3(ix,iy) * dram
         anue4(ix,iy) = anue4(ix,iy) * dram
      end do
      end do
!....                                     * set g(l)(j,k+1/2),l=1,2,3 *
!$OMP DO SCHEDULE(STATIC)
      do iy = 2, ly1
      do ix = 1, lx
!..                                                           * l = 1 *
         if( alfa1(ix,iy-1) * alfa1(ix,iy) .gt. dzero2 ) then
            if( alfa1(ix,iy) .gt. 0.0d0 ) then
               ag1(ix,iy) = min( alfa1(ix,iy-1), alfa1(ix,iy) )
            else
               ag1(ix,iy) = max( alfa1(ix,iy-1), alfa1(ix,iy) )
            end if
         else
            ag1(ix,iy) = 0.0d0
         end if
!..                                                           * l = 2 *
         if( alfa2(ix,iy-1) * alfa2(ix,iy) .gt. dzero2 ) then
            if( alfa2(ix,iy) .gt. 0.0d0 ) then
               ag2(ix,iy) = min( alfa2(ix,iy-1), alfa2(ix,iy) )
            else
               ag2(ix,iy) = max( alfa2(ix,iy-1), alfa2(ix,iy) )
            end if
            afg2(ix,iy) = domga * abs( alfa2(ix,iy) - alfa2(ix,iy-1) ) &
                     / ( abs( alfa2(ix,iy) ) + abs( alfa2(ix,iy-1) ) )
         else
            ag2(ix,iy)  = 0.0d0
            afg2(ix,iy) = 0.0d0
         end if
!..                                                           * l = 3 *
         if( alfa3(ix,iy-1) * alfa3(ix,iy) .gt. dzero2 ) then
            if( alfa3(ix,iy) .gt. 0.0d0 ) then
               ag3(ix,iy) = min( alfa3(ix,iy-1), alfa3(ix,iy) )
            else
               ag3(ix,iy) = max( alfa3(ix,iy-1), alfa3(ix,iy) )
            end if
            afg3(ix,iy) = domga * abs( alfa3(ix,iy) - alfa3(ix,iy-1) ) &
                     / ( abs( alfa3(ix,iy) ) + abs( alfa3(ix,iy-1) ) )
         else
            ag3(ix,iy)  = 0.0d0
            afg3(ix,iy) = 0.0d0
         end if
!..                                                           * l = 4 *
         if( alfa4(ix,iy-1) * alfa4(ix,iy) .gt. dzero2 ) then
            if( alfa4(ix,iy) .gt. 0.0d0 ) then
               ag4(ix,iy) = min( alfa4(ix,iy-1), alfa4(ix,iy) )
            else
               ag4(ix,iy) = max( alfa4(ix,iy-1), alfa4(ix,iy) )
            end if
         else
            ag4(ix,iy) = 0.0d0
         end if
      end do
      end do
!....                       * set nue(l)(j,k+1/2) + gamma(l)(j,k+1/2) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 2, ly2
      do ix = 1, lx
!.
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         afg = 0.5d0 * ( aq - anue1(ix,iy)**2 )
         abet1(ix,iy) = afg * ( ag1(ix,iy+1) + ag1(ix,iy) )
         if( abs( alfa1(ix,iy) ) .ge. dzero ) then
            anue1(ix,iy) = anue1(ix,iy) + &
                    afg * ( ag1(ix,iy+1) - ag1(ix,iy) ) / alfa1(ix,iy)
         end if
!.
         aq  = abs( anue2(ix,iy) )
         afg = 0.5d0 * ( aq - anue2(ix,iy)**2 ) &
                     * ( 1.0d0 + max( afg2(ix,iy+1), afg2(ix,iy) ) )
         abet2(ix,iy) = afg * ( ag2(ix,iy+1) + ag2(ix,iy) )
         if( abs( alfa2(ix,iy) ) .ge. dzero ) then
            anue2(ix,iy) = anue2(ix,iy) + &
                    afg * ( ag2(ix,iy+1) - ag2(ix,iy) ) / alfa2(ix,iy)
         end if
!.
         aq  = abs( anue3(ix,iy) )
         afg = 0.5d0 * ( aq - anue3(ix,iy)**2 ) &
                     * ( 1.0d0 + max( afg3(ix,iy+1), afg3(ix,iy) ) )
         abet3(ix,iy) = afg * ( ag3(ix,iy+1) + ag3(ix,iy) )
         if( abs( alfa3(ix,iy) ) .ge. dzero ) then
            anue3(ix,iy) = anue3(ix,iy) + &
                    afg * ( ag3(ix,iy+1) - ag3(ix,iy) ) / alfa3(ix,iy)
         end if
!.
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         afg = 0.5d0 * ( aq - anue4(ix,iy)**2 )
         abet4(ix,iy) = afg * ( ag4(ix,iy+1) + ag4(ix,iy) )
         if( abs( alfa4(ix,iy) ) .ge. dzero ) then
            anue4(ix,iy) = anue4(ix,iy) + &
                    afg * ( ag4(ix,iy+1) - ag4(ix,iy) ) / alfa4(ix,iy)
         end if
      end do
      end do
!....                                          * set beta(l)(j,k+1/2) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 2, ly2
      do ix = 1, lx
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet1(ix,iy) = abet1(ix,iy) - aq * alfa1(ix,iy)
         aq = abs( anue2(ix,iy) )
         abet2(ix,iy) = abet2(ix,iy) - aq * alfa2(ix,iy)
         aq = abs( anue3(ix,iy) )
         abet3(ix,iy) = abet3(ix,iy) - aq * alfa3(ix,iy)
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet4(ix,iy) = abet4(ix,iy) - aq * alfa4(ix,iy)
      end do
      end do
!....                                  * set modified flux g(j,k+1/2) *
!$OMP DO SCHEDULE(STATIC)
      do iy = 1, ly 
      do ix = 1, lx 
         arfg(ix,iy) = dn(ix,iy)
         amfg(ix,iy) = dn(ix,iy) * du(ix,iy)
         anfg(ix,iy) = dn(ix,iy) * dv(ix,iy) + dp(ix,iy)
         aefg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * dv(ix,iy)
      end do  
      end do  
!..
!$OMP DO SCHEDULE(STATIC)
      do iy = 2, ly2
      do ix = 1, lx
         afg1(ix,iy) = 0.5d0 * ( arfg(ix,iy) + arfg(ix,iy+1) + &
               ( abet1(ix,iy) + abet2(ix,iy) + abet4(ix,iy) ) / dram )
         afg2(ix,iy) = 0.5d0 * ( amfg(ix,iy) + amfg(ix,iy+1) + &
         ( ( abet1(ix,iy)+abet2(ix,iy)+abet4(ix,iy) ) * auu(ix,iy) + &
             abet3(ix,iy) ) / dram )
         afg3(ix,iy) = 0.5d0 * ( anfg(ix,iy) + anfg(ix,iy+1) + &
               ( abet1(ix,iy) * ( avv(ix,iy) - acc(ix,iy) ) + &
                 abet2(ix,iy) *   avv(ix,iy)                + &
                 abet4(ix,iy) * ( avv(ix,iy) + acc(ix,iy) ) ) / dram )
         afg4(ix,iy) = 0.5d0 * ( aefg(ix,iy) + aefg(ix,iy+1) + &
      ( abet1(ix,iy) * ( ahh(ix,iy)-avv(ix,iy)*acc(ix,iy) ) + &
        abet2(ix,iy) * 0.5d0 * ( auu(ix,iy)**2+avv(ix,iy)**2 ) + &
        abet3(ix,iy) * auu(ix,iy)                              + &
        abet4(ix,iy) * ( ahh(ix,iy)+avv(ix,iy)*acc(ix,iy) ) ) / dram )
      end do
      end do
!....                                                     * set flux *
!$OMP DO SCHEDULE(STATIC)
      do iy = 3, ly2
      do ix = 1, lx
         drf(ix,iy) = drf(ix,iy) + dram * ( afg1(ix,iy-1)-afg1(ix,iy) )
         dmf(ix,iy) = dmf(ix,iy) + dram * ( afg2(ix,iy-1)-afg2(ix,iy) )
         dnf(ix,iy) = dnf(ix,iy) + dram * ( afg3(ix,iy-1)-afg3(ix,iy) )
         def(ix,iy) = def(ix,iy) + dram * ( afg4(ix,iy-1)-afg4(ix,iy) )
      end do
      end do
!$OMP END PARALLEL
!.... 
      call fprint( 'cmp2fy', 1, ldebug )
!....
      return
      end
