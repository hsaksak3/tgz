module work
      real(8), allocatable :: &
         auu(:,:), avv(:,:), acc(:,:), ahh(:,:), &
         alfa1(:,:), alfa2(:,:), alfa3(:,:), alfa4(:,:), &
         abet1(:,:), abet2(:,:), abet3(:,:), abet4(:,:), &
         anue1(:,:), anue2(:,:), anue3(:,:), anue4(:,:), &
         arfg(:,:), amfg(:,:), anfg(:,:), aefg(:,:), &
         afg1(:,:), afg2(:,:), afg3(:,:), afg4(:,:), &
         ag1(:,:), ag2(:,:), ag3(:,:), ag4(:,:)
end module work
