      include "implicit.h"
      real(8), allocatable :: aval(:,:)
      real(8) :: ah(2), al(2), as(2)
      character:: ctime*16, cident*16, chead*4
!....
      ctime = 'xxx.xxx nsec'
!...
      write(*,*) 'enter iunit(r=10,p=11,u=12,v=13,te=14'
      read(*,*) iunit
!..
      read(iunit) chead, cident, ixl, iyl, amesh, ax0, ay0
      write(*,*) chead, ' ', cident, ixl, iyl, amesh, ax0, ay0
      allocate( aval(ixl,iyl) )
!....
      call fr_ginit
      call fr_opencanvas( 1, trim(chead)//'-'//trim(cident), 10 )
!
      ah(1) = 240.0d0 
      ah(2) = 0.0d0 
      al(1) = 0.3d0 
      al(2) = 0.7d0 
      as(1) = 1.0d0 
      as(2) = 1.0d0 
      call fr_hlsset ( ah, al, as, 128, 1 )
!..
    1 continue
      read(iunit, end=999) atime, aval
      write(*,*) 'time = ', atime
      write( ctime(1:8), '(f7.3)' ) atime 
      axn = - ax0
      axx = amesh * (ixl-1) - ax0
      ayn = - ay0
      ayx = amesh * (iyl-1) - ay0
!.
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
      call fr_contour ( aval, ixl, iyl, 1, -2 )
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 ) 
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
      goto 1
  999 continue
      call fr_gend
!....
      stop
      end
