!---------------------------------------------------------------------
! ray plot
!
      implicit none
      integer :: i, ii, in, ib, irn
      integer :: ix, iy, ilsrbn, iraytl, iraytn, iraynr
      integer, allocatable :: icol(:), iln(:), itn(:)
      real(8) :: ax0, ay0, amesh, axn, axx, ayn, ayx, atime, &
                 axo, ayo, adltx
      real(8), allocatable :: arho(:,:), arayda(:,:,:), &
               araypx(:), araypy(:)
      real(8) :: ah(2), al(2), as(2)
      character :: ctime*16, cident*16, chead*4
!....
      ctime = 'xxx.xxx nsec'
!....
      read(20) chead, cident, ix, iy, amesh, ax0, ay0
      write(*,*) chead, ' ', cident, ix, iy, amesh, ax0, ay0
      read(21) chead, cident, ilsrbn, iraytl, iraynr, axo,ayo,adltx
      write(*,*) chead, ' ', cident,ilsrbn,iraytl,iraynr,axo,ayo,adltx
!
      iraynr = iraynr * ilsrbn * 1.5
      allocate( arho(ix,iy), arayda(3,iraytl+1,iraynr), &
                araypx(iraytl+1), araypy(iraytl+1), &
                icol(iraytl+1), iln(iraynr), itn(iraynr) )
      axn = - ax0 
      axx = amesh * (ix-1) - ax0
      ayn = - ay0 
      ayx = amesh * (iy-1) - ay0
!.
      call fr_ginit 
      call fr_opencanvas( 1, trim(chead)//'-'//trim(cident), 10 )
!
      ah(1) = 0.0d0
      ah(2) = 0.0d0
      al(1) = 1.0d0
      al(2) = 0.1d0
      as(1) = 0.0d0
      as(2) = 0.0d0
      call fr_hlsset ( ah, al, as, 128, 1 )
      ah(1) = 240.0d0
      ah(2) = 0.0d0
      al(1) = 0.3d0
      al(2) = 0.7d0
      as(1) = 1.0d0
      as(2) = 1.0d0
      call fr_hlsset ( ah, al, as, 128, 1 )
!.
    1 continue
      read(20,end=999) atime, arho
      write(*,*) 'time = ', atime
      write( ctime(1:8), '(f7.3)' ) atime 
!
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
      call fr_hlsrecall ( 2 )
      call fr_contour ( arho, ix, iy, 1, -2 )
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
!..
      irn = 1
      do in = 1, ilsrbn
    2   continue
          read(21) ib,iraytn,arayda(1:3,1:iraytn,irn)
          if( ib .eq. -1 ) then
            irn = irn - 1
            goto 3
          end if
          iln(irn) = ib
          itn(irn) = iraytn
          do i = 1, iraytn
            araypx(i) = ( arayda(1,i,irn) - axo ) * adltx
            araypy(i) = ( arayda(2,i,irn) - ayo ) * adltx
            icol(i) = - ( arayda(3,i,irn) * 127 + 1 )
          end do
          if( ib .eq. in ) then
            do i = 1, iraytn
              call fr_draw2d ( araypx(i), araypy(i), icol(i), 2 )
            end do
          else
            call fr_xyname ( 'x[micron]', 'y[micron]' )
            call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
            call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
            call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
            call fr_gclear
            call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
            call fr_frame2d ( axn, axx, ayn, ayx, 3 )
            do i = 1, iraytn
              call fr_draw2d ( araypx(i), araypy(i), icol(i), 2 )
            end do
            cycle
          end if
          irn = irn + 1
        goto 2
      end do
    3 continue
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!
      write(*,*) 'total #ray:', irn
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
      call fr_hlsrecall ( 1 )
      call fr_contour ( arho, ix, iy, 1, -2 )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      do ii = 1, irn
        do i = 1, itn(ii)
          araypx(i) = ( arayda(1,i,ii) - axo ) * adltx
          araypy(i) = ( arayda(2,i,ii) - ayo ) * adltx
        end do
        call fr_graph2d ( araypx, araypy, itn(ii), iln(ii), 1 )
      end do
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!..
      read(20) atime, arho
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
      call fr_hlsrecall ( 2 )
      call fr_contour ( arho, ix, iy, 1, -2 )
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axn, axx, ayn, ayx, 3 )
      call fr_hlsrecall ( 1 )
      call fr_contour ( arho, ix, iy, 1, -2 )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      do ii = 1, irn
        do i = 1, itn(ii)
          araypx(i) = ( arayda(1,i,ii) - axo ) * adltx
          araypy(i) = ( arayda(2,i,ii) - ayo ) * adltx
        end do
        call fr_graph2d ( araypx, araypy, itn(ii), iln(ii), 1 )
      end do
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, chead, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!....
      goto 1
  999 continue
      call fr_gend
!....
      stop
      end
