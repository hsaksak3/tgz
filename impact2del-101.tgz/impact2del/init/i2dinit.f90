!----------------------------------------------------------------------
! impact2d initial data
      implicit none
      real(8), parameter :: api=acos(-1.0d0)
      integer :: ix, iy, lx, ly
      real(8) :: dxo, dyo, ddltx, dan, daz, af, &
                 ax, axs, axe, axd, ar0, ap0, art, apt
      real(8) :: ah(2), al(2), as(2)
      real(8), allocatable :: dr(:,:), dp(:,:)
      namelist /param/ lx, ly, dxo, dyo, ddltx, dan, daz, &
                       axs, axe, axd, ar0, ap0, art, apt
!....
      lx = 201
      ly = 201
      dxo = 1.0d100
      dyo = 1.0d100
      ddltx = 1.0d0
      dan = 6.5d0
      daz = 3.5d0
!.
      axs = -9.5d0
      axe = 0.5d0
      axd = 2.0d0
      ar0 = 1.0d-3
      ap0 = 1.0d-3
      art = 1.0d0
      apt = 10.0d0
!..
      read(*,nml=param)
      if( dxo .gt. 1.0d99 ) &
        dxo = ( 1 + lx ) / 2.0d0
      if( dyo .gt. 1.0d99 ) &
        dyo = ( 1 + ly ) / 2.0d0
      write(*,nml=param)
!....
      allocate( dr(lx,ly), dp(lx,ly) )
!..
      do iy = 1, ly
      do ix = 1, lx
        ax = ( ix - dxo ) * ddltx
        if( ax .lt. axs-axd ) then
          dr(ix,iy) = ar0 
          dp(ix,iy) = ap0
        else if( ax .ge. axs-axd .and. ax .le. axs ) then
          af = ( ax - (axs-axd) ) / axd
          af = ( 1.0d0 - cos( af * api ) ) * 0.5d0
          dr(ix,iy) = ar0 + ( art - ar0 ) * af
          dp(ix,iy) = ap0 + ( apt - ap0 ) * af
        else if( ax .gt. axs .and. ax .lt. axe ) then
          dr(ix,iy) = art
          dp(ix,iy) = apt
        else if( ax .ge. axe .and. ax .le. axe+axd ) then
          af = ( ax - axe ) / axd
          af = ( 1.0d0 - cos( af * api ) ) * 0.5d0
          dr(ix,iy) = art + ( ar0 - art ) * af
          dp(ix,iy) = apt + ( ap0 - apt ) * af
        else
          dr(ix,iy) = ar0
          dp(ix,iy) = ap0
        end if
      end do
      end do
!..
      write(8) lx,ly,dxo,dyo,ddltx,dan,daz
      write(8) 'i2r ', dr
      write(8) 'i2p ', dp
!....
      call fr_ginit
      call fr_opencanvas( 1, 'i2dinit', 10 )
      ah(1) = 240.0d0 
      ah(2) = 0.0d0 
      al(1) = 0.3d0 
      al(2) = 0.7d0 
      as(1) = 1.0d0 
      as(2) = 1.0d0 
      call fr_hlsset ( ah, al, as, 128, 1 )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( (1-dxo)*ddltx, (lx-dxo)*ddltx, &
                        (1-dyo)*ddltx, (ly-dyo)*ddltx, 3 )
      call fr_contour ( dr, lx, ly, 1, -2 ) 
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 ) 
      call fr_fpchars ( 5.0d0,15.0d0,'Density(g/cm^3)',7,1, -1, 0, 0 )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( (1-dxo)*ddltx, (lx-dxo)*ddltx, &
                        (1-dyo)*ddltx, (ly-dyo)*ddltx, 3 )
      call fr_contour ( dp, lx, ly, 1, -2 ) 
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 ) 
      call fr_fpchars ( 5.0d0,15.0d0,'Pressure(Mbar)',7,1, -1, 0, 0 )
      call fr_gend
!....
      stop
      end

