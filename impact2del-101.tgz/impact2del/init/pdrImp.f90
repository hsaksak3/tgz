! make initial profile of pressure drive implosion
!
! <unit>
! length   : micron
! density  : g/cc
! pressure : Mbar
!
! coded by yanu. (nifs) 14/03/16
!----------------------------------------------------------------------
      implicit none
      integer              :: lx, ly
      integer              :: ismth
      integer              :: ix, iy
      real(8)              :: wrf, wrp, wrs
      real(8)              :: wrhof, wrhop, wrhos, wrho0
      real(8)              :: wpf, wpp, wps, wp0
      real(8)              :: wx, wdltx, axo
      real(8)              :: wy, ayo
      real(8)              :: wr, wthe
      real(8)              :: wsmth
      real(8)              :: wt, wfac
      real(8)              :: wpi
      real(8), allocatable :: sx(:), sy(:)
      real(8), allocatable :: srho(:,:), sp(:,:), su(:,:), sv(:,:)
      real(8)              :: sh(4,2), sl(4,2), ss(4,2)
      integer              :: lHLSmode(2), lndiv(3,2)
      real(8) :: dan, daz
      namelist/INIT/ lx, ly, wdltx, dan, daz, &
                     wrf, wrp, wrs, &
                     wrhof, wrhop, wrhos, wrho0, &
                     wpf, wpp, wps, wp0, &
                     ismth
!
      wpi = ACOS(-1.0d0)
!
      lx = 201
      ly = 201
      dan = 6.5d0
      daz = 3.5d0
      wdltx = 1.0d0
      wrf = 25.0d0
      wrp = 50.0d0
      wrs = 50.0d0
      wrhof = 1.0d-4
      wrhop = 1.0d0
      wrhos = 1.0d-4
      wrho0 = 1.0d-4
      wpf = 1.0d-4
      wpp = 1.0d-4
      wps = 1.0d-4
      wp0 = 1.0d-4
      ismth = 10
!
      read(5,INIT)
      write(6,INIT)
!
      allocate( sx(lx) )
      allocate( sy(ly) )
      allocate( srho(lx,ly) )
      allocate( sp(lx,ly) )
      allocate( su(lx,ly) )
      allocate( sv(lx,ly) )
!
      axo = ( lx + 1 ) / 2.0d0
      ayo = ( ly + 1 ) / 2.0d0
      wsmth = ismth*wdltx*SQRT(2.0d0)
      do iy = 1, ly
       do ix = 1, lx
        wx = ( ix - axo ) * wdltx
        wy = ( iy - ayo ) * wdltx
        sx(ix) = wx
        sy(iy) = wy
        wr = SQRT( wx**2 + wy**2 )
        if( wr .LT. wrf )then
         srho(ix,iy) = wrhof
         sp(ix,iy) = wpf
        else if( wr .GE. wrf .AND. wr .LT. wrf+wsmth )then
         wt = (wr-wrf)/wsmth
         wfac = 0.5d0*( 1.0d0 - COS(wt*wpi) )
         srho(ix,iy) = wrhof + ( wrhop - wrhof )*wfac
         sp(ix,iy) = wpf + ( wpp - wpf )*wfac
        else if( wr .GE. wrf+wsmth .AND. wr .LT. wrp )then
         srho(ix,iy) = wrhop
         sp(ix,iy) = wpp
        else if( wr .GE. wrp .AND. wr .LT. wrp+wsmth )then
         wt = (wr-wrp)/wsmth
         wfac = 0.5d0*( 1.0d0 - COS(wt*wpi) )
         srho(ix,iy) = wrhop + ( wrhos - wrhop )*wfac
         sp(ix,iy) = wpp + ( wps - wpp )*wfac
        else if( wr .GE. wrp+wsmth .AND. wr .LT. wrs )then
         srho(ix,iy) = wrhos
         sp(ix,iy) = wps
        else if( wr .GE. wrs .AND. wr .LT. wrs+wsmth )then
         wt = (wr-wrs)/wsmth
         wfac = 0.5d0*( 1.0d0 - COS(wt*wpi) )
         srho(ix,iy) = wrhos + ( wrho0 - wrhos )*wfac
         sp(ix,iy) = wps + ( wp0 - wps )*wfac
        else
         srho(ix,iy) = wrho0
         sp(ix,iy) = wp0
        end if
        su(ix,iy) = 0.0d0
        sv(ix,iy) = 0.0d0
       end do
      end do
!
      write(8) lx,ly,axo,ayo,wdltx,dan,daz
      write(8) 'i2r ', srho
      write(8) 'i2p ', sp
      write(8) 'i2u ', su
      write(8) 'i2v ', sv
!
      !*
!  HLS for positive value profile
!*
      lHLSmode(1) = 1
      sh(1,1) = 240.0d0
      sh(2,1) = 0.0d0
      sl(1,1) = 0.6d0
      sl(2,1) = 0.6d0
      ss(1,1) = 1.0d0
      ss(2,1) = 1.0d0
      lndiv(1,1) = 128
!*
!  HLS for positive and negative value profile
!*
      lHLSmode(2) = 3
      sh(1,2) = 240.0d0
      sh(2,2) = 240.0d0
      sh(3,2) = 0.0d0
      sh(4,2) = 0.0d0
      sl(1,2) = 0.8d0
      sl(2,2) = 0.0d0
      sl(3,2) = 0.0d0
      sl(4,2) = 0.8d0
      ss(1,2) = 1.0d0
      ss(2,2) = 1.0d0
      ss(3,2) = 1.0d0
      ss(4,2) = 1.0d0
      lndiv(1,2) = 64
      lndiv(2,2) = 0
      lndiv(3,2) = 64
!
      call fr_ginit()
      call fr_gwsize(720,480,0,0)
      call fr_opencanvas(1,'init',10)
!
      call fr_gclear()
      call fr_hlsset(sh(:,1),sl(:,1),ss(:,1),lndiv(:,1),lHLSmode(1))
      call frames_contour(lx,ly,sx(1),sx(lx),sy(1),sy(ly),srho, &
                          'x','y','rho')
      call fr_gpause()
!
      call fr_gclear()
      call fr_hlsset(sh(:,1),sl(:,1),ss(:,1),lndiv(:,1),lHLSmode(1))
      call frames_contour(lx,ly,sx(1),sx(lx),sy(1),sy(ly),sp, &
                          'x','y','p')
      call fr_gpause()
!
      call fr_gclear()
      call fr_hlsset(sh(:,2),sl(:,2),ss(:,2),lndiv(:,2),lHLSmode(2))
      call frames_contour(lx,ly,sx(1),sx(lx),sy(1),sy(ly),su, &
                          'x','y','u')
      call fr_gpause()
!
      call fr_gclear()
      call fr_hlsset(sh(:,2),sl(:,2),ss(:,2),lndiv(:,2),lHLSmode(2))
      call frames_contour(lx,ly,sx(1),sx(lx),sy(1),sy(ly),sv, &
                          'x','y','v')
      call fr_gpause()
!
      end
!
      subroutine frames_contour( kx, ky, fx0, fx1, fy0, fy1, fu, &
                                 ex, ey, etime )
!
      implicit none
      integer, intent(in)      :: kx, ky
      real(8), intent(in)      :: fx0, fx1, fy0, fy1
      real(8), intent(in)      :: fu(kx,ky)
      character(*), intent(in) :: ex, ey, etime
!
      call fr_view2d(80,50,560,370)
      call fr_aspect2d(1.0d0,1.0d0,-1)
      call fr_frame2d(fx0,fx1,fy0,fy1,0)
      call fr_xyname(ex,ey)
      call fr_contour(fu,kx,ky,20,-2)
      call fr_fpchars(320.0d0,20.0d0,etime,7,1,0,0,0)
      call fr_colorbar ( 350, 475, 200, 15, 2 )
!
      end subroutine
