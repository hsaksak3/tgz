!-----------------------------------------------------------------------
! Compute 3D Particle Electron Force
!
      subroutine c3pef
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/12
!----------------------------------------------------------------------
#include "interpolate.macro"
#include "spdat.macro"
#include "sfield.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ixi, ixh, iyi, iyh, izi, izh
      real*8  :: wx1i,wx2i,wx3i,wx4i,wx1h,wx2h,wx3h,wx4h, &
                 wy1i,wy2i,wy3i,wy4i,wy1h,wy2h,wy3h,wy4h, &
                 wz1i,wz2i,wz3i,wz4i,wz1h,wz2h,wz3h,wz4h, &
                 wdd,wex,wbx,wez,wbz,wey,wby, &
                 wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac
      save
!....
      call fdebug ( 'c3pef', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP          PRIVATE(ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  ixh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                  iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  iyh,wy1h,wy2h,wy3h,wy4h, &
!$OMP                  izi,wz1i,wz2i,wz3i,wz4i, &
!$OMP                  izh,wz1h,wz2h,wz3h,wz4h, &
!$OMP                  wdd,wex,wbx,wez,wbz,wey,wby, &
!$OMP                  wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac)
      do i = lnoes, lnoee
#define _sx sxe(i)
#define _sy sye(i)
#define _sz sze(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_xi.h"
#include "interpolate_defxh.h"
#include "interpolate_xh.h"
#include "interpolate_defyi.h"
#include "interpolate_yi.h"
#include "interpolate_defyh.h"
#include "interpolate_yh.h"
#include "interpolate_defzi.h"
#include "interpolate_zi.h"
#include "interpolate_defzh.h"
#include "interpolate_zh.h"
!..
#include "interpolate_defxh.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _wv wex
#define _sv sex
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyh.h"
#include "interpolate_defzi.h"
#define _wv wey
#define _sv sey
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzh.h"
#define _wv wez
#define _sv sez
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyh.h"
#include "interpolate_defzh.h"
#define _wv wbx
#define _sv sbx
#include "interpolate_v.h"
         wbx = wbx + sextbx
!
#include "interpolate_defxh.h"
#include "interpolate_defyi.h"
#include "interpolate_defzh.h"
#define _wv wby
#define _sv sby
#include "interpolate_v.h"
         wby = wby + sextby
!
#include "interpolate_defxh.h"
#include "interpolate_defyh.h"
#include "interpolate_defzi.h"
#define _wv wbz
#define _sv sbz
#include "interpolate_v.h"
         wbz = wbz + sextbz
!..
         wax = suxe(i) - wex * s1o2
         way = suye(i) - wey * s1o2
         waz = suze(i) - wez * s1o2
         wtf = s1o2 / sqrt( s1o1 + (wax**2+way**2+waz**2)*scg1 )
         wcx = - wbx * wtf
         wcy = - wby * wtf
         wcz = - wbz * wtf
         wc2 = wcx**2 + wcy**2 + wcz**2
         wac = wax * wcx + way * wcy + waz * wcz
!.
         sfxe(i) = ( ( wax + way * wcz - waz * wcy + wac * wcx ) / &
                  ( s1o1 + wc2 ) - suxe(i) ) * s2o1
         sfye(i) = ( ( way + waz * wcx - wax * wcz + wac * wcy ) / &
                  ( s1o1 + wc2 ) - suye(i) ) * s2o1
         sfze(i) = ( ( waz + wax * wcy - way * wcx + wac * wcz ) / &
                  ( s1o1 + wc2 ) - suze(i) ) * s2o1
      end do
!....
      call fdebug ( 'c3pef', 1 )
!....
      return
      end
