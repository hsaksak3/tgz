!----------------------------------------------------------------------
! Observe 3D Field Electric Amplitude
!                          /
      subroutine o3fea ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 27, ifn = 8
      integer :: kflag, i, iofea, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iweaa
      real*8  :: wcofe2
      real*8, allocatable :: weaa(:)
      save
!....
      call fdebug ( 'o3fea', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
         iweaa = iweaa + 1
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               weaa(ixyz) = weaa(ixyz) + &
                     ( ( sex(ix,iy,iz) + sex(ix+1,iy,iz) )*s1o2 )**2 + &
                     ( ( sey(ix,iy,iz) + sey(ix,iy+1,iz) )*s1o2 )**2 + &
                     ( ( sez(ix,iy,iz) + sez(ix,iy,iz+1) )*s1o2 )**2 
             end do
           end do
         enddo
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            if( iweaa .eq. 1 ) then
               wcofe2 = scofe2h
            else
               wcofe2 = scofe2 / iweaa
            end if
            do i = 1, loxyzpl
               weaa(i) = weaa(i)  * wcofe2
            end do
            if( iofea .le. 4 ) then
               write(iun) sstcur, ( weaa(i),i=1,loxyzpl )
               flush(iun)
            end if
            if( iofea .ge. 2 ) then
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, 0, i3d, 0, 1, & 
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 weaa, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fea' ) 
            end if
          end if
         else
!....
            iofea = mod( lofea, 10 )
            i3d   = mod( lofea/100, 10 )
            icrxy = mod( lofea/1000, 10 )
            icryz = mod( lofea/10000, 10 )
            icrxz = mod( lofea/100000, 10 )
!.
            if( iofea .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fea', &
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
               if( .not. allocated(weaa) ) allocate( weaa(loxyzpl) )
            end if
!....
            if( iofea .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fea', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
               write(iun) 'fea4', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
               flush(iun)
            end if
            if( iofea .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fea', bfile )
               call frames_file ( bfile, ifn, iofea )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iweaa = 0
            do i = 1, loxyzpl
               weaa(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fea', 1 )
!....
      return
      end
