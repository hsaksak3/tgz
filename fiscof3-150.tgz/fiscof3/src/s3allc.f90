!-------------------------------------------------------------------
! Set 3D ALLoCate array
!                           /
      subroutine s3allc ( kmode )
!
!   <arguments>
!     kmode :  = 0 --> allocate particle array
!           : != 0 --> allocate field array
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/12
!----------------------------------------------------------------------
      use parameter
      use particle
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kmode
      save
!....
      call fdebug ( 's3allc', 0 )
!....                                                      * particle *
      if( kmode .eq. 0 ) then
         allocate( spdat1(lnox),  spdat2(lnox) )
!...                                                          * field *
      else
         allocate ( &
         sdeo(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1), &
         sdio(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1,lionspl),&
         sde(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1), &
         sdi(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1,lionspl), &
         sde0(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1), &
         sebxyz(6,lblxlm1:lblxup1,lblylm1:lblyup1,lblzlm1:lblzup1), &
         sjxyzt(3,lssxlm2:lssxup3,lssylm2:lssyup3,lsszlm2:lsszup3), &
         sdezydyz(lssxlm1:lssxup1,lssyl:lssyup1,lsszl:lsszup1), &
         sdexzdzx(lssxl:lssxup1,lssylm1:lssyup1,lsszl:lsszup1), & 
         sdeyxdxy(lssxl:lssxup1,lssyl:lssyup1,lsszlm1:lsszup1), &
         sjxe(lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2), &
         sjxi(lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2,lionspl),&
         sjye(lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2), &
         sjyi(lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2,lionspl),&
         sjze(lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3), &
         sjzi(lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3,lionspl) &
      )
!...                                                  * pml constants *
         allocate ( &
         scaxlh(lblxl:lssxlm1), scaxli(lblxlm1:lssxlm2), &
         scaxuh(lssxup2:lblxu), scaxui(lssxup2:lblxu), &
         scaylh(lblyl:lssylm1), scayli(lblylm1:lssylm2), &
         scayuh(lssyup2:lblyu), scayui(lssyup2:lblyu), &
         scazlh(lblzl:lsszlm1), scazli(lblzlm1:lsszlm2), &
         scazuh(lsszup2:lblzu), scazui(lsszup2:lblzu), &
         scbbxlh(lblxl:lssxlm1), scbbxuh(lssxup2:lblxu), &
         scbbylh(lblyl:lssylm1), scbbyuh(lssyup2:lblyu), &
         scbbzlh(lblzl:lsszlm1), scbbzuh(lsszup2:lblzu), &
         scbexli(lblxlm1:lssxlm2), scbexui(lssxup2:lblxu), &
         scbeyli(lblylm1:lssylm2), scbeyui(lssyup2:lblyu), &
         scbezli(lblzlm1:lsszlm2), scbezui(lsszup2:lblzu)  &
      )
!...                                                      * pml field *
         allocate ( &
         sbyxxl(lblxl:lssxlm1,lblyl:lblyu  ,lblzl:lblzu  ), &
         sbyxxu(lssxup2:lblxu,lblyl:lblyu  ,lblzl:lblzu  ), &
         sbyxzl(lssxl:lssxup1,lblyl:lblyu  ,lblzl:lsszlm1), &
         sbyxzu(lssxl:lssxup1,lblyl:lblyu  ,lsszup2:lblzu), &

         sbzxxl(lblxl:lssxlm1,lblyl:lblyu  ,lblzl:lblzu  ), &
         sbzxxu(lssxup2:lblxu,lblyl:lblyu  ,lblzl:lblzu  ), &
         sbzxyl(lssxl:lssxup1,lblyl:lssylm1,lblzl:lblzu  ), &
         sbzxyu(lssxl:lssxup1,lssyup2:lblyu,lblzl:lblzu  ), &

         seyxxl(lblxlm1:lssxlm2,lblyl:lblyu,lblzlm1:lblzu  ), &
         seyxxu(lssxup2:lblxu  ,lblyl:lblyu,lblzlm1:lblzu  ), &
         seyxzl(lssxlm1:lssxup1,lblyl:lblyu,lblzlm1:lsszlm2), &
         seyxzu(lssxlm1:lssxup1,lblyl:lblyu,lsszup2:lblzu), &

         sezxxl(lblxlm1:lssxlm2,lblylm1:lblyu  ,lblzl:lblzu  ), &
         sezxxu(lssxup2:lblxu  ,lblylm1:lblyu  ,lblzl:lblzu  ), &
         sezxyl(lssxlm1:lssxup1,lblylm1:lssylm2,lblzl:lblzu  ), &
         sezxyu(lssxlm1:lssxup1,lssyup2:lblyu  ,lblzl:lblzu  )  &
      )
         allocate ( &
         sbxyyl(lblxl:lblxu  ,lblyl:lssylm1,lblzl:lblzu  ), &
         sbxyyu(lblxl:lblxu  ,lssyup2:lblyu,lblzl:lblzu  ), &
         sbxyzl(lblxl:lblxu  ,lssyl:lssyup1,lblzl:lsszlm1), &
         sbxyzu(lblxl:lblxu  ,lssyl:lssyup1,lsszup2:lblzu), &

         sbzyyl(lblxl:lblxu  ,lblyl:lssylm1,lblzl:lblzu  ), &
         sbzyyu(lblxl:lblxu  ,lssyup2:lblyu,lblzl:lblzu  ), &
         sbzyxl(lblxl:lssxlm1,lssyl:lssyup1,lblzl:lblzu  ), &
         sbzyxu(lssxup2:lblxu,lssyl:lssyup1,lblzl:lblzu  ), &

         sexyyl(lblxl:lblxu,lblylm1:lssylm2,lblzlm1:lblzu), &
         sexyyu(lblxl:lblxu,lssyup2:lblyu  ,lblzlm1:lblzu), &
         sexyzl(lblxl:lblxu,lssylm1:lssyup1,lblzlm1:lsszlm2), &
         sexyzu(lblxl:lblxu,lssylm1:lssyup1,lsszup2:lblzu), &

         sezyyl(lblxlm1:lblxu  ,lblylm1:lssylm2,lblzl:lblzu), &
         sezyyu(lblxlm1:lblxu  ,lssyup2:lblyu  ,lblzl:lblzu), &
         sezyxl(lblxlm1:lssxlm2,lssylm1:lssyup1,lblzl:lblzu), &
         sezyxu(lssxup2:lblxu  ,lssylm1:lssyup1,lblzl:lblzu)  &
      )
         allocate ( &
         sbxzzl(lblxl:lblxu  ,lblyl:lblyu  ,lblzl:lsszlm1), &
         sbxzzu(lblxl:lblxu  ,lblyl:lblyu  ,lsszup2:lblzu), &
         sbxzyl(lblxl:lblxu  ,lblyl:lssylm1,lsszl:lsszup1), &
         sbxzyu(lblxl:lblxu  ,lssyup2:lblyu,lsszl:lsszup1), &

         sbyzzl(lblxl:lblxu  ,lblyl:lblyu  ,lblzl:lsszlm1), &
         sbyzzu(lblxl:lblxu  ,lblyl:lblyu  ,lsszup2:lblzu), &
         sbyzxl(lblxl:lssxlm1,lblyl:lblyu  ,lsszl:lsszup1), &
         sbyzxu(lssxup2:lblxu,lblyl:lblyu  ,lsszl:lsszup1), &

         sexzzl(lblxl:lblxu,lblylm1:lblyu  ,lblzlm1:lsszlm2), &
         sexzzu(lblxl:lblxu,lblylm1:lblyu  ,lsszup2:lblzu  ), &
         sexzyl(lblxl:lblxu,lblylm1:lssylm2,lsszlm1:lsszup1), &
         sexzyu(lblxl:lblxu,lssyup2:lblyu  ,lsszlm1:lsszup1), &

         seyzzl(lblxlm1:lblxu  ,lblyl:lblyu,lblzlm1:lsszlm2), &
         seyzzu(lblxlm1:lblxu  ,lblyl:lblyu,lsszup2:lblzu  ), &
         seyzxl(lblxlm1:lssxlm2,lblyl:lblyu,lsszlm1:lsszup1), &
         seyzxu(lssxup2:lblxu  ,lblyl:lblyu,lsszlm1:lsszup1)  &
         )
      end if
!....
      call fdebug ( 's3allc', 1 )
!....
      return
      end
