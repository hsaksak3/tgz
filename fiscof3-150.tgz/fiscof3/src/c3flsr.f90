!----------------------------------------------------------------------
! Compute 3D Field LaSeR
!
      subroutine c3flsr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/17
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use laserprf
      include "implicit.h"
      integer :: i, ipolm, iy, iz, id, ip1, ip2, ip3, iyy, izz
      real*8  ::  wamp, wlt, wlth
      real*8, allocatable  ::  wlsr(:,:,:)
      save
!....
      call fdebug ( 'c3flsr', 0 )
!....
      if( .not. allocated(wlsr) ) allocate( wlsr(6,0:lssyp1,0:lsszp1) )
!....
      if( llsrty .lt. 0 ) then
         ip1 = llinx
         iyy = lliny
         izz = llinz
         if( llsrty .eq. -1 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy,izz) = sbz(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlth )
         else if( llsrty .eq. -2 ) then
            wlt = lltcur
            if( wlt*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 )
            else
               wamp = s0o1
            end if
            sez(ip1,iyy,izz) = sez(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         else if( llsrty .eq. -3 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy,izz) = sbz(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlth )
            wamp = wamp * scfl
            wlt = lltcur
            sez(ip1,iyy,izz) = sez(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         end if
      else
         do i = 1, llsrbn
            if( lbemix(i) .ge. 0 ) then
               ip1 = lbemix(i)
               ip2 = lbemix(i)
               ip3 = lbemix(i) - 1
            else
               ip1 = lssx + lbemix(i)
               ip2 = lssx + lbemix(i) + 1
               ip3 = lssx + lbemix(i) + 1
            end if
!..
            call c3flcom ( i, wlsr, 6, lssyp1+1, lsszp1+1 )
!..
            ipolm = lbemty(i) / 100
!.                                                   * TM, CP *
            if( ipolm .ne. 2 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,iyy,izz)
              do iz = lsszlm1, lsszup1
                 izz = iz
                 do iy = lssyl, lssyup1
                    iyy = iy
                    sey(ip1,iy,iz) = sey(ip1,iy,iz) + wlsr(1,iyy,izz)
                    sbz(ip2,iy,iz) = sbz(ip2,iy,iz) + wlsr(2,iyy,izz)
                    sey(ip3,iy,iz) = sey(ip3,iy,iz) + wlsr(3,iyy,izz)
                 end do
              end do
            end if
!.                                                   * TE, CP *
            if( ipolm .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,iyy,izz)
              do iz = lsszl, lsszup1
                 izz = iz
                 do iy = lssylm1, lssyup1
                    iyy = iy
                    sez(ip1,iy,iz) = sez(ip1,iy,iz) + wlsr(4,iyy,izz)
                    sby(ip2,iy,iz) = sby(ip2,iy,iz) + wlsr(5,iyy,izz)
                    sez(ip3,iy,iz) = sez(ip3,iy,iz) + wlsr(6,iyy,izz)
                 end do
              end do
            end if
         end do
      end if
!....
      call fdebug ( 'c3flsr', 1 )
!....
      return
      end
