!-----------------------------------------------------------------------
! Compute 3D Field Density Electron
!
      subroutine c3fde
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#include "interpolate.macro"
#include "vector.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, iz, ixi, iyi, izi
      real*8  :: wdd,wx1i,wx2i,wx3i,wx4i, &
                 wy1i,wy2i,wy3i,wy4i,wz1i,wz2i,wz3i,wz4i
#ifdef VECTOR
      real*8, allocatable :: vsd(:,:,:,:)
      integer :: iv, iv2
#endif
      save
!....
      call fdebug ('c3fde', 0 )
!....
#ifdef VECTOR
      allocate( &
         vsd(lvlen,lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1) )
#endif
!$OMP PARALLEL PRIVATE(ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  izi,wz1i,wz2i,wz3i,wz4i,wdd)
!..
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sde(ix,iy,iz) = s0o1
#ifdef VECTOR
            vsd(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!..
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC), REDUCTION(+:sde)
      do i = lnoes, lnoee
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vsd)
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1 
#endif
#define _sx sxe(i)
#define _sy sye(i)
#define _sz sze(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#include "interpolate_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _sv _sde
#define _ss spfe(i)
#include "assign_vs.h"
#ifdef VECTOR
      end do
#endif
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            do iv = 1, lvlen
              sde(ix,iy,iz) = sde(ix,iy,iz) + vsd(iv,ix,iy,iz)
            end do
          end do
        end do
      end do
#endif
!...
      if( lexlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            sde(lssxlm1,iy,iz) = sde(lssxlm1,iy,iz) + sde(lssxum1,iy,iz)
            sde(lssxl  ,iy,iz) = sde(lssxl  ,iy,iz) + sde(lssxu  ,iy,iz)
            sde(lssxlp1,iy,iz) = sde(lssxlp1,iy,iz) + sde(lssxup1,iy,iz)
          end do
        end do
      end if
      if( lexupe .eq. 1 ) then
        if( lexlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              sde(lssxum1,iy,iz) = sde(lssxlm1,iy,iz)
              sde(lssxu  ,iy,iz) = sde(lssxl  ,iy,iz)
              sde(lssxup1,iy,iz) = sde(lssxlp1,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              sde(lssxum1,iy,iz) = sde(lssxlm1,iy,iz)+sde(lssxum1,iy,iz)
              sde(lssxu  ,iy,iz) = sde(lssxl  ,iy,iz)+sde(lssxu  ,iy,iz)
              sde(lssxup1,iy,iz) = sde(lssxlp1,iy,iz)+sde(lssxup1,iy,iz)
            end do
          end do
        end if
      end if
!.
      if( leylpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            sde(ix,lssylm1,iz) = sde(ix,lssylm1,iz) + sde(ix,lssyum1,iz)
            sde(ix,lssyl  ,iz) = sde(ix,lssyl  ,iz) + sde(ix,lssyu  ,iz)
            sde(ix,lssylp1,iz) = sde(ix,lssylp1,iz) + sde(ix,lssyup1,iz)
          end do
        end do
      end if
      if( leyupe .eq. 1 ) then
        if( leylpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              sde(ix,lssyum1,iz) = sde(ix,lssylm1,iz)
              sde(ix,lssyu  ,iz) = sde(ix,lssyl  ,iz)
              sde(ix,lssyup1,iz) = sde(ix,lssylp1,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              sde(ix,lssyum1,iz) = sde(ix,lssylm1,iz)+sde(ix,lssyum1,iz)
              sde(ix,lssyu  ,iz) = sde(ix,lssyl  ,iz)+sde(ix,lssyu  ,iz)
              sde(ix,lssyup1,iz) = sde(ix,lssylp1,iz)+sde(ix,lssyup1,iz)
            end do
          end do
        end if
      end if
!.
      if( lezlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sde(ix,iy,lsszlm1) = sde(ix,iy,lsszlm1) + sde(ix,iy,lsszum1)
            sde(ix,iy,lsszl  ) = sde(ix,iy,lsszl  ) + sde(ix,iy,lsszu  )
            sde(ix,iy,lsszlp1) = sde(ix,iy,lsszlp1) + sde(ix,iy,lsszup1)
          end do
        end do
      end if
      if( lezupe .eq. 1 ) then
        if( lezlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              sde(ix,iy,lsszum1) = sde(ix,iy,lsszlm1)
              sde(ix,iy,lsszu  ) = sde(ix,iy,lsszl  )
              sde(ix,iy,lsszup1) = sde(ix,iy,lsszlp1)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              sde(ix,iy,lsszum1) = sde(ix,iy,lsszlm1)+sde(ix,iy,lsszum1)
              sde(ix,iy,lsszu  ) = sde(ix,iy,lsszl  )+sde(ix,iy,lsszu  )
              sde(ix,iy,lsszup1) = sde(ix,iy,lsszlp1)+sde(ix,iy,lsszup1)
            end do
          end do
        end if
      end if
!..
!$OMP END PARALLEL
!...
      lcfde = 1
#ifdef VECTOR
      deallocate( vsd )
#endif
!....
      call fdebug ( 'c3fde', 1 )
!....
      return
      end
