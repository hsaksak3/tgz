!-----------------------------------------------------------------------
! Compute 3D Particle Electron Velocity
!
      subroutine c3pev
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      real*8  :: wtmp
      save
!....
      call fdebug ( 'c3pev', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wtmp)
      do i = lnoes, lnoee
         wtmp = s1o1 / sqrt( s1o1 + suue(i)**2 * scg1 )
         svxe(i) = suxe(i) * wtmp
         svye(i) = suye(i) * wtmp
         svze(i) = suze(i) * wtmp
      end do
!....
      call fdebug ( 'c3pev', 1 )
!....
      return
      end
