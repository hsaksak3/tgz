!-----------------------------------------------------------------------
! Compute 3D Field Density Electron for Old position
!
      subroutine c3fdeo
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#include "interpolate.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, iz, ixi, iyi, izi
      real*8  :: wdd,wx1i,wx2i,wx3i,wx4i, &
                 wy1i,wy2i,wy3i,wy4i,wz1i,wz2i,wz3i,wz4i
      save
!....
!$OMP PARALLEL PRIVATE(ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  izi,wz1i,wz2i,wz3i,wz4i,wdd)
!..
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sdeo(ix,iy,iz) = s0o1
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC), REDUCTION(+:sdeo)
      do i = lnoes, lnoee
#define _sx sxe(i)
#define _sy sye(i)
#define _sz sze(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#include "interpolate_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _sv sdeo
#define _ss spfe(i)
#include "assign_vs.h"
      end do
!...
      if( lexlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            sdeo(lssxlm1,iy,iz) = sdeo(lssxlm1,iy,iz) + sdeo(lssxum1,iy,iz)
            sdeo(lssxl  ,iy,iz) = sdeo(lssxl  ,iy,iz) + sdeo(lssxu  ,iy,iz)
            sdeo(lssxlp1,iy,iz) = sdeo(lssxlp1,iy,iz) + sdeo(lssxup1,iy,iz)
          end do
        end do
      end if
      if( lexupe .eq. 1 ) then
        if( lexlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              sdeo(lssxum1,iy,iz) = sdeo(lssxlm1,iy,iz)
              sdeo(lssxu  ,iy,iz) = sdeo(lssxl  ,iy,iz)
              sdeo(lssxup1,iy,iz) = sdeo(lssxlp1,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              sdeo(lssxum1,iy,iz) = sdeo(lssxlm1,iy,iz)+sdeo(lssxum1,iy,iz)
              sdeo(lssxu  ,iy,iz) = sdeo(lssxl  ,iy,iz)+sdeo(lssxu  ,iy,iz)
              sdeo(lssxup1,iy,iz) = sdeo(lssxlp1,iy,iz)+sdeo(lssxup1,iy,iz)
            end do
          end do
        end if
      end if
!.
      if( leylpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            sdeo(ix,lssylm1,iz) = sdeo(ix,lssylm1,iz) + sdeo(ix,lssyum1,iz)
            sdeo(ix,lssyl  ,iz) = sdeo(ix,lssyl  ,iz) + sdeo(ix,lssyu  ,iz)
            sdeo(ix,lssylp1,iz) = sdeo(ix,lssylp1,iz) + sdeo(ix,lssyup1,iz)
          end do
        end do
      end if
      if( leyupe .eq. 1 ) then
        if( leylpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              sdeo(ix,lssyum1,iz) = sdeo(ix,lssylm1,iz)
              sdeo(ix,lssyu  ,iz) = sdeo(ix,lssyl  ,iz)
              sdeo(ix,lssyup1,iz) = sdeo(ix,lssylp1,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              sdeo(ix,lssyum1,iz) = sdeo(ix,lssylm1,iz)+sdeo(ix,lssyum1,iz)
              sdeo(ix,lssyu  ,iz) = sdeo(ix,lssyl  ,iz)+sdeo(ix,lssyu  ,iz)
              sdeo(ix,lssyup1,iz) = sdeo(ix,lssylp1,iz)+sdeo(ix,lssyup1,iz)
            end do
          end do
        end if
      end if
!.
      if( lezlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sdeo(ix,iy,lsszlm1) = sdeo(ix,iy,lsszlm1) + sdeo(ix,iy,lsszum1)
            sdeo(ix,iy,lsszl  ) = sdeo(ix,iy,lsszl  ) + sdeo(ix,iy,lsszu  )
            sdeo(ix,iy,lsszlp1) = sdeo(ix,iy,lsszlp1) + sdeo(ix,iy,lsszup1)
          end do
        end do
      end if
      if( lezupe .eq. 1 ) then
        if( lezlpe .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              sdeo(ix,iy,lsszum1) = sdeo(ix,iy,lsszlm1)
              sdeo(ix,iy,lsszu  ) = sdeo(ix,iy,lsszl  )
              sdeo(ix,iy,lsszup1) = sdeo(ix,iy,lsszlp1)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              sdeo(ix,iy,lsszum1) = sdeo(ix,iy,lsszlm1)+sdeo(ix,iy,lsszum1)
              sdeo(ix,iy,lsszu  ) = sdeo(ix,iy,lsszl  )+sdeo(ix,iy,lsszu  )
              sdeo(ix,iy,lsszup1) = sdeo(ix,iy,lsszlp1)+sdeo(ix,iy,lsszup1)
            end do
          end do
        end if
      end if
!..
!$OMP END PARALLEL
!....
      return
      end
