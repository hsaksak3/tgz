!-----------------------------------------------------------------------
! Advance 3D Particle Ion Momentum
!
      subroutine a3pim
!
!   <arguments>
!    none
!
!   <remarks>
!    none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      save
!....
      call fdebug ( 'a3pim', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do i = lnois, lnoie
         suxi(i) = suxi(i) + sfxi(i)
         suyi(i) = suyi(i) + sfyi(i)
         suzi(i) = suzi(i) + sfzi(i)
         suui(i) = sqrt( suxi(i)**2 + suyi(i)**2 + suzi(i)**2 )
      end do
!....
      call fdebug( 'a3pim', 1 )
!....
      return
      end
