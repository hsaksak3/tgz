!----------------------------------------------------------------------
! Observe 3D Field Current Total
!                          /
      subroutine o3fjt ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/12/03
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 33, ifn = 14
      integer :: kflag, i, iofjt, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iwjta
      real*8, allocatable :: wjxa(:), wjya(:), wjza(:)
      save
!....
      call fdebug ( 'o3fjt', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
         iwjta = iwjta + 1
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wjxa(ixyz) = wjxa(ixyz) + &
                          ( sjxt(ix,iy,iz) + sjxt(ix+1,iy,iz) )*s1o2
               wjya(ixyz) = wjya(ixyz) + &
                          ( sjyt(ix,iy,iz) + sjyt(ix,iy+1,iz) )*s1o2
               wjza(ixyz) = wjza(ixyz) + &
                          ( sjzt(ix,iy,iz) + sjzt(ix,iy,iz+1) )*s1o2
             end do
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do i = 1, loxyzpl
               wjxa(i) = wjxa(i) /  ( iwjta * snepm1 * scfl )
               wjya(i) = wjya(i) /  ( iwjta * snepm1 * scfl )
               wjza(i) = wjza(i) /  ( iwjta * snepm1 * scfl )
            end do
            if( iofjt .le. 4 ) then
               write(iun) sstcur, (wjxa(i),wjya(i),wjza(i),i=1,loxyzpl)
               flush(iun)
            end if
            if( iofjt .ge. 2 ) then
               call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wjxa,wjya,wjza, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fjxt', 'fjyt', 'fjzt' )
            end if
          end if
         else
!....
            iofjt = mod( lofjt, 10 )
            i3d   = mod( lofjt/100, 10 )
            icrxy = mod( lofjt/1000, 10 )
            icryz = mod( lofjt/10000, 10 )
            icrxz = mod( lofjt/100000, 10 )
!.
            if( iofjt .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fjt', & 
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
               if( .not. allocated(wjxa) ) &
                 allocate( wjxa(loxyzpl), wjya(loxyzpl), wjza(loxyzpl) )
            end if
!....
            if( iofjt .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fjt', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
               write(iun) 'fjt4', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
               flush(iun)
            end if
            if( iofjt .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fjt', bfile )
               call frames_file ( bfile, ifn, iofjt )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwjta = 0
            do i = 1, loxyzpl
               wjxa(i) = s0o1
               wjya(i) = s0o1
               wjza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fjt', 1 )
!....
      return
      end
