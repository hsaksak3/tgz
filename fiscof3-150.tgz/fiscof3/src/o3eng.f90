!----------------------------------------------------------------------
! Observe 3D ENeGy
!                          /
      subroutine o3eng ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
      use parameter
      use constant
      use particle
      use field
      use observe
      use debug
      include "implicit.h"
      integer :: kflag, init=0, i, ix, iy, iz, io, ienga, &
                 iday, ihour, imin, isec
      real*8  :: fgetwtod, acpu, &
                 wee, wexe, weye, weze, wjxe, wjye, wjze, weeg, &
                 weea, wexea, weyea, wezea, wjxea, wjyea, wjzea, &
                 wei, wexi, weyi, wezi, wjxi, wjyi, wjzi, weig, &
                 weex, weey, weez, webx, weby, webz, &
                 weexa, weeya, weeza, webxa, webya, webza, &
                 wetot, wu2, wu2irt
      real*8  :: weia(lionspx),  &
                 wexia(lionspx), weyia(lionspx), wezia(lionspx), &
                 wjxia(lionspx), wjyia(lionspx), wjzia(lionspx)
      character*32 cdate
      save
!....
      call fdebug ( 'o3eng', 0 )
!....
      if( kflag .ge. 2 ) then
         ienga = ienga + 1
!..
         wee  = s0o1
         wexe = s0o1
         weye = s0o1
         weze = s0o1
         wjxe = s0o1
         wjye = s0o1
         wjze = s0o1
         if( lnoe .gt. 0 ) then
            do i = lnoes, lnoee
               wu2 = suue(i)**2
               if( wu2 .ne. s0o1 ) then
                  wu2irt = s1o1 / sqrt( wu2 )
                  weeg = ( sqrt( s1o1+wu2*scg1 ) - s1o1 ) * spfe(i)
                  wee  = wee + weeg
                  wexe = wexe + weeg * abs( suxe(i) ) * wu2irt
                  weye = weye + weeg * abs( suye(i) ) * wu2irt
                  weze = weze + weeg * abs( suze(i) ) * wu2irt
               end if
               wjxe = wjxe + svxe(i) * spfe(i)
               wjye = wjye + svye(i) * spfe(i)
               wjze = wjze + svze(i) * spfe(i)
            end do
         end if
!.
         wee  = wee * scoee
         wexe = wexe * scoee
         weye = weye * scoee
         weze = weze * scoee
         wjxe = - wjxe / ( spnoe * svte )
         wjye = - wjye / ( spnoe * svte )
         wjze = - wjze / ( spnoe * svte )
!.
         weea  = weea + wee
         wexea = wexea + wexe
         weyea = weyea + weye
         wezea = wezea + weze
         wjxea = wjxea + wjxe
         wjyea = wjyea + wjye
         wjzea = wjzea + wjze
!..
         if( lnoi .gt. 0 ) then
            do io = 1, lionspl
               wei  = s0o1
               wexi = s0o1
               weyi = s0o1
               wezi = s0o1
               wjxi = s0o1
               wjyi = s0o1
               wjzi = s0o1
               do i = lionids(io), lionide(io)
                  wu2 = suui(i)**2
                  if( wu2 .ne. s0o1 ) then
                     wu2irt = s1o1 / sqrt( wu2 )
                     weig = ( sqrt( s1o1+wu2*scg1 ) - s1o1 ) * spfi(i)
                     wei  = wei + weig
                     wexi = wexi + weig * abs( suxi(i) ) * wu2irt
                     weyi = weyi + weig * abs( suyi(i) ) * wu2irt
                     wezi = wezi + weig * abs( suzi(i) ) * wu2irt
                  end if
                  wjxi = wjxi + svxi(i) * spfi(i)
                  wjyi = wjyi + svyi(i) * spfi(i)
                  wjzi = wjzi + svzi(i) * spfi(i)
               end do
               wei  = wei * scoei * sionam(io)
               wexi = wexi * scoei * sionam(io)
               weyi = weyi * scoei * sionam(io)
               wezi = wezi * scoei * sionam(io)
               wjxi = wjxi * sionaz(io) / ( spnoit * svte )
               wjyi = wjyi * sionaz(io) / ( spnoit * svte )
               wjzi = wjzi * sionaz(io) / ( spnoit * svte )
!.
               weia(io)  = weia(io) + wei
               wexia(io) = wexia(io) + wexi
               weyia(io) = weyia(io) + weyi
               wezia(io) = wezia(io) + wezi
               wjxia(io) = wjxia(io) + wjxi
               wjyia(io) = wjyia(io) + wjyi
               wjzia(io) = wjzia(io) + wjzi
            end do
         end if
!..
         weex = s0o1
         weey = s0o1
         weez = s0o1
         webx = s0o1
         weby = s0o1
         webz = s0o1
         do iz = lsszlp1, lsszu
           do iy = lssylp1, lssyu
             do ix = lssxlp1, lssxu
               weex = weex + sex(ix,iy,iz)**2
               weey = weey + sey(ix,iy,iz)**2
               weez = weez + sez(ix,iy,iz)**2
               webx = webx + sbx(ix,iy,iz)**2
               weby = weby + sby(ix,iy,iz)**2
               webz = webz + sbz(ix,iy,iz)**2
             end do
           end do
         enddo
         weex = weex * scoef
         weey = weey * scoef
         weez = weez * scoef
         webx = webx * scoeb
         weby = weby * scoeb
         webz = webz * scoeb
!..
         weexa = weexa + weex
         weeya = weeya + weey
         weeza = weeza + weez
         webxa = webxa + webx
         webya = webya + weby
         webza = webza + webz
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
            weea  = weea / ienga
            wexea = wexea / ienga
            weyea = weyea / ienga
            wezea = wezea / ienga
            wjxea = wjxea / ienga
            wjyea = wjyea / ienga
            wjzea = wjzea / ienga
            do io = 1, lionspl
               weia(io)  = weia(io) / ienga
               wexia(io) = wexia(io) / ienga
               weyia(io) = weyia(io) / ienga
               wezia(io) = wezia(io) / ienga
               wjxia(io) = wjxia(io) / ienga
               wjyia(io) = wjyia(io) / ienga
               wjzia(io) = wjzia(io) / ienga
            end do
            weexa = weexa / ienga
            weeya = weeya / ienga
            weeza = weeza / ienga
            webxa = webxa / ienga
            webya = webya / ienga
            webza = webza / ienga
            acpu = fgetwtod() - dtotst
            iday  = acpu / ( 3600.0d0 * 24.0d0 )
            ihour = ( acpu - iday*3600.0d0*24.0d0 ) / 3600.0d0
            imin = ( acpu - (iday*24.0d0+ihour) * 3600.0d0 ) / 60.0d0
            isec =  acpu - ((iday*24.0d0+ihour)*3600.d0 + imin*60.d0 )
            if( init .eq. 0 ) then
              if( lrank .le. 0 ) then
                write(6,1000)
                do io = 1, lionspl
                  write(6,1001) io
                end do
                write(6,1002)
                do io = 1, lionspl
                  write(6,1003) io
                end do
              end if
              init = 1
            end if
            if( lrank .le. 0 ) then
              wetot = weea
              call fdate ( cdate )
              write(6,1100) sstcur, lstcur, iday, ihour, imin, isec, &
                          cdate(1:24), wexea, weyea, wezea, weea
              do io = 1, lionspl
                wetot = wetot + weia(io)
                write(6,1101) io,wexia(io),weyia(io),wezia(io),weia(io)
              end do
              wetot = wetot + (weexa+weeya+weeza) + (webxa+webya+webza)
              write(6,1102) weexa, weeya, weeza, (weexa+weeya+weeza), &
                         webxa, webya, webza, (webxa+webya+webza), &
                         wjxea, wjyea, wjzea, wetot
              do io = 1, lionspl
                write(6,1103) io,wjxia(io),wjyia(io),wjzia(io)
              end do
            end if
         end if
         ienga = 0
         weea  = s0o1
         wexea = s0o1
         weyea = s0o1
         wezea = s0o1
         wjxea = s0o1
         wjyea = s0o1
         wjzea = s0o1
         do io = 1, lionspl
            weia(io)  = s0o1
            wexia(io) = s0o1
            weyia(io) = s0o1
            wezia(io) = s0o1
            wjxia(io) = s0o1
            wjyia(io) = s0o1
            wjzia(io) = s0o1
         end do
         weexa = s0o1
         weeya = s0o1
         weeza = s0o1
         webxa = s0o1
         webya = s0o1
         webza = s0o1
      end if
!....
      call fdebug ( 'o3eng', 1 )
!....
      return
 1000 format('%%%%%%',t12,'time',t20,'step',t36,'cpu',t52,'date' / &
       t20,'ele-eng(x)', t36,'ele-eng(y)', t52,'ele-eng(z)',  &
                                                    t68, 'ele-eng' )
 1001 format( t12, 'ion#', i1,  &
       t20,'ion-eng(x)', t36,'ion-eng(y)', t52,'ion-eng(z)',  &
                                                    t68, 'ion-eng' )
 1002 format( &
       t20,'Ex', t36, 'Ey', t52, 'Ez', t68, 'E-field' / &
       t20,'Bx', t36, 'By', t52, 'Bz', t68, 'B-field' / &
       t20,'jxe', t36, 'jye', t52, 'jze', t68,'total eng' )
 1003 format( t12, 'ion#', i1, t20,'jxi', t36, 'jyi', t52, 'jzi' )
 1100 format('%%%%%%',f10.1,i16,i7,':',i2.2,':',i2.2,':',i2.2,t52,a24/&
       t17, 4e16.7 )
 1101 format( t12, 'ion#', i1, t17, 4e16.7 )
 1102 format( t17, 4e16.7 )
 1103 format( t12, 'ion#', i1, t17, 3e16.7 )
      end
