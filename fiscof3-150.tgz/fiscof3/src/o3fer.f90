!----------------------------------------------------------------------
! Observe 3D Field electric(E) Raw
!                          /
      subroutine o3fer ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 28, ifn = 9
      integer :: kflag, i, iofer, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iwera, inst
      real*8, allocatable :: wexa(:), weya(:), weza(:), &
                             wexi(:), weyi(:), wezi(:)
      character(4) :: chead
      save
!....
      call fdebug ( 'o3fer', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
         iwera = iwera + 1
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wexa(ixyz) = wexa(ixyz) + &
                          ( sex(ix,iy,iz) + sex(ix+1,iy,iz) )*s1o2
               weya(ixyz) = weya(ixyz) + &
                          ( sey(ix,iy,iz) + sey(ix,iy+1,iz) )*s1o2
               weza(ixyz) = weza(ixyz) + &
                          ( sez(ix,iy,iz) + sez(ix,iy,iz+1) )*s1o2
             end do
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do i = 1, loxyzpl
               wexa(i) = wexa(i) / iwera * scofe
               weya(i) = weya(i) / iwera * scofe
               weza(i) = weza(i) / iwera * scofe
            end do
!
            if( inst .ne. 0 ) then
              ixyz = 0
              do iz = lozps, lozpe, lozpi
                do iy = loyps, loype, loypi
                  do ix = loxps, loxpe, loxpi
                    ixyz = ixyz + 1
                    wexi(ixyz) = &
                       ( sex(ix,iy,iz) + sex(ix+1,iy,iz) )*s1o2 * scofe
                    weyi(ixyz) = &
                       ( sey(ix,iy,iz) + sey(ix,iy+1,iz) )*s1o2 * scofe
                    wezi(ixyz) = &
                       ( sez(ix,iy,iz) + sez(ix,iy,iz+1) )*s1o2 * scofe
                  end do
                end do
              end do
            end if
!
            if( iofer .le. 4 ) then
              if( inst .eq. 0 ) then
                write(iun) sstcur, (wexa(i),weya(i),weza(i),i=1,loxyzpl)
              else
                write(iun)sstcur,(wexa(i),weya(i),weza(i),i=1,loxyzpl),&
                                 (wexi(i),weyi(i),wezi(i),i=1,loxyzpl)
              end if
              flush(iun)
            end if
            if( iofer .ge. 2 ) then
               call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wexa,weya,weza, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fexr', 'feyr', 'fezr' )
               if( inst .ne. 0 ) &
                 call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wexi,weyi,wezi, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fexr(inst.)', 'feyr(inst.)', 'fezr(inst.)' )
            end if
          end if
         else
!....
            iofer = mod( lofer, 10 )
            i3d   = mod( lofer/100, 10 )
            icrxy = mod( lofer/1000, 10 )
            icryz = mod( lofer/10000, 10 )
            icrxz = mod( lofer/100000, 10 )
            inst  = lofer / 1000000
!.
            if( iofer .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fer', & 
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
              if( .not. allocated(wexa) ) &
                allocate( wexa(loxyzpl), weya(loxyzpl), weza(loxyzpl) )
              if( inst .ne. 0 ) then
                if( .not. allocated(wexi) ) &
                allocate( wexi(loxyzpl), weyi(loxyzpl), wezi(loxyzpl) )
              end if
            end if
!....
            if( iofer .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fer', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
               chead = 'fer4'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
               flush(iun)
            end if
            if( iofer .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fer', bfile )
               call frames_file ( bfile, ifn, iofer )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwera = 0
            do i = 1, loxyzpl
               wexa(i) = s0o1
               weya(i) = s0o1
               weza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fer', 1 )
!....
      return
      end
