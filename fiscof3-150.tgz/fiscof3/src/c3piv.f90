!-----------------------------------------------------------------------
! Compute 3D Particle Ion Velocity
!
      subroutine c3piv
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      real*8  :: wtmp
      save
!....
      call fdebug ( 'c3piv', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wtmp)
      do i = lnois, lnoie
         wtmp = s1o1 / sqrt( s1o1 + suui(i)**2 * scg1 )
         svxi(i) = suxi(i) * wtmp
         svyi(i) = suyi(i) * wtmp
         svzi(i) = suzi(i) * wtmp
      end do
!....
      call fdebug ( 'c3piv', 1 )
!....
      return
      end
