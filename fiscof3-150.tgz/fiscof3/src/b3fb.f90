!-----------------------------------------------------------------------
! Boundary condition 3D Field magnetic(B) 
!                         /
      subroutine b3fb ( kmode )
!
!   <arguments>
!     kmode : 0 = for all conditions except PML
!           : 1 = for all conditions
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/09/10
!----------------------------------------------------------------------
#include "sfield.macro"
      use constant
      use control
      use field
      include "implicit.h"
      integer :: ix, iy, iz, kmode
      save
!....
      call fdebug ( 'b3fb', 0 )
!....
      select case( lexlf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszl, lsszup1
          do iy = lssylm1, lssyup1
            sby(lssxlm1,iy,iz) = sby(lssxum1,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssyl, lssyup1
            sbz(lssxlm1,iy,iz) = sbz(lssxum1,iy,iz)
          end do
        end do
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlxl
        end if
      case default 
        write(0,*) '### ERROR: invalid lexlf =',lexlf
        call s3ext_abort
      end select
!..
      select case( lexuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszl, lsszup1
          do iy = lssylm1, lssyup1
            sby(lssxup2,iy,iz) = sby(lssxlp2,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssyl, lssyup1
            sbz(lssxup2,iy,iz) = sbz(lssxlp2,iy,iz)
          end do
        end do
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlxu
        end if
      case default 
        write(0,*) '### ERROR: invalid lexuf =',lexuf
        call s3ext_abort
      end select
!...
      select case( leylf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszl, lsszup1
          do ix = lblxl, lblxu
            sbx(ix,lssylm1,iz) = sbx(ix,lssyum1,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lblxl, lblxu
            sbz(ix,lssylm1,iz) = sbz(ix,lssyum1,iz)
          end do
        end do
        if( lexlf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm1, lsszup1
            sbz(lssxlm1,lssylm1,iz) = sbz(lssxum1,lssyum1,iz)
          end do
        end if
        if( lexuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm1, lsszup1
            sbz(lssxup2,lssylm1,iz) = sbz(lssxlp2,lssyum1,iz)
          end do
        end if
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlyl ( lexlf, lexuf )
        end if
      case default 
        write(0,*) '### ERROR: invalid leylf =',leylf
        call s3ext_abort
      end select
!..
      select case( leyuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszl, lsszup1
          do ix = lblxl, lblxu
            sbx(ix,lssyup2,iz) = sbx(ix,lssylp2,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lblxl, lblxu
            sbz(ix,lssyup2,iz) = sbz(ix,lssylp2,iz)
          end do
        end do
        if( lexlf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm1, lsszup1
            sbz(lssxlm1,lssyup2,iz) = sbz(lssxum1,lssylp2,iz)
          end do
        end if
        if( lexuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm1, lsszup1
            sbz(lssxup2,lssyup2,iz) = sbz(lssxlp2,lssylp2,iz)
          end do
        end if
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlyu ( lexlf, lexuf )
        end if
      case default 
        write(0,*) '### ERROR: invalid leyuf =',leyuf
        call s3ext_abort
      end select
!...
      select case( lezlf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssyl, lssyup1
          do ix = lblxl, lblxu
            sbx(ix,iy,lsszlm1) = sbx(ix,iy,lsszum1)
          end do
        end do
        if( leylf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do ix = lssxlm1, lssxup1
            sbx(ix,lssylm1,lsszlm1) = sbx(ix,lssyum1,lsszum1)
          end do
        end if
        if( leyuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do ix = lssxlm1, lssxup1
            sbx(ix,lssyup2,lsszlm1) = sbx(ix,lssylp2,lsszum1)
          end do
        end if
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lblxl, lblxu
            sby(ix,iy,lsszlm1) = sby(ix,iy,lsszum1)
          end do
        end do
        if( lexlf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm1, lssyup1
            sby(lssxlm1,iy,lsszlm1) = sby(lssxum1,iy,lsszum1)
          end do
        end if
        if( lexuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm1, lssyup1
            sby(lssxup2,iy,lsszlm1) = sby(lssxlp2,iy,lsszum1)
          end do
        end if
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlzl ( lexlf, lexuf, leylf, leyuf )
        end if
      case default 
        write(0,*) '### ERROR: invalid lezlf =',lezlf
        call s3ext_abort
      end select
!..
      select case( lezuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssyl, lssyup1
          do ix = lblxl, lblxu
            sbx(ix,iy,lsszup2) = sbx(ix,iy,lsszlp2)
          end do
        end do
        if( leylf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do ix = lssxlm1, lssxup1
            sbx(ix,lssylm1,lsszup2) = sbx(ix,lssyum1,lsszlp2)
          end do
        end if
        if( leyuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do ix = lssxlm1, lssxup1
            sbx(ix,lssyup2,lsszup2) = sbx(ix,lssylp2,lsszlp2)
          end do
        end if
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lblxl, lblxu
            sby(ix,iy,lsszup2) = sby(ix,iy,lsszlp2)
          end do
        end do
        if( lexlf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm1, lssyup1
            sby(lssxlm1,iy,lsszup2) = sby(lssxum1,iy,lsszlp2)
          end do
        end if
        if( lexuf .eq. 1 ) then
!         * Fields values are just needed for references by particles *
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm1, lssyup1
            sby(lssxup2,iy,lsszup2) = sby(lssxlp2,iy,lsszlp2)
          end do
        end if
!$OMP END PARALLEL
      case( 4 )
        if( kmode .ne. 0 ) then
           call b3fb_pmlzu ( lexlf, lexuf, leylf, leyuf )
        end if
      case default 
        write(0,*) '### ERROR: invalid lezuf =',lezuf
        call s3ext_abort
      end select
!....
      call fdebug ( 'b3fb', 1 )
!....
      return
      end
!-----------------------------------------------------------------------
      subroutine b3fb_pmlxl
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblyl, lblyu
          do ix = lblxl, lssxlm1 
            sbyxxl(ix,iy,iz) = scaxlh(ix) * sbyxxl(ix,iy,iz) + &
                      scbbxlh(ix) * ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
            sbzxxl(ix,iy,iz) = scaxlh(ix) * sbzxxl(ix,iy,iz) - &
                      scbbxlh(ix) * ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lblyl, lblyu 
          do ix = lblxl, lssxlm1 
            sbyzxl(ix,iy,iz) = sbyzxl(ix,iy,iz) - &
                                    ( sex(ix,iy,iz)-sex(ix,iy,iz-1) )
            sby(ix,iy,iz) = sbyzxl(ix,iy,iz) + sbyxxl(ix,iy,iz)
          end do
          sby(lblxlm1,iy,iz) = &
                        sby(lblxl,iy,iz)*scb2 + sez(lblxlm1,iy,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyl, lssyup1 
          do ix = lblxl, lssxlm1 
            sbzyxl(ix,iy,iz) = sbzyxl(ix,iy,iz) + &
                                    ( sex(ix,iy,iz)-sex(ix,iy-1,iz) )
            sbz(ix,iy,iz) = sbzyxl(ix,iy,iz) + sbzxxl(ix,iy,iz)
          end do
          sbz(lblxlm1,iy,iz) = &
                        sbz(lblxl,iy,iz)*scb2 - sey(lblxlm1,iy,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lssyl, lssyup1
          do ix = lblxlm1, lssxlm2 
            sbx(ix,iy,iz) = sbx(ix,iy,iz) + &
                                ( sey(ix,iy,iz)-sey(ix,iy,iz-1) ) - &
                                ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
          end do
        end do
      end do
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
      subroutine b3fb_pmlxu
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblyl, lblyu
          do ix = lssxup2, lblxu
            sbyxxu(ix,iy,iz) = scaxuh(ix) * sbyxxu(ix,iy,iz) + &
                      scbbxuh(ix) * ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
            sbzxxu(ix,iy,iz) = scaxuh(ix) * sbzxxu(ix,iy,iz) - &
                      scbbxuh(ix) * ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lblyl, lblyu 
          do ix = lssxup2, lblxu
            sbyzxu(ix,iy,iz) = sbyzxu(ix,iy,iz) - &
                                    ( sex(ix,iy,iz)-sex(ix,iy,iz-1) )
            sby(ix,iy,iz) = sbyzxu(ix,iy,iz) + sbyxxu(ix,iy,iz)
          end do
          sby(lblxup1,iy,iz) = &
                        sby(lblxu,iy,iz)*scb2 - sez(lblxu,iy,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyl, lssyup1 
          do ix = lssxup2, lblxu
            sbzyxu(ix,iy,iz) = sbzyxu(ix,iy,iz) + &
                                    ( sex(ix,iy,iz)-sex(ix,iy-1,iz) )
            sbz(ix,iy,iz) = sbzyxu(ix,iy,iz) + sbzxxu(ix,iy,iz)
          end do
          sbz(lblxup1,iy,iz) = &
                        sbz(lblxu,iy,iz)*scb2 + sey(lblxu,iy,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lssyl, lssyup1
          do ix = lssxup2, lblxu
            sbx(ix,iy,iz) = sbx(ix,iy,iz) + &
                                ( sey(ix,iy,iz)-sey(ix,iy,iz-1) ) - &
                                ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
          end do
        end do
      end do
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
!                               /      /
      subroutine b3fb_pmlyl ( kexlf, kexuf )
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblyl, lssylm1
          do ix = lblxl, lblxu
            sbxyyl(ix,iy,iz) = scaylh(iy) * sbxyyl(ix,iy,iz) - &
                      scbbylh(iy) * ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
            sbzyyl(ix,iy,iz) = scaylh(iy) * sbzyyl(ix,iy,iz) + &
                      scbbylh(iy) * ( sex(ix,iy,iz)-sex(ix,iy-1,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lblyl, lssylm1 
          do ix = lblxl, lblxu 
            sbxzyl(ix,iy,iz) = sbxzyl(ix,iy,iz) + &
                                    ( sey(ix,iy,iz)-sey(ix,iy,iz-1) )
            sbx(ix,iy,iz) = sbxzyl(ix,iy,iz) + sbxyyl(ix,iy,iz)
          end do
        end do
        do ix = lblxl, lblxu 
          sbx(ix,lblylm1,iz) = &
                        sbx(ix,lblyl,iz)*scb2 - sez(ix,lblylm1,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
       do iy = lblyl, lssylm1 
          do ix = lssxl, lssxup1 
            sbzxyl(ix,iy,iz) = sbzxyl(ix,iy,iz) - &
                                    ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
            sbz(ix,iy,iz) = sbzxyl(ix,iy,iz) + sbzyyl(ix,iy,iz)
          end do
        end do
        do ix = lssxl, lssxup1
          sbz(ix,lblylm1,iz) = &
                        sbz(ix,lblyl,iz)*scb2 + sex(ix,lblylm1,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lblylm1, lssylm2 
          do ix = lssxl, lssxup1 
            sby(ix,iy,iz) = sby(ix,iy,iz) - &
                                ( sex(ix,iy,iz)-sex(ix,iy,iz-1) ) + &
                                ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lblyl, lssylm1 
            do ix = lblxl, lssxlm1
              sbz(ix,iy,iz) = sbzxxl(ix,iy,iz) + sbzyyl(ix,iy,iz)
            end do
            sbz(lblxlm1,iy,iz) = &
                        sbz(lblxl,iy,iz)*scb2 - sey(lblxlm1,iy,iz)*sce2
          end do
          do ix = lblxl, lssxlm1
            sbz(ix,lblylm1,iz) = &
                        sbz(ix,lblyl,iz)*scb2 + sex(ix,lblylm1,iz)*sce2
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lblyl, lssylm1 
            do ix = lssxup2, lblxu
              sbz(ix,iy,iz) = sbzxxu(ix,iy,iz) + sbzyyl(ix,iy,iz)
            end do
            sbz(lblxup1,iy,iz) = &
                        sbz(lblxu,iy,iz)*scb2 + sey(lblxu,iy,iz)*sce2
          end do
          do ix = lssxup2, lblxu
            sbz(ix,lblylm1,iz) = &
                        sbz(ix,lblyl,iz)*scb2 + sex(ix,lblylm1,iz)*sce2
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
!                               /      /
      subroutine b3fb_pmlyu ( kexlf, kexuf )
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyup2, lblyu
          do ix = lblxl, lblxu
            sbxyyu(ix,iy,iz) = scayuh(iy) * sbxyyu(ix,iy,iz) - &
                      scbbyuh(iy) * ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
            sbzyyu(ix,iy,iz) = scayuh(iy) * sbzyyu(ix,iy,iz) + &
                      scbbyuh(iy) * ( sex(ix,iy,iz)-sex(ix,iy-1,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lssyup2, lblyu 
          do ix = lblxl, lblxu 
            sbxzyu(ix,iy,iz) = sbxzyu(ix,iy,iz) + &
                                    ( sey(ix,iy,iz)-sey(ix,iy,iz-1) )
            sbx(ix,iy,iz) = sbxzyu(ix,iy,iz) + sbxyyu(ix,iy,iz)
          end do
        end do
        do ix = lblxl, lblxu 
          sbx(ix,lblyup1,iz) = &
                        sbx(ix,lblyu,iz)*scb2 + sez(ix,lblyu,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyup2, lblyu 
          do ix = lssxl, lssxup1
            sbzxyu(ix,iy,iz) = sbzxyu(ix,iy,iz) - &
                                    ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
            sbz(ix,iy,iz) = sbzxyu(ix,iy,iz) + sbzyyu(ix,iy,iz)
          end do
        end do
        do ix = lssxl, lssxup1
          sbz(ix,lblyup1,iz) = &
                        sbz(ix,lblyu,iz)*scb2 - sex(ix,lblyu,iz)*sce2
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszl, lsszup1
        do iy = lssyup2, lblyu 
          do ix = lssxl, lssxup1 
            sby(ix,iy,iz) = sby(ix,iy,iz) - &
                                ( sex(ix,iy,iz)-sex(ix,iy,iz-1) ) + &
                                ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lssyup2, lblyu
            do ix = lblxl, lssxlm1
              sbz(ix,iy,iz) = sbzxxl(ix,iy,iz) + sbzyyu(ix,iy,iz)
            end do
            sbz(lblxlm1,iy,iz) = &
                        sbz(lblxl,iy,iz)*scb2 - sey(lblxlm1,iy,iz)*sce2
          end do
          do ix = lblxl, lssxlm1
            sbz(ix,lblyup1,iz) = &
                        sbz(ix,lblyu,iz)*scb2 - sex(ix,lblyu,iz)*sce2
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lssyup2, lblyu
            do ix = lssxup2, lblxu
              sbz(ix,iy,iz) = sbzxxu(ix,iy,iz) + sbzyyu(ix,iy,iz)
            end do
            sbz(lblxup1,iy,iz) = &
                        sbz(lblxu,iy,iz)*scb2 + sey(lblxu,iy,iz)*sce2
          end do
          do ix = lssxup2, lblxu
            sbz(ix,lblyup1,iz) = &
                        sbz(ix,lblyu,iz)*scb2 - sex(ix,lblyu,iz)*sce2
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
!                               /      /      /      /
      subroutine b3fb_pmlzl ( kexlf, kexuf, keylf, keyuf )
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!     keylf :  = 4 : PML in y low direction
!           : != 4 : ignore
!     keyuf :  = 4 : PML in y upper direction
!           : != 4 : ignore
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, keylf, keyuf, ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lsszlm1
        do iy = lblyl, lblyu
          do ix = lblxl, lblxu
            sbxzzl(ix,iy,iz) = scazlh(iz) * sbxzzl(ix,iy,iz) + &
                      scbbzlh(iz) * ( sey(ix,iy,iz)-sey(ix,iy,iz-1) )
            sbyzzl(ix,iy,iz) = scazlh(iz) * sbyzzl(ix,iy,iz) - &
                      scbbzlh(iz) * ( sex(ix,iy,iz)-sex(ix,iy,iz-1) )
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lsszlm1 
        do iy = lssyl, lssyup1
          do ix = lblxl, lblxu 
            sbxyzl(ix,iy,iz) = sbxyzl(ix,iy,iz) - &
                                    ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
            sbx(ix,iy,iz) = sbxyzl(ix,iy,iz) + sbxzzl(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
        do ix = lblxl, lblxu 
          sbx(ix,iy,lblzlm1) = &
                        sbx(ix,iy,lblzl)*scb2 + sey(ix,iy,lblzlm1)*sce2
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lsszlm1 
        do iy = lblyl, lblyu
          do ix = lssxl, lssxup1
            sbyxzl(ix,iy,iz) = sbyxzl(ix,iy,iz) + &
                                    ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
            sby(ix,iy,iz) = sbyxzl(ix,iy,iz) + sbyzzl(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lblyl, lblyu
        do ix = lssxl, lssxup1
          sby(ix,iy,lblzlm1) = &
                        sby(ix,iy,lblzl)*scb2 - sex(ix,iy,lblzlm1)*sce2
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lsszlm2 
        do iy = lssyl, lssyup1
          do ix = lssxl, lssxup1 
            sbz(ix,iy,iz) = sbz(ix,iy,iz) + &
                                ( sex(ix,iy,iz)-sex(ix,iy-1,iz) ) - &
                                ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lsszlm1
          do iy = lblyl, lblyu 
            do ix = lblxl, lssxlm1
              sby(ix,iy,iz) = sbyxxl(ix,iy,iz) + sbyzzl(ix,iy,iz)
            end do
            sby(lblxlm1,iy,iz) = &
                        sby(lblxl,iy,iz)*scb2 + sez(lblxlm1,iy,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lblyu 
          do ix = lblxl, lssxlm1
            sby(ix,iy,lblzlm1) = &
                        sby(ix,iy,lblzl)*scb2 - sex(ix,iy,lblzlm1)*sce2
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lsszlm1
          do iy = lblyl, lblyu 
            do ix = lssxup2, lblxu 
              sby(ix,iy,iz) = sbyxxu(ix,iy,iz) + sbxzzl(ix,iy,iz)
            end do
            sby(lblxup1,iy,iz) = &
                        sby(lblxu,iy,iz)*scb2 - sez(lblxu,iy,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lblyu 
          do ix = lssxup2, lblxu 
            sby(ix,iy,lblzlm1) = &
                        sby(ix,iy,lblzl)*scb2 - sex(ix,iy,lblzlm1)*sce2
          end do
        end do
      end if
!...
      if( keylf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lsszlm1
          do iy = lblyl, lssylm1 
            do ix = lblxl, lblxu
              sbx(ix,iy,iz) = sbxyyl(ix,iy,iz) + sbxzzl(ix,iy,iz)
            end do
          end do
          do ix = lblxl, lblxu
            sbx(ix,lblylm1,iz) = &
                        sbx(ix,lblyl,iz)*scb2 - sez(ix,lblylm1,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lssylm1 
          do ix = lblxl, lblxu
            sbx(ix,iy,lblzlm1) = &
                        sbx(ix,iy,lblzl)*scb2 + sey(ix,iy,lblzlm1)*sce2
          end do
        end do
      end if
!..
      if( keyuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lsszlm1
          do iy = lssyup2, lblyu 
            do ix = lblxl, lblxu
              sbx(ix,iy,iz) = sbxyyu(ix,iy,iz) + sbxzzl(ix,iy,iz)
            end do
          end do
          do ix = lblxl, lblxu
            sbx(ix,lblyup1,iz) = &
                        sbx(ix,lblyu,iz)*scb2 + sez(ix,lblyu,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssyup2, lblyu 
          do ix = lblxl, lblxu
            sbx(ix,iy,lblzlm1) = &
                        sbx(ix,iy,lblzl)*scb2 + sey(ix,iy,lblzlm1)*sce2
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
!                               /      /      /      /
      subroutine b3fb_pmlzu ( kexlf, kexuf, keylf, keyuf )
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!     keylf :  = 4 : PML in y low direction
!           : != 4 : ignore
!     keyuf :  = 4 : PML in y upper direction
!           : != 4 : ignore
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, keylf, keyuf, ix, iy, iz
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lblyl, lblyu
          do ix = lblxl, lblxu
            sbxzzu(ix,iy,iz) = scazuh(iz) * sbxzzu(ix,iy,iz) + &
                      scbbzuh(iz) * ( sey(ix,iy,iz)-sey(ix,iy,iz-1) )
            sbyzzu(ix,iy,iz) = scazuh(iz) * sbyzzu(ix,iy,iz) - &
                      scbbzuh(iz) * ( sex(ix,iy,iz)-sex(ix,iy,iz-1) )
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu 
        do iy = lssyl, lssyup1
          do ix = lblxl, lblxu 
            sbxyzu(ix,iy,iz) = sbxyzu(ix,iy,iz) - &
                                    ( sez(ix,iy,iz)-sez(ix,iy-1,iz) )
            sbx(ix,iy,iz) = sbxyzu(ix,iy,iz) + sbxzzu(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
        do ix = lblxl, lblxu 
          sbx(ix,iy,lblzup1) = &
                        sbx(ix,iy,lblzu)*scb2 - sey(ix,iy,lblzu)*sce2
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu 
        do iy = lblyl, lblyu
          do ix = lssxl, lssxup1
            sbyxzu(ix,iy,iz) = sbyxzu(ix,iy,iz) + &
                                    ( sez(ix,iy,iz)-sez(ix-1,iy,iz) )
            sby(ix,iy,iz) = sbyxzu(ix,iy,iz) + sbyzzu(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lblyl, lblyu
        do ix = lssxl, lssxup1
          sby(ix,iy,lblzup1) = &
                        sby(ix,iy,lblzu)*scb2 + sex(ix,iy,lblzu)*sce2
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu 
        do iy = lssyl, lssyup1
          do ix = lssxl, lssxup1 
            sbz(ix,iy,iz) = sbz(ix,iy,iz) + &
                                ( sex(ix,iy,iz)-sex(ix,iy-1,iz) ) - &
                                ( sey(ix,iy,iz)-sey(ix-1,iy,iz) )
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblyl, lblyu 
            do ix = lblxl, lssxlm1
              sby(ix,iy,iz) = sbyxxl(ix,iy,iz) + sbyzzu(ix,iy,iz)
            end do
            sby(lblxlm1,iy,iz) = &
                        sby(lblxl,iy,iz)*scb2 + sez(lblxlm1,iy,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lblyu 
          do ix = lblxl, lssxlm1
            sby(ix,iy,lblzup1) = &
                        sby(ix,iy,lblzu)*scb2 + sex(ix,iy,lblzu)*sce2
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblyl, lblyu 
            do ix = lssxup2, lblxu 
              sby(ix,iy,iz) = sbyxxu(ix,iy,iz) + sbxzzu(ix,iy,iz)
            end do
            sby(lblxup1,iy,iz) = &
                        sby(lblxu,iy,iz)*scb2 - sez(lblxu,iy,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lblyu 
          do ix = lssxup2, lblxu 
            sby(ix,iy,lblzup1) = &
                        sby(ix,iy,lblzu)*scb2 + sex(ix,iy,lblzu)*sce2
          end do
        end do
      end if
!...
      if( keylf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblyl, lssylm1 
            do ix = lblxl, lblxu
              sbx(ix,iy,iz) = sbxyyl(ix,iy,iz) + sbxzzu(ix,iy,iz)
            end do
          end do
          do ix = lblxl, lblxu
            sbx(ix,lblylm1,iz) = &
                        sbx(ix,lblyl,iz)*scb2 - sez(ix,lblylm1,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lblyl, lssylm1 
          do ix = lblxl, lblxu
            sbx(ix,iy,lblzup1) = &
                        sbx(ix,iy,lblzu)*scb2 - sey(ix,iy,lblzu)*sce2
          end do
        end do
      end if
!..
      if( keyuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lssyup2, lblyu 
            do ix = lblxl, lblxu
              sbx(ix,iy,iz) = sbxyyu(ix,iy,iz) + sbxzzu(ix,iy,iz)
            end do
          end do
          do ix = lblxl, lblxu
            sbx(ix,lblyup1,iz) = &
                        sbx(ix,lblyu,iz)*scb2 + sez(ix,lblyu,iz)*sce2
          end do
        end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssyup2, lblyu 
          do ix = lblxl, lblxu
            sbx(ix,iy,lblzup1) = &
                        sbx(ix,iy,lblzu)*scb2 - sey(ix,iy,lblzu)*sce2
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
