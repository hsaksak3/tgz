!-----------------------------------------------------------------------
! Compute 3D Field Density Ion
!
      subroutine c3fdi
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#include "interpolate.macro"
#include "vector.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, iz, ixi, iyi, izi
      real*8  :: wdd,wx1i,wx2i,wx3i,wx4i, &
                 wy1i,wy2i,wy3i,wy4i,wz1i,wz2i,wz3i,wz4i
      real*8, allocatable :: wdi(:,:,:)
#ifdef VECTOR
      real*8, allocatable :: vsd(:,:,:,:)
      integer :: iv, iv2 
#endif
      save
!....
      call fdebug ('c3fdi', 0 )
!....
      if( lnoi .gt. 0 ) then
!....
      if( .not. allocated(wdi) ) &
        allocate( wdi(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1) )
#ifdef VECTOR
      allocate( &
         vsd(lvlen,lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1) )
#endif
!....
!$OMP PARALLEL PRIVATE(io,ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                     iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                     izi,wz1i,wz2i,wz3i,wz4i,wdd)
!...
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            wdi(ix,iy,iz) = s0o1
#ifdef VECTOR
            vsd(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!..
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC), REDUCTION(+:wdi)
      do i = lionids(io), lionide(io)
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vsd)
      do iv2 = lionids(io), lionide(io), lvlen
!NEC$ IVDEP
      do iv = 1, min(lionide(io)-iv2+1, lvlen)
         i = iv + iv2 - 1 
#endif
#define _sx sxi(i)
#define _sy syi(i)
#define _sz szi(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#include "interpolate_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _sv _wdi
#define _ss spfi(i)
#include "assign_vs.h"
#ifdef VECTOR
      end do  
#endif
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm1, lsszup1 
        do iy = lssylm1, lssyup1 
          do ix = lssxlm1, lssxup1 
            do iv = 1, lvlen
              wdi(ix,iy,iz) = wdi(ix,iy,iz) + vsd(iv,ix,iy,iz)
            end do
          end do
        end do
      end do  
#endif
!...
      if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            wdi(lssxlm1,iy,iz) = wdi(lssxlm1,iy,iz) + wdi(lssxum1,iy,iz)
            wdi(lssxl  ,iy,iz) = wdi(lssxl  ,iy,iz) + wdi(lssxu  ,iy,iz)
            wdi(lssxlp1,iy,iz) = wdi(lssxlp1,iy,iz) + wdi(lssxup1,iy,iz)
          end do
        end do
      end if
      if( lexupi .eq. 1 ) then
        if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              wdi(lssxum1,iy,iz) = wdi(lssxlm1,iy,iz)
              wdi(lssxu  ,iy,iz) = wdi(lssxl  ,iy,iz)
              wdi(lssxup1,iy,iz) = wdi(lssxlp1,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              wdi(lssxum1,iy,iz) = wdi(lssxlm1,iy,iz)+wdi(lssxum1,iy,iz)
              wdi(lssxu  ,iy,iz) = wdi(lssxl  ,iy,iz)+wdi(lssxu  ,iy,iz)
              wdi(lssxup1,iy,iz) = wdi(lssxlp1,iy,iz)+wdi(lssxup1,iy,iz)
            end do
          end do
        end if
      end if
!.
      if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            wdi(ix,lssylm1,iz) = wdi(ix,lssylm1,iz) + wdi(ix,lssyum1,iz)
            wdi(ix,lssyl  ,iz) = wdi(ix,lssyl  ,iz) + wdi(ix,lssyu  ,iz)
            wdi(ix,lssylp1,iz) = wdi(ix,lssylp1,iz) + wdi(ix,lssyup1,iz)
          end do
        end do
      end if
      if( leyupi .eq. 1 ) then
        if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              wdi(ix,lssyum1,iz) = wdi(ix,lssylm1,iz)
              wdi(ix,lssyu  ,iz) = wdi(ix,lssyl  ,iz)
              wdi(ix,lssyup1,iz) = wdi(ix,lssylp1,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              wdi(ix,lssyum1,iz) = wdi(ix,lssylm1,iz)+wdi(ix,lssyum1,iz)
              wdi(ix,lssyu  ,iz) = wdi(ix,lssyl  ,iz)+wdi(ix,lssyu  ,iz)
              wdi(ix,lssyup1,iz) = wdi(ix,lssylp1,iz)+wdi(ix,lssyup1,iz)
            end do
          end do
        end if
      end if
!.
      if( lezlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            wdi(ix,iy,lsszlm1) = wdi(ix,iy,lsszlm1) + wdi(ix,iy,lsszum1)
            wdi(ix,iy,lsszl  ) = wdi(ix,iy,lsszl  ) + wdi(ix,iy,lsszu  )
            wdi(ix,iy,lsszlp1) = wdi(ix,iy,lsszlp1) + wdi(ix,iy,lsszup1)
          end do
        end do
      end if
      if( lezupi .eq. 1 ) then
        if( lezlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              wdi(ix,iy,lsszum1) = wdi(ix,iy,lsszlm1)
              wdi(ix,iy,lsszu  ) = wdi(ix,iy,lsszl  )
              wdi(ix,iy,lsszup1) = wdi(ix,iy,lsszlp1)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              wdi(ix,iy,lsszum1) = wdi(ix,iy,lsszlm1)+wdi(ix,iy,lsszum1)
              wdi(ix,iy,lsszu  ) = wdi(ix,iy,lsszl  )+wdi(ix,iy,lsszu  )
              wdi(ix,iy,lsszup1) = wdi(ix,iy,lsszlp1)+wdi(ix,iy,lsszup1)
            end do
          end do
        end if
      end if
!..
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sdi(ix,iy,iz,io) = wdi(ix,iy,iz)
          end do
        end do
      end do
!...
      end do
!$OMP END PARALLEL
!...
      lcfdi = 1
#ifdef VECTOR
      deallocate( vsd )
#endif
!....
      end if
!....
      call fdebug ( 'c3fdi', 1 )
!....
      return
      end
