!----------------------------------------------------------------------
! Observe 3D Field Density Electron
!                          /
      subroutine o3fde ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 24, ifn = 5
      integer :: kflag, i, iofde, ilog, iso, i3d, icrxy, icryz, &
                 icrxz, ix, iy, iz, ixyz, iwdea
      real*8:: woisov(loisox)
      real*8, allocatable :: wdea(:)
      save
!....
      call fdebug ( 'o3fde', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
         if( lcfde .eq. 0 ) call c3fde
         iwdea = iwdea + 1
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wdea(ixyz) = wdea(ixyz) + sde(ix,iy,iz)
             end do
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do i = 1, loxyzpl
               wdea(i) = wdea(i) / ( iwdea * snepm1 )
            end do
            if( iofde .le. 4 ) then
               write(iun) sstcur, ( wdea(i),i=1,loxyzpl )
               flush(iun)
            end if
            if( iofde .ge. 2 ) then
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, ilog, i3d, iso, 3, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, woisov, &
                 wdea, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, 'fde' )
            end if
          end if
         else
!....
           iofde = mod( lofde, 10 )
           ilog  = mod( lofde/10, 10 )
           i3d   = mod( lofde/100, 10 )
           iso   = i3d / 2
           i3d   = mod( i3d, 2 )
           icrxy = mod( lofde/1000, 10 )
           icryz = mod( lofde/10000, 10 )
           icrxz = mod( lofde/100000, 10 )
!.
           if( iofde .ge. 2 ) then
             if( iso+i3d+icrxy+icryz+icrxz .eq. 0 ) then
               write(0,*) '### ERROR: no plot for fde', &
                           iso, i3d, icrxy, icryz, icrxz
               call s3ext_abort
             end if
             if( iso .gt. loisox ) then
               write(0,*) '### ERROR: iso is greater than loisox.',lofde
               call s3ext_abort
             end if
             do i = 1, iso
               woisov(i) = soisov(i)
               if( ilog .ge. 1 ) woisov(i) = log10( woisov(i) )
             end do
           end if
!...
           if( loxyzpl .gt. 0 ) then
              if( .not. allocated(wdea) ) allocate( wdea(loxyzpl) )
           end if
!..
           if( iofde .le. 4 ) then
              call fntpcnv ( bbifntp, lrank,iun, bident,'fde', bfile )
              open(iun, file=bfile, form='UNFORMATTED')
              write(iun) 'fde4', bident, loxyzpl, loxpl, loypl, lozpl, &
                       soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
              flush(iun)
           end if
           if( iofde .ge. 2 ) then
              call fntpcnv ( bfrfntp, lrank,ifn, bident,'fde', bfile )
              call frames_file ( bfile, ifn, iofde )
           end if
         end if
         if( loxyzpl .gt. 0 ) then
           iwdea = 0
           do i = 1, loxyzpl
              wdea(i) = s0o1
           end do
         end if
      end if
!....
      call fdebug ( 'o3fde', 1 )
!....
      return
      end
