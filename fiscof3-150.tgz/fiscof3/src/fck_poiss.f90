!-----------------------------------------------------------------------
! Check Poisson equation
!                              /
      subroutine fck_poiss ( echar )
!
!   <arguments>
!     echar : message for print
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
      use constant
      use field
      use particle
      include "implicit.h"
      integer :: io, ix, iy, iz, ixerx, iyerx, izerx
      real*8  :: wdi, werr, werrx, werrs
      character*(*) echar
      save
!....
      if( lcfde .eq. 0 ) call c3fde
      if( lcfdi .eq. 0 ) call c3fdi
!...
      werrx = s0o1
      ixerx = -1
      iyerx = -1
      izerx = -1
      werrs = s0o1
!..
      if( lnoi .gt. 0 ) then
         do iz = lsszl, lsszu
           do iy = lssyl, lssyu
             do ix = lssxl, lssxu
               wdi = s0o1
               do io = 1, lionspl
                  wdi = wdi + sdi(ix,iy,iz,io) * sionaz(io)
               end do
               werr = ( sex(ix+1,iy,iz) - sex(ix,iy,iz) + &
                        sey(ix,iy+1,iz) - sey(ix,iy,iz) + &
                        sez(ix,iy,iz+1) - sez(ix,iy,iz) + &
                        ( sde(ix,iy,iz) - wdi ) * scr1 )**2
               if( werr .gt. werrx ) then
                  werrx = werr
                  ixerx = ix
                  iyerx = iy
                  izerx = iz
               end if
               werrs = werrs + werr
             end do
           end do
         end do
      else
         do iz = lsszl, lsszu
           do iy = lssyl, lssyu
             do ix = lssxl, lssxu
               werr = ( sex(ix+1,iy,iz) - sex(ix,iy,iz) + &
                        sey(ix,iy+1,iz) - sey(ix,iy,iz) + &
                        sez(ix,iy,iz+1) - sez(ix,iy,iz) + &
                        ( sde(ix,iy,iz) - sde0(ix,iy,iz) ) * scr1 )**2
               if( werr .gt. werrx ) then
                  werrx = werr
                  ixerx = ix
                  iyerx = iy
                  izerx = iz
               end if
               werrs = werrs + werr
             end do
           end do
         end do
      end if
!..
      werrx = sqrt( werrx )
      werrs = sqrt( werrs ) / &
                ( (lssxu-lssxl+1)*(lssyu-lssyl+1)*(lsszu-lsszl+1) )
      write(6,*) '@@@ fck_poiss ', echar, werrs, werrx, &
                                   ixerx, iyerx, izerx
!....
      return
      end
