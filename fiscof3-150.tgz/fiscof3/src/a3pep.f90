!-----------------------------------------------------------------------
! Advance 3D Particle Electron Position ( full step )
!
      subroutine a3pep
!
!   <arguments>
!     none
!
!   <remarks>
!     always save data
!
!    coded by Sakagami,H. (NIFS) 20/11/11
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      save
!....
      call fdebug( 'a3pep',0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do i = lnoes, lnoee
         sxeo(i) = sxe(i)
         syeo(i) = sye(i)
         szeo(i) = sze(i)
         sxe(i)  = sxe(i) + svxe(i)
         sye(i)  = sye(i) + svye(i)
         sze(i)  = sze(i) + svze(i)
      end do
!....
      call fdebug( 'a3pep', 1 )
!....
      return
      end
