!----------------------------------------------------------------------
! Debug
!                           /      /
      subroutine fdebug ( ename, kmode )
!
!   <arguments>
!     ename : subroutine name
!     kmode : 0 = entry, 1 = exit, -1 = start, -2 = end
!
!   <remarks>
!     ldebug :   1 = cpu time measurement mode
!            : >=2 = check write mode ( larger ldebug, more output )
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
      use debug
      include "implicit.h"
      integer :: kmode, indent=1, i, isubn, ix
      real*8  :: fgetwtod, asum, asump, atot
      character cdata*32, cname*8, ename*(*)
!$    integer OMP_GET_MAX_THREADS
!!$    integer OMP_GET_STACK_SIZE
      save
!....
      if( kmode .eq. -1 ) then
         call fdate ( cdata )
         write(6,*) '+++++ ',trim(ename),' started at ',cdata(1:24),' +++++'
!$       write(6,*) '+++++ OMP_GET_MAX_THREADS = ', OMP_GET_MAX_THREADS()
!!$       write(6,*) '+++++ OpenMP stack size = ', OMP_GET_STACK_SIZE()
!$       cdata = ' '
!$       call getenv ( 'OMP_STACKSIZE', cdata )
!$       if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$       write(6,*) '+++++ OMP_STACKSIZE = ', trim(cdata)
!...             * comment because ldebug is undefined at this moment *
!cc      if ( ldebug .eq. 1 ) then
            dtotst = fgetwtod()
            bsubnm(01) = 'a3fb'
            bsubnm(02) = 'a3fe'
            bsubnm(03) = 'a3flsr'
            bsubnm(04) = 'a3pem'
            bsubnm(05) = 'a3pep'
            bsubnm(06) = 'a3pim'
            bsubnm(07) = 'a3pip'
            bsubnm(08) = 'b3fb'
            bsubnm(09) = 'b3fe'
            bsubnm(10) = 'b3pep'
            bsubnm(11) = 'b3pip'
            bsubnm(12) = 'c3fde'
            bsubnm(13) = 'c3fdi'
            bsubnm(14) = 'c3fed'
            bsubnm(15) = 'c3fjecc'
            bsubnm(16) = 'c3fjicc'
            bsubnm(17) = 'c3fjt'
            bsubnm(18) = 'c3flcom'
            bsubnm(19) = 'c3flsr'
            bsubnm(20) = 'c3pec'
            bsubnm(21) = 'c3pef'
            bsubnm(22) = 'c3pev'
            bsubnm(23) = 'c3pic'
            bsubnm(24) = 'c3pif'
            bsubnm(25) = 'c3piv'
            bsubnm(26) = 's3cnst'
            bsubnm(27) = 's3init'
            bsubnm(28) = 's3qstr'
            bsubnm(29) = 's3rest'
            bsubnm(30) = 's3rstr'
            bsubnm(31) = 's3simp'
            bsubnm(32) = 's3reloc'
            do i = 1, lsubx
               dsubsm(i) = 0.0d0
               lsubcn(i) = 0
            end do
!cc      end if
      else if( kmode .eq. -2 ) then
         call fdate ( cdata )
         write(6,*) '----- ',trim(ename),' ended at ',cdata(1:24),' -----'
!$       write(6,*) '----- OMP_GET_MAX_THREADS = ', OMP_GET_MAX_THREADS()
!$       cdata = ' '
!$       call getenv ( 'OMP_STACKSIZE', cdata )
!$       if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$       write(6,*) '----- OMP_STACKSIZE = ', trim(cdata)
         if ( ldebug .eq. 1 ) then
            atot = fgetwtod() - dtotst
            asum = 0.0d0
            asump = 0.0d0
            write(6,1000)
            do i = 1, lsubx
               asum = asum + dsubsm(i)
               asump = asump + dsubsm(i)/atot*100.0d0
               write(6,1100) bsubnm(i), dsubsm(i), &
                            dsubsm(i)/atot*100.0d0, lsubcn(i)
            end do
            write(6,1000)
            write(6,1100) 'sum', asum, asump, 0
            write(6,1000)
            write(6,1100) 'total', atot, 100.0, 0
            write(6,1000)
         end if
      end if
!...
      if ( ldebug .eq. 1 ) then
         cname = ename
         isubn = 0
         do i = 1, lsubx
            if( cname .eq. bsubnm(i) ) then
               isubn = i
               exit
            end if
         end do
         if( kmode .eq. 0 ) then
            if( isubn .ne. 0 ) then
               dsubst(isubn) = fgetwtod()
            end if
         else if( kmode .eq. 1 ) then
            if( isubn .ne. 0 ) then
               dsubsm(isubn) = dsubsm(isubn) + &
                                        fgetwtod() - dsubst(isubn)
               lsubcn(isubn) = lsubcn(isubn) + 1
            end if
         end if
      end if
!...
      if ( ldebug .ge. 2 ) then
         cname = ename
         if( kmode .eq. 0 ) then
            indent = indent + 1
            if( indent .le. ldebug ) then
               ix = (indent-1)*3 + 1
               cdata = '( nnx,''+++ '', a8, '' +++'' )'
               write( cdata(3:4), '(i2)' ) ix
               write( 6, cdata ) cname
            end if
         else if( kmode .eq. 1 ) then
            if( indent .le. ldebug ) then
               ix = (indent-1)*3 + 1
               cdata = '( nnx,''--- '', a8, '' ---'' )'
               write( cdata(3:4), '(i2)' ) ix
               write( 6, cdata ) cname
            end if
            indent = indent - 1
         end if
      end if
!....
      return
 1000 format( ' +----------+--------------+--------+------------+' )
 1100 format( ' | ', a8, ' | ', f12.2, ' | ', f6.2, ' | ', i10, ' |' )
      end
