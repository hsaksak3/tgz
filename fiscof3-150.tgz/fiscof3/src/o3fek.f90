!----------------------------------------------------------------------
! Observe 3D Field Electric K (wave number) spectrum
!                          /
      subroutine o3fek ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/05/26
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use laserprf
      use profile
      use observe
      include "implicit.h"
      integer :: kflag, i, ii, io, ix, iy, iz, iofek, ilog, iofekl, &
                 ixl, iyl, izl,ikmx, ifftxs3(15),ifftys3(15),ifftzs3(15), &
                 ixps(lofekx),ixpe(lofekx),iyps(lofekx),iype(lofekx),&
                 izps(lofekx),izpe(lofekx),&
                 ixl2(lofekx),iyl2(lofekx),izl2(lofekx), &
                 i3d, iso
      integer, parameter :: iun = 38, ifn = 19
      real*8  :: amx, av,aspxx,aspmn
      real*8, allocatable :: afek(:,:,:), afftxs1(:), afftxs2(:), &
                             afftytm(:), afftys1(:), afftys2(:), &
                             afftztm(:), afftzs1(:), afftzs2(:), &
                             akx(:), aky(:), akz(:),asp(:,:,:), &
                             aspxy(:,:), aspxz(:,:), aspyz(:,:), &
                             aspx(:), aspy(:), aspz(:)
      character :: crange*48, clabel*8, ctime*13, cval*14
      save
!....
      call fdebug ( 'o3fek', 0 )
!....
      if( kflag .ge. 1 ) then
!...
        do io = 1, iofekl
!...
          ixl = ixpe(io)-ixps(io)+1
          iyl = iype(io)-iyps(io)+1
          izl = izpe(io)-izps(io)+1

          allocate( afek(ixl,iyl,izl), afftxs1(ixl), afftxs2(ixl), &
                    afftytm(iyl), afftys1(iyl), afftys2(iyl), &
                    afftztm(izl), afftzs1(izl), afftzs2(izl), &
                    akx(ixl2(io)), aky(iyl2(io)), akz(izl2(io)), &
                    asp(ixl2(io),iyl2(io),izl2(io)), &
                    aspxy(ixl2(io),iyl2(io)), aspxz(ixl2(io),izl2(io)), aspyz(iyl2(io),izl2(io)), &
                    aspx(ixl2(io)), aspy(iyl2(io)), aspz(izl2(io)) )
          call rffti3 ( ixl, iyl, izl, afftxs2,ifftxs3, afftys2,ifftys3, afftzs2,ifftzs3 )

          aspxy(1,1) = s0o1
          do ix = 2, ixl2(io)
            aspxy(ix,1) = s0o1
          end do
          do iy = 2, iyl2(io)
            aspxy(1,iy) = s0o1
          end do
          aspxz(1,1) = s0o1
          do ix = 2, ixl2(io)
            aspxz(ix,1) = s0o1
          end do
          do iz = 2, izl2(io)
            aspxz(1,iz) = s0o1
          end do
          aspyz(1,1) = s0o1
          do iy = 2, iyl2(io)
            aspyz(iy,1) = s0o1
          end do
          do iz = 2, izl2(io)
            aspyz(1,iz) = s0o1
          end do
          
          aspxx=s0o1
          aspmn=1.0d30
          
          asp(:,:,:)=s0o1
          aspx(:)=s0o1
          aspy(:)=s0o1
          aspz(:)=s0o1
!..
          do i = 1, 4
!.
            if( i .eq. 1 ) then
              clabel = 'fek(Ex)'
              do iz = 1, izl
                do iy = 1, iyl
                  do ix = 1, ixl
                    afek(ix,iy,iz) = sex(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)
                  end do
                end do
              end do
            else if( i .eq. 2 ) then
              clabel = 'fek(Ey)'
              do iz = 1, izl
                do iy = 1, iyl
                  do ix = 1, ixl
                    afek(ix,iy,iz) = sey(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)
                  end do
                end do
              end do
            else if( i .eq. 3 ) then
              clabel = 'fek(Ez)'
              do iz = 1, izl
                do iy = 1, iyl
                  do ix = 1, ixl
                    afek(ix,iy,iz) = sez(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)
                  end do
                end do
              end do
            else
              clabel = 'fek(|E|)'
              do iz = 1, izl
                do iy = 1, iyl
                  do ix = 1, ixl
                    afek(ix,iy,iz) = sqrt( &
                             sex(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)**2 + &
                             sey(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)**2 + &
                             sez(ix+ixps(io)-1,iy+iyps(io)-1,iz+izps(io)-1)**2 )
                  end do
                end do
              end do
            end if
!.
            call rfftf3 ( ixl, iyl, izl, afek, afftytm, afftztm, &
                 afftxs1, afftxs2, ifftxs3, afftys1, afftys2, ifftys3, &
                 afftzs1, afftzs2, ifftzs3 )
                 
!.
            do iz = 1, izl2(io)-1
              do iy = 1, iyl2(io)-1
                do ix = 1, ixl2(io)-1
                  asp(ix+1,iy+1,iz+1) = &
                      afek(ix*2  ,iy*2  ,iz*2   )**2 + afek(ix*2+1,iy*2  ,iz*2   )**2 + &
                      afek(ix*2  ,iy*2+1,iz*2   )**2 + afek(ix*2+1,iy*2+1,iz*2   )**2 + &
                      afek(ix*2  ,iy*2  ,iz*2+1 )**2 + afek(ix*2+1,iy*2  ,iz*2+1 )**2 + &
                      afek(ix*2  ,iy*2+1,iz*2+1 )**2 + afek(ix*2+1,iy*2+1,iz*2+1 )**2
                end do
              end do
            end do
!.
            do iy = 1, iyl2(io)
               do ix = 1, ixl2(io)
                  aspxy(ix,iy) = s0o1
                  do iz = 1, izl2(io)
                     aspxy(ix,iy) = aspxy(ix,iy) + asp(ix,iy,iz)
                  end do
               end do
            end do
            
            do iz = 1, izl2(io)
               do iy = 1, iyl2(io)
                  aspyz(iy,iz) = s0o1
                  do ix = 1, ixl2(io)
                     aspyz(iy,iz) = aspyz(iy,iz) + asp(ix,iy,iz)
                  end do
               end do
            end do
            
            do iz = 1, izl2(io)
               do ix = 1, ixl2(io)
                  aspxz(ix,iz) = s0o1
                  do iy = 1, iyl2(io)
                     aspxz(ix,iz) = aspxz(ix,iz) + asp(ix,iy,iz)
                  end do
               end do
            end do
!.
            do ix = 2, ixl2(io)
              aspx(ix) = s0o1
              do iy = 2, iyl2(io)
                aspx(ix) = aspx(ix) + aspxy(ix,iy)
              end do
            end do
            
            do iy = 2, iyl2(io)
              aspy(iy) = s0o1
              do ix = 2, ixl2(io)
                aspy(iy) = aspy(iy) + aspxy(ix,iy)
              end do
            end do
            
            do iz = 2, izl2(io)
              aspz(iz) = s0o1
              do ix = 2, ixl2(io)
                aspz(iz) = aspz(iz) + aspxz(ix,iz)
              end do
            end do
            
!..
            amx = 1.0d-30
            do iz = 2, izl2(io)
              do iy = 2, iyl2(io)
                do ix = 2, ixl2(io)
                  amx = max( amx, asp(ix,iy,iz) )
                end do
              end do
            end do
            do iz = 2, izl2(io)
              do iy = 2, iyl2(io)
                do ix = 2, ixl2(io)
                  asp(ix,iy,iz) = asp(ix,iy,iz) / amx
                  aspxx=max(aspxx,asp(ix,iy,iz))
                  aspmn=min(aspmn,asp(ix,iy,iz))
                end do
              end do
            end do
!
            amx = 1.0d-30
            do iy = 2, iyl2(io)
              do ix = 2, ixl2(io)
                amx = max( amx, aspxy(ix,iy) )
              end do
            end do
            do iz = 2, izl2(io)
              do ix = 2, ixl2(io)
                amx = max( amx, aspxz(ix,iz) )
              end do
            end do
            do iz = 2, izl2(io)
              do iy = 2, iyl2(io)
                amx = max( amx, aspyz(iy,iz) )
              end do
            end do
            
            do iy = 2, iyl2(io)
              do ix = 2, ixl2(io)
                aspxy(ix,iy) = aspxy(ix,iy) / amx
              end do
            end do
            
            do iz = 2, izl2(io)
              do ix = 2, ixl2(io)
                aspxz(ix,iz) = aspxz(ix,iz) / amx
              end do
            end do

            do iz = 2, izl2(io)
              do iy = 2, iyl2(io)
                aspyz(iy,iz) = aspyz(iy,iz) / amx
              end do
            end do

            amx = 1.0d-30
            akx(1) = s0o1
            do ix = 2, ixl2(io)
              akx(ix) = ( slram * (ix-1) ) / ixl
              aspx(ix) = aspx(ix) / ixl
              amx = max( amx, aspx(ix) )
            end do
!
            aky(1) = s0o1
            do iy = 2, iyl2(io)
              aky(iy) = ( slram * (iy-1) ) / iyl
              aspy(iy) = aspy(iy) / iyl
              amx = max( amx, aspy(iy) )
            end do
!
            akz(1) = s0o1
            do iz = 2, izl2(io)
              akz(iz) = ( slram * (iz-1) ) / izl
              aspz(iz) = aspz(iz) / izl
              amx = max( amx, aspz(iz) )
            end do
!
            do ix = 2, ixl2(io)
              aspx(ix) = aspx(ix) / amx
            end do
            do iy = 2, iyl2(io)
              aspy(iy) = aspy(iy) / amx
            end do
            do iz = 2, izl2(io)
              aspz(iz) = aspz(iz) / amx
            end do
!.
            if( iofek .le. 4 ) then
              write(iun) sstcur, io, i, akx, aky, akz, asp, aspxy, aspxz, aspyz, &
                         aspx, aspy, aspz
              flush(iun)
            end if
!.
            if( ilog .ge. 1 ) then
              do iz = 1, izl2(io)
                do iy = 1, iyl2(io)
                  do ix = 1, ixl2(io)
                    asp(ix,iy,iz) = log10( max( asp(ix,iy,iz), 1.0d-6 ) )
                  end do
                end do
              end do
              
              !aspxy,aspyz,aspxz
              
              do ix = 1, ixl2(io)
                aspx(ix) = log10( max( aspx(ix), 1.0d-6 ) )
              end do
              do iy = 1, iyl2(io)
                aspy(iy) = log10( max( aspy(iy), 1.0d-6 ) )
              end do
              do iz = 1, izl2(io)
                aspz(iz) = log10( max( aspz(iz), 1.0d-6 ) )
              end do
            end if
!..

            if( iofek .ge. 2 ) then
              if( iso+i3d .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fek', &
                           iso, i3d
                call s3ext_abort
              end if
              crange = 'range(-xx.x,-xx.x,-xx.x)(-xx.x,-xx.x,-xx.x)'
              write( crange(7:11),  '(f5.1)' ) sofekxps(io)
              write( crange(13:17), '(f5.1)' ) sofekyps(io)
              write( crange(19:23), '(f5.1)' ) sofekzps(io)
              write( crange(26:30), '(f5.1)' ) sofekxpe(io)
              write( crange(32:36), '(f5.1)' ) sofekype(io)
              write( crange(38:42), '(f5.1)' ) sofekzpe(io)
                            
        ctime = 'xxxxx.xx fsec'
        write( ctime(1:8), '(f8.2)' ) sstcur
        call fr_canvas ( ifn )
        
      av = ( aspxx+aspmn )*s1o2
      cval  = 'val = xxxx.xxx'
      do ii = 1, iso
        call fr_gclear
        call fr_project( 5.0d0, 1 )
        call fr_angle3d( 30.0d0, -30.0d0 )
        call fr_aspect3d( 1.0d0, 1.0d0, 1.0d0, 0 )
        call fr_xyzname( 'Kx/K-L', 'Ky/K-L', 'Kz/K-L' )
        call fr_frame3d( s0o1, akx(ixl2(io)), s0o1, aky(iyl2(io)), &
                         s0o1, akz(izl2(io)), 4 )
        call fr_isosurface( asp, ixl2(io), iyl2(io), izl2(io), av, i,6 )
        call fr_fpchars( 5.0d0, 15.0d0, bident, 7, 1, -1, 0, 0 )
        call fr_fpchars( 150.0d0, 15.0d0, clabel, 7, 1, -1, 0, 0 )
        call fr_fpchars( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
        write( cval(7:14), '(f8.3)' ) av
        call fr_fpchars( 5.0d0, 470.0d0, cval, 7, 1, -1, 0, 0 )
      end do
      
              call frames_body22 ( bident, sstcur, ifn, 3, 0, aspxy, &
                        ixl2(io), iyl2(io), &
                        s0o1, akx(ixl2(io)), s0o1, aky(iyl2(io)), &
                        'Kx/K-L', 'Ky/K-L', clabel, crange )
              call frames_body22 ( bident, sstcur, ifn, 3, 0, aspyz, &
                        iyl2(io), izl2(io), &
                        s0o1, aky(iyl2(io)), s0o1, akz(izl2(io)), &
                        'Ky/K-L', 'Kz/K-L', clabel, crange )
              call frames_body22 ( bident, sstcur, ifn, 3, 0, aspxz, &
                        ixl2(io), izl2(io), &
                        s0o1, akx(ixl2(io)), s0o1, aky(izl2(io)), &
                        'Kx/K-L', 'Kz/K-L', clabel, crange )
              call frames_body27 ( bident,sstcur,ifn,ilog, akx, aspx, &
                 ixl2(io), 'Kx/K-L', 'number[a.u.] ', clabel, crange )
              call frames_body27 ( bident,sstcur,ifn,ilog, aky, aspy, &
                 iyl2(io), 'Ky/K-L', 'number[a.u.] ', clabel, crange )
              call frames_body27 ( bident,sstcur,ifn,ilog, akz, aspz, &
                 izl2(io), 'Kz/K-L', 'number[a.u.] ', clabel, crange )
              
            end if
!.
          end do
!...
          deallocate( afek, afftxs1,afftxs2, afftytm,afftys1, afftys2, &
                      afftztm,afftzs1, afftzs2,akx, aky, akz, &
                      asp, aspxy, aspxz, aspyz, aspx, aspy, aspz )
        end do
!....
      else
         iofek  = mod( lofek, 10 )
         ilog   = mod( lofek/10, 10 )
         i3d    = mod( lofek/100, 10 )
         iso    = i3d / 2
         i3d    = mod( i3d, 2 )
         iofekl = mod( lofek/1000, 10 )
!....
         do io = 1, iofekl
            if( sofekxps(io) .le. sundef ) then
               ixps(io) = 1
               sofekxps(io) = ( ixps(io) - loxp0 ) * slmicinv
            else
               ixps(io) = sofekxps(io) * slmic + loxp0
            end if
            if( sofekxpe(io) .le. sundef ) then
               ixpe(io) = lssx-2
               sofekxpe(io) = ( ixpe(io) - loxp0 ) * slmicinv
            else
               ixpe(io) = sofekxpe(io) * slmic + loxp0
            end if
            if( sofekyps(io) .le. sundef ) then
               iyps(io) = 1
               sofekyps(io) = ( iyps(io) - loyp0 ) * slmicinv
            else
               iyps(io) = sofekyps(io) * slmic + loyp0
            end if
            if( sofekype(io) .le. sundef ) then
               iype(io) = lssy-2
               sofekype(io) = ( iype(io) - loyp0 ) * slmicinv
            else
               iype(io) = sofekype(io) * slmic + loyp0
            end if
            if( sofekzps(io) .le. sundef ) then
               izps(io) = 1
               sofekzps(io) = ( izps(io) - lozp0 ) * slmicinv
            else
               izps(io) = sofekzps(io) * slmic + lozp0
            end if
            if( sofekzpe(io) .le. sundef ) then
               izpe(io) = lssz-2
               sofekzpe(io) = ( izpe(io) - lozp0 ) * slmicinv
            else
               izpe(io) = sofekzpe(io) * slmic + lozp0
            end if
            ixl = ixpe(io)-ixps(io)+1
            iyl = iype(io)-iyps(io)+1
            izl = izpe(io)-izps(io)+1
            ixl2(io) = ixl / 2 - 1
            iyl2(io) = iyl / 2 - 1
            izl2(io) = izl / 2 - 1
            ikmx = sofekmax / slram * ixl + 2
            ixl2(io) = min( ixl2(io), ikmx )
            ikmx = sofekmax / slram * iyl + 2
            iyl2(io) = min( iyl2(io), ikmx )
            ikmx = sofekmax / slram * izl + 2
            izl2(io) = min( izl2(io), ikmx )
            if( lrank .le. 0 ) &
            write(6,*) '@@@ o3fek', &
               io, ixps(io),ixpe(io),iyps(io),iype(io),izps(io),izpe(io)
         end do
         if( iofek .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fek', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'fek4', bident, sofekmax, iofekl, &
                      ( ixl2(io), iyl2(io), izl2(io), io=1,iofekl ), &
                      ( sofekxps(io),sofekyps(io),sofekzps(io), &
                    sofekxpe(io),sofekype(io),sofekzpe(io),io=1,iofekl )
            flush(iun)
         end if
         if( iofek .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fek', bfile )
            call frames_file ( bfile, ifn, iofek )
         end if
!....
      end if
!....
      call fdebug ( 'o3fek', 1 )
!....
      return
      end
