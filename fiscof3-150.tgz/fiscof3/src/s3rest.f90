!----------------------------------------------------------------------
! Set 3D RESTart file i/o
!                           /      /
      subroutine s3rest ( kflag, kunit )
!
!   <arguments>
!     kflag : read = 0, write = 1
!     kunit : Fortran unit#
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/06/12
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use control
      use observe
      use profile
      use particle
      use field
      use pml
      use laserprf
      use fpprm
      include "implicit.h"
      integer :: kflag, kunit, issx, issy, issz, i, io, icll, &
                 iclflge, iclflgia, idivx, idivy, idivz, iloadbf, &
                 ipmlxl, ipmlxu, ipmlyl, ipmlyu, ipmlzl, ipmlzu
      character cident*16, cvers*10, cversr*10
      data cvers / 'fi3v1r02  ' /
      save
!....
      call fdebug ( 's3rest', 0 )
!....
      if( kflag .eq. 0 ) then
         call fntpcnv ( brestfntp, lrank,kunit, bident,'rest', bfile )
         open( kunit, file=bfile, form='UNFORMATTED', status='OLD' )
         read( kunit ) cversr, cident
         if( cversr .ne. cvers ) then
            write(0,*) '### ERROR: my version=', cvers, &
                      ', restart file version=', cversr
            call s3ext_abort
         end if
         read( kunit ) &
            issx, issy, issz, sstcur, lstcur, lopfeedc, lopfiedc, &
            lxps, lxpe, lxp0, loxp0, lyps, lype, lyp0, loyp0, &
            lzps, lzpe, lzp0, lozp0, &
            lnoe, lnoes, lnoee, lnoi, lnois, lnoie, lionspl, &
            idivx, idivy, idivz, iloadbf, &
            ipmlxl, ipmlxu, ipmlyl, ipmlyu, ipmlzl, ipmlzu
         if( issx.ne.lssx .or. issy.ne.lssy .or. issz.ne.lssz) then
            write(0,*) '### ERROR: system size mismatch',issx,issy,issz
            call s3ext_abort
         end if
         if( idivx.ne.ldivx.or.idivy.ne.ldivy.or.idivz.ne.ldivz ) then
            write(0,*) '### ERROR: division number mismatch',&
                       idivx,idivy,idivz
            call s3ext_abort
         endif
         if( ipmlxl .ne. lpmlxl .or. ipmlxu .ne. lpmlxu .or. &
             ipmlyl .ne. lpmlyl .or. ipmlyu .ne. lpmlyu .or. &
             ipmlzl .ne. lpmlzl .or. ipmlzu .ne. lpmlzu ) then
            write(0,*) '### ERROR: PML size mismatch', &
                         ipmlxl, ipmlxu, ipmlyl, ipmlyu, ipmlzl, ipmlzu
            call s3ext_abort
         end if
         if( lnoie .gt. lnox ) then
            write(0,*) '### ERROR: particle overflow', lnoe, lnoi
            call s3ext_abort
         end if
         write(6,*) '@@@ RESTART: sstcur=', sstcur, ', cident=', cident
         if( iloadbf .ne. lloadbf ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: lloadbf changed', iloadbf,lloadbf
         endif
         read( kunit ) &
            llsrbn, llsrty, llinx, lliny, llinz, llxps, llxpe, &
            lltend, lltcur, lbemty, lbemix, &
            slpwr, slramm, slomg, slram, &
            slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
            sbempw, sbemwl, sbemle, sbemwd, sbemtr, sbemmn, sbemfi, &
            sbemal, sbemxf, sbemyf, sbemzf, sbeman, sbemph, sbemdl, &
            sbemanr, sbemomg, sla, slinea, slinba, slinjy
         read( kunit ) &
            (spdat1(i),i=lnoes,lnoee), (spdat2(i),i=lnoes,lnoee), &
             spfen, spfex, spnoe
         if( lnoi .gt. 0 ) then
           read( kunit ) &
              (spdat1(i),i=lnois,lnoie), (spdat2(i),i=lnois,lnoie), &
              (lionids(i),i=1,lionspl), (lionide(i),i=1,lionspl), &
              (lionidl(i),i=1,lionspl), (spfin(i),i=1,lionspl), &
              (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
              (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
              (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
              (sionmm(i),i=1,lionspl), spnoit
         end if
         read( kunit ) &
            lcfde, lcfdi, sde, sde0, sdi, sebxyz, sjxyzt, &
            sdeyxdxy, sdezydyz, sdexzdzx, sextbx, sextby, sextbz, &
            sjxe, sjxi, sjye, sjyi, sjze, sjzi
         read( kunit ) &
            sbxyyl, sbxyyu, sbxyzl, sbxyzu, &
            sbxzyl, sbxzyu, sbxzzl, sbxzzu, &
            sbyxxl, sbyxxu, sbyxzl, sbyxzu, &
            sbyzxl, sbyzxu, sbyzzl, sbyzzu, &
            sbzxxl, sbzxxu, sbzxyl, sbzxyu, &
            sbzyxl, sbzyxu, sbzyyl, sbzyyu, &
            sexyyl, sexyyu, sexyzl, sexyzu, &
            sexzyl, sexzyu, sexzzl, sexzzu, &
            seyxxl, seyxxu, seyxzl, seyxzu, &
            seyzxl, seyzxu, seyzzl, seyzzu, &
            sezxxl, sezxxu, sezxyl, sezxyu, &
            sezyxl, sezyxu, sezyyl, sezyyu 
         read( kunit ) iclflge
         if( iclflge .gt. 0 ) then
            icll = iclflge / 10
            lclflge = - iclflge
            read( kunit ) &
               (sclboe(:,i),i=1,icll), &
               (scluure(i),i=1,icll), (scluule(i),i=1,icll), &
               (scluu0e(i),i=1,icll), (sclfcte(i),i=1,icll)
         end if
         if( lnoi .gt. 0 ) then
           read( kunit ) iclflgia
           if( iclflgia .gt. 0 ) then
             lclflgia = - iclflgia
             do io = 1, lionspl
               read( kunit ) lclflgi(io)
               if( lclflgi(io) .gt. 0 ) then
                 icll = lclflgi(io) / 10
                 read( kunit ) &
                  (sclboi(:,i,io),i=1,icll), &
                  (scluuri(i,io),i=1,icll), (scluuli(i,io),i=1,icll), &
                  (scluu0i(i,io),i=1,icll), (sclfcti(i,io),i=1,icll)
               end if
             end do
           end if
         end if
         close( kunit )
!....
      else
         call fntpcnv ( brestfntp, lrank,kunit, bident,'rest', bfile )
         open( kunit, file=bfile, form='UNFORMATTED' )
         write( kunit ) cvers, bident
         write( kunit ) &
            lssx, lssy, lssz, sstcur, lstcur, lopfeedc, lopfiedc, &
            lxps, lxpe, lxp0, loxp0, lyps, lype, lyp0, loyp0, &
            lzps, lzpe, lzp0, lozp0,&
            lnoe, lnoes, lnoee, lnoi, lnois, lnoie, lionspl, &
            ldivx, ldivy, ldivz, lloadbf, &
            lpmlxl, lpmlxu, lpmlyl, lpmlyu, lpmlzl, lpmlzu
         write( kunit ) &
            llsrbn, llsrty, llinx, lliny, llinz, llxps, llxpe, &
            lltend, lltcur, lbemty, lbemix, &
            slpwr, slramm, slomg, slram, &
            slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
            sbempw, sbemwl, sbemle, sbemwd, sbemtr, sbemmn, sbemfi, &
            sbemal, sbemxf, sbemyf, sbemzf, sbeman, sbemph, sbemdl, &
            sbemanr, sbemomg, sla, slinea, slinba, slinjy
         write( kunit ) &
            (spdat1(i),i=lnoes,lnoee), (spdat2(i),i=lnoes,lnoee), &
             spfen, spfex, spnoe
         if( lnoi .gt. 0 ) then
           write( kunit ) &
            (spdat1(i),i=lnois,lnoie), (spdat2(i),i=lnois,lnoie), &
            (lionids(i),i=1,lionspl), (lionide(i),i=1,lionspl), &
            (lionidl(i),i=1,lionspl), (spfin(i),i=1,lionspl), &
            (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
            (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
            (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
            (sionmm(i),i=1,lionspl), spnoit
         end if
         write( kunit ) &
            lcfde, lcfdi, sde, sde0, sdi, sebxyz, sjxyzt, &
            sdeyxdxy, sdezydyz, sdexzdzx, sextbx, sextby, sextbz, &
            sjxe, sjxi, sjye, sjyi, sjze, sjzi
         write( kunit ) &
            sbxyyl, sbxyyu, sbxyzl, sbxyzu, &
            sbxzyl, sbxzyu, sbxzzl, sbxzzu, &
            sbyxxl, sbyxxu, sbyxzl, sbyxzu, &
            sbyzxl, sbyzxu, sbyzzl, sbyzzu, &
            sbzxxl, sbzxxu, sbzxyl, sbzxyu, &
            sbzyxl, sbzyxu, sbzyyl, sbzyyu, &
            sexyyl, sexyyu, sexyzl, sexyzu, &
            sexzyl, sexzyu, sexzzl, sexzzu, &
            seyxxl, seyxxu, seyxzl, seyxzu, &
            seyzxl, seyzxu, seyzzl, seyzzu, &
            sezxxl, sezxxu, sezxyl, sezxyu, &
            sezyxl, sezyxu, sezyyl, sezyyu 
         write( kunit ) lclflge
         if( lclflge .gt. 0 ) then
            icll = lclflge / 10
            write( kunit ) &
               (sclboe(:,i),i=1,icll), &
               (scluure(i),i=1,icll), (scluule(i),i=1,icll), &
               (scluu0e(i),i=1,icll), (sclfcte(i),i=1,icll)
         end if
         if( lnoi .gt. 0 ) then
           write( kunit ) lclflgia
           if( lclflgia .gt. 0 ) then
             do io = 1, lionspl
               write( kunit ) lclflgi(io)
               if( lclflgi(io) .gt. 0 ) then
                 icll = lclflgi(io) / 10
                 write( kunit ) &
                  (sclboi(:,i,io),i=1,icll), &
                  (scluuri(i,io),i=1,icll), (scluuli(i,io),i=1,icll), &
                  (scluu0i(i,io),i=1,icll), (sclfcti(i,io),i=1,icll)
               end if
             end do
           end if
         end if
         flush( kunit )
         close( kunit )
      end if
!....
      call fdebug ( 's3rest', 1 )
!....
      return
      end
