!-----------------------------------------------------------------------
! Advance 3D Particle Ion Position ( full step )
!
      subroutine a3pip
!
!   <arguments>
!     none
!
!   <remarks>
!     always save data
!
!    coded by Sakagami,H. (NIFS) 20/11/11
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      save
!....
      call fdebug( 'a3pip',0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do i = lnois, lnoie
         sxio(i) = sxi(i)
         syio(i) = syi(i)
         szio(i) = szi(i)
         sxi(i)  = sxi(i) + svxi(i)
         syi(i)  = syi(i) + svyi(i)
         szi(i)  = szi(i) + svzi(i)
      end do
!....
      call fdebug( 'a3pip', 1 )
!....
      return
      end
