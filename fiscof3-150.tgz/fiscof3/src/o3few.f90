!----------------------------------------------------------------------
! Observe 3D Field Electric W (Omega) frequency spectrum
!                          /
      subroutine o3few ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output (last)
!                  2 = add and output if full
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/06/02
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use laserprf
      use field
      use observe
      include "implicit.h"
      integer :: kflag, i, ii, iii, ix, iy, iz, iofew, iofewl, icnt
      integer, parameter :: iun = 39
      real*8  :: wdelt
      real*8, allocatable :: wfew(:,:,:)
      save
!....
      call fdebug ( 'o3few', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         if( kflag .eq. 1 .or. icnt .eq. ltimex ) then
            if( iofew .le. 4 ) then
               write(iun) sstcur, kflag, icnt, &
               (  ( ( wfew(iii,ii,i),iii=1,3),ii=1,icnt),i=1,iofewl)
               flush(iun)
            end if
            icnt = 0
         end if
!..
         if( kflag .ge. 2 ) then
            icnt = icnt + 1
            do i = 1, iofewl
               ix = sofewxp(i) * slmic + loxp0
               iy = sofewyp(i) * slmic + loyp0
               iz = sofewzp(i) * slmic + lozp0
               wfew(1,icnt,i) = ( sex(ix,iy+1,iz) + sex(ix,iy,iz) )*s1o2
               wfew(2,icnt,i) = ( sey(ix+1,iy,iz) + sey(ix,iy,iz) )*s1o2
               wfew(3,icnt,i) = ( sez(ix,iy,iz+1) + sez(ix,iy,iz) )*s1o2
            end do
         end if
!....
      else
         iofew  = mod( lofew, 10 )
         iofewl = lofew/100
!..
         do i = 1, iofewl
            ix = sofewxp(i) * slmic + loxp0
            iy = sofewyp(i) * slmic + loyp0
            iz = sofewzp(i) * slmic + lozp0
            write(6,*) '@@@ o3few', i, ix, iy, iz
         end do
         if( iofewl .gt. 0 ) then
           if( .not. allocated(wfew) ) allocate( wfew(3,ltimex,iofewl) )
         end if
!..
         if( iofew .le. 4 ) then
            wdelt = s2pi / ( sdelt * slomg )
            call fntpcnv ( bbifntp, lrank, iun, bident,'few', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'few4', bident, wdelt, iofewl, &
                     (sofewxp(i), sofewyp(i), sofewzp(i), i=1,iofewl)
            flush(iun)
         end if
!..
         icnt = 0
      end if
!....
      call fdebug ( 'o3few', 1 )
!....
      return
      end
