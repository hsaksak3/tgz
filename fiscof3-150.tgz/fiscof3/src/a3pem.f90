!-----------------------------------------------------------------------
! Advance 3D Particle Electron Momentum
!
      subroutine a3pem
!
!   <arguments>
!    none
!
!   <remarks>
!    none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i
      save
!....
      call fdebug ( 'a3pem', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do i = lnoes, lnoee
         suxe(i) = suxe(i) + sfxe(i)
         suye(i) = suye(i) + sfye(i)
         suze(i) = suze(i) + sfze(i)
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
!....
      call fdebug( 'a3pem', 1 )
!....
      return
      end
