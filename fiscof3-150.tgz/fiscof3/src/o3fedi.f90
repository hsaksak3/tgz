!----------------------------------------------------------------------
! Observe 3D Field Energy Density Ion
!                           /
      subroutine o3fedi ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 12/05/30
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 37, ifn = 18
      integer :: kflag, is, iofedi, i3d, icrxy, icryz, icrxz, &
                 i, ix, iy, iz
      real*8, allocatable :: wfedi(:,:,:,:)
      character*20 clabel
      save
!....
      call fdebug ( 'o3fedi', 0 )
!....
      if( kflag .ge. 1 ) then
       if( loxyzpl .gt. 0 ) then
!...
         wfedi(:,:,:,:) = s0o1
!..
         do is = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wfedi), &
!$OMP          PRIVATE(ix,iy,iz)
           do i = lionids(is), lionide(is)
              ix = sxi(i) + s1o2
              iy = syi(i) + s1o2
              iz = szi(i) + s1o2
  !
              if( ix .lt. loxps .or. ix .gt. loxpe ) cycle
              if( iy .lt. loyps .or. iy .gt. loype ) cycle
              if( iz .lt. lozps .or. iz .gt. lozpe ) cycle
              if( mod(ix-loxps,loxpi) .ne. 0 ) cycle
              if( mod(iy-loyps,loypi) .ne. 0 ) cycle
              if( mod(iz-lozps,lozpi) .ne. 0 ) cycle
  !
              ix = ( ix - loxps ) / loxpi + 1
              iy = ( iy - loyps ) / loypi + 1
              iz = ( iz - lozps ) / lozpi + 1
              wfedi(ix,iy,iz,is) = wfedi(ix,iy,iz,is) +  &
                      ( sqrt( s1o1+suui(i)**2*scg1 ) - s1o1 ) * spfi(i)
           end do
         end do
!..
         do is = 1, lionspl
            wfedi(:,:,:,is) = wfedi(:,:,:,is) / snepm1 * sionmm(is)
         end do
!..
         if( iofedi .le. 4 ) then
            write(iun) sstcur, wfedi(:,:,:,:)
            flush(iun)
         end if

         if( iofedi .ge. 2 ) then
            do is = 1, lionspl
               call o3ionlabel ( is, sionam(is), sionaz(is), clabel )
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, 0, i3d, 0, 1, & 
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wfedi(1,1,1,is), loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fedi'//clabel ) 
            end do
         end if
       end if
!....
      else
!....
         iofedi = mod( lofedi, 10 )
         i3d    = mod( lofedi/100, 10 )
         icrxy  = mod( lofedi/1000, 10 )
         icryz  = mod( lofedi/10000, 10 )
         icrxz  = mod( lofedi/100000, 10 )
!.
         if( iofedi .ge. 2 ) then
           if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
             write(0,*) '### ERROR: no plot for fedi', & 
                        i3d, icrxy, icryz, icrxz
             call s3ext_abort
           end if
         end if
!....
         if( loxyzpl .gt. 0 ) then
            if( .not. allocated(wfedi) ) &
               allocate( wfedi(loxpl,loypl,lozpl,lionspl) )
         end if
!...
         if( iofedi .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fEi', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'fEi4', bident, loxyzpl, loxpl, loypl, lozpl, &
                     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                      lionspl, (sionam(is),sionaz(is),is=1,lionspl)
            flush(iun)
         end if
         if( iofedi .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fEi', bfile )
            call frames_file ( bfile, ifn, iofedi )
         end if
      end if
!....
      call fdebug ( 'o3fedi', 1 )
!....
      return
      end
