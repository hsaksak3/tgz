!----------------------------------------------------------------------
! field
!
module field
      integer :: lcfde, lcfdi
      real*8, allocatable, save :: &
        sde0(:,:,:), sdi(:,:,:,:), &
        sdeo(:,:,:), sdio(:,:,:,:)
      real*8, allocatable, save :: &
        sde(:,:,:), &
        sebxyz(:,:,:,:), sjxyzt(:,:,:,:), &
        sdeyxdxy(:,:,:), sdezydyz(:,:,:), sdexzdzx(:,:,:), &
        sjxe(:,:,:), sjxi(:,:,:,:), sjye(:,:,:), sjyi(:,:,:,:), &
        sjze(:,:,:), sjzi(:,:,:,:)
end module field
