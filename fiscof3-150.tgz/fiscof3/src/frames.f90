!----------------------------------------------------------------------
! frames interface routines
!
module frames_interface
   use parameter, only:locrsx
   integer, parameter :: lfrbx=65536
   integer :: ndiv(3), lcrsf1(locrsx), lcrsf2(locrsx)
   real*8 :: sfrbuf(lfrbx)
   real*8 :: sh(4), sl(4), ss(4)
end module frames_interface
!----------------------
      subroutine frames_init
      use frames_interface
!....
      call fr_ginit
!....
      sh(1) = 0.0d0
      sl(1) = 0.02d0
      ss(1) = 1.0d0
      ndiv(1) = 40
      sh(2) = 0.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 50
      sh(3) = 60.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 40
      sh(4) = 60.0d0
      sl(4) = 0.98d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!
      sh(1) = 180.0d0
      sl(1) = 0.9d0
      ss(1) = 1.0d0
      ndiv(1) = 60
      sh(2) = 240.0d0
      sl(2) = 0.1d0
      ss(2) = 1.0d0
      ndiv(2) = 10
      sh(3) = 360.0d0
      sl(3) = 0.1d0
      ss(3) = 1.0d0
      ndiv(3) = 60
      sh(4) = 390.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!
      sh(1) = 240.0d0
      sl(1) = 0.25d0
      ss(1) = 1.0d0
      ndiv(1) = 20
      sh(2) = 240.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 90
      sh(3) = 0.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 20
      sh(4) = 0.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!....
      return
      end
!----------------------
      subroutine frames_term
!.
      call fr_gend
!.
      return
      end
!----------------------
      subroutine frames_file ( efile, kcan, kmode )
      include "implicit.h"
      integer :: kcan, kmode, imode, iplt, igif
      character*(*) efile
!.....
      imode = mod( kmode-2,3 ) + 1
      iplt = mod( imode,2 )
      igif = imode / 2
      imode = 200*igif + iplt*10
!..
      call fr_opencanvas( kcan, efile, imode )
!....
      return
      end
!----------------------
      subroutine frames_body31( eident, ftime, knum, kcol, &
                                fdata,kx,ky,kz, ftd, knu, &
                             fxmic,fx0m,fymic,fy0m,fzmic,fz0m, etitle )
      use frames_interface
      include "implicit.h"
      integer :: knum, kcol, kx, ky, kz, knu(3)
      real*8  :: ftime, fdata(kx,ky,kz), ftd(3), &
                 fxmic, fx0m, fymic, fy0m, fzmic, fz0m, &
                 axm, axx, aym, ayx, azm, azx
      character*16 ctime, eident
      character*(*) etitle
!....
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      axm = - fx0m
      axx = fxmic * (kx-1) - fx0m
      aym = - fy0m
      ayx = fymic * (ky-1) - fy0m
      azm = - fz0m
      azx = fzmic * (kz-1) - fz0m
!.
      call fr_canvas ( knum )
!.
      call fr_gclear
      call fr_project( 5.0d0, 1 )
      call fr_angle3d( 30.0d0, -30.0d0 )
      call fr_aspect3d( 1.0d0, 1.0d0, 1.0d0, 0 )
      call fr_xyzname( 'x[micron]', 'y[micron]', 'z[micron]' )
      call fr_frame3d( axm, axx, aym, ayx, azm, azx, 4 )
      call fr_hlsrecall( kcol )
      call fr_slices( fdata, kx, ky, kz, ftd, knu, 1, -2, 0 ) 
      call fr_colorbar( 550, 200, 20, 200, 2 )
      call fr_fpchars( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body32( eident, ftime, knum, kcol, &
                                fdata,kx,ky,kz, kaxis,kcrs,fcrs, &
                             fxmic,fx0m,fymic,fy0m,fzmic,fz0m, etitle )
      use frames_interface
      include "implicit.h"
      integer :: knum, kcol, kx, ky, kz, kaxis, kcrs, &
                 ix, iy, iz, in, ixl, iyl, icrs
      real*8  :: ftime, fdata(kx,ky,kz), fcrs(kcrs), &
                 fxmic, fx0m, fymic, fy0m, fzmic, fz0m, &
                 axm, axx, aym, ayx, aw1, aw2
      character*16 ctime, cxname, cyname, czval*20, eident
      character*(*) etitle
!....
      select case( kaxis )
      case( 1 )
         ixl = kx
         iyl = ky
         axm = - fx0m
         axx = fxmic * (ixl-1) - fx0m
         aym = - fy0m
         ayx = fymic * (iyl-1) - fy0m
         cxname = 'x[micron]'
         cyname = 'y[micron]'
         czval = 'z=xxxxx.xx [micron]'
      case( 2 )
         ixl = ky
         iyl = kz
         axm = - fy0m
         axx = fymic * (ixl-1) - fy0m
         aym = - fz0m
         ayx = fzmic * (iyl-1) - fz0m
         cxname = 'y[micron]'
         cyname = 'z[micron]'
         czval = 'x=xxxxx.xx [micron]'
      case( 3 )
         ixl = kx
         iyl = kz
         axm = - fx0m
         axx = fxmic * (ixl-1) - fx0m
         aym = - fz0m
         ayx = fzmic * (iyl-1) - fz0m
         cxname = 'x[micron]'
         cyname = 'z[micron]'
         czval = 'y=xxxxx.xx [micron]'
      case default
         write(0,*) '### [frames_body32] invalid kaxis :', kaxis
         go to 999
      end select
!++++
      if( ixl*iyl .gt. lfrbx ) then
         write(0,*) '### [frames_body32] data overflow :',ixl*iyl,lfrbx
         go to 999
      end if
!++++
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!.
      call fr_canvas ( knum )
!.
      do icrs = 1, kcrs
        select case( kaxis )
        case( 1 )
          iz = ( fcrs(icrs) + fz0m ) / fzmic + 1
          if( iz .lt. 1 .or. iz+1 .gt. kz ) cycle
          aw1 = fcrs(icrs) - ( (iz-1)*fzmic - fz0m )
          aw2 = fzmic - aw1
          in = 0
          do iy = 1, iyl
            do ix = 1, ixl
              in = in + 1
              sfrbuf(in) = ( fdata(ix,iy,iz  ) * aw2 + &
                             fdata(ix,iy,iz+1) * aw1 ) / fzmic
            end do
          end do
        case( 2 )
          ix = ( fcrs(icrs) + fx0m ) / fxmic + 1
          if( ix .lt. 1 .or. ix+1 .gt. kx ) cycle
          aw1 = fcrs(icrs) - ( (ix-1)*fxmic - fx0m )
          aw2 = fxmic - aw1
          in = 0
          do iz = 1, iyl
            do iy = 1, ixl
              in = in + 1
              sfrbuf(in) = ( fdata(ix,iy,iz  ) * aw2 + &
                             fdata(ix+1,iy,iz) * aw1 ) / fxmic
            end do
          end do
        case( 3 )
          iy = ( fcrs(icrs) + fy0m ) / fymic + 1
          if( iy .lt. 1 .or. iy+1 .gt. ky ) cycle
          aw1 = fcrs(icrs) - ( (iy-1)*fymic - fy0m )
          aw2 = fymic - aw1
          in = 0
          do iz = 1, iyl
            do ix = 1, ixl
              in = in + 1
              sfrbuf(in) = ( fdata(ix,iy,iz  ) * aw2 + &
                             fdata(ix,iy+1,iz) * aw1 ) / fymic
            end do
          end do
        end select
        call fr_gclear
        call fr_aspect2d( 1.0d0, 1.0d0, 0 )
        call fr_frame2d( axm, axx, aym, ayx, 3 )
        call fr_hlsrecall( kcol )
        call fr_contour( sfrbuf, ixl, iyl, 1, -2 )
        call fr_xyname( cxname, cyname )
        call fr_colorbar( 350, 475, 200, 15, 2 )
        call fr_fpchars( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
        call fr_fpchars( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
        call fr_fpchars( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
        write( czval(3:10), '(f8.2)' ) fcrs(icrs)
        call fr_fpchars( 5.0d0, 470.0d0, czval, 7, 1, -1, 0, 0 )
      end do
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body33( eident, ftime, knum, &
                                fdata,kx,ky,kz, fv, kv, &
                             fxmic,fx0m,fymic,fy0m,fzmic,fz0m, etitle )
      use frames_interface
      include "implicit.h"
      integer :: i, knum, kx, ky, kz, kv
      real*8  :: ftime, fdata(kx,ky,kz), fv(kv), &
                 fxmic, fx0m, fymic, fy0m, fzmic, fz0m, &
                 axm, axx, aym, ayx, azm, azx
      character*16 ctime, cval, eident
      character*(*) etitle
!....
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      axm = - fx0m
      axx = fxmic * (kx-1) - fx0m
      aym = - fy0m
      ayx = fymic * (ky-1) - fy0m
      azm = - fz0m
      azx = fzmic * (kz-1) - fz0m
      cval  = 'val = xxxx.xxx'
!.
      call fr_canvas ( knum )
!.
      do i = 1, kv
        call fr_gclear
        call fr_project( 5.0d0, 1 )
        call fr_angle3d( 30.0d0, -30.0d0 )
        call fr_aspect3d( 1.0d0, 1.0d0, 1.0d0, 0 )
        call fr_xyzname( 'x[micron]', 'y[micron]', 'z[micron]' )
        call fr_frame3d( axm, axx, aym, ayx, azm, azx, 4 )
        call fr_isosurface( fdata, kx, ky, kz, fv(i), i, 6 )
        call fr_fpchars( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
        call fr_fpchars( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
        call fr_fpchars( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
        write( cval(7:14), '(f8.3)' ) fv(i)
        call fr_fpchars( 5.0d0, 470.0d0, cval, 7, 1, -1, 0, 0 )
      end do
!.
      return
      end
!----------------------
      subroutine frames_body34( eident, ftime, knum, klog, &
                        fdata,kx,ky,kz, kaxis,kcrs1,fcrs1,kcrs2,fcrs2, &
                             fxmic,fx0m,fymic,fy0m,fzmic,fz0m, etitle )
      use frames_interface
      include "implicit.h"
      integer :: knum, klog, kx, ky, kz, kaxis, kcrs1, kcrs2, &
                 i, i1, i2, ix, iy, iz, il, is, icrs1, icrs2, ii, icol
      real*8  :: ftime, fdata(kx,ky,kz), fcrs1(kcrs1), fcrs2(kcrs2),&
                 fxmic, fx0m, fymic, fy0m, fzmic, fz0m, &
                 aym, ayx, ayv
      character*16 ctime, cname, cval1*20, cval2*20, eident
      character*(*) etitle
!....
      select case( kaxis )
      case( 1 )
         il = kx
         cname = 'x[micron]'
         cval1 = 'y=xxxxx.xx [micron]'
         cval2 = 'z=xxxxx.xx [micron]'
      case( 2 )
         il = ky
         cname = 'y[micron]'
         cval1 = 'x=xxxxx.xx [micron]'
         cval2 = 'z=xxxxx.xx [micron]'
      case( 3 )
         il = kz
         cname = 'z[micron]'
         cval1 = 'x=xxxxx.xx [micron]'
         cval2 = 'y=xxxxx.xx [micron]'
      case default
         write(0,*) '### [frames_body34] invalid kaxis :', kaxis
         go to 999
      end select
!++++
      if( il*kcrs1*kcrs2 .gt. lfrbx ) then
         write(0,*) '### [frames_body34] data overflow :', &
                    il,kcrs1,kcrs2,lfrbx
         go to 999
      end if
!++++
!....
      lcrsf1(1:kcrs1) = 0
      lcrsf2(1:kcrs2) = 0
!..
      select case( kaxis )
      case( 1 )
         do i = 1, il
           sfrbuf(i) = (i-1) * fxmic - fx0m
         end do
         aym = 1.0d30
         ayx = -1.0d30
         is = 0
         do i2 = 1, kcrs2
           iz = ( fcrs2(i2) + fz0m ) / fzmic + 1.5
           if( iz .lt. 1 .or. iz .gt. kz ) then
             lcrsf2(i2) = 1
             cycle
           end if
           do i1 = 1, kcrs1
             iy = ( fcrs1(i1) + fy0m ) / fymic + 1.5
             if( iy .lt. 1 .or. iy .gt. ky ) then
               lcrsf1(i1) = 1
               cycle
             end if
             is = is + il
             do i = 1, il
               ayv = fdata(i,iy,iz)
               aym = min( aym, ayv )
               ayx = max( ayx, ayv )
               sfrbuf(i+is) = ayv
             end do
           end do
         end do
      case( 2 )
         do i = 1, il
           sfrbuf(i) = (i-1) * fymic - fy0m
         end do
         aym = 1.0d30
         ayx = -1.0d30
         is = 0
         do i2 = 1, kcrs2
           iz = ( fcrs2(i2) + fz0m ) / fzmic + 1.5
           if( iz .lt. 1 .or. iz .gt. kz ) then
             lcrsf2(i2) = 1
             cycle
           end if
           do i1 = 1, kcrs1
             ix = ( fcrs1(i1) + fx0m ) / fxmic + 1.5
             if( ix .lt. 1 .or. ix .gt. kx ) then
               lcrsf1(i1) = 1
               cycle
             end if
             is = is + il
             do i = 1, il
               ayv = fdata(ix,i,iz)
               aym = min( aym, ayv )
               ayx = max( ayx, ayv )
               sfrbuf(i+is) = ayv
             end do
           end do
         end do
      case( 3 )
         do i = 1, il
           sfrbuf(i) = (i-1) * fzmic - fz0m
         end do
         aym = 1.0d30
         ayx = -1.0d30
         is = 0
         do i2 = 1, kcrs2
           iy = ( fcrs2(i2) + fy0m ) / fymic + 1.5
           if( iy .lt. 1 .or. iy .gt. ky ) then
             lcrsf2(i2) = 1
             cycle
           end if
           do i1 = 1, kcrs1
             ix = ( fcrs1(i1) + fx0m ) / fxmic + 1.5
             if( ix .lt. 1 .or. ix .gt. kx ) then
               lcrsf1(i1) = 1
               cycle
             end if
             is = is + il
             do i = 1, il
               ayv = fdata(ix,iy,i)
               aym = min( aym, ayv )
               ayx = max( ayx, ayv )
               sfrbuf(i+is) = ayv
             end do
           end do
         end do
      end select
      if( aym .ge. 0.9d30 ) aym = 0.0d0
      if( ayx .le. -0.9d30 ) ayx = 0.0d0
      if( abs(aym) .le. 1.0d-35 ) aym = 0.0d0
      if( abs(ayx) .le. 1.0d-35 ) ayx = 0.0d0
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         aym = floor(aym)
         ayx = floor(ayx) + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d( sfrbuf(1), sfrbuf(il), aym, ayx, 3 )
!.
      is = 0
      ii = 0
      do i2 = 1, kcrs2
        if( lcrsf2(i2) .eq. 1 ) then
           ii = ii + kcrs1
           cycle
        end if
        write( cval2(3:10), '(f8.2)' ) fcrs2(i2)
        do i1 = 1, kcrs1
          ii = ii + 1
          if( lcrsf1(i1) .eq. 1 ) cycle
          write( cval1(3:10), '(f8.2)' ) fcrs1(i1)
          is = is + il
          icol = mod( ii+1, 6 ) + 1
          ix = real( il-1 ) / (kcrs1*kcrs2) * ( ii-0.5 )
          call fr_graph2d ( sfrbuf(1), sfrbuf(1+is), il, icol, 1 )
          call fr_fpchars( sfrbuf(1+ix),sfrbuf(1+is+ix),cval1,icol,0,-1,0,100 )
          call fr_fpchars( sfrbuf(1+ix),sfrbuf(1+is+ix),cval2,icol,0,1,0,100 )
        end do
      end do
      call fr_xyname( cname, etitle )
      call fr_fpchars( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body22 ( eident, ftime, knum, kcol, kas, &
                                fdata,kx,ky, fxm, fxx, fym, fyx, &
                                exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer :: knum, kcol, kas, kx, ky
      real*8  :: ftime, fdata(kx,ky), fxm, fxx, fym, fyx
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, kas )
      call fr_frame2d ( fxm, fxx, fym, fyx, 3 )
      call fr_hlsrecall ( kcol )
      call fr_contour ( fdata, kx, ky, 1, -2 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_colorbar ( 400, 475, 200, 15, 2 )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body24 ( eident, ftime, knum, klog, fdata, kl, &
                                ffct, exaxis, eyaxis, etitle, erange )
      use frames_interface
      include "implicit.h"
      integer :: knum, klog, kl, i, icol
      real*8  :: ftime, fdata(kl), ffct, amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!....
      if( kl .gt. lfrbx ) then
         write(0,*) '### [frames_body24] data overflow :', kl, lfrbx
         go to 999
      end if
!....
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!     icol = mod( knum-1, 6 ) + 1
      icol = 2
      amin = 1.0d30
      amax = -1.0d30
      do i = 1, kl
         sfrbuf(i) = ( i - ( (kl-1)/2 + 1 ) ) / ffct
         amin = min( amin, fdata(i) )
         amax = max( amax, fdata(i) )
      end do
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         amin = floor(amin)
         amax = floor(amax) + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( sfrbuf(1), sfrbuf(kl), amin, amax, 3 )
      call fr_graph2d ( sfrbuf, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body27 ( eident, ftime, knum, klog, fx,fdata, &
                                 kl, exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer :: knum, klog, kl, i, icol, imin, imax
      real*8  :: ftime, fx(kl), fdata(kl), amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!     icol = mod( knum-1, 6 ) + 1
      icol = 2
      amin = 0.0d0
      amax = 1.0d0
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         amin = -6.0d0
         amax = 0.0d0
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( fx(1), fx(kl), amin, amax, 3 )
      call fr_graph2d ( fx, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body28 ( eident, ftime, knum, klog, fdata, kl, &
                                ffct, exaxis, eyaxis, etitle, erange )
      use frames_interface
      include "implicit.h"
      integer :: knum, klog, kl, i, icol
      real*8  :: ftime, fdata(kl), ffct, amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      if( kl .gt. lfrbx ) then
         write(0,*) '### [frames_body28] data overflow :', kl, lfrbx
         go to 999
      end if  
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime 
!     icol = mod( knum-1, 6 ) + 1 
      icol = 2
      amin = 1.0d30
      amax = -1.0d30 
      do i = 1, kl 
         sfrbuf(i) = ( i - 1 ) / ffct
         amin = min( amin, fdata(i) )
         amax = max( amax, fdata(i) )
      end do  
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0 
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0 
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         amin = floor(amin)
         amax = floor(amax) + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( sfrbuf(1), sfrbuf(kl), amin, amax, 3 )
      call fr_graph2d ( sfrbuf, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
