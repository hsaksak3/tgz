!----------------------------------------------------------------------
! Observe 3D Particle Electron PHase space
!                           /
      subroutine o3peph ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     This routine does not average the value, so always alloc/dealloc
!    arrays to save the memory.
!
! modified by Sakagami,H. ( NIFS ) 15/11/27 to include in fiscof2
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use observe
      use particle
      use profile
      include "implicit.h"
      integer :: kflag, i, io, ix, iy, iopeph, ilog, iopephl
      integer, parameter :: lgphxx = 100, lgphux = 50
      integer, parameter :: iun = 40, ifn = 20
      real*8  :: wopephxps(lopephx), wopephxpe(lopephx), &
                 wopephyps(lopephx), wopephype(lopephx), &
                 wopephzps(lopephx), wopephzpe(lopephx), &
                 wopephuxm(lopephx), wopephuxx(lopephx), &
                 wopephxpr(lopephx), wopephuxr(lopephx), &
                 wopephuym(lopephx), wopephuyx(lopephx), &
                 wopephuyr(lopephx), &
                 wopephuzm(lopephx), wopephuzx(lopephx), &
                 wopephuzr(lopephx)
      real*8, allocatable :: &
                 apephxn(:,:,:), apephyn(:,:,:), apephzn(:,:,:)
      save

      call fdebug ( 'o3peph', 0 )

      if( kflag .ge. 1 ) then
        allocate( apephxn(lgphxx,lgphux,iopephl), &
                  apephyn(lgphxx,lgphux,iopephl), &
                  apephzn(lgphxx,lgphux,iopephl) )

        apephxn(:,:,:) = s0o1
        apephyn(:,:,:) = s0o1
        apephzn(:,:,:) = s0o1

!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP     REDUCTION(+:apephxn, apephyn, apephzn), PRIVATE(io,ix,iy)
        do i = lnoes, lnoee
           do io = 1, iopephl
              if( sxe(i).lt.sopephxps(io) .or. &
                  sxe(i).gt.sopephxpe(io) ) cycle
              if( sye(i).lt.sopephyps(io) .or. &
                  sye(i).gt.sopephype(io) ) cycle
              if( sze(i).lt.sopephzps(io) .or. &
                  sze(i).gt.sopephzpe(io) ) cycle

              ix = ( sxe(i) - sopephxps(io) ) / &
                         ( sopephxpe(io) - sopephxps(io) ) * lgphxx + 1
              ix = max( ix, 1 )
              ix = min( ix, lgphxx )

              if( suxe(i).ge.sopephuxm(io) .and. &
                  suxe(i).le.sopephuxx(io) ) then
                 iy = ( suxe(i) - sopephuxm(io) ) / &
                         ( sopephuxx(io) - sopephuxm(io) ) * lgphux + 1
                 iy = max( iy, 1 )
                 iy = min( iy, lgphux )
                 apephxn(ix,iy,io) = apephxn(ix,iy,io) + spfe(i) / &
                                     ( wopephxpr(io) * wopephuxr(io) )
              end if
!
              if( suye(i).ge.sopephuym(io) .and. &
                  suye(i).le.sopephuyx(io) ) then
                 iy = ( suye(i) - sopephuym(io) ) / &
                         ( sopephuyx(io) - sopephuym(io) ) * lgphux + 1
                 iy = max( iy, 1 )
                 iy = min( iy, lgphux )
                 apephyn(ix,iy,io) = apephyn(ix,iy,io) + spfe(i) / &
                                     ( wopephxpr(io) * wopephuyr(io) )
              end if
!
              if( suze(i).ge.sopephuzm(io) .and. &
                  suze(i).le.sopephuzx(io) ) then
                 iy = ( suze(i) - sopephuzm(io) ) / &
                         ( sopephuzx(io) - sopephuzm(io) ) * lgphux + 1
                 iy = max( iy, 1 )
                 iy = min( iy, lgphux )
                 apephzn(ix,iy,io) = apephzn(ix,iy,io) + spfe(i) / &
                                     ( wopephxpr(io) * wopephuzr(io) )
              end if
           end do
        end do

        if( iopeph .le. 4 ) then
           write(iun) sstcur, apephxn, apephyn, apephzn
           flush(iun)
        end if

        if( iopeph .ge. 2 ) then
           do io = 1, iopephl
              call o3pdrawph ( bident, sstcur, sminlog, lminlog, &
                        ifn, ilog, 3, apephxn(1,1,io), lgphxx, lgphux, &
                        wopephxps(io), wopephyps(io), wopephzps(io), &
                        wopephxpe(io), wopephype(io), wopephzpe(io), &
                        wopephuxm(io), wopephuxx(io), &
                        'x[micron]', 'Ux/c', 'peph' )
              call o3pdrawph ( bident, sstcur, sminlog, lminlog, &
                        ifn, ilog, 3, apephyn(1,1,io), lgphxx, lgphux, &
                        wopephxps(io), wopephyps(io), wopephzps(io), &
                        wopephxpe(io), wopephype(io), wopephzpe(io), &
                        wopephuym(io), wopephuyx(io), &
                        'x[micron]', 'Uy/c', 'peph' )
              call o3pdrawph ( bident, sstcur, sminlog, lminlog, &
                        ifn, ilog, 3, apephzn(1,1,io), lgphxx, lgphux, &
                        wopephxps(io), wopephyps(io), wopephzps(io), &
                        wopephxpe(io), wopephype(io), wopephzpe(io), &
                        wopephuzm(io), wopephuzx(io), &
                        'x[micron]', 'Uz/c', 'peph' )

!
           end do
        end if

        deallocate( apephxn, apephyn, apephzn )

      else
        iopeph  = mod( lopeph, 10 )
        ilog    = mod( lopeph/10, 10 )
        iopephl = lopeph/100

        do io = 1, iopephl
           if( sopephxps(io) .le. sundef ) then
               sopephxps(io) = lxps
           else
               sopephxps(io) = sopephxps(io) * slmic + loxp0
           end if
           if( sopephxpe(io) .le. sundef ) then
               sopephxpe(io) = lxpe
           else
               sopephxpe(io) = sopephxpe(io) * slmic + loxp0
           end if
           if( sopephyps(io) .le. sundef ) then
               sopephyps(io) = lyps
           else
               sopephyps(io) = sopephyps(io) * slmic + loyp0
           end if
           if( sopephype(io) .le. sundef ) then
               sopephype(io) = lype
           else
               sopephype(io) = sopephype(io) * slmic + loyp0
           end if
           if( sopephzps(io) .le. sundef ) then
               sopephzps(io) = lzps
           else
               sopephzps(io) = sopephzps(io) * slmic + lozp0
           end if
           if( sopephzpe(io) .le. sundef ) then
               sopephzpe(io) = lzpe
           else
               sopephzpe(io) = sopephzpe(io) * slmic + lozp0
           end if
           wopephxps(io) = ( sopephxps(io) - loxp0 ) * slmicinv
           wopephxpe(io) = ( sopephxpe(io) - loxp0 ) * slmicinv
           wopephyps(io) = ( sopephyps(io) - loyp0 ) * slmicinv
           wopephype(io) = ( sopephype(io) - loyp0 ) * slmicinv
           wopephzps(io) = ( sopephzps(io) - lozp0 ) * slmicinv
           wopephzpe(io) = ( sopephzpe(io) - lozp0 ) * slmicinv
           wopephxpr(io) = ( wopephxpe(io) - wopephxps(io) ) / lgphxx
!
           if( lrank .le. 0 ) &
              write(6,*) 'wopeph[xyz]p[se] = ', io, &
                       wopephxps(io), wopephyps(io), wopephzps(io), &
                       wopephxpe(io), wopephype(io), wopephzpe(io)
           wopephuxm(io) = sopephuxm(io)
           wopephuxx(io) = sopephuxx(io)
           sopephuxm(io) = sopephuxm(io) * scfl
           sopephuxx(io) = sopephuxx(io) * scfl
           wopephuxr(io) = ( wopephuxx(io) - wopephuxm(io) ) / lgphux
!
           wopephuym(io) = sopephuym(io)
           wopephuyx(io) = sopephuyx(io)
           sopephuym(io) = sopephuym(io) * scfl
           sopephuyx(io) = sopephuyx(io) * scfl
           wopephuyr(io) = ( wopephuyx(io) - wopephuym(io) ) / lgphux
           wopephuzm(io) = sopephuzm(io)
           wopephuzx(io) = sopephuzx(io)
           sopephuzm(io) = sopephuzm(io) * scfl
           sopephuzx(io) = sopephuzx(io) * scfl
           wopephuzr(io) = ( wopephuzx(io) - wopephuzm(io) ) / lgphux
!
           if( lrank .le. 0 ) then
             write(6,*) 'wopephux[mx] = ', io, wopephuxm(io), &
                         wopephuxx(io)
             write(6,*) 'wopephuy[mx] = ', io, wopephuym(io), &
                         wopephuyx(io)
             write(6,*) 'wopephuz[mx] = ', io, wopephuzm(io), &
                         wopephuzx(io)
           end if
!
        end do
        if( iopeph .le. 4 ) then
           call fntpcnv ( bbifntp, lrank,iun, bident,'peph', bfile )
           open( iun, file=bfile, form='UNFORMATTED' )
           write(iun) 'peh4', bident, lgphxx, lgphux, iopephl, &
            ( wopephxps(io),wopephyps(io),wopephzps(io), &
              wopephxpe(io),wopephype(io),wopephzpe(io), &
              wopephuxm(io),wopephuxx(io),wopephuym(io),wopephuyx(io), &
              wopephuzm(io),wopephuzx(io), io = 1, iopephl )
           flush(iun)
        end if
        if( iopeph .ge. 2 ) then
           call fntpcnv ( bfrfntp, lrank,ifn, bident,'peph', bfile )
           call frames_file ( bfile, ifn, iopeph )
        end if

      end if

      call fdebug ( 'o3peph', 1 )

      return
      end
