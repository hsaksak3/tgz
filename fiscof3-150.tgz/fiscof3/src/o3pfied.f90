!----------------------------------------------------------------------
! Observe 3D Particle Fast Ion Energy Distribution Function
!                            /
      subroutine o3pfied ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!                  4 = output footer
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 12/05/31
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use control
      use observe
      use fpprm
      use particle
      use field
      use laserprf
      include "implicit.h"
      integer, parameter :: lgprx = 200, lgpmx = 37, lgpnx = 36, &
                            lgpxyz = 10,  lgpmx1 = lgpmx + 1
      integer :: kflag, i, is, ii, im, in, ir, irl, ilu, ixpm, iypm, izpm, &
                 iflg, il, ilx, idrlx, idlux
      real*8  :: wzero=1.0d-6, womg, wdomg, wdomg2, wintt, wm, wn, wr, wrld, wlud, &
                 wnpnc, wpxs, wpxe, wpys, wpye, wpzs, wpze, wrang, &
                 wpx,wpy,wpz,wxd(lopfiedx), wyd(lopfiedx), wzd(lopfiedx), wzeroi
      real*8, allocatable :: wmue(:), wpidsn(:,:,:,:,:,:,:)
      save
!....
      call fdebug ( 'o3pfied', 0 )
!....
      if( kflag .eq. 4 ) then
         if( lresto .eq. 0 ) then
            lopfiedc = lopfiedc + 1
            if( iflg .le. 2 ) then
               do il = 1, ilx
                  write(54+il,1400) il,ilx
                  flush(54+il)
 1400             format( '------- end ',i1,'/',i1,' --------')
               end do
            end if
         end if
         return
      end if
!....
      if( kflag .ge. 2 ) then
         do is = 1, lionspl
           wzeroi = wzero * ( smasr/sionam(is) )**2
           do i = lionids(is), lionide(is)
             do il = 1, ilx
             if( lopfiedty(il) .eq. 1 )then
               if( (szi(i)-sopfiedpo(5,il))*(szi(i)+svzi(i)-sopfiedpo(5,il)) &
                                                     .gt. s0o1 ) cycle
               if( sxi(i).lt.sopfiedpo(1,il).or.sxi(i).gt.sopfiedpo(3,il) ) &
                                                                 cycle
               if( syi(i).lt.sopfiedpo(2,il).or.syi(i).gt.sopfiedpo(4,il) ) &
                                                                 cycle
             else if( lopfiedty(il) .eq. 2 )then
               if( (sxi(i)-sopfiedpo(5,il))*(sxi(i)+svxi(i)-sopfiedpo(5,il)) &
                                                     .gt. s0o1 ) cycle
               if( syi(i).lt.sopfiedpo(1,il).or.syi(i).gt.sopfiedpo(3,il) ) &
                                                                 cycle
               if( szi(i).lt.sopfiedpo(2,il).or.szi(i).gt.sopfiedpo(4,il) ) &
                                                                 cycle               
             else if( lopfiedty(il) .eq. 3 )then
               if( (syi(i)-sopfiedpo(5,il))*(syi(i)+svyi(i)-sopfiedpo(5,il)) &
                                                    .gt. s0o1 ) cycle
               if( sxi(i).lt.sopfiedpo(1,il).or.sxi(i).gt.sopfiedpo(3,il) ) &
                                                                 cycle
               if( szi(i).lt.sopfiedpo(2,il).or.szi(i).gt.sopfiedpo(4,il) ) &
                                                                 cycle               
             end if
!.
               wr = suui(i)
               wm = suxi(i) / wr
               wr = wr * scflinv * sopfiedr(is)
               ir = int( wr ) + 1
               ir = min( ir, lopfiedrl )
               do ii = 1, lopfiedml
                  if( (wm-wmue(ii)) * (wm-wmue(ii+1)) .le. s0o1 ) then
                     im = ii
                     go to 1
                  end if
               end do
               if( lrank .le. 0 ) &
               write(0,*) '### WARNING: mue', wm
               im = 1
    1          continue
               if( suyi(i)**2 + suzi(i)**2 .lt. wzeroi ) then
                  in = 1
               else
                  womg = atan2( suzi(i), suyi(i) ) + wdomg2
                  if( womg .lt. s0o1 ) womg = womg + s2pi
                  in = int( womg / wdomg ) + 1
               end if
             if( lopfiedty(il) .eq. 1 )then
               irl = int( (sxi(i)-sopfiedpo(1,il))/wxd(il) ) + 1
               ilu = int( (syi(i)-sopfiedpo(2,il))/wyd(il) ) + 1
             else if( lopfiedty(il) .eq. 2 )then
               irl = int( (syi(i)-sopfiedpo(1,il))/wyd(il) ) + 1
               ilu = int( (szi(i)-sopfiedpo(2,il))/wzd(il) ) + 1
             else if( lopfiedty(il) .eq. 3 )then
               irl = int( (sxi(i)-sopfiedpo(1,il))/wxd(il) ) + 1
               ilu = int( (szi(i)-sopfiedpo(2,il))/wzd(il) ) + 1
             end if
               wpidsn(ir,im,in,irl,ilu,is,il) = wpidsn(ir,im,in,irl,ilu,is,il) &
                                           + spfi(i)
             end do
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
            lopfiedc = lopfiedc + 1
            do il = 1, ilx
              write(54+il,1100) sstcur
 1100         format( '------------------------'/' time = ', f12.3 )
              do is = 1, lionspl
                wn = s0o1
                do ilu = 1, idlux
                do irl = 1, idrlx
                  do in = 1, lopfiednl
                    do im = 1, lopfiedml
                      do ir = 1, lopfiedrl
                        if( kflag .eq. 2 ) &
                          wpidsn(ir,im,in,irl,ilu,is,il) = &
                            wpidsn(ir,im,in,irl,ilu,is,il) * lopfieda
                        if(wpidsn(ir,im,in,irl,ilu,is,il).ge.sopfiedm(is)) &
                        then
                          wn = wn + wpidsn(ir,im,in,irl,ilu,is,il)
                          write(54+il,1200) ir,im,in,irl,ilu, &
                                            wpidsn(ir,im,in,irl,ilu,is,il)
 1200                     format( 5i4, f12.3 )
                        end if
                      end do
                    end do
                  end do
                end do
                end do
                write(54+il,1300) is, wn
 1300           format( 'total(',i1,') = ', f12.3 )
              end do
              flush(54+il)
            end do
!....
         else
!....
            iflg = mod( lopfied, 10 )
            ilx = lopfied / 10
!..
            if( lopfiedrl .lt. 1 .or. lopfiedrl .gt. lgprx ) then
               write(0,*) '### ERROR: lopfiedrl out of range!',  &
                          1,lopfiedrl,lgprx
               call s3ext_abort
            end if
            if( .not. allocated(wmue) ) allocate( wmue(lgpmx1) )
              if( lopfiedml .lt. 2 .or. lopfiedml .gt. lgpmx ) then
                write(0,*) '### ERROR: lopfiedml out of range!', &
                         2,lopfiedml,lgpmx
                call s3ext_abort
              else
                wdomg2 = spi / ( (lopfiedml-2)*2 + 2 )
                wdomg  = wdomg2 * s2o1
                wmue(1) = 1.0d0
                do im = 2, lopfiedml
                   wmue(im) = cos( wdomg2 + wdomg * (im-2) )
                end do
                wmue(lopfiedml+1) = -1.0d0
              end if
            if( lopfiednl .lt. 1 .or. lopfiednl .gt. lgpnx ) then
               write(0,*) '### ERROR: lopfiednl out of range!', &
                         1,lopfiednl,lgpnx
               call s3ext_abort
            end if
            idrlx = 0
            idlux = 0
            do il = 1, ilx
               if( lopfieddl(1,il) .gt. lgpxyz .or. &
                   lopfieddl(2,il) .gt. lgpxyz ) then
                  write(0,*) '### ERROR: lopfieddl overflow!',  &
                         il,lopfieddl(1,il),lopfieddl(2,il),lgpxyz
                 call s3ext_abort
               end if
               idrlx = max( idrlx, lopfieddl(1,il) )
               idlux = max( idlux, lopfieddl(2,il) )
            end do
!
            if( .not. allocated(wpidsn) ) allocate( &
         wpidsn(lopfiedrl,lopfiedml,lopfiednl,idrlx,idlux,lionspx,ilx) )
!
!
            wdomg  = s2pi / lopfiednl
            wdomg2 = wdomg / s2o1
            wintt = lopfieda * sdtfs
!..
            do il = 1, ilx
!
            wrld = ( sopfiedpo(3,il) - sopfiedpo(1,il) ) / lopfieddl(1,il)
            wlud = ( sopfiedpo(4,il) - sopfiedpo(2,il) ) / lopfieddl(2,il)
            if( lopfiedty(il).eq. 1 )then
               wxd(il) = wrld
               wyd(il) = wlud
            else if( lopfiedty(il) .eq. 2 )then
               wyd(il) = wrld
               wzd(il) = wlud
            else if( lopfiedty(il) .eq. 3 )then
               wxd(il) = wrld
               wzd(il) = wlud
            end if
!
            call fntpcnv ( bfpfntpi, lrank,il, bident,'pfied', bfile )
            open(54+il, file=trim(bfile), &
                                   form='FORMATTED', status='UNKNOWN')
!.
            if( lresti .eq. 0 ) then
              if( lopfiedty(il) .eq. 1 )then
                 wpxs = ( sopfiedpo(1,il) - loxp0 ) * slmicinv
                 wpys = ( sopfiedpo(2,il) - loyp0 ) * slmicinv
                 wpxe = ( sopfiedpo(3,il) - loxp0 ) * slmicinv
                 wpye = ( sopfiedpo(4,il) - loyp0 ) * slmicinv
                 wpz  = ( sopfiedpo(5,il) - lozp0 ) * slmicinv
              else if( lopfiedty(il) .eq. 2 )then
                 wpys = ( sopfiedpo(1,il) - loyp0 ) * slmicinv
                 wpzs = ( sopfiedpo(2,il) - lozp0 ) * slmicinv
                 wpye = ( sopfiedpo(3,il) - loyp0 ) * slmicinv
                 wpze = ( sopfiedpo(4,il) - lozp0 ) * slmicinv
                 wpx  = ( sopfiedpo(5,il) - loxp0 ) * slmicinv
              else if( lopfiedty(il) .eq. 3 )then
                 wpxs = ( sopfiedpo(1,il) - loxp0 ) * slmicinv
                 wpzs = ( sopfiedpo(2,il) - lozp0 ) * slmicinv
                 wpxe = ( sopfiedpo(3,il) - loxp0 ) * slmicinv
                 wpze = ( sopfiedpo(4,il) - lozp0 ) * slmicinv
                 wpy  = ( sopfiedpo(5,il) - loyp0 ) * slmicinv
              end if
              
              write(54+il,1001) il, ilx, bident, lopfiedml
              write(54+il,1002) lopfiednl, lopfiedrl, wintt, sotint
              if( lopfiedty(il) .eq. 1 )then
                 write(54+il,1003) wpz ,wpxs,wpxe,wpys,wpye, lopfieddl(1,il),lopfieddl(2,il)
              else if( lopfiedty(il) .eq. 2 )then
                 write(54+il,1004) wpx ,wpys,wpye,wpzs,wpze, lopfieddl(1,il),lopfieddl(2,il)
              else if( lopfiedty(il) .eq. 3 )then
                 write(54+il,1005) wpy ,wpxs,wpxe,wpzs,wpze, lopfieddl(1,il),lopfieddl(2,il)
              end if
              
              write(54+il,1006) snepm1,s1o1/smasr,lionspl
 1001         format( '------ start ',i1,'/',i1,' -------'/ &
            'ident character             = ', a16 / &
            'Equal Division              = ', i7 )
 1002         format( &
            '# of mesh for omega         = ', i7 / &
            '# of mesh for momentum      = ', i7 / &
            'integration time            = ', f11.3, ' [fsec]' / &
            'observation interval        = ', f11.3, ' [fsec]' )
 1003         format( &
            'observation position of z   = ', f11.3, ' [micron]'/ &
            'observation position of xs  = ', f11.3, ' [micron]'/ &
            'observation position of xe  = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            '# of division for xy        = ', 2i7 )
 1004         format( &
            'observation position of x   = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            'observation position of zs  = ', f11.3, ' [micron]'/ &
            'observation position of ze  = ', f11.3, ' [micron]'/ &
            '# of division for yz        = ', 2i7 )
 1005         format( &
            'observation position of y   = ', f11.3, ' [micron]'/ &
            'observation position of xs  = ', f11.3, ' [micron]'/ &
            'observation position of xe  = ', f11.3, ' [micron]'/ &
            'observation position of zs  = ', f11.3, ' [micron]'/ &
            'observation position of ze  = ', f11.3, ' [micron]'/ &
            '# of division for xz        = ', 2i7 )
 1006         format( &
            '# of particle/mesh at nc    = ', f11.3 / &
            'mass ratio                  = ', f11.3 / &
            'number of ion species       = ', i7 )
!
              if( lcfdi .eq. 0 ) call c3fdi
              do is = 1, lionspl
                wrang = s1o1 / sopfiedr(is)
                
                if( lopfiedty(il) .eq. 1 )then
                  ixpm = ( sopfiedpo(1,il) + sopfiedpo(3,il) ) / s2o1
                  iypm = ( sopfiedpo(2,il) + sopfiedpo(4,il) ) / s2o1
                  izpm = floor(sopfiedpo(5,il))
                else if( lopfiedty(il) .eq. 2 )then
                  ixpm = floor(sopfiedpo(5,il))
                  iypm = ( sopfiedpo(1,il) + sopfiedpo(3,il) ) / s2o1
                  izpm = ( sopfiedpo(2,il) + sopfiedpo(4,il) ) / s2o1
                else if( lopfiedty(il) .eq. 3 )then
                  ixpm = ( sopfiedpo(1,il) + sopfiedpo(3,il) ) / s2o1
                  iypm = floor(sopfiedpo(5,il))
                  izpm = ( sopfiedpo(2,il) + sopfiedpo(4,il) ) / s2o1
                end if
                wnpnc = sdi(ixpm,iypm,izpm,is) / snepm1
                write(54+il,1007) is,wrang, is,sionaz(is), &
                                is,sionam(is), is, wnpnc
 1007            format( &
            'range(',i1,')                    = ', e11.4 / &
            'average Z(',i1,')                = ', f11.3 / &
            'average weight number(',i1,')    = ', f11.3 / &
            'density at center(',i1,')        = ', f11.3 )
              end do
!
              write(54+il,1008) slramm,slram,sgrid,slpwr
 1008         format( &
            'laser wavelength            = ', f11.3,' [micron]'/ &
            'laser wavelength/mesh size  = ', f11.3 / &
            'Debye length/mesh size      = ', f11.3 / &
            'laser peak intensity        = ', e11.4, &
                                           ' [W/cm^2-micron^2]')
!
              if( llsrty .eq. 1 ) then
                 write(54+il,1010) slsrle, slsrwd, slsrtr
 1010            format( &
               'laser pulse shape           =  LINEAR + FLAT' / &
               'laser pulse (up,width,down) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 2 ) then
                 write(54+il,1020) slsrle, slsrwd, slsrtr
 1020            format( &
               'laser pulse shape           =  GAUSSIAN + FLAT' / &
               'laser pulse (HWHM,WID,HWHM) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 3 ) then
                 write(54+il,1030) slsrwd
 1030            format( &
               'laser pulse shape           = GAUSSIAN' / &
               'laser pulse (FWHM)          = ',f11.3,' [fsec]' )
              else if( llsrty .eq. 4 ) then
                 write(54+il,1040) slsrwd, slsrle
 1040            format( &
               'laser pulse shape           = SUPERGAUSSIAN' / &
               'laser pulse (FWHM,alpha)    = ',f11.3,' [fsec] (', &
                                                    f4.1, ')' )
              else
                 write(54+il,1050) llsrty, slsrle, slsrwd, slsrtr
 1050            format( &
               'laser pulse shape (TYPE)    = ', i7 / &
               'laser pulse parameters      = ', 3f11.3 )
              end if
!
              flush(54+il)
!
            end if
            end do
         end if
!...
         do il = 1, ilx
           do is = 1, lionspl
           do ilu = 1, idlux
             do irl = 1, idrlx
               do in = 1, lopfiednl
                 do im = 1, lopfiedml
                   do ir = 1, lopfiedrl
                     wpidsn(ir,im,in,irl,ilu,is,il) = s0o1
                   end do
                 end do
               end do
             end do
           end do
           end do
         end do
!....
      end if
!....
      call fdebug ( 'o3pfied', 1 )
!....
      return
      end
