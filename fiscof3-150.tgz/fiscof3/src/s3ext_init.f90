!----------------------------------------------------------------------
! Set 3D EXTernal system INITialize
!
      subroutine s3ext_init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
!....
      call frames_init
!..
      call gdfxs_init
!....
      return
      end
