!----------------------------------------------------------------------
! Set 3D EXTernal system BEGINning
!
      subroutine s3ext_begin
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 16/10/04
!----------------------------------------------------------------------
!....
      return
      end
