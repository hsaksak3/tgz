!-----------------------------------------------------------------------
! ChecK Current Conservation
!                            /
      subroutine fck_cc ( echar )
!
!   <arguments>
!     echar : message for print
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use field
      use particle
      include "implicit.h"
      integer :: io, ix, iy, iz, ixerx, iyerx, izerx
      real*8  :: werr, werrx, werrs
      character*(*) echar
      save
!....
      call c3fdeo
      if( lcfde .eq. 0 ) call c3fde
      werrx = s0o1
      ixerx = -1
      iyerx = -1
      izerx = -1
      werrs = s0o1
!..
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            werr = ( sjxe(ix+1,iy,iz) - sjxe(ix,iy,iz) + &
                     sjye(ix,iy+1,iz) - sjye(ix,iy,iz) + &
                     sjze(ix,iy,iz+1) - sjze(ix,iy,iz) - &
                     sde(ix,iy,iz) + sdeo(ix,iy,iz) ) ** 2
            if( werr .gt. werrx ) then
               werrx = werr
               ixerx = ix
               iyerx = iy
               izerx = iz
            end if
            werrs = werrs + werr
          end do
        end do
      end do
!..
      werrx = sqrt( werrx )
      werrs = sqrt( werrs ) / &
           ((lssxup1-lssxlm1+1)*(lssyup1-lssylm1+1)*(lsszup1-lsszlm1+1))
      write(6,*) '@@@ fck_cc(e) ', echar, werrs, werrx, &
                                   ixerx, iyerx, izerx
!....
      if( lnoi .gt. 0 ) then
         call c3fdio
         if( lcfdi .eq. 0 ) call c3fdi
!..
         do io = 1, lionspl
!.
            werrx = s0o1
            ixerx = -1
            iyerx = -1
            izerx = -1
            werrs = s0o1
            do iz = lsszlm1, lsszup1
              do iy = lssylm1, lssyup1
                do ix = lssxlm1, lssxup1
                  werr = ( sjxi(ix+1,iy,iz,io) - sjxi(ix,iy,iz,io) + &
                           sjyi(ix,iy+1,iz,io) - sjyi(ix,iy,iz,io) + &
                           sjzi(ix,iy,iz+1,io) - sjzi(ix,iy,iz,io) + &
                    (sdi(ix,iy,iz,io)-sdio(ix,iy,iz,io))*sionaz(io) )**2
                  if( werr .gt. werrx ) then
                     werrx = werr
                     ixerx = ix
                     iyerx = iy
                     izerx = iz
                  end if
                  werrs = werrs + werr
                end do
              end do
            end do
!.
            werrx = sqrt( werrx )
            werrs = sqrt( werrs ) / &
           ((lssxup1-lssxlm1+1)*(lssyup1-lssylm1+1)*(lsszup1-lsszlm1+1))
            write(6,*) '@@@ fck_cc(i) ', echar, io, werrs, werrx,  &
                      ixerx, iyerx, izerx
         end do
!..
      end if
!....
      return
      end
