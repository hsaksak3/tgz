module ptcltype
      type ty1_particle
         sequence
         real*8  :: x, y, z, ux, uy, uz, uu, pf
         integer :: nid, clfl
      end type ty1_particle
      type ty2_particle
         sequence
         real*8  :: xo, yo, zo, vx, vy, vz, fx, fy, fz
      end type ty2_particle
end module ptcltype
