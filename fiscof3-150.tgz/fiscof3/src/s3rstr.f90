!-------------------------------------------------------------------
! Set 3D Random STaRt
!
      subroutine s3rstr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use profile
      use constant
      use particle
      include "implicit.h"
      integer :: i, ix, ixs, ixe, iy, iys, iye, iz, izs, ize, ip, io, &
                 inoe, inoi, inepm, inepm2, inipm, inipm2, iionids
      real*8  :: wx(200), wy(200), wz(200), wvv(4), apf, wvte, wvti, &
                 wut, wxs, wxe, wys, wye, wzs, wze
      save
!....
      call fdebug ( 's3rstr', 0 )
!++++
      if( smasr .gt. 1.0d-29 ) then
         do ip = 1, lpppl
            if( lpppis(ip) .lt. 1 .or. lpppis(ip) .gt. lionspl ) then
               write(0,*) '### ERROR: ion was not specified.',  &
                         ip, lpppis(ip)
               call s3ext_abort
            end if
         end do
      end if
!++++
!....
      inoe = 0
!....
      do ip = 1, lpppl
!....
         ixs = spppbo(1,ip) * slmic + lxp0
         iys = spppbo(2,ip) * slmic + lyp0
         izs = spppbo(3,ip) * slmic + lzp0
         ixe = spppbo(4,ip) * slmic + lxp0
         iye = spppbo(5,ip) * slmic + lyp0
         ize = spppbo(6,ip) * slmic + lzp0
!..
         inepm = snepm1 * spppns(ip)
         if( inepm .gt. lnepme ) inepm = lnepme
         if( inepm .lt. 1      ) inepm = 1
         apf = ( snepm1*spppns(ip) ) / inepm
         inepm2 = inepm / 2
!++++
         if( inepm2 .gt. 200 ) then
            write(0,*) '### ERROR: table overflow in s3rstr', inepm2
            call s3ext_abort
         end if
!++++
         wvte = svte * sqrt( spppte(ip) )
         wut  = wvte / sqrt( s1o1 - ( s3o1 * wvte**2 ) * scg1 )
!.
         do iz = izs, ize
           do iy = iys, iye
             do ix = ixs, ixe
               call mt_drand3 ( wx, inepm2 )
               call mt_drand3 ( wy, inepm2 )
               call mt_drand3 ( wz, inepm2 )
               do i = 1, inepm2
                  inoe = inoe + 1
!++++
                  if( inoe+1 .gt. lnoex ) then
                     write(0,*) &
                   '### ERROR: electron number overflow in s3rstr', inoe
                     call s3ext_abort
                  end if
!++++
                  sxe(inoe) = ix + wx(i)
                  sye(inoe) = iy + wy(i)
                  sze(inoe) = iz + wz(i)
                  call mt_drand3 ( wvv, 4 )
                  suxe(inoe) = wut * sqrt( -s2o1 * log( wvv(1) ) ) *  &
                                       cos( wvv(2) * s2pi )
                  suye(inoe) = wut * sqrt( -s2o1 * log( wvv(1) ) ) *  &
                                       sin( wvv(2) * s2pi )
                  suze(inoe) = wut * sqrt( -s2o1 * log( wvv(3) ) ) *  &
                                       cos( wvv(4) * s2pi )
                  spfe(inoe) = apf
                  inoe = inoe + 1
                  sxe(inoe) = sxe(inoe-1)
                  sye(inoe) = sye(inoe-1)
                  sze(inoe) = sze(inoe-1)
                  suxe(inoe) = - suxe(inoe-1)
                  suye(inoe) = - suye(inoe-1)
                  suze(inoe) = - suze(inoe-1)
                  spfe(inoe) = spfe(inoe-1)
                  suxe(inoe-1) = suxe(inoe-1) + spppudxe(ip)
                  suye(inoe-1) = suye(inoe-1) + spppudye(ip)
                  suze(inoe-1) = suze(inoe-1) + spppudze(ip)
                  suxe(inoe) = suxe(inoe) + spppudxe(ip)
                  suye(inoe) = suye(inoe) + spppudye(ip)
                  suze(inoe) = suze(inoe) + spppudze(ip)
               end do
               if( mod(inepm,2) .eq. 1 ) then
                  call mt_drand3 ( wx, 7 )
                  inoe = inoe + 1
                  sxe(inoe) = ix + wx(1)
                  sye(inoe) = iy + wx(2)
                  sze(inoe) = iz + wx(3)
                  suxe(inoe) = wut * sqrt( -s2o1 * log( wx(4) ) ) *  &
                                       cos( wx(5) * s2pi )
                  suye(inoe) = wut * sqrt( -s2o1 * log( wx(4) ) ) *  &
                                       sin( wx(5) * s2pi )
                  suze(inoe) = wut * sqrt( -s2o1 * log( wx(6) ) ) *  &
                                       cos( wx(7) * s2pi )
                  suxe(inoe) = suxe(inoe) + spppudxe(ip)
                  suye(inoe) = suye(inoe) + spppudye(ip)
                  suze(inoe) = suze(inoe) + spppudze(ip)
                  spfe(inoe) = apf
               end if
             end do
           end do
         end do
      end do
!..
      lnoe = inoe
      lnoes = 1
      lnoee = lnoes + lnoe - 1
      inoi = inoe
!....
      if( smasr .gt. 1.0d-29 ) then
         do io = 1, lionspl
         iionids = inoi + 1
!...
         do ip = 1, lpppl
         if( lpppis(ip) .eq. io ) then
!....
         ixs = spppbo(1,ip) * slmic + lxp0
         iys = spppbo(2,ip) * slmic + lyp0
         izs = spppbo(3,ip) * slmic + lzp0
         ixe = spppbo(4,ip) * slmic + lxp0
         iye = spppbo(5,ip) * slmic + lyp0
         ize = spppbo(6,ip) * slmic + lzp0
!.
       !  inipm = snepm1 * spppnp(ip) / ( sionaz(io) * sionaf(io) )
         if( inipm .gt. lnipme(io) ) inipm = lnipme(io)
         if( inipm .lt. 1          ) inipm = 1
       !  apf = ( snepm1*spppnp(ip) / sionaz(io) ) / inipm
         inipm2 = inipm / 2
         wvti = svti(io) * sqrt( spppti(ip) )
         wut  = wvti / sqrt( s1o1 - ( s3o1 * wvti**2 ) * scg1 )
!.
         do iz = izs, ize
           do iy = iys, iye
             do ix = ixs, ixe
               call mt_drand3 ( wx, inepm2 )
               call mt_drand3 ( wy, inepm2 )
               call mt_drand3 ( wz, inepm2 )
               do i = 1, inipm2
                  inoi = inoi + 1
!++++
                  if( inoi+1 .gt. lnoix ) then
                     write(0,*) &
                       '### ERROR: ion number overflow in s3rstr', inoi
                     call s3ext_abort
                  end if
!++++
                  sxi(inoi) = ix + wx(i)
                  syi(inoi) = iy + wy(i)
                  szi(inoi) = iz + wz(i)
                  call mt_drand3 ( wvv, 4 )
                  suxi(inoi) = wut * sqrt( -s2o1*log( wvv(1) ) ) *  &
                                    cos( wvv(2) * s2pi )
                  suyi(inoi) = wut * sqrt( -s2o1*log( wvv(1) ) ) *  &
                                    sin( wvv(2) * s2pi )
                  suzi(inoi) = wut * sqrt( -s2o1*log( wvv(3) ) ) *  &
                                    cos( wvv(4) * s2pi )
                  spfi(inoi) = apf
                  inoi = inoi + 1
                  sxi(inoi) = sxi(inoi-1)
                  syi(inoi) = syi(inoi-1)
                  szi(inoi) = szi(inoi-1)
                  suxi(inoi) = - suxi(inoi-1)
                  suyi(inoi) = - suyi(inoi-1)
                  suzi(inoi) = - suzi(inoi-1)
                  spfi(inoi) = spfi(inoi-1)
                  suxi(inoi-1) = suxi(inoi-1) + spppudxi(ip)
                  suyi(inoi-1) = suyi(inoi-1) + spppudyi(ip)
                  suzi(inoi-1) = suzi(inoi-1) + spppudzi(ip)
                  suxi(inoi) = suxi(inoi) + spppudxi(ip)
                  suyi(inoi) = suyi(inoi) + spppudyi(ip)
                  suzi(inoi) = suzi(inoi) + spppudzi(ip)
               end do
               if( mod(inipm,2) .eq. 1 ) then
                  call mt_drand3 ( wx, 7 )
                  inoi = inoi + 1
                  sxi(inoi) = ix + wx(1)
                  syi(inoi) = iy + wx(2)
                  szi(inoi) = iz + wx(3)
                  suxi(inoi) = wut * sqrt( -s2o1*log( wx(4) ) ) *  &
                                    cos( wx(5) * s2pi )
                  suyi(inoi) = wut * sqrt( -s2o1*log( wx(4) ) ) *  &
                                    sin( wx(5) * s2pi )
                  suzi(inoi) = wut * sqrt( -s2o1*log( wx(6) ) ) *  &
                                    cos( wx(7) * s2pi )
                  suxi(inoi) = suxi(inoi) + spppudxi(ip)
                  suyi(inoi) = suyi(inoi) + spppudyi(ip)
                  suzi(inoi) = suzi(inoi) + spppudzi(ip)
                  spfi(inoi) = apf
               end if
             end do
           end do
         end do
!..
         end if
         end do
!....
         lionids(io) = iionids
         lionide(io) = inoi
         lionidl(io) = lionide(io)-lionids(io)+1
!++++
         if( lionidl(io) .lt. 1 ) then
            write(0,*) '### ERROR: specified ion was not used.', io
            call s3ext_abort
         end if
!++++
         end do
!..
         lnois = lionids(1)
         lnoie = lionide(lionspl)
         lnoi  = lnoie - lnois + 1
!...
      else
         lnoi  = 0
         lnois = 0
         lnoie = -1
         lionspl = 0
      end if
!....
      wxs =  1.0d30
      wys =  1.0d30
      wzs =  1.0d30
      wxe = -1.0d30
      wye = -1.0d30
      wze = -1.0d30
      do i = lnoes, lnoee
         wxs = min( wxs, sxe(i) )
         wxe = max( wxe, sxe(i) )
         wys = min( wys, sye(i) )
         wye = max( wye, sye(i) )
         wzs = min( wzs, sze(i) )
         wze = max( wze, sze(i) )
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
!.
      do i = lnois, lnoie
         suui(i) = sqrt( suxi(i)**2 + suyi(i)**2 + suzi(i)**2 )
      end do
!..
      lxps = wxs - 1
      lxpe = wxe + 2
      lyps = wys - 1
      lype = wye + 2
      lzps = wzs - 1
      lzpe = wze + 2
!....
      call fdebug ( 's3rstr', 1 )
!....
      return
      end
