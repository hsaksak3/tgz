!----------------------------------------------------------------------
! Observe 3D Particle Ion Momentum
!                          /
      subroutine o3pim ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     This routine does not average the value, so always alloc/dealloc
!    arrays to save the memory.
!
!    coded by Sakagami,H. (NIFS) 20/11/25
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: iun = 23, ifn = 4
!     integer, parameter :: lpmx = 301, lpmx2 = (lpmx-1) / 2 + 1
      integer, parameter :: lpmx = 101, lpmx2 = (lpmx-1) / 2 + 1
      real(8), parameter :: afac = 1.0d0/3.0d0
      integer :: kflag, i, is, io, ix, iy ,iz, iopim, ilog, iopiml
      real*8  :: wopimxps(lopimx), wopimxpe(lopimx), &
                 wopimyps(lopimx), wopimype(lopimx), &
                 wopimzps(lopimx), wopimzpe(lopimx), &
                 ww
!     real*8, allocatable :: apimxyn(:,:,:,:), apimxzn(:,:,:,:), &
!                            apimyzn(:,:,:,:), &
!                            apimxn(:,:,:), apimyn(:,:,:), apimzn(:,:,:)
      real(8), allocatable :: apimn(:,:,:,:,:), apimw1(:), apimw2(:,:)
      character :: clabel*20
      save
!....
      call fdebug ( 'o3pim', 0 )
!....
      if( kflag .ge. 1 ) then
!        allocate( apimxyn(lpmx,lpmx,iopiml,lionspl), &
!                  apimxzn(lpmx,lpmx,iopiml,lionspl), &
!                  apimyzn(lpmx,lpmx,iopiml,lionspl), &
!                  apimxn(lpmx,iopiml,lionspl), &
!                  apimyn(lpmx,iopiml,lionspl), &
!                  apimzn(lpmx,iopiml,lionspl) )
         allocate( apimn(lpmx,lpmx,lpmx,iopiml,lionspl), &
                   apimw1(lpmx), apimw2(lpmx,lpmx) )
!..
!        do is = 1, lionspl
!          do io = 1, iopiml
!            do iy = 1, lpmx
!              apimxn(iy,io,is) = s0o1
!              apimyn(iy,io,is) = s0o1
!              apimzn(iy,io,is) = s0o1
!              do ix = 1, lpmx
!                 apimxyn(ix,iy,io,is) = s0o1
!                 apimxzn(ix,iy,io,is) = s0o1
!                 apimyzn(ix,iy,io,is) = s0o1
!              end do
!            end do
!          end do
!        end do
         apimn(:,:,:,:,:) = s0o1
!.
         do is = 1, lionspl
! !$OMP PARALLEL DO SCHEDULE(STATIC), &
! !$OMP     REDUCTION(+:apimxn,apimyn,apimzn,apimxyn,apimyzn,apimxzn), &
! !$OMP     PRIVATE(io,ix,iy,iz,ww)
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP       REDUCTION(+:apimn), PRIVATE(io,ix,iy,iz,ww)
          do i = lionids(is), lionide(is)
            do io = 1, iopiml
              if(sxi(i).lt.sopimxps(io).or.sxi(i).gt.sopimxpe(io)) cycle
              if(syi(i).lt.sopimyps(io).or.syi(i).gt.sopimype(io)) cycle
              if(szi(i).lt.sopimzps(io).or.szi(i).gt.sopimzpe(io)) cycle
!
!             ww = suxi(i) *scflinv*sionmm(is)* sopimfct(io,is)
              ww = suxi(i) *scflinv*sionmm(is)* sopimfct(io,is) * afac
              ix = sign( abs(ww) + s1o2, ww )
              ix = ix + lpmx2
              ix = max( ix, 1 )
              ix = min( ix, lpmx )
!             ww = suyi(i) *scflinv*sionmm(is)* sopimfct(io,is)
              ww = suyi(i) *scflinv*sionmm(is)* sopimfct(io,is) * afac
              iy = sign( abs(ww) + s1o2, ww )
              iy = iy + lpmx2
              iy = max( iy, 1 )
              iy = min( iy, lpmx )
!             ww = suzi(i) *scflinv*sionmm(is)* sopimfct(io,is)
              ww = suzi(i) *scflinv*sionmm(is)* sopimfct(io,is) * afac
              iz = sign( abs(ww) + s1o2, ww )
              iz = iz + lpmx2
              iz = max( iz, 1 )
              iz = min( iz, lpmx )
!             apimxn(ix,io,is)     = apimxn(ix,io,is) + spfi(i)
!             apimyn(iy,io,is)     = apimyn(iy,io,is) + spfi(i)
!             apimzn(iz,io,is)     = apimzn(iz,io,is) + spfi(i)
!             apimxyn(ix,iy,io,is) = apimxyn(ix,iy,io,is) + spfi(i)
!             apimxzn(ix,iz,io,is) = apimxzn(ix,iz,io,is) + spfi(i)
!             apimyzn(iy,iz,io,is) = apimyzn(iy,iz,io,is) + spfi(i)
              apimn(ix,iy,iz,io,is) = apimn(ix,iy,iz,io,is) + spfi(i)
            end do
          end do
         end do
!.
         if( iopim .le. 4 ) then
!           write(iun) sstcur, ( ( &
!              (apimxn(ix,io,is),ix=1,lpmx), &
!              (apimyn(iy,io,is),iy=1,lpmx), &
!              (apimzn(iz,io,is),iz=1,lpmx), &
!             ((apimxyn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx), &
!             ((apimxzn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx),  &
!             ((apimyzn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx),  &
!               io=1,iopiml ), is=1,lionspl )
            write(iun) sstcur, apimn(:,:,:,:,:)
            flush(iun)
         end if
!.
         if( iopim .ge. 2 ) then
           do is = 1, lionspl
             call o3ionlabel ( is, sionam(is), sionaz(is), clabel )
             do io = 1, iopiml
!              call o3pdraw6 ( bident, sstcur, sminlog, lminlog, &
!                    ifn, ilog, &
!                    apimxn(1,io,is),apimyn(1,io,is),apimzn(1,io,is), &
!                    apimxyn(1,1,io,is),apimyzn(1,1,io,is), &
!                    apimxzn(1,1,io,is), &
!                    lpmx, sopimfct(io,is), &
!                    wopimxps(io), wopimyps(io), wopimzps(io), &
!                    wopimxpe(io), wopimype(io), wopimzpe(io), &
!                    'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', &
!                    'pim'//clabel )
               call o3pdraw6 ( bident, sstcur, sminlog, lminlog, &
                     ifn, ilog, &
                     apimn(1,1,1,io,is), apimw1, apimw2, &
                     lpmx, sopimfct(io,is) * afac, &
                     wopimxps(io), wopimyps(io), wopimzps(io), &
                     wopimxpe(io), wopimype(io), wopimzpe(io), &
                     'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', &
                     'pim'//clabel )
             end do
            end do
         end if
!..
!        deallocate( apimxyn, apimxzn, apimyzn, apimxn, apimyn, apimzn )
         deallocate( apimn, apimw1, apimw2 )
!....
      else
         iopim  = mod( lopim, 10 )
         ilog   = mod( lopim/10, 10 )
         iopiml = mod( lopim/100, 10 )
!..
         do io = 1, iopiml
            if( sopimxps(io) .le. sundef ) then
               sopimxps(io) = lxps
            else
               sopimxps(io) = sopimxps(io) * slmic + loxp0
            end if
            if( sopimxpe(io) .le. sundef ) then
               sopimxpe(io) = lxpe
            else
               sopimxpe(io) = sopimxpe(io) * slmic + loxp0
            end if
            if( sopimyps(io) .le. sundef ) then
               sopimyps(io) = lyps
            else
               sopimyps(io) = sopimyps(io) * slmic + loyp0
            end if
            if( sopimype(io) .le. sundef ) then
               sopimype(io) = lype
            else
               sopimype(io) = sopimype(io) * slmic + loyp0
            end if
            if( sopimzps(io) .le. sundef ) then
               sopimzps(io) = lzps
            else
               sopimzps(io) = sopimzps(io) * slmic + lozp0
            end if
            if( sopimzpe(io) .le. sundef ) then
               sopimzpe(io) = lzpe
            else
               sopimzpe(io) = sopimzpe(io) * slmic + lozp0
            end if
            wopimxps(io) = ( sopimxps(io) - loxp0 ) * slmicinv
            wopimxpe(io) = ( sopimxpe(io) - loxp0 ) * slmicinv
            wopimyps(io) = ( sopimyps(io) - loyp0 ) * slmicinv
            wopimype(io) = ( sopimype(io) - loyp0 ) * slmicinv
            wopimzps(io) = ( sopimzps(io) - lozp0 ) * slmicinv
            wopimzpe(io) = ( sopimzpe(io) - lozp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopim[xyz]p[se] = ', io, &
                wopimxps(io), wopimyps(io), wopimzps(io), &
                wopimxpe(io), wopimype(io), wopimzpe(io)
         end do
         if( iopim .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pim', bfile )
            open(iun, file=bfile, form='UNFORMATTED')
            write(iun) 'pim4', bident, lpmx, iopiml, lionspl, &
             ( (sionam(is),sionaz(is),is=1,lionspl), &
               (sopimfct(io,is) * afac,is=1,lionspl), &
                wopimxps(io),wopimyps(io),wopimzps(io), &
                wopimxpe(io),wopimype(io),wopimzpe(io), io=1,iopiml )
            flush(iun)
         end if
         if( iopim .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pim', bfile )
            call frames_file ( bfile, ifn, iopim )
         end if
!....
      end if
!....
      call fdebug ( 'o3pim', 1 )
!....
      return
      end
