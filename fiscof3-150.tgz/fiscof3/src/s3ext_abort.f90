!----------------------------------------------------------------------
! Set 3D EXTernal system ABORT
!
      subroutine s3ext_abort
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 14/05/01
!----------------------------------------------------------------------
!....
      flush(6)
!....
      stop 99999
!....
      end
