!-----------------------------------------------------------------------
! Advance 3D Field magnetic(B) 
!
      subroutine a3fb
!
!   <arguments>
!     none
!
!   <remarks>
!     "sdeyxdxy" was already divided by 2 for an half step and changed
!    its sign.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use field
      include "implicit.h"
      integer :: ix, iy, iz
      save
!....
      call fdebug ( 'a3fb', 0 )
!....
!$OMP PARALLEL 
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iy)
   do iz = lsszl , lsszup1
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sbx(ix,iy,iz) = sbx(ix,iy,iz) + sdezydyz(ix,iy,iz)
            sby(ix,iy,iz) = sby(ix,iy,iz) + sdexzdzx(ix,iy,iz)
            sbz(ix,iy,iz) = sbz(ix,iy,iz) + sdeyxdxy(ix,iy,iz)
         end do
      end do
   enddo
   
!..                                                       
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
   do iz = lsszl, lsszup1
     do iy = lssyl, lssyup1
       sbx(lssxlm1,iy,iz) = sbx(lssxlm1,iy,iz) + sdezydyz(lssxlm1,iy,iz)
     end do
   end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
   do iz = lsszl, lsszup1
     do ix = lssxl, lssxup1
       sby(ix,lssylm1,iz) = sby(ix,lssylm1,iz) + sdexzdzx(ix,lssylm1,iz)
     end do
   enddo
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
   do iy = lssyl, lssyup1
     do ix = lssxl, lssxup1
       sbz(ix,iy,lsszlm1) = sbz(ix,iy,lsszlm1) + sdeyxdxy(ix,iy,lsszlm1)
     end do
   enddo
!$OMP END PARALLEL
!....
      call fdebug ( 'a3fb', 1 )
!....
      return
      end
