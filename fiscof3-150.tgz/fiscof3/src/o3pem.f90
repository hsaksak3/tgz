!----------------------------------------------------------------------
! Observe 3D Particle Electron Momentum
!                          /
      subroutine o3pem ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     This routine does not average the value, so always alloc/dealloc
!    arrays to save the memory.
!
!    coded by Sakagami,H. (NIFS) 20/11/25
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: iun = 22, ifn = 3
!     integer, parameter :: lpmx = 301, lpmx2 = (lpmx-1) / 2 + 1
      integer, parameter :: lpmx = 101, lpmx2 = (lpmx-1) / 2 + 1
      real(8), parameter :: afac = 1.0d0/3.0d0
      integer :: kflag, i, io, ix, iy ,iz, iopem, ilog, iopeml
      real*8  :: ww, &
                 wopemxps(lopemx), wopemxpe(lopemx), &
                 wopemyps(lopemx), wopemype(lopemx), &
                 wopemzps(lopemx), wopemzpe(lopemx)
!     real*8, allocatable :: apemxyn(:,:,:), apemxzn(:,:,:), &
!                            apemyzn(:,:,:), &
!                            apemxn(:,:), apemyn(:,:), apemzn(:,:)
      real(8), allocatable :: apemn(:,:,:,:), apemw1(:), apemw2(:,:)
      save
!....
      call fdebug ( 'o3pem', 0 )
!....
      if( kflag .ge. 1 ) then
!..
!        allocate( &
!             apemxyn(lpmx,lpmx,iopeml), apemxzn(lpmx,lpmx,iopeml), &
!             apemyzn(lpmx,lpmx,iopeml), &
!             apemxn(lpmx,iopeml), apemyn(lpmx,iopeml), &
!             apemzn(lpmx,iopeml) )
         allocate( apemn(lpmx,lpmx,lpmx,iopeml), &
                   apemw1(lpmx), apemw2(lpmx,lpmx) )
!..
!        do io = 1, iopeml
!           do iy = 1, lpmx
!              apemxn(iy,io) = s0o1
!              apemyn(iy,io) = s0o1
!              apemzn(iy,io) = s0o1
!              do ix = 1, lpmx
!                 apemxyn(ix,iy,io) = s0o1
!                 apemxzn(ix,iy,io) = s0o1
!                 apemyzn(ix,iy,io) = s0o1
!              end do
!           end do
!        end do
         apemn(:,:,:,:) = s0o1
!.
! !$OMP PARALLEL DO SCHEDULE(STATIC), &
! !$OMP     REDUCTION(+:apemxn,apemyn,apemzn,apemxyn,apemyzn,apemxzn), &
! !$OMP     PRIVATE(io,ix,iy,iz,ww)
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP       REDUCTION(+:apemn), PRIVATE(io,ix,iy,iz,ww)
         do i = lnoes, lnoee
           do io = 1, iopeml
             if(sxe(i).lt.sopemxps(io).or.sxe(i).gt.sopemxpe(io)) cycle
             if(sye(i).lt.sopemyps(io).or.sye(i).gt.sopemype(io)) cycle
             if(sze(i).lt.sopemzps(io).or.sze(i).gt.sopemzpe(io)) cycle
!
!            ww = suxe(i) * scflinv * sopemfct(io)
             ww = suxe(i) * scflinv * sopemfct(io) * afac
             ix = sign( abs(ww) + s1o2, ww )
             ix = ix + lpmx2
             ix = max( ix, 1 )
             ix = min( ix, lpmx )
!            ww = suye(i) * scflinv * sopemfct(io)
             ww = suye(i) * scflinv * sopemfct(io) * afac
             iy = sign( abs(ww) + s1o2, ww )
             iy = iy + lpmx2
             iy = max( iy, 1 )
             iy = min( iy, lpmx )
!            ww = suze(i) * scflinv * sopemfct(io)
             ww = suze(i) * scflinv * sopemfct(io) * afac
             iz = sign( abs(ww) + s1o2, ww )
             iz = iz + lpmx2
             iz = max( iz, 1 )
             iz = min( iz, lpmx )
!            apemxn(ix,io)     = apemxn(ix,io) + spfe(i)
!            apemyn(iy,io)     = apemyn(iy,io) + spfe(i)
!            apemzn(iz,io)     = apemzn(iz,io) + spfe(i)
!            apemxyn(ix,iy,io) = apemxyn(ix,iy,io) + spfe(i)
!            apemxzn(ix,iz,io) = apemxzn(ix,iz,io) + spfe(i)
!            apemyzn(iy,iz,io) = apemyzn(iy,iz,io) + spfe(i)
             apemn(ix,iy,iz,io) = apemn(ix,iy,iz,io) + spfe(i)
           end do
         end do
!.
         if( iopem .le. 4 ) then
!           write(iun) sstcur, ( &
!              (apemxn(ix,io),ix=1,lpmx), (apemyn(iy,io),iy=1,lpmx), &
!              (apemzn(iz,io),iz=1,lpmx), &
!             ((apemxyn(ix,iy,io),ix=1,lpmx),iy=1,lpmx), &
!             ((apemxzn(ix,iy,io),ix=1,lpmx),iy=1,lpmx),  &
!             ((apemyzn(ix,iy,io),ix=1,lpmx),iy=1,lpmx), io=1,iopeml )
            write(iun) sstcur, apemn(:,:,:,:)
            flush(iun)
         end if
!.
         if( iopem .ge. 2 ) then
            do io = 1, iopeml
!              call o3pdraw6 ( bident, sstcur, sminlog, lminlog, &
!                    ifn, ilog, &
!                    apemxn(1,io), apemyn(1,io), apemzn(1,io), &
!                    apemxyn(1,1,io),apemyzn(1,1,io),apemxzn(1,1,io), &
!                    lpmx, sopemfct(io), &
!                    wopemxps(io), wopemyps(io), wopemzps(io), &
!                    wopemxpe(io), wopemype(io), wopemzpe(io), &
!                    'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pem' )
               call o3pdraw6 ( bident, sstcur, sminlog, lminlog, &
                 ifn, ilog, &
                 apemn(1,1,1,io), apemw1, apemw2, lpmx, &
                 sopemfct(io) * afac, &
                 wopemxps(io), wopemyps(io), wopemzps(io), &
                 wopemxpe(io), wopemype(io), wopemzpe(io), &
                 'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pem' )
            end do
         end if
!..
!        deallocate( apemxyn, apemxzn, apemyzn, apemxn, apemyn, apemzn )
         deallocate( apemn, apemw1, apemw2 )
!....
      else
         iopem  = mod( lopem, 10 )
         ilog   = mod( lopem/10, 10 )
         iopeml = mod( lopem/100, 10 )
!..
         do io = 1, iopeml
            if( sopemxps(io) .le. sundef ) then
               sopemxps(io) = lxps
            else
               sopemxps(io) = sopemxps(io) * slmic + loxp0
            end if
            if( sopemxpe(io) .le. sundef ) then
               sopemxpe(io) = lxpe
            else
               sopemxpe(io) = sopemxpe(io) * slmic + loxp0
            end if
            if( sopemyps(io) .le. sundef ) then
               sopemyps(io) = lyps
            else
               sopemyps(io) = sopemyps(io) * slmic + loyp0
            end if
            if( sopemype(io) .le. sundef ) then
               sopemype(io) = lype
            else
               sopemype(io) = sopemype(io) * slmic + loyp0
            end if
            if( sopemzps(io) .le. sundef ) then
               sopemzps(io) = lzps
            else
               sopemzps(io) = sopemzps(io) * slmic + lozp0
            end if
            if( sopemzpe(io) .le. sundef ) then
               sopemzpe(io) = lzpe
            else
               sopemzpe(io) = sopemzpe(io) * slmic + lozp0
            end if
            wopemxps(io) = ( sopemxps(io) - loxp0 ) * slmicinv
            wopemxpe(io) = ( sopemxpe(io) - loxp0 ) * slmicinv
            wopemyps(io) = ( sopemyps(io) - loyp0 ) * slmicinv
            wopemype(io) = ( sopemype(io) - loyp0 ) * slmicinv
            wopemzps(io) = ( sopemzps(io) - lozp0 ) * slmicinv
            wopemzpe(io) = ( sopemzpe(io) - lozp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopem[xyz]p[se] = ', io, &
                wopemxps(io), wopemyps(io), wopemzps(io), &
                wopemxpe(io), wopemype(io), wopemzpe(io)
         end do
         if( iopem .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pem', bfile )
            open(iun, file=bfile, form='UNFORMATTED')
            write(iun) 'pem4', bident, lpmx, iopeml, &
              (sopemfct(io) * afac, &
               wopemxps(io),wopemyps(io),wopemzps(io), &
               wopemxpe(io),wopemype(io),wopemzpe(io),io=1,iopeml)
            flush(iun)
         end if
         if( iopem .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pem', bfile )
            call frames_file ( bfile, ifn, iopem )
         end if
!....
      end if
!....
      call fdebug ( 'o3pem', 1 )
!....
      return
      end
