!----------------------------------------------------------------------
! Compute 3D Particle Electron Cooling
!
      subroutine c3pec
!
!   <arguments>
!     none
!
!   <remarks>
!     lclflge : xy
!                y = 1 cooling if suxe > 0 and suue > scluure
!                y = 2 cooling both 1 and 3
!                y = 3 cooling if suxe < 0 and suue > scluule
!               x  = number of cooling regions
!
!     wclvv*e is normalized as V/Vth.
!     wclfcte is normalized as alpha/OMEGApe
!
!    coded by Sakagami, H. (NIFS) 10/08/23
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, ic, iclel, iclflge
      real*8  :: wfac
      save
!....
      call fdebug ( 'c3pec', 0 )
!....                                   * check particle for cooling *
      iclflge = mod( lclflge, 10 )
      iclel   = lclflge / 10
!...
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ic)
      do i = lnoes, lnoee
         do ic = 1, iclel
#else
      do ic = 1, iclel
!$OMP PARALLEL DO SCHEDULE(STATIC)
         do i = lnoes, lnoee
#endif
            if( sxe(i).lt.sclboe(1,ic).or.sxe(i).gt.sclboe(4,ic) ) cycle
            if( sye(i).lt.sclboe(2,ic).or.sye(i).gt.sclboe(5,ic) ) cycle
            if( sze(i).lt.sclboe(3,ic).or.sze(i).gt.sclboe(6,ic) ) cycle
!..
            if( iclflge .le. 2 ) then
               if( suxe(i).gt.s0o1.and.suue(i).gt.scluure(ic) ) then
                  lclfle(i) = ic
               end if
            end if
!..
            if( iclflge .ge. 2 ) then
               if( suxe(i).lt.s0o1.and.suue(i).gt.scluule(ic) ) then
                  lclfle(i) = ic
               end if
            end if
         end do
      end do
!....                                                   * do cooling *
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ic,wfac)
      do i = lnoes, lnoee
!..
         ic = lclfle(i)
         if( ic .eq. 0 ) cycle
!.                                           * check quit of cooling *
         wfac = suue(i) - scluu0e(ic)
         if( sxe(i).lt.sclboe(1,ic).or.sxe(i).gt.sclboe(4,ic) .or. &
             sye(i).lt.sclboe(2,ic).or.sye(i).gt.sclboe(5,ic) .or. &
             sze(i).lt.sclboe(3,ic).or.sze(i).gt.sclboe(6,ic) .or. &
             wfac .lt. s0o1 ) then
            lclfle(i) = 0
         else
            wfac = wfac * sclfcte(ic) / suue(i)
            sfxe(i) = sfxe(i) - suxe(i) * wfac
            sfye(i) = sfye(i) - suye(i) * wfac
            sfze(i) = sfze(i) - suze(i) * wfac
         end if
!..
      end do
!....
      call fdebug ( 'c3pec', 1 )
!....
      return
      end
