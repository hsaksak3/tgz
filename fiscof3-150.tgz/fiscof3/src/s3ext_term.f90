!----------------------------------------------------------------------
! Set 3D EXTernal system TERMinate
!
      subroutine s3ext_term
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
!....
      call frames_term
!..
      call gdfxs_term
!....
      return
      end
