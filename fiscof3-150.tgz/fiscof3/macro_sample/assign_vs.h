     _sv(_ix-1,_iy-1) = _sv(_ix-1,_iy-1) + _ss*_x1*_y1
     _sv(_ix  ,_iy-1) = _sv(_ix  ,_iy-1) + _ss*_x2*_y1
     _sv(_ix+1,_iy-1) = _sv(_ix+1,_iy-1) + _ss*_x3*_y1
     _sv(_ix+2,_iy-1) = _sv(_ix+2,_iy-1) + _ss*_x4*_y1
!
     _sv(_ix-1,_iy  ) = _sv(_ix-1,_iy  ) + _ss*_x1*_y2
     _sv(_ix  ,_iy  ) = _sv(_ix  ,_iy  ) + _ss*_x2*_y2
     _sv(_ix+1,_iy  ) = _sv(_ix+1,_iy  ) + _ss*_x3*_y2
     _sv(_ix+2,_iy  ) = _sv(_ix+2,_iy  ) + _ss*_x4*_y2
!
     _sv(_ix-1,_iy+1) = _sv(_ix-1,_iy+1) + _ss*_x1*_y3
     _sv(_ix  ,_iy+1) = _sv(_ix  ,_iy+1) + _ss*_x2*_y3
     _sv(_ix+1,_iy+1) = _sv(_ix+1,_iy+1) + _ss*_x3*_y3
     _sv(_ix+2,_iy+1) = _sv(_ix+2,_iy+1) + _ss*_x4*_y3
!
     _sv(_ix-1,_iy+2) = _sv(_ix-1,_iy+2) + _ss*_x1*_y4
     _sv(_ix  ,_iy+2) = _sv(_ix  ,_iy+2) + _ss*_x2*_y4
     _sv(_ix+1,_iy+2) = _sv(_ix+1,_iy+2) + _ss*_x3*_y4
     _sv(_ix+2,_iy+2) = _sv(_ix+2,_iy+2) + _ss*_x4*_y4
#include "interpolate_undef.h"
