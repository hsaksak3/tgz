#include "interpolate.macro"
!#include "spdat.macro"
!
do i = 1, n
!
#define _sx sxe(i)
#define _sy sye(i)
#include "interpolate_defxi.h"
#include "interpolate_xi.h"
#include "interpolate_defyi.h"
#include "interpolate_yi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#define _sv sde
#define _ss spfe(i)
#include "assign_vs.h"
!
#include "interpolate_defxh.h"
#include "interpolate_defyh.h"
#define _sv sdi
#include "assign_v.h"
!
end do
!
stop
end
