#include "interpolate.macro"
!#include "spdat.macro"
!
do i = 1, n
!
#define _sx sxe(i)
#include "interpolate_defxi.h"
#include "interpolate_xi.h"
#include "interpolate_defxh.h"
#include "interpolate_xh.h"
#define _sy sye(i)
#include "interpolate_defyi.h"
#include "interpolate_yi.h"
#include "interpolate_defyh.h"
#include "interpolate_yh.h"
!
#include "interpolate_defxh.h"
#include "interpolate_defyi.h"
#define _wv wex
#define _sv sex
#include "interpolate_v.h"
!
#include "interpolate_defxh.h"
#include "interpolate_defyh.h"
#define _wv wez
#define _sv sez
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyh.h"
#define _wv wey
#define _sv sey
#include "interpolate_v.h"
!
end do
!
stop
end
