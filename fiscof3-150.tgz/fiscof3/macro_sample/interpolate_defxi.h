#define _ix ixi
#define _dx wxdi
#define _x1 wx1i
#define _x2 wx2i
#define _x3 wx3i
#define _x4 wx4i
