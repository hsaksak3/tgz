     _wv = ( _sv(_ix-1,_iy-1)*_x1 + _sv(_ix  ,_iy-1)*_x2 + &
             _sv(_ix+1,_iy-1)*_x3 + _sv(_ix+2,_iy-1)*_x4 )*_y1 &
         + ( _sv(_ix-1,_iy  )*_x1 + _sv(_ix  ,_iy  )*_x2 + &
             _sv(_ix+1,_iy  )*_x3 + _sv(_ix+2,_iy  )*_x4 )*_y2 &
         + ( _sv(_ix-1,_iy+1)*_x1 + _sv(_ix  ,_iy+1)*_x2 + &
             _sv(_ix+1,_iy+1)*_x3 + _sv(_ix+2,_iy+1)*_x4 )*_y3 &
         + ( _sv(_ix-1,_iy+2)*_x1 + _sv(_ix  ,_iy+2)*_x2 + &
             _sv(_ix+1,_iy+2)*_x3 + _sv(_ix+2,_iy+2)*_x4 )*_y4
#include "interpolate_undef.h"
