#include "interpolate.macro"
!#include "spdat.macro"
!
      do i = lnoes, lnoee
#define _fxo wffxo
#define _fxn wffxn
#define _fyo wffyo
#define _fyn wffyn
         _fxn(1) = s0o1
         _fxn(2) = s0o1
         _fxn(5) = s0o1
         _fxn(6) = s0o1
         _fyn(1) = s0o1
         _fyn(2) = s0o1
         _fyn(5) = s0o1
         _fyn(6) = s0o1
!..
#define _sx sxeo(i)
#define _ixo ixo
#include "interpolate_defjxo.h"
#include "interpolate_xi.h"
!
#define _sy syeo(i)
#define _iyo iyo
#include "interpolate_defjyo.h"
#include "interpolate_yi.h"
!.
#undef _sx
#define _sx sxe(i)
#include "interpolate_defjxn.h"
#define _ixd ixd
#include "interpolate_xi.h"
!.
#undef _sy
#define _sy sye(i)
#include "interpolate_defjyn.h"
#define _iyd iyd
#include "interpolate_yi.h"
!..
         do ii = 1, 6
            wdffx(ii) = _fxn(ii) - _fxo(ii)
            wdffy(ii) = _fyn(ii) - _fyo(ii)
         end do
!..
         do ij = 1, 6
            do ii = 1, 6
               wdjx(ii,ij) = spfe(i) * wdffx(ii) &
                             * ( _fyo(ij) + s1o2 * wdffy(ij) )
               wdjy(ii,ij) = spfe(i) * wdffy(ij) &
                             * ( _fxo(ii) + s1o2 * wdffx(ii) )
            end do
         end do
!..
         do ij = 1, 6
            wjxe(1,ij) = wdjx(1,ij)
            wjye(ij,1) = wdjy(ij,1)
            do ii = 1, 5
               wjxe(ii+1,ij) = wjxe(ii,ij) + wdjx(ii+1,ij)
               wjye(ij,ii+1) = wjye(ij,ii) + wdjy(ij,ii+1)
            end do
         end do
!..
         do ij = 1, 6
            iy = ij + _iyo - 3
            do ii = 1, 6
               ix = ii + _ixo - 3
               wjxea(ix+1,iy) = wjxea(ix+1,iy) + wjxe(ii,ij)
               wjyea(ix,iy+1) = wjyea(ix,iy+1) + wjye(ii,ij)
            end do
         end do
      end do
!....
      return
      end
