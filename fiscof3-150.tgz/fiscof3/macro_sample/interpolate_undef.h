#include "interpolate_undefx.h"
#include "interpolate_undefy.h"
#undef _wv
#undef _sv
#undef _ss
