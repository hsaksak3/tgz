!----------------------------------------------------------------------
! Observe 2D Field Current Electron
!                          /
      subroutine o2fje ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/06/02
! modified by Sakagami,H. (NIFS) 10/09/30:hot(Vx>0.7c) and cold
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 28, ifn = 9
      integer :: kflag, i, iofje, int, ix, iy, ixy, ixz, iwfjea
      real*8  :: wampx, wvv
      real*8, allocatable :: wfjx(:),  wfjy(:),  wfjz(:), &
                             wfjxh(:), wfjyh(:), wfjzh(:), &
                             wfjxc(:), wfjyc(:), wfjzc(:)
      save
!....
      call fdebug ( 'o2fje', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwfjea = iwfjea + 1
!..
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP          REDUCTION(+:wfjxh,wfjyh,wfjzh,wfjxc,wfjyc,wfjzc), &
!$OMP          PRIVATE(ix,iy,ixy,wvv)
         do i = lnoes, lnoee
            ix = sxe(i)
            iy = sye(i)
            if( ix .ge. loxps .and. ix .le. loxpe .and. &
                iy .ge. loyps .and. iy .le. loype ) then
               if( mod(ix-loxps,loxpi) .eq. 0 .and. &
                   mod(iy-loyps,loypi) .eq. 0 ) then
                  ix = ( ix - loxps ) / loxpi + 1
                  iy = ( iy - loyps ) / loypi
                  ixy = ix + iy * loxpl
!++++
                  if( ixy .lt. 1 .or. ixy .gt. loxypl )  &
                    write(0,*) '### WARNING: o2fje', ix, iy, ixy
!++++
! velovcity       wvv = suue(i) / sqrt( s1o1 + suue(i)**2 * scg1 )
                  if( ixz .ne. 1 ) then
                     wvv = svxe(i)
                  else
                     wvv = svze(i)
                  end if
                  if( wvv .gt. sofjehot ) then
                     wfjxh(ixy) = wfjxh(ixy) - svxe(i) * spfe(i)
                     wfjyh(ixy) = wfjyh(ixy) - svye(i) * spfe(i)
                     wfjzh(ixy) = wfjzh(ixy) - svze(i) * spfe(i)
                  else
                     wfjxc(ixy) = wfjxc(ixy) - svxe(i) * spfe(i)
                     wfjyc(ixy) = wfjyc(ixy) - svye(i) * spfe(i)
                     wfjzc(ixy) = wfjzc(ixy) - svze(i) * spfe(i)
                  end if
               end if
            end if
         end do
!..
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            wampx = -1.0d30
            do i = 1, loxypl
               wfjxh(i) = wfjxh(i) / ( iwfjea * snepm1 * scfl )
               wfjyh(i) = wfjyh(i) / ( iwfjea * snepm1 * scfl )
               wfjzh(i) = wfjzh(i) / ( iwfjea * snepm1 * scfl )
               wfjxc(i) = wfjxc(i) / ( iwfjea * snepm1 * scfl )
               wfjyc(i) = wfjyc(i) / ( iwfjea * snepm1 * scfl )
               wfjzc(i) = wfjzc(i) / ( iwfjea * snepm1 * scfl )
               wfjx(i)  = wfjxh(i) + wfjxc(i)
               wfjy(i)  = wfjyh(i) + wfjyc(i)
               wfjz(i)  = wfjzh(i) + wfjzc(i)
               wampx = max( wampx, &
                            wfjx(i)**2  + wfjy(i)**2  + wfjz(i)**2, &
                            wfjxh(i)**2 + wfjyh(i)**2 + wfjzh(i)**2, &
                            wfjxc(i)**2 + wfjyc(i)**2 + wfjzc(i)**2 )
            end do
            wampx = sqrt( wampx )
!..
            if( iofje .le. 4 ) then
               write(iun) sstcur, &
                  (wfjx(i),wfjy(i),wfjz(i),i=1,loxypl), &
                  (wfjxh(i),wfjyh(i),wfjzh(i),i=1,loxypl), &
                  (wfjxc(i),wfjyc(i),wfjzc(i),i=1,loxypl), wampx
               flush(iun)
            end if
            if( iofje .ge. 2 ) then
               call o2fdraw5 ( bident, sstcur, ifn, 2, int, 2, &
                    wampx, wfjx, wfjy, wfjz, loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
                    'fjxe', 'fjye', 'fjze', 'fjxye', 'fjyze', 'fjxze' )
               call o2fdraw5 ( bident, sstcur, ifn, 3, int, 1, &
                    wampx, wfjxh, wfjyh, wfjzh, loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
  'fjxe[h]', 'fjye[h]', 'fjze[h]', 'fjxye[h]', 'fjyze[h]', 'fjxze[h]' )
               call o2fdraw5 ( bident, sstcur, ifn, 3, int, 4, &
                    wampx, wfjxc, wfjyc, wfjzc, loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
  'fjxe[c]', 'fjye[c]', 'fjze[c]', 'fjxye[c]', 'fjyze[c]', 'fjxze[c]' )
            end if
          end if
!....
         else
            iofje = mod( lofje, 10 )
            ixz   = mod( lofje/10, 10 )
            int   = lofje/100
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wfjx) ) &
                 allocate( wfjx(loxypl), wfjy(loxypl), wfjz(loxypl), &
                     wfjxh(loxypl), wfjyh(loxypl), wfjzh(loxypl), &
                     wfjxc(loxypl), wfjyc(loxypl), wfjzc(loxypl) )
            end if
!
            if( iofje .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fje', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
               write(iun) 'fje2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
               flush(iun)
            end if
            if( iofje .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fje', bfile )
               call frames_file ( bfile, ifn, iofje )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwfjea = 0
            do i = 1, loxypl
               wfjxh(i) = s0o1
               wfjyh(i) = s0o1
               wfjzh(i) = s0o1
               wfjxc(i) = s0o1
               wfjyc(i) = s0o1
               wfjzc(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fje', 1 )
!....
      return
      end
