!----------------------------------------------------------------------
! Observe 2D Particle Ion PHase space
!                           /
      subroutine o2piph ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
! modified by Sakagami,H. ( NIFS ) 15/11/27 for include in fiscof2
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use observe
      use particle
      use profile
      include "implicit.h"
      integer :: kflag, i, io, is, iu, ix, iy, iopiph, ilog, iopiphl
      integer, parameter :: lgphxx = 100, lgphux = 50
      integer, parameter :: iun = 38, ifn = 18
      real*8  :: wopiphxps(lopiphx), wopiphxpe(lopiphx)
      real*8  :: wopiphyps(lopiphx), wopiphype(lopiphx)
      real*8  :: wopiphuxm(lopiphx), wopiphuxx(lopiphx)
      real*8  :: wopiphxpr(lopiphx), wopiphuxr(lopiphx)
      real*8, allocatable :: apiphn(:,:,:,:)
      character :: clabel*20
      save

      call fdebug ( 'o2piph', 0 )

      if( kflag .ge. 1 ) then

        do is = 1, lionspl
           do io = 1, iopiphl
              do iu = 1, lgphux
                 do ix = 1, lgphxx
                    apiphn(ix,iu,io,is) = s0o1
                 end do
              end do
           end do
        end do

        do is = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:apiphn), &
!$OMP             PRIVATE(io,ix,iy)
           do i = lionids(is), lionide(is)
              do io = 1, iopiphl
                 if( sxi(i).ge.sopiphxps(io) .and. &
                     sxi(i).le.sopiphxpe(io) ) then
                   if( syi(i).ge.sopiphyps(io) .and. &
                       syi(i).le.sopiphype(io) ) then
                     if( suxi(i).ge.sopiphuxm(io) .and. &
                         suxi(i).le.sopiphuxx(io) ) then
                         ix = ( sxi(i) - sopiphxps(io) ) / &
                         ( sopiphxpe(io) - sopiphxps(io) ) * lgphxx + 1
                         ix = max( ix, 1 )
                         ix = min( ix, lgphxx )
                         iy = ( suxi(i) - sopiphuxm(io) ) / &
                         ( sopiphuxx(io) - sopiphuxm(io) ) * lgphux + 1
                         iy = max( iy, 1 )
                         iy = min( iy, lgphux )
                         apiphn(ix,iy,io,is) = apiphn(ix,iy,io,is) + &
                            spfi(i) / ( wopiphxpr(io) * wopiphuxr(io) )
                     end if
                   end if
                 end if
              end do
           end do
        end do

        if( iopiph .le. 4 ) then
           write(iun) sstcur,((((apiphn(ix,iu,io,is), ix=1, lgphxx), &
                    iu=1, lgphux), io=1, iopiphl), is=1, lionspl )
           flush(iun)
        end if

        if( iopiph .ge. 2 ) then
          do is = 1, lionspl
            call o2ionlabel ( is, sionam(is), sionaz(is), clabel )
            do io = 1, iopiphl
              call o2pdrawph ( bident, sstcur, sminlog, lminlog, &
                     ifn, ilog, 3, apiphn(1,1,io,is), lgphxx, lgphux, &
                         wopiphxps(io), wopiphyps(io), wopiphxpe(io), &
                         wopiphype(io), wopiphuxm(io), wopiphuxx(io), &
                         'x[micron]', 'Ux/c', 'piph'//clabel )
            end do
          end do
        end if

      else
        iopiph = mod( lopiph, 10 )
        ilog   = mod( lopiph/10, 10 )
        iopiphl = lopiph/100

        if( .not. allocated(apiphn) ) &
           allocate( apiphn(lgphxx,lgphux,iopiphl,lionspl) )

        do io = 1, iopiphl
           if( sopiphxps(io) .le. sundef ) then
               sopiphxps(io) = lxps
           else
               sopiphxps(io) = sopiphxps(io) * slmic + loxp0
           end if
           if( sopiphxpe(io) .le. sundef ) then
               sopiphxpe(io) = lxpe
           else
               sopiphxpe(io) = sopiphxpe(io) * slmic + loxp0
           end if
           if( sopiphyps(io) .le. sundef ) then
               sopiphyps(io) = lyps
           else
               sopiphyps(io) = sopiphyps(io) * slmic + loyp0
           end if
           if( sopiphype(io) .le. sundef ) then
               sopiphype(io) = lype
           else
               sopiphype(io) = sopiphype(io) * slmic + loyp0
           end if
           wopiphxps(io) = ( sopiphxps(io) - loxp0 ) * slmicinv
           wopiphxpe(io) = ( sopiphxpe(io) - loxp0 ) * slmicinv
           wopiphyps(io) = ( sopiphyps(io) - loyp0 ) * slmicinv
           wopiphype(io) = ( sopiphype(io) - loyp0 ) * slmicinv
           wopiphxpr(io) = ( wopiphxpe(io) - wopiphxps(io) ) / lgphxx
           if( lrank .le. 0 ) &
           write(6,*) 'wopiph[xy]p[se] = ', io, &
             wopiphxps(io), wopiphyps(io), wopiphxpe(io), wopiphype(io)
           wopiphuxm(io) = sopiphuxm(io)
           wopiphuxx(io) = sopiphuxx(io)
           sopiphuxm(io) = sopiphuxm(io) * scfl
           sopiphuxx(io) = sopiphuxx(io) * scfl
           wopiphuxr(io) = ( wopiphuxx(io) - wopiphuxm(io) ) / lgphux
           if( lrank .le. 0 ) &
           write(6,*) 'wopiphux[mx] = ', io, wopiphuxm(io), &
                       wopiphuxx(io)
        end do
        if( iopiph .le. 4 ) then
           call fntpcnv ( bbifntp, lrank,iun, bident,'piph', bfile )
           open( iun, file=bfile, form='UNFORMATTED' )
           write(iun) 'pih2', bident, lgphxx,lgphux,iopiphl,lionspl, &
            ( sionam(is),sionaz(is),is=1,lionspl ), &
            ( wopiphxps(io),wopiphyps(io),wopiphxpe(io),wopiphype(io), &
              wopiphuxm(io),wopiphuxx(io),io =1,iopiphl )
           flush(iun)
        end if
        if( iopiph .ge. 2 ) then
           call fntpcnv ( bfrfntp, lrank,ifn, bident,'piph', bfile )
           call frames_file ( bfile, ifn, iopiph )
        end if

      end if

      call fdebug ( 'o2piph', 1 )

      return
      end
