!----------------------------------------------------------------------
! debug
!
module debug
      integer, parameter :: lsubx = 37
      integer :: ldebug, lsubcn(lsubx)
      real*8 ::  dtotst, dsubst(lsubx), dsubsm(lsubx)
      character :: bsubnm(lsubx)*8
end module debug
