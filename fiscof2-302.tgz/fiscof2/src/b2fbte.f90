!-----------------------------------------------------------------------
! Boundary condition 2D Field magnetic(B) - TE
!                           /
      subroutine b2fbte ( kmode )
!
!   <arguments>
!     kmode : 0 = for all conditions except PML
!           : 1 = for all conditions
!
!   <remarks>
!     sbx(0,iy), sbx(lssxup2,iy), sby(ix,0), sby(ix,lssyup2) are just
!   needed for references by particles.
!     Only periodic and PML conditions are correctly cared.
!
! original coded by Hata,M. (Nagoya Univ.) 11/06/23
!    coded by Sakagami,H. (NIFS) 11/07/27
!----------------------------------------------------------------------
#include "sfield.macro"
      use control
      use field
      include "implicit.h"
      integer :: ix, iy, kmode
      save
!....
      call fdebug ( 'b2fbte', 0 )
!....
!$OMP PARALLEL
!....
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sbx(lssxlm1,iy) = sbx(lssxum1,iy)
         end do
!..
      else if( lexlf .eq. 2 .or. lexlf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sbx(lssxlm1,iy) = sbx(lssxl,iy)
         end do
!..
      else if( lexlf .eq. 4 .and. kmode .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lblxl, lssxlm1
               sbx(ix,iy) = sbx(ix,iy) - ( sez(ix,iy+1) - sez(ix,iy) )
            end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lblyl, lblyu
            do ix = lblxlm1, lssxlm2
               sby(ix,iy) = scaxlh(ix) * sby(ix,iy) + &
                 scbbtexl(ix) * sez(ix+1,iy) - sccbtexl(ix) * sez(ix,iy)
            end do
         end do
      end if
!....
      if( lexuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sbx(lssxup2,iy) = sbx(lssxlp2,iy)
         end do
!..
      else if( lexuf .eq. 2 .or. lexuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sbx(lssxup2,iy) = sbx(lssxup1,iy)
         end do
!..
      else if( lexuf .eq. 4 .and. kmode .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lssxup2, lblxu
               sbx(ix,iy) = sbx(ix,iy) - ( sez(ix,iy+1) - sez(ix,iy) )
            end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lblyl, lblyu
            do ix = lssxup2, lblxu
               sby(ix,iy) = scaxuh(ix) * sby(ix,iy) + &
                 scbbtexu(ix) * sez(ix+1,iy) - sccbtexu(ix) * sez(ix,iy)
            end do
         end do
      end if
!....
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sby(ix,lssylm1) = sby(ix,lssyum1)
         end do
!..
      else if( leylf .eq. 2 .or. leylf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sby(ix,lssylm1) = sby(ix,1)
         end do
!..
      else if( leylf .eq. 4 .and. kmode .ne. 0 ) then
         do iy = lblylm1, lssylm2
!$OMP DO SCHEDULE(STATIC)
            do ix = lblxl, lblxu
               sbx(ix,iy) = scaylh(iy) * sbx(ix,iy) - &
                 scbbteyl(iy) * sez(ix,iy+1) + sccbteyl(iy) * sez(ix,iy)
            end do
         end do
!.
         do iy = lblyl, lssylm1
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup1
               sby(ix,iy) = sby(ix,iy) + ( sez(ix+1,iy) - sez(ix,iy) )
            end do
         end do
      end if
!....
      if( leyuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sby(ix,lssyup2) = sby(ix,lssylp2)
         end do
!..
      else if( leyuf .eq. 2 .or. leyuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sby(ix,lssyup2) = sby(ix,lssyup1)
         end do
!..
      else if( leyuf .eq. 4 .and. kmode .ne. 0 ) then
         do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
            do ix = lblxl, lblxu
               sbx(ix,iy) = scayuh(iy) * sbx(ix,iy) - &
                 scbbteyu(iy) * sez(ix,iy+1) + sccbteyu(iy) * sez(ix,iy)
            end do
         end do
!.
         do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup1
               sby(ix,iy) = sby(ix,iy) + ( sez(ix+1,iy) - sez(ix,iy) )
            end do
         end do
      end if
!....
!$OMP END PARALLEL
!....
      call fdebug ( 'b2fbte', 1 )
!....
      return
      end
