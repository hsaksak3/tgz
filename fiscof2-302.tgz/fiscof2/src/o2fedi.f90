!----------------------------------------------------------------------
! Observe 2D Field Energy Density Ion
!                           /
      subroutine o2fedi ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 12/05/30
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 36, ifn = 16
      integer :: kflag, i, is, iofedi, ix, iy, ixy
      real*8, allocatable :: wfedi(:,:)
      character*20 clabel
      save
!....
      call fdebug ( 'o2fedi', 0 )
!....
      if( kflag .ge. 1 ) then
       if( loxypl .gt. 0 ) then
!...
         do is = 1, lionspl
           do i = 1, loxypl
             wfedi(i,is) = s0o1
           end do
         end do
!..
         do is = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wfedi), &
!$OMP          PRIVATE(ix,iy,ixy)
           do i = lionids(is), lionide(is)
             ix = sxi(i)
             iy = syi(i)
             if( ix .ge. loxps .and. ix .le. loxpe .and. &
                 iy .ge. loyps .and. iy .le. loype ) then
                if( mod(ix-loxps,loxpi) .eq. 0 .and. &
                    mod(iy-loyps,loypi) .eq. 0 ) then
                    ix = ( ix - loxps ) / loxpi + 1
                    iy = ( iy - loyps ) / loypi
                    ixy = ix + iy * loxpl
!++++
                    if( ixy .lt. 1 .or. ixy .gt. loxypl )  &
                      write(0,*) '### WARNING: o2fedi', ix, iy, ixy
!++++
                    wfedi(ixy,is) = wfedi(ixy,is) +  &
               ( sqrt( s1o1+suui(i)**2*scg1 )-s1o1 )*sionmm(is)*spfi(i)
               end if
             end if
           end do
         end do
!..
         do is = 1, lionspl
           do i = 1, loxypl
             wfedi(i,is) = wfedi(i,is) / snepm1
           end do
         end do
!..
         if( iofedi .le. 4 ) then
            write(iun) sstcur, ((wfedi(i,is),i=1,loxypl),is=1,lionspl)
            flush(iun)
         end if
         if( iofedi .ge. 2 ) then
            do is = 1, lionspl
               call o2ionlabel ( is, sionam(is), sionaz(is), clabel )
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                               ifn, 0, 1, 0, 0, & 
                               wfedi(1,is), loxpl, loypl,  &
                       soxmic, soxp0m, soymic, soyp0m, 'fedi'//clabel )
            end do
         end if
       end if
!....
      else
         iofedi = lofedi
!..
         if( loxypl .gt. 0 ) then
            if(.not.allocated(wfedi)) allocate( wfedi(loxypl,lionspl) )
         end if
!
         if( iofedi .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fEi', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'fEi2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(is),sionaz(is),is=1,lionspl)
            flush(iun)
         end if
         if( iofedi .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fEi', bfile )
            call frames_file ( bfile, ifn, iofedi )
         end if
      end if
!....
      call fdebug ( 'o2fedi', 1 )
!....
      return
      end
