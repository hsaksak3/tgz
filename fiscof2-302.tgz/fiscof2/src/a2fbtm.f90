!-----------------------------------------------------------------------
! Advance 2D Field magnetic(B) - TM (half step)
!
      subroutine a2fbtm
!
!   <arguments>
!     none
!
!   <remarks>
!     "sdeyxdxy" was already divided by 2 for an half step and changed
!    its sign.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use field
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'a2fbtm', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sbz(ix,iy) = sbz(ix,iy) + sdeyxdxy(ix,iy)
         end do
      end do
!....
      call fdebug ( 'a2fbtm', 1 )
!....
      return
      end
