!-----------------------------------------------------------------------
! Advance 2D Particle Electron Position ( half step )
!                          /
      subroutine a2pep ( kmode )
!
!   <arguments>
!     kmode : mode 1 = save data
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i, kmode
      save
!....
      call fdebug( 'a2pep',0 )
!....
!$OMP PARALLEL
      if( kmode .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do i = lnoes, lnoee
            sxeo(i) = sxe(i)
            syeo(i) = sye(i)
         end do
      end if
!$OMP DO SCHEDULE(STATIC)
      do i = lnoes, lnoee
         sxe(i) = sxe(i) + svxe(i) * s1o2
         sye(i) = sye(i) + svye(i) * s1o2
      end do
!$OMP END PARALLEL
!....
      call fdebug( 'a2pep', 1 )
!....
      return
      end
