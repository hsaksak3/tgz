!----------------------------------------------------------------------
! Debug
!                           /      /
      subroutine fdebug ( ename, kmode )
!
!   <arguments>
!     ename : subroutine name
!     kmode : 0 = entry, 1 = exit, -1 = start, -2 = end
!
!   <remarks>
!     ldebug :   1 = cpu time measurement mode
!            : >=2 = check write mode ( larger ldebug, more output )
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
      use debug
      include "implicit.h"
      integer :: kmode, indent=1, i, isubn, ix
      real*8  :: fgetwtod, asum, asump, atot
      character cdata*32, cname*8, ename*(*)
!$    integer OMP_GET_MAX_THREADS
      save
!....
      if( kmode .eq. -1 ) then
         call fdate ( cdata )
         write(6,*) '+++++ ',trim(ename),' started at ',cdata(1:24),' +++++'
!$       write(6,*) '+++++ OMP_GET_MAX_THREADS = ', OMP_GET_MAX_THREADS()
!$       cdata = ' '
!$       call getenv ( 'OMP_STACKSIZE', cdata )
!$       if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$       write(6,*) '+++++ OMP_STACKSIZE = ', trim(cdata)
!...             * comment because ldebug is undefined at this moment *
!cc      if ( ldebug .eq. 1 ) then
            dtotst = fgetwtod()
            bsubnm(01) = 'a2fbte'
            bsubnm(02) = 'a2fbtm'
            bsubnm(03) = 'a2fete'
            bsubnm(04) = 'a2fetm'
            bsubnm(05) = 'a2flsr'
            bsubnm(06) = 'a2pem'
            bsubnm(07) = 'a2pep'
            bsubnm(08) = 'a2pim'
            bsubnm(09) = 'a2pip'
            bsubnm(10) = 'b2fbte'
            bsubnm(11) = 'b2fbtm'
            bsubnm(12) = 'b2fete'
            bsubnm(13) = 'b2fetm'
            bsubnm(14) = 'b2pep'
            bsubnm(15) = 'b2pip'
            bsubnm(16) = 'c2fde'
            bsubnm(17) = 'c2fdi'
            bsubnm(18) = 'c2fed'
            bsubnm(19) = 'c2fje'
            bsubnm(20) = 'c2fjecc'
            bsubnm(21) = 'c2fji'
            bsubnm(22) = 'c2fjicc'
            bsubnm(23) = 'c2fjt'
            bsubnm(24) = 'c2flsr'
            bsubnm(25) = 'c2pec'
            bsubnm(26) = 'c2pef'
            bsubnm(27) = 'c2pev'
            bsubnm(28) = 'c2pic'
            bsubnm(29) = 'c2pif'
            bsubnm(30) = 'c2piv'
            bsubnm(31) = 'o2anim'
            bsubnm(32) = 's2cnst'
            bsubnm(33) = 's2init'
            bsubnm(34) = 's2qstr'
            bsubnm(35) = 's2rest'
            bsubnm(36) = 's2rstr'
            bsubnm(37) = 's2simp'
            do i = 1, lsubx
               dsubsm(i) = 0.0d0
               lsubcn(i) = 0
            end do
!cc      end if
      else if( kmode .eq. -2 ) then
         call fdate ( cdata )
         write(6,*) '----- ',trim(ename),' ended at ',cdata(1:24),' -----'
!$       write(6,*) '----- OMP_GET_MAX_THREADS = ', OMP_GET_MAX_THREADS()
!$       cdata = ' '
!$       call getenv ( 'OMP_STACKSIZE', cdata )
!$       if( cdata(1:1) .eq. ' ' ) cdata = '*UNDEFINED*'
!$       write(6,*) '----- OMP_STACKSIZE = ', trim(cdata)
         if ( ldebug .eq. 1 ) then
            atot = fgetwtod() - dtotst
            asum = 0.0d0
            asump = 0.0d0
            write(6,1000)
            do i = 1, lsubx
               asum = asum + dsubsm(i)
               asump = asump + dsubsm(i)/atot*100.0d0
               write(6,1100) bsubnm(i), dsubsm(i), &
                            dsubsm(i)/atot*100.0d0, lsubcn(i)
            end do
            write(6,1000)
            write(6,1100) 'sum', asum, asump, 0
            write(6,1000)
            write(6,1100) 'total', atot, 100.0, 0
            write(6,1000)
         end if
      end if
!...
      if ( ldebug .eq. 1 ) then
         cname = ename
         isubn = 0
         do i = 1, lsubx
            if( cname .eq. bsubnm(i) ) then
               isubn = i
               exit
            end if
         end do
         if( kmode .eq. 0 ) then
            if( isubn .ne. 0 ) then
               dsubst(isubn) = fgetwtod()
            end if
         else if( kmode .eq. 1 ) then
            if( isubn .ne. 0 ) then
               dsubsm(isubn) = dsubsm(isubn) + &
                                        fgetwtod() - dsubst(isubn)
               lsubcn(isubn) = lsubcn(isubn) + 1
            end if
         end if
      end if
!...
      if ( ldebug .ge. 2 ) then
         cname = ename
         if( kmode .eq. 0 ) then
            indent = indent + 1
            if( indent .le. ldebug ) then
               ix = (indent-1)*3 + 1
               cdata = '( nnx,''+++ '', a8, '' +++'' )'
               write( cdata(3:4), '(i2)' ) ix
               write(6, cdata ) cname
            end if
         else if( kmode .eq. 1 ) then
            if( indent .le. ldebug ) then
               ix = (indent-1)*3 + 1
               cdata = '( nnx,''--- '', a8, '' ---'' )'
               write( cdata(3:4), '(i2)' ) ix
               write(6, cdata ) cname
            end if
            indent = indent - 1
         end if
      end if
!....
      return
 1000 format( ' +----------+--------------+--------+------------+' )
 1100 format( ' | ', a8, ' | ', f12.2, ' | ', f6.2, ' | ', i10, ' |' )
      end
