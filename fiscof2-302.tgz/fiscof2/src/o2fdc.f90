!----------------------------------------------------------------------
! Observe 2D Field Density Charge
!                          /
      subroutine o2fdc ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use field
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 41, ifn = 21
      integer :: kflag, i, io, iofdc, icrsx, icrsy, ix, iy, ixy, &
                 iwdca
      real*8 :: wminlog
      real*8, allocatable :: wdca(:)
      save
!....
      call fdebug ( 'o2fdc', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         if( lcfde .eq. 0 ) call c2fde
         if( lcfdi .eq. 0 ) call c2fdi
         iwdca = iwdca + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wdca(ixy) = wdca(ixy) - sde(ix,iy)
            end do
         end do
         if( lionspl .gt. 0 ) then
            do io = 1, lionspl
               ixy = 0
               do iy = loyps, loype, loypi
                  do ix = loxps, loxpe, loxpi
                     ixy = ixy + 1
                     wdca(ixy) = wdca(ixy) + sdi(ix,iy,io) * sionaz(io)
                  end do
               end do
            end do
         else
            ixy = 0
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  ixy = ixy + 1
                  wdca(ixy) = wdca(ixy) + sde0(ix,iy)
               end do
            end do
         end if
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do i = 1, loxypl
               wdca(i) = wdca(i) / ( iwdca * snepm1 )
            end do
            if( iofdc .le. 4 ) then
               write(iun) sstcur, ( wdca(i),i=1,loxypl )
               flush(iun)
            end if
            if( iofdc .ge. 2 ) then
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                               ifn, 0, 2, icrsx, icrsy, &
                               wdca, loxpl, loypl,  &
                               soxmic, soxp0m, soymic, soyp0m, 'fdc ' )
            end if
          end if
!....
         else
            iofdc = mod( lofdc, 10 )
            icrsx = mod( lofdc/100, 100 )
            icrsy = lofdc/10000
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wdca) ) allocate( wdca(loxypl) )
            end if
!
            if( iofdc .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fdc', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
               write(iun) 'fdc2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
               flush(iun)
            end if
            if( iofdc .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fdc', bfile )
               call frames_file ( bfile, ifn, iofdc )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwdca = 0
            do i = 1, loxypl
               wdca(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fdc', 1 )
!....
      return
      end
