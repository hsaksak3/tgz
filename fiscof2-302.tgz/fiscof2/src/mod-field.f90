!----------------------------------------------------------------------
! field
!
module field
      integer :: lcfde, lcfdi
      real*8, allocatable, save :: &
        sdeo(:,:), sdio(:,:,:)
      real*8, allocatable, save :: &
        sde0(:,:), sdi(:,:,:), &
        scaxlh(:),scbbtexl(:),sccbtexl(:),scbetmxl(:),sccetmxl(:), &
        scaxl(:), scbetexl(:),sccetexl(:),scbbtmxl(:),sccbtmxl(:), &
        scaxuh(:),scbbtexu(:),sccbtexu(:),scbetmxu(:),sccetmxu(:), &
        scaxu(:), scbetexu(:),sccetexu(:),scbbtmxu(:),sccbtmxu(:), &
        scaylh(:),scbbteyl(:),sccbteyl(:),scbetmyl(:),sccetmyl(:), &
        scayl(:), scbeteyl(:),scceteyl(:),scbbtmyl(:),sccbtmyl(:), &
        scayuh(:),scbbteyu(:),sccbteyu(:),scbetmyu(:),sccetmyu(:), &
        scayu(:), scbeteyu(:),scceteyu(:),scbbtmyu(:),sccbtmyu(:)
      real*8, allocatable, save :: &
        sde(:,:), &
        sebxy(:,:,:), sez(:,:), sbz(:,:), sjxyzt(:,:,:), &
        sdezdy(:,:), sdezdx(:,:), sdeyxdxy(:,:), &
        sjxe(:,:),   sjye(:,:),   sjze(:,:), &
        sjxi(:,:,:), sjyi(:,:,:), sjzi(:,:,:), &
        sezxxl(:,:), sezyxl(:,:), sbzxxl(:,:), sbzyxl(:,:), &
        sezxxu(:,:), sezyxu(:,:), sbzxxu(:,:), sbzyxu(:,:), &
        sezxyl(:,:), sezyyl(:,:), sbzxyl(:,:), sbzyyl(:,:), &
        sezxyu(:,:), sezyyu(:,:), sbzxyu(:,:), sbzyyu(:,:)
#ifdef VECTOR
!     real*8, allocatable, save :: vwjw1(:,:,:), vwjw2(:,:,:)
!     real*8, allocatable, save :: &
!       vwffxo(:,:), vwffx(:,:), vwjjx(:,:,:), &
!       vwffyo(:,:), vwffy(:,:), vwjjy(:,:,:)
#endif
end module field
