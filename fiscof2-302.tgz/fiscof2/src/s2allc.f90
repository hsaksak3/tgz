!-------------------------------------------------------------------
! Set 2D ALLoCate array
!                           /
      subroutine s2allc ( kmode )
!
!   <arguments>
!     kmode :  = 0 --> allocate particle array
!           : != 0 --> allocate field array
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/28
! modified by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
      use parameter
      use constant
      use particle
      use field
      include "implicit.h"
      integer :: kmode
      save
!....
      call fdebug ( 's2allc', 0 )
!....                                                      * particle *
      if( kmode .eq. 0 ) then
         allocate( spdat1(lnox), spdat2(lnox) )
!...                                                          * field *
      else
         allocate ( &
         sdeo(lssxlm1:lssxup1,lssylm1:lssyup1), &
         sdio(lssxlm1:lssxup1,lssylm1:lssyup1,lionspx) &
         )
         allocate ( &
         sde0(lssxlm1:lssxup1,lssylm1:lssyup1), &
         sde(lssxlm1:lssxup1,lssylm1:lssyup1), &
         sdi(lssxlm1:lssxup1,lssylm1:lssyup1,lionspl), &
         sebxy(4,lblxlm1:lblxup1,lblylm1:lblyup1), &
         sez(lblxlm1:lblxup1,lblylm1:lblyup1), &
         sbz(lblxlm1:lblxup1,lblylm1:lblyup1), &
         sjxyzt(3,lssxlm2:lssxup3,lssylm2:lssyup3), &
         sdezdy(lssxl:lssxup1,lssylm1:lssyup1), &
         sdezdx(lssxlm1:lssxup1,lssyl:lssyup1), &
         sdeyxdxy(lssxl:lssxup1,lssyl:lssyup1), &
         sjxe(lssxlm2:lssxup3,lssylm2:lssyup2), &
         sjxi(lssxlm2:lssxup3,lssylm2:lssyup2,lionspl), &
         sjye(lssxlm2:lssxup2,lssylm2:lssyup3), &
         sjyi(lssxlm2:lssxup2,lssylm2:lssyup3,lionspl), &
         sjze(lssxlm1:lssxup2,lssylm1:lssyup2), &
         sjzi(lssxlm1:lssxup2,lssylm1:lssyup2,lionspl), &
         sezxxl(lblxl:lssxlm1,lblyl:lblyu), &
         sezyxl(lblxl:lssxlm1,lssyl:lssyup1), &
         sbzxxl(lblxl:lssxlm1,lblyl:lblyu), &
         sbzyxl(lblxl:lssxlm1,lssyl:lssyup1), &
         sezxxu(lssxup2:lblxu,lblyl:lblyu), &
         sezyxu(lssxup2:lblxu,lssyl:lssyup1), &
         sbzxxu(lssxup2:lblxu,lblyl:lblyu), &
         sbzyxu(lssxup2:lblxu,lssyl:lssyup1), &
         sezxyl(lssxl:lssxup1,lblyl:lssylm1), &
         sezyyl(lblxl:lblxu,lblyl:lssylm1), &
         sbzxyl(lssxl:lssxup1,lblyl:lssylm1), &
         sbzyyl(lblxl:lblxu,lblyl:lssylm1), &
         sezxyu(lssxl:lssxup1,lssyup2:lblyu), &
         sezyyu(lblxl:lblxu,lssyup2:lblyu), &
         sbzxyu(lssxl:lssxup1,lssyup2:lblyu), &
         sbzyyu(lblxl:lblxu,lssyup2:lblyu) &
         )
         allocate ( &
         scaxl(lblxl:lssxlm1), scaxlh(lblxlm1:lssxlm2), &
         scbbtexl(lblxlm1:lssxlm2),sccbtexl(lblxlm1:lssxlm2), &
         scbetmxl(lblxlm1:lssxlm2), sccetmxl(lblxlm1:lssxlm2), &
         scbetexl(lblxl:lssxlm1), sccetexl(lblxl:lssxlm1), &
         scbbtmxl(lblxl:lssxlm1), sccbtmxl(lblxl:lssxlm1), &
         scaxu(lssxup2:lblxu), scaxuh(lssxup2:lblxu), &
         scbbtexu(lssxup2:lblxu), sccbtexu(lssxup2:lblxu), &
         scbetmxu(lssxup2:lblxu), sccetmxu(lssxup2:lblxu), &
         scbetexu(lssxup2:lblxu), sccetexu(lssxup2:lblxu), &
         scbbtmxu(lssxup2:lblxu), sccbtmxu(lssxup2:lblxu), &
         scayl(lblyl:lssylm1), scaylh(lblylm1:lssylm2), &
         scbbteyl(lblylm1:lssylm2),sccbteyl(lblylm1:lssylm2), &
         scbetmyl(lblylm1:lssylm2), sccetmyl(lblylm1:lssylm2), &
         scbeteyl(lblyl:lssylm1), scceteyl(lblyl:lssylm1), &
         scbbtmyl(lblyl:lssylm1), sccbtmyl(lblyl:lssylm1), &
         scayu(lssyup2:lblyu), scayuh(lssyup2:lblyu), &
         scbbteyu(lssyup2:lblyu), sccbteyu(lssyup2:lblyu), &
         scbetmyu(lssyup2:lblyu), sccetmyu(lssyup2:lblyu), &
         scbeteyu(lssyup2:lblyu), scceteyu(lssyup2:lblyu), &
         scbbtmyu(lssyup2:lblyu), sccbtmyu(lssyup2:lblyu) &
         )
      end if
!....
      call fdebug ( 's2allc', 1 )
!....
      return
      end
