!----------------------------------------------------------------------
! Observe 2D Particle Electron Shock parameters Average Profile
!                             /
       subroutine o2pesap ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
! modified by Sakagami,H. ( NIFS ) 15/11/27 for include in fiscof2
!----------------------------------------------------------------------
#include "spdat.macro"
       use parameter
       use constant
       use observe
       use particle
       include "implicit.h"
       integer :: kflag, i, io, iopesap, icrsx, iwpesap, &
                  ix, iy, ixy, ixe, iye
       real*8  :: wdx,wx1,wx2,wx3,wx4,wdy,wy1,wy2,wy3,wy4,wkev
       real*8, allocatable :: wn(:,:), wvxe(:,:), wuxe(:,:), wte(:,:),&
                               wdea(:), wvxea(:), wuxea(:), &
                               wtea(:), wpea(:)
       real*8, parameter :: wcns1 = 2.0d0, wminlog = 1.0d-3
       save

       call fdebug ( 'o2pesap', 0 )

       if(  .not. allocated(wn) ) &
          allocate( wn(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wvxe(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wuxe(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wte(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wdea(loxypl), wvxea(loxypl), wuxea(loxypl), &
                    wtea(loxypl), wpea(loxypl) )

       iopesap = mod( lopesap, 10 )
       icrsx   = mod( lopesap/100, 100 )

       if( kflag .ge. 2 ) then
            iwpesap = iwpesap + 1
            do iy = lssylm1, lssyup1
               do ix = lssxlm1, lssxup1
                  wn(ix,iy)    = s0o1
                  wvxe(ix,iy)  = s0o1
                  wuxe(ix,iy)  = s0o1
                  wte(ix,iy)   = s0o1
               end do
            end do

            do i = lnoes, lnoee
              if( sxe(i) .lt. loxps .or. sxe(i) .gt. loxpe ) cycle
              if( sye(i) .lt. loyps .or. sye(i) .gt. loype ) cycle

              ixe = sxe(i)
              wdx = sxe(i) - ixe - s1o2
              wx1 = (s1o2-wdx)**3*s1o6
              wx2 = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
              wx3 =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
              wx4 = (s1o2+wdx)**3*s1o6

              iye = sye(i)
              wdy = sye(i) - iye - s1o2
              wy1 = (s1o2-wdy)**3*s1o6
              wy2 = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
              wy3 =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
              wy4 = (s1o2+wdy)**3*s1o6

              wn(ixe-1,iye-1) = wn(ixe-1,iye-1) + spfe(i) * wx1 * wy1
              wn(ixe  ,iye-1) = wn(ixe  ,iye-1) + spfe(i) * wx2 * wy1
              wn(ixe+1,iye-1) = wn(ixe+1,iye-1) + spfe(i) * wx3 * wy1
              wn(ixe+2,iye-1) = wn(ixe+2,iye-1) + spfe(i) * wx4 * wy1

              wn(ixe-1,iye  ) = wn(ixe-1,iye  ) + spfe(i) * wx1 * wy2
              wn(ixe  ,iye  ) = wn(ixe  ,iye  ) + spfe(i) * wx2 * wy2
              wn(ixe+1,iye  ) = wn(ixe+1,iye  ) + spfe(i) * wx3 * wy2
              wn(ixe+2,iye  ) = wn(ixe+2,iye  ) + spfe(i) * wx4 * wy2

              wn(ixe-1,iye+1) = wn(ixe-1,iye+1) + spfe(i) * wx1 * wy3
              wn(ixe  ,iye+1) = wn(ixe  ,iye+1) + spfe(i) * wx2 * wy3
              wn(ixe+1,iye+1) = wn(ixe+1,iye+1) + spfe(i) * wx3 * wy3
              wn(ixe+2,iye+1) = wn(ixe+2,iye+1) + spfe(i) * wx4 * wy3

              wn(ixe-1,iye+2) = wn(ixe-1,iye+2) + spfe(i) * wx1 * wy4
              wn(ixe  ,iye+2) = wn(ixe  ,iye+2) + spfe(i) * wx2 * wy4
              wn(ixe+1,iye+2) = wn(ixe+1,iye+2) + spfe(i) * wx3 * wy4
              wn(ixe+2,iye+2) = wn(ixe+2,iye+2) + spfe(i) * wx4 * wy4

              wvxe(ixe-1,iye-1) = wvxe(ixe-1,iye-1) + spfe(i) * wx1 * wy1 &
                                                      * svxe(i)
              wvxe(ixe  ,iye-1) = wvxe(ixe  ,iye-1) + spfe(i) * wx2 * wy1 &
                                                      * svxe(i)
              wvxe(ixe+1,iye-1) = wvxe(ixe+1,iye-1) + spfe(i) * wx3 * wy1 &
                                                      * svxe(i)
              wvxe(ixe+2,iye-1) = wvxe(ixe+2,iye-1) + spfe(i) * wx4 * wy1 &
                                                      * svxe(i)

              wvxe(ixe-1,iye  ) = wvxe(ixe-1,iye  ) + spfe(i) * wx1 * wy2 &
                                                      * svxe(i)
              wvxe(ixe  ,iye  ) = wvxe(ixe  ,iye  ) + spfe(i) * wx2 * wy2 &
                                                      * svxe(i)
              wvxe(ixe+1,iye  ) = wvxe(ixe+1,iye  ) + spfe(i) * wx3 * wy2 &
                                                      * svxe(i)
              wvxe(ixe+2,iye  ) = wvxe(ixe+2,iye  ) + spfe(i) * wx4 * wy2 &
                                                      * svxe(i)

              wvxe(ixe-1,iye+1) = wvxe(ixe-1,iye+1) + spfe(i) * wx1 * wy3 &
                                                      * svxe(i)
              wvxe(ixe  ,iye+1) = wvxe(ixe  ,iye+1) + spfe(i) * wx2 * wy3 &
                                                      * svxe(i)
              wvxe(ixe+1,iye+1) = wvxe(ixe+1,iye+1) + spfe(i) * wx3 * wy3 &
                                                      * svxe(i)
              wvxe(ixe+2,iye+1) = wvxe(ixe+2,iye+1) + spfe(i) * wx4 * wy3 &
                                                      * svxe(i)

              wvxe(ixe-1,iye+2) = wvxe(ixe-1,iye+2) + spfe(i) * wx1 * wy4 &
                                                      * svxe(i)
              wvxe(ixe  ,iye+2) = wvxe(ixe  ,iye+2) + spfe(i) * wx2 * wy4 &
                                                      * svxe(i)
              wvxe(ixe+1,iye+2) = wvxe(ixe+1,iye+2) + spfe(i) * wx3 * wy4 &
                                                      * svxe(i)
              wvxe(ixe+2,iye+2) = wvxe(ixe+2,iye+2) + spfe(i) * wx4 * wy4 &
                                                      * svxe(i)

              wuxe(ixe-1,iye-1) = wuxe(ixe-1,iye-1) + spfe(i) * wx1 * wy1 &
                                                      * suxe(i)
              wuxe(ixe  ,iye-1) = wuxe(ixe  ,iye-1) + spfe(i) * wx2 * wy1 &
                                                      * suxe(i)
              wuxe(ixe+1,iye-1) = wuxe(ixe+1,iye-1) + spfe(i) * wx3 * wy1 &
                                                      * suxe(i)
              wuxe(ixe+2,iye-1) = wuxe(ixe+2,iye-1) + spfe(i) * wx4 * wy1 &
                                                      * suxe(i)

              wuxe(ixe-1,iye  ) = wuxe(ixe-1,iye  ) + spfe(i) * wx1 * wy2 &
                                                      * suxe(i)
              wuxe(ixe  ,iye  ) = wuxe(ixe  ,iye  ) + spfe(i) * wx2 * wy2 &
                                                      * suxe(i)
              wuxe(ixe+1,iye  ) = wuxe(ixe+1,iye  ) + spfe(i) * wx3 * wy2 &
                                                      * suxe(i)
              wuxe(ixe+2,iye  ) = wuxe(ixe+2,iye  ) + spfe(i) * wx4 * wy2 &
                                                      * suxe(i)

              wuxe(ixe-1,iye+1) = wuxe(ixe-1,iye+1) + spfe(i) * wx1 * wy3 &
                                                      * suxe(i)
              wuxe(ixe  ,iye+1) = wuxe(ixe  ,iye+1) + spfe(i) * wx2 * wy3 &
                                                      * suxe(i)
              wuxe(ixe+1,iye+1) = wuxe(ixe+1,iye+1) + spfe(i) * wx3 * wy3 &
                                                      * suxe(i)
              wuxe(ixe+2,iye+1) = wuxe(ixe+2,iye+1) + spfe(i) * wx4 * wy3 &
                                                      * suxe(i)

              wuxe(ixe-1,iye+2) = wuxe(ixe-1,iye+2) + spfe(i) * wx1 * wy4 &
                                                      * suxe(i)
              wuxe(ixe  ,iye+2) = wuxe(ixe  ,iye+2) + spfe(i) * wx2 * wy4 &
                                                      * suxe(i)
              wuxe(ixe+1,iye+2) = wuxe(ixe+1,iye+2) + spfe(i) * wx3 * wy4 &
                                                      * suxe(i)
              wuxe(ixe+2,iye+2) = wuxe(ixe+2,iye+2) + spfe(i) * wx4 * wy4 &
                                                      * suxe(i)

              wte(ixe-1,iye-1) = wte(ixe-1,iye-1) + spfe(i) * wx1 * wy1 &
                                                      * (suxe(i))**2
              wte(ixe  ,iye-1) = wte(ixe  ,iye-1) + spfe(i) * wx2 * wy1 &
                                                      * (suxe(i))**2
              wte(ixe+1,iye-1) = wte(ixe+1,iye-1) + spfe(i) * wx3 * wy1 &
                                                      * (suxe(i))**2
              wte(ixe+2,iye-1) = wte(ixe+2,iye-1) + spfe(i) * wx4 * wy1 &
                                                      * (suxe(i))**2

              wte(ixe-1,iye  ) = wte(ixe-1,iye  ) + spfe(i) * wx1 * wy2 &
                                                      * (suxe(i))**2
              wte(ixe  ,iye  ) = wte(ixe  ,iye  ) + spfe(i) * wx2 * wy2 &
                                                      * (suxe(i))**2
              wte(ixe+1,iye  ) = wte(ixe+1,iye  ) + spfe(i) * wx3 * wy2 &
                                                      * (suxe(i))**2
              wte(ixe+2,iye  ) = wte(ixe+2,iye  ) + spfe(i) * wx4 * wy2 &
                                                      * (suxe(i))**2

              wte(ixe-1,iye+1) = wte(ixe-1,iye+1) + spfe(i) * wx1 * wy3 &
                                                      * (suxe(i))**2
              wte(ixe  ,iye+1) = wte(ixe  ,iye+1) + spfe(i) * wx2 * wy3 &
                                                      * (suxe(i))**2
              wte(ixe+1,iye+1) = wte(ixe+1,iye+1) + spfe(i) * wx3 * wy3 &
                                                      * (suxe(i))**2
              wte(ixe+2,iye+1) = wte(ixe+2,iye+1) + spfe(i) * wx4 * wy3 &
                                                      * (suxe(i))**2

              wte(ixe-1,iye+2) = wte(ixe-1,iye+2) + spfe(i) * wx1 * wy4 &
                                                      * (suxe(i))**2
              wte(ixe  ,iye+2) = wte(ixe  ,iye+2) + spfe(i) * wx2 * wy4 &
                                                      * (suxe(i))**2
              wte(ixe+1,iye+2) = wte(ixe+1,iye+2) + spfe(i) * wx3 * wy4 &
                                                      * (suxe(i))**2
              wte(ixe+2,iye+2) = wte(ixe+2,iye+2) + spfe(i) * wx4 * wy4 &
                                                      * (suxe(i))**2
            end do

            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                 if ( wn(ix,iy) .gt. wcns1 ) then
                    wvxe(ix,iy) = wvxe(ix,iy) / wn(ix,iy)
                    wuxe(ix,iy) = wuxe(ix,iy) / wn(ix,iy)
                    wte(ix,iy)  = ( sqrt( s1o1 + s2o1 &
                           * (wte(ix,iy)/wn(ix,iy)-wuxe(ix,iy)**2) &
                           * scg1 ) - s1o1 ) * scoft * 1.0d3
                 else
                    wvxe(ix,iy) = s0o1
                    wuxe(ix,iy) = s0o1
                    wte(ix,iy)  = s0o1
                   end if
               end do
            end do
            ixy = 0
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  ixy = ixy + 1
                  wdea(ixy)  = wdea(ixy)  + wn(ix,iy)
                  wvxea(ixy) = wvxea(ixy) + wvxe(ix,iy)
                  wuxea(ixy) = wuxea(ixy) + wuxe(ix,iy)
                  wtea(ixy)  = wtea(ixy)  + wte(ix,iy)
                  wpea(ixy)  = wpea(ixy)  + wte(ix,iy) * wn(ix,iy)
               end do
            end do

       end if

       if( kflag .le. 2 ) then
          if( kflag .ge. 1 ) then
             do i = 1, loxypl
                wdea(i)  = wdea(i) / ( snepm1 * iwpesap )
                wvxea(i) = wvxea(i) * scflinv / iwpesap
                wuxea(i) = wuxea(i) * scflinv / iwpesap
                wtea(i)  = wtea(i) / iwpesap
                wpea(i)  = wpea(i) / ( snepm1 * iwpesap ) * scofp
             end do

             if( iopesap .le. 4 ) then
                write(39) sstcur, &
                    ( wdea(i) , i = 1, loxypl ), &
                    ( wvxea(i), i = 1, loxypl ), &
                    ( wuxea(i), i = 1, loxypl ), &
                    ( wtea(i) , i = 1, loxypl ), &
                    ( wpea(i) , i = 1, loxypl )
                flush(39)
             end if
             if( iopesap .ge. 2 ) then
                if( icrsx .ge. 1 ) then
                     call frames_body25 ( bident, sstcur, &
                     19, wdea(1), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                             'Electron Density[Ne/Ncr]' )
                     call frames_body25 ( bident, sstcur, &
                     19, wvxea(1), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                        'Electron Mean X Velocity[V/c]' )
                     call frames_body25 ( bident, sstcur, &
                     19, wuxea(1), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                 'Electron Mean Relativistic X Velocity[U/c]' )
                     call frames_body25 ( bident, sstcur, &
                     19, wtea(1), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                       'Electron Temperature[KeV] ' )
                     call frames_body25 ( bident, sstcur, &
                     19, wpea(1), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                       'Electron X Pressure[Mbar] ' )
                end if
             end if
          else
             if( iopesap .le. 4 ) then
                 call fntpcnv ( bbifntp, lrank,39,bident,'pesap',bfile)
                 open( 39, file=bfile, form='UNFORMATTED' )
                 write(39) 'pes2', bident, loxypl, loxpl, loypl, &
                              soxmic, soxp0m, soymic, soyp0m
                 flush(39)
             end if
             if( iopesap .ge. 2 ) then
                call fntpcnv ( bfrfntp, lrank,19,bident,'pesap',bfile )
                call frames_file ( bfile, 19, iopesap )
             end if
          end if
          iwpesap = 0
          do i = 1, loxypl
              wdea(i)  = s0o1
              wvxea(i) = s0o1
              wuxea(i) = s0o1
              wtea(i)  = s0o1
              wpea(i)  = s0o1
          end do

       end if

       call fdebug ( 'o2pesap', 1 )

       return
       end
