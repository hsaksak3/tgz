!----------------------------------------------------------------------
! Compute 2D Particle Ion Cooling
!
      subroutine c2pic
!
!   <arguments>
!     none
!
!   <remarks>
!     lclflgi(i) : xy
!                   y = 1 cooling if suxe > 0 and suue > scluure
!                   y = 2 cooling both 1 and 3
!                   y = 3 cooling if suxe < 0 and suue > scluule
!                  x  = number of cooling regions
!
!     wclvv*i is normalized as V/Vth.
!     wclfcti is normalized as alpha/OMEGApe
!
!    coded by Sakagami, H. (NIFS) 13/03/13
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, io, ic, iclil, iclflgi
      real*8  :: wfac
      save
!....
      call fdebug ( 'c2pic', 0 )
!....
      if( lnoi .gt. 0 ) then
!....                                   * check particle for cooling *
      do io = 1, lionspl
        iclflgi = mod( lclflgi(io), 10 )
        iclil   = lclflgi(io) / 10
!...
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ic)
        do i = lionids(io), lionide(io)
          do ic = 1, iclil
#else
        do ic = 1, iclil
!$OMP PARALLEL DO SCHEDULE(STATIC)
          do i = lionids(io), lionide(io)
#endif
            if( sxi(i) .lt. sclxpsi(ic,io) .or. &
                sxi(i) .gt. sclxpei(ic,io) ) cycle
            if( syi(i) .lt. sclypsi(ic,io) .or. &
                syi(i) .gt. sclypei(ic,io) ) cycle
!..
            if( iclflgi .le. 2 ) then
               if( suxi(i).gt.s0o1.and.suui(i).gt.scluuri(ic,io) ) then
                  lclfli(i) = ic
               end if
            end if
!..
            if( iclflgi .ge. 2 ) then
               if( suxi(i).lt.s0o1.and.suui(i).gt.scluuli(ic,io) ) then
                  lclfli(i) = ic
               end if
            end if
          end do
        end do
      end do
!....                                                   * do cooling *
      do io = 1, lionspl
        if( lclflgi(io) .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ic,wfac)
          do i = lionids(io), lionide(io)
!..
            ic = lclfli(i)
            if( ic .eq. 0 ) cycle
!.                                           * check quit of cooling *
            wfac = suui(i) - scluu0i(ic,io)
            if( sxi(i) .lt. sclxpsi(ic,io) .or. &
                sxi(i) .gt. sclxpei(ic,io) .or. &
                syi(i) .lt. sclypsi(ic,io) .or. &
                syi(i) .gt. sclypei(ic,io) .or. &
                wfac .lt. s0o1 ) then
              lclfli(i) = 0
            else
              wfac = wfac * sclfcti(ic,io) / suui(i)
              sfxi(i) = sfxi(i) - suxi(i) * wfac
              sfyi(i) = sfyi(i) - suyi(i) * wfac
              sfzi(i) = sfzi(i) - suzi(i) * wfac
            end if
          end do
        end if
      end do
!....
      end if
!....
      call fdebug ( 'c2pic', 1 )
!....
      return
      end
