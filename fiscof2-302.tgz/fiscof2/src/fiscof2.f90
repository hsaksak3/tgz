!----------------------------------------------------------------------
! Fast Ignition Simulation code with COllective and Flexible particles
! 2 dimension
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
      use ieee_arithmetic
      use parameter
      use constant
      use control
      use field
      use laserprf
      use observe
      use animation
      use fpprm
      use debug
      include "implicit.h"
      integer istat
      character :: cvers*20, cfile*64
      character :: ctime*20, cdate*20, cload*32, cfc*16, cff*128, cfv*64
!....
      ctime = __TIME__
      cdate = __DATE__
      cload = '*UNDEFINED*'
      cfc = '*UNDEFINED*'
      cfv = '*UNDEFINED*'
      cff = '*UNDEFINED*'
#ifdef LOAD
      cload = LOAD
#endif
#ifdef FC
      cfc = FC
#endif
#ifdef FVERS
      cfv = FVERS 
#endif
#ifdef FFLAGS
      cff = FFLAGS
#endif
!....
      cvers = 'fiscof2'
#ifdef VECTOR
      cvers = trim(cvers)//'v'
#endif
      cvers = trim(cvers)//' V3.R02'
#ifdef DEBUG
      cvers = trim(cvers)//' DL'
      write( cvers(len_trim(cvers)+1:len_trim(cvers)+1), '(i1)' ) DEBUG
#endif
!....
      call s2ext_begin
!....
      call getenv ( 'FISCOF2_STDIN_FILE', cfile )
      call fntpcnv ( cfile, lrank, 5, ' ',' ', bfile )
      if( bfile(1:1) .ne. ' ' ) then
         open( 5, file=bfile, status='OLD', err=998, iostat=istat )
         write(0,*) '@@@ input is read from "', trim(bfile), '"'
      else
         write(0,*) '@@@ input is connected with STDIN'
      end if
!
      call getenv ( 'FISCOF2_STDOUT_FILE', cfile )
      call fntpcnv ( cfile, lrank, 6, ' ',' ', bfile )
      if( bfile(1:1) .ne. ' ' ) then
         open( 6, file=bfile, err=999, iostat=istat )
         write(0,*) '@@@ output is written to "', trim(bfile), '"'
      else
         write(0,*) '@@@ output is connected with STDOUT'
      end if
!..
      if(lrank .le. 0 ) then
      write(6,*) '@@@ ',trim(cload)//' compiled at '//trim(ctime)//&
                 ' on '//trim(cdate)
      write(6,*) '@@@ by '//trim(cfc)//', '//trim(cfv)
      write(6,*) '@@@ with '//trim(cff)
      end if
!....
      call fdebug ( cvers, -1 )
!.
      call ieee_get_rounding_mode(default_round_type)
!
      sundef  = -1.0d20
      sundeff = -1.1d20
      s0o1 = 0.0d0
      s1o2 = 0.5d0
      s1o1 = 1.0d0
      s3o2 = 1.5d0
      s2o1 = 2.0d0
      s3o1 = 3.0d0
      s4o1 = 4.0d0
      s1o6 = 1.0d0 / 6.0d0
      s2o3 = 2.0d0 / 3.0d0
      spi  = acos( -1.0d0 )
      s2pi = 2.0d0 * spi
      sd2r = spi / 180.0d0
      sminlog = 1.0d-12
      lminlog = 5
!....
      call s2simp
      call s2cnst
!.
      call s2allc ( 0 )
!.
      call s2ext_init
!.
      call s2allc ( 1 )
!.
      call s2init
!..
      call a2flsr
!....
      call fck_poiss ( 'at begin @@@' )
!....
      do while( lstcur .gt. lotnxt )
         sotnxt = sotnxt + sotint
         if( sotnxt .le. sotend ) then
            lotnxt = sotnxt / sdtfs
         else
            lotnxt = 999999999
         end if
      end do
!.
      if( lagfl .ge. 1 ) then
         do while( lstcur .gt. latnxt )
            satnxt = satnxt + satint
            if( satnxt .le. satend ) then
               latnxt = satnxt / sdtfs
            else
               latnxt = 999999999
            end if
         end do
      end if
!....
      if( lstcur .eq. lotnxt ) then
         if( lresti .eq. 0 ) then
            if( lopem .ge. 1 ) call o2pem ( 1 )
            if( lopee .ge. 1 ) call o2pee ( 1 )
            if( lopim .ge. 1 ) call o2pim ( 1 )
            if( lopie .ge. 1 ) call o2pie ( 1 )
            if( lofde .ge. 1 ) call o2fde ( 2 )
            if( lofdi .ge. 1 ) call o2fdi ( 2 )
            if( lofdc .ge. 1 ) call o2fdc ( 2 )
            if( lofte .ge. 1 ) call o2fte ( 2 )
            if( lofer .ge. 1 ) call o2fer ( 2 )
            if( lofea .ge. 1 ) call o2fea ( 2 )
            if( lofek .ge. 1 ) call o2fek ( 1 )
            if( lofbr .ge. 1 ) call o2fbr ( 2 )
            if( lofba .ge. 1 ) call o2fba ( 2 )
            if( lofede .ge. 1 ) call o2fede ( 1 )
            if( lofedi .ge. 1 ) call o2fedi ( 1 )
            if( lofje .ge. 1 ) call o2fje ( 2 )
            if( lofji .ge. 1 ) call o2fji ( 2 )
            if( lofjt .ge. 1 ) call o2fjt ( 2 )
            if( lopeph .ge. 1 ) call o2peph ( 1 )
            if( lopiph .ge. 1 ) call o2piph ( 1 )
            if( lopesap .ge. 1 ) call o2pesap( 2 )
            if( lopisap .ge. 1 ) call o2pisap( 2 )
            if( lopfeed .ge. 1 ) call o2pfeed ( 2 )
            if( lopfied .ge. 1 ) call o2pfied ( 2 )
         end if
         if( loeng .ge. 1 ) then
            call o2eng ( 2 )
            if( lresti .ne. 0 ) then
               if(lrank .le. 0 ) &
               write(0,*) '### Observation values may differ from '// &
                          'previous values because of time averaging.'
            end if
         end if
         sotnxt = sotnxt + sotint
         if( sotnxt .le. sotend ) then
            lotnxt = sotnxt / sdtfs
         else
            lotnxt = 999999999
         end if
         call ffflushall
      end if
!..
      if( lstcur .eq. latnxt ) then
         if( lagfl .ge. 1 ) call o2anim
         satnxt = satnxt + satint
         if( satnxt .le. satend ) then
            latnxt = satnxt / sdtfs
         else
            latnxt = 999999999
         end if
      end if
!....
    1 continue
!...
         lstcur = lstcur + 1
         lltcur = lltcur + 1
         sstcur = lstcur * sdtfs
!..
         call c2pef
         if( lclflge .ge. 1 )  call c2pec
         call c2pif
         if( lclflgia .ge. 1 ) call c2pic
!...
         call a2pem
         call c2pev
         call a2pep ( 1 )
         call b2pep ( 2 )
         call c2fje
         call a2pep ( 0 )
         call b2pep ( 0 )
         call c2fjecc
         call b2pep ( 1 )
         lcfde = 0
!.
         call a2pim
         call c2piv
         call a2pip ( 1 )
         call b2pip ( 2 )
         call c2fji
         call a2pip ( 0 )
         call b2pip ( 0 )
         call c2fjicc
         call b2pip ( 1 )
         lcfdi = 0
!..
         call c2fjt
!...
         if( llsrbn .gt. 0 ) call c2flsr
!..
         call a2fbte
         call b2fbte ( 1 )
         call a2fbtm
         call b2fbtm ( 1 )
!..
         call a2fete
         call b2fete
         call a2fetm
         call b2fetm
         call c2fed
!..
         if( lofew .ge. 1 ) call o2few ( 2 )
!..
         call a2fbte
         call b2fbte ( 0 )
         call a2fbtm
         call b2fbtm ( 0 )
!...
         if( loeng .ge. 1 ) then
            if( lstcur .gt. lotnxt - loenga ) call o2eng ( 3 )
         end if
         if( lofde .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdea ) call o2fde ( 3 )
         end if
         if( lofdi .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdia ) call o2fdi ( 3 )
         end if
         if( lofdc .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdca ) call o2fdc ( 3 )
         end if
         if( lofte .ge. 1 ) then
            if( lstcur .gt. lotnxt - loftea ) call o2fte ( 3 )
         end if
         if( lofer .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofera ) call o2fer ( 3 )
         end if
         if( lofea .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofeaa ) call o2fea ( 3 )
         end if
         if( lofbr .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofbra ) call o2fbr ( 3 )
         end if
         if( lofba .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofbaa ) call o2fba ( 3 )
         end if
         if( lofje .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjea ) call o2fje ( 3 )
         end if
         if( lofji .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjia ) call o2fji ( 3 )
         end if
         if( lofjt .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjta ) call o2fjt ( 3 )
         end if
         if( lopesap .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopesapa ) call o2pesap ( 3 )
         end if
         if( lopisap .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopisapa ) call o2pisap ( 3 )
         end if
         if( lopfeed .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopfeeda ) call o2pfeed ( 3 )
         end if
         if( lopfied .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopfieda ) call o2pfied ( 3 )
         end if
!.
         if( lstcur .eq. lotnxt ) then
            if( lopem .ge. 1 ) call o2pem ( 1 )
            if( lopee .ge. 1 ) call o2pee ( 1 )
            if( lopim .ge. 1 ) call o2pim ( 1 )
            if( lopie .ge. 1 ) call o2pie ( 1 )
            if( lofde .ge. 1 ) call o2fde ( 1 )
            if( lofdi .ge. 1 ) call o2fdi ( 1 )
            if( lofdc .ge. 1 ) call o2fdc ( 1 )
            if( lofte .ge. 1 ) call o2fte ( 1 )
            if( lofer .ge. 1 ) call o2fer ( 1 )
            if( lofea .ge. 1 ) call o2fea ( 1 )
            if( lofek .ge. 1 ) call o2fek ( 1 )
            if( lofbr .ge. 1 ) call o2fbr ( 1 )
            if( lofba .ge. 1 ) call o2fba ( 1 )
            if( lofede .ge. 1 ) call o2fede ( 1 )
            if( lofedi .ge. 1 ) call o2fedi ( 1 )
            if( lofje .ge. 1 ) call o2fje ( 1 )
            if( lofji .ge. 1 ) call o2fji ( 1 )
            if( lofjt .ge. 1 ) call o2fjt ( 1 )
            if( lopeph .ge. 1 ) call o2peph( 1 )
            if( lopiph .ge. 1 ) call o2piph( 1 )
            if( lopesap .ge. 1 ) call o2pesap( 1 )
            if( lopisap .ge. 1 ) call o2pisap( 1 )
            if( lopfeed .ge. 1 ) call o2pfeed ( 1 )
            if( lopfied .ge. 1 ) call o2pfied ( 1 )
            if( loeng .ge. 1 ) then
               call o2eng ( 1 )
               if( ldebug .ge. 2 ) then
                  call fck_poiss ( 'at obs. @@@' )
                  call fck_cc ( 'at obs. @@@' )
               end if
            end if
            sotnxt = sotnxt + sotint
            if( sotnxt .le. sotend ) then
               lotnxt = sotnxt / sdtfs
            else
               lotnxt = 999999999
            end if
!
            if( lresto .ne. 0 ) call s2rest ( 1, lresto )
!
            call ffflushall
         end if
!.
         if( lstcur .eq. latnxt ) then
            if( lagfl .ge. 1 ) call o2anim
            satnxt = satnxt + satint
            if( satnxt .le. satend ) then
               latnxt = satnxt / sdtfs
            else
               latnxt = 999999999
            end if
         end if
!...
      if( lstcur .lt. lstend ) go to 1
!..
      if( lofew .ge. 1 ) call o2few ( 1 )
!..
      if( lopfeed .ge. 1 ) call o2pfeed ( 4 )
      if( lopfied .ge. 1 ) call o2pfied ( 4 )
!..
      if( lresto .ne. 0 ) call s2rest ( 1, lresto )
!...
      call s2ext_term
!....
      call fck_poiss ( 'at end @@@' )
      call fck_cc ( 'at end @@@' )
!....
      call fdebug ( cvers, -2 )
!....
      stop
!....
  998 continue
      write(0,*) '### ERROR: stdin file not found. file="', &
                 trim(bfile), '"', istat
      stop
!..
  999 continue
      write(0,*) '### ERROR: can not open stdout file. file="', &
                 trim(bfile), '"', istat
      stop
      end
