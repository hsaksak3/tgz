module ptcltype
      type ty1_particle
         sequence
         real*8  :: x, y, ux, uy, uz, uu, pf
         integer :: nid
         integer :: clfl
      end type ty1_particle
      type ty2_particle
         sequence
         real*8  :: xo, yo, vx, vy, vz, fx, fy, fz
      end type ty2_particle
end module ptcltype
