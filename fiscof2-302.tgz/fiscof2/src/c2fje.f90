!-----------------------------------------------------------------------
! Compute 2D Field current(J) Electron
!
      subroutine c2fje
!
!   <arguments>
!     none
!
!   <remarks>
!     do not care the boundary factors.
!
!    coded by Sakagami,H. (NIFS) 09/04/09
! modifedd by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
#include "spdat.macro"
#include "vector.macro"
      use constant
      use control
      use particle
!#ifndef VECTOR
      use field
!#else
!     use field, vwjz => vwjw1
!#endif
      include "implicit.h"
      integer :: i, ix, iy, ixeh, iyeh
      real*8  :: wdxh,wx1h,wx2h,wx3h,wx4h,wdyh,wy1h,wy2h,wy3h,wy4h
      real*8, allocatable :: wjze(:,:)
#ifdef VECTOR
      real*8, allocatable :: vwjz(:,:,:)
      integer :: iv, iv2
#endif
      save
!....
      call fdebug ( 'c2fje', 0 )
!....
      if( lnoe .gt. 0 ) then
!....
      if ( .not. allocated(wjze) ) then
         allocate ( wjze(lssxlm1:lssxup2,lssylm1:lssyup2) )
      end if  
#ifdef VECTOR
      allocate ( vwjz(lvlen,lssxlm1:lssxup2,lssylm1:lssyup2) )
#endif
!...
!$OMP PARALLEL PRIVATE(ixeh,wdxh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                  iyeh,wdyh,wy1h,wy2h,wy3h,wy4h)
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm1, lssyup2
         do ix = lssxlm1, lssxup2
            wjze(ix,iy) = s0o1
         end do
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm1, lssyup2
        do ix = lssxlm1, lssxup2
          do iv = 1, lvlen
            vwjz(iv,ix,iy) = s0o1
          end do
        end do
      end do
#endif
!...
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjze)
      do i = lnoes, lnoee
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vwjz)
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1 
#endif
!..
         ixeh = sxe(i) + s1o2
         wdxh = sxe(i) - ixeh
         wx1h = (s1o2-wdxh)**3*s1o6
         wx2h = (s1o2+wdxh)**2*(wdxh-s3o2)*s1o2 + s2o3
         wx3h =-(s1o2-wdxh)**2*(wdxh+s3o2)*s1o2 + s2o3
         wx4h = (s1o2+wdxh)**3*s1o6
!
         iyeh = sye(i) + s1o2
         wdyh = sye(i) - iyeh
         wy1h = (s1o2-wdyh)**3*s1o6
         wy2h = (s1o2+wdyh)**2*(wdyh-s3o2)*s1o2 + s2o3
         wy3h =-(s1o2-wdyh)**2*(wdyh+s3o2)*s1o2 + s2o3
         wy4h = (s1o2+wdyh)**3*s1o6
!..
         _wjze(ixeh-1,iyeh-1) = _wjze(ixeh-1,iyeh-1) -  &
                                       svze(i) * spfe(i) * wx1h * wy1h
         _wjze(ixeh,  iyeh-1) = _wjze(ixeh,  iyeh-1) -  &
                                       svze(i) * spfe(i) * wx2h * wy1h
         _wjze(ixeh+1,iyeh-1) = _wjze(ixeh+1,iyeh-1) -  &
                                       svze(i) * spfe(i) * wx3h * wy1h
         _wjze(ixeh+2,iyeh-1) = _wjze(ixeh+2,iyeh-1) -  &
                                       svze(i) * spfe(i) * wx4h * wy1h
!
         _wjze(ixeh-1,iyeh  ) = _wjze(ixeh-1,iyeh  ) -  &
                                       svze(i) * spfe(i) * wx1h * wy2h
         _wjze(ixeh,  iyeh  ) = _wjze(ixeh,  iyeh  ) -  &
                                       svze(i) * spfe(i) * wx2h * wy2h
         _wjze(ixeh+1,iyeh  ) = _wjze(ixeh+1,iyeh  ) -  &
                                       svze(i) * spfe(i) * wx3h * wy2h
         _wjze(ixeh+2,iyeh  ) = _wjze(ixeh+2,iyeh  ) -  &
                                       svze(i) * spfe(i) * wx4h * wy2h
!
         _wjze(ixeh-1,iyeh+1) = _wjze(ixeh-1,iyeh+1) -  &
                                       svze(i) * spfe(i) * wx1h * wy3h
         _wjze(ixeh,  iyeh+1) = _wjze(ixeh,  iyeh+1) -  &
                                       svze(i) * spfe(i) * wx2h * wy3h
         _wjze(ixeh+1,iyeh+1) = _wjze(ixeh+1,iyeh+1) -  &
                                       svze(i) * spfe(i) * wx3h * wy3h
         _wjze(ixeh+2,iyeh+1) = _wjze(ixeh+2,iyeh+1) -  &
                                       svze(i) * spfe(i) * wx4h * wy3h
!
         _wjze(ixeh-1,iyeh+2) = _wjze(ixeh-1,iyeh+2) -  &
                                       svze(i) * spfe(i) * wx1h * wy4h
         _wjze(ixeh,  iyeh+2) = _wjze(ixeh,  iyeh+2) -  &
                                       svze(i) * spfe(i) * wx2h * wy4h
         _wjze(ixeh+1,iyeh+2) = _wjze(ixeh+1,iyeh+2) -  &
                                       svze(i) * spfe(i) * wx3h * wy4h
         _wjze(ixeh+2,iyeh+2) = _wjze(ixeh+2,iyeh+2) -  &
                                       svze(i) * spfe(i) * wx4h * wy4h
#ifdef VECTOR
      end do
#endif
!..
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm1, lssyup2
        do ix = lssxlm1, lssxup2
          do iv = 1, lvlen
            wjze(ix,iy) = wjze(ix,iy) + vwjz(iv,ix,iy)
          end do
        end do
      end do
#endif
!....
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup2
            wjze(lssxlm1,iy) = wjze(lssxlm1,iy) + wjze(lssxum1,iy)
            wjze(lssxl  ,iy) = wjze(lssxl  ,iy) + wjze(lssxu  ,iy)
            wjze(lssxlp1,iy) = wjze(lssxlp1,iy) + wjze(lssxup1,iy)
            wjze(lssxlp2,iy) = wjze(lssxlp2,iy) + wjze(lssxup2,iy)
         end do
      end if
      if( lexuf .eq. 1 ) then
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm1, lssyup2
               wjze(lssxum1,iy) = wjze(lssxlm1,iy)
               wjze(lssxu  ,iy) = wjze(lssxl  ,iy)
               wjze(lssxup1,iy) = wjze(lssxlp1,iy)
               wjze(lssxup2,iy) = wjze(lssxlp2,iy)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm1, lssyup2
               wjze(lssxum1,iy) = wjze(lssxlm1,iy) + wjze(lssxum1,iy)
               wjze(lssxu  ,iy) = wjze(lssxl  ,iy) + wjze(lssxu  ,iy)
               wjze(lssxup1,iy) = wjze(lssxlp1,iy) + wjze(lssxup1,iy)
               wjze(lssxup2,iy) = wjze(lssxlp2,iy) + wjze(lssxup2,iy)
            end do
         end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup2
            wjze(ix,lssylm1) = wjze(ix,lssylm1) + wjze(ix,lssyum1)
            wjze(ix,lssyl  ) = wjze(ix,lssyl  ) + wjze(ix,lssyu  )
            wjze(ix,lssylp1) = wjze(ix,lssylp1) + wjze(ix,lssyup1)
            wjze(ix,lssylp2) = wjze(ix,lssylp2) + wjze(ix,lssyup2)
         end do
      end if
      if( leyuf .eq. 1 ) then
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup2
               wjze(ix,lssyum1) = wjze(ix,lssylm1)
               wjze(ix,lssyu  ) = wjze(ix,lssyl  )
               wjze(ix,lssyup1) = wjze(ix,lssylp1)
               wjze(ix,lssyup2) = wjze(ix,lssylp2)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup2
               wjze(ix,lssyum1) = wjze(ix,lssylm1) + wjze(ix,lssyum1)
               wjze(ix,lssyu  ) = wjze(ix,lssyl  ) + wjze(ix,lssyu  )
               wjze(ix,lssyup1) = wjze(ix,lssylp1) + wjze(ix,lssyup1)
               wjze(ix,lssyup2) = wjze(ix,lssylp2) + wjze(ix,lssyup2)
            end do
         end if
      end if
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm1, lssyup2
         do ix = lssxlm1, lssxup2
            sjze(ix,iy) = wjze(ix,iy)
         end do
      end do
!$OMP END PARALLEL
!....
#ifdef VECTOR
      deallocate ( vwjz )
#endif
      end if
!....
      call fdebug ( 'c2fje', 1 )
!....
      return
      end
