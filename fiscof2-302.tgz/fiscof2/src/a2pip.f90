!-----------------------------------------------------------------------
! Advance 2D Particle Ion Position ( half step )
!                          /
      subroutine a2pip ( kmode )
!
!   <arguments>
!     kmode : mode 1 = save data
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use particle
      include "implicit.h"
      integer :: i, kmode
      save
!....
      call fdebug( 'a2pip',0 )
!....
!$OMP PARALLEL
      if( kmode .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do i = lnois, lnoie
            sxio(i) = sxi(i)
            syio(i) = syi(i)
         end do
      end if
!$OMP DO SCHEDULE(STATIC)
      do i = lnois, lnoie
         sxi(i) = sxi(i) + svxi(i) * s1o2
         syi(i) = syi(i) + svyi(i) * s1o2
      end do
!$OMP END PARALLEL
!....
      call fdebug( 'a2pip', 1 )
!....
      return
      end
