!-----------------------------------------------------------------------
! Advance 2D Field magnetic(B) - TE (half step)
!
      subroutine a2fbte
!
!   <arguments>
!     none
!
!   <remarks>
!     - "sdezdy" was already divided by 2 for an half step and changed
!       its sign.
!     - "sdezdx" was already divided by 2 for an half step.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use field
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'a2fbte', 0 )
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sbx(ix,iy) = sbx(ix,iy) + sdezdy(ix,iy)
            sby(ix,iy) = sby(ix,iy) + sdezdx(ix,iy)
         end do
      end do
!.
!$OMP DO SCHEDULE(STATIC)
      do ix = lssxl, lssxup1
         sbx(ix,lssylm1) = sbx(ix,lssylm1) + sdezdy(ix,lssylm1)
      end do
!$OMP DO SCHEDULE(STATIC)
      do iy = lssyl, lssyup1
         sby(lssxlm1,iy) = sby(lssxlm1,iy) + sdezdx(lssxlm1,iy)
      end do
!$OMP END PARALLEL
!....
      call fdebug ( 'a2fbte', 1 )
!....
      return
      end
