!----------------------------------------------------------------------
! Set 2D EXTernal system INITialize
!
      subroutine s2ext_init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
! #ifdef OHHELP
!       use parameter
!       use ohhelp
!       include "implicit.h"
!       include "mpif.h"
!       integer :: impierr
! #endif
!....
      call fdebug ( 's2ext_init', 0 )
!....
      call frames_init
!..
      call gdfxs_init
!....
! #ifdef OHHELP
!       call oh3_init ()
! #endif
!....
      call fdebug ( 's2ext_init', 1 )
!....
      return
      end
