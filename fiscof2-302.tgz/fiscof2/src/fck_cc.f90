!-----------------------------------------------------------------------
! ChecK Current Conservation
!                            /
      subroutine fck_cc ( echar )
!
!   <arguments>
!     echar : message for print
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use field
      use particle
      include "implicit.h"
      integer :: io, ix, iy, ixerx, iyerx
      real*8  :: werr, werrx, werrs
      character*(*) echar
      save
!....
      call c2fdeo
      if( lcfde .eq. 0 ) call c2fde
      werrx = s0o1
      ixerx = -1
      iyerx = -1
      werrs = s0o1
!..
      do iy = lssylm1, lssyup1
         do ix = lssxlm1, lssxup1
            werr = ( sjxe(ix+1,iy) - sjxe(ix,iy) + &
                     sjye(ix,iy+1) - sjye(ix,iy) - &
                     sde(ix,iy) + sdeo(ix,iy) ) ** 2
            if( werr .gt. werrx ) then
               werrx = werr
               ixerx = ix
               iyerx = iy
            end if
            werrs = werrs + werr
         end do
      end do
!..
      werrx = sqrt( werrx )
      werrs = sqrt( werrs ) / ((lssxup1-lssxlm1+1)*(lssyup1-lssylm1+1))
      write(6,*) '@@@ fck_cc(e) ', echar, werrs, werrx, ixerx, iyerx
!....
      if( lnoi .gt. 0 ) then
         call c2fdio
         if( lcfdi .eq. 0 ) call c2fdi
!..
         do io = 1, lionspl
!.
            werrx = s0o1
            ixerx = -1
            iyerx = -1
            werrs = s0o1
            do iy = lssylm1, lssyup1
               do ix = lssxlm1, lssxup1
                  werr = ( sjxi(ix+1,iy,io) - sjxi(ix,iy,io) + &
                           sjyi(ix,iy+1,io) - sjyi(ix,iy,io) + &
                       (sdi(ix,iy,io)-sdio(ix,iy,io))*sionaz(io) )**2
                  if( werr .gt. werrx ) then
                     werrx = werr
                     ixerx = ix
                     iyerx = iy
                  end if
                  werrs = werrs + werr
               end do
            end do
!.
            werrx = sqrt( werrx )
            werrs = sqrt( werrs ) / &
                           ((lssxup1-lssxlm1+1)*(lssyup1-lssylm1+1))
            write(6,*) '@@@ fck_cc(i) ', echar, io, werrs, werrx,  &
                      ixerx, iyerx
         end do
!..
      end if
!....
      return
      end
