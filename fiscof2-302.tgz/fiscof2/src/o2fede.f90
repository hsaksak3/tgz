!----------------------------------------------------------------------
! Observe 2D Field Energy Density Electron
!                           /
      subroutine o2fede ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/05/29
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 27, ifn = 8
      integer :: kflag, i, iofede, ix, iy, ixy
      real*8, allocatable :: wfede(:)
      save
!....
      call fdebug ( 'o2fede', 0 )
!....
      if( kflag .ge. 1 ) then
       if( loxypl .gt. 0 ) then
!...
         do i = 1, loxypl
            wfede(i) = s0o1
         end do
!..
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wfede), &
!$OMP          PRIVATE(ix,iy,ixy)
         do i = lnoes, lnoee
            ix = sxe(i)
            iy = sye(i)
            if( ix .ge. loxps .and. ix .le. loxpe .and. &
                iy .ge. loyps .and. iy .le. loype ) then
               if( mod(ix-loxps,loxpi) .eq. 0 .and. &
                   mod(iy-loyps,loypi) .eq. 0 ) then
                  ix = ( ix - loxps ) / loxpi + 1
                  iy = ( iy - loyps ) / loypi
                  ixy = ix + iy * loxpl
!++++
                  if( ixy .lt. 1 .or. ixy .gt. loxypl )  &
                    write(0,*) '### WARNING: o2fede', ix, iy, ixy
!++++
                  wfede(ixy) = wfede(ixy) + &
              ( sqrt( s1o1+suue(i)**2*scg1 ) - s1o1 ) * spfe(i)
               end if
            end if
         end do
!..
         do i = 1, loxypl
            wfede(i) = wfede(i) / snepm1
         end do
!..
         if( iofede .le. 4 ) then
            write(iun) sstcur, ( wfede(i),i=1,loxypl )
            flush(iun)
         end if
         if( iofede .ge. 2 ) then
            call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                            ifn, 0, 1, 0, 0, &
                            wfede, loxpl, loypl,  &
                            soxmic, soxp0m, soymic, soyp0m, 'fede' )
         end if
       end if
!....
      else
         iofede = lofede
!..
         if( loxypl .gt. 0 ) then
            if( .not. allocated(wfede) ) allocate( wfede(loxypl) )
         end if
!
         if( iofede .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fEe', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'fEe2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
            flush(iun)
         end if
         if( iofede .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fEe', bfile )
            call frames_file ( bfile, ifn, iofede )
         end if
      end if
!....
      call fdebug ( 'o2fede', 1 )
!....
      return
      end
