!----------------------------------------------------------------------
! Observe 2D Field Electric K (wave number) spectrum
!                          /
      subroutine o2fek ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/05/26
!----------------------------------------------------------------------
#include "sfield.macro"
      use parameter
      use constant
      use field
      use laserprf
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: iun = 31, ifn = 12
      integer :: kflag, i, io, ix, iy, iofek, ilog, iofekl, &
                 ixl, iyl, ikmx, ifftxs3(15),ifftys3(15), &
                 ixps(lofekx),ixpe(lofekx),iyps(lofekx),iype(lofekx),&
                 ixl2(lofekx),iyl2(lofekx)
      real*8  :: amx
      real*8, allocatable :: afek(:,:), afftxs1(:), afftxs2(:), &
                             afftytm(:), afftys1(:), afftys2(:), &
                             akx(:), aky(:), asp(:,:), aspx(:), aspy(:)
      character :: clabel*8
      save
!....
      call fdebug ( 'o2fek', 0 )
!....
      if( kflag .ge. 1 ) then
!...
        do io = 1, iofekl
!...
          ixl = ixpe(io)-ixps(io)+1
          iyl = iype(io)-iyps(io)+1
          allocate( afek(ixl,iyl), afftxs1(ixl), afftxs2(ixl), &
                    afftytm(iyl), afftys1(iyl), afftys2(iyl), &
                    akx(ixl2(io)), aky(iyl2(io)), &
                    asp(ixl2(io),iyl2(io)), &
                    aspx(ixl2(io)), aspy(iyl2(io)) )
          call rffti2 ( ixl, iyl, afftxs2,ifftxs3, afftys2,ifftys3 )
          asp(1,1) = s0o1
          do ix = 2, ixl2(io)
            asp(ix,1) = s0o1
          end do
          do iy = 2, iyl2(io)
            asp(1,iy) = s0o1
          end do
          aspx(1) = s0o1
          aspy(1) = s0o1
!..
          do i = 1, 4
!.
            if( i .eq. 1 ) then
              clabel = 'fek(Ex)'
              do iy = 1, iyl
                do ix = 1, ixl
                  afek(ix,iy) = sex(ix+ixps(io)-1,iy+iyps(io)-1)
                end do
              end do
            else if( i .eq. 2 ) then
              clabel = 'fek(Ey)'
              do iy = 1, iyl
                do ix = 1, ixl
                  afek(ix,iy) = sey(ix+ixps(io)-1,iy+iyps(io)-1)
                end do
              end do
            else if( i .eq. 3 ) then
              clabel = 'fek(Ez)'
              do iy = 1, iyl
                do ix = 1, ixl
                  afek(ix,iy) = sez(ix+ixps(io)-1,iy+iyps(io)-1)
                end do
              end do
            else
              clabel = 'fek(|E|)'
              do iy = 1, iyl
                do ix = 1, ixl
                  afek(ix,iy) = sqrt( &
                           sex(ix+ixps(io)-1,iy+iyps(io)-1)**2 + &
                           sey(ix+ixps(io)-1,iy+iyps(io)-1)**2 + &
                           sez(ix+ixps(io)-1,iy+iyps(io)-1)**2 )
                end do
              end do
            end if
!.
            call rfftf2 ( ixl, iyl, afek, afftytm, &
                 afftxs1, afftxs2, ifftxs3, afftys1, afftys2, ifftys3 )
!.
            do iy = 1, iyl2(io)-1
              do ix = 1, ixl2(io)-1
                asp(ix+1,iy+1) = &
                      afek(ix*2  ,iy*2  )**2+afek(ix*2+1,iy*2  )**2 + &
                      afek(ix*2  ,iy*2+1)**2+afek(ix*2+1,iy*2+1)**2
              end do
            end do
            do ix = 2, ixl2(io)
              aspx(ix) = s0o1
              do iy = 2, iyl2(io)
                aspx(ix) = aspx(ix) + asp(ix,iy)
              end do
            end do
            do iy = 2, iyl2(io)
              aspy(iy) = s0o1
              do ix = 2, ixl2(io)
                aspy(iy) = aspy(iy) + asp(ix,iy)
              end do
            end do
!..
            amx = 1.0d-30
            do iy = 2, iyl2(io)
              do ix = 2, ixl2(io)
                amx = max( amx, asp(ix,iy) )
              end do
            end do
            do iy = 2, iyl2(io)
              do ix = 2, ixl2(io)
                asp(ix,iy) = asp(ix,iy) / amx
              end do
            end do
!
            amx = 1.0d-30
            akx(1) = s0o1
            do ix = 2, ixl2(io)
              akx(ix) = ( slram * (ix-1) ) / ixl
              aspx(ix) = aspx(ix) / ixl
              amx = max( amx, aspx(ix) )
            end do
!
            aky(1) = s0o1
            do iy = 2, iyl2(io)
              aky(iy) = ( slram * (iy-1) ) / iyl
              aspy(iy) = aspy(iy) / iyl
              amx = max( amx, aspy(iy) )
            end do
!
            do ix = 2, ixl2(io)
              aspx(ix) = aspx(ix) / amx
            end do
            do iy = 2, iyl2(io)
              aspy(iy) = aspy(iy) / amx
            end do
!.
            if( iofek .le. 4 ) then
              write(iun) sstcur, io, i, akx, aky, asp, aspx, aspy
              flush(iun)
            end if
!..
            if( iofek .ge. 2 ) then
               call o2fdrawk ( bident, sstcur, ifn, ilog, 3, &
                       akx, aky, asp, aspx, aspy, ixl2(io), iyl2(io), &
              sofekxps(io), sofekyps(io), sofekxpe(io), sofekype(io), &
                         'Kx/K-L', 'Ky/K-L', 'number[a.u.]', clabel )
            end if
!.
          end do
!...
          deallocate( afek, afftxs1, afftxs2, afftytm, &
                      afftys1, afftys2, akx, aky, asp, aspx, aspy )
        end do
!....
      else
         iofek  = mod( lofek, 10 )
         ilog   = mod( lofek/10, 10 )
         iofekl = mod( lofek/100, 10 )
!..
         do io = 1, iofekl
            if( sofekxps(io) .le. sundef ) then
               ixps(io) = 1
               sofekxps(io) = ( ixps(io) - loxp0 ) * slmicinv
            else
               ixps(io) = sofekxps(io) * slmic + loxp0
            end if
            if( sofekxpe(io) .le. sundef ) then
               ixpe(io) = lssx-2
               sofekxpe(io) = ( ixpe(io) - loxp0 ) * slmicinv
            else
               ixpe(io) = sofekxpe(io) * slmic + loxp0
            end if
            if( sofekyps(io) .le. sundef ) then
               iyps(io) = 1
               sofekyps(io) = ( iyps(io) - loyp0 ) * slmicinv
            else
               iyps(io) = sofekyps(io) * slmic + loyp0
            end if
            if( sofekype(io) .le. sundef ) then
               iype(io) = lssy-2
               sofekype(io) = ( iype(io) - loyp0 ) * slmicinv
            else
               iype(io) = sofekype(io) * slmic + loyp0
            end if
            ixl = ixpe(io)-ixps(io)+1
            iyl = iype(io)-iyps(io)+1
            ixl2(io) = ixl / 2 - 1
            iyl2(io) = iyl / 2 - 1
            ikmx = sofekmax / slram * ixl + 2
            ixl2(io) = min( ixl2(io), ikmx )
            ikmx = sofekmax / slram * iyl + 2
            iyl2(io) = min( iyl2(io), ikmx )
            if( lrank .le. 0 ) &
            write(6,*) '@@@ o2fek', &
                       io, ixps(io),ixpe(io),iyps(io),iype(io)
         end do
         if( iofek .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fek', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'fek2', bident, sofekmax, iofekl, &
                      ( ixl2(io), iyl2(io), io=1,iofekl ), &
      (sofekxps(io),sofekyps(io),sofekxpe(io),sofekype(io),io=1,iofekl)
            flush(iun)
         end if
         if( iofek .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fek', bfile )
            call frames_file ( bfile, ifn, iofek )
         end if
!....
      end if
!....
      call fdebug ( 'o2fek', 1 )
!....
      return
      end
