!----------------------------------------------------------------------
! Compute 2D Field Electric Differenctial
!
      subroutine c2fed
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/15
!----------------------------------------------------------------------
#include "sfield.macro"
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'c2fed', 0 )
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
!..                                                            * TE *
            sdezdx(ix,iy) = ( sez(ix+1,iy) - sez(ix,iy) ) * s1o2
            sdezdy(ix,iy) = ( sez(ix,iy) - sez(ix,iy+1) ) * s1o2
!..                                                            * TM *
            sdeyxdxy(ix,iy) = ( sex(ix  ,iy) - sex(ix,iy-1) + &
                                sey(ix-1,iy) - sey(ix,iy  ) ) * s1o2
         end do
      end do
!..                                                            * TE *
!$OMP DO SCHEDULE(STATIC)
      do ix = lssxl, lssxup1
         sdezdy(ix,lssylm1) = ( sez(ix,lssylm1) - sez(ix,lssyl) ) * s1o2
      end do
!$OMP DO SCHEDULE(STATIC)
      do iy = lssyl, lssyup1
         sdezdx(lssxlm1,iy) = ( sez(lssxl,iy) - sez(lssxlm1,iy) ) * s1o2
      end do
!$OMP END PARALLEL
!....
      call fdebug ( 'c2fed', 1 )
!....
      return
      end
