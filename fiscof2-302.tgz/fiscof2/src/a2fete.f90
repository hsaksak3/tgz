!-----------------------------------------------------------------------
! Advance 2D Field Electric - TE
!
      subroutine a2fete
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "sfield.macro"
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'a2fete', 0 )
!....
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sez(ix,iy) = sez(ix,iy) + ( sby(ix,iy) - sby(ix-1,iy) -  &
                         sbx(ix,iy) + sbx(ix,iy-1) ) * scb1 +  &
                         sjzt(ix,iy) * scj1
         end do
      end do
!....
      call fdebug ( 'a2fete', 1 )
!....
      return
      end
