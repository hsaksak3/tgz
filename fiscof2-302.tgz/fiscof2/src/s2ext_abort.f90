!----------------------------------------------------------------------
! Set 2D EXTernal system ABORT
!
      subroutine s2ext_abort
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 14/05/01
!----------------------------------------------------------------------
! #ifdef OHHELP
!       use parameter
!       include "implicit.h"
!       include "mpif.h"
!       integer :: impierr
! #endif
!....
! #ifdef OHHELP
!       write(0,*) '### ABORT: called by lrank =', lrank
!       call MPI_ABORT ( MPI_COMM_WORLD, lrank, impierr )
!       if( impierr .ne. 0 ) &
!          write(0,*) '### ERROR: MPI_ABORT, impierr =', impierr
! #endif
!....
      stop 99999
!....
      end
