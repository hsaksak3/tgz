!-----------------------------------------------------------------------
! Compute 2D Field Density Electron
!
      subroutine c2fde
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, ixe, iye
      real*8  :: wdx,wx1,wx2,wx3,wx4,wdy,wy1,wy2,wy3,wy4
      save
!....
      call fdebug ('c2fde', 0 )
!....
      do iy = lssylm1, lssyup1
         do ix = lssxlm1, lssxup1
            sde(ix,iy) = s0o1
         end do
      end do
!..
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:sde), &
!$OMP          PRIVATE(ixe,wdx,wx1,wx2,wx3,wx4,iye,wdy,wy1,wy2,wy3,wy4)
      do i = lnoes, lnoee
         ixe = sxe(i)
         wdx = sxe(i) - ixe - s1o2
         wx1 = (s1o2-wdx)**3*s1o6
         wx2 = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
         wx3 =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
         wx4 = (s1o2+wdx)**3*s1o6
!.
         iye = sye(i)
         wdy = sye(i) - iye - s1o2
         wy1 = (s1o2-wdy)**3*s1o6
         wy2 = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
         wy3 =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
         wy4 = (s1o2+wdy)**3*s1o6
!..
         sde(ixe-1,iye-1) = sde(ixe-1,iye-1) + spfe(i) * wx1 * wy1
         sde(ixe,  iye-1) = sde(ixe,  iye-1) + spfe(i) * wx2 * wy1
         sde(ixe+1,iye-1) = sde(ixe+1,iye-1) + spfe(i) * wx3 * wy1
         sde(ixe+2,iye-1) = sde(ixe+2,iye-1) + spfe(i) * wx4 * wy1
!.
         sde(ixe-1,iye  ) = sde(ixe-1,iye  ) + spfe(i) * wx1 * wy2
         sde(ixe,  iye  ) = sde(ixe,  iye  ) + spfe(i) * wx2 * wy2
         sde(ixe+1,iye  ) = sde(ixe+1,iye  ) + spfe(i) * wx3 * wy2
         sde(ixe+2,iye  ) = sde(ixe+2,iye  ) + spfe(i) * wx4 * wy2
!.
         sde(ixe-1,iye+1) = sde(ixe-1,iye+1) + spfe(i) * wx1 * wy3
         sde(ixe,  iye+1) = sde(ixe,  iye+1) + spfe(i) * wx2 * wy3
         sde(ixe+1,iye+1) = sde(ixe+1,iye+1) + spfe(i) * wx3 * wy3
         sde(ixe+2,iye+1) = sde(ixe+2,iye+1) + spfe(i) * wx4 * wy3
!.
         sde(ixe-1,iye+2) = sde(ixe-1,iye+2) + spfe(i) * wx1 * wy4
         sde(ixe,  iye+2) = sde(ixe,  iye+2) + spfe(i) * wx2 * wy4
         sde(ixe+1,iye+2) = sde(ixe+1,iye+2) + spfe(i) * wx3 * wy4
         sde(ixe+2,iye+2) = sde(ixe+2,iye+2) + spfe(i) * wx4 * wy4
      end do
!...
      if( lexlpe .eq. 1 ) then
         do iy = lssylm1, lssyup1
            sde(lssxlm1,iy) = sde(lssxlm1,iy) + sde(lssxum1,iy)
            sde(lssxl  ,iy) = sde(lssxl,  iy) + sde(lssxu  ,iy)
            sde(lssxlp1,iy) = sde(lssxlp1,iy) + sde(lssxup1,iy)
         end do
      end if
      if( lexupe .eq. 1 ) then
         if( lexlpe .eq. 1 ) then
            do iy = lssylm1, lssyup1
               sde(lssxum1,iy) = sde(lssxlm1,iy)
               sde(lssxu  ,iy) = sde(lssxl  ,iy)
               sde(lssxup1,iy) = sde(lssxlp1,iy)
            end do
         else
            do iy = lssylm1, lssyup1
               sde(lssxum1,iy) = sde(lssxlm1,iy) + sde(lssxum1,iy)
               sde(lssxu  ,iy) = sde(lssxl,  iy) + sde(lssxu  ,iy)
               sde(lssxup1,iy) = sde(lssxlp1,iy) + sde(lssxup1,iy)
            end do
         end if
      end if
!.
      if( leylpe .eq. 1 ) then
         do ix = lssxlm1, lssxup1
            sde(ix,lssylm1) = sde(ix,lssylm1) + sde(ix,lssyum1)
            sde(ix,lssyl  ) = sde(ix,lssyl  ) + sde(ix,lssyu  )
            sde(ix,lssylp1) = sde(ix,lssylp1) + sde(ix,lssyup1)
         end do
      end if
      if( leyupe .eq. 1 ) then
         if( leylpe .eq. 1 ) then
            do ix = lssxlm1, lssxup1
               sde(ix,lssyum1) = sde(ix,lssylm1)
               sde(ix,lssyu  ) = sde(ix,lssyl  )
               sde(ix,lssyup1) = sde(ix,lssylp1)
            end do
         else
            do ix = lssxlm1, lssxup1
               sde(ix,lssyum1) = sde(ix,lssylm1) + sde(ix,lssyum1)
               sde(ix,lssyu  ) = sde(ix,lssyl  ) + sde(ix,lssyu  )
               sde(ix,lssyup1) = sde(ix,lssylp1) + sde(ix,lssyup1)
            end do
         end if
      end if
!...
      lcfde = 1
!....
      call fdebug ( 'c2fde', 1 )
!....
      return
      end
