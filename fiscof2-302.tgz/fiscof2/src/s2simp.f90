!----------------------------------------------------------------------
! Set 2D SIMulation Parameters
!
      subroutine s2simp
!
!   <arguments>
!     none
!
!   <remarks>
!     In some cases, read(* still reads from STDIN even open
!    the file with UNIT=5, so change read(* to read(5.
!    As same reason, change write(* to write(6.
!
!    coded by Sakagami,H. (NIFS) 09/04/14
!----------------------------------------------------------------------
      use parameter
      use constant
      use control
      use profile
      use particle
      use laserprf
      use observe
      use animation
      use fpprm
      use debug
      include "implicit.h"
      integer :: i, io, il, iote, ioteh, ioti, iotih, &
                 iotint, iotl, iotlh, ifsec
      real*8  :: wmassi, wncmax, wte, wti, wgam, acr
      real*8  :: wclvvre(lclflgex), wclvvle(lclflgex), &
                 wclvv0e(lclflgex), wclfcte(lclflgex), &
                 wclvvri(lclflgix,lionspx), wclvvli(lclflgix,lionspx), &
                 wclvv0i(lclflgix,lionspx), wclfcti(lclflgix,lionspx), &
                 wpppvdxe(lpppx), wpppvdye(lpppx), wpppvdze(lpppx), &
                 wpppvdxi(lpppx), wpppvdyi(lpppx), wpppvdzi(lpppx)
      character*17 cident
      save
!....
      namelist /numeri/ &
         lssx, lssy, ldivx, ldivy, lloadbf, lvlen, lccsch, &
         lnoex, lnoix, sdelt, sgrid, lnepm, lnepme, wncmax, sncmaxtl, &
         lnipme, wmassi, sstend, cident, ldebug, lrinit, scr, scfl
      namelist /cntrl/ &
         sextbx, sextby, sextbz, &
         lresti, lresto, &
         lbxlf, lbxlpe, lbxlpi, lbxuf, lbxupe, lbxupi, &
         lbylf, lbylpe, lbylpi, lbyuf, lbyupe, lbyupi, &
         lpmlxl, lpmlxu, lpmlyl, lpmlyu, &
         lblsgxl, lblsgxu, lblsgyl, lblsgyu, &
         sblsgxl, sblsgxu, sblsgyl, sblsgyu, &
         lclflge, sclxpse, sclxpee, sclypse, sclypee, &
         wclvvre, wclvvle, wclvv0e, wclfcte, &
         lclflgi, sclxpsi, sclxpei, sclypsi, sclypei, &
         wclvvri, wclvvli, wclvv0i, wclfcti, brestfntp
      namelist /plasma/ &
         wte, wti, lionspl, &
         sionaf, sionaz, sionam, &
         lpprof, lxp0, lyp0, lpppl, lpppis, lpppty, &
         lppphis, lppphie, &
         spppxps, spppyps, spppds, spppxpe, spppype, spppde, &
         spppnp, spppnd, spppte, spppti, &
         wpppvdxe, wpppvdye, wpppvdze, &
         wpppvdxi, wpppvdyi, wpppvdzi, &
         sppphxo, sppphyo, sppphrr
      namelist /laser/ &
         llsrbn, llsrty, llinx, lliny, slpwr, slramm, &
         slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
         lbemty, lbemix, sbempw, sbemwl, &
         sbemle, sbemwd, sbemtr, sbemmn, &
         sbemfi, sbemal, sbemxf, sbemyf, sbeman, sbemph, sbemdl, &
         slram, slomg, llxps, llxpe, lltend
      namelist /observ/ &
         sotstr, sotend, sotint, ifsec, slmic, &
         soxps, soxpe, soxmic, loxpi, loxp0,  &
         soyps, soype, soymic, loypi, loyp0,  &
         loeng, loenga, &
         lopem, sopemfct, sopemxps, sopemxpe, sopemyps, sopemype, &
         lopee, sopeefct, sopeexps, sopeexpe, sopeeyps, sopeeype, &
         lopim, sopimfct, sopimxps, sopimxpe, sopimyps, sopimype, &
         lopie, sopiefct, sopiexps, sopiexpe, sopieyps, sopieype, &
         lopeph, sopephxps, sopephxpe, sopephyps, sopephype, &
         sopephuxm, sopephuxx, &
         lopiph, sopiphxps, sopiphxpe, sopiphyps, sopiphype, &
         sopiphuxm, sopiphuxx, &
         lopesap, lopesapa, lopisap, lopisapa, &
         lofde, lofdea, lofdi, lofdia, lofdc, lofdca, lofte, loftea, &
         lofede, lofedi, lofje, sofjehot, lofjea, lofji, lofjia, &
         lofjt, lofjta, &
         lofea, lofeaa, lofer, lofera, lofba, lofbaa, lofbr, lofbra, &
         lofek, sofekxps, sofekxpe, sofekyps, sofekype, sofekmax, &
         lofew, sofewxp, sofewyp, &
         bbifntp, bfrfntp
      namelist /anime/ &
         lagfl, lavpl, lawnl, &
         lamode, lagifw, lagifh, banfntp, satstr, satend, satint, &
         savpxm, savpxx, savpym, savpyx, &
         sawnxm, sawnxx, sawnym, sawnyx, sawnzm, sawnzx, &
         lapepl, lapep, &
         lapeuxyl, lapeuxy, lapeuxzl, lapeuxz, lapeuyzl, lapeuyz, &
         lapexuxl, lapexux, lapexuyl, lapexuy, lapexuzl, lapexuz, &
         lapipl, lapip, &
         lapiuxyl, lapiuxy, lapixuxl, lapixux, lapixuyl, lapixuy, &
         lafdel, lafde, lafdil, lafdi, &
         lafedel, lafede, lafedil, lafedi, &
         lafjexl, lafjex, lafjeyl, lafjey, lafjezl, lafjez, &
         lafeal, lafea, lafexl, lafex, lafeyl, lafey, lafezl, lafez, &
         lafbal, lafba, lafbxl, lafbx, lafbyl, lafby, lafbzl, lafbz
       namelist /fpparam/ &
         bfpfntpe, bfpfntpi, &
         lopfeed, lopfeeda, lopfeedc, &
         lopfeedrl, lopfeedml, lopfeednl, lopfeedyl, &
         sopfeedx, sopfeedys, sopfeedye, sopfeedr, sopfeedm, &
         lopfied, lopfieda, lopfiedc, &
         lopfiedrl, lopfiedml, lopfiednl, lopfiedyl, &
         sopfiedx, sopfiedys, sopfiedye, sopfiedr, sopfiedm
!.... * ldebug is not defined at this moment. set for ldebug = 1 mode *
      ldebug = 1
!....
      call fdebug ( 's2simp', 0 )
!....
!...                                     * basic numerical parameters *
!.                                                    * PIC parameter *
      sdelt  = 0.1d0
      sgrid  = 1.0d0
      lnepm  = 10000
      wncmax = 100.0d0
      sncmaxtl = 5.0d-2
      lnepme = 100
      wmassi = 1836.0d0
      lccsch = 0
!.                                              * execution parameter *
      sstend = 50.0d0
      cident = ' '
      ldebug = 0
      lrinit = 4137
!.
      read(5,nml=numeri)
!.                                                   * size parameter *
      lssxp1  = lssx + 1
      lssxm1  = lssx - 1
      lssyp1  = lssy + 1
      lssym1  = lssy - 1
!
      lssxl   = 1
      lssxlp1 = lssxl + 1
      lssxlp2 = lssxl + 2
      lssxlp3 = lssxl + 3
      lssxlm1 = lssxl - 1
      lssxlm2 = lssxl - 2
      lssxu   = lssx
      lssxup1 = lssxu + 1
      lssxup2 = lssxu + 2
      lssxup3 = lssxu + 3
      lssxum1 = lssxu - 1
      lssxum2 = lssxu - 2
!
      lssyl   = 1
      lssylp1 = lssyl + 1
      lssylp2 = lssyl + 2
      lssylp3 = lssyl + 3
      lssylm1 = lssyl - 1
      lssylm2 = lssyl - 2
      lssyu   = lssy
      lssyup1 = lssyu + 1
      lssyup2 = lssyu + 2
      lssyup3 = lssyu + 3
      lssyum1 = lssyu - 1
      lssyum2 = lssyu - 2
!
      lnox = lnoex + lnoix
!.
      if( cident(17:17) .ne. ' ' ) then
         write(0,*) '### ERROR: cident must be less than 16 chars.'
         call s2ext_abort
      end if
      if( cident(1:16) .eq. '                ' ) then
         write(0,*) '### ERROR: cident must be specified.'
         call s2ext_abort
      end if
      bident = cident
!...                                       * basic control parameters *
!.                                                 * external B field *
      sextbx = s0o1
      sextby = s0o1
      sextbz = s0o1
!.
      lresti = 0
      lresto = 0
      brestfntp = 'fort.%%.###'
!.
      lbxlf  = 4
      lbxuf  = 4
      lbylf  = 4
      lbyuf  = 4
      lbxlpe = 2
      lbxupe = 2
      lbylpe = 2
      lbyupe = 2
      lbxlpi = 2
      lbxupi = 2
      lbylpi = 2
      lbyupi = 2
      lblsgxl = 3
      lblsgxu = 3
      lblsgyl = 3
      lblsgyu = 3
      sblsgxl = 2.0d-5
      sblsgxu = 2.0d-5
      sblsgyl = 2.0d-5
      sblsgyu = 2.0d-5
!.                                               * cooling parameters *
      lclflge = 0
      do i = 1, lclflgex
         sclxpse(i)  = sundeff
         sclxpee(i)  = sundeff
         sclypse(i)  = sundeff
         sclypee(i)  = sundeff
         wclvvre(i) = 3.5d0
         wclvvle(i) = 3.5d0
         wclvv0e(i) = s1o1
         wclfcte(i) = 0.0075d0
      end do
      lclflgia = 0
      do io = 1, lionspx
         lclflgi(io) = 0
         do i = 1, lclflgix
            sclxpsi(i,io)  = sundeff
            sclxpei(i,io)  = sundeff
            sclypsi(i,io)  = sundeff
            sclypei(i,io)  = sundeff
            wclvvri(i,io) = 3.5d0
            wclvvli(i,io) = 3.5d0
            wclvv0i(i,io) = s1o1
            wclfcti(i,io) = 0.0075d0
         end do
      end do
!.
      read(5,nml=cntrl)
!.                                              * boundary conditions *
      lexlf  = lbxlf
      lexuf  = lbxuf
      leylf  = lbylf
      leyuf  = lbyuf
      lexlpe = lbxlpe
      lexupe = lbxupe
      leylpe = lbylpe
      leyupe = lbyupe
      lexlpi = lbxlpi
      lexupi = lbxupi
      leylpi = lbylpi
      leyupi = lbyupi
!.                                                   * PML parameters *
      lblxl   = lssxl - lpmlxl
      lblxlm1 = lblxl - 1
      lblxu   = lssxup1 + lpmlxu
      lblxup1 = lblxu + 1
      lblyl   = lssyl - lpmlyl
      lblylm1 = lblyl - 1
      lblyu   = lssyup1 + lpmlyu
      lblyup1 = lblyu + 1
!...                                        * basic plasma parameters *
      wte     = 10.0d0
      wti     = 0.30d0
      lionspl = 0
      do i = 1, lionspx
         lionids(i) = -9999999
         lionide(i) = -9999999
         lionidl(i) = -9999999
         lnipme(i)  = -9999999
         sionaf(i)  = sundeff
         sionaz(i)  = sundeff
         sionam(i)  = sundeff
         sionqm(i)  = sundeff
         sionmm(i)  = sundeff
      end do
!...                                        * basic profile parameters *
      lpprof = 0
      lxp0 = lssxm1 / 2 + 1
      lyp0 = lssym1 / 2 + 1
      lpppl = 0
      do i = 1, lpppx
         lpppis(i) = 0
         lpppty(i) = 0
         lppphis(i) = 0
         lppphie(i) = -1
         spppxps(i) = sundeff
         spppyps(i) = sundeff
         spppds(i)  = s0o1
         spppxpe(i) = sundeff
         spppype(i) = sundeff
         spppde(i)  = s0o1
         spppnp(i)  = s0o1
         spppnd(i)  = s0o1
         spppte(i)  = sundeff
         spppti(i)  = sundeff
         wpppvdxe(i)  = s0o1
         wpppvdye(i)  = s0o1
         wpppvdze(i)  = s0o1
         wpppvdxi(i)  = s0o1
         wpppvdyi(i)  = s0o1
         wpppvdzi(i)  = s0o1
      end do
      do i = 1, lppphx
         sppphxo(i) = sundeff
         sppphyo(i) = sundeff
         sppphrr(i) = sundeff
      end do
      bprffn = ' '
!.
      read(5,nml=plasma)
!...                                         * basic laser parameters *
      slpwr  = 1.0d20
      slramm = 1.06d0
      llsrbn = 0
      llsrty = 0
      llinx = 10
      lliny = lssym1 / 2 + 1
      llxps  = -1
      llxpe  = -1
      lltend = -1
      slsrle = s0o1
      slsrwd = s0o1
      slsrtr = s0o1
      slsrmn = 0.005d0
      slsrfi = s0o1
      slsral = s0o1
      do i = 1, llsrbx
         lbemty(i) = 0
         lbemix(i) = 0
         sbempw(i) = sundeff
         sbemwl(i) = sundeff
         sbemle(i) = sundeff
         sbemwd(i) = sundeff
         sbemtr(i) = sundeff
         sbemmn(i) = sundeff
         sbemfi(i) = sundeff
         sbemal(i) = sundeff
         sbemxf(i) = s0o1
         sbemyf(i) = s0o1
         sbeman(i) = s0o1
         sbemph(i) = s0o1
         sbemdl(i) = s0o1
      end do
!.
      read(5,nml=laser)
!....
      smasr  = s1o1 / wmassi
      sncinv = s1o1 / wncmax
      snepm1 = lnepm * sncinv
      snepm1inv = s1o1 / snepm1
      stemr  = wti / wte
      svte = sdelt * sgrid
!.
      if( abs(lpprof) .eq. 1 ) then
         if( lpppl .le. 0 ) then
            write(0,*) '### ERROR: lpppl must be specified.', lpppl
            call s2ext_abort
         else if( lpppl .gt. lpppx ) then
            write(0,*) '### ERROR: lpppl must be less equal lpppx.', &
                       lpppl, lpppx
            call s2ext_abort
         end if
         do i = 1, lpppl
           if( lpppty(i) .gt. 10 ) then
             if( lppphis(i) .gt. lppphie(i) ) then
               write(0,*)'### ERROR: lppphis must be less than lppphie.', &
                         i, lppphis(i), lppphie(i)
               call s2ext_abort
             else if( lppphis(i).lt.1 .or. lppphis(i).gt.lppphx ) then
               write(0,*)'### ERROR: lppphis is out of range.', &
                         i, lppphis(i), lppphx
               call s2ext_abort
             else if( lppphie(i).lt.1 .or. lppphie(i).gt.lppphx ) then
               write(0,*)'### ERROR: lppphie is out of range.', &
                         i, lppphie(i), lppphx
               call s2ext_abort
             end if
           end if
         end do
         if( smasr .gt. 1.0d-29 ) then
           if( lionspl .le. 0 ) then
             write(0,*) '### ERROR: ion must be specified.', lionspl
             call s2ext_abort
           else if( lionspl .gt. lionspx ) then
             write(0,*)'### ERROR: lionspl must be less equal lionspx.', &
                       lionspl, lionspx
             call s2ext_abort
           end if
           do i = 1, lionspl
             if( sionaz(i) .le. sundef .or. sionam(i) .le. sundef ) then
               write(0,*)'### ERROR: sionaz and sionam must be specified.',&
                         i, sionaz(i), sionam(i)
               call s2ext_abort
             end if
             if( lnipme(i) .le. 0 ) lnipme(i) = lnepme
             if( sionaf(i) .le. sundef ) sionaf(i) = s1o1 / sionaz(i)
             svti(i) = svte * sqrt( smasr / sionam(i) * stemr )
             sionqm(i) = sionaz(i) / sionam(i) * smasr
             sionmm(i) = sionam(i) / smasr
           end do
         end if
      end if
!.
      if( lpprof .ne. 0 ) then
         if( lbxlf .eq. 1 ) then
            if( lbxlpe .ne. 1 ) then
               write(0,*) '### ERROR: lbxlpe must be periodic, ', &
                          'if periodic field.', lbxlpe, lbxlf
               call s2ext_abort
            end if
            if( smasr .gt. 1.0d-29 .and. lbxlpi .ne. 1 ) then
               write(0,*) '### ERROR: lbxlpi must be periodic, ', &
                          'if periodic field.', lbxlpi, lbxlf
               call s2ext_abort
            end if
         end if
         if( lbxuf .eq. 1 ) then
            if( lbxupe .ne. 1 ) then
               write(0,*) '### ERROR: lbxupe must be periodic, ', &
                          'if periodic field.', lbxupe, lbxuf
               call s2ext_abort
            end if
            if( smasr .gt. 1.0d-29 .and. lbxupi .ne. 1 ) then
               write(0,*) '### ERROR: lbxupi must be periodic, ', &
                          'if periodic field.', lbxupi, lbxuf
               call s2ext_abort
            end if
         end if
         if( lbylf .eq. 1 ) then
            if( lbylpe .ne. 1 ) then
               write(0,*) '### ERROR: lbylpe must be periodic, ', &
                          'if periodic field.', lbylpe, lbylf
               call s2ext_abort
            end if
            if( smasr .gt. 1.0d-29 .and. lbylpi .ne. 1 ) then
               write(0,*) '### ERROR: lbylpi must be periodic, ', &
                          'if periodic field.', lbylpi, lbylf
               call s2ext_abort
            end if
         end if
         if( lbyuf .eq. 1 ) then
            if( lbyupe .ne. 1 ) then
               write(0,*) '### ERROR: lbyupe must be periodic, ', &
                          'if periodic field.', lbyupe, lbyuf
               call s2ext_abort
            end if
            if( smasr .gt. 1.0d-29 .and. lbyupi .ne. 1 ) then
               write(0,*) '### ERROR: lbyupi must be periodic, ', &
                          'if periodic field.', lbyupi, lbyuf
               call s2ext_abort
            end if
         end if
      end if
!
      scr  = 22.6054d0 / sqrt( wte )
      scfl = scr * svte
      if( scfl .gt. s1o1/sqrt(s2o1) ) then
         write(0,*) '### ERROR: CFL must be less than 1/sqrt(2).',scfl
         call s2ext_abort
      end if
      scflinv = s1o1 / scfl
!
      do i = 1, lpppl
         wgam = s1o1 / sqrt( s1o1 - ( wpppvdxe(i)**2 + &
                                  wpppvdye(i)**2 + wpppvdze(i)**2 ) )
         spppudxe(i) = wpppvdxe(i) * wgam * scfl
         spppudye(i) = wpppvdye(i) * wgam * scfl
         spppudze(i) = wpppvdze(i) * wgam * scfl
         wgam = s1o1 / sqrt( s1o1 - ( wpppvdxi(i)**2 + &
                                  wpppvdyi(i)**2 + wpppvdzi(i)**2 ) )
         spppudxi(i) = wpppvdxi(i) * wgam * scfl
         spppudyi(i) = wpppvdyi(i) * wgam * scfl
         spppudzi(i) = wpppvdzi(i) * wgam * scfl
      end do
!
      if( lbxlf .eq. 4 ) then
         sblsgxl = - log(sblsgxl) * (lblsgxl+1 ) * scfl*s1o2 / lpmlxl
      end if
      if( lbxuf .eq. 4 ) then
         sblsgxu = - log(sblsgxu) * (lblsgxu+1 ) * scfl*s1o2 / lpmlxu
      end if
      if( lbylf .eq. 4 ) then
         sblsgyl = - log(sblsgyl) * (lblsgyl+1 ) * scfl*s1o2 / lpmlyl
      end if
      if( lbyuf .eq. 4 ) then
         sblsgyu = - log(sblsgyu) * (lblsgyu+1 ) * scfl*s1o2 / lpmlyu
      end if
!
      if( lclflge .gt. 0 ) then
        il = lclflge / 10
        if( il .eq. 0 ) then
          if( lrank .le. 0 ) &
          write(0,*) '### WARNING: ', &
             'number of areas is 0 for lclflge, set to 1.', lclflge
          lclflge = lclflge + 10
          il = 1
        else if( il .gt. lclflgex ) then
          write(0,*) '### ERROR: ', &
              'number of areas overflow for lclflge.', lclflge, lclflgex
          call s2ext_abort
        end if
        do i = 1, il
          scluure(i) = wclvvre(i) * svte/sqrt(s1o1-(wclvvre(i)/scr)**2)
          scluule(i) = wclvvle(i) * svte/sqrt(s1o1-(wclvvle(i)/scr)**2)
          scluu0e(i) = wclvv0e(i) * svte/sqrt(s1o1-(wclvv0e(i)/scr)**2)
          sclfcte(i) = wclfcte(i) * sdelt
        end do
      end if
!
      do io = 1, lionspl
        if( lclflgi(io) .gt. 0 ) then
          il = lclflgi(io) / 10
          if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
              'number of areas is 0 for lclflgi, set to 1.', &
              io, lclflgi(io)
            lclflgi(io) = lclflgi(io) + 10
            il = 1
          else if( il .gt. lclflgix ) then
            write(0,*) '### ERROR: ', &
              'number of areas overflow for lclflgi.', &
              io, lclflgi(io), lclflgix
            call s2ext_abort
          end if
          acr = scr / sqrt( smasr / sionam(io) * stemr )
          do i = 1, il
            scluuri(i,io) = wclvvri(i,io) * svti(io) / &
                                      sqrt(s1o1-(wclvvri(i,io)/acr)**2)
            scluuli(i,io) = wclvvli(i,io) * svti(io) / &
                                      sqrt(s1o1-(wclvvli(i,io)/acr)**2)
            scluu0i(i,io) = wclvv0i(i,io) * svti(io) / &
                                      sqrt(s1o1-(wclvv0i(i,io)/acr)**2)
            sclfcti(i,io) = wclfcti(i,io) * sdelt
          end do
        end if
      end do
!..
      do i = 1, lpppl
         if ( spppte(i) .le. sundef ) then
            spppte(i) = s1o1
         else
            spppte(i) = spppte(i) / wte
         end if
         if ( spppti(i) .le. sundef ) then
            spppti(i) = s1o1
         else
            spppti(i) = spppti(i) / wti
         end if
      end do
!..
      if( llsrbn .gt. llsrbx ) then
         write(0,*)'### ERROR: llsrbn must be less than llsrbx.', &
                   llsrbn, llsrbx
         call s2ext_abort
      end if
!
      slomg  = sqrt( sncinv )
      slram  = s2pi * sgrid * scr / slomg
      sdtfs = sdelt / sqrt( wncmax ) * slramm * 0.5308846d0
      do i = 1, llsrbn
         if( lbemty(i) .le. 0 ) lbemty(i) = llsrty
         if( lbemix(i) .eq. 0 ) lbemix(i) = llinx
         if( sbempw(i) .le. sundef ) sbempw(i) = slpwr
         if( sbemwl(i) .le. sundef ) sbemwl(i) = slramm
         if( sbemle(i) .le. sundef ) sbemle(i) = slsrle
         if( sbemwd(i) .le. sundef ) sbemwd(i) = slsrwd
         if( sbemtr(i) .le. sundef ) sbemtr(i) = slsrtr
         if( sbemmn(i) .le. sundef ) sbemmn(i) = slsrmn
         if( sbemfi(i) .le. sundef ) sbemfi(i) = slsrfi
         if( sbemal(i) .le. sundef ) sbemal(i) = slsral
         sbemanr(i) = sbeman(i) * sd2r
         sbemomg(i) = slomg * slramm / sbemwl(i)
         sla(i) = sqrt( sbempw(i) / 1.368165d18 )
         if( lbemty(i) / 100 .ge. 3 ) then
            sla(i) = sla(i) / sqrt( s2o1 )
         end if
      end do
      lltcur = 0
      lstend = sstend / sdtfs
!....                                        * observation parameters *
      bbifntp = 'fort.%%.###'
      bfrfntp = '&K-&I-###'
!..
      ifsec = s1o1 / sdtfs
      iote  = s2pi / sdelt
      ioteh = iote / 2
!ion  ioti  = s2pi / sdelt / sqrt(smasr/savmi*savzi)
!ion  iotih = ioti / 2
      ioti  = 1
      iotih = 1
      iotl  = s2pi / sdelt / slomg
      iotlh = iotl / 2
!.
      iote = max( iote, 1 )
      ioteh= max( ioteh, 1 )
      ioti = max( ioti, 1 )
      iotih= max( iotih, 1 )
      iotl = max( iotl, 1 )
      iotlh= max( iotlh, 1 )
!..                                                  * time in [fsec] *
      sotstr = 0.0
      sotend = 0.0
      sotint = 10.0
!..
      soxps  = sundeff
      soxpe  = sundeff
      loxpi  = 1
      loxp0  = -1
      soyps  = sundeff
      soype  = sundeff
      loypi  = 1
      loyp0  = -1
!.
      loeng  = 1
      loenga = ioteh
      lopem  = 0
      do i = 1, lopemx
         sopemfct(i) = 5.0
         sopemxps(i) = sundeff
         sopemxpe(i) = sundeff
         sopemyps(i) = sundeff
         sopemype(i) = sundeff
      end do
      lopee  = 0
      do i = 1, lopeex
         sopeefct(i) = 4.0
         sopeexps(i) = sundeff
         sopeexpe(i) = sundeff
         sopeeyps(i) = sundeff
         sopeeype(i) = sundeff
      end do
      lopeph = 0
      do i = 1, lopephx
         sopephxps(i) = sundeff
         sopephxpe(i) = sundeff
         sopephyps(i) = sundeff
         sopephype(i) = sundeff
         sopephuxm(i) = -1.0d0
         sopephuxx(i) =  1.0d0
      end do
      lopim  = 0
      do i = 1, lopimx
         do io = 1, lionspx
            sopimfct(i,io) = 1.0
         end do
         do io = 1, lionspl
            sopimfct(i,io) = 5.0 / sqrt( sionam(io)/smasr * stemr )
         end do
         sopimxps(i) = sundeff
         sopimxpe(i) = sundeff
         sopimyps(i) = sundeff
         sopimype(i) = sundeff
      end do
      lopie  = 0
      do i = 1, lopiex
         do io = 1, lionspx
            sopiefct(i,io) = 4.0
         end do
         sopiexps(i) = sundeff
         sopiexpe(i) = sundeff
         sopieyps(i) = sundeff
         sopieype(i) = sundeff
      end do
      lopiph = 0
      do i = 1, lopiphx
         sopiphxps(i) = sundeff
         sopiphxpe(i) = sundeff
         sopiphyps(i) = sundeff
         sopiphype(i) = sundeff
         sopiphuxm(i) = -1.0d0
         sopiphuxx(i) =  1.0d0
      end do
      lopesap = 0
      lopesapa = iote
      lopisap = 0
      lopisapa = ioti
      lofde  = 0
      lofdea = iote
      lofdi  = 0
      lofdia = ioti
      lofdc  = 0
      lofdca = iote
      lofte  = 0
      loftea = iote
      lofede = 0
      lofedi = 0
      lofje  = 0
      sofjehot = 0.7d0
      lofjea = iote
      lofji  = 0
      lofjia = iote
      lofjt  = 0
      lofjta = iote
      lofea  = 0
      lofeaa = iotlh
      lofer  = 0
      lofera = iotl
      lofek  = 0
      do i = 1, lofekx
         sofekxps(i) = sundeff
         sofekxpe(i) = sundeff
         sofekyps(i) = sundeff
         sofekype(i) = sundeff
      end do
      sofekmax = 10.0d0
      lofew  = 0
      do i = 1, lofewx
         sofewxp(i) = s0o1
         sofewyp(i) = s0o1
      end do
      lofba  = 0
      lofbaa = iotlh
      lofbr  = 0
      lofbra = iotl
!.
      read(5,nml=observ)
!....
      if( lofek .gt. 0 ) then
         il = lofek / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lofek, set to 1.', lofek
            lofek = lofek + 100
         else if( il .gt. lofekx ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lofek.', lofek, lofekx
            call s2ext_abort
         end if
      end if
      if( lofew .gt. 0 ) then
         il = lofew / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lofew, set to 1.', lofew
            lofew = lofew + 100
         else if( il .gt. lofewx ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lofew.', lofew, lofewx
            call s2ext_abort
         end if
      end if
      if( lopem .gt. 0 ) then
         il = lopem / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopem, set to 1.', lopem
            lopem = lopem + 100
         else if( il .gt. lopemx ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lopem.', lopem, lopemx
            call s2ext_abort
         end if
      end if
      if( lopee .gt. 0 ) then
         il = lopee / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopee, set to 1.', lopee
            lopee = lopee + 100
         else if( il .gt. lopeex ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lopee.', lopee, lopeex
            call s2ext_abort
         end if
      end if
      if( lopeph .gt. 0 ) then
         il = lopeph / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopeph, set to 1.', lopeph
            lopeph = lopeph + 100
         else if( il .gt. lopephx ) then
            write(0,*) '### ERROR: ', &
            'number of positions overflow for lopeph.', lopeph, lopephx
            call s2ext_abort
         end if
      end if
      if( lopim .gt. 0 ) then
         il = lopim / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopim, set to 1.', lopim
            lopim = lopim + 100
         else if( il .gt. lopimx ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lopim.', lopim
            call s2ext_abort
         end if
      end if
      if( lopie .gt. 0 ) then
         il = lopie / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopie, set to 1.', lopie
            lopie = lopie + 100
         else if( il .gt. lopiex ) then
            write(0,*) '### ERROR: ', &
               'number of positions overflow for lopie.', lopie
            call s2ext_abort
         end if
      end if
      if( lopiph .gt. 0 ) then
         il = lopiph / 100
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
               'number of positions is 0 for lopiph, set to 1.', lopiph
            lopiph = lopiph + 100
         else if( il .gt. lopiphx ) then
            write(0,*) '### ERROR: ', &
            'number of positions overflow for lopiph.', lopiph, lopiphx
            call s2ext_abort
         end if
      end if
!..
      iotint = sotint / sdtfs
      if( loeng .ne. 0 ) then
         if( loenga .le. 0 ) then
            write(0,*) '### ERROR: loenga is less than 0.', loenga
            call s2ext_abort
         end if
         if( iotint - loenga .lt. 0 ) then
            write(0,*) '### ERROR: loenga is greater than interval.',  &
                      loenga, iotint
            call s2ext_abort
         end if
      end if
      if( lofde .ne. 0 ) then
         if( lofdea .le. 0 ) then
            write(0,*) '### ERROR: lofdea is less than 0.', lofdea
            call s2ext_abort
         end if
         if( iotint - lofdea .lt. 0 ) then
            write(0,*) '### ERROR: lofdea is greater than interval.',  &
                      lofdea, iotint
            call s2ext_abort
         end if
      end if
      if( lofdi .ne. 0 ) then
         if( lofdia .le. 0 ) then
            write(0,*) '### ERROR: lofdia is less than 0.', lofdia
            call s2ext_abort
         end if
         if( iotint - lofdia .lt. 0 ) then
            write(0,*) '### ERROR: lofdia is greater than interval.',  &
                      lofdia, iotint
            call s2ext_abort
         end if
      end if
      if( lofdc .ne. 0 ) then
         if( lofdca .le. 0 ) then
            write(0,*) '### ERROR: lofdca is less than 0.', lofdca
            call s2ext_abort
         end if
         if( iotint - lofdca .lt. 0 ) then
            write(0,*) '### ERROR: lofdca is greater than interval.',  &
                      lofdca, iotint
            call s2ext_abort
         end if
      end if
      if( lofte .ne. 0 ) then
         if( loftea .le. 0 ) then
            write(0,*) '### ERROR: loftea is less than 0.', loftea
            call s2ext_abort
         end if
         if( iotint - loftea .lt. 0 ) then
            write(0,*) '### ERROR: loftea is greater than interval.',  &
                      loftea, iotint
            call s2ext_abort
         end if
      end if
      if( lofer .ne. 0 ) then
         if( lofera .le. 0 ) then
            write(0,*) '### ERROR: lofera is less than 0.', lofera
            call s2ext_abort
         end if
         if( iotint - lofera .lt. 0 ) then
            write(0,*) '### ERROR: lofera is greater than interval.',  &
                      lofera, iotint
            call s2ext_abort
         end if
      end if
      if( lofea .ne. 0 ) then
         if( lofeaa .le. 0 ) then
            write(0,*) '### ERROR: lofeaa is less than 0.', lofeaa
            call s2ext_abort
         end if
         if( iotint - lofeaa .lt. 0 ) then
            write(0,*) '### ERROR: lofeaa is greater than interval.',  &
                      lofeaa, iotint
            call s2ext_abort
         end if
      end if
      if( lofbr .ne. 0 ) then
         if( lofbra .le. 0 ) then
            write(0,*) '### ERROR: lofbra is less than 0.', lofbra
            call s2ext_abort
         end if
         if( iotint - lofbra .lt. 0 ) then
            write(0,*) '### ERROR: lofbra is greater than interval.',  &
                      lofbra, iotint
            call s2ext_abort
         end if
      end if
      if( lofba .ne. 0 ) then
         if( lofbaa .le. 0 ) then
            write(0,*) '### ERROR: lofbaa is less than 0.', lofbaa
            call s2ext_abort
         end if
         if( iotint - lofbaa .lt. 0 ) then
            write(0,*) '### ERROR: lofbaa is greater than interval.',  &
                      lofbaa, iotint
            call s2ext_abort
         end if
      end if
      if( lofje .ne. 0 ) then
         if( lofjea .le. 0 ) then
            write(0,*) '### ERROR: lofjea is less than 0.', lofjea
            call s2ext_abort
         end if
         if( iotint - lofjea .lt. 0 ) then
            write(0,*) '### ERROR: lofjea is greater than interval.',  &
                      lofjea, iotint
            call s2ext_abort
         end if
      end if
      if( lofji .ne. 0 ) then
         if( lofjia .le. 0 ) then
            write(0,*) '### ERROR: lofjia is less than 0.', lofjia
            call s2ext_abort
         end if
         if( iotint - lofjia .lt. 0 ) then
            write(0,*) '### ERROR: lofjia is greater than interval.',  &
                      lofjia, iotint
            call s2ext_abort
         end if
      end if
      if( lofjt .ne. 0 ) then
         if( lofjta .le. 0 ) then
            write(0,*) '### ERROR: lofjta is less than 0.', lofjta
            call s2ext_abort
         end if
         if( iotint - lofjta .lt. 0 ) then
            write(0,*) '### ERROR: lofjta is greater than interval.',  &
                      lofjta, iotint
            call s2ext_abort
         end if
      end if
      if( lopesap .ne. 0 ) then
         if( lopesapa .le. 0 ) then
            write(0,*) '### ERROR: lopesapa is less than 0.', lopesapa
            call s2ext_abort
         end if
         if( iotint - lopesapa .lt. 0 ) then
            write(0,*) '### ERROR: lopesapa is greater than interval.',&
                      lopesapa, iotint
            call s2ext_abort
         end if
         il = mod( lopesap/100, 100 )
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
          'number of cross section is 0 for lopesap, set to 1.', lopesap
            lopesap = lopesap + 100
         end if
      end if
      if( lopisap .ne. 0 ) then
         if( lopisapa .le. 0 ) then
            write(0,*) '### ERROR: lopisapa is less than 0.', lopisapa
            call s2ext_abort
         end if
         if( iotint - lopisap .lt. 0 ) then
            write(0,*) '### ERROR: lopisapa is greater than interval.',&
                      lopisapa, iotint
            call s2ext_abort
         end if
         il = mod( lopisap/100, 100 )
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
          'number of cross section is 0 for lopisap, set to 1.', lopisap
            lopisap = lopisap + 100
         end if
      end if
!....
      lstcur = 0
      sstcur = s0o1
      sotnxt = sotstr
      lotnxt = sotnxt / sdtfs
      slmic  = slram / slramm
      slmicinv  = s1o1 / slmic
      soxmic = loxpi * slmicinv
      soymic = loypi * slmicinv
      sofjehot = sofjehot * scfl
!....                                          * animation parameters *
!..                                                  * time in [fsec] *
      satstr = 0.0
      satend = 0.0
      satint = 0.0
!..
      lapepl   = 0
      lapeuxyl = 0
      lapeuxzl = 0
      lapeuyzl = 0
      lapexuxl = 0
      lapexuyl = 0
      lapexuzl = 0
      lapipl   = 0
      lapiuxyl = 0
      lapixuxl = 0
      lapixuyl = 0
      lafdel   = 0
      lafdil   = 0
      lafedel  = 0
      lafedil  = 0
      lafjexl  = 0
      lafjeyl  = 0
      lafjezl  = 0
      lafeal   = 0
      lafexl   = 0
      lafeyl   = 0
      lafezl   = 0
      lafbal   = 0
      lafbxl   = 0
      lafbyl   = 0
      lafbzl   = 0
!..
      do i = 1, 3
         lapep(i)   = 0
         lapeuxy(i) = 0
         lapeuxz(i) = 0
         lapeuyz(i) = 0
         lapexux(i) = 0
         lapexuy(i) = 0
         lapexuz(i) = 0
         lapip(i)   = 0
         lapiuxy(i) = 0
         lapixux(i) = 0
         lapixuy(i) = 0
         lafde(i)   = 0
         lafdi(i)   = 0
         lafede(i)  = 0
         lafedi(i)  = 0
         lafjex(i)  = 0
         lafjey(i)  = 0
         lafjez(i)  = 0
         lafea(i)   = 0
         lafex(i)   = 0
         lafey(i)   = 0
         lafez(i)   = 0
         lafba(i)   = 0
         lafbx(i)   = 0
         lafby(i)   = 0
         lafbz(i)   = 0
      end do
!..
      lagfl = 0
      lavpl = 1
      lawnl = 1
      do i = 1, lagfx
         lamode(i) = 1
         lagifw(i) = 640
         lagifh(i) = 480
         banfntp(i) = '&K%-&I-###'
      end do
      do i = 1, lavpx
         savpxm(i) = 0.0
         savpxx(i) = 1.0
         savpym(i) = 0.0
         savpyx(i) = 1.0
      end do
      do i = 1, lawnx
         sawnxm(i) = sundeff
         sawnxx(i) = sundeff
         sawnym(i) = sundeff
         sawnyx(i) = sundeff
         sawnzm(i) = s1o1
         sawnzx(i) = s0o1
      end do
!.
      read(5,nml=anime)
!..
      satnxt = satstr
      latnxt = satnxt / sdtfs
!....                                      * Fast Particle parameters *
      lopfeed   = 0
      lopfeeda  = iotl
      lopfeedrl = 100
      lopfeedml = 16
      lopfeednl = 10
      lopfeedc  = 0
      do i = 1, lopfeedx
         lopfeedyl(i) = 1
         sopfeedx(i)  = sundeff
         sopfeedys(i) = sundeff
         sopfeedye(i) = sundeff
      end do
      sopfeedr  = s2o1
      sopfeedm  = s1o1
      lopfied   = 0
      lopfieda  = iotl
      lopfiedrl = 100
      lopfiedml = 16
      lopfiednl = 10
      lopfiedc  = 0
      lopfiedyl = 1
      do i = 1, lopfiedx
         lopfiedyl(i) = 1
         sopfiedx(i)  = sundeff
         sopfiedys(i) = sundeff
         sopfiedye(i) = sundeff
      end do
      do i = 1, lionspl
         sopfiedr(i)  = s2o1
         sopfiedm(i)  = sionaf(i)
      end do
      bfpfntpe  = '&K-&I-%-###.dat'
      bfpfntpi  = '&K-&I-%-###.dat'
!.
      read(5,nml=fpparam)
!....
      if( lopfeed .gt. 0 ) then
         if( lopfeeda .le. 0 ) then
            write(0,*) '### ERROR: lopfeeda is less than 0.', lopfeeda
            call s2ext_abort
         end if
         if( iotint - lopfeeda .lt. 0 ) then
            write(0,*) '### ERROR: lopfeeda is greater than interval.',&
                      lopfeeda, iotint
            call s2ext_abort
         end if
         il = lopfeed / 10
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
             'number of positions is 0 for lopfeed, set to 1.', lopfeed
            lopfeed = lopfeed + 10
         else if( il .gt. lopfeedx ) then
            write(0,*) '### ERROR: ', &
         'number of positions overflow for lopfeed.', lopfeed, lopfeedx
            call s2ext_abort
         end if
      end if
      if( lopfied .gt. 0 ) then
         if( lopfieda .le. 0 ) then
            write(0,*) '### ERROR: lopfieda is less than 0.', lopfieda
            call s2ext_abort
         end if
         if( iotint - lopfieda .lt. 0 ) then
            write(0,*) '### ERROR: lopfieda is greater than interval.',&
                      lopfieda, iotint
            call s2ext_abort
         end if
         il = lopfied / 10
         if( il .eq. 0 ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: ', &
             'number of positions is 0 for lopfied, set to 1.', lopfied
            lopfied = lopfied + 10
         else if( il .gt. lopfiedx ) then
            write(0,*) '### ERROR: ', &
         'number of positions overflow for lopfied.', lopfied, lopfiedx
            call s2ext_abort
         end if
      end if
!....
      if( lrank .le. 0 .or. ldebug .ge. 2 ) then
        write(6,1000) lionspx, lpppx, lppphx, llsrbx, lclflgex, &
                    lclflgix, ltimex, &
                    lopemx, lopeex, lopimx, lopiex, lopephx, lopiphx, &
                    lofekx, lofewx, lopfeedx, lopfiedx, &
                    lavpx, lawnx, lagfx, laxxx
 1000 format('parameter start' / &
            ' lionspx = ', i10 / ' lpppx   = ', i10 / &
            ' lppphx  = ', i10 / ' llsrbx  = ', i10 / &
            ' lclflgex= ', i10 / ' lclflgix= ', i10 / &
            ' ltimex  = ', i10 / &
            ' lopemx  = ', i10 / ' lopeex  = ', i10 / &
            ' lopimx  = ', i10 / ' lopiex  = ', i10 / &
            ' lopephx = ', i10 / ' lopiphx = ', i10 / &
            ' lofekx  = ', i10 / ' lofewx  = ', i10 / &
            ' lopfeedx= ', i10 / ' lopfiedx= ', i10 / &
            ' lavpx   = ', i10 / ' lawnx   = ', i10 / &
            ' lagfx   = ', i10 / ' laxxx   = ', i10 / &
            'parameter  end' )
        write(6,nml=numeri)
        write(6,nml=cntrl)
        write(6,nml=plasma)
        write(6,nml=laser)
        write(6,nml=observ)
        write(6,nml=anime)
        write(6,nml=fpparam)
      end if
!....
      call fdebug ( 's2simp', 1 )
!....
      return
      end
