!----------------------------------------------------------------------
! Set 2D EXTernal system TERMinate
!
      subroutine s2ext_term
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
! #ifdef OHHELP
!       include "implicit.h"
!       integer :: impierr
! #endif
!....
      call fdebug ( 's2ext_term', 0 )
!....
! #ifdef OHHELP
!       call MPI_FINALIZE ( impierr )
!       if( impierr .ne. 0 ) &
!          write(0,*) '### ERROR: MPI_FINALIZE, impierr =', impierr
! #endif
!....
      call frames_term
!..
      call gdfxs_term
!....
      call fdebug ( 's2ext_term', 1 )
!....
      return
      end
