!-----------------------------------------------------------------------
! Boundary condition 2D Field Electric - TM
!
      subroutine b2fetm
!
!   <arguments>
!     none
!
!   <remarks>
!     sex(0,iy), sex(lssxup2,iy), sey(ix,0), sey(ix,lssyup2) are just
!   needed for references by particles.
!     Only periodic and PML conditions are correctly cared.
!
! original coded by Hata,M. (Nagoya Univ.) 11/06/24
!    coded by Sakagami,H. (NIFS) 11/07/27
!----------------------------------------------------------------------
#include "sfield.macro"
      use constant
      use control
      use field
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'b2fetm', 0 )
!....
!$OMP PARALLEL
!....
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sex(lssxlm1,iy) = sex(lssxum1,iy)
         end do
!..
      else if( lexlf .eq. 2 .or. lexlf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sex(lssxlm1,iy) = sex(lssxl,iy)
         end do
!..
      else if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lblxl, lssxlm1
               sex(ix,iy) = sex(ix,iy)+( sbz(ix,iy+1)-sbz(ix,iy) )*scb1
            end do
!           do ix = lssxlm2, lssxlm1
!              sex(ix,iy) = sex(ix,iy) + sjxt(ix,iy) * scj1
!           end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyup1
            do ix = lblxlm1, lssxlm2
               sey(ix,iy) = scaxlh(ix) * sey(ix,iy) - &
                      scbetmxl(ix)*sbz(ix+1,iy)+sccetmxl(ix)*sbz(ix,iy)
            end do
!           sey(lssxlm2,iy) = sey(lssxlm2,iy) + sjyt(lssxlm2,iy) * scj1
         end do
      end if
!...
      if( lexuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sex(lssxup2,iy) = sex(lssxlp2,iy)
         end do
!..
      else if( lexuf .eq. 2 .or. lexuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup1
            sex(lssxup2,iy) = sex(lssxup1,iy)
         end do
!..
      else if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lssxup2, lblxu
               sex(ix,iy) = sex(ix,iy)+( sbz(ix,iy+1)-sbz(ix,iy) )*scb1
            end do
!           do ix = lssxup2, lssxup3
!              sex(ix,iy) = sex(ix,iy) + sjxt(ix,iy) * scj1
!           end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyup1
            do ix = lssxup2, lblxu
               sey(ix,iy) = scaxuh(ix) * sey(ix,iy) - &
                      scbetmxu(ix)*sbz(ix+1,iy)+sccetmxu(ix)*sbz(ix,iy)
            end do
!           sey(lssxup2,iy) = sey(lssxup2,iy) + sjyt(lssxup2,iy) * scj1
         end do
      end if
!...
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sey(ix,lssylm1) = sey(ix,lssyum1)
         end do
!..
      else if( leylf .eq. 2 .or. leylf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sey(ix,lssylm1) = sey(ix,lssyl)
         end do
!..
      else if( leylf .eq. 4 ) then
         do iy = lblylm1, lssylm2
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxl, lssxup1
               sex(ix,iy) = scaylh(iy) * sex(ix,iy) + &
                      scbetmyl(iy)*sbz(ix,iy+1)-sccetmyl(iy)*sbz(ix,iy)
            end do
         end do
! !$OMP DO SCHEDULE(STATIC)
!        do ix = lssxl, lssxup1
!           sex(ix,lssylm2) = sex(ix,lssylm2) + sjxt(ix,lssylm2) * scj1
!        end do
!.
         do iy = lblyl, lssylm1
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup1
               sey(ix,iy) = sey(ix,iy)-( sbz(ix+1,iy)-sbz(ix,iy) )*scb1
            end do
         end do
!        do iy = lssylm2, lssylm1
! !$OMP DO SCHEDULE(STATIC)
!           do ix = lssxlm1, lssxup1
!              sey(ix,iy) = sey(ix,iy) + sjyt(ix,iy) * scj1
!           end do
!        end do
!.
         if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblylm1, lssylm2
               do ix = lblxl, lssxlm1
                  sex(ix,iy) = scaylh(iy) * sex(ix,iy) + &
                      scbetmyl(iy)*sbz(ix,iy+1)-sccetmyl(iy)*sbz(ix,iy)
               end do
            end do
!           do ix = lssxlm2, lssxlm1
!              sex(ix,lssylm2) = sex(ix,lssylm2) + sjxt(ix,lssylm2)*scj1
!           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblyl, lssylm1
               do ix = lblxlm1, lssxlm2
                  sey(ix,iy) = scaxlh(ix) * sey(ix,iy) - &
                      scbetmxl(ix)*sbz(ix+1,iy)+sccetmxl(ix)*sbz(ix,iy)
               end do
            end do
!           do iy = lssylm2, lssylm1
!              sey(lssxlm2,iy) = sey(lssxlm2,iy) + sjyt(lssxlm2,iy)*scj1
!           end do
         end if
!.
         if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblylm1, lssylm2
               do ix = lssxup2, lblxu
                  sex(ix,iy) = scaylh(iy) * sex(ix,iy) + &
                      scbetmyl(iy)*sbz(ix,iy+1)-sccetmyl(iy)*sbz(ix,iy)
               end do
            end do
!           do ix = lssxup2, lssxup3
!              sex(ix,lssylm2) = sex(ix,lssylm2) + sjxt(ix,lssylm2)*scj1
!           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblyl, lssylm1
               do ix = lssxup2, lblxu
                  sey(ix,iy) = scaxuh(ix) * sey(ix,iy) - &
                      scbetmxu(ix)*sbz(ix+1,iy)+sccetmxu(ix)*sbz(ix,iy)
               end do
            end do
!           do iy = lssylm2, lssylm1
!              sey(lssxup2,iy) = sey(lssxup2,iy) + sjyt(lssxup2,iy)*scj1
!           end do
         end if
      end if
!...
      if( leyuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sey(ix,lssyup2) = sey(ix,lssylp2)
         end do
!..
      else if( leyuf .eq. 2 .or. leyuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm1, lssxup1
            sey(ix,lssyup2) = sey(ix,lssyup1)
         end do
!..
      else if( leyuf .eq. 4 ) then
         do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxl, lssxup1
               sex(ix,iy) = scayuh(iy) * sex(ix,iy) + &
                      scbetmyu(iy)*sbz(ix,iy+1)-sccetmyu(iy)*sbz(ix,iy)
            end do
         end do
! !$OMP DO SCHEDULE(STATIC)
!        do ix = lssxl, lssxup1
!           sex(ix,lssyup2) = sex(ix,lssyup2) + sjxt(ix,lssyup2) * scj1
!        end do
!.
         do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup1
               sey(ix,iy) = sey(ix,iy)-( sbz(ix+1,iy)-sbz(ix,iy) )*scb1
            end do
         end do
!        do iy = lssyup2, lssyup3
! !$OMP DO SCHEDULE(STATIC)
!           do ix = lssxlm1, lssxup1
!              sey(ix,iy) = sey(ix,iy) + sjyt(ix,iy) * scj1
!           end do
!        end do
!.
         if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyup2, lblyu
               do ix = lblxl, lssxlm1
                  sex(ix,iy) = scayuh(iy) * sex(ix,iy) + &
                      scbetmyu(iy)*sbz(ix,iy+1)-sccetmyu(iy)*sbz(ix,iy)
               end do
            end do
!           do ix = lssxlm2, lssxlm1
!              sex(ix,lssyup2) = sex(ix,lssyup2) + sjxt(ix,lssyup2)*scj1
!           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyup2, lblyu
               do ix = lblxlm1, lssxlm2
                  sey(ix,iy) = scaxlh(ix) * sey(ix,iy) - &
                      scbetmxl(ix)*sbz(ix+1,iy)+sccetmxl(ix)*sbz(ix,iy)
               end do
            end do
!           do iy = lssyup2, lssyup3
!              sey(lssxlm2,iy) = sey(lssxlm2,iy) + sjyt(lssxlm2,iy)*scj1
!           end do
         end if
!.
         if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyup2, lblyu
               do ix = lssxup2, lblxu
                  sex(ix,iy) = scayuh(iy) * sex(ix,iy) + &
                      scbetmyu(iy)*sbz(ix,iy+1)-sccetmyu(iy)*sbz(ix,iy)
               end do
            end do
!           do ix = lssxup2, lssxup3
!              sex(ix,lssyup2) = sex(ix,lssyup2) + sjxt(ix,lssyup2)*scj1
!           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyup2, lblyu
               do ix = lssxup2, lblxu
                  sey(ix,iy) = scaxuh(ix) * sey(ix,iy) - &
                      scbetmxu(ix)*sbz(ix+1,iy)+sccetmxu(ix)*sbz(ix,iy)
               end do
            end do
!           do iy = lssyup2, lssyup3
!              sey(lssxup2,iy) = sey(lssxup2,iy) + sjyt(lssxup2,iy)*scj1
!           end do
         end if
      end if
!....
!$OMP END PARALLEL
!....
      call fdebug ( 'b2fetm', 1 )
!....
      return
      end
