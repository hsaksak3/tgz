!----------------------------------------------------------------------
! Observe 2D Particle Ion Momentum
!                          /
      subroutine o2pim ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     If change lpmx here, must change in frames.f.
!
!    coded by Sakagami,H. (NIFS) 10/07/18
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: lpmx = 301, lpmx2 = (lpmx-1) / 2 + 1
      integer, parameter :: iun = 30, ifn = 11
      integer :: kflag, i, is, io, ix, iy ,iz, iopim, ilog, iopiml
      real*8  :: wopimxps(lopimx), wopimxpe(lopimx), &
                 wopimyps(lopimx), wopimype(lopimx), ww
      real*8, allocatable :: apimxyn(:,:,:,:), apimxzn(:,:,:,:), &
                             apimyzn(:,:,:,:), &
                             apimxn(:,:,:), apimyn(:,:,:), apimzn(:,:,:)
      character :: clabel*20
      save
!....
      call fdebug ( 'o2pim', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         do is = 1, lionspl
           do io = 1, iopiml
             do iy = 1, lpmx
               apimxn(iy,io,is) = s0o1
               apimyn(iy,io,is) = s0o1
               apimzn(iy,io,is) = s0o1
               do ix = 1, lpmx
                  apimxyn(ix,iy,io,is) = s0o1
                  apimyzn(ix,iy,io,is) = s0o1
                  apimxzn(ix,iy,io,is) = s0o1
               end do
             end do
           end do
         end do
!.
         do is = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP       REDUCTION(+:apimxn,apimyn,apimzn,apimxyn,apimyzn,apimxzn), &
!$OMP       PRIVATE(io,ix,iy,iz,ww)
         do i = lionids(is), lionide(is)
          do io = 1, iopiml
            if(sxi(i).ge.sopimxps(io).and.sxi(i).le.sopimxpe(io) .and. &
               syi(i).ge.sopimyps(io).and.syi(i).le.sopimype(io)) then
               ww = suxi(i) *scflinv*sionmm(is)* sopimfct(io,is)
               ix = sign( abs(ww) + s1o2, ww )
               ix = ix + lpmx2
               ix = max( ix, 1 )
               ix = min( ix, lpmx )
               ww = suyi(i) *scflinv*sionmm(is)* sopimfct(io,is)
               iy = sign( abs(ww) + s1o2, ww )
               iy = iy + lpmx2
               iy = max( iy, 1 )
               iy = min( iy, lpmx )
               ww = suzi(i) *scflinv*sionmm(is)* sopimfct(io,is)
               iz = sign( abs(ww) + s1o2, ww )
               iz = iz + lpmx2
               iz = max( iz, 1 )
               iz = min( iz, lpmx )
               apimxn(ix,io,is)     = apimxn(ix,io,is) + spfi(i)
               apimyn(iy,io,is)     = apimyn(iy,io,is) + spfi(i)
               apimzn(iz,io,is)     = apimzn(iz,io,is) + spfi(i)
               apimxyn(ix,iy,io,is) = apimxyn(ix,iy,io,is) + spfi(i)
               apimyzn(iy,iz,io,is) = apimyzn(iy,iz,io,is) + spfi(i)
               apimxzn(ix,iz,io,is) = apimxzn(ix,iz,io,is) + spfi(i)
             end if
           end do
         end do
         end do
!..
         if( iopim .le. 4 ) then
            write(iun)sstcur, ( ( &
               (apimxn(ix,io,is),ix=1,lpmx), &
               (apimyn(iy,io,is),iy=1,lpmx), &
               (apimzn(iz,io,is),iz=1,lpmx), &
              ((apimxyn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx), &
              ((apimyzn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx),  &
              ((apimxzn(ix,iy,io,is),ix=1,lpmx),iy=1,lpmx),  &
                io=1,iopiml ), is=1,lionspl )
            flush(iun)
         end if
!..
         if( iopim .ge. 2 ) then
           do is = 1, lionspl
             call o2ionlabel ( is, sionam(is), sionaz(is), clabel )
             do io = 1, iopiml
               call o2pdraw6 ( bident, sstcur, sminlog, lminlog, &
               ifn, ilog, 3, &
                    apimxn(1,io,is), apimyn(1,io,is), apimzn(1,io,is), &
           apimxyn(1,1,io,is), apimyzn(1,1,io,is), apimxzn(1,1,io,is), &
           lpmx, sopimfct(io,is), &
               wopimxps(io), wopimyps(io), wopimxpe(io), wopimype(io), &
             'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pim'//clabel ) 
             end do
           end do
         end if
!....
      else
         iopim  = mod( lopim, 10 )
         ilog   = mod( lopim/10, 10 )
         iopiml = mod( lopim/100, 10 )
!..
         if( .not. allocated(apimxyn) ) allocate( &
                             apimxyn(lpmx,lpmx,iopiml,lionspl), &
                             apimyzn(lpmx,lpmx,iopiml,lionspl), &
                             apimxzn(lpmx,lpmx,iopiml,lionspl), &
                             apimxn(lpmx,iopiml,lionspl), &
                             apimyn(lpmx,iopiml,lionspl), &
                             apimzn(lpmx,iopiml,lionspl) )
!..
         do io = 1, iopiml
            if( sopimxps(io) .le. sundef ) then
               sopimxps(io) = lxps
            else
               sopimxps(io) = sopimxps(io) * slmic + loxp0
            end if
            if( sopimxpe(io) .le. sundef ) then
               sopimxpe(io) = lxpe
            else
               sopimxpe(io) = sopimxpe(io) * slmic + loxp0
            end if
            if( sopimyps(io) .le. sundef ) then
               sopimyps(io) = lyps
            else
               sopimyps(io) = sopimyps(io) * slmic + loyp0
            end if
            if( sopimype(io) .le. sundef ) then
               sopimype(io) = lype
            else
               sopimype(io) = sopimype(io) * slmic + loyp0
            end if
            wopimxps(io) = ( sopimxps(io) - loxp0 ) * slmicinv
            wopimxpe(io) = ( sopimxpe(io) - loxp0 ) * slmicinv
            wopimyps(io) = ( sopimyps(io) - loyp0 ) * slmicinv
            wopimype(io) = ( sopimype(io) - loyp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopim[xy]p[se] = ', io, &
                wopimxps(io), wopimyps(io), wopimxpe(io), wopimype(io)
         end do
         if( iopim .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pim', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'pim2', bident, lpmx, iopiml, lionspl, &
           ( (sionam(is),sionaz(is),is=1,lionspl), &
             (sopimfct(io,is),is=1,lionspl), &
              wopimxps(io),wopimyps(io),wopimxpe(io),wopimype(io), &
              io=1,iopiml)
            flush(iun)
         end if
         if( iopim .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pim', bfile )
            call frames_file ( bfile, ifn, iopim )
         end if
!....
      end if
!....
      call fdebug ( 'o2pim', 1 )
!....
      return
      end
