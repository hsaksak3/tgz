!-----------------------------------------------------------------------
! Compute 2D Field current(J) Electron with Current Conservation
!
      subroutine c2fjecc
!
!   <arguments>
!     none
!
!   <remarks>
!     lccsch : current conservation scheme
!            : = 0 : Esirkepov's scheme
!            : = 1 : 1st order ZigZag scheme
!            : = 3 : 3rd order ZigZag scheme and 2nd order interpolation
!
!    coded by Sakagami,H. (NIFS) 20/11/04
!-----------------------------------------------------------------------
#include "spdat.macro"
#include "vector.macro"
      use constant
      include "implicit.h"
!....
      call fdebug ('c2fjecc', 0 )
!....
      select case( lccsch )
      case( 0 )
        call c2fjecc_esirkepov
#ifndef VECTOR
      case( 1 )
        call c2fjecc_zigzag1
#endif
      case( 3 )
        call c2fjecc_zigzag32
      case default
        write(0,*) '### ERROR: invalid lccsch', lccsch
        call s2ext_abort
      end select
!....
      call fdebug ( 'c2fjecc', 1 )
!....
      return
      end
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Electron with Current Conservation
! by Esirkepov's scheme
!
      subroutine c2fjecc_esirkepov
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
! original by Hata,M. (Nagoya Univ.) 09/11/06
!    coded by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, ixe, iye, ixea, iyea, idxe, idye, ii, ij
      real*8  :: wdx,wdxa,wdy,wdya
      real*8  :: wdffx(6), wdffy(6), wdjx(6,6), wdjy(6,6)
#ifndef VECTOR
      real*8  :: wffxo(6), wffx(6), wjjx(6,6), &
                 wffyo(6), wffy(6), wjjy(6,6)
#else
      real*8, allocatable :: vwffxo(:,:), vwffx(:,:), vwjjx(:,:,:), &
                             vwffyo(:,:), vwffy(:,:), vwjjy(:,:,:)
      integer :: iv, iv2
#endif
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:), wjye(:,:)
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
      if( lnoe .gt. 0 ) then
!....
      if ( .not. allocated(wjxe) ) then
         allocate( wjxe(lssxlm2:lssxup3,lssylm2:lssyup2), &
                   wjye(lssxlm2:lssxup2,lssylm2:lssyup3) )
      end if
!.
#ifndef VECTOR
!$OMP PARALLEL PRIVATE(ixe,wdx,wffxo,ixea,wdxa,idxe,wffx, &
!$OMP                  iye,wdy,wffyo,iyea,wdya,idye,wffy, &
!$OMP                  ii,ij,wjjx,wjjy,wdffx,wdffy,wdjx,wdjy,ix,iy)
#else
!$OMP PARALLEL PRIVATE(ixe,wdx,ixea,wdxa,idxe, &
!$OMP                  iye,wdy,iyea,wdya,idye, &
!$OMP                  ii,ij,wdffx,wdffy,wdjx,wdjy,ix,iy, &
!$OMP                  i,iv,vwffxo,vwffx,vwjjx,vwffyo,vwffy,vwjjy)
#endif
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            wjxe(ix,iy) = s0o1
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            wjye(ix,iy) = s0o1
         end do
      end do
!....
#ifdef VECTOR
      if ( .not. allocated(vwffxo) ) then
         allocate( vwffxo(lvlen,6), vwffx(lvlen,6), vwjjx(lvlen,6,6), &
                   vwffyo(lvlen,6), vwffy(lvlen,6), vwjjy(lvlen,6,6) )
      end if
      do iv = 1, lvlen
#endif
      _wffxo(1) = s0o1
      _wffxo(6) = s0o1
      _wffyo(1) = s0o1
      _wffyo(6) = s0o1
#ifdef VECTOR
      end do
#endif
!..
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye)
#ifndef VECTOR
      do i = lnoes, lnoee
#else
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
         _wffx(1) = s0o1
         _wffx(2) = s0o1
         _wffx(5) = s0o1
         _wffx(6) = s0o1
         _wffy(1) = s0o1
         _wffy(2) = s0o1
         _wffy(5) = s0o1
         _wffy(6) = s0o1
!..
         ixe = sxeo(i)
         wdx = sxeo(i) - ixe - s1o2
         _wffxo(2) = (s1o2-wdx)**3*s1o6
         _wffxo(3) = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
         _wffxo(4) =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
         _wffxo(5) = (s1o2+wdx)**3*s1o6
!.
         iye = syeo(i)
         wdy = syeo(i) - iye - s1o2
         _wffyo(2) = (s1o2-wdy)**3*s1o6
         _wffyo(3) = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
         _wffyo(4) =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
         _wffyo(5) = (s1o2+wdy)**3*s1o6
!.
         ixea = sxe(i)
         wdxa = sxe(i) - ixea - s1o2
         idxe = ixea - ixe
         _wffx(2+idxe) = (s1o2-wdxa)**3*s1o6
         _wffx(3+idxe) = (s1o2+wdxa)**2*(wdxa-s3o2)*s1o2 + s2o3
         _wffx(4+idxe) =-(s1o2-wdxa)**2*(wdxa+s3o2)*s1o2 + s2o3
         _wffx(5+idxe) = (s1o2+wdxa)**3*s1o6
!.
         iyea = sye(i)
         wdya = sye(i) - iyea - s1o2
         idye = iyea - iye
         _wffy(2+idye) = (s1o2-wdya)**3*s1o6
         _wffy(3+idye) = (s1o2+wdya)**2*(wdya-s3o2)*s1o2 + s2o3
         _wffy(4+idye) =-(s1o2-wdya)**2*(wdya+s3o2)*s1o2 + s2o3
         _wffy(5+idye) = (s1o2+wdya)**3*s1o6
#ifdef VECTOR
      end do
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
!..
!NEC$ UNROLL_COMPLETELY
         do ii = 1, 6
            wdffx(ii) = _wffx(ii) - _wffxo(ii)
            wdffy(ii) = _wffy(ii) - _wffyo(ii)
         end do
!..
!NEC$ UNROLL_COMPLETELY
         do ij = 1, 6
!NEC$ UNROLL_COMPLETELY
            do ii = 1, 6
               wdjx(ii,ij) = spfe(i) * wdffx(ii) &
                             * ( _wffyo(ij) + s1o2 * wdffy(ij) )
               wdjy(ii,ij) = spfe(i) * wdffy(ij) &
                             * ( _wffxo(ii) + s1o2 * wdffx(ii) )
            end do
         end do
!..
!NEC$ UNROLL_COMPLETELY
         do ij = 1, 6
            _wjjx(1,ij) = wdjx(1,ij)
            _wjjy(ij,1) = wdjy(ij,1)
!NEC$ UNROLL_COMPLETELY
            do ii = 1, 5
               _wjjx(ii+1,ij) = _wjjx(ii,ij) + wdjx(ii+1,ij)
               _wjjy(ij,ii+1) = _wjjy(ij,ii) + wdjy(ij,ii+1)
            end do
         end do
#ifdef VECTOR
      end do
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
         ixe = sxeo(i)
         iye = syeo(i)
#endif
!..
         do ij = 1, 6
            iy = ij + iye - 3
            do ii = 1, 6
               ix = ii + ixe - 3
               wjxe(ix+1,iy) = wjxe(ix+1,iy) + _wjjx(ii,ij)
               wjye(ix,iy+1) = wjye(ix,iy+1) + _wjjy(ii,ij)
            end do
         end do
#ifdef VECTOR
      end do
#endif
      end do
!...
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup2
            wjxe(lssxlm2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
            wjxe(lssxlm1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
            wjxe(lssxl  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
            wjxe(lssxlp1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
            wjxe(lssxlp2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
            wjxe(lssxlp3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup3
            wjye(lssxlm2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
            wjye(lssxlm1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
            wjye(lssxl  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
            wjye(lssxlp1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
            wjye(lssxlp2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
         end do
      end if
      if( lexuf .eq. 1 ) then
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
            end do
         end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup3
            wjxe(ix,lssylm2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
            wjxe(ix,lssylm1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
            wjxe(ix,lssyl  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
            wjxe(ix,lssylp1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
            wjxe(ix,lssylp2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
         end do
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup2
            wjye(ix,lssylm2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
            wjye(ix,lssylm1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
            wjye(ix,lssyl  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
            wjye(ix,lssylp1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
            wjye(ix,lssylp2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
            wjye(ix,lssylp3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
         end do
      end if
      if( leyuf .eq. 1 ) then
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
            end do
         end if
      end if
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            sjxe(ix,iy) = wjxe(ix,iy)
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            sjye(ix,iy) = wjye(ix,iy)
         end do
      end do
!...
!$OMP END PARALLEL
!....
      end if
!....
      return
      end
#ifndef VECTOR
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Electron with Current Conservation
! by 1st order ZigZag scheme
!
      subroutine c2fjecc_zigzag1
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/10/28
!----------------------------------------------------------------------
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, &
                 ixi1, ixh1, iyi1, iyh1, ixi2, ixh2, iyi2, iyh2
      real*8  :: wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
                 wdxi1, wdxi2, wdyi1, wdyi2, &
                 wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:), wjye(:,:)
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
      if( lnoe .gt. 0 ) then
!....
      if ( .not. allocated(wjxe) ) then
         allocate ( wjxe(lssxlm2:lssxup3,lssylm2:lssyup2), &
                    wjye(lssxlm2:lssxup2,lssylm2:lssyup3) )
      end if
!.
!$OMP PARALLEL PRIVATE(ixi1,ixh1,iyi1,iyh1,ixi2,ixh2,iyi2,iyh2, &
!$OMP                  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
!$OMP                  wdxi1, wdxi2, wdyi1, wdyi2, &
!$OMP                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i )
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            wjxe(ix,iy) = s0o1
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            wjye(ix,iy) = s0o1
         end do
      end do
!....
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye)
      do i = lnoes, lnoee
         ixi1 = sxeo(i)
         ixh1 = ixi1 + 1
         iyi1 = syeo(i)
         iyh1 = iyi1 + 1
         ixi2 = sxe(i)
         ixh2 = ixi2 + 1
         iyi2 = sye(i)
         iyh2 = iyi2 + 1
!.
         wmin = min(ixi1, ixi2) + 1
         wmax = max(ixi1, ixi2)
         wxr = min( wmin, max( wmax, (sxeo(i)+sxe(i))*s1o2 ) )
         wmin = min(iyi1, iyi2) + 1
         wmax = max(iyi1, iyi2)
         wyr = min( wmin, max( wmax, (syeo(i)+sye(i))*s1o2 ) )
!.
         wfx1 = ( sxeo(i) - wxr ) * spfe(i)
         wfx2 = ( wxr - sxe(i)  ) * spfe(i)
         wfy1 = ( syeo(i) - wyr ) * spfe(i)
         wfy2 = ( wyr - sye(i)  ) * spfe(i)
!.
         wdxi1 = (sxeo(i)+wxr)*s1o2 - ixi1
         wdxi2 = (sxe(i) +wxr)*s1o2 - ixi2
         wdyi1 = (syeo(i)+wyr)*s1o2 - iyi1
         wdyi2 = (sye(i) +wyr)*s1o2 - iyi2
!..
         wy1i = s1o1 - wdyi1
         wy2i = wdyi1
!
         wjxe(ixh1,iyi1  ) = wjxe(ixh1,iyi1  ) + wfx1 * wy1i
         wjxe(ixh1,iyi1+1) = wjxe(ixh1,iyi1+1) + wfx1 * wy2i
!.
         wx1i = s1o1 - wdxi1
         wx2i = wdxi1
!
         wjye(ixi1  ,iyh1) = wjye(ixi1  ,iyh1) + wfy1 * wx1i
         wjye(ixi1+1,iyh1) = wjye(ixi1+1,iyh1) + wfy1 * wx2i
!..
         wy1i = s1o1 - wdyi2
         wy2i = wdyi2
!
         wjxe(ixh2,iyi2  ) = wjxe(ixh2,iyi2  ) + wfx2 * wy1i
         wjxe(ixh2,iyi2+1) = wjxe(ixh2,iyi2+1) + wfx2 * wy2i
!.
         wx1i = s1o1 - wdxi2
         wx2i = wdxi2
!
         wjye(ixi2  ,iyh2) = wjye(ixi2  ,iyh2) + wfy2 * wx1i
         wjye(ixi2+1,iyh2) = wjye(ixi2+1,iyh2) + wfy2 * wx2i
      end do
!...
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup2
            wjxe(lssxlm2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
            wjxe(lssxlm1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
            wjxe(lssxl  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
            wjxe(lssxlp1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
            wjxe(lssxlp2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
            wjxe(lssxlp3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup3
            wjye(lssxlm2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
            wjye(lssxlm1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
            wjye(lssxl  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
            wjye(lssxlp1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
            wjye(lssxlp2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
         end do
      end if
      if( lexuf .eq. 1 ) then
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
            end do
         end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup3
            wjxe(ix,lssylm2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
            wjxe(ix,lssylm1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
            wjxe(ix,lssyl  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
            wjxe(ix,lssylp1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
            wjxe(ix,lssylp2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
         end do
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup2
            wjye(ix,lssylm2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
            wjye(ix,lssylm1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
            wjye(ix,lssyl  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
            wjye(ix,lssylp1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
            wjye(ix,lssylp2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
            wjye(ix,lssylp3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
         end do
      end if
      if( leyuf .eq. 1 ) then
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
            end do
         end if
      end if
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            sjxe(ix,iy) = wjxe(ix,iy)
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            sjye(ix,iy) = wjye(ix,iy)
         end do
      end do
!...
!$OMP END PARALLEL
!....
      end if
!....
      return
      end
#endif
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Electron with Current Conservation
! by 3rd order ZigZag scheme and 2nd order interpolation
!
      subroutine c2fjecc_zigzag32
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/10/28
!-----------------------------------------------------------------------
      use constant
      use control
      use particle
!#ifndef VECTOR
      use field
!#else
!     use field, vwjx => vwjw1, vwjy => vwjw2
!#endif
      include "implicit.h"
      integer :: i, ix, iy, &
                 ixi1, ixh1, iyi1, iyh1, ixi2, ixh2, iyi2, iyh2
      real*8  :: wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
                 wdxi, wdyi, &
                 wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:), wjye(:,:)
#ifdef VECTOR
      real*8, allocatable :: vwjx(:,:,:), vwjy(:,:,:)
      integer :: iv, iv2
#endif
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
      if( lnoe .gt. 0 ) then
!....
      if ( .not. allocated(wjxe) ) then
         allocate( wjxe(lssxlm2:lssxup3,lssylm2:lssyup2), &
                   wjye(lssxlm2:lssxup2,lssylm2:lssyup3) )
      end if
#ifdef VECTOR
      allocate( vwjx(lvlen,lssxlm2:lssxup3,lssylm2:lssyup2), &
                vwjy(lvlen,lssxlm2:lssxup2,lssylm2:lssyup3) )
#endif
!.
!$OMP PARALLEL PRIVATE(ixi1,ixh1,iyi1,iyh1,ixi2,ixh2,iyi2,iyh2, &
!$OMP                  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
!$OMP                  wdxi, wdyi, &
!$OMP                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i )
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            wjxe(ix,iy) = s0o1
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            wjye(ix,iy) = s0o1
         end do
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm2, lssyup2
        do ix = lssxlm2, lssxup3
          do iv = 1, lvlen
            vwjx(iv,ix,iy) = s0o1
          end do
        end do
      end do  
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm2, lssyup3
        do ix = lssxlm2, lssxup2
          do iv = 1, lvlen
            vwjy(iv,ix,iy) = s0o1
          end do
        end do
      end do  
#endif
!....
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye)
      do i = lnoes, lnoee
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vwjx,vwjy)
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1 
#endif
         ixi1 = sxeo(i)
         ixh1 = ixi1 + 1
         iyi1 = syeo(i)
         iyh1 = iyi1 + 1
         ixi2 = sxe(i)
         ixh2 = ixi2 + 1
         iyi2 = sye(i)
         iyh2 = iyi2 + 1
!.
         wmin = min(ixi1, ixi2) + 1
         wmax = max(ixi1, ixi2)
         wxr = min( wmin, max( wmax, (sxeo(i)+sxe(i))*s1o2 ) )
         wmin = min(iyi1, iyi2) + 1
         wmax = max(iyi1, iyi2)
         wyr = min( wmin, max( wmax, (syeo(i)+sye(i))*s1o2 ) )
!.
         wfx1 = ( sxeo(i) - wxr ) * spfe(i)
         wfx2 = ( wxr - sxe(i)  ) * spfe(i)
         wfy1 = ( syeo(i) - wyr ) * spfe(i)
         wfy2 = ( wyr - sye(i)  ) * spfe(i)
!..
         wdxi = (sxeo(i)+wxr)*s1o2 - ixi1 - s1o2
         wdyi = (syeo(i)+wyr)*s1o2 - iyi1 - s1o2
!..
         wx1i = s1o2*(s1o2-wdxi)**2
         wx2i = s3o2*s1o2-wdxi**2
         wx3i = s1o2*(s1o2+wdxi)**2
         wy1i = (s1o2-wdyi)**3*s1o6
         wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
         wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
         wy4i = (s1o2+wdyi)**3*s1o6
!
         _wjxe(ixh1-1,iyi1-1) = _wjxe(ixh1-1,iyi1-1) + wfx1*wy1i*wx1i
         _wjxe(ixh1-1,iyi1  ) = _wjxe(ixh1-1,iyi1  ) + wfx1*wy2i*wx1i
         _wjxe(ixh1-1,iyi1+1) = _wjxe(ixh1-1,iyi1+1) + wfx1*wy3i*wx1i
         _wjxe(ixh1-1,iyi1+2) = _wjxe(ixh1-1,iyi1+2) + wfx1*wy4i*wx1i
         _wjxe(ixh1  ,iyi1-1) = _wjxe(ixh1  ,iyi1-1) + wfx1*wy1i*wx2i
         _wjxe(ixh1  ,iyi1  ) = _wjxe(ixh1  ,iyi1  ) + wfx1*wy2i*wx2i
         _wjxe(ixh1  ,iyi1+1) = _wjxe(ixh1  ,iyi1+1) + wfx1*wy3i*wx2i
         _wjxe(ixh1  ,iyi1+2) = _wjxe(ixh1  ,iyi1+2) + wfx1*wy4i*wx2i
         _wjxe(ixh1+1,iyi1-1) = _wjxe(ixh1+1,iyi1-1) + wfx1*wy1i*wx3i
         _wjxe(ixh1+1,iyi1  ) = _wjxe(ixh1+1,iyi1  ) + wfx1*wy2i*wx3i
         _wjxe(ixh1+1,iyi1+1) = _wjxe(ixh1+1,iyi1+1) + wfx1*wy3i*wx3i
         _wjxe(ixh1+1,iyi1+2) = _wjxe(ixh1+1,iyi1+2) + wfx1*wy4i*wx3i
!.
         wx1i = (s1o2-wdxi)**3*s1o6
         wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
         wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
         wx4i = (s1o2+wdxi)**3*s1o6
         wy1i = s1o2*(s1o2-wdyi)**2
         wy2i = s3o2*s1o2-wdyi**2
         wy3i = s1o2*(s1o2+wdyi)**2
!
         _wjye(ixi1-1,iyh1-1) = _wjye(ixi1-1,iyh1-1) + wfy1*wx1i*wy1i
         _wjye(ixi1  ,iyh1-1) = _wjye(ixi1  ,iyh1-1) + wfy1*wx2i*wy1i
         _wjye(ixi1+1,iyh1-1) = _wjye(ixi1+1,iyh1-1) + wfy1*wx3i*wy1i
         _wjye(ixi1+2,iyh1-1) = _wjye(ixi1+2,iyh1-1) + wfy1*wx4i*wy1i
         _wjye(ixi1-1,iyh1  ) = _wjye(ixi1-1,iyh1  ) + wfy1*wx1i*wy2i
         _wjye(ixi1  ,iyh1  ) = _wjye(ixi1  ,iyh1  ) + wfy1*wx2i*wy2i
         _wjye(ixi1+1,iyh1  ) = _wjye(ixi1+1,iyh1  ) + wfy1*wx3i*wy2i
         _wjye(ixi1+2,iyh1  ) = _wjye(ixi1+2,iyh1  ) + wfy1*wx4i*wy2i
         _wjye(ixi1-1,iyh1+1) = _wjye(ixi1-1,iyh1+1) + wfy1*wx1i*wy3i
         _wjye(ixi1  ,iyh1+1) = _wjye(ixi1  ,iyh1+1) + wfy1*wx2i*wy3i
         _wjye(ixi1+1,iyh1+1) = _wjye(ixi1+1,iyh1+1) + wfy1*wx3i*wy3i
         _wjye(ixi1+2,iyh1+1) = _wjye(ixi1+2,iyh1+1) + wfy1*wx4i*wy3i
!..
         wdxi = (sxe(i)+wxr)*s1o2 - ixi2 - s1o2
         wdyi = (sye(i)+wyr)*s1o2 - iyi2 - s1o2
!..
         wx1i = s1o2*(s1o2-wdxi)**2
         wx2i = s3o2*s1o2-wdxi**2
         wx3i = s1o2*(s1o2+wdxi)**2
         wy1i = (s1o2-wdyi)**3*s1o6
         wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
         wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
         wy4i = (s1o2+wdyi)**3*s1o6
!
         _wjxe(ixh2-1,iyi2-1) = _wjxe(ixh2-1,iyi2-1) + wfx2*wy1i*wx1i
         _wjxe(ixh2-1,iyi2  ) = _wjxe(ixh2-1,iyi2  ) + wfx2*wy2i*wx1i
         _wjxe(ixh2-1,iyi2+1) = _wjxe(ixh2-1,iyi2+1) + wfx2*wy3i*wx1i
         _wjxe(ixh2-1,iyi2+2) = _wjxe(ixh2-1,iyi2+2) + wfx2*wy4i*wx1i
         _wjxe(ixh2,  iyi2-1) = _wjxe(ixh2  ,iyi2-1) + wfx2*wy1i*wx2i
         _wjxe(ixh2  ,iyi2  ) = _wjxe(ixh2  ,iyi2  ) + wfx2*wy2i*wx2i
         _wjxe(ixh2  ,iyi2+1) = _wjxe(ixh2  ,iyi2+1) + wfx2*wy3i*wx2i
         _wjxe(ixh2  ,iyi2+2) = _wjxe(ixh2  ,iyi2+2) + wfx2*wy4i*wx2i
         _wjxe(ixh2+1,iyi2-1) = _wjxe(ixh2+1,iyi2-1) + wfx2*wy1i*wx3i
         _wjxe(ixh2+1,iyi2  ) = _wjxe(ixh2+1,iyi2  ) + wfx2*wy2i*wx3i
         _wjxe(ixh2+1,iyi2+1) = _wjxe(ixh2+1,iyi2+1) + wfx2*wy3i*wx3i
         _wjxe(ixh2+1,iyi2+2) = _wjxe(ixh2+1,iyi2+2) + wfx2*wy4i*wx3i
!.
         wx1i = (s1o2-wdxi)**3*s1o6
         wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
         wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
         wx4i = (s1o2+wdxi)**3*s1o6
         wy1i = s1o2*(s1o2-wdyi)**2
         wy2i = s3o2*s1o2-wdyi**2
         wy3i = s1o2*(s1o2+wdyi)**2
!
         _wjye(ixi2-1,iyh2-1) = _wjye(ixi2-1,iyh2-1) + wfy2*wx1i*wy1i
         _wjye(ixi2  ,iyh2-1) = _wjye(ixi2  ,iyh2-1) + wfy2*wx2i*wy1i
         _wjye(ixi2+1,iyh2-1) = _wjye(ixi2+1,iyh2-1) + wfy2*wx3i*wy1i
         _wjye(ixi2+2,iyh2-1) = _wjye(ixi2+2,iyh2-1) + wfy2*wx4i*wy1i
         _wjye(ixi2-1,iyh2  ) = _wjye(ixi2-1,iyh2  ) + wfy2*wx1i*wy2i
         _wjye(ixi2  ,iyh2  ) = _wjye(ixi2  ,iyh2  ) + wfy2*wx2i*wy2i
         _wjye(ixi2+1,iyh2  ) = _wjye(ixi2+1,iyh2  ) + wfy2*wx3i*wy2i
         _wjye(ixi2+2,iyh2  ) = _wjye(ixi2+2,iyh2  ) + wfy2*wx4i*wy2i
         _wjye(ixi2-1,iyh2+1) = _wjye(ixi2-1,iyh2+1) + wfy2*wx1i*wy3i
         _wjye(ixi2  ,iyh2+1) = _wjye(ixi2  ,iyh2+1) + wfy2*wx2i*wy3i
         _wjye(ixi2+1,iyh2+1) = _wjye(ixi2+1,iyh2+1) + wfy2*wx3i*wy3i
         _wjye(ixi2+2,iyh2+1) = _wjye(ixi2+2,iyh2+1) + wfy2*wx4i*wy3i
#ifdef VECTOR
      end do
#endif
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm2, lssyup2
        do ix = lssxlm2, lssxup3
          do iv = 1, lvlen
            wjxe(ix,iy) = wjxe(ix,iy) + vwjx(iv,ix,iy)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
      do iy = lssylm2, lssyup3
        do ix = lssxlm2, lssxup2
          do iv = 1, lvlen
            wjye(ix,iy) = wjye(ix,iy) + vwjy(iv,ix,iy)
          end do
        end do
      end do
#endif
!...
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup2
            wjxe(lssxlm2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
            wjxe(lssxlm1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
            wjxe(lssxl  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
            wjxe(lssxlp1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
            wjxe(lssxlp2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
            wjxe(lssxlp3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup3
            wjye(lssxlm2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
            wjye(lssxlm1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
            wjye(lssxl  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
            wjye(lssxlp1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
            wjye(lssxlp2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
         end do
      end if
      if( lexuf .eq. 1 ) then
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxe(lssxum2,iy) = wjxe(lssxlm2,iy) + wjxe(lssxum2,iy)
               wjxe(lssxum1,iy) = wjxe(lssxlm1,iy) + wjxe(lssxum1,iy)
               wjxe(lssxu  ,iy) = wjxe(lssxl  ,iy) + wjxe(lssxu  ,iy)
               wjxe(lssxup1,iy) = wjxe(lssxlp1,iy) + wjxe(lssxup1,iy)
               wjxe(lssxup2,iy) = wjxe(lssxlp2,iy) + wjxe(lssxup2,iy)
               wjxe(lssxup3,iy) = wjxe(lssxlp3,iy) + wjxe(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjye(lssxum2,iy) = wjye(lssxlm2,iy) + wjye(lssxum2,iy)
               wjye(lssxum1,iy) = wjye(lssxlm1,iy) + wjye(lssxum1,iy)
               wjye(lssxu  ,iy) = wjye(lssxl  ,iy) + wjye(lssxu  ,iy)
               wjye(lssxup1,iy) = wjye(lssxlp1,iy) + wjye(lssxup1,iy)
               wjye(lssxup2,iy) = wjye(lssxlp2,iy) + wjye(lssxup2,iy)
            end do
         end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup3
            wjxe(ix,lssylm2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
            wjxe(ix,lssylm1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
            wjxe(ix,lssyl  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
            wjxe(ix,lssylp1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
            wjxe(ix,lssylp2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
         end do
!$OMP DO SCHEDULE(STATIC)
         do ix = lssxlm2, lssxup2
            wjye(ix,lssylm2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
            wjye(ix,lssylm1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
            wjye(ix,lssyl  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
            wjye(ix,lssylp1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
            wjye(ix,lssylp2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
            wjye(ix,lssylp3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
         end do
      end if
      if( leyuf .eq. 1 ) then
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3)
            end do
         else
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxe(ix,lssyum2) = wjxe(ix,lssylm2) + wjxe(ix,lssyum2)
               wjxe(ix,lssyum1) = wjxe(ix,lssylm1) + wjxe(ix,lssyum1)
               wjxe(ix,lssyu  ) = wjxe(ix,lssyl  ) + wjxe(ix,lssyu  )
               wjxe(ix,lssyup1) = wjxe(ix,lssylp1) + wjxe(ix,lssyup1)
               wjxe(ix,lssyup2) = wjxe(ix,lssylp2) + wjxe(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjye(ix,lssyum2) = wjye(ix,lssylm2) + wjye(ix,lssyum2)
               wjye(ix,lssyum1) = wjye(ix,lssylm1) + wjye(ix,lssyum1)
               wjye(ix,lssyu  ) = wjye(ix,lssyl  ) + wjye(ix,lssyu  )
               wjye(ix,lssyup1) = wjye(ix,lssylp1) + wjye(ix,lssyup1)
               wjye(ix,lssyup2) = wjye(ix,lssylp2) + wjye(ix,lssyup2)
               wjye(ix,lssyup3) = wjye(ix,lssylp3) + wjye(ix,lssyup3)
            end do
         end if
      end if
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup2
         do ix = lssxlm2, lssxup3
            sjxe(ix,iy) = wjxe(ix,iy)
         end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssylm2, lssyup3
         do ix = lssxlm2, lssxup2
            sjye(ix,iy) = wjye(ix,iy)
         end do
      end do
!...
!$OMP END PARALLEL
!....
#ifdef VECTOR
      deallocate( vwjx, vwjy )
#endif
      end if
!....
      return
      end
