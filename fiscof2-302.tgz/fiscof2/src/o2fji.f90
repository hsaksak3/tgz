!----------------------------------------------------------------------
! Observe 2D Field Current Ion
!                          /
      subroutine o2fji ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use field
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 29, ifn = 10
      integer :: kflag, i, io, iofji, int, ix,iy,ixy, iwfjia, idum
      real*8  :: wamp
      real*8, allocatable :: wfjx(:,:), wfjy(:,:), wfjz(:,:), wampx(:)
      character*20 clabel
      save
!....
      call fdebug ( 'o2fji', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwfjia = iwfjia + 1
         do io = 1, lionspl
           ixy = 0
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wfjx(ixy,io) = wfjx(ixy,io) + sjxi(ix,iy,io)
               wfjy(ixy,io) = wfjy(ixy,io) + sjyi(ix,iy,io)
               wfjz(ixy,io) = wfjz(ixy,io) + sjzi(ix,iy,io)
             end do
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do io = 1, lionspl
              wamp = -1.0d30
              do i = 1, loxypl
               wfjx(i,io) = wfjx(i,io) / ( iwfjia * snepm1 * scfl )
               wfjy(i,io) = wfjy(i,io) / ( iwfjia * snepm1 * scfl )
               wfjz(i,io) = wfjz(i,io) / ( iwfjia * snepm1 * scfl )
               wamp = max( wamp, &
                        wfjx(i,io)**2+wfjy(i,io)**2+wfjz(i,io)**2 )
              end do
              wampx(io) = sqrt( wamp )
            end do
!..
            if( iofji .le. 4 ) then
               write(iun) sstcur, &
         ((wfjx(i,io),wfjy(i,io),wfjz(i,io),i=1,loxypl),io=1,lionspl), &
                                                (wampx(io),io=1,lionspl)
               flush(iun)
            end if
            if( iofji .ge. 2 ) then
              do io = 1, lionspl
                call o2ionlabel ( io, sionam(io), sionaz(io), clabel )
                call o2fdraw5 ( bident, sstcur, ifn, 2, int, 2, &
                    wampx(io), &
                    wfjx(1,io), wfjy(1,io), wfjz(1,io), loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
                    'fjxi'//clabel, 'fjyi'//clabel, 'fjzi'//clabel, &
                    'fjxyi'//clabel, 'fjyzi'//clabel, 'fjxzi'//clabel )
              end do
            end if
          end if
!....
         else
            iofji = mod( lofji, 10 )
            idum  = mod( lofji/10, 10 )
            int   = lofji/100
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wfjx) ) &
               allocate( wfjx(loxypl,lionspl), wfjy(loxypl,lionspl), &
                         wfjz(loxypl,lionspl), wampx(lionspl) )
            end if
!
            if( iofji .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fji', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
               write(iun) 'fji2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(io),sionaz(io),io=1,lionspl)
               flush(iun)
            end if
            if( iofji .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fji', bfile )
               call frames_file ( bfile, ifn, iofji )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwfjia = 0
            do io = 1, lionspl
              do i = 1, loxypl
                wfjx(i,io) = s0o1
                wfjy(i,io) = s0o1
                wfjz(i,io) = s0o1
              end do
            end do
         end if
      end if
!....
      call fdebug ( 'o2fji', 1 )
!....
      return
      end
