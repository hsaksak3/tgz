!-------------------------------------------------------------------
! Set 2D Random STaRt
!
      subroutine s2rstr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use profile
      use constant
      use particle
      include "implicit.h"
      integer :: i, ix, ixs, ixe, iy, iys, iye, ip, io, &
                 inoe, inoi, inepm, inepm2, inipm, inipm2, iionids
      real*8  :: wx(200), wy(200), wvv(4), apf, wvte, wvti, wut, &
                 wxs, wxe, wys, wye
      save
!....
      call fdebug ( 's2rstr', 0 )
!++++
      if( smasr .gt. 1.0d-29 ) then
         do ip = 1, lpppl
            if( lpppis(ip) .lt. 1 .or. lpppis(ip) .gt. lionspl ) then
               write(0,*) '### ERROR: ion was not specified.',  &
                         ip, lpppis(ip)
               call s2ext_abort
            end if
         end do
      end if
!++++
!....
      inoe = 0
!....
      do ip = 1, lpppl
!....
         ixs = spppxps(ip) * slmic + lxp0
         iys = spppyps(ip) * slmic + lyp0
         ixe = spppxpe(ip) * slmic + lxp0
         iye = spppype(ip) * slmic + lyp0
!..
         inepm = snepm1 * spppnp(ip)
         if( inepm .gt. lnepme ) inepm = lnepme
         if( inepm .lt. 1      ) inepm = 1
         apf = ( snepm1*spppnp(ip) ) / inepm
         inepm2 = inepm / 2
!++++
         if( inepm2 .gt. 200 ) then
            write(0,*) '### ERROR: table overflow in s2rstr', inepm2
            call s2ext_abort
         end if
!++++
         wvte = svte * sqrt( spppte(ip) )
         wut  = wvte / sqrt( s1o1 - ( s3o1 * wvte**2 ) * scg1 )
!.
         do iy = iys, iye
            do ix = ixs, ixe
               call mt_drand3 ( wx, inepm2 )
               call mt_drand3 ( wy, inepm2 )
               do i = 1, inepm2
                  inoe = inoe + 1
!++++
                  if( inoe+1 .gt. lnoex ) then
                     write(0,*) &
                   '### ERROR: electron number overflow in s2rstr', inoe
                     call s2ext_abort
                  end if
!++++
                  sxe(inoe) = ix + wx(i)
                  sye(inoe) = iy + wy(i)
                  call mt_drand3 ( wvv, 4 )
                  suxe(inoe) = wut * sqrt( -s2o1 * log( wvv(1) ) ) *  &
                                       cos( wvv(2) * s2pi )
                  suye(inoe) = wut * sqrt( -s2o1 * log( wvv(1) ) ) *  &
                                       sin( wvv(2) * s2pi )
                  suze(inoe) = wut * sqrt( -s2o1 * log( wvv(3) ) ) *  &
                                       cos( wvv(4) * s2pi )
                  spfe(inoe) = apf
                  inoe = inoe + 1
                  sxe(inoe) = sxe(inoe-1)
                  sye(inoe) = sye(inoe-1)
                  suxe(inoe) = - suxe(inoe-1)
                  suye(inoe) = - suye(inoe-1)
                  suze(inoe) = - suze(inoe-1)
                  spfe(inoe) = spfe(inoe-1)
                  suxe(inoe-1) = suxe(inoe-1) + spppudxe(ip)
                  suye(inoe-1) = suye(inoe-1) + spppudye(ip)
                  suze(inoe-1) = suze(inoe-1) + spppudze(ip)
                  suxe(inoe) = suxe(inoe) + spppudxe(ip)
                  suye(inoe) = suye(inoe) + spppudye(ip)
                  suze(inoe) = suze(inoe) + spppudze(ip)
               end do
               if( mod(inepm,2) .eq. 1 ) then
                  call mt_drand3 ( wx, 6 )
                  inoe = inoe + 1
                  sxe(inoe) = ix + wx(1)
                  sye(inoe) = iy + wx(2)
                  suxe(inoe) = wut * sqrt( -s2o1 * log( wx(3) ) ) *  &
                                       cos( wx(4) * s2pi )
                  suye(inoe) = wut * sqrt( -s2o1 * log( wx(3) ) ) *  &
                                       sin( wx(4) * s2pi )
                  suze(inoe) = wut * sqrt( -s2o1 * log( wx(5) ) ) *  &
                                       cos( wx(6) * s2pi )
                  suxe(inoe) = suxe(inoe) + spppudxe(ip)
                  suye(inoe) = suye(inoe) + spppudye(ip)
                  suze(inoe) = suze(inoe) + spppudze(ip)
                  spfe(inoe) = apf
               end if
            end do
         end do
      end do
!..
      lnoe = inoe
      lnoes = 1
      lnoee = lnoes + lnoe - 1
      inoi = inoe
!....
      if( smasr .gt. 1.0d-29 ) then
         do io = 1, lionspl
         iionids = inoi + 1
!...
         do ip = 1, lpppl
         if( lpppis(ip) .eq. io ) then
!....
         ixs = spppxps(ip) * slmic + lxp0
         iys = spppyps(ip) * slmic + lyp0
         ixe = spppxpe(ip) * slmic + lxp0
         iye = spppype(ip) * slmic + lyp0
!.
         inipm = snepm1 * spppnp(ip) / ( sionaz(io) * sionaf(io) )
         if( inipm .gt. lnipme(io) ) inipm = lnipme(io)
         if( inipm .lt. 1          ) inipm = 1
         apf = ( snepm1*spppnp(ip) / sionaz(io) ) / inipm
         inipm2 = inipm / 2
         wvti = svti(io) * sqrt( spppti(ip) )
         wut  = wvti / sqrt( s1o1 - ( s3o1 * wvti**2 ) * scg1 )
!.
         do iy = iys, iye
            do ix = ixs, ixe
               call mt_drand3 ( wx, inepm2 )
               call mt_drand3 ( wy, inepm2 )
               do i = 1, inipm2
                  inoi = inoi + 1
!++++
                  if( inoi+1 .gt. lnoix ) then
                     write(0,*) &
                       '### ERROR: ion number overflow in s2rstr', inoi
                     call s2ext_abort
                  end if
!++++
                  sxi(inoi) = ix + wx(i)
                  syi(inoi) = iy + wy(i)
                  call mt_drand3 ( wvv, 4 )
                  suxi(inoi) = wut * sqrt( -s2o1*log( wvv(1) ) ) *  &
                                    cos( wvv(2) * s2pi )
                  suyi(inoi) = wut * sqrt( -s2o1*log( wvv(1) ) ) *  &
                                    sin( wvv(2) * s2pi )
                  suzi(inoi) = wut * sqrt( -s2o1*log( wvv(3) ) ) *  &
                                    cos( wvv(4) * s2pi )
                  spfi(inoi) = apf
                  inoi = inoi + 1
                  sxi(inoi) = sxi(inoi-1)
                  syi(inoi) = syi(inoi-1)
                  suxi(inoi) = - suxi(inoi-1)
                  suyi(inoi) = - suyi(inoi-1)
                  suzi(inoi) = - suzi(inoi-1)
                  spfi(inoi) = spfi(inoi-1)
                  suxi(inoi-1) = suxi(inoi-1) + spppudxi(ip)
                  suyi(inoi-1) = suyi(inoi-1) + spppudyi(ip)
                  suzi(inoi-1) = suzi(inoi-1) + spppudzi(ip)
                  suxi(inoi) = suxi(inoi) + spppudxi(ip)
                  suyi(inoi) = suyi(inoi) + spppudyi(ip)
                  suzi(inoi) = suzi(inoi) + spppudzi(ip)
               end do
               if( mod(inipm,2) .eq. 1 ) then
                  call mt_drand3 ( wx, 6 )
                  inoi = inoi + 1
                  sxi(inoi) = ix + wx(1)
                  syi(inoi) = iy + wx(2)
                  suxi(inoi) = wut * sqrt( -s2o1*log( wx(3) ) ) *  &
                                    cos( wx(4) * s2pi )
                  suyi(inoi) = wut * sqrt( -s2o1*log( wx(3) ) ) *  &
                                    sin( wx(4) * s2pi )
                  suzi(inoi) = wut * sqrt( -s2o1*log( wx(5) ) ) *  &
                                    cos( wx(6) * s2pi )
                  suxi(inoi) = suxi(inoi) + spppudxi(ip)
                  suyi(inoi) = suyi(inoi) + spppudyi(ip)
                  suzi(inoi) = suzi(inoi) + spppudzi(ip)
                  spfi(inoi) = apf
               end if
            end do
         end do
!..
         end if
         end do
!....
         lionids(io) = iionids
         lionide(io) = inoi
         lionidl(io) = lionide(io)-lionids(io)+1
!++++
         if( lionidl(io) .lt. 1 ) then
            write(0,*) '### ERROR: specified ion was not used.', io
            call s2ext_abort
         end if
!++++
         end do
!..
         lnois = lionids(1)
         lnoie = lionide(lionspl)
         lnoi  = lnoie - lnois + 1
!...
      else
         lnoi  = 0
         lnois = 0
         lnoie = -1
         lionspl = 0
      end if
!....
      wxs =  1.0d30
      wys =  1.0d30
      wxe = -1.0d30
      wye = -1.0d30
      do i = lnoes, lnoee
         wxs = min( wxs, sxe(i) )
         wxe = max( wxe, sxe(i) )
         wys = min( wys, sye(i) )
         wye = max( wye, sye(i) )
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
!.
      do i = lnois, lnoie
         suui(i) = sqrt( suxi(i)**2 + suyi(i)**2 + suzi(i)**2 )
      end do
!..
      lxps = wxs - 1
      lxpe = wxe + 2
      lyps = wys - 1
      lype = wye + 2
!....
      call fdebug ( 's2rstr', 1 )
!....
      return
      end
