!----------------------------------------------------------------------
! Observe 2D Particle Electron Energy (MeV)
!                          /
      subroutine o2pee ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     If change lpex here, must change in frames.f90.
!
!    coded by Sakagami,H. (NIFS) 11/06/30
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: lpex = 201, iun = 34, ifn = 14
      integer :: kflag, i, io, ig, iopee, ilog, iopeel
      real*8  :: wgam, &
                 wopeexps(lopeex), wopeexpe(lopeex), &
                 wopeeyps(lopeex), wopeeype(lopeex)
      real*8, allocatable :: apeen(:,:)
      save
!....
      call fdebug ( 'o2pee', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         do io = 1, iopeel
            do i = 1, lpex
               apeen(i,io) = s0o1
            end do
         end do
!.
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:apeen), &
!$OMP             PRIVATE(io,ig,wgam)
         do i = lnoes, lnoee
          do io = 1, iopeel
            if(sxe(i).ge.sopeexps(io).and.sxe(i).le.sopeexpe(io) .and. &
               sye(i).ge.sopeeyps(io).and.sye(i).le.sopeeype(io)) then
               wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
               ig = ( wgam - s1o1 ) * scoft * sopeefct(io) + s1o1
               ig = min( ig, lpex )
               apeen(ig,io) = apeen(ig,io) + spfe(i)
             end if
           end do
         end do
!.
         if( iopee .le. 4 ) then
            write(iun) sstcur, ((apeen(i,io),i=1,lpex),io=1,iopeel)
            flush(iun)
         end if
!.
         if( iopee .ge. 2 ) then
            do io = 1, iopeel
               call o2pdraw1 ( bident, sstcur, sminlog, lminlog, &
                     ifn, ilog, apeen(1,io), lpex, sopeefct(io), &
               wopeexps(io), wopeeyps(io), wopeexpe(io), wopeeype(io), &
                     'MeV', 'number[a.u.]', 'pee' )
            end do
         end if
!....
      else
         iopee  = mod( lopee, 10 )
         ilog   = mod( lopee/10, 10 )
         iopeel = mod( lopee/100, 10 )
!...
         if( .not. allocated(apeen) ) allocate( apeen(lpex,iopeel) )
!..
         do io = 1, iopeel
            if( sopeexps(io) .le. sundef ) then
               sopeexps(io) = lxps
            else
               sopeexps(io) = sopeexps(io) * slmic + loxp0
            end if
            if( sopeexpe(io) .le. sundef ) then
               sopeexpe(io) = lxpe
            else
               sopeexpe(io) = sopeexpe(io) * slmic + loxp0
            end if
            if( sopeeyps(io) .le. sundef ) then
               sopeeyps(io) = lyps
            else
               sopeeyps(io) = sopeeyps(io) * slmic + loyp0
            end if
            if( sopeeype(io) .le. sundef ) then
               sopeeype(io) = lype
            else
               sopeeype(io) = sopeeype(io) * slmic + loyp0
            end if
            wopeexps(io) = ( sopeexps(io) - loxp0 ) * slmicinv
            wopeexpe(io) = ( sopeexpe(io) - loxp0 ) * slmicinv
            wopeeyps(io) = ( sopeeyps(io) - loyp0 ) * slmicinv
            wopeeype(io) = ( sopeeype(io) - loyp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopee[xy]p[se] = ', io, &
                wopeexps(io), wopeeyps(io), wopeexpe(io), wopeeype(io)
         end do
         if( iopee .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pee', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
            write(iun) 'pee2', bident, lpex, iopeel, (sopeefct(io), &
      wopeexps(io),wopeeyps(io),wopeexpe(io),wopeeype(io),io=1,iopeel)
            flush(iun)
         end if
         if( iopee .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pee', bfile )
            call frames_file ( bfile, ifn, iopee )
         end if
!....
      end if
!....
      call fdebug ( 'o2pee', 1 )
!....
      return
      end
