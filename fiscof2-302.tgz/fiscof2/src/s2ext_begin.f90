!----------------------------------------------------------------------
! Set 2D EXTernal system BEGINning
!
      subroutine s2ext_begin
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 16/10/04
!----------------------------------------------------------------------
! #ifdef OHHELP
!       use parameter
!       use ohhelp
!       include "implicit.h"
!       include "mpif.h"
!       integer :: impierr
! #endif
!....
! #ifdef OHHELP
!       call MPI_INIT ( impierr )
!       if( impierr .ne. 0 ) then
!          write(0,*) '### ERROR: MPI_INIT, impierr =', impierr
!          stop 88888
!       end if
!       call MPI_COMM_SIZE ( MPI_COMM_WORLD, lsize, impierr )
!       if( impierr .ne. 0 ) then
!          write(0,*) '### ERROR: MPI_COMM_SIZE, impierr =', impierr
!          call s2ext_abort
!       end if
!       call MPI_COMM_RANK ( MPI_COMM_WORLD, lrank, impierr )
!       if( impierr .ne. 0 ) then
!          write(0,*) '### ERROR: MPI_COMM_RANK, impierr =', impierr
!          call s2ext_abort
!       end if
! #endif
!....
      return
      end
