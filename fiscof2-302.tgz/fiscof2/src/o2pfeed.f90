!----------------------------------------------------------------------
! Observe 2D Particle Fast Electron Energy Distribution Functio
!                            /
      subroutine o2pfeed ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!                  4 = output footer
!
!   <remarks>
!     As reduction array is very large, OpenMP is not recommended.
!
!    coded by Sakagami,H. ( NIFS ) 09/12/02
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use constant
      use control
      use observe
      use fpprm
      use particle
      use field
      use laserprf
      include "implicit.h"
      integer, parameter :: lgprx = 200, lgpmx = 36, lgpnx = 36, &
                            lgpyx = 10,  lgpmx1 = lgpmx + 1
      integer :: kflag, i, ii, im, in, ir, iy, ixpm, iypm, &
                 iflg, iml, il, ilx, iylx
      real*8  :: wzero=1.0d-6, womg, wdomg, wdomg2, wintt, wm, wn, wr, &
                 wnpnc, wpx, wpys, wpye, wrang, wyd(lopfeedx)
      real*8, allocatable :: wmue(:), wpedsn(:,:,:,:,:)
      save
!....
      call fdebug ( 'o2pfeed', 0 )
!....
      if( kflag .eq. 4 ) then
         if( lresto .eq. 0 ) then
            lopfeedc = lopfeedc + 1
            if( iflg .le. 2 ) then
               do il = 1, ilx
                 write(49+il,1400) il,ilx
                 flush(49+il)
 1400            format( '------- end ',i1,'/',i1,' --------')
               end do
            end if
         end if
         return
      end if
!....
      if( kflag .ge. 2 ) then
         do i = lnoes, lnoee
           do il = 1, ilx
             if( lopfeedyl(il) .gt. 0 ) then
               if( (sxe(i)-sopfeedx(il))*(sxe(i)+svxe(i)-sopfeedx(il)) &
                                                     .gt. s0o1 ) cycle
               if( sye(i).lt.sopfeedys(il).or.sye(i).gt.sopfeedye(il) ) &
                                                                 cycle
             else
               if( (sye(i)-sopfeedx(il))*(sye(i)+svye(i)-sopfeedx(il)) &
                                                     .gt. s0o1 ) cycle
               if( sxe(i).lt.sopfeedys(il).or.sxe(i).gt.sopfeedye(il) ) &
                                                                 cycle
             end if
!.
             wr = suue(i)
             wm = suxe(i) / wr
             wr = wr * scflinv * sopfeedr
             ir = int( wr ) + 1
             ir = min( ir, lopfeedrl )
             do ii = 1, iml
                if( (wm-wmue(ii)) * (wm-wmue(ii+1)) .le. s0o1 ) then
                   im = ii
                   go to 1
                end if
             end do
             write(0,*) '### WARNING: mue', wm
             im = 1
    1        continue
             if( suye(i)**2 + suze(i)**2 .lt. wzero ) then
                in = 1
             else
                womg = atan2( suze(i), suye(i) ) + wdomg2
                if( womg .lt. s0o1 ) womg = womg + s2pi
                in = int( womg / wdomg ) + 1
             end if
             if( lopfeedyl(il) .gt. 0 ) then
               iy = int( (sye(i)-sopfeedys(il))/wyd(il) ) + 1
             else
               iy = int( (sxe(i)-sopfeedys(il))/wyd(il) ) + 1
             end if
             wpedsn(ir,im,in,iy,il) = wpedsn(ir,im,in,iy,il) + spfe(i)
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
            lopfeedc = lopfeedc + 1
            do il = 1, ilx
              write(49+il,1100) sstcur
 1100         format( '------------------------'/' time = ', f12.3 )
              wn = s0o1
              do iy = 1, abs(lopfeedyl(il))
                do in = 1, lopfeednl
                  do im = 1, iml
                    do ir = 1, lopfeedrl
                      if( kflag .eq. 2 ) &
                         wpedsn(ir,im,in,iy,il) = &
                            wpedsn(ir,im,in,iy,il) * lopfeeda
                      if( wpedsn(ir,im,in,iy,il) .ge. sopfeedm ) then
                        wn = wn + wpedsn(ir,im,in,iy,il)
                        write(49+il,1200) ir,im,in,iy,&
                                          wpedsn(ir,im,in,iy,il)
                        flush(49+il)
 1200                   format( 4i4, f12.3 )
                      end if
                    end do
                  end do
                end do
              end do
              write(49+il,1300) wn
 1300         format( 'total = ', f12.3 )
              flush(49+il)
            end do
!....
         else
!....
            iflg = mod( lopfeed, 10 )
            ilx = lopfeed / 10
            iml = abs( lopfeedml )
!..
            if( lopfeedrl .gt. lgprx ) then
               write(0,*) '### ERROR: lopfeedrl overflow!',  &
                          lopfeedrl,lgprx
               call s2ext_abort
            end if
            if( .not. allocated(wmue) ) allocate( wmue(lgpmx1) )
            if( lopfeedml .ge. 0 ) then
              if( lopfeedml .eq. 36 ) then
                wmue( 1) = -1.00000000000000000D+00
                wmue( 2) = -9.93207305669784500D-01
                wmue( 3) = -9.80307489633560200D-01
                wmue( 4) = -9.60150837898254400D-01
                wmue( 5) = -9.32884603738784800D-01
                wmue( 6) = -8.98714393377304100D-01
                wmue( 7) = -8.57888221740722700D-01
                wmue( 8) = -8.10711771249771100D-01
                wmue( 9) = -7.57532685995101900D-01
                wmue(10) = -6.98745220899581900D-01
                wmue(11) = -6.34784460067749000D-01
                wmue(12) = -5.66123992204666100D-01
                wmue(13) = -4.93272125720977800D-01
                wmue(14) = -4.16768252849578900D-01
                wmue(15) = -3.37178781628608700D-01
                wmue(16) = -2.55092948675155600D-01
                wmue(17) = -1.71118497848510700D-01
                wmue(18) = -8.58771540224552200D-02
                wmue(19) =  0.00000000000000000D+00
                wmue(20) =  8.58771540224552200D-02
                wmue(21) =  1.71118497848510700D-01
                wmue(22) =  2.55092948675155600D-01
                wmue(23) =  3.37178781628608700D-01
                wmue(24) =  4.16768252849578900D-01
                wmue(25) =  4.93272125720977800D-01
                wmue(26) =  5.66123992204666100D-01
                wmue(27) =  6.34784460067749000D-01
                wmue(28) =  6.98745220899581900D-01
                wmue(29) =  7.57532685995101900D-01
                wmue(30) =  8.10711860656738300D-01
                wmue(31) =  8.57888072729110700D-01
                wmue(32) =  8.98714631795883200D-01
                wmue(33) =  9.32884305715560900D-01
                wmue(34) =  9.60150927305221600D-01
                wmue(35) =  9.80307668447494500D-01
                wmue(36) =  9.93206858634948700D-01
                wmue(37) =  1.00000000000000000D+00
              else if( lopfeedml .eq. 16 ) then
                wmue( 1) = -1.00000000000000000D+00
                wmue( 2) = -9.42144960000000000D-01
                wmue( 3) = -8.68379005000000000D-01
                wmue( 4) = -7.87674650000000000D-01
                wmue( 5) = -6.97571140000000000D-01
                wmue( 6) = -5.93635069999999900D-01
                wmue( 7) = -4.65944585000000000D-01
                wmue( 8) = -2.71738260000000000D-01
                wmue( 9) =  0.00000000000000000D+00
                wmue(10) =  2.71738260000000000D-01
                wmue(11) =  4.65944585000000000D-01
                wmue(12) =  5.93635069999999900D-01
                wmue(13) =  6.97571140000000000D-01
                wmue(14) =  7.87674650000000000D-01
                wmue(15) =  8.68379005000000000D-01
                wmue(16) =  9.42144960000000000D-01
                wmue(17) =  1.00000000000000000D+00
              else
                write(0,*) '### ERROR: invalid lopfeedml', lopfeedml
                call s2ext_abort
              end if
            else
              if( iml .gt. lgpmx ) then
                write(0,*) '### ERROR: lopfeedml overflow!', &
                         lopfeedml,lgpmx
                call s2ext_abort
              else
                wdomg2 = spi / ( (iml-2)*2 + 2 )
                wdomg  = wdomg2 * s2o1
                wmue(1) = 1.0d0
                do im = 2, iml
                   wmue(im) = cos( wdomg2 + wdomg * (im-2) )
                end do
                wmue(iml+1) = -1.0d0
              end if
            end if
            if( lopfeednl .gt. lgpnx ) then
               write(0,*) '### ERROR: lopfeednl overflow!', &
                         lopfeednl,lgpnx
               call s2ext_abort
            end if
            iylx = 0
            do il = 1, ilx
               if( abs(lopfeedyl(il)) .gt. lgpyx ) then
                  write(0,*) '### ERROR: lopfeedyl overflow!',  &
                         il,lopfeedyl(il),lgpyx
                 call s2ext_abort
               end if
               iylx = max( iylx, abs(lopfeedyl(il)) )
            end do
!
            if( .not. allocated(wpedsn) ) allocate( &
                       wpedsn(lopfeedrl,iml,lopfeednl,iylx,ilx) )
!
            wdomg  = s2pi / lopfeednl
            wdomg2 = wdomg / s2o1
!
            wrang = s1o1 / sopfeedr
            wintt = lopfeeda * sdtfs
!..
            do il = 1, ilx
!
            wyd(il) = (sopfeedye(il)-sopfeedys(il))/abs(lopfeedyl(il))
!
            if( ilx .eq. 1 ) then
              call fntpcnv ( bfpfntpe, lrank,-1, bident,'pfeed', bfile )
            else
              call fntpcnv ( bfpfntpe, lrank,il, bident,'pfeed', bfile )
            end if
            open(49+il, file=trim(bfile), &
                                   form='FORMATTED', status='UNKNOWN')
!.
            if( lresti .eq. 0 ) then
              if( lcfde .eq. 0 ) call c2fde
              if( lopfeedyl(il) .gt. 0 ) then
                wpx = ( sopfeedx(il) - loxp0 ) * slmicinv
                wpys= ( sopfeedys(il) - loyp0 ) * slmicinv
                wpye= ( sopfeedye(il) - loyp0 ) * slmicinv
                ixpm = floor( sopfeedx(il) )
                iypm = ( sopfeedys(il) + sopfeedye(il) ) / s2o1
              else
                wpx = ( sopfeedx(il) - loyp0 ) * slmicinv
                wpys= ( sopfeedys(il) - loxp0 ) * slmicinv
                wpye= ( sopfeedye(il) - loxp0 ) * slmicinv
                ixpm = ( sopfeedys(il) + sopfeedye(il) ) / s2o1
                iypm = floor( sopfeedx(il) )
              end if
              wnpnc = sde(ixpm,iypm) / snepm1
              if( lopfeedml .gt. 0 ) then
                 write(49+il,1000) il, ilx, bident, lopfeedml
              else
                 write(49+il,1001) il, ilx, bident, iml
              end if
              write(49+il,1002) lopfeednl,lopfeedrl,wrang,wintt,sotint
              if( lopfeedyl(il) .gt. 0 ) then
                 write(49+il,1003) wpx ,wpys, wpye, lopfeedyl(il)
              else
                 write(49+il,1004) wpx ,wpys, wpye, -lopfeedyl(il)
              end if
              write(49+il,1005) snepm1,wnpnc,slramm,slram,sgrid,slpwr
 1000         format( '------ start ',i1,'/',i1,' -------'/ &
            'ident character             = ', a16 / &
            'Sn                          = ', i7 )
 1001         format( '------ start ',i1,'/',i1,' -------'/ &
            'ident character             = ', a16 / &
            'Equal Division              = ', i7 )
 1002         format( &
            '# of mesh for omega         = ', i7 / &
            '# of mesh for momentum      = ', i7 / &
            'range                       = ', e11.4 / &
            'integration time            = ', f11.3, ' [fsec]' / &
            'observation interval        = ', f11.3, ' [fsec]' )
 1003         format( &
            'observation position of x   = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            '# of division for y         = ', i7 )
 1004         format( &
            'observation position of y   = ', f11.3, ' [micron]'/ &
            'observation position of xs  = ', f11.3, ' [micron]'/ &
            'observation position of xe  = ', f11.3, ' [micron]'/ &
            '# of division for x         = ', i7 )
 1005         format( &
            '# of particle/mesh at nc    = ', f11.3 / &
            'density at center           = ', f11.3 / &
            'laser wavelength            = ', f11.3,' [micron]'/ &
            'laser wavelength/mesh size  = ', f11.3 / &
            'Debye length/mesh size      = ', f11.3 / &
            'laser peak intensity        = ', e11.4, &
                                           ' [W/cm^2-micron^2]')
!
              if( llsrty .eq. 1 ) then
                 write(49+il,1010) slsrle, slsrwd, slsrtr
 1010            format( &
               'laser pulse shape           =  LINEAR + FLAT' / &
               'laser pulse (up,width,down) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 2 ) then
                 write(49+il,1020) slsrle, slsrwd, slsrtr
 1020            format( &
               'laser pulse shape           =  GAUSSIAN + FLAT' / &
               'laser pulse (HWHM,WID,HWHM) = ',3f11.3,' [fsec]' )
              else if( llsrty .eq. 3 ) then
                 write(49+il,1030) slsrwd
 1030            format( &
               'laser pulse shape           = GAUSSIAN' / &
               'laser pulse (FWHM)          = ',f11.3,' [fsec]' )
              else if( llsrty .eq. 4 ) then
                 write(49+il,1040) slsrwd, slsrle
 1040            format( &
               'laser pulse shape           = SUPERGAUSSIAN' / &
               'laser pulse (FWHM,alpha)    = ',f11.3,' [fsec] (', &
                                                    f4.1, ')' )
              else
                 write(49+il,1050) llsrty, slsrle, slsrwd, slsrtr
 1050            format( &
               'laser pulse shape (TYPE)    = ', i7 / &
               'laser pulse parameters      = ', 3f11.3 )
              end if
!
              flush(49+il)
!
            end if
            end do
         end if
!...
         do il = 1, ilx
           do iy = 1, iylx
             do in = 1, lopfeednl
               do im = 1, iml
                 do ir = 1, lopfeedrl
                   wpedsn(ir,im,in,iy,il) = s0o1
                 end do
               end do
             end do
           end do
         end do
!....
      end if
!....
      call fdebug ( 'o2pfeed', 1 )
!....
      return
      end
