!-----------------------------------------------------------------------
! Compute 2D Field Density Electron for Old position
!
      subroutine c2fdeo
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
#include "spdat.macro"
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, ixe, iye
      real*8  :: wdx,wx1,wx2,wx3,wx4,wdy,wy1,wy2,wy3,wy4
      save
!....
      do iy = lssylm1, lssyup1
         do ix = lssxlm1, lssxup1
            sdeo(ix,iy) = s0o1
         end do
      end do
!..
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:sdeo), &
!$OMP          PRIVATE(ixe,wdx,wx1,wx2,wx3,wx4,iye,wdy,wy1,wy2,wy3,wy4)
      do i = lnoes, lnoee
         ixe = sxeo(i)
         wdx = sxeo(i) - ixe - s1o2
         wx1 = (s1o2-wdx)**3*s1o6
         wx2 = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
         wx3 =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
         wx4 = (s1o2+wdx)**3*s1o6
!.
         iye = syeo(i)
         wdy = syeo(i) - iye - s1o2
         wy1 = (s1o2-wdy)**3*s1o6
         wy2 = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
         wy3 =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
         wy4 = (s1o2+wdy)**3*s1o6
!..
         sdeo(ixe-1,iye-1) = sdeo(ixe-1,iye-1) + spfe(i) * wx1 * wy1
         sdeo(ixe,  iye-1) = sdeo(ixe,  iye-1) + spfe(i) * wx2 * wy1
         sdeo(ixe+1,iye-1) = sdeo(ixe+1,iye-1) + spfe(i) * wx3 * wy1
         sdeo(ixe+2,iye-1) = sdeo(ixe+2,iye-1) + spfe(i) * wx4 * wy1
!.
         sdeo(ixe-1,iye  ) = sdeo(ixe-1,iye  ) + spfe(i) * wx1 * wy2
         sdeo(ixe,  iye  ) = sdeo(ixe,  iye  ) + spfe(i) * wx2 * wy2
         sdeo(ixe+1,iye  ) = sdeo(ixe+1,iye  ) + spfe(i) * wx3 * wy2
         sdeo(ixe+2,iye  ) = sdeo(ixe+2,iye  ) + spfe(i) * wx4 * wy2
!.
         sdeo(ixe-1,iye+1) = sdeo(ixe-1,iye+1) + spfe(i) * wx1 * wy3
         sdeo(ixe,  iye+1) = sdeo(ixe,  iye+1) + spfe(i) * wx2 * wy3
         sdeo(ixe+1,iye+1) = sdeo(ixe+1,iye+1) + spfe(i) * wx3 * wy3
         sdeo(ixe+2,iye+1) = sdeo(ixe+2,iye+1) + spfe(i) * wx4 * wy3
!.
         sdeo(ixe-1,iye+2) = sdeo(ixe-1,iye+2) + spfe(i) * wx1 * wy4
         sdeo(ixe,  iye+2) = sdeo(ixe,  iye+2) + spfe(i) * wx2 * wy4
         sdeo(ixe+1,iye+2) = sdeo(ixe+1,iye+2) + spfe(i) * wx3 * wy4
         sdeo(ixe+2,iye+2) = sdeo(ixe+2,iye+2) + spfe(i) * wx4 * wy4
      end do
!...
      if( lexlpe .eq. 1 ) then
         do iy = lssylm1, lssyup1
            sdeo(lssxlm1,iy) = sdeo(lssxlm1,iy) + sdeo(lssxum1,iy)
            sdeo(lssxl  ,iy) = sdeo(lssxl,  iy) + sdeo(lssxu  ,iy)
            sdeo(lssxlp1,iy) = sdeo(lssxlp1,iy) + sdeo(lssxup1,iy)
         end do
      end if
      if( lexupe .eq. 1 ) then
         if( lexlpe .eq. 1 ) then
            do iy = lssylm1, lssyup1
               sdeo(lssxum1,iy) = sdeo(lssxlm1,iy)
               sdeo(lssxu  ,iy) = sdeo(lssxl  ,iy)
               sdeo(lssxup1,iy) = sdeo(lssxlp1,iy)
            end do
         else
            do iy = lssylm1, lssyup1
               sdeo(lssxum1,iy) = sdeo(lssxlm1,iy) + sdeo(lssxum1,iy)
               sdeo(lssxu  ,iy) = sdeo(lssxl,  iy) + sdeo(lssxu  ,iy)
               sdeo(lssxup1,iy) = sdeo(lssxlp1,iy) + sdeo(lssxup1,iy)
            end do
         end if
      end if
!.
      if( leylpe .eq. 1 ) then
         do ix = lssxlm1, lssxup1
            sdeo(ix,lssylm1) = sdeo(ix,lssylm1) + sdeo(ix,lssyum1)
            sdeo(ix,lssyl  ) = sdeo(ix,lssyl  ) + sdeo(ix,lssyu  )
            sdeo(ix,lssylp1) = sdeo(ix,lssylp1) + sdeo(ix,lssyup1)
         end do
      end if
      if( leyupe .eq. 1 ) then
         if( leylpe .eq. 1 ) then
            do ix = lssxlm1, lssxup1
               sdeo(ix,lssyum1) = sdeo(ix,lssylm1)
               sdeo(ix,lssyu  ) = sdeo(ix,lssyl  )
               sdeo(ix,lssyup1) = sdeo(ix,lssylp1)
            end do
         else
            do ix = lssxlm1, lssxup1
               sdeo(ix,lssyum1) = sdeo(ix,lssylm1) + sdeo(ix,lssyum1)
               sdeo(ix,lssyu  ) = sdeo(ix,lssyl  ) + sdeo(ix,lssyu  )
               sdeo(ix,lssyup1) = sdeo(ix,lssylp1) + sdeo(ix,lssyup1)
            end do
         end if
      end if
!....
      return
      end
