!-----------------------------------------------------------------------
! Boundary condition 2D Field Electric - TE
!
      subroutine b2fete
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
! original coded by Hata,M. (Nagoya Univ.) 11/06/23
!    coded by Sakagami,H. (NIFS) 11/07/27
!----------------------------------------------------------------------
#include "sfield.macro"
      use constant
      use field
      use control
      include "implicit.h"
      integer :: ix, iy
      save
!....
      call fdebug ( 'b2fete', 0 )
!....
!$OMP PARALLEL
!....
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sez(lssxlm1,iy) = sez(lssxum1,iy)
            sez(lssxl,iy) = sez(lssxu,iy)
         end do
!..
      else if( lexlf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sez(lssxlm1,iy) = s0o1
         end do
!..
      else if( lexlf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lblyl, lblyu
            sez(lssxlm1,iy) = sez(lssxl,iy)*sce3 + sby(lssxlm1,iy)*scb3
         end do
!..
      else if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lblyl, lblyu
            do ix = lblxl, lssxlm1
               sezxxl(ix,iy) = scaxl(ix) * sezxxl(ix,iy) + &
                      scbetexl(ix)*sby(ix,iy)-sccetexl(ix)*sby(ix-1,iy)
            end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyup1
            do ix = lblxl, lssxlm1
               sezyxl(ix,iy) = sezyxl(ix,iy) - &
                             ( sbx(ix,iy) - sbx(ix,iy-1) ) * scb1
               sez(ix,iy)  = sezxxl(ix,iy) + sezyxl(ix,iy)
            end do
!           sez(lssxlm1,iy)  = sez(lssxlm1,iy) + sjzt(lssxlm1,iy) * scj1
         end do
!.
!$OMP DO SCHEDULE(STATIC)
         do iy = lblyl, lblyu
            sez(lblxlm1,iy) = sez(lblxl,iy)*sce3 + sby(lblxlm1,iy)*scb3
         end do
      end if
!...
      if( lexuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sez(lssxup2,iy) = sez(lssxlp2,iy)
            sez(lssxup1,iy) = sez(lssxlp1,iy)
         end do
!..
      else if( lexuf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sez(lssxup2,iy) = s0o1
         end do
!..
      else if( lexuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lblyl, lblyu
            sez(lssxup2,iy) = sez(lssxup1,iy)*sce3 - sby(lssxup1,iy)*scb3
         end do
!..
      else if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lblyl, lblyu
            do ix = lssxup2, lblxu
               sezxxu(ix,iy) = scaxu(ix) * sezxxu(ix,iy) + &
                      scbetexu(ix)*sby(ix,iy)-sccetexu(ix)*sby(ix-1,iy)
            end do
         end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyup1
            do ix = lssxup2, lblxu
               sezyxu(ix,iy) = sezyxu(ix,iy) - &
                             ( sbx(ix,iy) - sbx(ix,iy-1) ) * scb1
               sez(ix,iy)  = sezxxu(ix,iy) + sezyxu(ix,iy)
            end do
!           sez(lssxup2,iy)  = sez(lssxup2,iy) + sjzt(lssxup2,iy) * scj1
         end do
!.
!$OMP DO SCHEDULE(STATIC)
         do iy = lblyl, lblyu
            sez(lblxup1,iy) = sez(lblxu,iy)*sce3 - sby(lblxu,iy)*scb3
         end do
      end if
!...
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssylm1) = sez(ix,lssyum1)
            sez(ix,lssyl) = sez(ix,lssyu)
         end do
!..
      else if( leylf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssylm1) = s0o1
         end do
!..
      else if( leylf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssylm1) = sez(ix,lssyl)*sce3 - sbx(ix,lssylm1)*scb3
         end do
!..
      else if( leylf .eq. 4 ) then
         do iy = lblyl, lssylm1
!$OMP DO SCHEDULE(STATIC)
            do ix = lblxl, lblxu
               sezyyl(ix,iy) = scayl(iy) * sezyyl(ix,iy) - &
                      scbeteyl(iy)*sbx(ix,iy)+scceteyl(iy)*sbx(ix,iy-1)
            end do
!.
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxl, lssxup1
               sezxyl(ix,iy) = sezxyl(ix,iy) + &
                             ( sby(ix,iy) - sby(ix-1,iy) ) * scb1
               sez(ix,iy)  = sezxyl(ix,iy) + sezyyl(ix,iy)
            end do
!.
            if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lblxl, lssxlm1
                  sez(ix,iy)  = sezxxl(ix,iy) + sezyyl(ix,iy)
               end do
            end if
            if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxup2, lblxu
                  sez(ix,iy)  = sezxxu(ix,iy) + sezyyl(ix,iy)
               end do
            end if
         end do
!.
! !$OMP DO SCHEDULE(STATIC)
!        do ix = lssxl, lssxup1
!           sez(ix,lssylm1)  = sez(ix,lssylm1) + sjzt(ix,lssylm1) * scj1
!        end do
!.
!        if( lexlf .eq. 4 ) then
!           sez(lssxlm1,lssylm1)  = sez(lssxlm1,lssylm1) + &
!                                   sjzt(lssxlm1,lssylm1) * scj1
!        end if
!        if( lexuf .eq. 4 ) then
!           sez(lssxup2,lssylm1)  = sez(lssxup2,lssylm1) + &
!                                   sjzt(lssxup2,lssylm1) * scj1
!        end if
!.
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lblylm1) = sez(ix,lblyl)*sce3 - sbx(ix,lblylm1)*scb3
         end do
      end if
!...
      if( leyuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssyup2) = sez(ix,lssylp2)
            sez(ix,lssyup1) = sez(ix,lssylp1)
         end do
!..
      else if( leyuf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssyup2) = s0o1
         end do
!..
      else if( leyuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lssyup2) = sez(ix,lssyup1)*sce3 + sbx(ix,lssyup1)*scb3
         end do
!..
      else if( leyuf .eq. 4 ) then
         do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
            do ix = lblxl, lblxu
               sezyyu(ix,iy) = scayu(iy) * sezyyu(ix,iy) - &
                      scbeteyu(iy)*sbx(ix,iy)+scceteyu(iy)*sbx(ix,iy-1)
            end do
!.
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxl, lssxup1
               sezxyu(ix,iy) = sezxyu(ix,iy) + &
                             ( sby(ix,iy) - sby(ix-1,iy) ) * scb1
               sez(ix,iy)  = sezxyu(ix,iy) + sezyyu(ix,iy)
            end do
!.
            if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lblxl, lssxlm1
                  sez(ix,iy)  = sezxxl(ix,iy) + sezyyu(ix,iy)
               end do
            end if
            if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxup2, lblxu
                  sez(ix,iy)  = sezxxu(ix,iy) + sezyyu(ix,iy)
               end do
            end if
         end do
!.
! !$OMP DO SCHEDULE(STATIC)
!        do ix = lssxl, lssxup1
!           sez(ix,lssyup2)  = sez(ix,lssyup2) + sjzt(ix,lssyup2) * scj1
!        end do
!.
!        if( lexlf .eq. 4 ) then
!           sez(lssxlm1,lssyup2)  = sez(lssxlm1,lssyup2) + &
!                                   sjzt(lssxlm1,lssyup2) * scj1
!        end if
!        if( lexuf .eq. 4 ) then
!           sez(lssxup2,lssyup2)  = sez(lssxup2,lssyup2) + &
!                                   sjzt(lssxup2,lssyup2) * scj1
!        end if
!.
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sez(ix,lblyup1) = sez(ix,lblyu)*sce3 + sbx(ix,lblyu)*scb3
         end do
      end if
!....
!$OMP END PARALLEL
!....
      call fdebug ( 'b2fete', 1 )
!....
      return
      end
