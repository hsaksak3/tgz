!----------------------------------------------------------------------
! Fast Ignition Simulation code with COllective and Flexible particles
! 3 dimension
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 10/06/07
!----------------------------------------------------------------------
      use ieee_arithmetic
      use parameter
      use constant
      use control
      use field
      use laserprf
      use observe
      use animation
      use fpprm
      use debug
      include "implicit.h"
      integer istat
      character :: cvers*24, cfile*64
      character :: ctime*20, cdate*20, cload*32, cfc*16, cff*128, cfv*64
!....
      ctime = __TIME__
      cdate = __DATE__
      cload = '*UNDEFINED*'
      cfc = '*UNDEFINED*'
      cfv = '*UNDEFINED*'
      cff = '*UNDEFINED*'
#ifdef LOAD
      cload = LOAD
#endif
#ifdef FC
      cfc = FC
#endif
#ifdef FVERS
      cfv = FVERS 
#endif
#ifdef FFLAGS
      cff = FFLAGS
#endif
!....
#ifndef OHHELP
      cvers = 'fiscof3s'
#else
      cvers = 'fiscof3oh'
#endif
#ifdef VECTOR
      cvers = trim(cvers)//'v'
#endif
      cvers = trim(cvers)//' V2.R48' 
#ifdef DEBUG
      cvers = trim(cvers)//' DL'
      write( cvers(len_trim(cvers)+1:len_trim(cvers)+1), '(i1)' ) DEBUG 
#endif
!....
      call s3ext_begin
!....
      call getenv ( 'FISCOF3_STDIN_FILE', cfile )
      call fntpcnv ( cfile, lrank, 5, ' ',' ', bfile )
      if( bfile(1:1) .ne. ' ' ) then
         open( 5, file=bfile, status='OLD', err=998, iostat=istat )
         write(0,*) '@@@ input is read from "', trim(bfile), '"'
      else
         write(0,*) '@@@ input is connected with STDIN'
      end if
!
      call getenv ( 'FISCOF3_STDOUT_FILE', cfile )
      call fntpcnv ( cfile, lrank, 6, ' ',' ', bfile )
      if( bfile(1:1) .ne. ' ' ) then
         open( 6, file=bfile, err=999, iostat=istat )
         write(0,*) '@@@ output is written to "', trim(bfile), '"'
      else
         write(0,*) '@@@ output is connected with STDOUT'
      end if
!..
      if(lrank .le. 0 ) then
      write(6,*) '@@@ ',trim(cload)//' compiled at '//trim(ctime)//&
                 ' on '//trim(cdate)
      write(6,*) '@@@ by '//trim(cfc)//', '//trim(cfv)
      write(6,*) '@@@ with '//trim(cff)
      end if
!....
      call fdebug ( cvers, -1 )
!.
      call ieee_get_rounding_mode(default_round_type)
!
      sundef  = -1.0d20
      sundeff = -1.1d20
      s0o1 = 0.0d0
      s1o2 = 0.5d0
      s1o1 = 1.0d0
      s3o2 = 1.5d0
      s2o1 = 2.0d0
      s3o1 = 3.0d0
      s4o1 = 4.0d0
      s1o6 = 1.0d0 / 6.0d0
      s2o3 = 2.0d0 / 3.0d0
      s1o3 = 1.0d0 / 3.0d0
      s1o4 = 0.25d0
      s3o4 = 0.75d0
      spi  = acos( -1.0d0 )
      s2pi = 2.0d0 * spi
      sd2r = spi / 180.0d0
      sminlog = 1.0d-12
      lminlog = 5
!....
      call s3simp
      call s3cnst
!.
      call s3allc ( 0 )
!.
      call s3ext_init
!.
      call s3allc ( 1 )
!.
      call s3init
!                                                 * debug for current *
!     call s3ext_exec( 6 )
!..
      call a3flsr
!....
      do while( lstcur .gt. lotnxt )
         sotnxt = sotnxt + sotint
         if( sotnxt .le. sotend ) then
            lotnxt = sotnxt / sdtfs
         else
            lotnxt = 999999999
         end if
      end do
!.
      if( lagfl .ge. 1 ) then
         do while( lstcur .gt. latnxt )
            satnxt = satnxt + satint
            if( satnxt .le. satend ) then
               latnxt = satnxt / sdtfs
            else
               latnxt = 999999999
            end if
         end do
      end if
!....
      if( lstcur .eq. lotnxt ) then
         if( lresti .eq. 0 ) then
            if( lopee .ge. 1 ) call o3pee ( 1 )
            if( lopie .ge. 1 ) call o3pie ( 1 )
            if( lopem .ge. 1 ) call o3pem ( 1 )
            if( lopim .ge. 1 ) call o3pim ( 1 )
            if( lofde .ge. 1 ) call o3fde ( 2 )
            if( lofdi .ge. 1 ) call o3fdi ( 2 )
            if( lofdc .ge. 1 ) call o3fdc ( 2 )
            if( lofea .ge. 1 ) call o3fea ( 2 )
            if( lofer .ge. 1 ) call o3fer ( 2 )
            if( lofba .ge. 1 ) call o3fba ( 2 )
            if( lofbr .ge. 1 ) call o3fbr ( 2 )
            if( lofje .ge. 1 ) call o3fje ( 2 )
            if( lofji .ge. 1 ) call o3fji ( 2 )
            if( lofjt .ge. 1 ) call o3fjt ( 2 )
            if( lofte .ge. 1 ) call o3fte ( 2 )
            if( lofede .ge. 1 ) call o3fede ( 1 )
            if( lofek .ge. 1 ) call o3fek ( 1 )
            if( lofedi .ge. 1 ) call o3fedi ( 1 )
            if( lopfeed .ge. 1 ) call o3pfeed ( 2 )
            if( lopfied .ge. 1 ) call o3pfied ( 2 )
            if( lopeph .ge. 1 ) call o3peph ( 1 )
         end if
         if( loeng .ge. 1 ) then
            call o3eng ( 2 )
            if( lresti .ne. 0 ) then
               if(lrank .le. 0 ) &
               write(0,*) '@@@ Observation values may differ from '// &
                          'previous values because of time averaging.'
            end if
         end if
         sotnxt = sotnxt + sotint
         if( sotnxt .le. sotend ) then
            lotnxt = sotnxt / sdtfs
         else
            lotnxt = 999999999
         end if
         call ffflushall
       end if
!..
      if( lstcur .eq. latnxt ) then
         if( lagfl .ge. 1 ) call o3anim
         satnxt = satnxt + satint
         if( satnxt .le. satend ) then
            latnxt = satnxt / sdtfs
         else
            latnxt = 999999999
         end if
      end if
!....
    1 continue
!...
         lstcur = lstcur + 1
         lltcur = lltcur + 1
         sstcur = lstcur * sdtfs
!...
         if( mod(lstcur,lreloce) .eq. 0 ) call s3reloc( lstcur, 1 )
         if( mod(lstcur,lreloci) .eq. 0 ) call s3reloc( lstcur, 3 )
!...
         call c3pef
         if( lclflge .ge. 1 )  call c3pec
!.
         call c3pif
         if( lclflgia .ge. 1 ) call c3pic
!..
         call a3pem
         call c3pev
         call a3pep
         call b3pep ( 2 )
         call c3fjecc
         call b3pep ( 1 )
         lcfde = 0
!.
         call a3pim
         call c3piv
         call a3pip
         call b3pip ( 2 )
         call c3fjicc
         call b3pip ( 1 )
         lcfdi = 0
!.
         call c3fjt
!                                                 * debug for current *
!        call s3ext_exec( 7 )
         call s3ext_exec( 5 )
         call s3ext_exec( 4 )
!..
         if( llsrbn .gt. 0 ) call c3flsr
!..
         call a3fb
         call b3fb ( 1 )
         call s3ext_exec( 3 )
!..
         call a3fe
         call b3fe
         call s3ext_exec( 2 )
!..
         call s3ext_exec( 1 )
!..
         call c3fed         
!..
         if( lofew .ge. 1 ) call o3few ( 2 )
!..
         call a3fb
         call b3fb ( 0 )
         call s3ext_exec( 3 )
!                                                 * debug for field *
!        call s3ext_exec( 8 )
!...
         if( loeng .ge. 1 ) then
            if( lstcur .gt. lotnxt - loenga ) call o3eng ( 3 )
         end if
         if( lofde .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdea ) call o3fde ( 3 )
         end if
         if( lofdi .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdia ) call o3fdi ( 3 )
         end if
         if( lofdc .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofdca ) call o3fdc ( 3 )
         end if
         if( lofea .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofeaa ) call o3fea ( 3 )
         end if
         if( lofer .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofera ) call o3fer ( 3 )
         end if
         if( lofba .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofbaa ) call o3fba ( 3 )
         end if
         if( lofbr .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofbra ) call o3fbr ( 3 )
         end if
         if( lofje .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjea ) call o3fje ( 3 )
         end if
         if( lofji .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjia ) call o3fji ( 3 )
         end if
         if( lofjt .ge. 1 ) then
            if( lstcur .gt. lotnxt - lofjta ) call o3fjt ( 3 )
         end if
         if( lofte .ge. 1 ) then
            if( lstcur .gt. lotnxt - loftea ) call o3fte ( 3 )
         end if
         if( lopfeed .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopfeeda ) call o3pfeed ( 3 )
         end if
         if( lopfied .ge. 1 ) then
            if( lstcur .gt. lotnxt - lopfieda ) call o3pfied ( 3 )
         end if
!.
         if( lstcur .eq. lotnxt ) then
            if( lopee .ge. 1 ) call o3pee ( 1 )
            if( lopie .ge. 1 ) call o3pie ( 1 )
            if( lopem .ge. 1 ) call o3pem ( 1 )
            if( lopim .ge. 1 ) call o3pim ( 1 )
            if( lofde .ge. 1 ) call o3fde ( 1 )
            if( lofdi .ge. 1 ) call o3fdi ( 1 )
            if( lofdc .ge. 1 ) call o3fdc ( 1 )
            if( lofea .ge. 1 ) call o3fea ( 1 )
            if( lofer .ge. 1 ) call o3fer ( 1 )
            if( lofba .ge. 1 ) call o3fba ( 1 )
            if( lofbr .ge. 1 ) call o3fbr ( 1 )
            if( lofje .ge. 1 ) call o3fje ( 1 )
            if( lofji .ge. 1 ) call o3fji ( 1 )
            if( lofjt .ge. 1 ) call o3fjt ( 1 )
            if( lofte .ge. 1 ) call o3fte ( 1 )
            if( lofede .ge. 1 ) call o3fede ( 1 )
            if( lofek .ge. 1 ) call o3fek ( 1 )
            if( lofedi .ge. 1 ) call o3fedi ( 1 )
            if( lopfeed .ge. 1 ) call o3pfeed ( 1 )
            if( lopfied .ge. 1 ) call o3pfied ( 1 )
            if( lopeph .ge. 1 ) call o3peph ( 1 )
            if( loeng .ge. 1 ) then
               call o3eng ( 1 )
            end if
            sotnxt = sotnxt + sotint
            if( sotnxt .le. sotend ) then
               lotnxt = sotnxt / sdtfs
            else
               lotnxt = 999999999
            end if
!
            if( lresto .ne. 0 ) call s3rest ( 1, lresto )
!
            call ffflushall
         end if
!.
         if( lstcur .eq. latnxt ) then
            if( lagfl .ge. 1 ) call o3anim
            satnxt = satnxt + satint
            if( satnxt .le. satend ) then
               latnxt = satnxt / sdtfs
            else
               latnxt = 999999999
            end if
         end if
!...
      if( lstcur .lt. lstend ) go to 1
!..
      if( lofew .ge. 1 ) call o3few ( 1 )
!..
      if( lopfeed .ge. 1 ) call o3pfeed ( 4 )
      if( lopfied .ge. 1 ) call o3pfied ( 4 )
!..
      if( lresto .ne. 0 ) call s3rest ( 1, lresto )
!...
      call s3ext_term
!....
      call fdebug ( cvers, -2 )
!....
      stop
!....
  998 continue
      write(0,*) '### ERROR: stdin file not found. file="', &
                 trim(bfile), '"', istat
      stop
!..
  999 continue
      write(0,*) '### ERROR: can not open stdout file. file="', &
                 trim(bfile), '"', istat
      stop
      end
