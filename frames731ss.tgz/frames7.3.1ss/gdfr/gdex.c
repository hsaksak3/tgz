/******************************************************
 *                      gdex 1.1                      *
 *  GD Extention source to connect gd, gdf and gdfr   *
 *         Programmed by T. Taguchi for Frames        *
 *                   July  18, 2007                   *
 ******************************************************
*/

#define cost		gd_cosine_value
#define sint		gd_sine_value

#include "gd.c"

void gd_set_static_values(int RWidth,int RHeight)
{
	Width = RWidth;
	Height = RHeight;
	CountDown = (long)Width * (long)Height;
	Pass = 0;
	curx = cury = 0;
}

void gd_static_compress(int init_bits, FILE *outfile, gdImagePtr im, int background, int RInterlace)
{
	Interlace = RInterlace;
	compress( init_bits, outfile, im, background);
}

int gd_init_statics_colorstobpp(int colors)
{
	init_statics();
	return colorstobpp(colors);
}

#ifdef PPM
/*	The followings are additional gd routines	*/
gdImagePtr gd_image_create(int sx, int sy, int size)
{
	int i;
	gdImagePtr im;
	im = (gdImage *) malloc(sizeof(gdImage));
	/* NOW ROW-MAJOR IN GD 1.3 */
	im->pixels = (u_pixel **) malloc(sizeof(u_pixel *) * sy);
	im->polyInts = 0;
	im->polyAllocated = 0;
	im->brush = 0;
	im->tile = 0;
	im->style = 0;
	for (i=0; (i<sy); i++) {
		/* NOW ROW-MAJOR IN GD 1.3 */
		im->pixels[i] = (u_pixel *) calloc(sx, sizeof(u_pixel));
	}	
	im->sx = sx;
	im->sy = sy;
	im->colorsTotal = 0;
	im->transparent = (-1);
	im->interlace = 0;
	if (size==0) gdMaxColors=gifMaxColors;
		else   	 gdMaxColors=size;
	im->red = (int *) malloc(sizeof(int) * gdMaxColors * 6);
	im->green = im->red + gdMaxColors;
	im->blue = im->green + gdMaxColors;
	im->open = im->blue + gdMaxColors;
	im->brushColorMap = im->open + gdMaxColors;
	im->tileColorMap = im->brushColorMap + gdMaxColors;
	return im;
}

void gd_image_ppm(gdImagePtr im, FILE *out)
{
	int i,j,c;
	unsigned char rgb[3];
	fprintf(out,"P6\n# CREATOR: Frames - libgdfr\n%d %d\n255\n",im->sx,im->sy);
	for(j=0;j<im->sy;j++) {
		for(i=0;i<im->sx;i++) {
			c=gdImageGetPixel(im,i,j);
			rgb[0] = im->red[c];
			rgb[1] = im->green[c];
			rgb[2] = im->blue[c];
			fwrite(rgb,1,3,out);
		}
	}
}

void gd_colormap_size(gdImagePtr im, int size, int add)
{
	int i,*red,*red1;

	if (size<0) size=gdMaxColors+add;

	if (size>gdMaxColors) {
		red = (int *) malloc(sizeof(int) * size * 6);
		red1=red;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->red[i];
		}
		red1+=size;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->green[i];
		}
		red1+=size;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->blue[i];
		}
		red1+=size;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->open[i];
		}
		red1+=size;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->brushColorMap[i];
		}
		red1+=size;
		for (i=0;i<gdMaxColors;i++) {
			red1[i]=im->tileColorMap[i];
		}
		free(im->red);
		gdMaxColors=size;
		im->red = red;
		im->green = im->red + gdMaxColors;
		im->blue = im->green + gdMaxColors;
		im->open = im->blue + gdMaxColors;
		im->brushColorMap = im->open + gdMaxColors;
		im->tileColorMap = im->brushColorMap + gdMaxColors;
	}
}
#endif

int gd_image_color_near(gdImagePtr im, int r, int g, int b)
{
	int i,c2,cmax=1000000,imax=-1,r2,g2,b2;
	for (i=0; (i<(im->colorsTotal)); i++) {
		if (im->open[i]) {
			continue;
		}
		r2=r-im->red[i];		g2=g-im->green[i];		b2=b-im->blue[i];
		c2=r2*r2+g2*g2+b2*b2;
		if (c2<cmax) {  cmax=c2;  imax=i;  }
	}
	return imax;
}
