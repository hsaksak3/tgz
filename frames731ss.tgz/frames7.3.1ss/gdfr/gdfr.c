/******************************************************
 *                      gdfr 1.3                      *
 *       GD Extention to create a GIF Animation       *
 *             Programmed by Y. Fujii, HIT            *
 *          Modified by T. Taguchi for Frames         *
 *                   July 14, 2007                    *
 ******************************************************
*/
#include <math.h>
#include <stdlib.h>
/*
#define gdImageCreate					gdImage_Create
#define gdImageCreateFromGif			gdImage_CreateFromGif
#define gdImageCreateFromGd				gdImage_CreateFromGd
#define gdImageCreateFromXbm			gdImage_CreateFromXbm
#define gdImageDestroy					gdImage_Destroy
#define gdImageSetPixel					gdImage_SetPixel
#define gdImageGetPixel					gdImage_GetPixel
#define gdImageLine						gdImage_Line
#define gdImageDashedLine				gdImage_DashedLine
#define gdImageRectangle				gdImage_Rectangle
#define gdImageFilledRectangle			gdImage_FilledRectangle
#define gdImageBoundsSafe				gdImage_BoundsSafe
#define gdImageChar						gdImage_Char
#define gdImageCharUp					gdImage_CharUp
#define gdImageString					gdImage_String
#define gdImageStringUp					gdImage_StringUp
#define gdImageString16					gdImage_String16
#define gdImageStringUp16				gdImage_StringUp16
#define gdImagePolygon					gdImage_Polygon
#define gdImageFilledPolygon			gdImage_FilledPolygon

#define gdImageColorAllocate			gdImage_ColorAllocate
#define gdImageColorClosest				gdImage_ColorClosest
#define gdImageColorExact				gdImage_ColorExact
#define gdImageColorDeallocate			gdImage_ColorDeallocate
#define gdImageColorTransparent			gdImage_ColorTransparent
#define gdImageGif						gdImage_Gif
#define gdImageGd						gdImage_Gd
#define gdImageArc						gdImage_Arc
#define gdImageFillToBorder				gdImage_FillToBorder
#define gdImageFill						gdImage_Fill
#define gdImageCopy						gdImage_Copy
#define gdImageCopyResized				gdImage_CopyResized
#define gdImageSetBrush					gdImage_SetBrush
#define gdImageSetTile					gdImage_SetTile
#define gdImageSetStyle					gdImage_SetStyle
#define gdImageInterlace				gdImage_Interlace

#define gdGetWord						gd_GetWord
#define gdPutWord						gd_PutWord
#define gdGetByte						gd_GetByte
#define gdCompareInt					gd_CompareInt

#define cost		gd_cosine_value
#define sint		gd_sine_value
*/

#define Bresenham_Circle
#define AntiLine

#define AALRESOLV				8
#define ADDCOLMAP				256
#define PI						3.141592653589793

#include "gd.h"

extern gdFontPtr	gdFontGiant;
extern gdFontPtr	gdFontLarge;
extern gdFontPtr	gdFontMediumBold;
extern gdFontPtr	gdFontSmall;
extern gdFontPtr	gdFontTiny;

static int			gctable=0, gifwidth=-1, gifheight=-1, gbegin=0, comcolor;
static int			gcreate=0, maxgifaddr, gifwidthaa, gifheightaa;
static gdImagePtr	imgif=NULL;
static gdFontPtr	gdFonts[5];

#define Putword(w, fp)		{ fputc( (w)&0xff, fp ); fputc( ((w)>>8)&0xff, fp ); }
void gd_set_static_values(int RWidth,int RHeight);
void gd_static_compress(int init_bits, FILE *outfile, gdImagePtr im, int background, int RInterlace);
int gd_init_statics_colorstobpp(int colors);

#ifdef PPM
gdImagePtr gd_image_create(int sx, int sy, int size);
void gd_image_ppm(gdImagePtr im, FILE *out);
void gd_colormap_size(gdImagePtr im, int size, int add);
#endif
int gd_image_color_near(gdImagePtr im, int r, int g, int b);

void gdframes_image_create(int width, int height)
{
#ifdef PPM
	if (imgif==NULL) {
		imgif=gd_image_create(width, height, 0);
	  }
	  else {
		gdImageDestroy(imgif);
		imgif=gd_image_create(width, height, 0);
	}
#else
	if (imgif==NULL) {
		imgif=gdImageCreate(width, height);
	  }
	  else {
		gdImageDestroy(imgif);
		imgif=gdImageCreate(width, height);
	}
#endif
/*
	  else if (gifwidth!=width || gifheight!=height) {
		gdImageDestroy(imgif);
		imgif=gdImageCreate(width, height);
	}
*/

	if (gifwidth!=width || gifheight!=height) {
		gcreate=0;
		gifwidth=width;
		gifheight=height;
		gifwidthaa=gifwidth*AALRESOLV;
		gifheightaa=gifheight*AALRESOLV;
		maxgifaddr=gifwidthaa*gifheightaa;
	}

	if (gbegin == 0) {
		gdFonts[0]=gdFontGiant;
		gdFonts[1]=gdFontLarge;
		gdFonts[2]=gdFontMediumBold;
		gdFonts[3]=gdFontSmall;
		gdFonts[4]=gdFontTiny;
		gbegin=1;
	}
}

void gdframes_image_destroy(void)
{
	if (imgif!=NULL) {
		gdImageDestroy(imgif);
		imgif=NULL;
	}
}

void gdframes_image_gif(FILE *out)
{
	gdImageGif(imgif, out);
}

#ifdef PPM
void gdframes_image_ppm(FILE *out)
{
	gd_image_ppm(imgif, out);
}

void gdframes_colormap_size(int size)
{
	gd_colormap_size(imgif, size, 0);
}
#endif

int gdframes_color_allocate(int r, int g, int b)
{
	return gdImageColorAllocate(imgif, r, g, b);
}

void gdframes_color_deallocate(int color)
{
	gdImageColorDeallocate(imgif,color);
}

void gdframes_color_transparent(int color)
{
	if (imgif!=NULL) gdImageColorTransparent(imgif,color);
}

void gdframes_interlace(int interlaceArg)
{
	if (imgif!=NULL) gdImageInterlace(imgif,interlaceArg);
}

void gdframes_frame_clear(int color)
{
	if (imgif!=NULL) gdImageFilledRectangle(imgif, 0, 0, gifwidth-1, gifheight-1, color);
}

void gdframes_set_pixel(int x1, int y1, int color)
{
	gdImageSetPixel(imgif,x1,y1,color);
}

void gdframes_set_style(int *style, int noOfPixels)
{
	gdImageSetStyle(imgif, style, noOfPixels);
}

#ifdef AntiLine
static unsigned char **fbuff=NULL;
static int			aalxmin,aalxmax,aalymin,aalymax,daddr[AALRESOLV*2];
static float		alpha=1;
#define SHIFTVAL				3
#define MAXALINECOL 			(1<<SHIFTVAL)
#define BLEND(cover,back)		((((MAXALINECOL-(cover))*(back))>>SHIFTVAL)+(cover))

/***********     Function Anti Aliased Line     *********************************/
/*   Partially refered the following Web site                                   */
/*   http://courses.ece.uiuc.edu/ece390/archive/archive-f2000/mp/mp4/anti.html	*/
/********************************************************************************/
static void create_aaspace(void)
{
	int i,j;

	if (fbuff!=NULL) {
		for (j=0;j<gifheightaa;j++) free(fbuff[j]);
		free(fbuff);
	}
	fbuff = (unsigned char **) malloc( sizeof(unsigned char *)*gifheightaa );
	for (j=0;j<gifheightaa;j++) fbuff[j] = (unsigned char *) malloc( sizeof(unsigned char)*gifwidth );
	for (j=0;j<gifheightaa;j++)
		for (i=0;i<gifwidth;i++)  fbuff[j][i] = '\0';

	aalxmin=gifwidthaa+1;		aalxmax=-1;
	aalymin=gifheightaa+1;		aalymax=-1;
	gcreate=1;
}

static int gd_clip2d(float *x1,float *y1,float *x2,float *y2)
{
	char c,c1,c2,ik;
	double xx1=*x1,yy1=*y1,xx2=*x2,yy2=*y2,xx,yy;
	double bx2=gifwidth,by2=gifheight;

	ik = 3;
	while (1) {
		if (ik&1) {
			if (xx1<0) 		    c1 =1;
			 else if (xx1>bx2)  c1 =2;
			 else			    c1 =0;
			if (yy1<0) 		    c1|=4;
			  else if (yy1>by2) c1|=8;
		}
		if (ik&2) {
			if (xx2<0) 		    c2 =1;
			 else if (xx2>bx2)  c2 =2;
			 else			    c2 =0;
			if (yy2<0) 		    c2|=4;
			  else if (yy2>by2) c2|=8;
		}

		if (c1==0 && c2==0) {
			*x1=xx1;		*y1=yy1;
			*x2=xx2;		*y2=yy2;
			return 1;
		}
		if (c1&c2) {
			return 0;
		}
		if (c1) c = c1;
		 else   c = c2;
		if (xx1==xx2) {
			*x1=*x2=xx1;
			*y1=yy1;		*y2=yy2;
			if (yy1<0) *y1 = 0;
			  else if (yy1>by2) *y1 = by2;
			if (yy2<0) *y2 = 0;
			  else if (yy2>by2) *y2 = by2;
			return 1;
		  }
		 else if (yy1==yy2) {
			*y1=*y2=yy1;
			*x1=xx1;		*x2=xx2;
			if (xx1<0) *x1 = 0;
			  else if (xx1>bx2) *x1 = bx2;
			if (xx2<0) *x2 = 0;
			  else if (xx2>bx2) *x2 = bx2;
			return 1;
		  }
		  else if (c&1) {
			yy = yy1 + (yy2-yy1)*(-xx1)/(xx2-xx1);
			xx = 0;
		  }
		  else if (c&2) {
			yy = yy1 + (yy2-yy1)*(bx2-xx1)/(xx2-xx1);
			xx = bx2;
		  }
		  else if (c&4) {
			xx = xx1 + (xx2-xx1)*(-yy1)/(yy2-yy1);
			yy = 0;
		  }
		  else if (c&8) {
			xx = xx1 + (xx2-xx1)*(by2-yy1)/(yy2-yy1);
			yy = by2;
		}

		if (c==c1) {
			xx1 = xx;		yy1 = yy;		ik = 1;
		  }
		  else {
			xx2 = xx;		yy2 = yy;		ik = 2;
		}
	}
}

static void DrawPixelDy(int addr,int da,int nn0)
{
	int c1,cc,cx,cy,i,i0=0,addr1,addr2;
	addr2=addr+da;
	if (addr2<0) return;
	addr1=addr-da;
	if (addr1>=maxgifaddr) return;
	if (addr1<0) {
		for (i=1;i<AALRESOLV;i++) {
			addr1+=gifwidthaa*daddr[i-1];
			if (addr1>=0) break;
		}
		i0=i;
	  }
	  else if (addr2>=maxgifaddr) {
		for (i=nn0-1;i>=0;i--) {
			addr2-=gifwidthaa*daddr[i];
			if (addr2<maxgifaddr) break;
		}
		nn0=i;
	}
	c1=addr1%AALRESOLV;		cc=addr1/AALRESOLV;
	cx=cc%gifwidth;			cy=cc/gifwidth;
	c1=1<<c1;
	for (i=i0;i<=nn0;i++) {
		fbuff[cy][cx]|=c1;
		cy+=daddr[i];
	}
}

static void DrawPixelDx(int addr,int da,int nn0)
{
	int c1,cc,cx,cy,i,i0=0;

	if (addr+da<0) return;
	if (addr-da>=maxgifaddr) return;

	c1=addr%AALRESOLV;		cc=addr/AALRESOLV;
	cx=cc%gifwidth;			cy=cc/gifwidth;
	if (c1<da) {
		i0=da-c1;
		c1=1<<(c1+AALRESOLV-da);
		for (cc=0,i=0;i<i0;i++) {
			cc|=c1;		c1<<=daddr[i];
			if (c1>=(1<<AALRESOLV)) break;
		}
		if (cx>0) fbuff[cy][cx-1]|=(unsigned char)(cc&0xff);
		c1>>=AALRESOLV;
	  }
	  else c1=1<<(c1-da);
	for (cc=0,i=i0;i<=nn0;i++) {
		cc|=c1;		c1<<=daddr[i];
	}
	fbuff[cy][cx]|=(unsigned char)(cc&0xff);
	while (1) {
		cc>>=AALRESOLV;
		if (cc && cx<gifwidth-1) fbuff[cy][++cx]|=(unsigned char)(cc&0xff);
			else break;
	}
}

static int anti_aliased_line(float xd0, float yd0, float xd1, float yd1, int mode)
{
	int ic,l,nn,nn0;
	int x0,y0,x1,y1;
	int addr,dx,dy,da;
	int u,v,du,dv,uincr,vincr,uend,d,incrS,incrD;
	double ddu,ddv;

	ic=gd_clip2d(&xd0,&yd0,&xd1,&yd1);
	if (ic==0) return 0;

	x0=(xd0+0.5)*AALRESOLV;		y0=(yd0+0.5)*AALRESOLV;
	x1=(xd1+0.5)*AALRESOLV;		y1=(yd1+0.5)*AALRESOLV;

	if (x0<aalxmin) aalxmin=x0;
	if (x1<aalxmin) aalxmin=x1;
	if (x0>aalxmax) aalxmax=x0;
	if (x1>aalxmax) aalxmax=x1;
	if (y0<aalymin) aalymin=y0;
	if (y1<aalymin) aalymin=y1;
	if (y0>aalymax) aalymax=y0;
	if (y1>aalymax) aalymax=y1;

	addr = y0*gifwidthaa+x0;
	dx = x1-x0;		dy = y1-y0;

    /* By switching to (u,v), we combine all eight octants */
	if (abs(dx) > abs(dy)) {
		du = abs(dx);
		dv = abs(dy);
		u = x1;
		v = y1;
		uincr = 1;
		vincr = gifwidthaa;
		if (dx < 0) uincr = -uincr;
		if (dy < 0) vincr = -vincr;
		uend = u + du;
		d = (2*dv) - du;							/* Initial value as in Bresenham's */
		incrS = 2*dv;								/* Delta_d for straight increments */
		incrD = 2*(dv - du);						/* Delta_d for diagonal increments */
		ddu = dx;
		ddv = dy;

		if (mode==0) {
			if (du) nn=(AALRESOLV/2)*sqrt(ddu*ddu + ddv*ddv)/du*alpha;
			   else nn=(AALRESOLV/2)*alpha;
		  }
		  else nn=mode;

		nn0=2*nn;
		daddr[0]=daddr[1]=daddr[nn0-2]=daddr[nn0-1]=daddr[nn0]=2;
		for (l=2;l<nn0-2;l++) daddr[l]=1;
		da=gifwidthaa*(nn+2);

		do {
			DrawPixelDy(addr,da,nn0);
			if (d < 0) {
				d += incrS;
			  }
			  else {
				d += incrD;
				v++;
				addr += vincr;
			}
			u++;
			addr += uincr;
	    } while (u <= uend);
	  }
	  else {
		du = abs(dy);
		dv = abs(dx);
		u = y1;
		v = x1;
		uincr = gifwidthaa;
		vincr = 1;
		if (dy < 0) uincr = -uincr;
		if (dx < 0) vincr = -vincr;
		uend = u + du;
		d = (2*dv) - du;							/* Initial value as in Bresenham's */
		incrS = 2*dv;								/* Delta_d for straight increments */
		incrD = 2*(dv - du);						/* Delta_d for diagonal increments */
		ddu = dx;
		ddv = dy;

		if (du) nn=(AALRESOLV/2)*sqrt(ddu*ddu + ddv*ddv)/du*alpha;
		   else nn=(AALRESOLV/2)*alpha;

		nn0=2*nn;
		daddr[0]=daddr[1]=daddr[nn0-2]=daddr[nn0-1]=daddr[nn0]=2;
		for (l=2;l<nn0-2;l++) daddr[l]=1;
		da=nn+2;

		do {
			DrawPixelDx(addr,da,nn0);
			if (d < 0) {
				d += incrS;
			  }
			  else {
				d += incrD;
				v++;
				addr += vincr;
			}
			u++;
			addr += uincr;
	    } while (u <= uend);
	}
	return 1;
}

int gdframes_aaline(float x1, float y1, float x2, float y2, int thick)
{
	alpha=(thick+100)/100.0;
	if (gcreate == 0) create_aaspace();

	return anti_aliased_line( x1, y1, x2, y2, 0 );
}

static void DrawPixelLine(int x0,int y0,int dx,int mode)
{
	int c1,c2,cx1,cx2,cy,cc,cs,i,addr1,addr2;

	if (y0<0) return;

	if (mode) {
		x0-=dx;		dx*=2;
	}
	if (x0<0) {  dx+=x0;	x0=0;  }
	if (x0+dx>=gifwidthaa) dx=gifwidthaa-x0-1;

	addr1=y0*gifwidthaa+x0;
	addr2=addr1+dx;
	c1=addr1%AALRESOLV;		cc=addr1/AALRESOLV;
	cx1=cc%gifwidth;		cy=cc/gifwidth;
//	if (cy<0 || cy>=gifheightaa) return;
	if (cy>=gifheightaa) return;
	c2=addr2%AALRESOLV;		cc=addr2/AALRESOLV;
	cx2=cc%gifwidth;
	if (cx1==cx2) {
		for (cc=0,i=c1,cs=1<<c1;i<=c2;i++) {
			cc|=cs;		cs<<=1;
		}
		fbuff[cy][cx1]|=(unsigned char)(cc&0xff);
	  }
	  else {
		for (cc=0,i=c1,cs=1<<c1;i<AALRESOLV;i++) {
			cc|=cs;		cs<<=1;
		}
		fbuff[cy][cx1]|=(unsigned char)(cc&0xff);
		for (cc=cx1+1;cc<cx2;cc++) fbuff[cy][cc]=0xff;
		for (cc=0,i=0,cs=1;i<=c2;i++) {
			cc|=cs;		cs<<=1;
		}
		fbuff[cy][cx2]|=(unsigned char)(cc&0xff);
	}
}

static int anti_aliased_circle(float xd,float yd,float rd,int fill)
{
	int x1,y1,p;
	int x0,y0,r0,l,nn,nn0;
	int addr,dax,day;

	if (xd+rd<0 || xd-rd>=gifwidth || yd+rd<0 || yd-rd>=gifheight) return 0;
	x0=(xd+0.5)*AALRESOLV;		y0=(yd+0.5)*AALRESOLV;
	r0=rd*AALRESOLV;

	if (x0-r0<aalxmin) aalxmin=x0-r0;
	if (x0+r0>aalxmax) aalxmax=x0+r0;
	if (y0-r0<aalymin) aalymin=y0-r0;
	if (y0+r0>aalymax) aalymax=y0+r0;

	x1 = 0;
	y1 = r0;
	p  = 3-(r0<<1);

	if (fill==0) {
		while ( x1 <= y1+1 ) {
			nn=(AALRESOLV/2)*(1+0.42*x1/y1)*alpha;
//			nn=(AALRESOLV/2)*sqrt((double)(x1*x1 + y1*y1))/y1*alpha;
//			nn=(AALRESOLV/2)*alpha;
			nn0=2*nn;
			daddr[0]=daddr[1]=daddr[nn0-2]=daddr[nn0-1]=daddr[nn0]=2;
			for (l=2;l<nn0-2;l++) daddr[l]=1;
			dax=nn+2;		day=gifwidthaa*(nn+2);
			if (x0+x1<gifwidthaa) {
				addr = (y0+y1)*gifwidthaa+x0+x1;
				DrawPixelDy(addr,day,nn0);
				addr = (y0-y1)*gifwidthaa+x0+x1;
				DrawPixelDy(addr,day,nn0);
			}
			if (x0-x1>=0) {
				addr = (y0+y1)*gifwidthaa+x0-x1;
				DrawPixelDy(addr,day,nn0);
				addr = (y0-y1)*gifwidthaa+x0-x1;
				DrawPixelDy(addr,day,nn0);
			}
			if (x0+y1<gifwidthaa) {
				addr = (y0+x1)*gifwidthaa+x0+y1;
				DrawPixelDx(addr,dax,nn0);
				addr = (y0-x1)*gifwidthaa+x0+y1;
				DrawPixelDx(addr,dax,nn0);
			}
			if (x0-y1>=0) {
				addr = (y0+x1)*gifwidthaa+x0-y1;
				DrawPixelDx(addr,dax,nn0);
				addr = (y0-x1)*gifwidthaa+x0-y1;
				DrawPixelDx(addr,dax,nn0);
			}
			if ( p < 0 ) p += (x1<<2)+6;
			  else {
				p += ((x1-y1)<<2)+10;
				y1--;
			}
			x1++;
		} 
	  }
	  else {
		while ( x1 < y1 ) {
			DrawPixelLine(x0,y0+x1,y1,1);
			DrawPixelLine(x0,y0-x1,y1,1);
			DrawPixelLine(x0,y0-y1,x1,1);
			DrawPixelLine(x0,y0+y1,x1,1);
			if ( p < 0 ) p += (x1<<2)+6;
			  else {
				p += ((x1-y1)<<2)+10;
				y1--;
			}
			x1++;
		} 
		if ( x1 == y1 ) {
			DrawPixelLine(x0,y0-y1,x1,1);
			DrawPixelLine(x0,y0+y1,x1,1);
		}
	}
	return 1;
}

/*	cf. http://www2.starcat.ne.jp/~fussy/algo/index.htm			*/
static int anti_aliased_ellipse(float xd,float yd,float rxd,float ryd,int fill)
{
	int x1,y1;
	int x0,y0,rx0,ry0,l,nn,nn0;
	int addr,dax,day;
	double F,H,r,b,a;

	if (xd+rxd<0 || xd-rxd>=gifwidth || yd+ryd<0 || yd-ryd>=gifheight) return 0;
	x0=(xd+0.5)*AALRESOLV;		y0=(yd+0.5)*AALRESOLV;
	rx0=rxd*AALRESOLV;			ry0=ryd*AALRESOLV;

	if (x0-rx0<aalxmin) aalxmin=x0-rx0;
	if (x0+rx0>aalxmax) aalxmax=x0+rx0;
	if (y0-ry0<aalymin) aalymin=y0-ry0;
	if (y0+ry0>aalymax) aalymax=y0+ry0;

	r=rx0*ry0;	b=rx0*rx0;	a=ry0*ry0;

	if (fill==0) {
		x1 = rx0;
		y1 = 0;
		F = -2*ry0*r + a + 2*b;
		H = -4*ry0*r + 2*a + b;
		while ( x1 > 0 ) {
			if (ryd*x1<rxd*y1) {
				nn=(AALRESOLV/2)*(1+0.42*ryd*x1/(rxd*y1))*alpha;
//				nn=(AALRESOLV/2)*sqrt((double)(x1*x1 + y1*y1))/y1*alpha;
//				nn=(AALRESOLV/2)*alpha;
				nn0=2*nn;
				daddr[0]=daddr[1]=daddr[nn0-2]=daddr[nn0-1]=daddr[nn0]=2;
				for (l=2;l<nn0-2;l++) daddr[l]=1;
				day=gifwidthaa*(nn+2);
				if (x0+x1<gifwidthaa) {
					addr = (y0+y1)*gifwidthaa+x0+x1;
					DrawPixelDy(addr,day,nn0);
					addr = (y0-y1)*gifwidthaa+x0+x1;
					DrawPixelDy(addr,day,nn0);
				}
				if (x0-x1>=0) {
					addr = (y0+y1)*gifwidthaa+x0-x1;
					DrawPixelDy(addr,day,nn0);
					addr = (y0-y1)*gifwidthaa+x0-x1;
					DrawPixelDy(addr,day,nn0);
				}
			  }
			  else {
				nn=(AALRESOLV/2)*(1+0.42*rxd*y1/(ryd*x1))*alpha;
//				nn=(AALRESOLV/2)*sqrt((double)(x1*x1 + y1*y1))/y1*alpha;
//				nn=(AALRESOLV/2)*alpha;
				nn0=2*nn;
				daddr[0]=daddr[1]=daddr[nn0-2]=daddr[nn0-1]=daddr[nn0]=2;
				for (l=2;l<nn0-2;l++) daddr[l]=1;
				dax=nn+2;
				if (x0+x1<gifwidthaa) {
					addr = (y0+y1)*gifwidthaa+x0+x1;
					DrawPixelDx(addr,dax,nn0);
					addr = (y0-y1)*gifwidthaa+x0+x1;
					DrawPixelDx(addr,dax,nn0);
				}
				if (x0-x1>=0) {
					addr = (y0+y1)*gifwidthaa+x0-x1;
					DrawPixelDx(addr,dax,nn0);
					addr = (y0-y1)*gifwidthaa+x0-x1;
					DrawPixelDx(addr,dax,nn0);
				}
			}
			if ( F < 0 ) {
				y1++;
				F += 4 * b * y1 + 2 * b;
				H += 4 * b * y1;
			  }
			  else if ( H >= 0 ) {
				x1--;
				F -= 4*a*x1;
				H -= 4*a*x1 - 2*a;
			  }
			  else {
				x1--;
				y1++;
				F += 4*b*y1 - 4*a*x1 + 2*b;
				H += 4*b*y1 - 4*a*x1 + 2*a;
			}
		}
	  }
	  else {
		x1 = rx0;
		y1 = 0;
		F = -2*ry0*r + a + 2*b;
		H = -4*ry0*r + 2*a + b;
		while ( x1 > 0 ) {
			DrawPixelLine(x0,y0-y1,x1,1);
			DrawPixelLine(x0,y0+y1,x1,1);
			if ( F < 0 ) {
				y1++;
				F += 4*b*y1 + 2*b;
				H += 4*b*y1;
			  }
			  else if ( H >= 0 ) {
				x1--;
				F -= 4*a*x1;
				H -= 4*a*x1 - 2*a;
			  }
			  else {
				x1--;
				y1++;
				F += 4*b*y1 - 4*a*x1 + 2*b;
				H += 4*b*y1 - 4*a*x1 + 2*a;
			}
		}
	}
	return 1;
}

int gdframes_aacircle(float cx, float cy, float dx, float dy, int fill)
{
	int ret;

	if (gcreate == 0) create_aaspace();

	dx/=2;		dy/=2;
	if (dy<=0) ret=anti_aliased_line(cx-dx,cy,cx+dx,cy,0);
	  else if (dx<=0) ret=anti_aliased_line(cx,cy-dy,cx,cy+dy,0);
	  else if (dx==dy) ret=anti_aliased_circle(cx,cy,dx,fill);
	  else ret=anti_aliased_ellipse(cx,cy,dx,dy,fill);

	return ret;
}

int gdframes_aagradcircle(float cx, float cy, float dr)
{
	int ret=0;

	if (gcreate == 0) create_aaspace();

	dr/=2;
	if (dr>0) ret=anti_aliased_circle(cx,cy,dr,1);

	return ret;
}

static int compare_int(const void *a, const void *b)
{
	return (*(const int *)a) - (*(const int *)b);
}

int gdframes_aafillpolygon(float *px, float *py, int n)
{
	int i, y;
	int miny, maxy;
	float x1, y1, x2, y2;
	int ind1, ind2;
	int ints;

	if (n<=0) return 0;

	if (gcreate == 0) create_aaspace();

	for (i=0;i<n-1;i++) {
		anti_aliased_line(px[i], py[i], px[i+1], py[i+1], 1);
	}
	anti_aliased_line(px[n-1], py[n-1], px[0], py[0], 1);


	for (i=0; i < n; i++) {
		px[i]=(px[i]+0.5)*AALRESOLV;		py[i]=(py[i]+0.5)*AALRESOLV;
		if (px[i]<aalxmin) aalxmin=px[i];
		if (px[i]>aalxmax) aalxmax=px[i];
		if (py[i]<aalymin) aalymin=py[i];
		if (py[i]>aalymax) aalymax=py[i];
	}
	miny = px[0];
	maxy = px[0];
	for (i=1; i < n; i++) {
		if (px[i] < miny) miny = px[i];
		if (px[i] > maxy) maxy = px[i];
	}
	if (maxy<0 || miny>=gifwidthaa) return 0;
	miny = py[0];
	maxy = py[0];
	for (i=1; i < n; i++) {
		if (py[i] < miny) miny = py[i];
		if (py[i] > maxy) maxy = py[i];
	}
	if (maxy<0 || miny>=gifheightaa) return 0;

	if (imgif->polyAllocated==0) {
		imgif->polyInts = (int *) malloc(sizeof(int) * n);
		imgif->polyAllocated = n;
	}
	if (imgif->polyAllocated < n) {
		while (imgif->polyAllocated < n) {
			imgif->polyAllocated *= 2;
		}
		imgif->polyInts = (int *) realloc(imgif->polyInts, sizeof(int) * imgif->polyAllocated);
	}

	/* Fix in 1.3: count a vertex only once */
	for (y=miny; y <= maxy; y++) {
		ints = 0;
		for (i=0; i < n; i++) {
			if (i==0) {
				ind1 = n-1;
				ind2 = 0;
			} else {
				ind1 = i-1;
				ind2 = i;
			}
			y1 = py[ind1];
			y2 = py[ind2];
			if (y1 < y2) {
				x1 = px[ind1];
				x2 = px[ind2];
			} else if (y1 > y2) {
				y2 = py[ind1];
				y1 = py[ind2];
				x2 = px[ind1];
				x1 = px[ind2];
			} else {
				continue;
			}
			if ((y >= y1) && (y < y2)) {
				imgif->polyInts[ints++] = (y-y1) * (x2-x1) / (y2-y1) + x1 + 0.5;
			} else if ((y == maxy) && (y > y1) && (y <= y2)) {
				imgif->polyInts[ints++] = (y-y1) * (x2-x1) / (y2-y1) + x1 + 0.5;
			}
		}
		qsort(imgif->polyInts, ints, sizeof(int), compare_int);

		for (i=0; i < ints; i+=2) {
			DrawPixelLine(imgif->polyInts[i],y,imgif->polyInts[i+1]-imgif->polyInts[i],0);
		}
	}
	return 1;
}

static int anti_aliased_putfont(int xx, int yy, unsigned char *font, int nxmin,int nxmax,int nymin,int nymax)
{
	int i,j,n,cx,cy;

	if (xx+nxmax*8<0 || xx+nxmin*8>=gifwidthaa || yy+nymax<0 || yy+nymin>=gifheightaa) return 0;

	if (gcreate == 0) create_aaspace();

	if (xx+nxmin*8<aalxmin) aalxmin=xx+nxmin*8;
	if (xx+nxmax*8>aalxmax) aalxmax=xx+nxmax*8;
	if (yy+nymin  <aalymin) aalymin=yy+nymin;
	if (yy+nymax  >aalymax) aalymax=yy+nymax;
//		printf("   %d %d %d %d\n",aalxmin,aalxmax,aalymin,aalymax);
//		printf("   %d %d %d %d\n",xx,yy,dx,dy);

	for (j=nymin,n=0;j<=nymax;j++) {
		cy=yy+j;
		if (cy<0) continue;
		if (cy>=gifheightaa) break;
		for (i=nxmin;i<=nxmax;i++,n++) {
			cx=xx/8+i;
			if (cx<0 || cx>=gifwidth) continue;
			fbuff[cy][cx]|=font[n];		//printf("%d %d: %02x\n",cx,cy,font[n]);
		}
	}
	return 1;
}

static int anti_aliased_tiltedfont(int xx, int yy, unsigned char *font, int nxmin,int nxmax,int nymin,int nymax)
{
	int i,j,k,n,cx,cy,bx;
	double th=PI/5;

	if (xx+nxmax*8<0 || xx+nxmin*8>=gifwidthaa || yy+nymax<0 || yy+nymin>=gifheightaa) return 0;

	if (gcreate == 0) create_aaspace();

//		printf("   %d %d %d %d\n",aalxmin,aalxmax,aalymin,aalymax);
//		printf("   %d %d %d %d\n",xx,yy,dx,dy);

	for (j=nymin,n=0;j<=nymax;j++) {
		for (i=nxmin;i<=nxmax;i++,n++) {
			for (k=0;k<8;k++) {
				if (font[n]&(1<<k)) {					//Depend upon bit alignment
					bx=i*8+k;
					cy=yy-sin(th)*bx+cos(th)*j;
					if (cy<0 || cy>=gifheightaa) continue;
					if (cy<aalymin) aalymin=cy;
					if (cy>aalymax) aalymax=cy;
					cx=xx+cos(th)*bx+sin(th)*j;
					if (cx<0 || cx>=gifwidthaa) continue;
					if (cx<aalxmin) aalxmin=cx;
					if (cx>aalxmax) aalxmax=cx;
					fbuff[cy][cx/8]|=1<<(cx%8);
				}
			}
		}
	}
	return 1;
}
#ifdef AAFONT
int gdframes_aastring(float px, float py, char *str, int chk)
{
	static FILE *fontfp=NULL;
	static int err=0,yoff=0;
	static unsigned char *font=NULL,*cc;
	static long fontpt[95];
	static int kern,space;
	unsigned int c1;
	int i,j,k,nfont,nfont0,fwid,fhei,nbit,nxmin,nxmax,nymin,nymax,xx,yy,nf,xw,yh;

	if (err) return -1;				// Not available

	if (chk==1 || fontfp == NULL) {
		if (fontfp == NULL) {
			fontfp = fopen("NS128.font", "r");
			if (fontfp == NULL) {
				err=1;
				return -1;			// Not available
			}
			fscanf(fontfp,"%d %d %d %d %d %d",&nbit,&fhei,&nfont0,&nfont,&kern,&space);
			fscanf(fontfp,"%d %d %d",&fwid,&xw,&yoff);
			yh=(yoff-1)/8+1;		xw/=8;
			yoff=yh*8+4-yoff;
//			if (nbit!=8) printf("Not a 8 bit case!\n");
			if (font != NULL) free(font);
			font=(unsigned char *)malloc(sizeof(unsigned char *)*fwid*fhei/8);
//			printf("%d %d\n",fwid,fhei);
			for (k=0;k<nfont;k++) {
				fontpt[k]=ftell(fontfp);
				fscanf(fontfp,"%d %d %d %d %d",&nf,&nxmin,&nxmax,&nymin,&nymax);
//				printf("%d: %d %d %d %d\n",nf,nxmin,nxmax,nymin,nymax);
				for (j=nymin;j<=nymax;j++) {
					for (i=nxmin;i<=nxmax;i++) fscanf(fontfp,"%3x",&c1);
				}
			}
		}
		if (chk==1) return (xw<<16|yh);			// Check only
	  }
	  else if (chk==2) {
		xx=0;
		while (*str) {
			fseek(fontfp, fontpt[*str-' '], SEEK_SET);
			fscanf(fontfp,"%d %d %d %d %d",&k,&nxmin,&nxmax,&nymin,&nymax);
			if (nxmin<=nxmax) {
				xx+=(nxmax-nxmin+kern)*8;
			  }
			  else xx+=space*8;
			str++;
		}
		return xx;								// Check string width
	}

	xx=(px+0.5)*AALRESOLV;			yy=(py+0.5)*AALRESOLV+yoff;

	while (*str) {
		fseek(fontfp, fontpt[*str-' '], SEEK_SET);
		fscanf(fontfp,"%d %d %d %d %d",&k,&nxmin,&nxmax,&nymin,&nymax);
//		printf("%c %d %d %d %d %d\n",*str,k,nxmin,nxmax,nymin,nymax);
		for (j=nymin,cc=font;j<=nymax;j++) {
			for (i=nxmin;i<=nxmax;i++,cc++) {
				fscanf(fontfp,"%3x",&c1);		*cc=c1;
//				printf("%03x ",c1);
			}
//			printf("\n");
		}
		if (nxmin<=nxmax) {
			anti_aliased_putfont(xx, yy, font, nxmin, nxmax, nymin, nymax);
//			anti_aliased_tiltedfont(xx, yy, font, nxmin, nxmax, nymin, nymax);
			xx+=(nxmax-nxmin+kern)*8;
		  }
		  else xx+=space*8;
		str++;
	}
//	fclose(fontfp);
	return 1;
}
#else
int gdframes_aastring(float px, float py, char *str, int chk)
{
	return -1;
}
#endif

#define AASTEP			5
int gdframes_aaspaceflush(int fcol, int bcol, int resol, int ppm)
{
	int xx,yy,l,p,c,addr,c1;
	int r1,g1,b1,r2,g2,b2;
	int m=0;

	if (resol<0) {
		r1=imgif->red[bcol];
		g1=imgif->green[bcol];
		b1=imgif->blue[bcol];
	  }
	  else if (resol>=8) resol=AASTEP;
	aalxmin/=AALRESOLV;		aalxmax/=AALRESOLV;
	aalymin/=AALRESOLV;		aalymax/=AALRESOLV;
	aalxmin--;	aalxmax++;	aalymin--;	aalymax++;
	if (aalxmin<0) aalxmin=0;
	if (aalxmax>=gifwidth ) aalxmax=gifwidth-1;
	if (aalymin<0) aalymin=0;
	if (aalymax>=gifheight) aalymax=gifheight-1;

	for (yy=aalymin;yy<=aalymax;yy++)
		for (xx=aalxmin;xx<=aalxmax;xx++) {
			for (c=0,l=0,addr=yy*AALRESOLV;l<AALRESOLV;l++,addr++) {
				for (c1=fbuff[addr][xx];c1>0;c1>>=1) c+=(c1&1);
				fbuff[addr][xx]=0;
			}
			if (c) {
//				c=(c+3)/(AALRESOLV*AALRESOLV/MAXALINECOL);
				c/=(AALRESOLV*AALRESOLV/MAXALINECOL);
				if (c<MAXALINECOL) {
					r2=imgif->red[fcol];
					g2=imgif->green[fcol];
					b2=imgif->blue[fcol];
					if (resol>=0) {
						p = gdImageGetPixel(imgif, xx, yy);
						r1=imgif->red[p];
						g1=imgif->green[p];
						b1=imgif->blue[p];
						r2=(r2*c+r1*(MAXALINECOL-c))>>SHIFTVAL;
						g2=(g2*c+g1*(MAXALINECOL-c))>>SHIFTVAL;
						b2=(b2*c+b1*(MAXALINECOL-c))>>SHIFTVAL;
						r2=(r2>>resol)<<resol;		g2=(g2>>resol)<<resol;		b2=(b2>>resol)<<resol;
					  }
					  else {
						r2=(r2*c+r1*(MAXALINECOL-c))>>SHIFTVAL;
						g2=(g2*c+g1*(MAXALINECOL-c))>>SHIFTVAL;
						b2=(b2*c+b1*(MAXALINECOL-c))>>SHIFTVAL;
					}
					p=gdImageColorExact(imgif,r2,g2,b2);
					if (p<0) {
						p = gdImageColorAllocate(imgif, r2, g2, b2);
						if (p<0) {
#ifdef PPM
							if (ppm>0) {
								gd_colormap_size(imgif, -1, ADDCOLMAP);
								p = gdImageColorAllocate(imgif, r2, g2, b2);
							  }
							  else {
								p=gd_image_color_near(imgif,r2,g2,b2);		m--;
							}
#else
							p=gd_image_color_near(imgif,r2,g2,b2);		m--;
#endif
//							  else {
//								p=fcol;		m--;
//							}
						}
						m++;
					}
				  }
				  else p=fcol;
				gdImageSetPixel(imgif,xx,yy,p);
			}
		}
	aalxmin=gifwidthaa+1;		aalxmax=-1;
	aalymin=gifheightaa+1;		aalymax=-1;
//	printf("ff %d %d\n",fcol,m);
	return m;
}

int gdframes_aagradspaceflush(int xc, int yc, int dr, int cn1, int cn2, int *gifrgbp, int resol, int ppm)
{
	int xx,yy,l,p,c,addr,c1;
	int r1,g1,b1,r2,g2,b2,cn;
	int m=0;
	double dcn,rr,sqrt(double);

//	if (resol<0) {
//		r1=imgif->red[bcol];
//		g1=imgif->green[bcol];
//		b1=imgif->blue[bcol];
//	  }
//	  else if (resol>=8) resol=AASTEP;
	if (resol>=8) resol=AASTEP;
	aalxmin/=AALRESOLV;		aalxmax/=AALRESOLV;
	aalymin/=AALRESOLV;		aalymax/=AALRESOLV;
	aalxmin--;	aalxmax++;	aalymin--;	aalymax++;
	if (aalxmin<0) aalxmin=0;
	if (aalxmax>=gifwidth ) aalxmax=gifwidth-1;
	if (aalymin<0) aalymin=0;
	if (aalymax>=gifheight) aalymax=gifheight-1;

	dcn = 6*(cn2-cn1)/((double)dr*5);
	xc+=dr/6;		yc-=dr/6;

	for (yy=aalymin;yy<=aalymax;yy++)
		for (xx=aalxmin;xx<=aalxmax;xx++) {
			for (c=0,l=0,addr=yy*AALRESOLV;l<AALRESOLV;l++,addr++) {
				for (c1=fbuff[addr][xx];c1>0;c1>>=1) c+=(c1&1);
				fbuff[addr][xx]=0;
			}
			if (c) {
//				c=(c+3)/(AALRESOLV*AALRESOLV/MAXALINECOL);
				c/=(AALRESOLV*AALRESOLV/MAXALINECOL);
				rr=sqrt((double)((xx-xc)*(xx-xc)+(yy-yc)*(yy-yc)));
				cn=(cn2-dcn*rr);
				p=gifrgbp[cn];
				if (c<MAXALINECOL) {
					r2=imgif->red[p];
					g2=imgif->green[p];
					b2=imgif->blue[p];
					if (resol>=0) {
						p = gdImageGetPixel(imgif, xx, yy);
						r1=imgif->red[p];
						g1=imgif->green[p];
						b1=imgif->blue[p];
						r2=(r2*c+r1*(MAXALINECOL-c))>>SHIFTVAL;
						g2=(g2*c+g1*(MAXALINECOL-c))>>SHIFTVAL;
						b2=(b2*c+b1*(MAXALINECOL-c))>>SHIFTVAL;
						r2=(r2>>resol)<<resol;		g2=(g2>>resol)<<resol;		b2=(b2>>resol)<<resol;
					  }
					  else {
						r2=(r2*c+r1*(MAXALINECOL-c))>>SHIFTVAL;
						g2=(g2*c+g1*(MAXALINECOL-c))>>SHIFTVAL;
						b2=(b2*c+b1*(MAXALINECOL-c))>>SHIFTVAL;
					}
					p=gdImageColorExact(imgif,r2,g2,b2);
					if (p<0) {
						p = gdImageColorAllocate(imgif, r2, g2, b2);
						if (p<0) {
#ifdef PPM
							if (ppm>0) {
								gd_colormap_size(imgif, -1, ADDCOLMAP);
								p = gdImageColorAllocate(imgif, r2, g2, b2);
							  }
							  else {
								p=gd_image_color_near(imgif,r2,g2,b2);		m--;
							}
#else
							p=gd_image_color_near(imgif,r2,g2,b2);		m--;
#endif
//							  else {
//								p=fcol;		m--;
//							}
						}
						m++;
					}
				}
				gdImageSetPixel(imgif,xx,yy,p);
			}
		}
	aalxmin=gifwidthaa+1;		aalxmax=-1;
	aalymin=gifheightaa+1;		aalymax=-1;
//	printf("ff %d %d\n",fcol,m);
	return m;
}
#endif

void gdframes_line(int x1, int y1, int x2, int y2)
{
	gdImageLine(imgif,x1,y1,x2,y2,gdStyled);
}

void gdframes_rectangle(int x1, int y1, int x2, int y2, int color)
{
	gdImageRectangle(imgif,x1,y1,x2,y2,color);
}

void gdframes_fill_rectangle(int x1, int y1, int x2, int y2, int color)
{
	gdImageFilledRectangle(imgif,x1,y1,x2,y2,color);
}

void gdframes_fill_polygon(gdPointPtr p, int n, int color)
{
	gdImageFilledPolygon(imgif, p, n, color);
}

void gdframes_fillf_polygon(float *px, float *py, int n, int c)
{
	int i, y;
	float miny, maxy;
	float x1, y1, x2, y2;
	int ind1, ind2;
	int ints;

	if (n==0) return;

	if (imgif->polyAllocated==0) {
		imgif->polyInts = (int *) malloc(sizeof(int) * n);
		imgif->polyAllocated = n;
	}
	if (imgif->polyAllocated < n) {
		while (imgif->polyAllocated < n) imgif->polyAllocated *= 2;
		imgif->polyInts = (int *) realloc(imgif->polyInts, sizeof(int) * imgif->polyAllocated);
	}
	miny = py[0];
	maxy = py[0];
	for (i=1; (i < n); i++) {
		if (py[i] < miny) miny = py[i];
		if (py[i] > maxy) maxy = py[i];
	}
	/* Fix in 1.3: count a vertex only once */
	for (y=miny; (y <= maxy); y++) {
/*1.4		int interLast = 0; */
/*		int dirLast = 0; */
/*		int interFirst = 1; */
		ints = 0;
		for (i=0; (i < n); i++) {
			if (i==0) {
				ind1 = n-1;
				ind2 = 0;
			} else {
				ind1 = i-1;
				ind2 = i;
			}
			y1 = py[ind1];
			y2 = py[ind2];
			if (y1 < y2) {
				x1 = px[ind1];
				x2 = px[ind2];
			} else if (y1 > y2) {
				y2 = py[ind1];
				y1 = py[ind2];
				x2 = px[ind1];
				x1 = px[ind2];
			} else {
				continue;
			}
			if ((y >= y1) && (y < y2)) {
				imgif->polyInts[ints++] = (y-y1) * (x2-x1) / (y2-y1) + x1 + 0.5;
			} else if ((y == maxy) && (y > y1) && (y <= y2)) {
				imgif->polyInts[ints++] = (y-y1) * (x2-x1) / (y2-y1) + x1 + 0.5;
			}
		}
		qsort(imgif->polyInts, ints, sizeof(int), compare_int);

		for (i=0; (i < (ints)); i+=2) {
			gdImageLine(imgif, imgif->polyInts[i], y, imgif->polyInts[i+1], y, c);
		}
	}
}

#ifdef Bresenham_Circle

static void put_adot(int x, int y)
{
	if ((y < 0) || (y >= imgif->sy) || (x < 0) || (x >= imgif->sx)) return;
	imgif->pixels[y][x] = comcolor;
}

static void put_xdots(int x,int y,int x1)
{
	if ((y < 0) || (y >= imgif->sy)) return;
	if (x < 0) x=0;
	if (x1 >= imgif->sx) x1=(imgif->sx)-1;

	for ( ; x<=x1; x++) imgif->pixels[y][x] = comcolor;
}

static void put_ydots(int x,int y,int y1)
{
	if ((x < 0) || (x >= imgif->sx)) return;
	if (y < 0) y=0;
	if (y1 >= imgif->sy) y1=(imgif->sy)-1;
	for ( ; y<=y1; y++) imgif->pixels[y][x] = comcolor;
}

static void put_circle( int x, int y, int x1, int y1 )
{
	put_adot( x + x1, y + y1 );
	put_adot( x - x1, y + y1 );
	put_adot( x + x1, y - y1 );
	put_adot( x - x1, y - y1 );
	put_adot( x + y1, y + x1 );
	put_adot( x - y1, y + x1 );
	put_adot( x + y1, y - x1 );
	put_adot( x - y1, y - x1 );
}

/*	cf. http://www.funducode.com/freec/graphics/graphics2.htm		*/
static void g_circle(int x,int y,int r,int fill)
{
	int x1,y1,p;

	x1 = 0;
	y1 = r;
	p  = 3-(r<<1);

	if (fill==0) {
		while ( x1 < y1 ) {
			put_circle( x, y, x1, y1 );
			if ( p < 0 ) p += (x1<<2)+6;
			  else {
				p += ((x1-y1)<<2)+10;
				y1--;
			}
			x1++;
		} 
		if (r == 6) put_circle( x, y, x1, y1+1 );
		  else if (r == 5) put_circle( x, y, x1, x1 );
		  else if ( x1 == y1 ) put_circle( x, y, x1, y1 );
	  }
	  else {
		while ( x1 < y1 ) {
			put_xdots( x - y1, y + x1, x + y1 );
			put_xdots( x - y1, y - x1, x + y1 );
/*			put_ydots( x - x1, y - y1, y + y1 );
			put_ydots( x + x1, y - y1, y + y1 );	*/
			put_xdots( x - x1, y - y1, x + x1 );
			put_xdots( x - x1, y + y1, x + x1 );
			if ( p < 0 ) p += (x1<<2)+6;
			  else {
				p += ((x1-y1)<<2)+10;
				y1--;
			}
			x1++;
		} 
		if ( x1 == y1 ) {
/*			put_circle( x, y, x1, y1 );			*/
			put_xdots( x - x1, y - y1, x + x1 );
			put_xdots( x - x1, y + y1, x + x1 );
		}
		if (r == 6) put_circle( x, y, x1, y1+1 );
		if (r == 5) put_circle( x, y, x1, x1 );
	}
}

/*	cf. http://www2.starcat.ne.jp/~fussy/algo/index.htm			*/
static void g_ellipse(int x,int y,int rx,int ry,int fill)
{
	int x1,y1,F,H,r=rx*ry,b=rx*rx,a=ry*ry;

	if (fill==0) {
		x1 = rx;
		y1 = 0;
		F = -2*ry*r + a + 2*b;
		H = -4*ry*r + 2*a + b;
		while ( x1 >= 0 ) {
			put_adot( x + x1, y + y1 );
			put_adot( x - x1, y + y1 );
			put_adot( x + x1, y - y1 );
			put_adot( x - x1, y - y1 );
			if ( F < 0 ) {
				y1++;
				F += 4 * b * y1 + 2 * b;
				H += 4 * b * y1;
			  }
			  else if ( H >= 0 ) {
				x1--;
				F -= 4*a*x1;
				H -= 4*a*x1 - 2*a;
			  }
			  else {
				x1--;
				y1++;
				F += 4*b*y1 - 4*a*x1 + 2*b;
				H += 4*b*y1 - 4*a*x1 + 2*a;
			}
		}
	  }
	  else {
		x1 = rx;
		y1 = 0;
		F = -2*ry*r + a + 2*b;
		H = -4*ry*r + 2*a + b;
		while ( x1 > 0 ) {
			put_xdots( x - x1, y + y1, x + x1 );
			put_xdots( x - x1, y - y1, x + x1 );
			if ( F < 0 ) {
				y1++;
				F += 4*b*y1 + 2*b;
				H += 4*b*y1;
			  }
			  else if ( H >= 0 ) {
				x1--;
				F -= 4*a*x1;
				H -= 4*a*x1 - 2*a;
			  }
			  else {
				x1--;
				y1++;
				F += 4*b*y1 - 4*a*x1 + 2*b;
				H += 4*b*y1 - 4*a*x1 + 2*a;
			}
		}
	}
}

void gdframes_circle(int cx, int cy, int dx, int dy, int color, int fill)
{
	comcolor=color;
	dx/=2;		dy/=2;
	if (dy<=0) put_xdots(cx-dx,cy,cx+dx);
	  else if (dx<=0) put_ydots(cx,cy-dy,cy+dy);
	  else if (dx==dy) g_circle(cx,cy,dx,fill);
	  else g_ellipse(cx,cy,dx,dy,fill);
}

#else
void gdframes_circle(int cx, int cy, int dx, int dy, int color, int fill)
{
	int i;
	comcolor=color;
	gdImageArc(imgif,cx,cy,dx,dy,0,360,color);

	if (fill) {
		for(i=1;i<=dx && i<=dy;i++) {
			gdImageArc(imgif,cx,cy,dx-i,dy-i,0,360,color);
		}
	}
}
#endif

void gdframes_arc(int cx, int cy, int w, int h, int s, int e, int color)
{
	gdImageArc(imgif,cx,cy,w,h,s,e,color);
}

static void put_graddot(int x, int y, int xc, int yc, int cn2, double dcn,int *gifrgbp)
{
	double rr,sqrt(double);
	int cn;
	if ((y < 0) || (y >= imgif->sy) || (x < 0) || (x >= imgif->sx)) return;

	rr=sqrt((double)(xc*xc+yc*yc));
	cn=(cn2-dcn*rr);
	imgif->pixels[y][x] = gifrgbp[cn];
}

static void put_gradcircle_peri( int xx, int yy, int x1, int y1, int xc, int yc, int cn2, double dcn,int *gifrgbp)
{
	put_graddot( xx + x1, yy + y1 , x1-xc, y1-yc, cn2, dcn, gifrgbp);
	put_graddot( xx - x1, yy + y1 , x1+xc, y1-yc, cn2, dcn, gifrgbp);
	put_graddot( xx + x1, yy - y1 , x1-xc, y1+yc, cn2, dcn, gifrgbp);
	put_graddot( xx - x1, yy - y1 , x1+xc, y1+yc, cn2, dcn, gifrgbp);
	put_graddot( xx + y1, yy + x1 , y1-xc, x1-yc, cn2, dcn, gifrgbp);
	put_graddot( xx - y1, yy + x1 , y1+xc, x1-yc, cn2, dcn, gifrgbp);
	put_graddot( xx + y1, yy - x1 , y1-xc, x1+yc, cn2, dcn, gifrgbp);
	put_graddot( xx - y1, yy - x1 , y1+xc, x1+yc, cn2, dcn, gifrgbp);
}

void gdframes_gradcircle(int xx,int yy,int dr,int cn1,int cn2,int *gifrgbp)
{
	int x1,y1,p,r;
	int x,y,y2,cn,xc,yc,xs,xe;
	double dcn,rr,sqrt(double);

	dcn = 6*(cn2-cn1)/((double)dr*5);
	xc=dr/6;	yc=-dr/6;	r=dr/2;
	x1 = 0;
	y1 = r;
	p  = 3-(r<<1);
	while ( x1 < y1 ) {
		y=yy+x1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-y1;		xe=y1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=xs, y2=(x1-yc)*(x1-yc); x<=xe; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		y=yy-x1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-y1;		xe=y1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=xs, y2=(x1+yc)*(x1+yc); x<=xe; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		y=yy-y1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-x1;		xe=x1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=-x1, y2=(y1+yc)*(y1+yc); x<=x1; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		y=yy+y1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-x1;		xe=x1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=-x1, y2=(y1-yc)*(y1-yc); x<=x1; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		if ( p < 0 ) p += (x1<<2)+6;
		  else {
			p += ((x1-y1)<<2)+10;
			y1--;
		}
		x1++;
	}
	if ( x1 == y1 ) {
		y=yy-y1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-x1;		xe=x1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=-x1, y2=(y1+yc)*(y1+yc); x<=x1; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		y=yy+y1;
		if ((y >= 0) && (y < imgif->sy)) {
			xs=-x1;		xe=x1;
			if (xx+xs < 0) xs=-xx;
			if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
			for (x=-x1, y2=(y1-yc)*(y1-yc); x<=x1; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+y2));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
	}
	if (r == 6) put_gradcircle_peri( xx, yy, x1, y1+1, xc, yc, cn2, dcn, gifrgbp);
	if (r == 5) put_gradcircle_peri( xx, yy, x1, x1 ,xc, yc, cn2, dcn, gifrgbp);
}
/*
void gdframes_gradcircle(int xx,int yy,int dr,int ic,int *gifrgbp,int maxcolnum)
{
	int x,y,x1,y1,F,H,r,b,a;
	int cn,xc,yc,cn1,cn2,xs,xe;
	double dcn,rr,sqrt(double);

	r=drx*dry/4;		b=drx*drx/4;		a=dry*dry/4;
	if (ic<=0) {
		cn1=maxcolnum*0.05;			cn2=maxcolnum*0.95;
	  }
	  else {
		cn1=(ic-1)<<5;				cn2=cn1+31;
	}
	dcn = 6*(cn2-cn1)/((double)drx*4);

	x1 = drx/2;
	y1 = 0;
	xc=drx/6;		yc=dry/6;
	F = -dry*r + a + 2*b;
	H = -2*dry*r + 2*a + b;
	while ( x1 > 0 ) {
		y=yy+y1;
		xs=-x1;		xe=x1;
		if (xx+xs < 0) xs=-xx;
		if (xx+xe >= imgif->sx) xe=(imgif->sx)-1-xx;
		if ((y >= 0) && (y < imgif->sy)) {
			for (x=xs; x<=xe; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+(y1+yc)*(y1+yc)));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		y=yy-y1;
		if ((y >= 0) && (y < imgif->sy)) {
			for (x=xs; x<=xe; x++) {
				rr=sqrt((double)((x-xc)*(x-xc)+(y1+yc)*(y1+yc)));
				cn=(cn2-dcn*rr);
				imgif->pixels[y][xx+x] = gifrgbp[cn];
			}
		}
		if ( F < 0 ) {
			y1++;
			F += 4*b*y1 + 2*b;
			H += 4*b*y1;
		  }
		  else if ( H >= 0 ) {
			x1--;
			F -= 4*a*x1;
			H -= 4*a*x1 - 2*a;
		  }
		  else {
			x1--;
			y1++;
			F += 4*b*y1 - 4*a*x1 + 2*b;
			H += 4*b*y1 - 4*a*x1 + 2*a;
		}
	}
}
*/

void gdframes_gradrectangle(int xs,int ys,int xe,int ye,int icn[],int *gifrgbp,int maxcolnum)
{
	double a,b,c,d1,d2;
	int x,y,ff,cn,x1,y1;

	a=b=c=0;
	if (xs!=xe) {
		b=((double)(icn[2]-icn[0]))/(xe-xs);
		if (ys!=ye) {
			c=((double)(icn[1]-icn[0]))/(ye-ys);
			a=((double)(icn[3]+icn[0]-icn[2]-icn[1]))/((xe-xs)*(ye-ys));
		}
	  }
	  else if (ys!=ye) {
		c=((double)(icn[1]-icn[0]))/(ye-ys);
	}

	x1=xs;		y1=ys;
	if (xs<0) xs=0;
	if (ys<0) ys=0;
	if (xe>=imgif->sx) xe=(imgif->sx)-1;
	if (ye>=imgif->sy) ye=(imgif->sy)-1;
	for (y=ys;y<=ye;y++) {
		d1=a*(y-y1)+b;		d2=c*(y-y1)+icn[0];
		for (x=xs;x<=xe;x++) {
			ff=d1*(x-x1)+d2;
			if (ff<0) ff=0;
			cn=(ff>>16);
			if (cn>=maxcolnum) cn=maxcolnum-1;
			imgif->pixels[y][x] = gifrgbp[cn];
		}
	}
}

#define PUTDOT(X,Y,C)	(((Y)<0 || (Y)>=imgif->sy || (X)<0 || (X)>=imgif->sx)?0:(imgif->pixels[Y][X]=gifrgbp[C]))
static int l1[1000][2],l2[1000][2],l3[1000][2];

static void get_line_dots(int x0, int y0, int x1, int y1, int ll[][2])
{
	int x,y,dx,dy,ddx,de;

	dx = x1-x0;		dy = y1-y0;		ddx=1;

	if (abs(dx) >= dy) {
		if (dx>=0) {
			de=-dx;		dx+=dx;		dy+=dy;
			for (x=x0,y=y0,ll[0][0]=x0;x<x1; ) {
//				PUTDOT(x,y,cn);
				ll[y-y0][1]=x++;	de+=dy;
				if (de>0) {
					y++;	de-=dx;		ll[y-y0][0]=x;
				}
			}
			ll[y1-y0][1]=x1;
		  }
		  else {
			de=dx;		dx+=dx;		dy+=dy;
			for (x=x0,y=y0,ll[0][1]=x0;x>x1; ) {
//				PUTDOT(x,y,cn);
				ll[y-y0][0]=x--;	de+=dy;
				if (de>0) {
					y++;	de+=dx;	ll[y-y0][1]=x;
				}
			}
			ll[y1-y0][0]=x1;
		}
	  }
	  else {
		if (dx<0) { dx=-dx;  ddx=-ddx; }
		de=-dy;		dx+=dx;		dy+=dy;
		for (x=x0,y=y0;y<=y1;y++) {
//			PUTDOT(x,y,cn);
			de+=dx;	ll[y-y0][0]=ll[y-y0][1]=x;
			if (de>0) {
				x+=ddx;		de-=dy;
			}
		}
	}
}

/*	Suppose yy[0] <= yy[1] <= yy[2]	
	Caution ! xx, yy, icn will be broken.		*/
void gdframes_gradtriangle(int xx[],int yy[],int icn[],int *gifrgbp,int maxcolnum)
{
	double a,b,s;
	int x,y,x0,y0,x1,y1,x2,y2,cn,i,j,cmin,cmax;

	cmin=icn[0]>>16;		cmax=icn[2]>>16;
	for (j=0;j<2;j++) {
		for (i=j+1;i<3;i++) {
			if (yy[j]>yy[i]) {
				cn=icn[i];		icn[i]=icn[j];		icn[j]=cn;
				cn=xx[i];		xx[i]=xx[j];		xx[j]=cn;
				cn=yy[i];		yy[i]=yy[j];		yy[j]=cn;
			}
		}
	}

	if (yy[2] < 0 || yy[0] >= imgif->sy) return;

	x0 = xx[0];			y0 = yy[0];
	x1 = xx[1];			y1 = yy[1];
	x2 = xx[2];			y2 = yy[2];

	get_line_dots(x0,y0,x1,y1,l1);
	get_line_dots(x0,y0,x2,y2,l2);
	get_line_dots(x1,y1,x2,y2,l3);

	s=(x1-x0)*(y2-y0)-(x2-x0)*(y1-y0);
	if (s < 0) {
/*			cn=icn[0]>>16;
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l1[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y0;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l2[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y1;y<=y2;y++) {
				for (x=l3[y-y1][0];x<=l3[y-y1][1];x++) PUTDOT(x,y,cn);
			}*/
		if (icn[1]==icn[0] && icn[2]==icn[0]) {
			cn=icn[0]>>16;
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l2[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y1;y<=y2;y++) {
				for (x=l3[y-y1][0];x<=l2[y-y0][1];x++) PUTDOT(x,y,cn);
			}
		  }
		  else {
			a=((icn[1]-icn[0])*(y2-y0)-(icn[2]-icn[0])*(y1-y0))/s;
			b=((icn[2]-icn[0])*(x1-x0)-(icn[1]-icn[0])*(x2-x0))/s;
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l2[y-y0][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
			for (y=y1;y<=y2;y++) {
				for (x=l3[y-y1][0];x<=l2[y-y0][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
		}
	  }
	  else if (s > 0) {
		if (icn[1]==icn[0] && icn[2]==icn[0]) {
			cn=icn[0]>>16;
/*			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l1[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y0;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l2[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y1;y<=y2;y++) {
				for (x=l3[y-y1][0];x<=l3[y-y1][1];x++) PUTDOT(x,y,cn);
			}*/
			for (y=y0;y<=y1;y++) {
				for (x=l2[y-y0][0];x<=l1[y-y0][1];x++) PUTDOT(x,y,cn);
			}
			for (y=y1;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l3[y-y1][1];x++) PUTDOT(x,y,cn);
			}
		  }
		  else {
/*			cn=icn[0]>>16;
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l1[y-y0][1];x++) {PUTDOT(x,y,cn);				printf("cc1 %d %d\n",x,y);}

			}
			for (y=y0;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l2[y-y0][1];x++) {PUTDOT(x,y,cn);				printf("cc2 %d %d\n",x,y);}
			}
			for (y=y1;y<=y2;y++) {
				for (x=l3[y-y1][0];x<=l3[y-y1][1];x++) {PUTDOT(x,y,cn);				printf("cc3 %d %d\n",x,y);}
			}*/
			a=((icn[1]-icn[0])*(y2-y0)-(icn[2]-icn[0])*(y1-y0))/s;
			b=((icn[2]-icn[0])*(x1-x0)-(icn[1]-icn[0])*(x2-x0))/s;
			for (y=y0;y<=y1;y++) {
				for (x=l2[y-y0][0];x<=l1[y-y0][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
			for (y=y1;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l3[y-y1][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
		}
	  }
	  else if ((icn[1]==icn[0] && icn[2]==icn[0]) || y2==y1) {
		cn=icn[0]>>16;
		if (y2>=y1) {
			for (y=y0;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l2[y-y0][1];x++) PUTDOT(x,y,cn);
			}
		  }
		  else {
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l1[y-y0][1];x++) PUTDOT(x,y,cn);
			}
		}
	  }
	  else {
		a=b=0;
		if (y2>y1) {
			if (abs(x2-x0) >= y2-y0) a=((double)(icn[2]-icn[0]))/(x2-x0);
			  else 					 b=((double)(icn[2]-icn[0]))/(y2-y0);
			for (y=y0;y<=y2;y++) {
				for (x=l2[y-y0][0];x<=l2[y-y0][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
		  }
		  else {
			if (abs(x1-x0) >= y1-y0) a=((double)(icn[1]-icn[0]))/(x1-x0);
			  else 					 b=((double)(icn[1]-icn[0]))/(y1-y0);
			for (y=y0;y<=y1;y++) {
				for (x=l1[y-y0][0];x<=l1[y-y0][1];x++) {
					cn=a*(x-x0)+b*(y-y0)+icn[0];
					cn>>=16;
					if (cn<cmin) cn=cmin;
					if (cn>cmax) cn=cmax;
					PUTDOT(x,y,cn);
				}
			}
		}
	}
}

/*
void gdframes_gradtriangle(int xx[],int yy[],int icn[],int *gifrgbp,int maxcolnum)
{
	double a,b,c,d1,d2;
	int dx1,dy1,ddx1,de1,dx2,dy2,ddx2,de2,dx3,dy3,ddx3,de3;
	int x,y,x0,y0,x1,y1,x2,y2,tt,cn;

	if (yy[2] < 0 || yy[0] >= imgif->sy) return;

	x0 = xx[0];			y0 = yy[0];
	x1 = xx[1];			y1 = yy[1];
	x2 = xx[2];			y2 = yy[2];
	dx1 = x1-x0;		dy1 = y1-y0;		ddx1=1;
	dx2 = x2-x0;		dy2 = y2-y0;		ddx2=1;
	dx3 = x2-x1;		dy3 = y2-y1;		ddx3=1;

	cn = icn[0]>>16;
	if (abs(dx1) >= dy1) {
		if (dx1>=0) {
			de1=-dx1;	dx1+=dx1;	dy1+=dy1;
			for (x=x0,y=y0;x<=x1;x++) {
				PUTDOT(x,y,cn);
				de1+=dy1;
				if (de1>0) {
					y++;	de1-=dx1;
				}
			}
		  }
		  else {
			de1=dx1;	dx1+=dx1;	dy1+=dy1;
			for (x=x0,y=y0;x>=x1;x--) {
				PUTDOT(x,y,cn);
				de1+=dy1;
				if (de1>0) {
					y++;	de1+=dx1;
				}
			}
		}
	  }
	  else {
		if (dx1<0) { dx1=-dx1;  ddx1=-ddx1; }
		de1=-dy1;	dx1+=dx1;	dy1+=dy1;
		for (x=x0,y=y0;y<=y1;y++) {
			PUTDOT(x,y,cn);
			de1+=dx1;
			if (de1>0) {
				x+=ddx1;	de1-=dy1;
			}
		}
	}

	cn = icn[0]>>16;
	if (abs(dx2) >= dy2) {
		if (dx2>=0) {
			de2=-dx2;	dx2+=dx2;	dy2+=dy2;
			for (x=x0,y=y0;x<=x2;x++) {
				PUTDOT(x,y,cn);
				de2+=dy2;
				if (de2>0) {
					y++;	de2-=dx2;
				}
			}
		  }
		  else {
			de2=dx2;	dx2+=dx2;	dy2+=dy2;
			for (x=x0,y=y0;x>=x2;x--) {
				PUTDOT(x,y,cn);
				de2+=dy2;
				if (de2>0) {
					y++;	de2+=dx2;
				}
			}
		}
	  }
	  else {
		if (dx2<0) { dx2=-dx2;  ddx2=-ddx2; }
		de2=-dy2;	dx2+=dx2;	dy2+=dy2;
		for (x=x0,y=y0;y<=y2;y++) {
			PUTDOT(x,y,cn);
			de2+=dx2;
			if (de2>0) {
				x+=ddx2;	de2-=dy2;
			}
		}
	}

	cn = icn[1]>>16;
	if (abs(dx3) >= dy3) {
		if (dx3>=0) {
			de3=-dx3;	dx3+=dx3;	dy3+=dy3;
			for (x=x1,y=y1;x<=x2;x++) {
				PUTDOT(x,y,cn);
				de3+=dy3;
				if (de3>0) {
					y++;	de3-=dx3;
				}
			}
		  }
		  else {
			de3=dx3;	dx3+=dx3;	dy3+=dy3;
			for (x=x1,y=y1;x>=x2;x--) {
				PUTDOT(x,y,cn);
				de3+=dy3;
				if (de3>0) {
					y++;	de3+=dx3;
				}
			}
		}
	  }
	  else {
		if (dx3<0) { dx3=-dx3;  ddx3=-ddx3; }
		de3=-dy3;	dx3+=dx3;	dy3+=dy3;
		for (x=x1,y=y1;y<=y2;y++) {
			PUTDOT(x,y,cn);
			de3+=dx3;
			if (de3>0) {
				x+=ddx3;	de3-=dy3;
			}
		}
	}
}
*/

void gdframes_string(int font, int x1, int y1, char *str, int color)
{
	gdImageString(imgif, gdFonts[font], x1, y1, (unsigned char *)str, color);
}

void gdframes_colset(FILE *fp)
{
	int B,i;
	int interlace, transparent, BitsPerPixel;
	int Resolution;
	int ColorMapSize;
	int ColorMopSize,ColorMopSize1,ColorMopSize2;
	int *Red,*Green,*Blue;
	
	Red=imgif->red;
	Green=imgif->green;
	Blue=imgif->blue;
	interlace = imgif->interlace;
	transparent = imgif->transparent;

/* Clear any old values in statics strewn through the GIF code */
/*	init_statics();
	BitsPerPixel = colorstobpp(imgif->colorsTotal);		*/
	BitsPerPixel = gd_init_statics_colorstobpp(imgif->colorsTotal);
	ColorMapSize = 1 << BitsPerPixel;
	
	fseek(fp,10,SEEK_SET); 
	Resolution = BitsPerPixel;

	B = 0x80|((Resolution-1)<<4)|(BitsPerPixel-1);
	fputc( B, fp );		fputc( 0, fp );		fputc( 0, fp );

	ColorMopSize=(256-ColorMapSize)*3;
	
/*	printf("clmap==%d,mop==%d\n",ColorMapSize,ColorMopSize);*/
	for ( i=0; i<ColorMapSize; i++ ) {
		fputc( Red[i], fp );
		fputc( Green[i], fp );
		fputc( Blue[i], fp );
	}

/*	Fill up with meaningless characters in the rest for 256 colormap space		*/
	if (gctable==0) {
		if(ColorMopSize > 256){
			ColorMopSize1=ColorMopSize/3;
			ColorMopSize2=ColorMopSize/3;
			ColorMopSize=ColorMopSize-ColorMopSize1-ColorMopSize2;
		/*printf("%d,%d,%d\n",ColorMopSize,ColorMopSize1,ColorMopSize2);	*/
			ColorMopSize1=ColorMopSize1-4;
			fputc( 0x21, fp );		fputc( 0xfe, fp );
			fputc( ColorMopSize1, fp );
			for ( i=0; i<ColorMopSize1; i++ ) fputc( 4, fp );
			fputc( 0, fp );

			ColorMopSize2=ColorMopSize2-4;
			fputc( 0x21, fp );
			fputc( 0xfe, fp );
			fputc( ColorMopSize2, fp );
			for ( i=0; i<ColorMopSize2; i++ ) fputc( 5, fp );
			fputc( 0, fp );
		
			ColorMopSize=ColorMopSize-4;
			fputc( 0x21, fp );
			fputc( 0xfe, fp );
			fputc( ColorMopSize, fp );
			for ( i=0; i<ColorMopSize; i++ ) fputc( 6, fp );
			fputc( 0, fp );
		  }
		  else if(ColorMopSize > 0) {
			ColorMopSize=ColorMopSize-4;
			fputc( 0x21, fp );	fputc( 0xfe, fp );
			fputc( ColorMopSize, fp );
			for ( i=0; i<ColorMopSize; i++ ) fputc( 0, fp );
			fputc( 0, fp );
		}
	}
}

static void store_for_frames(FILE *fp, int step)
{
	fputc( 0x21, fp );		fputc( 0xfe, fp );
	fputc( 9, fp );
	fwrite( "*Frames*", 1, 8, fp );
	fputc( step, fp );
	fputc( 0, fp );
}

void gdframes_animation(FILE *fp,int count,int delay,int gct,int step)
{
	int B;
	int RWidth, RHeight, RInterlace;
	int LeftOfs, TopOfs;
	int Resolution;
	int ColorMapSize;
	int ColorMopSize,ColorMopSize1,ColorMopSize2;
	int InitCodeSize;
	int i,icheck;
	int *Red, *Green, *Blue;
	int Transparent, BitsPerPixel, Background=0;
	char chc;

	gctable=gct;
	/* Clear any old values in statics strewn through the GIF code */
	/* init_statics();
	All set, let's do it. */

	Red = imgif->red;
	Green = imgif->green;
	Blue = imgif->blue;
	RInterlace = imgif->interlace;
	Transparent = imgif->transparent;

/*	BitsPerPixel = colorstobpp(imgif->colorsTotal);		*/
	BitsPerPixel = gd_init_statics_colorstobpp(imgif->colorsTotal);
	ColorMapSize = 1 << BitsPerPixel;

/*
	Interlace = imgif->interlace;
	RWidth = Width = imgif->sx;
	RHeight = Height = imgif->sy;
*/
	RWidth = imgif->sx;
	RHeight = imgif->sy;
	LeftOfs = TopOfs = 0;

	Resolution = BitsPerPixel;

/*
* Calculate number of bits we are expecting
*/
/*
	CountDown = (long)Width * (long)Height;
	Pass = 0;
	curx = cury = 0;
 */

	gd_set_static_values(RWidth, RHeight);

	if ( BitsPerPixel <= 1 ) InitCodeSize = 2;
        else				 InitCodeSize = BitsPerPixel;


/*********** Pass At the First Time ********************************/
	icheck=0;

	chc=fgetc(fp);
	if (chc!='G') {
		fwrite( "GIF89a", 1, 6, fp );
		Putword( RWidth, fp );
		Putword( RHeight, fp );

		B = 0x80|((Resolution-1)<<4)|(BitsPerPixel-1);
		fputc( B, fp );

		fputc( Background, fp );		fputc( 0, fp );

		ColorMopSize=(256-ColorMapSize)*3;
/*printf("clmap==%d,mop==%d\n",ColorMapSize,ColorMopSize);
*/
		for ( i=0; i<ColorMapSize; i++ ) {
			fputc( Red[i], fp );
			fputc( Green[i], fp );
			fputc( Blue[i], fp );
		}

/*	Fill up with meaningless characters in the rest for 256 colormap space		*/
		if (gctable==0) {
			if (ColorMopSize > 256) {
				ColorMopSize1=ColorMopSize/3;
				ColorMopSize2=ColorMopSize/3;
				ColorMopSize=ColorMopSize-ColorMopSize1-ColorMopSize2;
/*				printf("%d,%d,%d\n",ColorMopSize,ColorMopSize1,ColorMopSize2);*/
				ColorMopSize1=ColorMopSize1-4;
				fputc( 0x21, fp );		fputc( 0xfe, fp );
				fputc( ColorMopSize1, fp );
				for ( i=0; i<ColorMopSize1; i++ ) fputc( 0, fp );
				fputc( 0, fp );

				ColorMopSize2=ColorMopSize2-4;
				fputc( 0x21, fp );		fputc( 0xfe, fp );
				fputc( ColorMopSize2, fp );
				for ( i=0; i<ColorMopSize2; i++ ) fputc( 1, fp );
				fputc( 0, fp );

				ColorMopSize=ColorMopSize-4;
				fputc( 0x21, fp );		fputc( 0xfe, fp );
				fputc( ColorMopSize, fp );
				for ( i=0; i<ColorMopSize; i++ ) fputc( 2, fp );
				fputc( 0, fp );
			  }
			  else if (ColorMopSize > 0) {
				ColorMopSize=ColorMopSize-4;
				fputc( 0x21, fp );		fputc( 0xfe, fp );
				fputc( ColorMopSize, fp );
				for ( i=0; i<ColorMopSize; i++ ) fputc( 3, fp );
				fputc( 0, fp );
			}
		}

/********** Application Settings *********************/
		if (count!=1) {
			fputc( 0x21, fp );		fputc( 0xff, fp );		fputc( 0x0b, fp );
			fwrite("NETSCAPE2.0", 1, 11, fp );
/*			fputc( 'N', fp );
			fputc( 'E', fp );
			fputc( 'T', fp );
			fputc( 'S', fp );
			fputc( 'C', fp );
			fputc( 'A', fp );
			fputc( 'P', fp );
			fputc( 'E', fp );
			fputc( '2', fp );
			fputc( '.', fp );
			fputc( '0', fp );		*/
			fputc( 3, fp );		fputc( 1, fp );

			if (count>65535) {
				fprintf(stderr,"GIF repeat times are too large !!!\n");
				exit(0);
			}
			fputc( count&0xff, fp );
			fputc( count>>8  , fp );
			fputc( 0, fp );
		}	/* Unnecessary for one time */

		fputc( 0x21, fp );		fputc( 0xf9, fp );		fputc( 4, fp );
		if (Transparent >= 0) fputc( 9, fp );
			else 			  fputc( 8, fp );

		if (delay>65535) {
			fprintf(stderr,"GIF Delay time is too large !!!\n");
			exit(0);
		}
		fputc( delay&0xff, fp );		fputc( delay>>8  , fp );

		if (Transparent >= 0) fputc( (unsigned char) Transparent, fp );
			else 			  fputc( 0, fp);
		fputc( 0, fp );

		if (step>1) store_for_frames(fp, step);

		icheck=1;
	}

/*********** End up the First Time ********************************/
/*********** Animation Settings *********************/
	if (icheck!=1) {
		fseek(fp,-1,SEEK_END); 
/*		chc=fgetc(fp);
		if (chc==';') fseek(fp,-2,SEEK_END);		*/

		fputc( 0x21, fp );		fputc( 0xf9, fp );		fputc( 4, fp );
		if (Transparent >= 0) fputc( 9, fp );
			else 			  fputc( 8, fp );

		if (delay>65535) {
			fprintf(stderr,"GIF Delay time is too large !!!\n");
			exit(0);
		}
		fputc( delay&0xff, fp );		fputc( delay>>8  , fp );

		if (Transparent >= 0) fputc( (unsigned char) Transparent, fp );
			else 			  fputc( 0, fp);
		fputc( 0, fp );
	}

	fputc( 0x2c, fp );

	Putword( LeftOfs, fp );
	Putword( TopOfs, fp );
	Putword( RWidth, fp );
	Putword( RHeight, fp );

	if (gctable) {
		RInterlace = imgif->interlace;
		ColorMapSize = 1 << BitsPerPixel;

		if ( RInterlace ) B = 0xc0;
			else		 B = 0x80;       
		B |= (BitsPerPixel - 1);
		fputc( B, fp );

		for ( i=0; i<ColorMapSize; i++ ) {
			fputc( Red[i], fp );
			fputc( Green[i], fp );
			fputc( Blue[i], fp );
		}
	  }
	  else {
		if ( RInterlace ) fputc( 0x40, fp );
			else		 fputc( 0x00, fp );
	}

	fputc( InitCodeSize, fp );
	gd_static_compress( InitCodeSize+1, fp, imgif, Background, RInterlace);
	fputc( 0, fp );
	fputc( 0x3b, fp );
}
