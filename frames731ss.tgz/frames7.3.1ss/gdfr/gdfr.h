/******************************************************
 *                 gdfr 1.3 Header File               *
 *       GD Extention to create a GIF Animation       *
 *           Written by T. Taguchi for Frames         *
 *                     July 14, 2007                  *
 ******************************************************
*/

#ifndef _GDFR_H_
#define _GDFR_H_

typedef struct {
	int x, y;
} gdPoint, *gdPointPtr;

void gdframes_image_create(int width, int height);
void gdframes_image_destroy(void);
void gdframes_image_gif(FILE *out);
void gdframes_image_ppm(FILE *out);
void gdframes_colormap_size(int size);

int  gdframes_color_allocate(int r, int g, int b);
void gdframes_color_deallocate(int color);
void gdframes_color_transparent(int color);
void gdframes_interlace(int interlaceArg);

void gdframes_frame_clear(int color);
void gdframes_set_pixel(int x1, int y1, int color);
void gdframes_set_style(int *style, int noOfPixels);
void gdframes_line(int x1, int y1, int x2, int y2);
void gdframes_rectangle(int x1, int y1, int x2, int y2, int color);
void gdframes_fill_rectangle(int x1, int y1, int x2, int y2, int color);
void gdframes_gradrectangle(int xs,int ys,int xe,int ye,int icn[],int *gifrgbp,int maxcolnum);
void gdframes_gradtriangle(int xx[],int yy[],int icn[],int *gifrgbp,int maxcolnum);
void gdframes_fill_polygon(gdPointPtr p, int n, int color);
void gdframes_fillf_polygon(float *px, float *py, int n, int c);
void gdframes_arc(int cx, int cy, int w, int h, int s, int e, int color);
void gdframes_circle(int cx, int cy, int w, int h, int color, int fill);
void gdframes_gradcircle(int xx,int yy,int dr,int cn1,int cn2,int *gifrgbp);
void gdframes_string(int font, int x1, int y1, char *str, int color);

void gdframes_animation(FILE *,int,int,int,int);
void gdframes_colset(FILE *);

int  gdframes_aaline(float x1, float y1, float x2, float y2, int thick);
int  gdframes_aacircle(float cx, float cy, float dx, float dy, int fill);
int  gdframes_aagradcircle(float cx, float cy, float dr);
int  gdframes_aafillpolygon(float *px, float *py, int n);
int  gdframes_aaspaceflush(int fcol, int bcol, int resol, int ppm);
int  gdframes_aagradspaceflush(int xc, int yc, int dr, int cn1, int cn2, int *gifrgbp, int resol, int ppm);
int  gdframes_aastring(float px, float py, char *str, int chk);

#endif
