###############################################
###              gdfr 1.2 README            ###
###       For Microsoft Visual Studio       ###
###       June 29, 2007 by T. Taguchi       ###
###############################################

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

OUTDIR=.
INTDIR=.
GDDIR=gd1.3

ALL : "$(OUTDIR)\gdfr.lib"


clean :
	-@erase "$(INTDIR)\gdfr.obj"
	-@erase "$(INTDIR)\gdex.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\gdfr.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=icl.exe
CPP_PROJ=/nologo /GX /Fp"$(INTDIR)gdfr.pch" /YX /FD /c

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"gdfr.bsc" 
BSC32_SBRS= \
	
LIB32=xilink6.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\gdfr.lib"
LIB32_OBJS= \
	"$(INTDIR)\gdfr.obj" \
	"$(INTDIR)\gdex.obj" \
	"$(INTDIR)\gdfontt.obj" \
	"$(INTDIR)\gdfonts.obj" \
	"$(INTDIR)\gdfontmb.obj" \
	"$(INTDIR)\gdfontl.obj" \
	"$(INTDIR)\gdfontg.obj"

"$(OUTDIR)\gdfr.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

SOURCE=gdfr.c

"$(INTDIR)\gdfr.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=gdex.c

"$(INTDIR)\gdex.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=$(GDDIR)\gdfontt.c

"$(INTDIR)\gdfontt.obj" : $(SOURCE)
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=$(GDDIR)\gdfonts.c

"$(INTDIR)\gdfonts.obj" : $(SOURCE)
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=$(GDDIR)\gdfontmb.c

"$(INTDIR)\gdfontmb.obj" : $(SOURCE)
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=$(GDDIR)\gdfontl.c

"$(INTDIR)\gdfontl.obj" : $(SOURCE)
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)


SOURCE=$(GDDIR)\gdfontg.c

"$(INTDIR)\gdfontg.obj" : $(SOURCE)
	$(CPP) $(CPP_PROJ) /I"$(GDDIR)" $(SOURCE)
