#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "gdfr.h"

int			gifbasecolor[255],giflineset;
unsigned char	*font,line[100];
/*  Real number version  0<=fh<=360   0<=fl,fs<=1	*/
#define weps 		1.0e-3
#define rgbmax 		65536
#define rgbmax1		(rgbmax-1)
#define rgbmax6 	(6*rgbmax)

static void hls2rgb(double dh,double dl,double ds,int *ir,int *ig,int *ib)
{
	unsigned int w1,w2,fl,fs,fh;
	int wh;

	if (dh < 0) dh+=360;
	fh=rgbmax*dh/60;		fl=rgbmax1*dl;		fs=rgbmax1*ds;
	if (fl>rgbmax1) fl=rgbmax1;
	if (fs>rgbmax1) fs=rgbmax1;

	if ( fl < rgbmax/2 ) w2 = fl*(rgbmax+fs)/rgbmax;
				else     w2 = rgbmax1-(rgbmax-fs)*(rgbmax-fl)/rgbmax;
	w1 = 2*fl-w2;

	if ( fs < rgbmax/1024 ) *ir = *ig = *ib = fl;
	  else {
		wh = fh+2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ir = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
				( wh < 3*rgbmax? w2:
				( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));

		*ig = (  fh <   rgbmax? w1+(w2-w1)*fh/rgbmax:
				( fh < 3*rgbmax? w2:
				( fh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-fh)/rgbmax: w1 )));

		wh = fh-2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ib = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
				( wh < 3*rgbmax? w2:
				( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));
	}
}

static int maxlincol=8;

main()
{
	int i,j,k,n=600,n1=64,n2,n3=64,r,g,b,r1,g1,b1,r2,g2,b2;
	int dd=100;
	double x[600],y[600];
	int x1,y1,x2,y2,alinecol[8];
	double dl,xx,th,pi=3.14159265358979;
	float px[10],py[10];
	gdPoint xy[30];
	FILE *imout,*nsfont;
	int nfont0,nfont,ifont,nf,fwid,fhei,nbit,c1;
	int nxmin,nxmax,nymin,nymax;
	unsigned char *cc;

	ifont = '0'-' ';

/*
	nsfont = fopen("NS128.font", "r");
	fscanf(nsfont,"%d %d",&nfont0,&nfont);
	fscanf(nsfont,"%d %d %d",&fwid,&fhei,&nbit);
	if (nbit!=8) printf("Not a 8 bit case!\n");
	font=(unsigned char *)malloc(sizeof(unsigned char *)*fwid*fhei/8);
	printf("%d %d\n",fwid,fhei);
	fscanf(nsfont,"%d %d %d %d %d",&nf,&nxmin,&nxmax,&nymin,&nymax);
	for (k=1;k<ifont;k++) {
		fscanf(nsfont,"%d %d %d %d %d",&nf,&nxmin,&nxmax,&nymin,&nymax);
		fgets(line,100,nsfont);
//		printf("%d: %d %d %d %d\n",nf,nxmin,nxmax,nymin,nymax);
//		for (j=nymin;j<=nymax;j++) {fgets(line,100,nsfont);printf("%d: %s",j,line);}
		for (j=nymin;j<=nymax;j++) fgets(line,100,nsfont);
	}
	fscanf(nsfont,"%d %d %d %d %d",&nf,&nxmin,&nxmax,&nymin,&nymax);
	for (j=nymin,cc=font;j<=nymax;j++) {
		for (i=nxmin;i<=nxmax;i++,cc++) {
			fscanf(nsfont,"%3x",&c1);		*cc=c1;
//			printf("%02x ",*cc);
		}
//		printf("\n");
	}
	fclose(nsfont);
*/

	gdframes_image_create(640, 480);
	gifbasecolor[0] = gdframes_color_allocate(0, 0, 0);
	gifbasecolor[1] = gdframes_color_allocate(  0,   0, 255);
	gifbasecolor[2] = gdframes_color_allocate(255,   0,   0);
	gifbasecolor[3] = gdframes_color_allocate(255,   0, 255);
	gifbasecolor[4] = gdframes_color_allocate(  0, 255,   0);
	gifbasecolor[5] = gdframes_color_allocate(  0, 255, 255);
	gifbasecolor[6] = gdframes_color_allocate(255, 127,   0);
	gifbasecolor[7] = gdframes_color_allocate(255, 255, 255);

	hls2rgb(60,0.88,1,&r1,&g1,&b1);
	gifbasecolor[8] = gdframes_color_allocate(r1/256,g1/256,b1/256);
	hls2rgb(0,0.5,1,&r2,&g2,&b2);
//	printf("%d %d %d : %d %d %d\n",r1,g1,b1,r2,g2,b2);
/*	for (i=0;i<maxlincol;i++) {
		dl=(i+1)/((double)maxlincol);
		r=r2*dl+r1*(1-dl);
		g=g2*dl+g1*(1-dl);
		b=b2*dl+b1*(1-dl);
		alinecol[i] = gdframes_color_allocate(r/256,g/256,b/256);
	}*/
//	Anti_Init ( );

	for (i=0;i<n;i++) {
//		xx=30+500*i/n;
//		x[i]=30+600*i/n+50*cos(pi*6*xx/600);
//		y[i]=50*sin(pi*6*xx/600);
		x[i]=dd*cos(pi*2*i/n);
		y[i]=dd*sin(pi*2*i/n);
	}

	gdframes_fill_rectangle(0,0,639,479,8);
	giflineset=4;
	gdframes_set_style(&giflineset, 1);
	for (i=0;i<n-1;i++) gdframes_line(100+x[i],50+y[i],100+x[i+1],50+y[i+1]);
//	gdframes_circle(250, 300, 50, 80, 4, 1);
/*	x1=100;	y1=50;		x2=600;		y2=150;
	gdframes_line(x1,y1+5,x2,y2+5);*/
//	anti_aliased_line(x1,y1,x2,y2);
/*
	x1=450;		y1=300;
	for (i=0;i<n3;i++) {
		th = pi*2/n3*i;
		anti_aliased_line(x1,y1,x1+dd*cos(th),y1+dd*sin(th));
	}
//	anti_aliased_line(x1,y1+15,x2,y2+15);
	for (i=0;i<n-1;i++) {
		anti_aliased_line(300+x[i],150+y[i],300+x[i+1],150+y[i+1]);
	}
	aaline_flush(2);
*/
//	gdframes_aaline(x1,y1+15,x2,y2+15,0);
	x1=100;		y1=100;
	for (i=0;i<n-1;i++) {
//	for (i=295;i<305;i++) {
		gdframes_aaline(x1+x[i],y1+y[i],x1+x[i+1],y1+y[i+1],0);
	}

	x1=200;	y1=300;
//	gdframes_circle(450, 300, x1, y1, 4, 0);
//	gdframes_aacircle(250,300,x1,y1,0);

	x1=460;	y1=160;	dd=100;	n=7;
	for (i=0;i<n;i++) {
		px[i]=x1+dd*cos(pi*2*i/n);
		py[i]=y1+dd*sin(pi*2*i/n);
	}
//	gdframes_aafillpolygon(px, py, n);
/*
	n2=63;
	x1=200;		y1=300;
	for (i=0;i<n3;i++) {
		th = pi*2/n3*i;
		gdframes_aaline(x1,y1,x1+dd*cos(th),y1+dd*sin(th),0);
	}
*/
//	gdframes_aaputfont(300,300,font,nxmin,nxmax,nymin,nymax);
	gdframes_aastring(300, 300, "ABCDE=0", 0);
	gdframes_aaspaceflush(2,8,-1,0);
	gdframes_string(0, 300, 350, "A", 2);

	x1=200;	y1=160;	dd=100;	n=7;
	for (i=0;i<n;i++) {
		xy[i].x=x1+dd*cos(pi*2*i/n);
		xy[i].y=y1+dd*sin(pi*2*i/n);
	}
	for (i=0;i<n-1;i++) {
		gdframes_line(xy[i].x,xy[i].y,xy[i+1].x,xy[i+1].y);
	}
	gdframes_line(xy[n-1].x,xy[n-1].y,xy[0].x,xy[0].y);
	gdframes_fill_polygon(xy, n, 4);
/*	for (i=0;i<n3;i++) {
		th = pi*2/n3*i;
		gdframes_line(300,100,(int)(300+dd*cos(th)),(int)(100+dd*sin(th)));
	}
*/
/*
	gdframes_line(200,330,400,330);
	gdframes_line(330,200,330,400);
	giflineset=2;
	gdframes_set_style(&giflineset, 1);
	gdframes_line(200,200,500,200);*/
/*	for (i=1;i<=maxlincol;i++) {
		gdframes_set_style(&i, 1);
		gdframes_line(400+i,30,400+i,130);
	}
*/
	imout = fopen("gdfrtest.gif", "wb");
	gdframes_image_gif(imout);
	fclose(imout);

}
