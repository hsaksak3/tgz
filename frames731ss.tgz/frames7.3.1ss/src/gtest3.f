*******************************************
*          F  R  A  M  E  S  V.6          *
*   TESTS OF SIMPLE 3D FRAME SUBROUTINES  *
*         PROGRAMMED BY T.TAGUCHI         *
*******************************************
      
      IMPLICIT REAL*8 (A-H,O-Z)

      CALL FR_GINIT
      CALL FR_GFILE('gtest3',0)

      CALL DRAWAVE
        CALL NEXT
      CALL GRWAVE
        CALL NEXT
      CALL PFWAVE
        CALL NEXT
      CALL TORUS

      CALL FR_GEND

      STOP
      END

      SUBROUTINE NEXT
      CALL FR_GPAUSE
      CALL FR_GCLEAR
      RETURN
      END


***********************
*   3D GRAPHIC TEST   *
***********************
      SUBROUTINE DRAWAVE
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (VEC=50.0D0)
      PARAMETER (IMAX=100,JMAX=50)

      XMIN = -15.D0
      XMAX = 15.D0
      YMIN = -10.D0
      YMAX = 10.D0
      ZMIN = -15.0D0
      ZMAX = 15.0D0

      DT = 0.5D0/VEC
      DX = (XMAX-XMIN)/IMAX
      DZ = (ZMAX-ZMIN)/JMAX

*      CALL FR_GCLEAR
*      CALL FR_PMVIEW(70,150,430,370,550,250)
      CALL FR_XYZNAME('X-AXIS','Z-AXIS','Y-AXIS')
      CALL FR_PMFRAME(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_HCLEAR(1)

      T = 0.D0
      DO J = 0, JMAX
         Z = DZ*J + ZMIN
         CALL FR_PMSET(Z)
         Y = FUNC(XMIN,Z,T)
         CALL FR_PMDRAW(XMIN,Y,6,-2)
         DO I = 1, IMAX
            X = DX*I + XMIN
            Y = FUNC(X,Z,T)
            CALL FR_PMDRAW(X,Y,6,-1)
         ENDDO
      ENDDO

      RETURN
      END

*-----------------------------------------*
*    TEST  PROGRAM  OF  3D  GRAPHICS      *
*-----------------------------------------*
      SUBROUTINE GRWAVE
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=100,JMAX=50)

      REAL*8 X(0:IMAX),Y(0:IMAX)

      XMIN = -15.D0
      XMAX =  15.D0
      YMIN = -10.D0
      YMAX =  10.D0
      ZMIN = -15.0D0
      ZMAX =  15.0D0

      DX = (XMAX-XMIN)/IMAX
      DZ = (ZMAX-ZMIN)/JMAX

      CALL FR_PMVIEW(50,180,400,390,500,180)
      CALL FR_XYZNAME('X-AXIS','Z-AXIS','Y-AXIS')
      CALL FR_PMFRAME(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_HCLEAR(1)

      X(0) = XMIN
      X(1) = XMAX
      DO J = 0, JMAX
         Z = DZ*J + ZMIN
         DO I = 0, IMAX
*            X(I) = DX*I+XMIN
*            Y(I) = FUNC(X(I),Z,0.D0)
            Y(I) = FUNC(DX*I+XMIN,Z,0.D0)
         ENDDO
*         CALL FR_PMGRAPH(X,Y,Z,IMAX+1,2,-1)
         CALL FR_PMGRAPH(X,Y,Z,IMAX+1,2,-101)
      ENDDO

      RETURN
      END

      SUBROUTINE PFWAVE
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=50,JMAX=50)

      REAL*8 T2(0:IMAX,0:JMAX)

      XMIN = -15.D0
      XMAX = 15.D0
      YMIN = -10.D0
      YMAX = 10.D0
      ZMIN = -15.0D0
      ZMAX = 15.0D0

      DX = (XMAX-XMIN)/IMAX
      DZ = (ZMAX-ZMIN)/JMAX
      CALL FR_PMVIEW(50,180,400,390,600,280)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
      CALL FR_PMFRAME(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)

      DO I = 0, IMAX
         X = DX*I + XMIN
         DO J = 0, JMAX
            Z = DZ*J + ZMIN
            T2(I,J) = FUNC(X,Z,0.D0)
         ENDDO
      ENDDO
      
      CALL FR_SET2DRGN(0,30,0,25)
      CALL FR_PROFILE(T2,IMAX+1,JMAX+1,5,1)

      RETURN
      END

      REAL*8 FUNCTION FUNC(X,Y,T)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (VEC=50.0D0)

      XX = X*X + Y*Y
      FUNC = 15.D0*COS(SQRT(XX)-VEC*T)*EXP0(-(0.01*XX+50*T*T))

      RETURN
      END

      REAL*8 FUNCTION EXP0(X)
      REAL*8 X

      EXP0 = 0.D0
      IF (ABS(X).LE.20.D0) EXP0 = EXP(X)

      RETURN
      END

*-------------------------*
*      TORUS DISPLAY      *
*-------------------------*
      SUBROUTINE TORUS
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=30,JMAX=31,PI=3.141592653589793D0)
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)

      DU = 2*PI/(IMAX-1)
      DV = 2*PI/(JMAX-1)

      DO J = 1, JMAX
         V = DV*J
         DO I = 1, IMAX
            U      = DU*I
            X(I,J) = (2+0.75*COS(V))*COS(U)
            Y(I,J) = (2+0.75*COS(V))*SIN(U)
            Z(I,J) = 0.75*SIN(V)
         ENDDO
      ENDDO

      CALL FR_SETAXIS(3)
      CALL FR_PMVIEW(60,130,460,390,580,180)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
      CALL FR_PMFRAME(-3.0D0,3.0D0,-1.0D0,2.0D0,-3.0D0,3.0D0,0)

      CALL FR_SURFACE(X,Y,Z,IMAX,JMAX,4,4)

      RETURN
      END
