/*********************************************************
 *                 F r a m e s  V.7.3                    *
 *                SURFACE Core Routine                   *
 *               Programed by T. Taguchi                 *
 *                 February 18, 2013                     *
 *********************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "frames.h"

#ifndef CompaqVisual
extern void surface3dmain(double *,double *,double *,double *,int *,int *
								,int *,int *,int *,int *,int *,int *,int *,int *,float *,float *,int *);
#endif

void mallocandsurfacecore(double *x,double *y,double *z,double *f,int *imax,int *jmax
							,int *nx1,int *nx2,int *ny1,int *ny2,int *ic,int *m1,int *ind,int *npr,int *ier)
{
	float *ws2,*ts;
	int *hs,nuv,i;
	static float *ws;
	static int nuvmax;

	*ier=0;
	nuv=(*nx2-*nx1+1)*(*ny2-*ny1+1);
/*	if (*ind>9) {		*/
	if (*ind<0) {
		if (*npr>0) {
			ws2=(float *)malloc(sizeof(float)*(nuvmax+nuv)*3);
			for (i=0;i<nuvmax*3;i++) ws2[i]=ws[i];
			nuvmax+=nuv;	free(ws);	ws=ws2;
		  }
		  else {
			ws=(float *)malloc(sizeof(float)*nuv*3);
			nuvmax=nuv;
		}
		if (ws==NULL) {
			*ier=2;
			return;
		}
	  }
	  else {
		if (*npr>0) {
			ws2=(float *)malloc(sizeof(float)*(nuvmax+nuv)*4);
			for (i=0;i<nuvmax*3;i++) ws2[i]=ws[i];
			nuvmax+=nuv;	free(ws);	ws=ws2;
		  }
		  else {
			ws=(float *)malloc(sizeof(float)*nuv*4);
			nuvmax=nuv;
		}
		ts=ws+nuvmax*3;
		if (*ic<0 || *ind==5 || *ind==6) {
			hs=(int *)malloc(sizeof(int)*nuvmax);
		  }
		  else if (*ind<5) {
			hs=(int *)malloc(sizeof(int)*nuvmax*4);
		  }
		  else {
		  	*ier=1;
			return;
		}
		if (ws==NULL || hs==NULL) {
			*ier=2;
			return;
		}
	}
	surface3dmain(x,y,z,f,imax,jmax,nx1,nx2,ny1,ny2,ic,m1,ind,npr,ws,ts,hs);
/*	if (*ind>9) return;		*/
	if (*ind<0) return;

	free(ws);	free(hs);
	*npr=0;
}
