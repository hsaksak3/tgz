/******************************************************
 *              F  r  a  m  e  s   V.7.2              *
 *         Postscript I/O Routine for Frames          *
 *              Programed by T. Taguchi               *
 *                  October, 05, 2006                 *
 ******************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/*#include <varargs.h>*/
#include <fcntl.h>
#include <signal.h>
/*
FILE *popen(const char *command, const char *type); 
int pclose(FILE *stream);
*/

#define NOT_USED_TPLOT
#include "frames.h"

/*#define US*/
#define DARKYELLOW

/*
#define	MAXLINE				20
#define	MAXSTROKE			30
*/
#define Nothing
#define	MAXLINE				10000
#define	MAXSTROKE			10000
#define	MAXCNLINK			10000
/*#define MAXGRAYNO			65536	*/
#define MAXGRAYNO			256
#define	GRAY256(X)			(MAXGRAYNO*(maxcolnum-(X))/maxcolnum)
#define	COLOR256(X)			(X)
#define MAX256COL			256
#define MAXPSLINE			8
#define MAXPSROW			8
#define COLORNUM(X)			((X)<1?2:(X))

#define PICDOT				1
#define PICLINE				2
#define PICLINECLOSE		3
#define PICLINEGRADFILL		4
#define PICPOLYGON			PICLINE
#define PICPOLYGONFILL		5
#define PICARROW			6
#define PICCIRCLE			7
#define PICCIRCLEFILL		8
#define PICCIRCLEGRADFILL	9
#define PICTEXT				10
#define PICTEXT10			11

#define MAXFONT				5
#define FCHR				0
#define FTAX				1
#define FNUM				2
#define FTEN				3
#define FPOW				4

typedef struct {
	int   n1,n2,mark;
} cnlink;

typedef struct {
	float x,y;
	int   l1,l2;
} cnnode;

extern int		PSPIPE;
extern char		psname[];
extern int		GWIDTH,GHEIGHT,IGXOFF,IGYOFF,PSWRITE;
extern float	PSYOFF;

static int 		linestroke,picture,iline,pageno,puton,psout,linespec,nfont;
static int		txangle,hchrmove,wchrmove;
static float	hchrx,hchry,wchrx,wchry;
static char 	str[256];
static int		psno=0,fpsmod=0,ncnline=0,ncnpoint=0,maxcnlines=0,maxcnpoints=0,mcncol;
static int		papersize,paperdir,graphno,lcolmode,vcolmode,ccolmode;
static int		plotlmax,plotrmax,wwidth,wheight,wxoff,wyoff,plotl,plotr;
static int		paperheight,paperwidth,lmargin,bmargin,wmargin,hmargin,setrgb=0,mkarray=0;
static int		wmargin1,hmargin1;
static int		tcolor,lcolor,mcolor,lnumber,lnmode,rgbcol[MAX256COL][3];
static char		*lncol[9]={"bdash","dash0","dash1","dash2"
							,"dash3","dash4","dash5","dash6","dash7"};
static char		*fontname[5]={"CHR","TAX","NUM","TEN","POW"};
static char		lnnum[11],outpsfilename[128];
static int		gray,grayno[11],maxcolnum,vpage[MAXPSLINE],hpage[MAXPSROW];
static float 	XX=-99999.9,YY=-99999.9;
static cnlink	*cnlines=NULL;
static cnnode	*cnpoints=NULL;

#ifdef PIPE
static FILE		*outpipe;
#endif

static void psputs(char *s)
{
#ifdef PIPE
	if (psout) fputs(s,outpipe);
#else
	write(1,s,strlen(s));
#endif
}

/*
static void psprintf(va_alist)
va_dcl
{
	char *form;
	va_list argptr;
	va_start(argptr);
	form=va_arg(argptr,char *);
	vsprintf(str,form,argptr);
	va_end(argptr);
	write(1,str,strlen(str));
}
*/

static void setlinestyle()
{
	int gray1;
	if (mcolor<0) {
		if (gray!=0) { psputs("G0\n");	gray=0; }
		if (lnumber!=lnnum[lcolor]) {
			lnumber=lnnum[lcolor];
			psputs(lncol[lnumber]); psputs("\n"); 
		}
	  }
	 else {
	  	gray1=GRAY256(mcolor);
		if (gray1!=gray) {
			/*psprintf("%d divsetgray\n",gray1);*/
			sprintf(str,"%d G\n",gray1);
			psputs(str);
			gray=gray1;
		}
		if (lnumber) { psputs(lncol[0]); psputs("\n"); lnumber=0; }
	}
}

static void setgrayscale()
{
	int gray1,lc;

	if (lcolmode<3) {
		if (mcolor<0) gray1=grayno[lcolor];
		  else 		  gray1=GRAY256(mcolor);
		if (gray1!=gray) {
			/*psprintf("%d divsetgray\n",gray1);*/
			sprintf(str,"%d G\n",gray1);
			psputs(str);
			gray=gray1;
		}
	  }
	  else {
		if (mcolor<0) gray1=grayno[lcolor];
		  else 	      gray1=-(1+GRAY256(mcolor));
		if (gray1!=gray) {
			if (mcolor<0) {
				lc=lcolor-1;
				if (lc==0) lc=7;
				  else if (lc==7) lc=0;
				  else if (lc<0)  lc=0;
				  else if (lc==9) lc=0;
				  else if (lc==10) lc=7;
				/*psprintf("%d %d %d setrgbcolor\n",(lc&2)>>1,(lc&4)>>2,lc&1);*/
#ifdef DARKYELLOW
				if (lc==6) 	sprintf(str,"%d %f %d B\n",1,0.5,0);
					else
#endif
						sprintf(str,"%d %d %d B\n",(lc&2)>>1,(lc&4)>>2,lc&1);
				psputs(str);
			  }
			  else {
			  	lc=mcolor;
				/*psprintf("%d %d %d divsetrgb\n",COLOR256(rgbcol[lc][0])
							,COLOR256(rgbcol[lc][1]),COLOR256(rgbcol[lc][2]));*/
				sprintf(str,"%d %d %d H\n",COLOR256(rgbcol[lc][0])
							,COLOR256(rgbcol[lc][1]),COLOR256(rgbcol[lc][2]));
				/*if (lc>127)fprintf(stderr,"%d %d %d %d divsetrgb\n",lc,COLOR256(rgbcol[lc][0])
							,COLOR256(rgbcol[lc][1]),COLOR256(rgbcol[lc][2]));*/
				psputs(str);
			}
			gray=gray1;
		}
	}
/*	printf("%d %d\n",gray1,mcolor);		*/
	if (lnumber) { psputs(lncol[0]); psputs("\n"); lnumber=0; }
}

static void clearlinegray()
{
	if (gray!=0) { psputs("0 setgray\n");	gray=0; }
	if (lnumber) { psputs(lncol[0]); psputs("\n"); lnumber=0; }
}

/*  Real number version  0<=fh<=360   0<=fl,fs<=1	*/
#define weps 		1.0e-3
#define rgbmax 		65535.999
static void hls2rgb(double fh,double fl,double fs,int *ir,int *ig,int *ib)
{
    double w1,w2,wh;

    if ( fl <= 0.5 ) w2 = fl*(1.0+fs);
                else w2 = fl+fs-fl*fs;
    w1 = 2.0*fl-w2;

    if ( fs <= weps ) {
         *ir = fl*rgbmax;   *ig = fl*rgbmax;    *ib = fl*rgbmax;
      }
      else {
         wh = fh+120.0;
         if( wh > 360.0 ) wh-=360.0;
         if( wh <   0.0 ) wh+=360.0;

         *ir =rgbmax*(  wh<=60.0?  w1+(w2-w1)*wh/60.0:
                      ( wh<=180.0? w2:
                       (wh<=240.0? w1+(w2-w1)*(240.0-wh)/60.0: w1 )));

         *ig =rgbmax*(  fh<=60.0?  w1+(w2-w1)*fh/60.0:
                      ( fh<=180.0? w2:
                       (fh<=240.0? w1+(w2-w1)*(240.0-fh)/60.0: w1 )));

         wh = fh-120.0;
         if( wh > 360.0 ) wh-=360.0;
         if( wh <   0.0 ) wh+=360.0;

         *ib =rgbmax*(  wh<=60.0?  w1+(w2-w1)*wh/60.0:
                      ( wh<=180.0? w2:
                       (wh<=240.0? w1+(w2-w1)*(240.0-wh)/60.0: w1 )));
     }
}

void postscriptsetrgb(double *sh,double *sl,double *ss,int *div,int *mode,int *cdef)
{
	int i,j,dpm,cnm,nc,mc,kkk,k,ii,jj,kk;
	double sh0[2],sl0[2],ss0[2],hue,lig,sat;

	if (*mode<=0 || *div<=0) {
		dpm=1;
		if (*mode<0 || *div<=0) i=*cdef;
		  else					i=*div;
		sh0[0]=300;       sh0[1]=0;
		sl0[0]=sl0[1]=0.5;
		ss0[0]=ss0[1]=1;
		sh=sh0;		ss=ss0;		sl=sl0;
		maxcolnum=i;	div=&maxcolnum;
	  }
	  else {
		dpm=*mode;
		if (dpm==1) maxcolnum=*div;
		  else {
/*	color setting point		*/
			for (i=maxcolnum=0;i<dpm;i++) {
				mc=div[i]-1;
				if (mc<0) mc=1;
				maxcolnum+=mc;
			}
			maxcolnum++;
		}
	}

	if (maxcolnum>MAX256COL) cnm=MAX256COL;
		else cnm=maxcolnum;

	mc=div[0]-1;
	if (mc<1) mc=1;
	for (i=j=nc=0,kkk=-1;i<maxcolnum;i++,j++) {
		k = i*cnm/maxcolnum;
		while (j>=COLORNUM(div[nc])) {
			nc++;	j=1;
			mc=div[nc]-1;
			if (mc<0) mc=1;
		}
		if (k!=kkk) {
			hue = sh[nc]+j*(sh[nc+1]-sh[nc])/mc;
			lig = sl[nc]+j*(sl[nc+1]-sl[nc])/mc;
			sat = ss[nc]+j*(ss[nc+1]-ss[nc])/mc;
			hls2rgb(hue,lig,sat,&ii,&jj,&kk);
			kkk=k;
		}
		rgbcol[i][0]=ii;		rgbcol[i][1]=jj;		rgbcol[i][2]=kk;
	}

	setrgb=1;
/*
	sprintf(str,"/maxcolnum %d def\n",maxcolnum);
	psputs(str);
*/
	if (mkarray==0) {
		psputs("/CAY 256 array def\n");
	}
	for (i=0;i<maxcolnum;i++) {
		sprintf(str,"CAY %d %d D6 %d D6 %d D6 AA\n",i,rgbcol[i][0],rgbcol[i][1],rgbcol[i][2]);
		psputs(str);
	}
}

void postscriptinit(int page,int pdir,int psize,int lmax,int rmax,int lmarg,int bmarg,int fmode)
{
	int i;
	double wx,wy,rx,ry;
	
	papersize=psize;		paperdir=pdir;
	plotlmax=lmax;			plotrmax=rmax;
	wwidth=GWIDTH;			wheight=GHEIGHT;
	wxoff=IGXOFF;			wyoff=IGYOFF;
	lmargin=lmarg;			bmargin=bmarg;

	txangle=hchrmove=wchrmove=0;
	tcolor=7;		lcolor=0;		mcolor=-1;	lnumber=0;	lnmode=-1;
	plotl=plotr=0;
	graphno=lmax*rmax;
	psno++;

#ifdef PIPE
	if (PSPIPE==0) {
		if (fmode==0) {
			sprintf(outpsfilename,"%s.ps",psname);
		  }
		  else if (fmode==3) {
			sprintf(outpsfilename,"%s%.4d.ps",psname,page);
		  }
		  else {
			sprintf(outpsfilename,"%s_%.4d.ps",psname,psno);
		}
		fpsmod=fmode;
	 	if ((outpipe=fopen(outpsfilename,"w"))==NULL) {
			fprintf(stderr,"PS output file %s open error !!\n",outpsfilename);
			psout=0;
		  }
		  else psout=1;
	  }
	  else {
	 	if ((outpipe=popen(psname,"w"))==NULL) {
			fprintf(stderr,"PS output pipe \"%s\" open error !!\n",psname);
			psout=0;
		  }
		  else psout=1;
		fpsmod=fmode;
	}
#endif

	psputs("%!PS-Adobe-2.0\n");
	psputs("%%Title: PS output from Frames\n");
	psputs("%%Program: Written by Toshihiro Taguchi, Setsunan University\n");

	/*	29 times cm scale	*/
	if (papersize==1) {
		paperheight=610;		paperwidth=855;		wmargin=200;	hmargin=100;
		if (lmargin<0) lmargin=100;
		if (bmargin<0) bmargin=hmargin/2;
		wmargin1=hmargin1=0;
/*
		hpage[0]=lmargin;
		vpage[0]=30+bmargin;
*/
	  }
	  else if (papersize==2) {
		paperheight=810;		paperwidth=625;		wmargin=100;		hmargin=0;
		if (lmargin<0) lmargin=60;
		if (bmargin<0) bmargin=0;
		wmargin1=hmargin1=0;
/*
		hpage[0]=lmargin;
		vpage[0]=395+bmargin;
		vpage[1]=30+bmargin;
*/	  }
	  else {
		paperheight=855;		paperwidth=610;		wmargin=100;		hmargin=110;
		if (lmargin<0) lmargin=55;
		if (bmargin<0) bmargin=hmargin/2;
		wmargin1=hmargin1=0;
/*
		hpage[0]=lmargin;
		vpage[0]=395+bmargin;
		vpage[1]=30+bmargin;
*/
  }

	sprintf(str,"%%%%BoundingBox: 0 0 %d %d\n",paperwidth,paperheight);
	psputs(str);
	
	if (paperdir) {
		i=paperheight;		paperheight=paperwidth;		paperwidth=i;
	}

	rx=paperwidth-wmargin-wmargin1*rmax;
	ry=paperheight-hmargin-hmargin1*lmax;
	rx/=(wwidth*rmax);		ry/=(wheight*lmax);
	if (rx>ry) {
		wmargin1=wmargin1+(rx-ry)*wwidth/2;
		rx=ry;
	  }
	  else hmargin1=hmargin1+(ry-rx)*wheight/2;

	wx=rx*wwidth;			wy=rx*wheight;
	
	for (i=0;i<plotlmax;i++) vpage[i]=hmargin1+bmargin+(hmargin1+wy)*(plotlmax-i-1);
	for (i=0;i<plotrmax;i++) hpage[i]=wmargin1+lmargin+(wmargin1+wx)*i;	

	sprintf(str,"/paperheight %d def /paperwidth %d def\n",paperheight,paperwidth);		psputs(str);
	sprintf(str,"/leftmargin %d def /rightmargin %d def /botmargin %d def\n",lmargin,wmargin-lmargin,bmargin);	psputs(str);
	sprintf(str,"/scrwidth %d def /scrheight %d def\n",wwidth,wheight);				psputs(str);

	if (paperdir) {
		psputs("90 rotate 0 paperheight neg translate\n");
	}

	sprintf(str,"/pagescale { %.4f scrwidth div dup scale } def\n",wx);		psputs(str);

	psputs("% \n% Character Sets\n% \n");
	psputs("% Characters for text\n");
	psputs("/chrheight 14 def  /FCHR /Courier findfont chrheight scalefont def\n");
	psputs("% Characters for text with axis\n");
	psputs("/taxheight 14 def  /FTAX /Courier findfont taxheight scalefont def\n");
	psputs("% Characters for numbers with axis\n");
	psputs("/numheight 14 def  /FNUM /Courier findfont numheight scalefont def\n");
	psputs("% Characters for 10 with log axis\n");
	psputs("/tenheight 14 def  /FTEN /Courier findfont tenheight scalefont def\n");
	psputs("% Characters for powers with log axis\n");
	psputs("/powheight 10 def  /FPOW /Courier findfont powheight scalefont def\n");

	psputs("% \n% Dot and Line Styles\n% \n");
	psputs("/dotsize 1.0 def        % Size of dots\n");
	psputs("/zeroline 0 def         % Zero width lines\n");
	psputs("/thickline 0.5 def      % Thickness of lines\n");
	psputs("/thicksysline 0.7 def   % Thickness of axis lines\n");
	psputs("/thickarrow 0.2 def     % Thickness of arrows\n");
	psputs("/thickbline 0.8 def     % Thickness of 256 color lines\n");
	psputs("% \n");

/*	psputs("/movedown { 0 nheight neg rmoveto } def\n");
	psputs("/movehalfdown { 0 nheight 2 div neg rmoveto } def\n");		*/
	psputs("/ellipse { gsave translate 2 copy add 2 div dup /ellipscale exch def div exch ellipscale div exch ");
	psputs("scale ellipscale 0 moveto 0 0 ellipscale 0 360 arc } def\n");
	psputs("/ellipseend { stroke grestore } def\n");

	psputs("/A { 0 360 arc } def\n");
	psputs("/AA { 3 array astore put } def\n");
	psputs("/AF { 0 360 arc fill } def\n");
	psputs("/AH { get aload pop setrgbcolor } def\n");
	psputs("/AS { thickarrow setlinewidth } def\n");
	psputs("/B { setrgbcolor } def\n");
	psputs("/C { closepath } def\n");
	psputs("/CW { dup stringwidth pop neg 2 div 0 rmoveto show } def\n");
	psputs("/D6 { 65536 div } def\n");
	psputs("/F { fill } def\n");
	psputs("/DS { dotsize setlinewidth } def\n");
/*	psputs("/DS2 { 1.01 setlinewidth 2 setlinecap } def\n");			*/
	psputs("/DS2 { 2 setlinecap } def\n");
	psputs("/E { ellipse ellipseend } def\n");
	psputs("/EF { ellipse fill ellipseend } def\n");
	psputs("/F3 { moveto lineto lineto closepath fill } def\n");
	psputs("/F4 { moveto lineto lineto lineto closepath fill } def\n");
	psputs("/F5 { moveto lineto lineto lineto lineto closepath fill } def\n");
	sprintf(str,"/G { %d div setgray } def\n",MAXGRAYNO);		psputs(str);
	psputs("/G0 { 0 setgray } def\n");
	psputs("/H  { 65536 div 3 1 roll 65536 div 3 1 roll 65536 div 3 1 roll setrgbcolor } def\n");
	psputs("/L { lineto } def\n");
	psputs("/LC { lineto closepath } def\n");
	psputs("/LF { lineto fill } def\n");
	psputs("/M { moveto } def\n");
	psputs("/ML { moveto lineto } def\n");
	psputs("/MV { moveto curveto } def\n");
	psputs("/MH { exch HTEXT mul 2 div exch HTEXT mul 2 div neg rmoveto } def\n");
	psputs("/MW { exch WTEXT mul 2 div exch WTEXT mul 2 div neg rmoveto } def\n");
	psputs("/P { moveto 0 0 rlineto stroke } def\n");
	psputs("/PS { CAY exch get aload pop setrgbcolor moveto 0.01 0 rlineto stroke } def\n");
	psputs("/R { rlineto } def\n");
	psputs("/RC { rlineto closepath } def\n");
	psputs("/RF { rlineto fill } def\n");
	psputs("/RW { dup stringwidth pop neg 0 rmoveto show } def\n");
	psputs("/RWM { dup dup stringwidth pop neg 0 rmoveto show stringwidth pop neg 0 rmoveto } def\n");
	psputs("/S { stroke } def\n");
	psputs("/SD { 0 exch HTEXT mul 2 div neg rmoveto } def\n");
	psputs("/SR { WTEXT mul 2 div 0 rmoveto } def\n");
	psputs("/SS { exch dup stringwidth pop 3 -1 roll mul 2 div 0 rmoveto show } def\n");
	psputs("/S1 { 1 setlinecap } def\n");
	psputs("/S2 { 2 setlinecap } def\n");
	psputs("/T { 2 copy moveto 4 1 roll 2 copy exch lineto pop 2 copy lineto pop exch lineto closepath fill } def\n");
	psputs("/T3 { moveto lineto lineto closepath } def\n");
	psputs("/T4 { moveto lineto lineto lineto closepath } def\n");
	psputs("/TS { TLINE setlinewidth } def\n");
	psputs("/V { curveto } def\n");
	psputs("/W { show } def\n");

	psputs("/bdash { [] 0 setdash } def\n");
	psputs("/dash0 { [0 10000] 0 setdash } def\n");
	psputs("/dash1 { [0.7 1.5] 0 setdash } def\n");
	psputs("/dash2 { [2] 0 setdash } def\n");
	psputs("/dash3 { [4] 0 setdash } def\n");
	psputs("/dash4 { [10 4] 0 setdash } def\n");
	psputs("/dash5 { [2 2 15 2] 0 setdash } def\n");
	psputs("/dash6 { [2 2 2 2 15 2] 0 setdash } def\n");
	psputs("/dash7 { [] 0 setdash } def\n");

	psputs("FCHR setfont\n");
	psputs("gsave newpath 0 0 moveto (Z) true charpath\n");
	psputs("flattenpath pathbbox /HCHR exch def pop pop pop grestore\n");
	psputs("(Z) stringwidth pop /WCHR exch def\n");
	psputs("FTAX setfont\n");
	psputs("gsave newpath 0 0 moveto (Z) true charpath\n");
	psputs("flattenpath pathbbox /HTAX exch def pop pop pop grestore\n");
	psputs("(Z) stringwidth pop /WTAX exch def\n");
	psputs("FNUM setfont\n");
	psputs("gsave newpath 0 0 moveto (1) true charpath\n");
	psputs("flattenpath pathbbox /HNUM exch def pop pop pop grestore\n");
	psputs("(1) stringwidth pop /WNUM exch def\n");
	psputs("FTEN setfont\n");
	psputs("gsave newpath 0 0 moveto (1) true charpath\n");
	psputs("flattenpath pathbbox /HTEN exch def pop pop pop grestore\n");
	psputs("(1) stringwidth pop /WTEN exch def\n");
	psputs("FPOW setfont\n");
	psputs("gsave newpath 0 0 moveto (1) true charpath\n");
	psputs("flattenpath pathbbox /HPOW exch def pop pop pop grestore\n");
	psputs("(1) stringwidth pop /WPOW exch def\n");

	psputs("FCHR setfont\n");
	psputs("/HTEXT HCHR def /WTEXT WCHR def\n");
	psputs("/cleartpos { /tposx 0 def /tposy 0 def /tposx1 0 def /tposx2 0 def /tposy1 0 def /tposy2 0 def /twidth 0 def} def\n");
	psputs("/cleartpos\n");

	psputs("/TLINE thicksysline def\n");

	psputs("3 setmiterlimit\n");
	psputs("1 setlinecap\n");
	psputs("0 setgray\n");
	psputs("gsave\n");
	
	picture=0;		gray=0;				linespec=0;			nfont=0;
	linestroke=0; 	iline=MAXLINE;
	pageno=0;		puton=0;

}

void postscriptstyle(int colormode,char *line_style,char *gray_style,int vectormode,int charmode)
{
	int i,ii,jj;

	lcolmode=colormode;
	vcolmode=vectormode;
	ccolmode=charmode;

	if (lcolmode==0) {
		for (i=0;i<11;i++) lnnum[i]=0;
		for (i=0;i<11;i++) grayno[i]=0;
	  }
	  else {
		lnnum[0]=0;		grayno[0]=0;
		for (i=0;i<8;i++) lnnum[i+1]=line_style[i]+1;
		for (i=0;i<8;i++) grayno[i+1]=(7-gray_style[i])*MAXGRAYNO/7;
		lnnum[9]=lnnum[8];		lnnum[10]=lnnum[0];
		grayno[9]=grayno[8];	grayno[10]=grayno[0];
	}

/*		if (lcolmode==3 && setrgb==0) {	*/
	if (setrgb==0) {
		ii=0;	jj=128;
		postscriptsetrgb(NULL,NULL,NULL,&ii,&ii,&jj);
	}
}

void postscriptend(void)
{
	if (linestroke) psputs("S\n");
	psputs("showpage\n");
#ifdef PIPE
	if (psout) {
		if (PSPIPE==0) fclose(outpipe);
	  		else pclose(outpipe);
	}
	PSWRITE=1;
#endif
}

void postscriptpage()
{
	if (linestroke) {
		psputs("S\n");
		linestroke=0;		iline=MAXLINE;
	}
	picture=0;		linespec=0;

	if ((pageno%graphno)==0) {
		if (pageno) psputs("showpage grestore gsave\n");
		plotl=plotr=0;
	  }
	  else psputs("grestore gsave\n");

	sprintf(str,"%d %d translate pagescale\n",hpage[plotr],vpage[plotl]);
	psputs(str);
	sprintf(str,"%d %d translate\n",-wxoff,wyoff);
	psputs(str);

}

void postscriptnext(void)
{
	pageno++;
	puton=0;
	if (fpsmod==2) {
		postscriptend();
		return;
	}

	plotr=(plotr+1)%plotrmax;
	if (plotr==0) plotl=(plotl+1)%plotlmax;
	if (plotr==0 && plotl==0 && fpsmod==1) {
		postscriptend();
		return;
	}
}

void postscriptcolor(int *n,int *pal)
{
/*		n=0... both,  n=1... text,  n=2... lines,  n=256... 256 color	*/
	if (*n!=256) {
/*
		if ((*n)!=2 && (*pal)!=tcolor) {
			tcolor=*pal;
/ *			picture=0;		* /
		}
		if ((*n)!=1) {
*/
			if (*pal>=0) {
				if (lcolor!=(*pal)+1 && linestroke) picture=0;
				lcolor=(*pal)+1;
				if (lcolor>8) lcolor++;
					else if (lcolor>10) lcolor=8;
				if (lnmode<=0) {
					psputs("/TLINE thickline def\n");
					lnmode=1;		linespec=0;
				}
			  }
			  else {
				if (linestroke) picture=0;
				lcolor=0;
				if (lnmode>=0) {
					psputs("/TLINE thicksysline def\n");
					lnmode=-1;		linespec=0;
				}
			}
/*
		}
*/
		mcolor=-1;
	  }
	  else {
		if (mcolor!=*pal && linestroke) picture=0;
	 	mcolor=*pal;
	 	if (mcolor>=maxcolnum) mcolor=maxcolnum-1;
	 	if (lnmode) {
			psputs("/TLINE thickbline def\n");
			lnmode=0;		linespec=0;
		}
	}
}

static void	checkstroke(int pic)
{
	if (puton==0) {
		postscriptpage();
		puton=1;
	}
	if (linestroke>0 && picture!=pic) {
		psputs("S\n");		linestroke=0;
	}
}

void postscriptdot(float *x,float *y)
{
	checkstroke(PICDOT);
	if (linespec!=PICDOT) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
		psputs("DS\n");		linespec=PICDOT;
	}

	setgrayscale();

	/*psprintf("%.2f %.2f putdot\n",*x,*y);*/
	sprintf(str,"%.2f %.2f P\n",*x,PSYOFF-(*y));
	psputs(str);
	linestroke++;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		linestroke=0;
	}
	iline=MAXLINE;		picture=PICDOT;
}

void postscriptline(float *x1,float *y1,float *x2,float *y2,int *dc)
{
	float yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2);

	checkstroke(PICLINE);
	if (linespec!=PICLINE) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
		psputs("TS\n");		linespec=PICLINE;
	}

	if (lcolmode==2 && *dc<2) setlinestyle();
		else   setgrayscale();

	if (*dc==0) {
		if (*x1==XX && yy1==YY && iline<MAXLINE) {
			/*psprintf("%.2f %.2f lineto\n",*x2,yy2);*/
			sprintf(str,"%.2f %.2f L\n",*x2,yy2);
			psputs(str);
			XX=*x2;		YY=yy2;
			iline++;	linestroke++;
		  }
		  else {
			/*psprintf("%.2f %.2f moveto %.2f %.2f lineto\n",*x1,yy1,*x2,yy2);*/
			sprintf(str,"%.2f %.2f %.2f %.2f ML\n",*x2,yy2,*x1,yy1);
			psputs(str);
			XX=*x2;		YY=yy2;
			iline=1;	linestroke++;
		}
		picture=PICLINE;
	  }
	  else {
		/*psprintf("%.2f %.2f moveto %.2f %.2f lineto\n",*x1,yy1,*x2,yy1);*/
		sprintf(str,"%.2f %.2f %.2f %.2f ML\n",*x2,yy1,*x1,yy1);
		psputs(str);
		/*psprintf("%.2f %.2f lineto %.2f %.2f lineto closepath",*x2,yy2,*x1,yy2);*/
		if (*dc==2) sprintf(str,"%.2f %.2f L %.2f %.2f LF\n",*x2,yy2,*x1,yy2);
			else	sprintf(str,"%.2f %.2f L %.2f %.2f LC S\n",*x2,yy2,*x1,yy2);
		psputs(str);
		XX=-99999.9;		YY=-99999.9;
		iline=MAXLINE;		linestroke=0;
		picture=PICLINECLOSE;
	}

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}
}

static void cnline_data_store(float x1,float y1,float x2,float y2)
{
	int i,mc;
	cnlink *cn;
	cnnode *cd;

	if (cnlines==NULL) {
		maxcnlines=MAXCNLINK;
		maxcnpoints=MAXCNLINK*2;
		cnlines=(cnlink *)malloc(sizeof(cnlink)*maxcnlines);
		cnpoints=(cnnode *)malloc(sizeof(cnnode)*maxcnpoints);
	  }
	  else if (ncnline>=maxcnlines) {
		maxcnlines+=MAXCNLINK;
		maxcnpoints+=MAXCNLINK*2;
		cn=(cnlink *)malloc(sizeof(cnlink)*maxcnlines);
		cd=(cnnode *)malloc(sizeof(cnnode)*maxcnpoints);
		for (i=0;i<ncnline;i++) cn[i]=cnlines[i];
		for (i=0;i<ncnpoint;i++) cd[i]=cnpoints[i];
		free(cnlines);
		free(cnpoints);
		cnlines=cn;
		cnpoints=cd;
	}
	if (mcolor<0) mc=-1;
		else 	  mc=-mcolor;
	mcncol=mcolor;
	cnlines[ncnline].n1=ncnpoint;
	cnlines[ncnline].n2=ncnpoint+1;
	cnlines[ncnline].mark=mc;
	cnpoints[ncnpoint].x=x1;
	cnpoints[ncnpoint].y=y1;
	cnpoints[ncnpoint].l1=ncnline;
	cnpoints[ncnpoint].l2=-(ncnpoint+1);
	ncnpoint++;
	cnpoints[ncnpoint].x=x2;
	cnpoints[ncnpoint].y=y2;
	cnpoints[ncnpoint].l1=ncnline;
	cnpoints[ncnpoint].l2=-(ncnpoint+1);
	ncnpoint++;
	ncnline++;
}

static int sort_cmp(cnnode *a, cnnode *b)
{
	if ((a->x) < (b->x)) return -1;
	if ((a->x) > (b->x)) return  1;
	if ((a->y) < (b->y)) return -1;
	if ((a->y) > (b->y)) return  1;

	return 0;
}

static void cnline_stroke()
{
	int i,*node,n1,n2,l1,l2,l0;
	float x1,y1,x2,y2;
	qsort(cnpoints, ncnpoint, sizeof(cnnode), (int (*)(const void *, const void *)) sort_cmp);
	node=(int *)malloc(sizeof(int)*maxcnpoints);
	for (i=0;i<ncnpoint;i++) {
		node[-(cnpoints[i].l2)-1]=i;
//		cnpoints[i].l2=-1;
//		printf("%f %f %d %d\n",cnpoints[i].x,cnpoints[i].y,cnpoints[i].l1,cnpoints[i].l2);
	}
	for (i=1;i<ncnpoint;i++) {
		if (fabs(cnpoints[i-1].x-cnpoints[i].x)<0.0001 && fabs(cnpoints[i-1].y-cnpoints[i].y)<0.0001) {
			if (cnlines[cnpoints[i].l1].n1 == -(cnpoints[i].l2)-1) {
				cnlines[cnpoints[i].l1].n1=-(cnpoints[i-1].l2)-1;
			  }
			  else {
				cnlines[cnpoints[i].l1].n2=-(cnpoints[i-1].l2)-1;
			}
			cnpoints[i-1].l2=cnpoints[i].l1;
			i++;
		}
	}

	if (linestroke>0) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}

	if (lcolmode==2) setlinestyle();
		else   setgrayscale();

	for (i=0;i<ncnline;i++) {
		if (cnlines[i].mark > 0) continue;
		if (mcncol>=0) {
			n1=256;		mcolor=-cnlines[i].mark;
			postscriptcolor(&n1,&mcolor);
		}
		if (lcolmode==2) setlinestyle();
			else   setgrayscale();
		n2=node[cnlines[i].n1];
		l2=l0=i;
		while (1) {
			l1=cnpoints[n2].l1;
			if (l2==l1) l1=cnpoints[n2].l2;
			if (l1<0 || l1==l0) break;
			n1=node[cnlines[l1].n2];
			if (n1==n2) n1=node[cnlines[l1].n1];
			l2=l1;		n2=n1;
		}
		n1=node[cnlines[l2].n1];
		if (n2==n1) n2=node[cnlines[l2].n2];
		  else	{	n2=n1;		n1=node[cnlines[l2].n2];	}
		x1=cnpoints[n1].x;			y1=cnpoints[n1].y;
		x2=cnpoints[n2].x;			y2=cnpoints[n2].y;
//		printf("%f %f %d %d %d\n",x1,y1,n1,n2,l2);
		sprintf(str,"%.2f %.2f %.2f %.2f ML\n",x1,y1,x2,y2);
		psputs(str);
		linestroke++;		cnlines[l2].mark=1;
		while (1) {
			l1=cnpoints[n2].l1;
			if (l2==l1) l1=cnpoints[n2].l2;
			if (l1<0 || cnlines[l1].mark > 0) break;
			n1=node[cnlines[l1].n2];
			if (n1==n2) n1=node[cnlines[l1].n1];
			x1=cnpoints[n1].x;			y1=cnpoints[n1].y;
			sprintf(str,"%.2f %.2f L\n",x1,y1);
			psputs(str);
			linestroke++;		cnlines[l1].mark=1;		l2=l1;		n2=n1;
		}
		psputs("S\n");
		linestroke=0;
	}

	picture=PICLINE;		iline=MAXLINE;	

	free(cnlines);		free(cnpoints);		free(node);
	cnlines=NULL;		ncnline=0;
	cnpoints=NULL;		ncnpoint=0;
}

void postscriptcnline(float *x1,float *y1,float *x2,float *y2,int *dc)
{
	float yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2);

	if (*dc==0) cnline_data_store(*x1,yy1,*x2,yy2);
	 else cnline_stroke();
}

void postscriptgradrectangle(float *x1,float *y1,float *x2,float *y2,float *cnc)
{
	float a,b,c,d1,d2;
	float xx1=*x1, xx2=*x2, yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2),ff,dx=1,dy=1,dx1,dy1,x,y;
	int i,j,nx,ny,cn;

	checkstroke(PICLINEGRADFILL);
	if (linespec!=PICLINEGRADFILL) {
		psputs("DS2\n");		linespec=PICLINEGRADFILL;
	}

	setgrayscale();

	if (xx1>xx2) {
		ff=xx2;		xx2=xx1;		xx1=ff;
		ff=cnc[0];	cnc[0]=cnc[2];	cnc[2]=ff;
		ff=cnc[1];	cnc[1]=cnc[3];	cnc[3]=ff;
	}
	if (yy1>yy2) {
		ff=yy2;		yy2=yy1;		yy1=ff;
		ff=cnc[0];	cnc[0]=cnc[1];	cnc[1]=ff;
		ff=cnc[2];	cnc[2]=cnc[3];	cnc[3]=ff;
	}

	a=b=c=0;
	if (xx1!=xx2) {
	  	b=(cnc[2]-cnc[0])/(xx2-xx1);
		if (yy1!=yy2) {
	  		c=(cnc[1]-cnc[0])/(yy2-yy1);
			a=(cnc[3]+cnc[0]-cnc[2]-cnc[1])/((xx2-xx1)*(yy2-yy1));
		}
	  }
	  else if (yy1!=yy2) {
		c=(cnc[1]-cnc[0])/(yy2-yy1);
	}

	nx=(xx2-xx1)/dx+0.99;	ny=(yy2-yy1)/dy+0.99;
	if (nx<1) nx=1;
	if (ny<1) ny=1;
	dx=xx2/nx;		dy=yy2/ny;
	dx1=xx1/nx;		dy1=yy1/ny;

	for (i=0;i<=nx;i++) {
		x=dx1*i+dx*(nx-i);
		sprintf(str,"%.2f \n",x);
		psputs(str);
	}
	for (j=0;j<=ny;j++) {
		if (j<ny) {
			sprintf(str,"%d copy\n",nx+1);
			psputs(str);
		}
		y=dy1*(ny-j)+dy*j;
		d1=a*(y-yy1)+b;		d2=c*(y-yy1)+cnc[0];
		for (i=0;i<=nx;i++) {
			x=dx1*(nx-i)+dx*i;
			cn=d1*(x-xx1)+d2;
			if (cn<0) cn=0;
			if (cn>=maxcolnum) cn=maxcolnum-1;
			sprintf(str,"%.2f %d PS\n",y,cn);
			psputs(str);
			linestroke++;
		}
	}

	picture=PICLINEGRADFILL;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}
/*	psputs("1 setlinecap\n");			*/
}

/*
void postscriptgradrectangle(float *x1,float *y1,float *x2,float *y2,float *cnc)
{
	float xx1=*x1, xx2=*x2, yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2);
	int i,icn[4];

	checkstroke(PICLINE);
	if (linespec!=PICLINE) {
		psputs("TS\n");		linespec=PICLINE;
	}

	setgrayscale();

	for (i=0;i<4;i++) {
		icn[i]=cnc[i];
		if (icn[i]<0) icn[i]=0;
		if (icn[i]>=maxcolnum) icn[i]=maxcolnum-1;
		printf("%d %d\n",i,icn[i]);
		printf("  %d %d %d\n",rgbcol[icn[0]][0],rgbcol[icn[0]][1],rgbcol[icn[0]][2]);
	}
	sprintf(str,"gsave %.2f %.2f %.2f %.2f ML\n",xx2,yy1,xx1,yy1);
	psputs(str);
	sprintf(str,"%.2f %.2f L %.2f %.2f LC clip\n",xx2,yy2,xx1,yy2);
	psputs(str);
	psputs("<< /ShadingType 1 /ColorSpace /DeviceRGB\n");
	sprintf(str,"/Domain [%.2f %.2f %.2f %.2f]\n",xx1,xx2,yy1,yy2);
	psputs(str);
	psputs("/Function << /FunctionType 0 /Order 1\n");
	sprintf(str,"/Domain [%.2f %.2f %.2f %.2f]\n",xx1,xx2,yy1,yy2);
	psputs(str);
	psputs("/Range [0 1 0 1 0 1] /Decode [0 1 0 1 0 1] /DataSource < \n");
	sprintf(str,"%04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X %04X\n",
			COLOR256(rgbcol[icn[0]][0]),COLOR256(rgbcol[icn[0]][1]),COLOR256(rgbcol[icn[0]][2]),
			COLOR256(rgbcol[icn[2]][0]),COLOR256(rgbcol[icn[2]][1]),COLOR256(rgbcol[icn[2]][2]),
			COLOR256(rgbcol[icn[1]][0]),COLOR256(rgbcol[icn[1]][1]),COLOR256(rgbcol[icn[1]][2]),
			COLOR256(rgbcol[icn[3]][0]),COLOR256(rgbcol[icn[3]][1]),COLOR256(rgbcol[icn[3]][2]));
	psputs(str);
	psputs("> /BitsPerSample 16 /Size [2 2] >> >> shfill grestore\n");

	XX=-99999.9;		YY=-99999.9;
	iline=MAXLINE;		linestroke=0;
	picture=PICLINEGRADFILL;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}
}
*/

void postscriptspline(float *x1,float *dx1,float *y1,float *dy1,
						float *x2,float *dx2,float *y2,float *dy2)
{
	float bx1,bx2,by1,by2;
	float yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2),dyy1=-(*dy1),dyy2=-(*dy2);

	checkstroke(PICLINE);
	if (linespec!=PICLINE) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
		psputs("TS\n");		linespec=PICLINE;
	}

	if (lcolmode==2) setlinestyle();
		else   setgrayscale();

	bx1=((*dx1)+3*(*x1))/3;
	bx2=(3*(*x2)-(*dx2))/3; 
	by1=((dyy1)+3*(yy1))/3;
	by2=(3*(yy2)-(dyy2))/3; 
	if (*x1==XX && yy1==YY && iline<MAXLINE) {
		/*psprintf("%.2f %.2f %.2f %.2f %.2f %.2f curveto\n",bx1,by1,bx2,by2,*x2,yy2);*/
		sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f V\n",bx1,by1,bx2,by2,*x2,yy2);
		psputs(str);
		XX=*x2;		YY=yy2;
		iline++;	linestroke++;
	  }
	  else {
		/*psprintf("%.2f %.2f moveto %.2f %.2f %.2f %.2f %.2f %.2f curveto\n",*x1,yy1,bx1,by1,bx2,by2,*x2,yy2);*/
		/*psprintf("%.2f %.2f moveto %.2f %.2f lineto\n",*x1,yy1,*x2,yy2);*/
		sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f MV\n",bx1,by1,bx2,by2,*x2,yy2,*x1,yy1);
		psputs(str);
		XX=*x2;		YY=yy2;
		iline=1;	linestroke++;
	}
	picture=PICLINE;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}
}

void postscriptlinestroke()
{
	if (linestroke>0) {
		psputs("S\n");
		iline=MAXLINE;	linestroke=0;
	}
}

void postscriptpolygon(float *px,float *py,int *nn,int *md)
{
	int i;

	if (*md<=1) {
		checkstroke(PICPOLYGON);
		if (linespec!=PICLINE) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
			psputs("TS\n");		linespec=PICLINE;
		}
		if (lcolmode==2) setlinestyle();
			else		 setgrayscale();
		/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
		if (*md==1) {
		  	if (*nn==3) {
				/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
				sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f T3\n",px[2],PSYOFF-py[2],px[1],PSYOFF-py[1],px[0],PSYOFF-py[0]);
				psputs(str);
			  }
			  else if (*nn==4) {
				/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
				sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f T4\n"
										,px[3],PSYOFF-py[3],px[2],PSYOFF-py[2],px[1],PSYOFF-py[1],px[0],PSYOFF-py[0]);
				psputs(str);
			  }
			  else {
				sprintf(str,"%.2f %.2f M\n",px[0],PSYOFF-py[0]);
				psputs(str);
				for (i=1;i<*nn;i++) {
					/*psprintf("%.2f %.2f lineto\n",px[i],PSYOFF-py[i]);*/
					sprintf(str,"%.2f %.2f L\n",px[i],PSYOFF-py[i]);
					psputs(str);
				}
				psputs("C\n");
			}
		  }
		  else {
			for (i=1;i<*nn;i++) {
				/*psprintf("%.2f %.2f lineto\n",px[i],PSYOFF-py[i]);*/
				sprintf(str,"%.2f %.2f L\n",px[i],PSYOFF-py[i]);
				psputs(str);
			}
		}
		linestroke+=*nn;
		picture=PICPOLYGON;
	  }
	  else {
		checkstroke(PICPOLYGONFILL);
		setgrayscale();
	  	if (*nn==3) {
			/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
			sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f F3\n",px[2],PSYOFF-py[2],px[1],PSYOFF-py[1],px[0],PSYOFF-py[0]);
			psputs(str);
		  }
		  else if (*nn==4) {
			/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
/*			if (px[0]==px[1] && py[1]==py[2] && px[2]==px[3] && py[3]==py[0]) {
				sprintf(str,"%.2f %.2f %.2f %.2f T\n",px[2],PSYOFF-py[2],px[0],PSYOFF-py[0]);
			  }
			  else if (py[0]==py[1] && px[1]==px[2] && py[2]==py[3] && px[3]==px[0]) {
				sprintf(str,"%.2f %.2f %.2f %.2f T\n",px[2],PSYOFF-py[2],px[0],PSYOFF-py[0]);
			  }*/
			sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f F4\n"
									,px[3],PSYOFF-py[3],px[2],PSYOFF-py[2],px[1],PSYOFF-py[1],px[0],PSYOFF-py[0]);
			psputs(str);
		  }
		  else if (*nn==5) {
			/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
			sprintf(str,"%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f F5\n"
									,px[4],PSYOFF-py[4],px[3],PSYOFF-py[3],px[2],PSYOFF-py[2],px[1],PSYOFF-py[1],px[0],PSYOFF-py[0]);
			psputs(str);
		  }
		  else {
			/*psprintf("%.2f %.2f moveto\n",px[0],PSYOFF-py[0]);*/
			sprintf(str,"%.2f %.2f M\n",px[0],PSYOFF-py[0]);
			psputs(str);
			for (i=1;i<*nn;i++) {
				/*psprintf("%.2f %.2f lineto\n",px[i],PSYOFF-py[i]);*/
				sprintf(str,"%.2f %.2f L\n",px[i],PSYOFF-py[i]);
				psputs(str);
			}
			psputs("F\n");
		}
		linestroke=0;
		picture=PICPOLYGONFILL;
	}
	XX=-99999.9;		YY=-99999.9;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		iline=MAXLINE;		linestroke=0;
	}
}

void postscriptarrow(float *x1,float *y1,float *x2,float *y2
					,float *vx,float *vy,float *cs,float *sn,int *icv)
{
	float xx,yy;
	float yy1=PSYOFF-(*y1), yy2=PSYOFF-(*y2);

	checkstroke(PICARROW);
	if (linespec!=PICARROW) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
		psputs("AS\n");		linespec=PICARROW;
	}

	if (vcolmode && lcolmode) setgrayscale();
		else 	  clearlinegray();

	/*psprintf("%.2f %.2f moveto %.2f %.2f lineto stroke\n",*x1,yy1,*x2,yy2);*/
	sprintf(str,"%.2f %.2f M %.2f %.2f L S\n",*x1,yy1,*x2,yy2);
	psputs(str);
	if (*vx!=0 && *icv==0) {
		xx=-(*vx)*(*cs)+(*vy)*(*sn);
		yy= (*vy)*(*cs)+(*vx)*(*sn);
		/*psprintf("%.2f %.2f moveto %.2f %.2f rlineto\n",*x2,yy2,xx,yy);*/
		sprintf(str,"%.2f %.2f M %.2f %.2f R\n",*x2,yy2,xx,yy);
		psputs(str);
		xx=-2*(*vy)*(*sn);
		yy=-2*(*vy)*(*cs);
		/*psprintf("%.2f %.2f rlineto closepath fill\n",xx,yy);*/
		sprintf(str,"%.2f %.2f RF\n",xx,yy);
		psputs(str);
	}

	linestroke=0;		iline=MAXLINE;
	picture=PICARROW;
}

void postscriptcirc(float *x,float *y,float *dx,float *dy,int *md)
{
	float rx=*dx/2,ry=*dy/2,yy=PSYOFF-(*y);

	checkstroke(PICCIRCLE);

	if (*md) {
		setgrayscale();
		if (*dx==*dy) {
			/*psprintf("%.2f %.2f moveto %.2f %.2f %.2f 0 360 arc fill\n",*x+rx,yy,*x,yy,rx);*/
			sprintf(str,"%.2f %.2f M %.2f %.2f %.2f AF\n",*x+rx,yy,*x,yy,rx);
			psputs(str);
		  }
		  else {
		    	/*psprintf("%.2f %.2f %.2f %.2f ellipse fill ellipseend\n",rx,ry,*x,yy);*/
			sprintf(str,"%.2f %.2f %.2f %.2f EF\n",rx,ry,*x,yy);
			psputs(str);
		 }
 		linestroke=0;
		picture=PICCIRCLEFILL;
	  }
	  else {
		if (linespec!=PICLINE) {
		if (linespec==PICLINEGRADFILL) psputs("S1 ");
			psputs("TS\n");		linespec=PICLINE;
		}
		if (lcolmode==2) setlinestyle();
			else		 setgrayscale();
		if (*dx==*dy) {
			/*psprintf("%.2f %.2f moveto %.2f %.2f %.2f 0 360 arc\n",*x+rx,yy,*x,yy,rx);*/
			sprintf(str,"%.2f %.2f M %.2f %.2f %.2f A\n",*x+rx,yy,*x,yy,rx);
			psputs(str);
		  }
		  else {
		    	/*psprintf("%.2f %.2f %.2f %.2f ellipse ellipseend\n",rx,ry,*x,yy);*/
			sprintf(str,"%.2f %.2f %.2f %.2f E\n",rx,ry,*x,yy);
			psputs(str);
		}
		linestroke++;
		picture=PICCIRCLE;
	}


	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		linestroke=0;
	}
	iline=MAXLINE;
}

void postscriptgradcirc(float *x,float *y,float *dx,float *dy,int *md)
{
	float rx=*dx/2,ry=*dy/2,yy=PSYOFF-(*y);
	int ic=*md;

	if (ic<=0) ic=1;
		else if (ic>=7) ic=7;
	checkstroke(PICCIRCLE);

	setgrayscale();
	if (*dx==*dy) {
		/*psprintf("%.2f %.2f moveto %.2f %.2f %.2f 0 360 arc fill\n",*x+rx,yy,*x,yy,rx);*/
		sprintf(str,"gsave %.2f %.2f M %.2f %.2f %.2f A\n",*x+rx,yy,*x,yy,rx);
		psputs(str);
	  }
	  else {
	    	/*psprintf("%.2f %.2f %.2f %.2f ellipse fill ellipseend\n",rx,ry,*x,yy);*/
		sprintf(str,"gsave %.2f %.2f %.2f %.2f E\n",rx,ry,*x,yy);
		psputs(str);
	}
	psputs("clip << /ShadingType 3 /ColorSpace /DeviceRGB\n");
	sprintf(str,"/Coords [%.2f %.2f 0 %.2f %.2f %.2f]\n",*x+rx/3,yy+ry/3,*x+rx/3,yy+ry/3,rx+ry);
	psputs(str);
	psputs("/Function << /FunctionType 2 /Domain [0 1]\n");
	sprintf(str,"/C1 [0 0 0] /C0 [%d %d %d]\n",(ic&4)>>2,(ic&2)>>1,(ic&1));
	psputs(str);
	psputs("/N 1 >> >> shfill grestore\n");
	linestroke=0;
	picture=PICCIRCLEGRADFILL;

	if (linestroke>MAXSTROKE) {
		psputs("S\n");
		linestroke=0;
	}
	iline=MAXLINE;
}

void psfontset(int ifont)
{
	if (ifont==nfont) return;
	sprintf(str,"F%s setfont /HTEXT H%s def /WTEXT W%s def\n"
					,fontname[ifont],fontname[ifont],fontname[ifont]);
	psputs(str);
	nfont=ifont;
}	

void postscriptchr(float *x,float *y,char *chr,int *nc,float *hwx,float *hhy,int *midx
								,int *mode,int *cond,int *ifont)
/*
 *   hwx, hhy : 1/2 font width and height (real)
 *   midx     : 1/2 word width (integer)
 *   Base Point is Bottom Left
 */
{
	int i,n,nl;
	float yy=PSYOFF-(*y);

	checkstroke(PICTEXT);

/*	printf("%d %d %d\n",lcolmode,lcolor,mcolor);*/
	if (ccolmode && lcolmode) setgrayscale();
		else 	  clearlinegray();

/*
 	switch (*cond) {
		case 0: goto def;
		case 1:	psputs("tposx2 tposy2 M\n");
    			break;
		case 2:	psputs("tposx1 tposy2 M\n");
				break;
		case 3:	psputs("tposx2 tposy1 M\n");
    			break;
		case 4:	psputs("tposx1 tposy1 M\n");
    			break;
		default:
		def:
			sprintf(str,"%.2f %.2f M\n",*x,yy);
			psputs(str);
	 }
*/
	psfontset(*ifont);
	if (*mode) {
		sprintf(str,"%.4f twidth  mul tposx add /tposx exch def\n",*x);
		psputs(str);
		sprintf(str,"%.4f HTEXT mul tposy add /tposy exch def\n",*y);
		psputs(str);
		psputs("tposx tposy M\n");
	  }
	  else {
		sprintf(str,"%.2f %.2f M\n",*x,yy);
		psputs(str);
		if (*cond) {
			sprintf(str,"%.2f /tposx exch def %.2f /tposy exch def\n",*x,yy);
			psputs(str);
		}
	}

	if (hchrmove) {
		sprintf(str,"%.4f %.4f MH\n",hchrx,hchry);
		psputs(str);
		hchrmove=0;
	}
	if (wchrmove) {
		sprintf(str,"%.4f %.4f MW\n",wchrx,wchry);
		psputs(str);
		wchrmove=0;
	}

	if (txangle) psputs("gsave currentpoint translate txangle rotate\n");

	if (*hhy+1!=0) {
		/*psprintf("%d stepmovedown\n",*iy+1);*/
		sprintf(str,"%.4f SD\n",*hhy+1);
		psputs(str);
	}
	if (*hwx!=0) {
		/*psprintf("%d stepmoveright\n",*idx);*/
		sprintf(str,"%.4f SR\n",*hwx);
		psputs(str);
	}

	psputs("currentpoint dup /tposy2 exch def HTEXT add /tposy1 exch def pop\n");

	n=*nc;		nl=1;
	str[0]='(';
	for (i=0;i<n;i++) {
		if (chr[i]=='(' || chr[i]==')') {
			str[nl++]='\\';
			str[nl++]=chr[i];
		}
		else str[nl++]=chr[i];
	}
	str[nl++]=')';
	str[nl]='\0';
	strcat(str," stringwidth pop /twidth exch def\n");
	psputs(str);
	str[nl]='\0';

	switch (*midx) {
	  	case 0:		strcat(str," CW\n");
					break;
	  	case -1:	strcat(str," RW\n");
	  				break;
  		case 1:		strcat(str," W\n");
  					break;
	  	default:	sprintf(&str[nl]," %d SS\n",*midx-1);
	}
	psputs(str);
/*
	psputs("currentpoint pop /tposx2 exch def\n");
	str[nl]='\0';
	strcat(str," stringwidth pop neg tposx2 add /tposx1 exch def\n");
	psputs(str);
*/

	if (txangle) {	psputs("grestore\n");	txangle=0;	}

	linestroke=0;		iline=MAXLINE;
	picture=PICTEXT;
}

void postscriptchr10(float *x,float *y,char *chr,int *nc,char *chr10,int *nc10
										,float *hwx,float *hhy,int *midx,int *ifont)
{
	int i,n,nl,n10,nl10;
	char strexp[30],strnum[50];
	float yy=PSYOFF-(*y);

	checkstroke(PICTEXT10);

	if (ccolmode && lcolmode) setgrayscale();
		else 	  clearlinegray();

	/*psprintf("%.2f %.2f moveto\n",*x,yy);*/
	sprintf(str,"%.2f %.2f M\n",*x,yy);
	psputs(str);

	psfontset(*ifont);
	if (txangle) psputs("gsave currentpoint translate txangle rotate\n");

	if (*hhy+1!=0) {
		/*psprintf("%d stepmovedown\n",*iy+1);*/
		sprintf(str,"%.4f SD\n",*hhy+1);
		psputs(str);
	}
	if (*hwx!=0) {
		/*psprintf("%d stepmoveright\n",*idx);*/
		sprintf(str,"%.4f SR\n",*hwx);
		psputs(str);
	}

	strnum[0]='(';
	n=*nc;		nl=1;
	for (i=0;i<n;i++) {
		if (chr[i]=='(' || chr[i]==')') {
			strnum[nl++]='\\';
			strnum[nl++]=chr[i];
		}
		else strnum[nl++]=chr[i];
	}
	strnum[nl++]=')';
	strnum[nl]='\0';

	strexp[0]='(';
	n10=*nc10;		nl10=1;
	for (i=0;i<n10;i++) {
		if (chr10[i]=='(' || chr10[i]==')') {
			strexp[nl10++]='\\';
			strexp[nl10++]=chr10[i];
		}
		else strexp[nl10++]=chr10[i];
	}
	strexp[nl10++]=')';
	strexp[nl10]='\0';

	if (*midx>0) {
		psputs("0 HPOW 2 div neg rmoveto\n");
		if (n>0) {
			strcat(strnum," W\n");				psputs(strnum);
			psputs("(\26410) W\n");								/* Dot + 10  */
		  }
		  else {
			psputs("(10) W\n");
		}
		psputs("0 .7 HTEN mul rmoveto\n");
		psfontset(FPOW);
		strcat(strexp," W\n");					psputs(strexp);
	 }
	 else {
		psputs("0 .7 HTEN mul rmoveto\n");
		psfontset(FPOW);
		strcat(strexp," RWM\n");				psputs(strexp);
		psfontset(*ifont);
		psputs("0 -0.7 HTEN mul rmoveto\n");
		if (n>0) {
			psputs("(\26410) RWM\n");							/* Dot + 10  */
			strcat(strnum," RW\n");				psputs(strnum);
		  }
		  else {
			psputs("(10) RW\n");
		}
	 }

	if (txangle) {	
		psputs("grestore\n");	txangle=0;
		psputs("/cleartpos\n");
	}

	linestroke=0;		iline=MAXLINE;
	picture=PICTEXT10;
}

void postscriptchrangle(float *dx,float *dy)
{
	if (*dy==0) txangle=0;
	  else {
		/*psprintf("/txangle %f %f atan def\n",*dy,*dx);*/
		sprintf(str,"/txangle %f %f atan def\n",*dy,*dx);
		psputs(str);
		txangle=1;
		psputs("/cleartpos\n");
	}
}

void postscriptchrmove(float *hdx,float *hdy,float *wdx,float *wdy)
{
	if (*hdx!=0 || *hdy!=0) {
		hchrx=*hdx;		hchry=*hdy;
		hchrmove=1;
	}
	if (*wdx!=0 || *wdy!=0) {
		wchrx=*wdx;		wchry=*wdy;
		wchrmove=1;
	}
}
