*****************************************
*         F  R  A  M  E  S  V.7         *
*     REAL  3D   FRAME  SUBROUTINES     *
*        PROGRAMMED BY T.TAGUCHI        *
*****************************************
      SUBROUTINE FR_VIEW3D(IXXMIN,IYYMIN,IXXMAX,IYYMAX)
      COMMON /GRAPHCOM/ XMIN2,XMAX2,YMIN2,YMAX2,XTAN2,YTAN2,X02,Y02
     +            ,PX2,PY2,IXMIN2,IXMAX2,IYMIN2,IYMAX2,IFRAM2,IVIEW2
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(61,1)
         CALL GSENDBYTE(IXXMIN,2)
         CALL GSENDBYTE(IYYMIN,2)
         CALL GSENDBYTE(IXXMAX,2)
         CALL GSENDBYTE(IYYMAX,2)
      ENDIF

      IXPMIN = IXXMIN
      IXPMAX = IXXMAX
      IYPMIN = IYYMIN
      IYPMAX = IYYMAX

      XPMID = 0.5*(IXPMIN + IXPMAX)
      YPMID = 0.5*(IYPMIN + IYPMAX)

      IFRAM   = 0
      MODE3D  = 1
      IVIEW2  = 0
      IVIEW   = IOR(IVIEW,1)
      IPRREG  = 0
      ICNREG3 = 0

      RETURN
      END

      SUBROUTINE FR_MARGIN3D(XLM,YLM,XUM,YUM)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER XLM,YLM,XUM,YUM

      IF (IGCANVAS.LT.0) RETURN

      call getcanvaswindowsize(IBX,IBY,IOX,IOY)
      IXXMIN   = XLM-IOX
      IYYMIN   = YLM-IOY
      IXXMAX   = IBX-IOX-XUM
      IYYMAX   = IBY-IOY-YUM

      CALL FR_VIEW3D(IXXMIN,IYYMIN,IXXMAX,IYYMAX)

      RETURN
      END

      SUBROUTINE FR_ANGLE3D(THETA0,PHI0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 THETA0,PHI0

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(62,1)
         CALL GSEND8BYTE(THETA0,PHI0,1,0)
      ENDIF

      THETA  = DMOD(THETA0,180.0D0)
      IF (THETA.GT.90.0)  THETA =  180.0 - THETA
      IF (THETA.LT.-90.0) THETA = -180.0 - THETA
      PHI    = DMOD(PHI0,360.0D0)
      IF (PHI.GT.180.0)  PHI = PHI - 360.0
      IF (PHI.LE.-180.0) PHI = PHI + 360.0

      IFRAM  = 0
      MODE3D = 1
      IVIEW  = IOR(IVIEW,2)

      RETURN
      END

      SUBROUTINE FR_ASPECT3D(RTX,RTY,RTZ,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 RTX,RTY,RTZ,RY,RZ

      IF (IGCANVAS.LT.0) RETURN

      IF (RTX.EQ.0.0D0.OR.RTY.EQ.0.0D0.OR.RTZ.EQ.0.0D0) THEN
         CALL FRAMESERROR('ILLEGAL SETTINGS FOR 3D ASPECT RATIO !!!')
         RETURN
      ENDIF

      RY = RTY/RTX
      RZ = RTZ/RTX
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(63,1)
         CALL GSENDBYTE(IND,1)
         CALL GSEND8BYTE(RY,RZ,1,0)
      ENDIF

      RATIOXY = RY
      RATIOXZ = RZ

      IFRAM  = 0
      MODE3D = 1
      IPROJ  = IND
      IVIEW  = IOR(IVIEW,4)

      RETURN
      END

      SUBROUTINE FR_ROTATE(THETA0,PHI0,IND)
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      REAL*8 THETA0,PHI0
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2

      IF (IGCANVAS.LT.0) RETURN

      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR ROTATE')
         RETURN
      ENDIF

      IF (IGPLT.GT.0) THEN
        IF (IFRAM.EQ.0) THEN
          IF (IAND(IVIEW,1).EQ.0) CALL FR_VIEW3D(IXPMIN,IYPMIN
     ,                                       ,IXPMAX,IYPMAX)
          IF (IAND(IVIEW,4).EQ.0) CALL FR_ASPECT3D(1.D0,DBLE(RATIOXY)
     ,                                            ,DBLE(RATIOXZ),IPROJ)
          IF (IAND(IVIEW,8).EQ.0) CALL FR_PROJECT(DBLE(DISTAN),-9999)
        ENDIF
        CALL GSENDBYTE(64,1)
        CALL GSENDBYTE(IND,1)
        CALL GSEND8BYTE(DBLE(XMIN),DBLE(XMAX),1,0)
        CALL GSEND8BYTE(DBLE(YMIN),DBLE(YMAX),1,0)
        CALL GSEND8BYTE(DBLE(ZMIN),DBLE(ZMAX),1,0)
        CALL GSEND8BYTE(DBLE(RATIO),PHI0,1,-1)
        CALL GSEND8BYTE(THETA0,PHI0,1,0)
      ENDIF

      THETA = DMOD(THETA0,180.0D0)
      IF (THETA.GT.90.0)  THETA =  180.0 - THETA
      IF (THETA.LT.-90.0) THETA = -180.0 - THETA
      PHI   = DMOD(PHI0,360.0D0)
      IF (PHI.GT.180.0)  PHI = PHI - 360.0
      IF (PHI.LE.-180.0) PHI = PHI + 360.0

      TH     = PI*THETA/180.0
      PH     = PI*PHI/180.0

*      XMID0 = COX(0.5*(XMIN+XMAX),0.5*(YMIN+YMAX))
*      YMID0 = COY(0.5*(XMIN+XMAX),0.5*(YMIN+YMAX),0.5*(ZMIN+ZMAX))

      IF (MOD3DIR.EQ.1) THEN
         XPX    =  0
         XPY    = -SIN(PH)
         XPZ    =  COS(PH)
         YPX    =  COS(TH)
         YPY    = -SIN(TH)*XPZ
         YPZ    =  SIN(TH)*XPY
         ZPX    =  SIN(TH)
         ZPY    =  COS(TH)*XPZ
         ZPZ    = -COS(TH)*XPY
       ELSE IF (MOD3DIR.EQ.2) THEN
         XPX    =  COS(PH)
         XPY    =  0
         XPZ    = -SIN(PH)
         YPX    =  SIN(TH)*XPZ
         YPY    =  COS(TH)
         YPZ    = -SIN(TH)*XPX
         ZPX    = -COS(TH)*XPZ
         ZPY    =  SIN(TH)
         ZPZ    =  COS(TH)*XPX
       ELSE
         XPX    = -SIN(PH)
         XPY    =  COS(PH)
         XPZ    =  0
         YPX    = -SIN(TH)*XPY
         YPY    =  SIN(TH)*XPX
         YPZ    =  COS(TH)
         ZPX    =  COS(TH)*XPY
         ZPY    = -COS(TH)*XPX
         ZPZ    =  SIN(TH)
      ENDIF

      XPY    = XPY*RATIOXY
      XPZ    = XPZ*RATIOXZ
      YPY    = YPY*RATIOXY
      YPZ    = YPZ*RATIOXZ
      ZPY    = ZPY*RATIOXY
      ZPZ    = ZPZ*RATIOXZ

      IF (IPROJ.NE.0) THEN
         XPZ = XPZ/ABS(ZMAX - ZMIN)
         YPZ = YPZ/ABS(ZMAX - ZMIN)
         ZPZ = ZPZ/ABS(ZMAX - ZMIN)
         IF (IPROJ.EQ.2) THEN
            XPX = XPX/ABS(XMAX - XMIN)
            YPX = YPX/ABS(XMAX - XMIN)
            ZPX = ZPX/ABS(XMAX - XMIN)
            XPY = XPY/ABS(XMAX - XMIN)
            YPY = YPY/ABS(XMAX - XMIN)
            ZPY = ZPY/ABS(XMAX - XMIN)
          ELSE IF (IPROJ.EQ.3) THEN
            XPX = XPX/ABS(YMAX - YMIN)
            YPX = YPX/ABS(YMAX - YMIN)
            ZPX = ZPX/ABS(YMAX - YMIN)
            XPY = XPY/ABS(YMAX - YMIN)
            YPY = YPY/ABS(YMAX - YMIN)
            ZPY = ZPY/ABS(YMAX - YMIN)
          ELSE
            XPX = XPX/ABS(XMAX - XMIN)
            YPX = YPX/ABS(XMAX - XMIN)
            ZPX = ZPX/ABS(XMAX - XMIN)
            XPY = XPY/ABS(YMAX - YMIN)
            YPY = YPY/ABS(YMAX - YMIN)
            ZPY = ZPY/ABS(YMAX - YMIN)
         ENDIF
      ENDIF

      IF (XMIN.GT.XMAX) THEN
         XPX = -XPX
         YPX = -YPX
         ZPX = -ZPX
      ENDIF
      IF (YMIN.GT.YMAX) THEN
         XPY = -XPY
         YPY = -YPY
         ZPY = -ZPY
      ENDIF
      IF (ZMIN.GT.ZMAX) THEN
         XPZ = -XPZ
         YPZ = -YPZ
         ZPZ = -ZPZ
      ENDIF

      REFX    = 0.5*(XMIN + XMAX)
      REFY    = 0.5*(YMIN + YMAX)
      REFZ    = 0.5*(ZMIN + ZMAX)

      IF (MDPROJ.NE.0) THEN
         X0M = XPX*(XMAX-REFX) + XPY*(YMAX-REFY) + XPZ*(ZMAX-REFZ)
         Y0M = YPX*(XMAX-REFX) + YPY*(YMAX-REFY) + YPZ*(ZMAX-REFZ)
         Z0M = ZPX*(XMAX-REFX) + ZPY*(YMAX-REFY) + ZPZ*(ZMAX-REFZ)
         D0  = DISTAN*SQRT(X0M*X0M + Y0M*Y0M + Z0M*Z0M)
         ZPX = ZPX/D0
         ZPY = ZPY/D0
         ZPZ = ZPZ/D0
         ZP0 = -ZPX*REFX - ZPY*REFY - ZPZ*REFZ
         ZSCALE = D0
      ENDIF

      RATE    = RATIO

      XPX     =  RATE*XPX
      XPY     =  RATE*XPY
      XPZ     =  RATE*XPZ
      YPX     = -RATE*YPX
      YPY     = -RATE*YPY
      YPZ     = -RATE*YPZ

      XP0     = -XPX*REFX - XPY*REFY - XPZ*REFZ
      YP0     = -YPX*REFX - YPY*REFY - YPZ*REFZ

      ZSCALE  = RATE*ZSCALE

*     change here
*      XMID1   = COX(0.5*(XMIN+XMAX),0.5*(YMIN+YMAX))
*      YMID1   = COY(0.5*(XMIN+XMAX),0.5*(YMIN+YMAX),0.5*(ZMIN+ZMAX))
*      XP0     = XP0 + (XMID0 - XMID1)
*      YP0     = YP0 + (YMID0 - YMID1)

      tdx1   = min(XMIN,XMAX)
      tdx2   = max(XMIN,XMAX)
      tdy1   = min(YMIN,YMAX)
      tdy2   = max(YMIN,YMAX)
      tdz1   = min(ZMIN,ZMAX)
      tdz2   = max(ZMIN,ZMAX)


      IFRAM = 1
      IF (IGCANVAS.EQ.0) RETURN

      IF (IND.NE.1) THEN
         ICLP = 0
         CALL GWIONOCLIP
         IFRAM = 9999
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,IND)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_FRAME3D(XXMIN0,XXMAX0,YYMIN0,YYMAX0,ZZMIN0,ZZMAX0
     ,                                             ,IND)
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XM(2),YM(2),XTAN,YTAN,X0,Y0
     +        ,ZM(2),ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /AXISNAMECOM3D/ XNAME,YNAME,ZNAME,IXYZNAME,LXNM,LYNM,LZNM
      CHARACTER XNAME*128,YNAME*128,ZNAME*128
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      REAL*8 XXMIN0,XXMAX0,YYMIN0,YYMAX0,ZZMIN0,ZZMAX0
      REAL*8 XXMIN,XXMAX,YYMIN,YYMAX,ZZMIN,ZZMAX
      EQUIVALENCE (XM(1),XMIN),(XM(2),XMAX),(YM(1),YMIN),(YM(2),YMAX)
      EQUIVALENCE (ZM(1),ZMIN),(ZM(2),ZMAX)
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2

      IF (IGCANVAS.LT.0) RETURN

      NOTCHR = 0
      IF (IND.EQ.99999) THEN
         IOFR = 1
         IND1 = IFRAM - 1
         GO TO 100
      ENDIF
      IOFR = 0

      IND0 = MOD(IND,100)
      IF (IAND(IVIEW,4).EQ.0.AND.IND.GE.100) THEN
         CALL FR_ASPECT3D(1.D0,1.D0,0.5D0,2)
      ENDIF

      IF (IFRAM.EQ.9999) GO TO 10000
      MODE3D = 1

      CALL REGULATEGREGION(XXMIN0,XXMAX0,XXMIN,XXMAX)
      CALL REGULATEGREGION(YYMIN0,YYMAX0,YYMIN,YYMAX)
      CALL REGULATEGREGION(ZZMIN0,ZZMAX0,ZZMIN,ZZMAX)

      XMIN   = XXMIN
      XMAX   = XXMAX
      YMIN   = YYMIN
      YMAX   = YYMAX
      ZMIN   = ZZMIN
      ZMAX   = ZZMAX

      tdx1   = min(XMIN,XMAX)
      tdx2   = max(XMIN,XMAX)
      tdy1   = min(YMIN,YMAX)
      tdy2   = max(YMIN,YMAX)
      tdz1   = min(ZMIN,ZMAX)
      tdz2   = max(ZMIN,ZMAX)

      TH     = PI*THETA/180.0
      PH     = PI*PHI/180.0
      IF (MOD3DIR.EQ.1) THEN
         XPX    =  0
         XPY    = -SIN(PH)
         XPZ    =  COS(PH)
         YPX    =  COS(TH)
         YPY    = -SIN(TH)*XPZ
         YPZ    =  SIN(TH)*XPY
         ZPX    =  SIN(TH)
         ZPY    =  COS(TH)*XPZ
         ZPZ    = -COS(TH)*XPY
       ELSE IF (MOD3DIR.EQ.2) THEN
         XPX    =  COS(PH)
         XPY    =  0
         XPZ    = -SIN(PH)
         YPX    =  SIN(TH)*XPZ
         YPY    =  COS(TH)
         YPZ    = -SIN(TH)*XPX
         ZPX    = -COS(TH)*XPZ
         ZPY    =  SIN(TH)
         ZPZ    =  COS(TH)*XPX
       ELSE
         XPX    = -SIN(PH)
         XPY    =  COS(PH)
         XPZ    =  0
         YPX    = -SIN(TH)*XPY
         YPY    =  SIN(TH)*XPX
         YPZ    =  COS(TH)
         ZPX    =  COS(TH)*XPY
         ZPY    = -COS(TH)*XPX
         ZPZ    =  SIN(TH)
      ENDIF

      XPY    = XPY*RATIOXY
      XPZ    = XPZ*RATIOXZ
      YPY    = YPY*RATIOXY
      YPZ    = YPZ*RATIOXZ
      ZPY    = ZPY*RATIOXY
      ZPZ    = ZPZ*RATIOXZ
      IF (IPROJ.NE.0) THEN
         XPZ = XPZ/ABS(ZMAX - ZMIN)
         YPZ = YPZ/ABS(ZMAX - ZMIN)
         ZPZ = ZPZ/ABS(ZMAX - ZMIN)
         IF (IPROJ.EQ.2) THEN
            XPX = XPX/ABS(XMAX - XMIN)
            YPX = YPX/ABS(XMAX - XMIN)
            ZPX = ZPX/ABS(XMAX - XMIN)
            XPY = XPY/ABS(XMAX - XMIN)
            YPY = YPY/ABS(XMAX - XMIN)
            ZPY = ZPY/ABS(XMAX - XMIN)
          ELSE IF (IPROJ.EQ.3) THEN
            XPX = XPX/ABS(YMAX - YMIN)
            YPX = YPX/ABS(YMAX - YMIN)
            ZPX = ZPX/ABS(YMAX - YMIN)
            XPY = XPY/ABS(YMAX - YMIN)
            YPY = YPY/ABS(YMAX - YMIN)
            ZPY = ZPY/ABS(YMAX - YMIN)
          ELSE
            XPX = XPX/ABS(XMAX - XMIN)
            YPX = YPX/ABS(XMAX - XMIN)
            ZPX = ZPX/ABS(XMAX - XMIN)
            XPY = XPY/ABS(YMAX - YMIN)
            YPY = YPY/ABS(YMAX - YMIN)
            ZPY = ZPY/ABS(YMAX - YMIN)
         ENDIF
      ENDIF

      IF (XMIN.GT.XMAX) THEN
         XPX = -XPX
         YPX = -YPX
         ZPX = -ZPX
      ENDIF
      IF (YMIN.GT.YMAX) THEN
         XPY = -XPY
         YPY = -YPY
         ZPY = -ZPY
      ENDIF
      IF (ZMIN.GT.ZMAX) THEN
         XPZ = -XPZ
         YPZ = -YPZ
         ZPZ = -ZPZ
      ENDIF

      REFX = 0.5*(XMIN + XMAX)
      REFY = 0.5*(YMIN + YMAX)
      REFZ = 0.5*(ZMIN + ZMAX)
      XP0  = -XPX*REFX - XPY*REFY - XPZ*REFZ
      YP0  = -YPX*REFX - YPY*REFY - YPZ*REFZ

      IF (MDPROJ.NE.0) THEN
         X0M = XPX*(XMAX-REFX) + XPY*(YMAX-REFY) + XPZ*(ZMAX-REFZ)
         Y0M = YPX*(XMAX-REFX) + YPY*(YMAX-REFY) + YPZ*(ZMAX-REFZ)
         Z0M = ZPX*(XMAX-REFX) + ZPY*(YMAX-REFY) + ZPZ*(ZMAX-REFZ)
         D0  = DISTAN*SQRT(X0M*X0M + Y0M*Y0M + Z0M*Z0M)
         ZPX = ZPX/D0
         ZPY = ZPY/D0
         ZPZ = ZPZ/D0
         ZP0 = -ZPX*REFX - ZPY*REFY - ZPZ*REFZ
         ZSCALE = D0
      ENDIF

      CALL COORDINXYZ(XXMIN,YYMIN,ZZMIN,XPMIN,YPMIN)
      XPMAX  = XPMIN
      YPMAX  = YPMIN
      CALL COORDINXYZ(XXMAX,YYMIN,ZZMIN,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMIN,YYMAX,ZZMIN,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMAX,YYMAX,ZZMIN,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMIN,YYMIN,ZZMAX,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMAX,YYMIN,ZZMAX,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMIN,YYMAX,ZZMAX,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2
      CALL COORDINXYZ(XXMAX,YYMAX,ZZMAX,XP2,YP2)
      IF (XPMIN.GT.XP2) XPMIN = XP2
      IF (XPMAX.LT.XP2) XPMAX = XP2
      IF (YPMIN.GT.YP2) YPMIN = YP2
      IF (YPMAX.LT.YP2) YPMAX = YP2

      RX     = (IXPMAX - IXPMIN)/(XPMAX - XPMIN)
      RY     = (IYPMAX - IYPMIN)/(YPMAX - YPMIN)
      IF (ABS(RX).GE.ABS(RY)) THEN
         RATE = ABS(RY)
       ELSE
         RATE = ABS(RX)
      ENDIF
      XPX     = RATE*XPX
      XPY     = RATE*XPY
      XPZ     = RATE*XPZ
      YPX     = -RATE*YPX
      YPY     = -RATE*YPY
      YPZ     = -RATE*YPZ

      XP0     = -XPX*REFX - XPY*REFY - XPZ*REFZ
      YP0     = -YPX*REFX - YPY*REFY - YPZ*REFZ
      RATIO   = RATE
      ZSCALE  = RATE*ZSCALE

      IF (IGPLT.GT.0) THEN
         IF (IAND(IVIEW,1).EQ.0) CALL FR_VIEW3D(IXPMIN,IYPMIN
     ,                                          ,IXPMAX,IYPMAX)
         IF (IAND(IVIEW,2).EQ.0) CALL FR_ANGLE3D(DBLE(THETA),DBLE(PHI))
         IF (IAND(IVIEW,4).EQ.0) CALL FR_ASPECT3D(1.D0,DBLE(RATIOXY)
     ,                                          ,DBLE(RATIOXZ),IPROJ)
         IF (IAND(IVIEW,8).EQ.0) CALL FR_PROJECT(DBLE(DISTAN),-9999)
         IFRAM  = 1
         IF (IFRAM.NE.999) THEN
            CALL GSENDBYTE(65,1)
            CALL GFILE3FRAME(XXMIN,XXMAX,YYMIN,YYMAX,ZZMIN,ZZMAX,IND0)
*            IF (IFSW.EQ.2) RETURN
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) THEN
         LABELAX = 0
         RETURN
      ENDIF

      ICLP   = 0
      CALL GWIONOCLIP

10000    CONTINUE

      IND1   = MOD(IND0,10)
      ICLP3D = IND0/10
      IFRAM  = IND1 + 1

      IF (IND.EQ.10001) RETURN
100   IF (IND1.NE.1) THEN
         CALL GWIOBDFREEZ(IER)
         IF (IER.NE.0) RETURN
         CALL GWIOSETAASPACE(0)
         CALL GWIOCOLOR(0,-7)

         IF (MOD3DIR.EQ.1) THEN
            CALL FRAMES3DAXIS(YM,ZM,XM,IND1,IOFR)
          ELSE IF (MOD3DIR.EQ.2) THEN
            CALL FRAMES3DAXIS(ZM,XM,YM,IND1,IOFR)
          ELSE
            CALL FRAMES3DAXIS(XM,YM,ZM,IND1,IOFR)
         ENDIF
         CALL GWIOBDFLUSH(1)
         IF (IXYZNAME.NE.0) CALL FR_XYZNAME(' ',' ',' ')
      ENDIF

      RETURN
      END

      SUBROUTINE FRAMES3DAXIS(XM,YM,ZM,IND1,IOFR)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      REAL XM(2),YM(2),ZM(2)

      IF (THETA.LT.0.0) THEN
         Z0  = ZM(2)
         Z1  = ZM(1)
         IT  = -1
       ELSE
         Z0  = ZM(1)
         Z1  = ZM(2)
         IT  = 1
      ENDIF

      IF (ABS(THETA).EQ.90.0) THEN
         IF (IND1.EQ.2) RETURN
         IF (PHI.LT.-90.0) THEN
            IY = 1
            IX = 1
            IB = 1
            IN = 0
          ELSE IF (PHI.LT.0.0) THEN
            IY = 1
            IX = 2
            IB = -1
            IN = 0
          ELSE IF (PHI.LE.90.0) THEN
            IY = 2
            IX = 2
            IB = 1
            IN = 0
          ELSE
            IY = 2
            IX = 1
            IB = -1
            IN = 0
         ENDIF
         IF (IOFR.EQ.0) THEN
            CALL FRAMESAXIS1(1,XM,YM(IY),Z0,IB,IT,IN,YM(3-IY),Z0)
            CALL FRAMESAXIS1(2,YM,Z0,XM(IX),-IB,IT,-IN,Z0,XM(3-IX))
         ENDIF
       ELSE IF (THETA.NE.0.0) THEN
         IX1 = 1
         IF (PHI.LT.-90.0) THEN
            IY  = 1
            IX  = 1
            IB  = 1
            IN  = 0
            IY1 = 2
            IX2 = 1
            IB1 = -1
            IN1 = -1
          ELSE IF (PHI.LT.0.0) THEN
            IY  = 1
            IX  = 2
            IB  = -1
            IN  = 0
            IY1 = 1
            IX2 = 2
            IB1 = -1
            IN1 = -1
          ELSE IF (PHI.EQ.0.0) THEN
            IY  = 1
            IX  = 2
            IB  = -1
            IN  = 0
            IX1 = 2
            IY1 = 2
            IX2 = 2
            IB1 = 1
            IN1 = 1
          ELSE IF (PHI.LE.90.0) THEN
            IY  = 2
            IX  = 2
            IB  = 1
            IN  = 0
            IY1 = 2
            IX2 = 2
            IB1 = 1
            IN1 = 1
          ELSE
            IY  = 2
            IX  = 1
            IB  = -1
            IN  = 0
            IY1 = 1
            IX2 = 1
            IB1 = 1
            IN1 = 1
         ENDIF
         IF (IND1.GE.2) THEN
            IF (IOFR.NE.0.AND.IND1.GE.2) THEN
*               CALL GWIOCOLOR(0,2)
*               IF (WD.LT.0) CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               NPH = (PHI+225)/90
               CALL COORDINQXYZ(XM(IX),YM(IY),Z1,XPO,YPO)
               CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP1,YP1)
               CALL COORDINQXYZ(XM(IX),YM(3-IY),Z1,XP2,YP2)
               CALL COORDINQXYZ(XM(3-IX),YM(IY),Z1,XP3,YP3)
               IF (ABS(THETA).LT.60.0) THEN
                  IF (MOD(NPH,2).EQ.0) THEN
                     DD1 = (XP1-XPO)*(YP2-YPO)-(XP2-XPO)*(YP1-YPO)
                     DD2 = (XP1-XPO)*(YP3-YPO)-(XP3-XPO)*(YP1-YPO)
                     DD3 = (XP2-XPO)*(YP3-YPO)-(XP3-XPO)*(YP2-YPO)
                   ELSE
                     DD1 = (XP1-XPO)*(YP3-YPO)-(XP3-XPO)*(YP1-YPO)
                     DD2 = (XP1-XPO)*(YP2-YPO)-(XP2-XPO)*(YP1-YPO)
                     DD3 = (XP3-XPO)*(YP2-YPO)-(XP2-XPO)*(YP3-YPO)
                  ENDIF
                ELSE
                  DD1 = (XP3-XPO)*(YP2-YPO)-(XP2-XPO)*(YP3-YPO)
                  DD2 = (XP3-XPO)*(YP1-YPO)-(XP1-XPO)*(YP3-YPO)
                  DD3 = (XP2-XPO)*(YP1-YPO)-(XP1-XPO)*(YP2-YPO)
               ENDIF
               IF (DD1*DD2.LT.0.OR.DD1*DD3.GT.0) THEN
                  CALL GWIOLINE(XPO,YPO,XP1,YP1,0)
                  CALL GWIOLINE(XPO,YPO,XP2,YP2,0)
                  CALL GWIOLINE(XPO,YPO,XP3,YP3,0)
               ENDIF
*               CALL GWIOCOLOR(0,-7)
               RETURN
            ENDIF
            CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP1,YP1)
            CALL COORDINQXYZ(XM(IX),YM(IY),Z1,XP2,YP2)
            CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
            CALL COORDINQXYZ(XM(3-IX1),YM(3-IY1),Z0,XP1,YP1)
            CALL COORDINQXYZ(XM(3-IX1),YM(3-IY1),Z1,XP2,YP2)
            CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP3,YP3)
            WD = ((XP2-XP1)*(YP3-YP1)-(XP3-XP1)*(YP2-YP1))*IB1*IT
            IF (WD.GE.0) THEN
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               IT1 = IT
               IT2 = IT
             ELSE IF (IY.EQ.3-IY1) THEN
               IT1 = 0
               IT2 = IT
             ELSE
               IT1 = IT
               IT2 = 0
            ENDIF
            IF (IOFR.EQ.0.AND.IND1.EQ.4) THEN
               CALL GWIOCOLOR(0,1)
               IF (WD.LT.0) CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               CALL COORDINQXYZ(XM(3-IX),YM(3-IY),Z0,XP1,YP1)
               CALL COORDINQXYZ(XM(3-IX),YM(3-IY),Z1,XP2,YP2)
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               CALL COORDINQXYZ(XM(3-IX),YM(IY),Z0,XP2,YP2)
               CALL GWIOLINE(XP2,YP2,XP1,YP1,0)
               CALL COORDINQXYZ(XM(IX),YM(3-IY),Z0,XP2,YP2)
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               CALL GWIOCOLOR(0,-7)
            ENDIF
            IF (IND1.EQ.2) THEN
               CALL COORDINQXYZ(XM(IX1),YM(IY1),Z0,XP1,YP1)
               CALL COORDINQXYZ(XM(IX1),YM(IY1),Z1,XP2,YP2)
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP2,YP2)
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
               CALL COORDINQXYZ(XM(3-IX1),YM(3-IY1),Z0,XP1,YP1)
               CALL GWIOLINE(XP2,YP2,XP1,YP1,0)
               GO TO 100
            ENDIF
          ELSE
            CALL COORDINQXYZ(XM(3-IX1),YM(3-IY1),Z0,XP1,YP1)
            CALL COORDINQXYZ(XM(3-IX1),YM(3-IY1),Z1,XP2,YP2)
            CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP3,YP3)
            WD = ((XP2-XP1)*(YP3-YP1)-(XP3-XP1)*(YP2-YP1))*IB1*IT
            IF (WD.GE.0) THEN
               IT1 = IT
               IT2 = IT
             ELSE IF (IY.EQ.3-IY1) THEN
               IT1 = 0
               IT2 = IT
             ELSE
               IT1 = IT
               IT2 = 0
            ENDIF
         ENDIF
         IF (IOFR.EQ.0) THEN
            CALL FRAMESAXIS1(1,XM,YM(IY),Z0,IB,IT1,IN,YM(3-IY),Z0)
            CALL FRAMESAXIS1(2,YM,Z0,XM(IX),-IB,IT2,-IN,Z0,XM(3-IX))
        CALL FRAMESAXIS1(3,ZM,XM(IX1),YM(IY1),IB1,IT,IN1,XM(IX2),YM(IY))
         ENDIF
       ELSE
         IAX = 1
         IAY = 1
         IF (PHI.LE.-90.0) THEN
            IY  = 1
            IB  = 1
            IN  = 0
            IY1 = 2
            IF (PHI.NE.-90.0) THEN
               IX  = 1
               IX2 = 1
               IY2 = 1
             ELSE
               IX2 = 2
               IY2 = 2
               IAY = 0
            ENDIF 
            IB1 = -1
            IN1 = -1
          ELSE IF (PHI.LT.0.0) THEN
            IY  = 1
            IX  = 2
            IB  = -1
            IN  = 0
            IY1 = 1
            IX2 = 2
            IY2 = 1
            IB1 = -1
            IN1 = -1
          ELSE IF (PHI.EQ.0.0) THEN
            IX  = 2
            IB  = -1
            IN  = 0
            IY1 = 2
            IX2 = 1
            IY2 = 1
            IB1 = 1
            IN1 = 1
            IAX = 0
          ELSE IF (PHI.LE.90.0) THEN
            IY  = 2
            IB  = 1
            IN  = 0
            IY1 = 2
            IF (PHI.NE.90.0) THEN
               IX  = 2
               IX2 = 1
               IY2 = 1
             ELSE
               IX2 = 2
               IY2 = 2
               IAY = 0
            ENDIF
            IB1 = 1
            IN1 = 1
          ELSE
            IY  = 2
            IX  = 1
            IB  = -1
            IN  = 0
            IY1 = 1
            IX2 = 1
            IY2 = 2
            IB1 = 1
            IN1 = 1
            IF (PHI.EQ.180.0) IAX = 0
         ENDIF
         IF (IND1.GE.2) THEN
            IF (IAX.NE.0.AND.IAY.NE.0) THEN
               CALL COORDINQXYZ(XM(IX),YM(IY),Z0,XP1,YP1)
               CALL COORDINQXYZ(XM(IX),YM(IY),Z1,XP2,YP2)
               CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
            ENDIF
            CALL COORDINQXYZ(XM(2),YM(3-IY1),Z1,XP1,YP1)
            CALL COORDINQXYZ(XM(2),YM(3-IY1),Z0,XP2,YP2)
            CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
            IF (IND1.EQ.2) THEN
               CALL COORDINQXYZ(XM(1),YM(IY1),Z0,XP1,YP1)
               CALL GWIOLINE(XP2,YP2,XP1,YP1,0)
               CALL COORDINQXYZ(XM(1),YM(IY1),Z1,XP2,YP2)
               CALL GWIOLINE(XP2,YP2,XP1,YP1,0)
               RETURN
            ENDIF
         ENDIF
         IF (IOFR.EQ.0) THEN
            IF (IAX.NE.0) THEN
              CALL FRAMESAXIS1(1,XM,YM(IY),ZM(1),IB,1,IN,YM(IY),ZM(2))
            ENDIF
            IF (IAY.NE.0) THEN
              CALL FRAMESAXIS1(2,YM,ZM(1),XM(IX),-IB,1,-IN,ZM(2),XM(IX))
            ENDIF
          CALL FRAMESAXIS1(3,ZM,XM(1),YM(IY1),IB1,1,IN1,XM(IX2),YM(IY2))
         ENDIF
      ENDIF

  100 CONTINUE
      IF (IND1.GE.2) THEN
         CALL COORDINQXYZ(XM(1),YM(1),Z1,XP1,YP1)
         CALL COORDINQXYZ(XM(2),YM(1),Z1,XP2,YP2)
         CALL GWIOLINE(XP1,YP1,XP2,YP2,0)
         CALL COORDINQXYZ(XM(2),YM(2),Z1,XP3,YP3)
         CALL GWIOLINE(XP2,YP2,XP3,YP3,0)
         CALL COORDINQXYZ(XM(1),YM(2),Z1,XP2,YP2)
         CALL GWIOLINE(XP3,YP3,XP2,YP2,0)
         CALL GWIOLINE(XP2,YP2,XP1,YP1,0)
      ENDIF

      RETURN
      END

      SUBROUTINE FRAMESAXIS1(IAX,AM,A1,A2,IBX,ITC,INUM,A11,A12)
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      CHARACTER CH*20,FORM*20
      REAL AM(2)

      AMIN = AM(1)
      AMAX = AM(2)
      IF (IAX.EQ.1) THEN
         CALL COORDINQXYZ(AMIN,A1,A2,XP1,YP1)
         CALL COORDINQXYZ(AMAX,A1,A2,XP2,YP2)
         CALL COORDINQXYZ(AMIN,A11,A12,XP3,YP3)
         CS   = XP3 - XP1
         SN   = YP3 - YP1
         R    = SQRT(CS*CS + SN*SN)
         TCX  = 4*CS/R
         TCY  = 4*SN/R
         CRX  = -TCX*3/2
         CRY  = -TCY*3/2
         ITC2 = ITC
         ACX  = (A11-A1)*4/R
         ACY  = (A12-A2)*4/R
       ELSE IF (IAX.EQ.2) THEN
         CALL COORDINQXYZ(A2,AMIN,A1,XP1,YP1)
         CALL COORDINQXYZ(A2,AMAX,A1,XP2,YP2)
         CALL COORDINQXYZ(A12,AMIN,A11,XP3,YP3)
         CS   = XP3 - XP1
         SN   = YP3 - YP1
         R    = SQRT(CS*CS + SN*SN)
         TCX  = 4*CS/R
         TCY  = 4*SN/R
         CRX  = -TCX*3/2
         CRY  = -TCY*3/2
         ITC2 = ITC
         ACX  = (A11-A1)*4/R
         ACY  = (A12-A2)*4/R
       ELSE
         CALL COORDINQXYZ(A1,A2,AMIN,XP1,YP1)
         CALL COORDINQXYZ(A1,A2,AMAX,XP2,YP2)
         CALL COORDINQXYZ(A11,A12,AMIN,XP3,YP3)
         CS   = XP3 - XP1
         SN   = YP3 - YP1
         R    = SQRT(CS*CS + SN*SN)
*         TCX  = 4*CS/R
*         TCY  = 4*SN/R
         INM3 = INUM*2
         ACX  = (A11-A1)*4/R
         ACY  = (A12-A2)*4/R
      ENDIF

      IF (MOD(LABELAX,2).EQ.1) THEN
         IXNUM = 0
       ELSE
         IXNUM = 1
      ENDIF

      IF (MOD(LABELAX/2,2).EQ.1) THEN
         IYNUM = 0
       ELSE
         IYNUM = 1
      ENDIF

      IF (LABELAX/4.EQ.1) THEN
         IZNUM = 0
       ELSE
         IZNUM = 1
      ENDIF
      LABELAX = 0

      CALL GWIOLINE(XP1,YP1,XP2,YP2,0)

      IF (AMIN.GT.AMAX) THEN
         DA   = AMAX
         AMAX = AMIN
         AMIN = DA
      ENDIF

      CALL AXISDELFORM(AMIN,AMAX,DA,FORM,NS,NSC,NS1,NMZ,1)
      IF (NMZ.NE.0) THEN
         AMIN = AMIN*10.D0**(-NMZ)
         AMAX = AMAX*10.D0**(-NMZ)
      ENDIF
      DAR  = DA*10.D0**(NMZ)

      AMIN = AMIN - 0.001*DA
      AMAX = AMAX + 0.001*DA
      NM   = INT(AMIN/DA) - 1
      AAT  = NM*DA
      AAR  = NM*DAR

1000  IF (AAT.LT.AMIN) THEN
         NM  = NM + 1
         AAT = DA*NM
         AAR = DAR*NM
         GO TO 1000
      ENDIF
      IF (IAX.EQ.1) THEN
1010     IF (AAT.LT.AMAX) THEN
            CALL COORDINQXYZ(AAR,A1,A2,PAX,PAY)
            AC1 = ACX
            AC2 = ACY
            IF (MOD(NM,NS).EQ.0) THEN
               WRITE(CH,FORM) AAT
               AC1 = ACX*2
               AC2 = ACY*2
               IF (MOD(NM,NSC).EQ.0) THEN
                  IF (IXNUM.EQ.1) THEN
                   CALL FWNUMBER(PAX+CRX,PAY+CRY,CH,NMZ,IBX,ITC2,INUM,1)
                  ENDIF
                ELSE IF (NS1.EQ.1) THEN
                  AC1 = ACX*1.5
                  AC2 = ACY*1.5
               ENDIF
            ENDIF
            CALL COORDINQXYZ(AAR,A1+AC1,A2+AC2,PAX1,PAY1)
            CALL GWIOLINE(PAX,PAY,PAX1,PAY1,0)
            NM  = NM + 1
            AAT = NM*DA
            AAR = NM*DAR
            GO TO 1010
         ENDIF
       ELSE IF (IAX.EQ.2) THEN
1020     IF (AAT.LT.AMAX) THEN
            CALL COORDINQXYZ(A2,AAR,A1,PAX,PAY)
            AC1 = ACX
            AC2 = ACY
            IF (MOD(NM,NS).EQ.0) THEN
               WRITE(CH,FORM) AAT
               AC1 = ACX*2
               AC2 = ACY*2
               IF (MOD(NM,NSC).EQ.0) THEN
                  IF (IYNUM.EQ.1) THEN
                   CALL FWNUMBER(PAX+CRX,PAY+CRY,CH,NMZ,IBX,ITC2,INUM,1)
                  ENDIF
                ELSE IF (NS1.EQ.1) THEN
                  AC1 = ACX*1.5
                  AC2 = ACY*1.5
               ENDIF
            ENDIF
            CALL COORDINQXYZ(A2+AC2,AAR,A1+AC1,PAX1,PAY1)
            CALL GWIOLINE(PAX,PAY,PAX1,PAY1,0)
            NM  = NM + 1
            AAT = NM*DA
            AAR = NM*DAR
            GO TO 1020
          ENDIF
       ELSE
1030     IF (AAT.LT.AMAX) THEN
            CALL COORDINQXYZ(A1,A2,AAR,PAX,PAY)
            AC1 = ACX
            AC2 = ACY
            IF (MOD(NM,NS).EQ.0) THEN
               WRITE(CH,FORM) AAT
               AC1 = ACX*2
               AC2 = ACY*2
               IF (MOD(NM,NSC).EQ.0) THEN
                  IF (IZNUM.EQ.1) THEN
                     CALL FWNUMBER(PAX,PAY,CH,NMZ,IBX,-ITC,INM3,1)
                  ENDIF
                ELSE IF (NS1.EQ.1) THEN
                  AC1 = ACX*1.5
                  AC2 = ACY*1.5
               ENDIF
            ENDIF
            CALL COORDINQXYZ(A1+AC1,A2+AC2,AAR,PAX1,PAY1)
            CALL GWIOLINE(PAX,PAY,PAX1,PAY1,0)
            NM  = NM + 1
            AAT = NM*DA
            AAR = NM*DAR
            GO TO 1030
          ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE COORDINQXYZ(XQ,YQ,ZQ,XP,YP)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR

      IF (MOD3DIR.EQ.1) THEN
         X = ZQ
         Y = XQ
         Z = YQ
       ELSE IF (MOD3DIR.EQ.2) THEN
         X = YQ
         Y = ZQ
         Z = XQ
       ELSE
         X = XQ
         Y = YQ
         Z = ZQ
      ENDIF

      XP1 = XPX*X + XPY*Y + XPZ*Z + XP0
      YP1 = YPX*X + YPY*Y + YPZ*Z + YP0
      IF (MDPROJ.NE.0) THEN
         ZP  = ZPX*X + ZPY*Y + ZPZ*Z + ZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END

      SUBROUTINE FR_GRAPH3D(X,Y,Z,N,ICOL,MODE)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X(N),Y(N),Z(N),X1,X2,Y1,Y2,Z1,Z2,DX,DY,DZ
      REAL*8 XR1,XR2,YR1,YR2,ZR1,ZR2
      INTEGER ICOL(*),ICSP(7)

      IF (IGCANVAS.LT.0) RETURN

      IND = MOD(MODE,100)
      M1  = ABS(MODE/100)
      IC  = ICOL(1)
      IC1 = MOD(IC,100)
      IC2 = IC/100
      ICM = 2

      IF (IFRAM.EQ.0) THEN
         IF (M1.EQ.0) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO 100 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
  100       CONTINUE
          ELSE IF (M1.EQ.1) THEN
            X1 = X(1)
            X2 = X1
            IF (X1.GT.X(2)) X1 = X(2)
            IF (X2.LT.X(2)) X2 = X(2)
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO 101 I = 2, N
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
  101        CONTINUE
          ELSE IF (M1.EQ.2) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            IF (Y1.GT.Y(2)) Y1 = Y(2)
            IF (Y2.LT.Y(2)) Y2 = Y(2)
            Z1 = Z(1)
            Z2 = Z1
            DO 102 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
  102       CONTINUE
          ELSE IF (M1.EQ.3) THEN
            X1 = X(1)
            X2 = X1
            IF (X1.GT.X(2)) X1 = X(2)
            IF (X2.LT.X(2)) X2 = X(2)
            Y1 = Y(1)
            Y2 = Y1
            IF (Y1.GT.Y(2)) Y1 = Y(2)
            IF (Y2.LT.Y(2)) Y2 = Y(2)
            Z1 = Z(1)
            Z2 = Z1
            DO 103 I = 2, N
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
  103       CONTINUE
          ELSE IF (M1.EQ.5) THEN
            X1 = X(1)
            X2 = X1
            IF (X1.GT.X(2)) X1 = X(2)
            IF (X2.LT.X(2)) X2 = X(2)
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            IF (Z1.GT.Z(2)) Z1 = Z(2)
            IF (Z2.LT.Z(2)) Z2 = Z(2)
            DO 105 I = 2, N
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
  105       CONTINUE
          ELSE IF (M1.EQ.6) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            IF (Y1.GT.Y(2)) Y1 = Y(2)
            IF (Y2.LT.Y(2)) Y2 = Y(2)
            Z1 = Z(1)
            Z2 = Z1
            IF (Z1.GT.Z(2)) Z1 = Z(2)
            IF (Z2.LT.Z(2)) Z2 = Z(2)
            DO 106 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
  106       CONTINUE
          ELSE
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            IF (Z1.GT.Z(2)) Z1 = Z(2)
            IF (Z2.LT.Z(2)) Z2 = Z(2)
            DO 104 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
  104        CONTINUE
         ENDIF
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         IF (X1.EQ.X2) THEN
            IF (X1.EQ.0) THEN
               X2 = 1
             ELSE IF (X1.GT.0) THEN
               X1 = 0
             ELSE
               X2 = 0
            ENDIF
          ELSE IF (Y1.EQ.Y2) THEN
            IF (Y1.EQ.0) THEN
               Y2 = 1
             ELSE IF (Y1.GT.0) THEN
               Y1 = 0
             ELSE
               Y2 = 0
            ENDIF
          ELSE IF (Z1.EQ.Z2) THEN
            IF (Z1.EQ.0) THEN
               Z2 = 1
             ELSE IF (Z1.GT.0) THEN
               Z1 = 0
             ELSE
               Z2 = 0
            ENDIF
         ENDIF
         CALL FR_FRAME3D(X1,X2,Y1,Y2,Z1,Z2,IDFR)
      ENDIF

      ICOLMODE = 0
      IF (IND.EQ.-3) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC1.GE.0) THEN
               CALL HLSSPHERECOLORSET(ICOL,1)
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC1.GE.0) THEN
            CALL HLSSPHERECOLORSET(ICOL,-1)
         ENDIF
       ELSE IF (IND.EQ.-13) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC1.GE.0) THEN
               DO 1 I = 1, 7
                  ICSP(I) = -1
    1          CONTINUE
               DO 2 I = 1, N
                  IF (ICOL(I).GE.1.AND.ICOL(I).LE.7) ICSP(ICOL(I)) = 1
    2          CONTINUE
               DO 3 I = 1, 7
                  IF (ICSP(I).EQ.1) CALL HLSSPHERECOLORSET(I,1)
    3          CONTINUE
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC1.GE.0) THEN
               DO 4 I = 1, 7
                  ICSP(I) = -1
    4          CONTINUE
               DO 5 I = 1, N
                  IF (ICOL(I).GE.1.AND.ICOL(I).LE.7) ICSP(ICOL(I)) = 1
    5          CONTINUE
               DO 6 I = 1, 7
                  IF (ICSP(I).EQ.1) CALL HLSSPHERECOLORSET(I,-1)
    6          CONTINUE
         ENDIF
       ELSE
         IF (IC.LT.0) THEN
            ICM = 256
            IC0 = -IC - 1
            IC1 = MOD(IC0,1000)
            IC2 = IC0/1000
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
          ELSE
            IC1 = MOD(IC,100)
            IC2 = IC/100
         ENDIF
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(66,1)
         CALL GSENDBYTE(MODE,2)
         IF (IND.EQ.-13) THEN
            CALL GSENDBYTE(N,4)
            DO 7 I = 1, N
               CALL GSENDBYTE(ICOL(I),1)
    7        CONTINUE
          ELSE
            CALL GSENDBYTE(IC,2)
            CALL GSENDBYTE(N,4)
         ENDIF
         IF (M1.EQ.0) THEN
            CALL GSEND38BYTE(X,Y,Z,N,1)
          ELSE IF (M1.EQ.1) THEN
            CALL GSEND8BYTE(X(1),X(2),1,0)
            CALL GSEND38BYTE(X,Y,Z,N,5)
          ELSE IF (M1.EQ.2) THEN
            CALL GSEND8BYTE(Y(1),Y(2),1,0)
            CALL GSEND38BYTE(X,Y,Z,N,6)
          ELSE IF (M1.EQ.3) THEN
            CALL GSEND8BYTE(X(1),X(2),1,0)
            CALL GSEND8BYTE(Y(1),Y(2),1,0)
            CALL GSEND38BYTE(X,Y,Z,N,0)
          ELSE IF (M1.EQ.5) THEN
            CALL GSEND8BYTE(X(1),X(2),1,0)
            CALL GSEND8BYTE(Z(1),Z(2),1,0)
            CALL GSEND8BYTE(X,Y,N,6)
          ELSE IF (M1.EQ.6) THEN
            CALL GSEND8BYTE(Y(1),Y(2),1,0)
            CALL GSEND8BYTE(Z(1),Z(2),1,0)
            CALL GSEND8BYTE(X,Y,N,5)
          ELSE
            CALL GSEND8BYTE(Z(1),Z(2),1,0)
            CALL GSEND38BYTE(X,Y,Z,N,7)
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 9999

      IF (NSTEP.GT.0) THEN
         NS = NSTEP
         NM = N
       ELSE IF (NSTEP.EQ.0) THEN
         NS = 1
         NM = N
       ELSE
         NS = -NSTEP
         NM = N*NS
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 9999
      CALL GWIOSETAASPACE(1)
      CALL GWIOCOLOR(ICM,IC1)

      IF (M1.EQ.0) THEN
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 10 I = NS+1, NM, NS
              CALL COORDINXYZ(X(I),Y(I),Z(I),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
   10       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 20 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                 CALL GWIOPSET(XX,YY)
   20          CONTINUE
             ELSE
               DO 21 I = 1, NM, NS
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                    CALL GWIOPSET(XX,YY)
                 ENDIF
   21          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
   31       IF (ICLP3D.EQ.0) THEN
               DO 30 I = 1, NM, NS
                  CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                  CALL GWIOMARKING(XX,YY,IM)
   30          CONTINUE
             ELSE
               DO 32 I = 1, NM, NS
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                     CALL GWIOMARKING(XX,YY,IM)
                  ENDIF
   32          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 31
            ENDIF
          ELSE IF (IND.EQ.-3.OR.IND.EQ.-13) THEN
            CALL MALLOCSPHGRAPHCORE(X,Y,Z,NM,NS,ICOL,IND/10,IER)
            IF (IER.NE.0) THEN
               CALL FRAMESERROR('SPHERE GRAPH IS MEMORY SHORTAGE !')
            ENDIF
          ELSE IF (IND.EQ.4.OR.IND.EQ.5) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 40 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                 CALL COORDINXYZ(X(I+1),Y(I+1),Z(I+1),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
   40          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 41 I = 1, NM, NS
                  XR1 = X(I)
                  YR1 = Y(I)
                  ZR1 = Z(I)
                  XR2 = X(I+1)
                  YR2 = Y(I+1)
                  ZR2 = Z(I+1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
   41          CONTINUE
             ELSE
               DO 42 I = 1, NM, NS
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
                     CALL COORDINXYZ(X(I+1),Y(I+1),Z(I+1),XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
   42          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.6) THEN
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               CALL COORDINDXYZ(X(1),Y(1),Z(1),X(2),Y(2),Z(2)
     ,                                        ,XX1,YY1,DX1,DY1)
               DO 60 I = NS+1, NM, NS
                 CALL COORDINDXYZ(X(I),Y(I),Z(I),X(I+1),Y(I+1),Z(I+1)
     ,                                        ,XX2,YY2,DX2,DY2)
                 CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX2,YY2,DY2)
                 XX1  = XX2
                 YY1  = YY2
                 DX1  = DX2
                 DY1  = DY2
   60          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
               CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
               DO 50 I = NS+1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),Z(I),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,0)
                 XX  = XX1
                 YY  = YY1
   50          CONTINUE
             ELSE
               I1 = 1
               DO 51 I = NS+1, NM, NS
                  XR1 = X(I1)
                  YR1 = Y(I1)
                  ZR1 = Z(I1)
                  XR2 = X(I)
                  YR2 = Y(I)
                  ZR2 = Z(I)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
   51          CONTINUE
            ENDIF
         ENDIF

       ELSE IF (M1.EQ.1) THEN
         IF (NM.LE.1) THEN
            DX = 1
          ELSE
            DX = (X(2)-X(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 110 I = NS+1, NM, NS
              CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),Z(I),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  110       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 120 I = 1, NM, NS
                  CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),Z(I),XX,YY)
                  CALL GWIOPSET(XX,YY)
  120          CONTINUE
             ELSE
               DO 121 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y(I),Z(I),XX,YY)
                     CALL GWIOPSET(XX,YY)
                  ENDIF
  121          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  131       IF (ICLP3D.EQ.0) THEN
               DO 130 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),Z(I),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  130          CONTINUE
             ELSE
               DO 132 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y(I),Z(I),XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                  ENDIF
  132          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 131
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 140 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),Z(I),XX,YY)
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I+1),Z(I+1),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  140          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 141 I = 1, NM, NS
                  XR1 = DX*(I-1)+X(1)
                  YR1 = Y(I)
                  ZR1 = Z(I)
                  XR2 = XR1
                  YR2 = Y(I+1)
                  ZR2 = Z(I+1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  141          CONTINUE
             ELSE
               DO 142 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y(I),Z(I),XX,YY)
                     CALL COORDINXYZ(X1,Y(I+1),Z(I+1),XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  142          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
               CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
               DO 150 I = NS+1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),Z(I),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,0)
                 XX  = XX1
                 YY  = YY1
  150          CONTINUE
             ELSE
               I1 = 1
               DO 151 I = NS+1, NM, NS
                  XR1 = DX*(I1-1)+X(1)
                  YR1 = Y(I1)
                  ZR1 = Z(I1)
                  XR2 = DX*(I-1)+X(1)
                  YR2 = Y(I)
                  ZR2 = Z(I)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  151          CONTINUE
            ENDIF
         ENDIF

       ELSE IF (M1.EQ.2) THEN
         IF (NM.LE.1) THEN
            DY = 1
          ELSE
            DY = (Y(2)-Y(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),DY*(I-1)+Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 210 I = NS+1, NM, NS
              CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),Z(I),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  210       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 220 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),Z(I),XX,YY)
                 CALL GWIOPSET(XX,YY)
  220          CONTINUE
             ELSE
               DO 221 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y1,Z(I),XX,YY)
                    CALL GWIOPSET(XX,YY)
                  ENDIF
  221          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  231       IF (ICLP3D.EQ.0) THEN
               DO 230 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),Z(I),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  230          CONTINUE
             ELSE
               DO 232 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y1,Z(I),XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                  ENDIF
  232          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 231
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 240 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),Z(I),XX,YY)
                 CALL COORDINXYZ(X(I+1),DY*(I-1)+Y(1),Z(I+1),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  240          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 241 I = 1, NM, NS
                  XR1 = X(I)
                  YR1 = DY*(I-1)+Y(1)
                  ZR1 = Z(I)
                  XR2 = X(I+1)
                  YR2 = YR1
                  ZR2 = Z(I+1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  241          CONTINUE
             ELSE
               DO 242 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X(I),Y1,Z(I),XX,YY)
                     CALL COORDINXYZ(X(I+1),Y1,Z(I+1),XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  242          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
               CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
               DO 250 I = NS+1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),Z(I),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,0)
                 XX  = XX1
                 YY  = YY1
  250          CONTINUE
             ELSE
               I1 = 1
               DO 251 I = NS+1, NM, NS
                  XR1 = X(I1)
                  YR1 = DY*(I1-1)+Y(1)
                  ZR1 = Z(I1)
                  XR2 = X(I)
                  YR2 = DY*(I-1)+Y(1)
                  ZR2 = Z(I)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  251          CONTINUE
            ENDIF
         ENDIF

       ELSE IF (M1.EQ.3) THEN
         IF (NM.LE.1) THEN
            DX = 1
          ELSE
            DX = (X(2)-X(1))/(NM-1)
         ENDIF
         IF (NM.LE.1) THEN
            DY = 1
          ELSE
            DY = (Y(2)-Y(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),DY*(I-1)+Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 310 I = NS+1, NM, NS
              CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  310       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 320 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I),XX,YY)
                 CALL GWIOPSET(XX,YY)
  320          CONTINUE
             ELSE
               DO 321 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Y1 = DY*(I-1)+Y(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y1,Z(I),XX,YY)
                     CALL GWIOPSET(XX,YY)
                  ENDIF
  321          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  331       IF (ICLP3D.EQ.0) THEN
               DO 330 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  330          CONTINUE
             ELSE
               DO 332 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Y1 = DY*(I-1)+Y(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y1,Z(I),XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                  ENDIF
  332          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 331
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 340 I = 1, NM, NS
                CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I),XX,YY)
            CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I+1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  340          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 341 I = 1, NM, NS
                  XR1 = DX*(I-1)+X(1)
                  YR1 = DY*(I-1)+Y(1)
                  ZR1 = Z(I)
                  XR2 = XR1
                  YR2 = YR1
                  ZR2 = Z(I+1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  341          CONTINUE
             ELSE
               DO 342 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Y1 = DY*(I-1)+Y(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y1,Z(I),XX,YY)
                     CALL COORDINXYZ(X1,Y1,Z(I+1),XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  342          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
              CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
              DO 350 I = NS+1, NM, NS
               CALL COORDINXYZ(DX*(I-1)+X(1),DY*(I-1)+Y(1),Z(I),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,0)
                XX  = XX1
                YY  = YY1
  350         CONTINUE
             ELSE
               I1 = 1
               DO 351 I = NS+1, NM, NS
                  XR1 = DX*(I1-1)+X(1)
                  YR1 = DY*(I1-1)+Y(1)
                  ZR1 = Z(I1)
                  XR2 = DX*(I-1)+X(1)
                  YR2 = DY*(I-1)+Y(1)
                  ZR2 = Z(I)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  351          CONTINUE
            ENDIF
         ENDIF

       ELSE IF (M1.EQ.5) THEN
         IF (NM.LE.1) THEN
            DX = 1
          ELSE
            DX = (X(2)-X(1))/(NM-1)
         ENDIF
         IF (NM.LE.1) THEN
            DZ = 1
          ELSE
            DZ = (Z(2)-Z(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 510 I = NS+1, NM, NS
              CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),DZ*(I-1)+Z(1),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  510       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 520 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOPSET(XX,YY)
  520          CONTINUE
             ELSE
               DO 521 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X1,Y(I),Z1,XX,YY)
                    CALL GWIOPSET(XX,YY)
                 ENDIF
  521          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  531       IF (ICLP3D.EQ.0) THEN
               DO 530 I = 1, NM, NS
                 CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  530          CONTINUE
             ELSE
               DO 532 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X1,Y(I),Z1,XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                 ENDIF
  532          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 531
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 540 I = 1, NM, NS
                CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),DZ*(I-1)+Z(1),XX,YY)
            CALL COORDINXYZ(DX*(I-1)+X(1),Y(I+1),DZ*(I-1)+Z(1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  540          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 541 I = 1, NM, NS
                  XR1 = DX*(I-1)+X(1)
                  YR1 = Y(I)
                  ZR1 = DZ*(I-1)+Z(1)
                  XR2 = XR1
                  YR2 = Y(I+1)
                  ZR2 = ZR1
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  541          CONTINUE
             ELSE
               DO 542 I = 1, NM, NS
                  X1 = DX*(I-1)+X(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X1.GE.tdx1.AND.X1.LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                     CALL COORDINXYZ(X1,Y(I),Z1,XX,YY)
                     CALL COORDINXYZ(X1,Y(I+1),Z1,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  542          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
              CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
              DO 550 I = NS+1, NM, NS
               CALL COORDINXYZ(DX*(I-1)+X(1),Y(I),DZ*(I-1)+Z(1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,0)
                XX  = XX1
                YY  = YY1
  550         CONTINUE
             ELSE
               I1 = 1
               DO 551 I = NS+1, NM, NS
                  XR1 = DX*(I1-1)+X(1)
                  YR1 = Y(I1)
                  ZR1 = DZ*(I1-1)+Z(1)
                  XR2 = DX*(I-1)+X(1)
                  YR2 = Y(I)
                  ZR2 = DZ*(I-1)+Z(1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  551          CONTINUE
            ENDIF
         ENDIF

       ELSE IF (M1.EQ.6) THEN
         IF (NM.LE.1) THEN
            DY = 1
          ELSE
            DY = (Y(2)-Y(1))/(NM-1)
         ENDIF
         IF (NM.LE.1) THEN
            DZ = 1
          ELSE
            DZ = (Z(2)-Z(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),DY*(I-1)+Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 610 I = NS+1, NM, NS
              CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  610       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 620 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOPSET(XX,YY)
  620          CONTINUE
             ELSE
               DO 621 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y1,Z1,XX,YY)
                    CALL GWIOPSET(XX,YY)
                 ENDIF
  621          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  631       IF (ICLP3D.EQ.0) THEN
               DO 630 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  630          CONTINUE
             ELSE
               DO 632 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y1,Z1,XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                 ENDIF
  632          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 631
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 640 I = 1, NM, NS
                CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),XX,YY)
            CALL COORDINXYZ(X(I+1),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  640          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 641 I = 1, NM, NS
                  XR1 = X(I)
                  YR1 = DY*(I-1)+Y(1)
                  ZR1 = DZ*(I-1)+Z(1)
                  XR2 = X(I+1)
                  YR2 = YR1
                  ZR2 = ZR1
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  641          CONTINUE
             ELSE
               DO 642 I = 1, NM, NS
                  Y1 = DY*(I-1)+Y(1)
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y1.GE.tdy1.AND.Y1.LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                     CALL COORDINXYZ(X(I),Y1,Z1,XX,YY)
                     CALL COORDINXYZ(X(I+1),Y1,Z1,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  642          CONTINUE
            ENDIF
          ELSE
            CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
            IF (ICLP3D.EQ.0) THEN
              DO 650 I = NS+1, NM, NS
               CALL COORDINXYZ(X(I),DY*(I-1)+Y(1),DZ*(I-1)+Z(1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,0)
                XX  = XX1
                YY  = YY1
  650         CONTINUE
             ELSE
               I1 = 1
               DO 651 I = NS+1, NM, NS
                  XR1 = X(I1)
                  YR1 = DY*(I1-1)+Y(1)
                  ZR1 = DZ*(I1-1)+Z(1)
                  XR2 = X(I)
                  YR2 = DY*(I-1)+Y(1)
                  ZR2 = DZ*(I-1)+Z(1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  651          CONTINUE
            ENDIF
         ENDIF

       ELSE
         IF (NM.LE.1) THEN
            DZ = 1
          ELSE
            DZ = (Z(2)-Z(1))/(NM-1)
         ENDIF
         IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
            CALL COORDINXYZ(X(1),Y(1),Z(1),PX,PY)
            PXMIN = PX
            PXMAX = PX
            DO 410 I = NS+1, NM, NS
              CALL COORDINXYZ(X(I),Y(I),DZ*(I-1)+Z(1),PX1,PY1)
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  410       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (IND.EQ.2.OR.IND.EQ.-2) THEN
            IF (ICLP3D.EQ.0) THEN
               DO 420 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOPSET(XX,YY)
  420          CONTINUE
             ELSE
               DO 421 I = 1, NM, NS
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y(I),Z1,XX,YY)
                    CALL GWIOPSET(XX,YY)
                 ENDIF
  421          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  431       IF (ICLP3D.EQ.0) THEN
               DO 430 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),DZ*(I-1)+Z(1),XX,YY)
                 CALL GWIOMARKING(XX,YY,IM)
  430          CONTINUE
             ELSE
               DO 432 I = 1, NM, NS
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                    CALL COORDINXYZ(X(I),Y(I),Z1,XX,YY)
                    CALL GWIOMARKING(XX,YY,IM)
                 ENDIF
  432          CONTINUE
            ENDIF
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 431
            ENDIF
          ELSE IF (IND.GE.4) THEN
            IF (IND.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            IF (ICLP3D.EQ.0) THEN
               DO 440 I = 1, NM, NS
                 CALL COORDINXYZ(X(I),Y(I),DZ*(I-1)+Z(1),XX,YY)
                 CALL COORDINXYZ(X(I+1),Y(I+1),DZ*(I-1)+Z(1),XX1,YY1)
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  440          CONTINUE
             ELSE IF (IM.EQ.0) THEN
               DO 441 I = 1, NM, NS
                  XR1 = X(I)
                  YR1 = Y(I)
                  ZR1 = DZ*(I-1)+Z(1)
                  XR2 = X(I+1)
                  YR2 = Y(I+1)
                  ZR2 = ZR1
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  441          CONTINUE
             ELSE
               DO 442 I = 1, NM, NS
                  Z1 = DZ*(I-1)+Z(1)
                  IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                  Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                    Z1.GE.tdz1.AND.Z1.LE.tdz2) THEN
                     CALL COORDINXYZ(X(I),Y(I),Z1,XX,YY)
                     CALL COORDINXYZ(X(I+1),Y(I+1),Z1,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                  ENDIF
  442          CONTINUE
            ENDIF
          ELSE
            IF (ICLP3D.EQ.0) THEN
              CALL COORDINXYZ(X(1),Y(1),Z(1),XX,YY)
              DO 450 I = NS+1, NM, NS
                CALL COORDINXYZ(X(I),Y(I),DZ*(I-1)+Z(1),XX1,YY1)
                CALL GWIOLINE(XX,YY,XX1,YY1,0)
                XX  = XX1
                YY  = YY1
  450         CONTINUE
             ELSE
               I1 = 1
               DO 451 I = NS+1, NM, NS
                  XR1 = X(I1)
                  YR1 = Y(I1)
                  ZR1 = DZ*(I1-1)+Z(1)
                  XR2 = X(I)
                  YR2 = Y(I)
                  ZR2 = DZ*(I-1)+Z(1)
                  CALL GWIOCLIP3D(XR1,YR1,ZR1,XR2,YR2,ZR2,ICL)
                  IF (ICL.NE.0) THEN
                     CALL COORDINXYZ(XR1,YR1,ZR1,XX,YY)
                     CALL COORDINXYZ(XR2,YR2,ZR2,XX1,YY1)
                     CALL GWIOLINE(XX,YY,XX1,YY1,0)
                  ENDIF
                  I1 = I
  451          CONTINUE
            ENDIF
         ENDIF
      ENDIF

  999 CALL GWIOBDFLUSH(1)

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

 9999 IF (ICOLMODE.NE.0) CALL HLSSPHERECOLORSET(IC,0)
      RETURN
      END

      SUBROUTINE SPHEREGRAPHMAIN(X,Y,Z,NM,NS,CC,IND,WS,HS)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X(*),Y(*),Z(*)
      REAL*4 WS(*)
      INTEGER CC(*),HS(*)
      INTEGER L,R,S,SB0(20),SB1(20)

      IW = 0
      IC = CC(1)
      IF (MDPROJ.EQ.0) THEN
         IF (ICLP3D.EQ.0) THEN
            DO 10 I = 1, NM, NS
               IW = IW + 1
               WS(IW) = (ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
               HS(IW) = I
   10       CONTINUE
          ELSE
            DO 11 I = 1, NM, NS
               IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                     Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                       Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                  IW = IW + 1
                  WS(IW) = (ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
                  HS(IW) = I
               ENDIF
   11       CONTINUE
         ENDIF
       ELSE
         ZZ = ZSCALE*ZSCALE
         IF (ICLP3D.EQ.0) THEN
            DO 20 I = 1, NM, NS
               IW = IW + 1
               XP  = XPX*X(I) + XPY*Y(I) + XPZ*Z(I) + XP0
               YP  = YPX*X(I) + YPY*Y(I) + YPZ*Z(I) + YP0
               ZP  = ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I) + ZP0
               WS(IW) = -(XP*XP+YP*YP+ZZ*(1-ZP)*(1-ZP))
*               WS(IW) = (ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
               HS(IW) = I
   20       CONTINUE
          ELSE
            DO 21 I = 1, NM, NS
               IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                     Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                       Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                  IW = IW + 1
                  XP  = XPX*X(I) + XPY*Y(I) + XPZ*Z(I) + XP0
                  YP  = YPX*X(I) + YPY*Y(I) + YPZ*Z(I) + YP0
                  ZP  = ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I) + ZP0
                  WS(IW) = -(XP*XP+YP*YP+ZZ*(1-ZP)*(1-ZP))
*                  WS(IW) = (ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
                  HS(IW) = I
               ENDIF
   21       CONTINUE
         ENDIF
      ENDIF

*     QUICK SORTING FROM FAR POINT TO NEAR POINT
      K      = 1
      SB0(1) = 1
      SB1(1) = IW

  100 IF (K.GT.0) THEN
         L = SB0(K)
         R = SB1(K)
         K = K - 1
  200    IF (L.LT.R) THEN
            I = L
            J = R
            W = WS((L+R)/2)
  300       IF (I.LE.J) THEN
** LEFT HANDED SYSTEM **
  400          IF (WS(I).LT.W) THEN
                  I = I + 1
                  GO TO 400
               ENDIF
  500          IF (WS(J).GT.W) THEN
                  J = J - 1
                  GO TO 500
               ENDIF
               IF (I.LE.J) THEN
                  D      = WS(I)
                  WS(I)  = WS(J)
                  WS(J)  = D
                  S      = HS(I)
                  HS(I)  = HS(J)
                  HS(J)  = S
                  I = I + 1
                  J = J - 1
               ENDIF
               GO TO 300
            ENDIF
            IF (J-L.LT.R-I) THEN
               IF (I.LT.R) THEN
                  K      = K + 1
                  SB0(K) = I
                  SB1(K) = R
                  R      = J
                ELSE
                  R = J
               ENDIF
             ELSE IF (L.LT.J) THEN
               K      = K + 1
               SB0(K) = L
               SB1(K) = J
               L      = I
             ELSE
               L = I
           ENDIF
           GO TO 200
        ENDIF
        GO TO 100
      ENDIF

      IF (MDPROJ.NE.0) THEN
         IF (IND.EQ.0) THEN
            DO 30 I1 = 1, IW
               I = HS(I1)
               CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
               ZP = ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I) + ZP0
               ZP = 1.0/(1-ZP)
               CALL GWIOGRADCIRCLE(XX,YY,ZP,IC)
   30       CONTINUE
          ELSE
            DO 31 I1 = 1, IW
               I = HS(I1)
               CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
               ZP = ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I) + ZP0
               ZP = 1.0/(1-ZP)
               CALL GWIOGRADCIRCLE(XX,YY,ZP,CC(I))
   31       CONTINUE
         ENDIF
       ELSE
         IF (IND.EQ.0) THEN
            ZP = 1
            DO 40 I1 = 1, IW
               I = HS(I1)
               CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
               CALL GWIOGRADCIRCLE(XX,YY,ZP,IC)
   40       CONTINUE
          ELSE
            ZP = 1
            DO 41 I1 = 1, IW
               I = HS(I1)
               CALL COORDINXYZ(X(I),Y(I),Z(I),XX,YY)
               CALL GWIOGRADCIRCLE(XX,YY,ZP,CC(I))
   41       CONTINUE
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_DRAW3D(X,Y,Z,IC,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X,Y,Z

      IF (IGCANVAS.LT.0) RETURN

      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR DRAW3D')
         RETURN
      ENDIF

      ICM      = 2
      IC1      = IC
      ICOLMODE = 0
      IF (IND.EQ.-3) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC.GE.0) THEN
               CALL HLSSPHERECOLORSET(IC,1)
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC.GE.0) THEN
            CALL HLSSPHERECOLORSET(IC,-1)
         ENDIF
       ELSE IF (IC.LT.0) THEN
         ICM = 256
         IC1 = -IC - 1
         IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(67,1)
         CALL GSENDBYTE(IND,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND38BYTE(X,Y,Z,1,1)
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 9999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 9999
      IF (IND.EQ.-3) CALL GWIOSETAASPACE(1)
      CALL GWIOCOLOR(ICM,IC1)

      IF (IND.EQ.-1.AND.IHIND.NE.0) THEN
         CALL COORDINXYZ(X,Y,Z,GX1,GY1)
         CALL HGWIOLINE(GX,GY,GX1,GY1)
         IF (GX1.LT.GX) THEN
            GG1 = GX1
            GG2 = GX
          ELSE
            GG1 = GX
            GG2 = GX1
         ENDIF
         CALL SETHIDDEN(GG1,GG2)
         GX = GX1
         GY = GY1
       ELSE IF (IND.EQ.0) THEN
         CALL COORDINXYZ(X,Y,Z,GX,GY)
       ELSE IF (IND.EQ.2.OR.IND.EQ.-2) THEN
         CALL COORDINXYZ(X,Y,Z,GX,GY)
         IF (ICLP3D.EQ.0) THEN
            CALL GWIOPSET(GX,GY)
          ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +            Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +              Z.GE.tdz1.AND.Z.LE.tdz2) THEN
            CALL GWIOPSET(GX,GY)
         ENDIF
       ELSE IF (IND.EQ.3) THEN
         CALL COORDINXYZ(X,Y,Z,GX,GY)
         IF (ICLP3D.EQ.0) THEN
            CALL GWIOMARKING(GX,GY,1)
          ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +            Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +              Z.GE.tdz1.AND.Z.LE.tdz2) THEN
            CALL GWIOMARKING(GX,GY,1)
         ENDIF
       ELSE IF (IND.EQ.-3) THEN
         CALL COORDINXYZ(X,Y,Z,GX,GY)
         IF (MDPROJ.NE.0) THEN
            ZP = ZPX*X + ZPY*Y + ZPZ*Z + ZP0
            ZP = 1.0/(1-ZP)
          ELSE
            ZP = 1
         ENDIF
         IF (ICLP3D.EQ.0) THEN
            CALL GWIOGRADCIRCLE(GX,GY,ZP,IC)
          ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +            Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +              Z.GE.tdz1.AND.Z.LE.tdz2) THEN
            CALL GWIOGRADCIRCLE(GX,GY,ZP,IC)
         ENDIF
       ELSE IF (IND.EQ.5.OR.IND.EQ.-5) THEN
         CALL COORDINXYZ(X,Y,Z,GX1,GY1)
         IF (ICLP3D.EQ.0) THEN
            CALL GWIOLINE(GX,GY,GX1,GY1,3)
          ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +            Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +              Z.GE.tdz1.AND.Z.LE.tdz2) THEN
            CALL GWIOLINE(GX,GY,GX1,GY1,3)
         ENDIF
         GX  = GX1
         GY  = GY1
       ELSE
         CALL COORDINXYZ(X,Y,Z,GX1,GY1)
         IF (ICLP3D.EQ.0) THEN
            CALL GWIOLINE(GX,GY,GX1,GY1,0)
          ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +            Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +              Z.GE.tdz1.AND.Z.LE.tdz2) THEN
            CALL GWIOLINE(GX,GY,GX1,GY1,0)
         ENDIF
         GX  = GX1
         GY  = GY1
      ENDIF

      CALL GWIOBDFLUSH(0)
 9999 IF (ICOLMODE.NE.0) CALL HLSSPHERECOLORSET(IC,0)
      RETURN
      END

      SUBROUTINE FR_VECTOR3D(X,Y,Z,DX,DY,DZ,IC,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X,Y,Z,DX,DY,DZ

      IF (IGCANVAS.LT.0) RETURN

      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR VECTOR3D')
         RETURN
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(68,1)
         CALL GSENDBYTE(IND,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND38BYTE(X,Y,Z,1,1)
         CALL GSEND38BYTE(DX,DY,DZ,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(2,IC)

      CALL COORDINXYZ(X,Y,Z,GX,GY)
      IF (IND.EQ.0) THEN
         CALL COORDINXYZ(X+DX,Y+DY,Z+DZ,GX1,GY1)
       ELSE IF (IND.EQ.1) THEN
         CALL COORDINXYZ(DX,DY,DZ,GX1,GY1)
      ENDIF

      IF (ICLP3D.EQ.0) THEN
         CALL GWIOLINE(GX,GY,GX1,GY1,3)
       ELSE IF (X.GE.tdx1.AND.X.LE.tdx2.AND.
     +         Y.GE.tdy1.AND.Y.LE.tdy2.AND.
     +           Z.GE.tdz1.AND.Z.LE.tdz2) THEN
         CALL GWIOLINE(GX,GY,GX1,GY1,3)
      ENDIF

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_PROJECT(D,MD)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 D

      IF (IGCANVAS.LT.0) RETURN

      IF (MD.NE.-9999) THEN
         MDPROJ  = MOD(MD,10)
         MOD3DIR = MD/10
         IF (MOD3DIR.LT.0.OR.MOD3DIR.GT.2) MOD3DIR = 0
      ENDIF
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(69,1)
         CALL GSENDBYTE(10*MOD3DIR+MDPROJ,1)
         CALL GSEND8BYTE(D,D,1,3)
      ENDIF

      DISTAN  = D
      MODE3D  = 1
      IFRAM   = 0
      IVIEW   = IOR(IVIEW,8)

      RETURN
      END

      SUBROUTINE FR_CLIP3D(X1,X2,Y1,Y2,Z1,Z2,IC)
      REAL*8 X1,X2,Y1,Y2,Z1,Z2
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(73,1)
         CALL GSENDBYTE(IC,1)
         CALL GSEND8BYTE(X1,X2,1,0)
         CALL GSEND8BYTE(Y1,Y2,1,0)
         CALL GSEND8BYTE(Z1,Z2,1,0)
      ENDIF

      IF (IC.EQ.0) THEN
         ICLP3D = 0
       ELSE
         ICLP3D = 1
      ENDIF

      IC1 = IABS(IC)
      IF (MOD(IC1,2).EQ.1) THEN
         IF (IC.LT.0) THEN
            A1 = ZPX*tdx1 + ZPY*tdy1 + ZPZ*tdz1
            A2 = ZPX*tdx2 + ZPY*tdy1 + ZPZ*tdz1
            IF (A2.GT.A1) THEN
               tdx1 = X1
             ELSE IF (A2.LT.A1) THEN
               tdx2 = X1
            ENDIF
          ELSE
            IF (X2.GE.X1) THEN
               tdx1 = X1
               tdx2 = X2
             ELSE
               tdx1 = X2
               tdx2 = X1
            ENDIF
         ENDIF
      ENDIF
      IC1 = IC1/2
      IF (MOD(IC1,2).EQ.1) THEN
         IF (IC.LT.0) THEN
            A1 = ZPX*tdx1 + ZPY*tdy1 + ZPZ*tdz1
            A2 = ZPX*tdx1 + ZPY*tdy2 + ZPZ*tdz1
            IF (A2.GT.A1) THEN
               tdy1 = Y1
             ELSE IF (A2.LT.A1) THEN
               tdy2 = Y1
            ENDIF
          ELSE
            IF (Y2.GE.Y1) THEN
               tdy1 = Y1
               tdy2 = Y2
             ELSE
               tdy1 = Y2
               tdy2 = Y1
            ENDIF
         ENDIF
      ENDIF
      IC1 = IC1/2
      IF (MOD(IC1,2).EQ.1) THEN
         IF (IC.LT.0) THEN
            A1 = ZPX*tdx1 + ZPY*tdy1 + ZPZ*tdz1
            A2 = ZPX*tdx1 + ZPY*tdy1 + ZPZ*tdz2
            IF (A2.GT.A1) THEN
               tdz1 = Z1
             ELSE IF (A2.LT.A1) THEN
               tdz2 = Z1
            ENDIF
          ELSE
            IF (Z2.GE.Z1) THEN
               tdz1 = Z1
               tdz2 = Z2
             ELSE
               tdz1 = Z2
               tdz2 = Z1
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE GWIOCLIP3D(X1,Y1,Z1,X2,Y2,Z2,IC)
      IMPLICIT INTEGER (A-Z)
      real*8 x1,y1,z1,x2,y2,z2,x,y,z
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      real tdx1,tdy1,tdz1,tdx2,tdy2,tdz2

      ic = 1
      ik = 0
    1   continue
      if (x1.lt.tdx1) then
         c1 = 1
       else if (x1.gt.tdx2) then
         c1 = 2
       else
         c1 = 0
      endif
      if (y1.lt.tdy1) then
         c1 = c1 + 4
       else if (y1.gt.tdy2) then
         c1 = c1 + 8
      endif
      if (z1.lt.tdz1) then
         c1 = c1 + 16
       else if (z1.gt.tdz2) then
         c1 = c1 + 32
      endif

      if (ik.ne.0) go to 3
    2   continue
      if (x2.lt.tdx1) then
         c2 = 1
       else if (x2.gt.tdx2) then
         c2 = 2
       else
         c2 = 0
      endif
      if (y2.lt.tdy1) then
         c2 = c2 + 4
       else if (y2.gt.tdy2) then
         c2 = c2 + 8
      endif
      if (z2.lt.tdz1) then
         c2 = c2 + 16
       else if (z2.gt.tdz2) then
         c2 = c2 + 32
      endif

    3   continue
      if (c1.eq.0.and.c2.eq.0) return
      if (iand(c1,c2).ne.0) then
         ic = 0
         return
      endif
      if (c1.ne.0) then
         c = c1
       else
         c = c2
      endif
      if (x1.eq.x2) then
         if (y1.eq.y2) then
            if (z1.lt.tdz1) then
               z1 = tdz1
             else if (z1.gt.tdz2) then
               z1 = tdz2
            endif
            if (z2.lt.tdz1) then
               z2 = tdz1
             else if (z2.gt.tdz2) then
               z2 = tdz2
            endif
            return
          else if (z1.eq.z2) then
            if (y1.lt.tdy1) then
               y1 = tdy1
             else if (y1.gt.tdy2) then
               y1 = tdy2
            endif
            if (y2.lt.tdy1) then
               y2 = tdy1
             else if (y2.gt.tdy2) then
               y2 = tdy2
            endif
            return
          else if (iand(c,4).ne.0) then
            z = z1 + (z2-z1)*(tdy1-y1)/(y2-y1)
            y = tdy1
          else if (iand(c,8).ne.0) then
            z = z1 + (z2-z1)*(tdy2-y1)/(y2-y1)
            y = tdy2
          else if (iand(c,16).ne.0) then
            y = y1 + (y2-y1)*(tdz1-z1)/(z2-z1)
            z = tdz1
          else if (iand(c,32).ne.0) then
            y = y1 + (y2-y1)*(tdz2-z1)/(z2-z1)
            z = tdz2
         endif
         x = x1
       else if (y1.eq.y2) then
         if (z1.eq.z2) then
            if (x1.lt.tdx1) then
               x1 = tdx1
             else if (x1.gt.tdx2) then
               x1 = tdx2
            endif
            if (x2.lt.tdx1) then
               x2 = tdx1
             else if (x2.gt.tdx2) then
               x2 = tdx2
            endif
            return
          else if (iand(c,1).ne.0) then
            z = z1 + (z2-z1)*(tdx1-x1)/(x2-x1)
            x = tdx1
          else if (iand(c,2).ne.0) then
            z = z1 + (z2-z1)*(tdx2-x1)/(x2-x1)
            x = tdx2
          else if (iand(c,16).ne.0) then
            x = x1 + (x2-x1)*(tdz1-z1)/(z2-z1)
            z = tdz1
          else if (iand(c,32).ne.0) then
            x = x1 + (x2-x1)*(tdz2-z1)/(z2-z1)
            z = tdz2
         endif
         y = y1
       else if (z1.eq.z2) then
         if (iand(c,1).ne.0) then
            y = y1 + (y2-y1)*(tdx1-x1)/(x2-x1)
            x = tdx1
          else if (iand(c,2).ne.0) then
            y = y1 + (y2-y1)*(tdx2-x1)/(x2-x1)
            x = tdx2
          else if (iand(c,4).ne.0) then
            x = x1 + (x2-x1)*(tdy1-y1)/(y2-y1)
            y = tdy1
          else if (iand(c,8).ne.0) then
            x = x1 + (x2-x1)*(tdy2-y1)/(y2-y1)
            y = tdy2
         endif
         z = z1
       else if (iand(c,1).ne.0) then
         y = y1 + (y2-y1)*(tdx1-x1)/(x2-x1)
         z = z1 + (z2-z1)*(tdx1-x1)/(x2-x1)
         x = tdx1
       else if (iand(c,2).ne.0) then
         y = y1 + (y2-y1)*(tdx2-x1)/(x2-x1)
         z = z1 + (z2-z1)*(tdx2-x1)/(x2-x1)
         x = tdx2
       else if (iand(c,4).ne.0) then
         x = x1 + (x2-x1)*(tdy1-y1)/(y2-y1)
         z = z1 + (z2-z1)*(tdy1-y1)/(y2-y1)
         y = tdy1
       else if (iand(c,8).ne.0) then
         x = x1 + (x2-x1)*(tdy2-y1)/(y2-y1)
         z = z1 + (z2-z1)*(tdy2-y1)/(y2-y1)
         y = tdy2
       else if (iand(c,16).ne.0) then
         x = x1 + (x2-x1)*(tdz1-z1)/(z2-z1)
         y = y1 + (y2-y1)*(tdz1-z1)/(z2-z1)
         z = tdz1
       else if (iand(c,32).ne.0) then
         x = x1 + (x2-x1)*(tdz2-z1)/(z2-z1)
         y = y1 + (y2-y1)*(tdz2-z1)/(z2-z1)
         z = tdz2
      endif

      if (c.eq.c1) then
         x1 = x
         y1 = y
         z1 = z
         ik = 1
         go to 1
      endif
      x2 = x
      y2 = y
      z2 = z
      go to 2

      END
