**************************************************************
*                     F  R  A  M  E  S  V.7.2                *
*         CHARACTER USING ROUTINES (DEPEND ON MACHINES)      *
*                  FOR X WINDOW MANAGERS                     *
*                 PROGRAMMED BY T.TAGUCHI                    *
**************************************************************
      SUBROUTINE FWNUMBER(X,Y,CH,NMZ,IBX,IBY,IDX,IP)
      integer cunit,cunit2,csup
      parameter (cunit=128,cunit2=cunit/2,csup=cunit*7/10)
      integer gcunit,gcunit2
      parameter (gcunit=1024,gcunit2=gcunit/2)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      CHARACTER CH*(*)
      CHARACTER CH10*10
      integer xx,yy

      N0  = LEN(CH)
      IN  = 0
      DO 10 N = 1, N0
         IF (IN.NE.0) THEN
            IF (ICHAR(CH(N:N)).EQ.ICHAR(' ')) GO TO 11
          ELSE IF (ICHAR(CH(N:N)).NE.ICHAR(' ')) THEN
            IN = N
         ENDIF
  10   CONTINUE
  11  N = N - 1
      IF (ICHAR(CH(N:N)).EQ.ICHAR('.')) N = N - 1

      N1 = N
      if (NMZ.NE.0) then
         IF (ABS(NMZ).GE.100) THEN
            NM = 3
          ELSE IF (ABS(NMZ).GE.10) THEN
            NM = 2
          ELSE
            NM = 1
         ENDIF
         IF (NMZ.LT.0) NM = NM + 1
         CALL GET10EXPFORM(NMZ,NM,CH10,IN10,N10)
         NN10 = N10-IN10+1
*         N1   = N1 + 3 + NN10
         N1   = N1 + 3
      endif

      if (ip.gt.0) then
         n1 = n1-in+1
       else
         in = 1
      endif

         show = 1
      if (windsw.eq.1) then
*//         show = 1
         xx   = grate*(X + ixoff)
         yy   = grate*(Y + iyoff)
         icx  = cunit2*(n1*(ibx-1)+idx)
         icy  = cunit2*(iby+1)
         if (iby.gt.0.and.NMZ.ne.0) icy = icy + csup*2/3
         nn   = n-in+1
         if (NMZ.eq.0) then
            call wpicdrawcharacters(xx,yy,ch(in:n),NN,icx,icy,0,0,0)
          else
            icx  = icx + cunit2*nn10*(ibx-1)
            call wpicdrawcharacters(xx,yy,ch(in:n),NN,icx,icy,0,0,0)
            icx2 = icx + NN*cunit
            icx3 = icx2 + cunit*3
            icy2 = icy - csup
            call wpicdrawcharacters(xx,yy,' 10',3,icx2,icy,0,0,0)
            call wpicdrawcharacters(xx,yy,ch10(in10:n10),NN10
     ,                                         ,icx3,icy2,0,0,0)
         endif
      endif

      if (mdgif.ne.0) then
         nn   = n-in+1
         if (NMZ.eq.0) then
*            if (ip.eq.2) iby1 = iby1 + 1
*            icx = gcunit2*(n1*(ibx-1)+idx)
*            icy = gcunit2*(iby+1)
*            call giffilechr(x,y,ch(in:n),nn,icx,icy,0,0)
            icx  = gcunit2*(ibx-1)
            icy  = gcunit2*(iby+1)
            icdx = gcunit2*idx
            call giffilechr(x,y,ch(in:n),nn,icx,icy,icdx,0,0)
          else
            iby1 = iby
            if (ip.eq.2) iby1 = iby1 + 1
            call giffilechr10(x,y,ch(in:n),nn
     ,                           ,ch10(in10:n10),nn10,ibx,iby1,idx)
         endif
      endif

      RETURN
      END

      SUBROUTINE LGNUMBER(X,Y,Z,NMZ,IBX,IBY,IDX)
      integer cunit,cunit2,csup
      parameter (cunit=128,cunit2=cunit/2,csup=cunit*7/10)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      CHARACTER CH*10
      integer xx,yy

      CALL GET10EXPFORM(INT(Z),NMZ,CH,IN,N)

         show = 1
      if (windsw.eq.1) then
*//         show = 1
         xx   = grate*(X + ixoff)
         yy   = grate*(Y + iyoff)
         n1   = n-in+1
         icx  = cunit2*(n1*(ibx-1)+idx-4)
         icy  = cunit2*(iby+1)
         IF (iby.gt.0) icy = icy + csup*2/3
         icx2 = icx + 2*cunit
         icy2 = icy - csup
         call wpicdrawcharacters(xx,yy,'10',2,icx,icy,0,0,0)
         call wpicdrawcharacters(xx,yy,ch(in:n),n1,icx2,icy2,0,0,0)
      endif

      if (mdgif.ne.0) then
         iby1 = iby
         if (iby.gt.0) iby1 = iby1 + 1
         call giffilechr10(x,y,' ',0,ch(in:n),n-in+1,ibx,iby1,idx)
      endif

      RETURN
      END

      SUBROUTINE GET10EXPFORM(IZ,NMZ,CH,IN,N)
      CHARACTER FORM*10
      CHARACTER CH*(*)

      FORM = '(I3)'
      IS   = 3
      IF (NMZ.LE.10) THEN
         FORM(3:3) = CHAR(ICHAR('0')+NMZ)
         IS = NMZ
      ENDIF
      WRITE(CH,FORM) IZ

      IN  = 0
      DO 10 N = 1, IS
          IF (IN.NE.0) THEN
              IF (ICHAR(CH(N:N)).EQ.ICHAR(' ')) GO TO 11
            ELSE IF (ICHAR(CH(N:N)).NE.ICHAR(' ')) THEN
              IN = N
           ENDIF
  10    CONTINUE
      N = IS
  11  CONTINUE

      RETURN
      END

      SUBROUTINE FR_XYNAME(CHX,CHY)
      integer cunit,cunit2,cunit8,csup
      parameter (cunit=128,cunit2=cunit/2)
      parameter (cunit8=cunit/8,csup=cunit*7/10)
      integer gcunit,gcunit2,gcunit8
      parameter (gcunit=1024,gcunit2=gcunit/2,gcunit8=gcunit/8)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /AXISNAMECOM/ XNAME,YNAME,IXYNAME,LXNM,LYNM
      CHARACTER XNAME*128,YNAME*128
      CHARACTER CHX*(*),CHY*(*)
      INTEGER CHRLENGTH
      integer xx,yy

      IF (IGCANVAS.LT.0) RETURN

      IF (IXYNAME.EQ.0.OR.IFRAM.EQ.0) THEN
         NX = CHRLENGTH(CHX)
         NY = CHRLENGTH(CHY)

         IF (IGPLT.GT.0) THEN
            CALL GSENDBYTE(3,1)
            CALL GSENDBYTE(NX,2)
            CALL GSENDBYTE(NY,2)
            CALL GSENDCHAR(CHX,NX)
            CALL GSENDCHAR(CHY,NY)
         ENDIF
         IF (IGCANVAS.EQ.0) RETURN

         IF (NX.GT.128) NX = 128
         IF (NY.GT.128) NY = 128
         XNAME   = CHX(1:NX)
         YNAME   = CHY(1:NY)
         IF (IFRAM.EQ.0) THEN
            LXNM    = NX
            LYNM    = NY
            IXYNAME = 1
            RETURN
         ENDIF
       ELSE
         NX = LXNM
         NY = LYNM
      ENDIF

      IXYNAME = 0

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(1,7)
*      CALL GPTXFO(IFONT)
*      CALL GPCHH(HIGHT)

         show = 1
      if (windsw.eq.1) then
*//         show = 1
         xx  = 0.5*grate*(IXMIN + IXMAX + ixoff*2)
         yy  = grate*(IYMAX + iyoff)
*         yy  = grate*(IYMAX + 22 + iyoff)
         icx = -nx*cunit2
         icy = 27*cunit8
         call wpicdrawcharacters(xx,yy,xname(1:nx),nx,icx,icy,0,0,0)
         xx = grate*(IXMIN + ixoff)
         yy = grate*(IYMIN + iyoff)
*         yy = grate*(IYMIN - 10 + iyoff)
         icy = -cunit2
         call wpicdrawcharacters(xx,yy,yname(1:ny),ny,0,icy,0,0,0)
      endif

      if (mdgif.ne.0) then
         psx = 0.5*(IXMIN + IXMAX)
         psy = IYMAX
*         icx = -nx*gcunit2
         icx = -gcunit2
         icy = 29*gcunit8
         call giffilechr(psx,psy,xname(1:nx),nx,icx,icy,0,0,0)
         psx = IXMIN
         psy = IYMIN
         icy = -gcunit2
         call giffilechr(psx,psy,yname(1:ny),ny,0,icy,0,0,0)
      endif

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_XYZNAME(CHX,CHY,CHZ)
      integer cunit,cunit2,cunit8,csup
      parameter (cunit=128,cunit2=cunit/2)
      parameter (cunit8=cunit/8,csup=cunit*7/10)
      integer gcunit,gcunit2,gcunit8
      parameter (gcunit=1024,gcunit2=gcunit/2,gcunit8=gcunit/8)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      COMMON /GRAPHCOM3D/ XM(2),YM(2),XTAN,YTAN,X0,Y0
     +        ,ZM(2),ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /AXISNAMECOM3D/ XNAME,YNAME,ZNAME,IXYZNAME,LXNM,LYNM,LZNM
      CHARACTER XNAME*128,YNAME*128,ZNAME*128
      CHARACTER CHX*(*),CHY*(*),CHZ*(*)
      INTEGER CHRLENGTH
      integer xx,yy
      EQUIVALENCE (XM(1),XMIN),(XM(2),XMAX),(YM(1),YMIN),(YM(2),YMAX)
      EQUIVALENCE (ZM(1),ZMIN),(ZM(2),ZMAX)

      IF (IGCANVAS.LT.0) RETURN

      IF (IXYZNAME.EQ.0.OR.IFRAM.EQ.0) THEN
         NX = CHRLENGTH(CHX)
         NY = CHRLENGTH(CHY)
         NZ = CHRLENGTH(CHZ)

         IF (IGPLT.GT.0) THEN
            CALL GSENDBYTE(33,1)
            CALL GSENDBYTE(NX,2)
            CALL GSENDBYTE(NY,2)
            CALL GSENDBYTE(NZ,2)
            CALL GSENDCHAR(CHX,NX)
            CALL GSENDCHAR(CHY,NY)
            CALL GSENDCHAR(CHZ,NZ)
         ENDIF
         IF (IGCANVAS.EQ.0) RETURN

         IF (NX.GT.128) NX = 128
         IF (NY.GT.128) NY = 128
         IF (NZ.GT.128) NZ = 128
         XNAME   = CHX(1:NX)
         YNAME   = CHY(1:NY)
         ZNAME   = CHZ(1:NZ)
         IF (IFRAM.EQ.0) THEN
            LXNM    = NX
            LYNM    = NY
            LZNM    = NZ
            IXYZNAME = 1
            RETURN
         ENDIF
       ELSE
         NX = LXNM
         NY = LYNM
         NZ = LZNM
      ENDIF

      IXYZNAME = 0
      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(1,7)

      IF (MODE3D.NE.0) GO TO 100

      IDX = IZXMAX - IXMAX
      IDY = IZYMAX - IYMAX  

      show = 1
      if (windsw.ne.1) go to 110

*//      show = 1
      xx  = 0.5*grate*(IXMIN + IXMAX + ixoff*2)
      yy  = grate*(IYMAX + iyoff)
*      yy  = grate*(IYMAX + 22 + iyoff)
*      icx = -nx*cunit2
*      icy = 2*cunit
      icx = -nx*cunit2
      icy = 27*cunit8
      call wpicdrawcharacters(xx,yy,xname(1:nx),nx,icx,icy,0,0,0)

      xx = grate*(IXMIN + ixoff)
      yy = grate*(IYMIN + iyoff)
*      yy = grate*(IYMIN - 10 + iyoff)
      icy = -cunit2
      call wpicdrawcharacters(xx,yy,yname(1:ny),ny,0,icy,0,0,0)

      CC  = IDX
      SS  = IDY
      RR  = SQRT(CC*CC + SS*SS)
      CC  = CC/RR
      SS  = SS/RR

*      xx  = grate*((IZXMAX + IXMAX)/2 - 82*SS + ixoff) + 0.5
*      yy  = grate*((IZYMAX + IYMAX)/2 + 82*CC - 10 + iyoff) + 0.5
      xx  = grate*((IZXMAX + IXMAX)/2 + ixoff) + 0.5
      yy  = grate*((IZYMAX + IYMAX)/2 + iyoff) + 0.5
      rd  = 10.25
      IF (2*ABS(IDX).GE.ABS(IDY)) THEN
         TT  = SS/CC
         icx = -nz*cunit2
         icy = (RD*CC-2)*cunit2
         ipx = -RD*SS*cunit2
         ipy = icx*tt
         cdd = cunit*tt
         ccy = ipy
         DO I = 1, NZ
           call wpicdrawcharacters(xx,yy,zname(i:i),1,icx,icy,ipx,ipy,0)
            icx  = icx + cunit
            ccy  = ccy + cdd
            ipy  = ccy
         ENDDO
       ELSE
         TT  = CC/SS
         icx = 0
         icy = (nz+RD*CC)*cunit2
         ipx = (nz*tt-RD*SS)*cunit2
         ipy = -cunit
         cdd = cunit*tt
         ccx = ipx
         DO I = 1, NZ
           call wpicdrawcharacters(xx,yy,zname(i:i),1,icx,icy,ipx,ipy,0)
            ccx  = ccx - cdd
            ipx  = ccx
            icy  = icy - cunit
         ENDDO
      ENDIF

110   continue
      if (mdgif.ne.0) then
         psx = 0.5D0*(IXMIN + IXMAX)
         psy = IYMAX
*         icx = -nx*gcunit2
         icx = -gcunit2
         icy = 29*gcunit8
         call giffilechr(psx,psy,xname(1:nx),nx,icx,icy,0,0,0)
         psx = IXMIN
         psy = IYMIN
         icy = -gcunit2
         call giffilechr(psx,psy,yname(1:ny),ny,0,icy,0,0,0)

         CC  = IDX
         SS  = IDY
         RR  = SQRT(CC*CC + SS*SS)
         CC  = CC/RR
         SS  = SS/RR
*         psx = (IZXMAX + IXMAX)/2 - 82*SS + ixoff
*         psy = (IZYMAX + IYMAX)/2 + 82*CC - 10 + iyoff
         psx = (IZXMAX + IXMAX)/2
         psy = (IZYMAX + IYMAX)/2
         rd  = 12.25
         IF (2*ABS(IDX).GE.ABS(IDY)) THEN
            TT  = SS/CC
*            icx = -nz*gcunit2
            icx = -gcunit2
            icy = (RD*CC-2)*gcunit2
            ipx = -RD*SS*gcunit2
            ipy = icx*tt
            cdd = gcunit*tt
            ccy = ipy
            DO I = 1, NZ
               call giffilechr(psx,psy,zname(i:i),1,icx,icy,0,ipx,ipy)
               icx  = icx + gcunit
               ccy  = ccy + cdd
               ipy  = ccy
            ENDDO
          ELSE
            TT  = CC/SS
            icx = 0
            icy = (nz+RD*CC)*gcunit2
            ipx = (nz*tt-RD*SS)*gcunit2
            ipy = -gcunit
            cdd = gcunit*tt
            ccx = ipx
            DO I = 1, NZ
               call giffilechr(psx,psy,zname(i:i),1,icx,icy,0,ipx,ipy)
               ccx  = ccx - cdd
               ipx  = ccx
               icy  = icy - gcunit
            ENDDO
         ENDIF
      endif

      GO TO 200

  100   CONTINUE
      IF (MOD3DIR.EQ.1) THEN
         CALL FRAMES3DLETTER(YM,ZM,XM,yname,zname,xname,NY,NZ,NX)
       ELSE IF (MOD3DIR.EQ.2) THEN
         CALL FRAMES3DLETTER(ZM,XM,YM,zname,xname,yname,NZ,NX,NY)
       ELSE
         CALL FRAMES3DLETTER(XM,YM,ZM,xname,yname,zname,NX,NY,NZ)
      ENDIF

  200 CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FRAMES3DLETTER(XM,YM,ZM,CHX,CHY,CHZ,NX,NY,NZ)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      REAL XM(2),YM(2),ZM(2)
      CHARACTER CHX*(*),CHY*(*),CHZ*(*)

      IF (THETA.LT.0.0) THEN
         Z0 = ZM(2)
         Z1 = ZM(1)
         IT = -1
       ELSE
         Z0 = ZM(1)
         Z1 = ZM(2)
         IT = 1
      ENDIF

      IF (ABS(THETA).EQ.90.0) THEN
         IF (PHI.LT.-90.0) THEN
            IY = 1
            IX = 1
            IN = 1
          ELSE IF (PHI.LT.0.0) THEN
            IY = 1
            IX = 2
            IN = 2
          ELSE IF (PHI.LE.90.0) THEN
            IY = 2
            IX = 2
            IN = 1
          ELSE
            IY = 2
            IX = 1
            IN = 2
         ENDIF
         CALL FRAMELETTER(1,XM,YM(IY),Z0,IT,IN,YM(3-IY),Z0,CHX,NX)
         CALL FRAMELETTER(2,YM,Z0,XM(IX),IT,3-IN,Z0,XM(3-IX),CHY,NY)
       ELSE IF (THETA.NE.0.0) THEN
         IX1 = 1
         IF (PHI.LT.-90.0) THEN
            IY  = 1
            IX  = 1
            IN  = 1
            IY1 = 2
            IX2 = 1
            IN1 = 2
          ELSE IF (PHI.LT.0.0) THEN
            IY  = 1
            IX  = 2
            IN  = 2
            IY1 = 1
            IX2 = 2
            IN1 = 2
          ELSE IF (PHI.EQ.0.0) THEN
            IY  = 1
            IX  = 2
            IN  = 2
            IX1 = 2
            IY1 = 2
            IX2 = 2
            IN1 = 1
          ELSE IF (PHI.LE.90.0) THEN
            IY  = 2
            IX  = 2
            IN  = 1
            IY1 = 2
            IX2 = 2
            IN1 = 1
          ELSE
            IY  = 2
            IX  = 1
            IN  = 2
            IY1 = 1
            IX2 = 1
            IN1 = 1
         ENDIF
         CALL FRAMELETTER(1,XM,YM(IY),Z0,IT,IN,YM(3-IY),Z0,CHX,NX)
         CALL FRAMELETTER(2,YM,Z0,XM(IX),IT,3-IN,Z0,XM(3-IX),CHY,NY)
         CALL FRAMELETTER(3,ZM,XM(IX1),YM(IY1),IT,IN1,XM(IX2),YM(IY)
     ,                                                      ,CHZ,NZ)
       ELSE
         IAX = 1
         IAY = 1
         IF (PHI.LE.-90.0) THEN
            IY  = 1
            IN  = 1
            IY1 = 2
            IF (PHI.NE.-90.0) THEN
               IX  = 1
               IX2 = 1
               IY2 = 1
             ELSE
               IX2 = 2
               IY2 = 2
               IAY = 0
            ENDIF 
            IN1 = 2
          ELSE IF (PHI.LT.0.0) THEN
            IY  = 1
            IX  = 2
            IN  = 2
            IY1 = 1
            IX2 = 2
            IY2 = 1
            IN1 = 2
          ELSE IF (PHI.EQ.0.0) THEN
            IX  = 2
            IN  = 2
            IY1 = 2
            IX2 = 1
            IY2 = 1
            IN1 = 1
            IAX = 0
          ELSE IF (PHI.LE.90.0) THEN
            IY  = 2
            IN  = 1
            IY1 = 2
            IF (PHI.NE.90.0) THEN
               IX  = 2
               IX2 = 1
               IY2 = 1
             ELSE
               IX2 = 2
               IY2 = 2
               IAY = 0
            ENDIF
            IN1 = 1
          ELSE
            IY  = 2
            IX  = 1
            IN  = 2
            IY1 = 1
            IX2 = 1
            IY2 = 2
            IN1 = 1
            IF (PHI.EQ.180.0) IAX = 0
         ENDIF
         IF (IAX.NE.0) THEN
           CALL FRAMELETTER(1,XM,YM(IY),ZM(1),1,IN,YM(IY),ZM(2),CHX,NX)
         ENDIF
         IF (IAY.NE.0) THEN
           CALL FRAMELETTER(2,YM,ZM(1),XM(IX),1,3-IN,ZM(2),XM(IX)
     ,                                                     ,CHY,NY)
         ENDIF
         CALL FRAMELETTER(3,ZM,XM(1),YM(IY1),1,IN1,XM(IX2),YM(IY2)
     ,                                                     ,CHZ,NZ)
      ENDIF

      RETURN
      END

      SUBROUTINE FRAMELETTER(IAX,AM,A1,A2,ITC,INUM,A11,A12,CH,NC)
      integer cunit,cunit2,csup
      parameter (cunit=128,cunit2=cunit/2,csup=cunit*7/10)
      integer gcunit,gcunit2
      parameter (gcunit=1024,gcunit2=gcunit/2)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      REAL AM(2)
      CHARACTER CH*(*)
      integer xx,yy

      rd  = 3.125
      AMIN = AM(1)
      AMAX = AM(2)
      IF (IAX.EQ.1) THEN
         CALL COORDINQXYZ(AMIN,A1,A2,XP1,YP1)
         CALL COORDINQXYZ(AMAX,A1,A2,XP2,YP2)
         CALL COORDINQXYZ(AMIN,A11,A12,XP3,YP3)
         CS   = XP3 - XP1
         SN   = YP3 - YP1
         R    = SQRT(CS*CS + SN*SN)
         RD   = RD/R
*         xx   = grate*(-50*CS/R + 0.5*(XP1 + XP2) + ixoff)
*         yy   = grate*(-50*SN/R + 0.5*(YP1 + YP2) + iyoff)
         xx   = grate*(0.5*(XP1 + XP2) + ixoff)
         yy   = grate*(0.5*(YP1 + YP2) + iyoff)
         icx  = 0
         icy  = cunit*((ITC+1)-RD*SN)
         idx  = -RD*CS*cunit
         idy  = 0
       ELSE IF (IAX.EQ.2) THEN
         CALL COORDINQXYZ(A2,AMIN,A1,XP1,YP1)
         CALL COORDINQXYZ(A2,AMAX,A1,XP2,YP2)
         CALL COORDINQXYZ(A12,AMIN,A11,XP3,YP3)
         CS   = XP3 - XP1
         SN   = YP3 - YP1
         R    = SQRT(CS*CS + SN*SN)
         RD   = RD/R
*         xx   = grate*(-50*CS/R + 0.5*(XP1 + XP2) + ixoff)
*         yy   = grate*(-50*SN/R + 0.5*(YP1 + YP2) + iyoff)
         xx   = grate*(0.5*(XP1 + XP2) + ixoff)
         yy   = grate*(0.5*(YP1 + YP2) + iyoff)
         icx  = 0
         icy  = cunit*((ITC+1)-RD*SN)
         idx  = -RD*CS*cunit
         idy  = 0
       ELSE
         IF (ITC.GT.0) THEN
            CALL COORDINQXYZ(A1,A2,AMAX,XP1,YP1)
            xx   = grate*(XP1 - 8*(2*INUM - 3) + ixoff)
            yy   = grate*(YP1 + iyoff)
*            xx   = grate*(XP1 - 8*(2*INUM - 3) + ixoff)
*            yy   = grate*(YP1 - 14 + iyoff)
            icx  = 0
            icy  = -cunit*1.875
            idx  = 0
            idy  = 0
          ELSE
            CALL COORDINQXYZ(A1,A2,AMIN,XP1,YP1)
            xx   = grate*(XP1 - 8*(2*INUM - 3) + ixoff)
            yy   = grate*(YP1 + iyoff)
*            xx   = grate*(XP1 - 8*(2*INUM - 3) + ixoff)
*            yy   = grate*(YP1 + 20 + iyoff) 
            icx  = 0
            icy  = cunit*2.875
            idx  = 0
            idy  = 0
         ENDIF
      ENDIF

         show = 1
      if (windsw.eq.1) then
*//         show = 1
         IF (INUM.EQ.2) icx = icx - NC*cunit
         call wpicdrawcharacters(xx,yy,ch(1:nc),nc,icx,icy,idx,idy,0)
      endif

      if (mdgif.ne.0) then
         IF (IAX.EQ.1) THEN
*            psx  = -50*CS/R + 0.5*(XP1 + XP2)
*            psy  = -50*SN/R + 0.5*(YP1 + YP2)
*            iy   = itc
            psx  = 0.5*(XP1 + XP2)
            psy  = 0.5*(YP1 + YP2)
            icx  = 0
            icy  = gcunit*((ITC+1)-RD*SN)
            idx  = -RD*CS*gcunit
            idy  = 0
          ELSE IF (IAX.EQ.2) THEN
*            psx  = -50*CS/R + 0.5*(XP1 + XP2)
*            psy  = -50*SN/R + 0.5*(YP1 + YP2)
*            iy   = itc
            psx  = 0.5*(XP1 + XP2)
            psy  = 0.5*(YP1 + YP2)
            icx  = 0
            icy  = gcunit*((ITC+1)-RD*SN)
            idx  = -RD*CS*gcunit
            idy  = 0
          ELSE
            psx  = XP1 - 8*(2*INUM - 3)
            psy  = YP1
            IF (ITC.GT.0) THEN
*               psy = YP1 - 30
               icx  = 0
               icy  = -gcunit*2.2
               idx  = 0
               idy  = 0
             ELSE
*               psy = YP1 + 34 
               icx  = 0
               icy  = gcunit*4.2
               idx  = 0
               idy  = 0
            ENDIF
         ENDIF

*         IF (INUM.EQ.2) icx = icx - NC*gcunit
         IF (INUM.EQ.2) icx = icx - gcunit
         call giffilechr(psx,psy,ch(1:nc),nc,icx,icy,0,idx,idy)
      endif

      RETURN
      END

      SUBROUTINE FR_FPCHARS(X,Y,CH,IC,IBX,IBY,IDX,MODE)
      integer cunit,cunit2,csup
      parameter (cunit=128,cunit2=cunit/2,csup=cunit*7/10)
      integer gcunit,gcunit2,rcunit
      parameter (gcunit=1024,gcunit2=gcunit/2,rcunit=gcunit/cunit)
      common /comgpwinio/ grate,windsw,show,delay,winmode,wpause
      real grate
      integer windsw,show,delay,winmode,wpause
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer clip
      common /comgifmode/ mdgif
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      CHARACTER CH*(*)
      REAL*8 X,Y
      integer xx,yy,ccx,ccy
      save xx,yy,ccx,ccy,nn
      data xx,yy,ccx,ccy,nn/0,0,0,0,0/

      IF (IGCANVAS.LT.0) RETURN

      N0 = LEN(CH)
      N  = N0
      DO I = N0, 1, -1
          IF (CH(I:I).EQ.'|') GO TO 110
          IF (CH(I:I).NE.' ') GO TO 111
          N = N - 1
      ENDDO
  110 IF (N.GT.1) N = N - 1
  111 CONTINUE

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(84,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IBX,1)
         CALL GSENDBYTE(IBY,1)
         CALL GSENDBYTE(IDX,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X,Y,1,2)
         CALL GSENDBYTE(N,2)
         CALL GSENDCHAR(CH,N)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)

**
**    xx and yy are in screen coordinates ( x grate)
**    ccx and ccy are in 1/cunit character width and height
**    Don't confuse their units'
**

      if (MD.NE.0) then
         ccx = ccx + nn*cunit*X
         ccy = ccy + cunit*Y
         xx  = grate*(CURPX + ixoff)
         yy  = grate*(CURPY + iyoff)
       else
         IF (M2.EQ.0) THEN
            xxx = X
            yyy = Y
            IF (M1.EQ.1.OR.M1.EQ.3) THEN
               xxx = xxx + CURPX
            ENDIF
            IF (M1.GE.2) THEN
               yyy = yyy + CURPY
            ENDIF
          ELSE
            IF (M1.EQ.1.OR.M1.EQ.3) THEN
               ccx = CURPX
             ELSE
               ccx = X0
            ENDIF
            IF (M1.GE.2) THEN
               ccy = CURPY
             ELSE
               ccy = Y0
            ENDIF
            xxx = XTAN*X + ccx
            yyy = YTAN*Y + ccy
         ENDIF
         xx  = grate*(xxx + ixoff)
         yy  = grate*(yyy + iyoff)
         ccx = 0
         ccy = 0
         CURPX = xxx
         CURPY = yyy
      endif
      icx = ccx + cunit2*(n*(ibx-1)+idx)
      icy = ccy + cunit2*(iby+1)
      nn  = n
      if (n.eq.0) go to 100

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(10)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 1
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

         show = 1
      if (windsw.eq.1) then
*//         show = 1
         call wpicdrawcharacters(xx,yy,ch(1:n),n,icx,icy,0,0,0)
      endif

100   if (mdgif.ne.0) then
         if (MD.NE.0) then
            psx  = CURPX
            psy  = CURPY
          else
            psx  = xxx
            psy  = yyy
         endif
*         icx = icx*rcunit
         icx  = gcunit2*(ibx-1)
         icdx = gcunit2*ccx/cunit2 + gcunit2*idx
         icy  = icy*rcunit
         call giffilechr(psx,psy,ch(1:n),n,icx,icy,icdx,0,0)
      endif

      CALL GWIOBDFLUSH(0)

      RETURN
      END
