/**********************************************************************
 *                    F    r    a    m    e    s                      *
 *      Graphic Core Routines for GTK/GDK  Ver 0.1 (07/19/10)         *
 *                                              By T. Taguchi         *
 **********************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include 	<math.h>

/*#define TEST_ROUTINES		*/

#define WINDRAW_END				0							/* End reading */
#define WINDRAW_DOT				10							/* Dot */
#define WINDRAW_DOTS			11							/* Several dots */
#define WINDRAW_DRAW			19							/* draw */
#define WINDRAW_LINE			20							/* Line */
#define WINDRAW_SEGMENTS		21							/* Separate lines */
#define WINDRAW_LINKS			22							/* Linked lines */
#define WINDRAW_FILLPOLYGON		23							/* Closed linked lines and Fill */
#define WINDRAW_CIRCLE			30							/* Circle */
#define WINDRAW_FILLCIRCLE		35							/* Fill circle */
#define WINDRAW_GRADCIRCLE		36							/* Gradient fill circle */
#define WINDRAW_BOX				40							/* Box */
#define WINDRAW_FILLBOX			45							/* Fill box */
#define WINDRAW_GRADFILLBOX		46							/* Gradient fill box */
#define WINDRAW_CHAR			81							/* Characters */
#define WINDRAW_XORCHAR			82							/* XOR Characters */
#define WINDRAW_FINECHAR		83							/* Fine Position Characters */
#define WINDRAW_BASECOLMAP		90							/* Base of the Current Colormap */
#define WINDRAW_BASICCOL		91							/* Basic color setting */
#define WINDRAW_EXTENDCOL		92							/* Extended color setting */
#define WINDRAW_EXTEND2COL		93							/* Extended color setting */

#define NGBUFFER				4096
#define NCHRBUFFER				1024
#define MAXMEMSIZE				40960			/* Buffer size to allocate at one time        */
#define BFSMAX					(MAXMEMSIZE-sizeof(short)+1)
#define IFSMAX					(MAXMEMSIZE-sizeof(int)+1)
#define BORDERWIDTH				10

#include "frames_canvas.h"

#ifdef GTK
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
typedef struct {
	gint16 x;
	gint16 y;
	guint16 width;
	guint16 height;
	gint16 angle1,angle2;            // angle in degrees*64
} GdkArc;
#endif

#define rgbmax 			65536
#define ONEBUFFER		250		/* Buffer increase size (about 10MB) -- 1 unit 40k        */
#define BASE_NPIXEL		256
#define MAXCOLMAPS		(MAXDEFCUMAPP+MAXSYSCOLMAP)
/*#define XSERVER_CHECK		*/

typedef struct {
#ifdef GTK
	GdkWindow		*win;
	GtkWidget		*topwin;
	GtkWidget		*area;
	GdkPixmap		*pix;
	GdkGC			*gc;
	GdkDrawable		*drw;
#else
	Window			win;
#ifdef TOOLKIT
	Window			topwin;
#endif
	Pixmap			pix;
	GC				gc;
	Drawable		drw;
#endif
	unsigned int	width, height;			/* Display window size */
	unsigned int	owidth, oheight;		/* Original window size */
	int				chsize;					/* Character Magnification */
	int				bfmmax;
	char			**grbuf, *bmap;			/* Array for buffer access */
	int				draw_mode;				/* Drawed items (0 means nothing)  			  */
	int				bfmad, bfsad;			/* Arrays to manage buffers (for 2 pages)     */
	int				nfont, fontheight, fontwidth;	/* Current using font number and size */
	int				ccmap;					/* Current Color map  						  */
#ifdef GTK
	GdkColor 		bcolor[10];
	GdkColor		*pixels;				/* Pointer to color table                      */
#else
	unsigned int	bcolor[10];				/* Basic color number                         */
	PIXELTYPE		*pixels;				/* Pointer to color table                      */
#endif
//	unsigned int	pixpt[MAXCOLMAPS];		/* Pointer to the pixel array				  */
//	int				cmapnum[MAXCOLMAPS];	/* Assign to the Frames color table number	  */
//	PIXELTYPE		*lpixels;				/* Local color number                         */
} FRAMESWINDOW;

#ifdef GTK
static FRAMESWINDOW		*frwin[MAXFP];
int				TGMODE=1;
GdkColor		*gpixels=NULL;				/* Global color tables						  */
GdkColor		*gsphept[7];
#else
PIXELTYPE		*gpixels=NULL;				/* Global color tables						  */
PIXELTYPE		*gsphept[7];
#endif
unsigned int	gpixpt[MAXCOLMAPS];			/* Global Pointer to the pixel array		  */
int				gcmapnum[MAXCOLMAPS];		/* Assign to the Frames color table number	  */
int				max_colmap=-1, max_gpixels=-1, current_hlstable=0, def_colmap=0;

#define xchg(xx)		(int)(((double)(xx)*magni)+revx+0.5)
#define ychg(yy)		(int)(((double)(yy)*magni)+revy+0.5)
#define rchg(rr)		(int)(((double)(rr)*magni)+0.5)
#define xrchg(xx)		(int)(((double)(xx)-revx)/magni+0.5)
#define yrchg(yy)		(int)(((double)(yy)-revy)/magni+0.5)
#define dxrchg(xx)		(((double)(xx)-revx)/magni)
#define dyrchg(yy)		(((double)(yy)-revy)/magni)

#ifndef TOOLKIT
/*#define ColorSet		1*/
static FRAMESWINDOW		*frwin[MAXFP];
static Atom				num_frames;
#else
/*#define ColorSet		0*/
extern int				TGMODE;
extern XtAppContext		app_con;
extern Widget			toplevel, xframes, seq_button, mode_button;
extern Widget			ctoggle[7], cradio[7], lradio[7];
extern char				filename[];
#endif
#ifdef GTK
extern GtkWidget		*framesarea, *mainwindow;
#endif

static FRAMESWINDOW		*cwin, *dwin;
#ifdef GTK
static GdkColormap		*cmap=NULL, *dcmap;
static GdkFont			*fontst;
#else
static Colormap			cmap=0, dcmap;
static XFontStruct		*fontst;
static XCharStruct		charst;
#endif

static Display			*dpID;
static int				maxwindow=0;			/* Maximum Window Number                           */
static int				display_mode=1;			/* Display mode (0: step by step, 1: draw at once) */
static Atom				wm_delete_window;

static unsigned int		border_width, display_width, display_height;
static int				xyratiomode;
static int				color_num, dp_ncolor, max_colors, max_acolors, color_set, color_mode=0;
static int				dp_cells, dp_planes, dp_depth, dp_class, dp_mincmap, dp_maxcmap;
static int				*dp_sh=NULL,*dp_sl,*dp_ss,*dp_div,dp_mode;
static int				shmin0,shmax0,slmin0,slmax0,ssmin0,ssmax0;

static int				eventmask;				/* Mask for getting events                    */
static int				revx, revy;				/* Offset coordinates for the window position */
static double			magni,magnix,magniy,grate;		/* (Display size) / (Virtual size)            */
static int				magnum, magden;
#ifdef GTK
static GdkColor			colplt[11];				/* Basic color palette                        */
#else
static unsigned int		colplt[11];				/* Basic color palette                        */
#endif
static int				colbkup;				/* Present color number                       */
static int				polyshape=Nonconvex;
static int				error_draw=0,true_color=0;
static int				huesave[BASE_NPIXEL],satsave[BASE_NPIXEL],ligsave[BASE_NPIXEL];

/*   3 Definitions of Font Name Lists   */

#ifdef GTK
void update_frame(GtkWidget *widget);
#endif

static void redraw_pics(FRAMESWINDOW *cw);


static int init_configure=0;

gint configure_event(GtkWidget *widget, GdkEventConfigure *event, gint *data)
{

//	printf("configure %d %x\n",init_configure,cwin);
	if (init_configure) return TRUE;
	if (cwin->pix) {
		gdk_pixmap_unref(cwin->pix);
		cwin->pix=NULL;
	}

	cwin->width  = widget->allocation.width;
	cwin->height = widget->allocation.height;
	set_magnification(cwin);
	make_pixmap(cwin);
//	redraw_pics(cwin);
	update_frame(cwin->area);
	init_configure=1;
	return TRUE;
}

gint expose_event(GtkWidget *widget, GdkEventExpose *event, gint *data)
{
//	printf("expose\n");
	if (cwin->pix) {
		gdk_draw_pixmap(widget->window,
					widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
					cwin->pix,
					event->area.x,event->area.y,
					event->area.x,event->area.y,
					event->area.width,event->area.height);
	}
	return FALSE;
}
