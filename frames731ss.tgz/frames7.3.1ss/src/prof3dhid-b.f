*******************************************
*        F  R  A  M  E  S  V.7.3          *
*       FOR 3D HIDDEN LINE ROUTINES       *
*           USE BYTE VARIABLES            *
*       PROGRAMMED BY T.TAGUCHI           *
*             JANUARY/19/2013             *
*******************************************

      SUBROUTINE DRAWSURFACE3D(WS,TS,HS,BS,NUV,IND0,IND1,IC0)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      REAL*4    WS(NUV,3),TS(*)
      INTEGER   HS(NUV,4)
      BYTE      BS(NUV,4)

      IF (IND1.NE.0) THEN
*         IF (IND0.GT.NUV*2/3) THEN
            IND0 = 0
*   REGIONORDER routine contains a BUG so now skip it.
*           ELSE
*            IND0 = 1
*            CALL REGIONORDER(HS(1,2),HS(1,3),HS(1,4))
*         ENDIF
      ENDIF

      DO NPP = 1, NPROF
         NW  = NUNV3(NPP)+1
         NW1 = NUNV1(NPP)+1
         CALL SETAREATYPE(WS(NW,1),WS(NW+NUNV(NPP),1)
     ,                            ,BS(NW1,3),NU(NPP),NV(NPP))
      ENDDO

      DO NP = 1, NPROF
         NW = NUNV1(NP)
         IW = NUNV3(NP)
         JW = IW+NUNV(NP)
         KW = JW+NUNV(NP)
         DO NK = 1, NUNV(NP)
            XXX = WS(IW+NK,1)
            YYY = WS(JW+NK,1)
            ZZZ = WS(KW+NK,1)
            CALL SEARCHIMAX2(TS)
            IF (IV.NE.0) CALL VISIBLEDOT(WS,HS,BS(1,3),HS(1,3)
     ,                                     ,HS(1,2),HS(1,4),IND0)
            BS(NW+NK,4) = IV
         ENDDO
      ENDDO

      CALL REMOVEHIDDEN(TS,HS,HS(1,2),BS(1,4))

      DO NP = 1, NPROF
         CALL GWIOCOLOR(2,ICOLS(NP))
         NR   = 0
         IDIR = 0
         DO NK = 1, NU(NP)-1
            CALL HIDBRANCH(WS,TS,HS,BS,NUV)
         ENDDO

         NK0 = 1
         DO J = 1, NV(NP)-1
            NK   = NK0
            IDIR = 1
            CALL HIDBRANCH(WS,TS,HS,BS,NUV)
            DO I = 1, NU(NP)-1
               NK   = NK0 + 1
               IDIR = 1
               CALL HIDBRANCH(WS,TS,HS,BS,NUV)
               NK   = NK0 + NU(NP)
               IDIR = 0
               CALL HIDBRANCH(WS,TS,HS,BS,NUV)
               NK0 = NK0 + 1
            ENDDO
            NK0 = NK0 + 1
         ENDDO
      ENDDO

      RETURN
      END

      SUBROUTINE SETAREATYPE(X,Y,TYPE,NU,NV)
      REAL*4 X(NU,NV),Y(NU,NV)
      BYTE TYPE(NU,NV)

      DO 10 J = 1, NV-1
         DO 11 I = 1, NU-1
            DX21 = X(I+1,J)   - X(I,J)
            DY21 = Y(I+1,J)   - Y(I,J)
            DX31 = X(I+1,J+1) - X(I,J)
            DY31 = Y(I+1,J+1) - Y(I,J)
            DX41 = X(I,J+1)   - X(I,J)
            DY41 = Y(I,J+1)   - Y(I,J)
            D1   = DX21*DY31 - DX31*DY21
            D2   = DX31*DY41 - DX41*DY31
            D3   = DX21*DY41 - DX41*DY21
            D4   = (DX31-DX21)*(DY41-DY21) - (DX41-DX21)*(DY31-DY21)

            IF (D1.GT.0) THEN
               IF (D2.GT.0) THEN
                  IF (D4.EQ.0) THEN
                     TYPE(I,J) = 17
                   ELSE IF (D3.EQ.0) THEN
                     TYPE(I,J) = 22
                   ELSE 
                     TYPE(I,J) = 1
                  ENDIF
                ELSE IF (D2.EQ.0) THEN
                  TYPE(I,J) = 16
                ELSE
                  IF (D3.GT.0) THEN
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 2
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 17
                      ELSE 
                        TYPE(I,J) = 8
                     ENDIF
                   ELSE IF (D3.EQ.0) THEN
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 22
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 0
                      ELSE
                        TYPE(I,J) = 23
                     ENDIF
                   ELSE
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 10
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 20
                      ELSE
                        TYPE(I,J) = 3
                     ENDIF
                  ENDIF
               ENDIF
             ELSE IF (D1.EQ.0) THEN
               IF (D2.GT.0) THEN
                  TYPE(I,J) = 19
                ELSE IF (D2.EQ.0) THEN
                  TYPE(I,J) = 0
                ELSE
                  TYPE(I,J) = 21
               ENDIF
             ELSE
               IF (D2.LT.0) THEN
                  IF (D4.EQ.0) THEN
                     TYPE(I,J) = 20
                   ELSE IF (D3.EQ.0) THEN
                     TYPE(I,J) = 23
                   ELSE
                     TYPE(I,J) = 4
                  ENDIF
                ELSE IF (D2.EQ.0) THEN
                  TYPE(I,J) = 18
                ELSE
                  IF (D3.GT.0) THEN
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 2
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 17
                      ELSE
                        TYPE(I,J) = 11
                     ENDIF
                   ELSE IF (D3.EQ.0) THEN
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 22
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 0
                      ELSE
                        TYPE(I,J) = 23
                     ENDIF
                   ELSE
                     IF (D4.GT.0) THEN
                        TYPE(I,J) = 9
                      ELSE IF (D4.EQ.0) THEN
                        TYPE(I,J) = 20
                      ELSE
                        TYPE(I,J) = 3
                     ENDIF
                  ENDIF
               ENDIF
            ENDIF
   11  CONTINUE
   10  CONTINUE

      RETURN
      END

      SUBROUTINE REMOVEHIDDEN(TS,ORDER,REGION,VPOS)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      REAL*4    TS(*)
      INTEGER     ORDER(*),REGION(*)
      BYTE      VPOS(*)

      K1 = 0
      DO 10 I = 1, NORDER
         K  = ORDER(I)
         DO NPP = NPROF, 2, -1
            IF (K.GT.NUNV1(NPP)) GO TO 101
         ENDDO
  101    IF (VPOS(K).NE.0.OR.VPOS(K+1).NE.0.OR.
     +          VPOS(K+NU(NPP)).NE.0.OR.VPOS(K+NU(NPP)+1).NE.0) THEN
            K1         = K1 + 1
            TS(K1)     = TS(I)
            ORDER(K1)  = ORDER(I)
            REGION(K1) = REGION(I)
         ENDIF
   10  CONTINUE

      NORDER = K1

      RETURN
      END

      SUBROUTINE HIDBRANCH(WS,TS,HS,BS,NUV)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      INTEGER   V1,V2
      REAL*4    WS(NUV,3),TS(*)
      INTEGER   HS(NUV,2)
      BYTE      BS(NUV,4)

      NW = NUNV1(NP)+NK
      IW = NUNV3(NP)+NK
      JW = IW+NUNV(NP)
      KW = JW+NUNV(NP)
      IF (IDIR.EQ.0) THEN
         N2 = 1
       ELSE
         N2 = NU(NP)
      ENDIF

      XX1 = WS(IW,1)
      XX2 = WS(IW+N2,1)
      YY1 = WS(JW,1)
      YY2 = WS(JW+N2,1)
      ZZ1 = WS(KW,1)
      ZZ2 = WS(KW+N2,1)
      V1  = BS(NW,4)
      V2  = BS(NW+N2,4)

      IF (V1.NE.0) THEN
         IF (V2.NE.0) THEN
            CALL GWIOLINE(XX1,YY1,XX2,YY2,0)
          ELSE
            CALL HIDBRANCH1(XX1,YY1,ZZ1,XX2,YY2,ZZ2,WS,TS,HS,BS,NUV)
         ENDIF
       ELSE IF (V2.NE.0) THEN
         CALL HIDBRANCH1(XX2,YY2,ZZ2,XX1,YY1,ZZ1,WS,TS,HS,BS,NUV)
      ENDIF

      RETURN
      END

      SUBROUTINE HIDBRANCH1(XX0,YY0,ZZ0,XX3,YY3,ZZ3,WS,TS,HS,BS,NUV)
      PARAMETER (DMIN=0.2)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      REAL*4    WS(NUV,3),TS(*)
      INTEGER   HS(NUV,2)
      BYTE      BS(NUV,4)

      XX1 = XX0
      YY1 = YY0
      ZZ1 = ZZ0
      XX2 = XX3
      YY2 = YY3
      ZZ2 = ZZ3
  100    CONTINUE
        XXX = (XX1 + XX2)/2
        YYY = (YY1 + YY2)/2
        ZZZ = (ZZ1 + ZZ2)/2
        CALL SEARCHIMAX(TS,HS(1,2),BS)
        IF (IV.NE.0) CALL VISIBLELINE(WS,HS,BS(1,3),BS,HS(1,2))
        IF (IV.EQ.0) THEN
           XX2 = XXX
           YY2 = YYY
           ZZ2 = ZZZ
         ELSE
           XX1 = XXX
           YY1 = YYY
           ZZ1 = ZZZ
        ENDIF
        IF (ABS(XX1-XX2)+ABS(YY1-YY2).GE.DMIN) GO TO 100

      IF (XX0.NE.XX1.OR.YY0.NE.YY1) CALL GWIOLINE(XX0,YY0,XX1,YY1,0)

      RETURN
      END

      SUBROUTINE VISIBLEDOT(WS,ORDER,TYPE,REGSEL,REGION,REGDER,IND)
      PARAMETER (NDIV=16,MASK=2**16-1)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      COMMON /PROF3DNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      REAL*4    WS(*)
      INTEGER   ORDER(*),REGION(*),REGSEL(*),REGDER(*)
      BYTE      TYPE(*),TY1,TY2,TY3,TY4

*     REMOVE CURRENT QUADRILATERAL
      NW       = NUNV1(NP)+NK
      TY1      = TYPE(NW)
      TYPE(NW) = 0
      KI       = MOD(NK-1,NU(NP)) + 1
      KJ       = (NK-1)/NU(NP) + 1
      IF (KI.GT.1) THEN
         TY3        = TYPE(NW-1)
         TYPE(NW-1) = 0
         IF (KJ.GT.1) THEN
            TY4           = TYPE(NW-NU(NP)-1)
            TYPE(NW-NU(NP)-1) = 0
         ENDIF
      ENDIF
      IF (KJ.GT.1) THEN
         TY2         = TYPE(NW-NU(NP))
         TYPE(NW-NU(NP)) = 0
      ENDIF

      IE  = 0
      ID  = IND
      GO TO 1

      ENTRY VISIBLELINE(WS,ORDER,TYPE,REGSEL,REGION)

*     REMOVE CURRENT QUADRILATERAL
      NW       = NUNV1(NP)+NK
      TY1      = TYPE(NW)
      TYPE(NW) = 0
      KI       = MOD(NK-1,NU(NP)) + 1
      KJ       = (NK-1)/NU(NP) + 1
      IF (IDIR.EQ.0.AND.KJ.GT.1) THEN
         TY2         = TYPE(NW-NU(NP))
         TYPE(NW-NU(NP)) = 0
       ELSE IF (IDIR.NE.0.AND.KI.GT.1) THEN
         TY3        = TYPE(NW-1)
         TYPE(NW-1) = 0
      ENDIF

      IE = 1
      ID = 0

    1    CONTINUE

      DO 10 K0 = 1, K0MAX
         I   = REGSEL(K0)
         K   = ORDER(I)
         ITY = TYPE(K)
         IF (ITY.EQ.0) GO TO 10
         DO NPP = NPROF, 2, -1
            IF (K.GT.NUNV1(NPP)) GO TO 105
         ENDDO
  105    CALL TRIVISIBLE(WS(NUNV3(NPP)+1),NUNV(NPP),K,NPP)
         IF (IV.EQ.0) GO TO 100
   10   CONTINUE

      IF (ID.EQ.0) THEN
         IF (I0.NE.0) THEN
            DO I = I0, I0MAX
              IF (IAND(NR,REGION(I)).EQ.NR) THEN
                 K   = ORDER(I)
                 ITY = TYPE(K)
                 IF (ITY.NE.0) THEN
                    DO NPP = NPROF, 2, -1
                       IF (K.GT.NUNV1(NPP)) GO TO 102
                    ENDDO
  102               CALL TRIVISIBLE(WS(NUNV3(NPP)+1),NUNV(NPP),K,NPP)
                    IF (IV.EQ.0) GO TO 100
                 ENDIF
              ENDIF
            ENDDO
         ENDIF

       ELSE
         IK1 = IREGDEX(NX0,NY0)
         IF (NX0.LT.NDIV) THEN
            IK2 = IREGDEX(NX0+1,NY0) - 1
          ELSE
            IK2 = IREGDEX(1,NY0+1) - 1
         ENDIF

         DO IP = IK1, IK2
            I = REGDER(IP)
            IF (I.GT.I0MAX) GO TO 101
            K   = ORDER(I)
            ITY = TYPE(K)
            IF (ITY.NE.0) THEN
               DO NPP = NPROF, 2, -1
                  IF (K.GT.NUNV1(NPP)) GO TO 103
               ENDDO
  103          CALL TRIVISIBLE(WS(NUNV3(NPP)+1),NUNV(NPP),K,NPP)
               IF (IV.EQ.0) GO TO 100
            ENDIF
         ENDDO
  101    DO IP = 1, IREGDEX(1,1)-1
            I = REGDER(IP)
            IF (I.GT.I0MAX) GO TO 100
            IF (IAND(NR,REGION(I)).EQ.NR) THEN
               K   = ORDER(I)
               ITY = TYPE(K)
               IF (ITY.NE.0) THEN
                  DO NPP = NPROF, 2, -1
                     IF (K.GT.NUNV1(NPP)) GO TO 104
                  ENDDO
  104             CALL TRIVISIBLE(WS(NUNV3(NPP)+1),NUNV(NPP),K,NPP)
                  IF (IV.EQ.0) GO TO 100
               ENDIF
            ENDIF
         ENDDO
      ENDIF

  100   CONTINUE
      IF (IE.EQ.0) THEN
          TYPE(NW) = TY1
          IF (KI.GT.1) THEN
              TYPE(NW-1) = TY3
              IF (KJ.GT.1) TYPE(NW-NU(NP)-1) = TY4
            ENDIF
          IF (KJ.GT.1) TYPE(NW-NU(NP)) = TY2
        ELSE
          TYPE(NW) = TY1
          IF (IDIR.EQ.0.AND.KJ.GT.1) THEN
              TYPE(NW-NU(NP)) = TY2
           ELSE IF (IDIR.NE.0.AND.KI.GT.1) THEN
              TYPE(NW-1)  = TY3
           ENDIF
        ENDIF

      RETURN
      END

      SUBROUTINE DRAWTRISURFACE(X,Y,Z,WS,HS,BS,NP,NS,NODE,IND)
      PARAMETER (NDIV=16)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8    X(*),Y(*),Z(*)
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,4)
      BYTE      BS(NP,3)
      INTEGER   NODE(3,*)
      REAL      TRIX(3),TRIY(3)

      IF (IND.EQ.-1000) THEN
         IND1 = 0
         IPRE = 0
         IF (NSMODE.GE.0) IND1 = -1
       ELSE
         IND1 = IND
         IPRE = 1
         IF (IND1.GT.0.AND.NP.LT.NDIV*NDIV) IND1 = 0
      ENDIF

      IF (ICLP3D.EQ.0.OR.IPRE.EQ.0) THEN
         DO 10 N = 1, NT
            HS(N,2) = N
   10    CONTINUE
         NORDER = NT

       ELSE IF (NSMODE.EQ.30) THEN
         NORDER = 0
         DO 11 N = 1, NT
            N1    = 2*NODE(1,N)-1
            N2    = 2*NODE(2,N)-1
            N3    = 2*NODE(3,N)-1
            XX    = (X(N1)+X(N2)+X(N3))/3
            YY    = (Y(N1)+Y(N2)+Y(N3))/3
            ZZ    = (Z(N1)+Z(N2)+Z(N3))/3
            IF (XX.GE.tdx1.AND.XX.LE.tdx2.AND.
     +               YY.GE.tdy1.AND.YY.LE.tdy2.AND.
     +                     ZZ.GE.tdz1.AND.ZZ.LE.tdz2) THEN
               NORDER = NORDER + 1
               HS(NORDER,2) = N
            ENDIF
   11    CONTINUE
       ELSE
         NORDER = 0
         DO 12 N = 1, NT
            N1    = NODE(1,N)
            N2    = NODE(2,N)
            N3    = NODE(3,N)
            XX    = (X(N1)+X(N2)+X(N3))/3
            YY    = (Y(N1)+Y(N2)+Y(N3))/3
            ZZ    = (Z(N1)+Z(N2)+Z(N3))/3
            IF (XX.GE.tdx1.AND.XX.LE.tdx2.AND.
     +               YY.GE.tdy1.AND.YY.LE.tdy2.AND.
     +                     ZZ.GE.tdz1.AND.ZZ.LE.tdz2) THEN
               NORDER = NORDER + 1
               HS(NORDER,2) = N
            ENDIF
   12    CONTINUE
      ENDIF

      IND0 = IND1
      CALL TRZDATASORT(WS(1,1),WS(1,2),WS(1,3),HS(1,1),HS(1,2),HS(1,3)
     ,                  ,NODE,IND0)
      IF (NSMODE.GE.0) RETURN

      IF (IND1.NE.0) THEN
         IF (IND0.GT.NORDER*2/3) THEN
            IND0 = 0
           ELSE
            IND0 = 1
            CALL TRREGIONORDER(HS(1,3),BS,HS(1,4))
         ENDIF
      ENDIF

      DO N = 1, NU
         XXX = WS(N,1)
         YYY = WS(N,2)
         ZZZ = WS(N,3)
         CALL TRSEARCHIMAX2(HS)
         IF (IV.NE.0) CALL TRVISIBLEDOT(WS,HS(1,2),BS
     ,                         ,HS(1,3),HS(1,4),NODE,IND0)
         BS(N,3) = IV
      ENDDO

      CALL TRREMOVEHIDDEN(HS,HS(1,2),HS(1,3),BS(1,3),NODE)

      NR   = 0

      DO K = 1, NORDER
         KN = HS(K,2)
         N1 = NODE(1,KN)
         N2 = NODE(2,KN)
         N3 = NODE(3,KN)

         IF (BS(N1,3).NE.0.AND.BS(N2,3).NE.0.AND.BS(N3,3).NE.0) THEN
            TRIX(1)  = WS(N1,1)
            TRIX(2)  = WS(N2,1)
            TRIX(3)  = WS(N3,1)
            TRIY(1)  = WS(N1,2)
            TRIY(2)  = WS(N2,2)
            TRIY(3)  = WS(N3,2)
            ZZ1      = WS(N1,3)
            ZZ2      = WS(N2,3)
            ZZ3      = WS(N3,3)
            XXX = (TRIX(1) + TRIX(2) + TRIX(3))/3
            YYY = (TRIY(1) + TRIY(2) + TRIY(3))/3
            ZZZ = (ZZ1 + ZZ2 + ZZ3)/3
            CALL TRSEARCHIMAX(HS,HS(1,3),BS)
            IF (IV.NE.0) THEN
               CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
            ENDIF
*            write(*,*) kn,iv
            IF (IV.NE.0) THEN
               CALL GWIOPOLYGON(TRIX,TRIY,3,1)
            ENDIF
          ELSE
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N1,N2)
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N2,N3)
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N3,N1)
         ENDIF
      ENDDO

      RETURN
      END

      SUBROUTINE TRREMOVEHIDDEN(TS,ORDER,REGION,VPOS,NODE)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL*4    TS(*)
      INTEGER   ORDER(*),REGION(*),NODE(3,*)
      BYTE      VPOS(*)

      K1 = 0
      DO 10 N = 1, NORDER
         K  = ORDER(N)
         IF (VPOS(NODE(1,K)).NE.0.OR.VPOS(NODE(2,K)).NE.0.OR.
     +                          VPOS(NODE(3,K)).NE.0) THEN
            K1         = K1 + 1
            TS(K1)     = TS(N)
            ORDER(K1)  = ORDER(N)
            REGION(K1) = REGION(N)
         ENDIF
   10  CONTINUE

      NORDER = K1

      RETURN
      END

      SUBROUTINE TRHIDBRANCH(WS,HS,BS,NP,NS,NODE,N1,N2)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      INTEGER   V1,V2
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,3),NODE(3,*)
      BYTE      BS(NP,3)

      XX1  = WS(N1,1)
      XX2  = WS(N2,1)
      YY1  = WS(N1,2)
      YY2  = WS(N2,2)
      ZZ1  = WS(N1,3)
      ZZ2  = WS(N2,3)
      V1   = BS(N1,3)
      V2   = BS(N2,3)
      NNN1 = N1
      NNN2 = N2

      IF (V1.NE.0) THEN
         IF (V2.NE.0) THEN
           XXX = (XX1 + XX2)/2
           YYY = (YY1 + YY2)/2
           ZZZ = (ZZ1 + ZZ2)/2
           CALL TRSEARCHIMAX(HS,HS(1,3),BS)
           IF (IV.NE.0) THEN
              CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
           ENDIF
            if (IV.NE.0) CALL GWIOLINE(XX1,YY1,XX2,YY2,0)
          ELSE
            CALL TRHIDBRANCH1(XX1,YY1,ZZ1,XX2,YY2,ZZ2
     ,                                      ,WS,HS,BS,NP,NS,NODE)
         ENDIF
       ELSE IF (V2.NE.0) THEN
         CALL TRHIDBRANCH1(XX2,YY2,ZZ2,XX1,YY1,ZZ1,WS,HS,BS,NP,NS,NODE)
      ENDIF

      RETURN
      END

      SUBROUTINE TRHIDBRANCH1(XX0,YY0,ZZ0,XX3,YY3,ZZ3
     ,                                   ,WS,HS,BS,NP,NS,NODE)
      PARAMETER (DMIN=0.2)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,3),NODE(3,*)
      BYTE      BS(NP,4)

      XX1 = XX0
      YY1 = YY0
      ZZ1 = ZZ0
      XX2 = XX3
      YY2 = YY3
      ZZ2 = ZZ3
  100    CONTINUE
        XXX = (XX1 + XX2)/2
        YYY = (YY1 + YY2)/2
        ZZZ = (ZZ1 + ZZ2)/2
        CALL TRSEARCHIMAX(HS,HS(1,3),BS)
        IF (IV.NE.0) THEN
           CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
        ENDIF
        IF (IV.EQ.0) THEN
           XX2 = XXX
           YY2 = YYY
           ZZ2 = ZZZ
         ELSE
           XX1 = XXX
           YY1 = YYY
           ZZ1 = ZZZ
        ENDIF
        IF (ABS(XX1-XX2)+ABS(YY1-YY2).GE.DMIN) GO TO 100

      IF (XX0.NE.XX1.OR.YY0.NE.YY1) THEN
         CALL GWIOLINE(XX0,YY0,XX1,YY1,0)
      ENDIF

      RETURN
      END
