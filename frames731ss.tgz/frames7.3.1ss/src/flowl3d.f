*******************************************************
*              F  R  A  M  E  S   V.7                 *
*                DRAW  3D  STREAM  LINE               *
*           USING RUNGE-KUTTA APPROXIMATION           *
*         PROGRAMMED BY T. TAGUCHI (SETSUNAN)         *
*                 SINCE APRIL/20/2000                 *
*******************************************************
      SUBROUTINE FR_FLOW3DLINE(X,Y,Z,NMAX,XFLD,YFLD,ZFLD
     ,                          ,NXMAX,NYMAX,NZMAX,ICOL,FMIN,ND)
      IMPLICIT REAL*8 (A-H)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,XA,YA
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,PX,PY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      REAL*8 XFLD(NXMAX,NYMAX,NZMAX),YFLD(NXMAX,NYMAX,NZMAX)
     ,      ,ZFLD(NXMAX,NYMAX,NZMAX)
      REAL*8 X(*),Y(*),Z(*),FMIN
      REAL*8 X0,Y0,Z0,X1,Y1,Z1,R0,T0,R1,T1,RR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /FLUIDREGIONCOM3D/ RNX1,RNX2,RNY1,RNY2,RNZ1,RNZ2
     ,                         ,NX1,NX2,NY1,NY2,NZ1,NZ2,NFMOD
      COMMON /FLRREGIONCOM3D/ RNXM1,RNXM2,RNYM1,RNYM2,RNZM1,RNZM2,NFCHK
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /FLRREGION32COM/ RRXM1,RRXM2,RRYM1,RRYM2,RRZM1,RRZM2
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      SAVE XMIN0,YMIN0,ZMIN0

      IF (IGCANVAS.LT.0.AND.NMAX.GE.0) RETURN

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.NXMAX-1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - FLOW3DLINE')
            RETURN
         ENDIF
         IF (NX2.GE.NXMAX) NX2 = NXMAX - 1
       ELSE
         NX1 = 0
         NX2 = NXMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.NYMAX-1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - FLOW3DLINE')
            RETURN
         ENDIF
         IF (NY2.GE.NYMAX) NY2 = NYMAX - 1
       ELSE
         NY1 = 0
         NY2 = NYMAX - 1
      ENDIF

      IF (NZDMIN.GT.0) THEN
         NZ1 = NZDMIN - 1
         NZ2 = NZDMAX - 1
         IF (NZ1.GE.NZMAX-1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF K REGION - FLOW3DLINE')
            RETURN
         ENDIF
         IF (NZ2.GE.NZMAX) NZ2 = NZMAX - 1
       ELSE
         NZ1 = 0
         NZ2 = NZMAX - 1
      ENDIF

      NFM0  = 0
      NFMOD = 0
      IF (NXMAX.LE.1) THEN
         NFM0  = NFM0 + 1
         NFMOD = 1
      ENDIF
      IF (NYMAX.LE.1) THEN
         NFM0  = NFM0 + 1
         NFMOD = 2
      ENDIF
      IF (NZMAX.LE.1) THEN
         NFM0  = NFM0 + 1
         NFMOD = 3
      ENDIF
      IF (NFM0.GT.1) THEN
         CALL FRAMESERROR('REQUIRE LARGER DIMENSION - FLOW3DLINE')
         RETURN
      ENDIF

      IF (NMAX.GE.0) THEN
         IF (IFRAM.EQ.0) THEN
*            IFRAM = 999
            IF (IDFFR2.LT.0) THEN
               IDFR = 3
              ELSE
               IDFR = IDFFR3
            ENDIF
            CALL FR_FRAME3D(DBLE(NX1),DBLE(NX2),DBLE(NY1),DBLE(NY2)
     ,                           ,DBLE(NZ1),DBLE(NZ2),IDFR)
         ENDIF
         XMIN0 = XMIN
         YMIN0 = YMIN
         ZMIN0 = ZMIN
         IF (NFMOD.EQ.2) THEN
            YT    = 1
            IF (MODEGEOM.EQ.2.AND.XMIN0.LT.0) XMIN0 = 0
          ELSE
            YT    = (YMAX-YMIN0)/(NY2-NY1)
         ENDIF
         IF (NFMOD.EQ.1) THEN
            XT    = 1
          ELSE
            XT    = (XMAX-XMIN0)/(NX2-NX1)
         ENDIF
         IF (NFMOD.EQ.3) THEN
            ZT    = 1
          ELSE
            ZT    = (ZMAX-ZMIN0)/(NZ2-NZ1)
         ENDIF
       ELSE
         IF (IFRAM.NE.0) THEN
            XMIN0 = XMIN
            YMIN0 = YMIN
            ZMIN0 = ZMIN
            IF (NFMOD.EQ.2) THEN
               YT    = 1
               IF (MODEGEOM.EQ.2.AND.XMIN0.LT.0) XMIN0 = 0
             ELSE
               YT    = (YMAX-YMIN0)/(NY2-NY1)
            ENDIF
            IF (NFMOD.EQ.1) THEN
               XT    = 1
             ELSE
               XT    = (XMAX-XMIN0)/(NX2-NX1)
            ENDIF
            IF (NFMOD.EQ.3) THEN
               ZT    = 1
             ELSE
               ZT    = (ZMAX-ZMIN0)/(NZ2-NZ1)
            ENDIF
          ELSE IF (NFCHK.EQ.0) THEN
            XT    = 1
            YT    = 1
            ZT    = 1
            IF (NFMOD.EQ.1) THEN
               XMIN0 = XMIN
             ELSE
               XMIN0 = NX1
            ENDIF
            IF (NFMOD.EQ.2) THEN
               YMIN0 = YMIN
             ELSE
               YMIN0 = NY1
            ENDIF
            IF (NFMOD.EQ.3) THEN
               ZMIN0 = ZMIN
             ELSE
               ZMIN0 = NZ1
            ENDIF
          ELSE
            IF (NFMOD.EQ.1) THEN
               XT    = 1
               XMIN0 = XMIN
             ELSE
               XT    = (RRXM2-RRXM1)/(NX2-NX1)
               XMIN0 = RRXM1
            ENDIF
            IF (NFMOD.EQ.2) THEN
               YT    = 1
               YMIN0 = YMIN
             ELSE
               YT    = (RRYM2-RRYM1)/(NY2-NY1)
               YMIN0 = RRYM1
            ENDIF
            IF (NFMOD.EQ.3) THEN
               ZT    = 1
               ZMIN0 = ZMIN
             ELSE
               ZT    = (RRZM2-RRZM1)/(NZ2-NZ1)
               ZMIN0 = RRZM1
            ENDIF
         ENDIF
      ENDIF

      IF (NFCHK.EQ.0) THEN
         IF (NFMOD.EQ.1) THEN
            RNX1  = XMIN
            RNX2  = XMAX
          ELSE
            RNX1  = NX1
            RNX2  = NX2
         ENDIF
         IF (NFMOD.EQ.2) THEN
            RNY1  = YMIN
            RNY2  = YMAX
          ELSE
            RNY1  = NY1
            RNY2  = NY2
         ENDIF
         IF (NFMOD.EQ.3) THEN
            RNZ1  = ZMIN
            RNZ2  = ZMAX
          ELSE
            RNZ1  = NZ1
            RNZ2  = NZ2
         ENDIF
       ELSE
         IF (NFMOD.EQ.1) THEN
            RNX1  = XMIN
            RNX2  = XMAX
          ELSE
            RNX1  = (RNXM1-XMIN0)/XT + NX1
            RNX2  = (RNXM2-XMIN0)/XT + NX1
            IF (RNX1.LT.NX1) RNX1 = NX1
            IF (RNX2.GT.NX2) RNX2 = NX2
         ENDIF
         IF (NFMOD.EQ.2) THEN
            RNY1  = YMIN
            RNY2  = YMAX
          ELSE
            RNY1  = (RNYM1-YMIN0)/YT + NY1
            RNY2  = (RNYM2-YMIN0)/YT + NY1
            IF (RNY1.LT.NY1) RNY1 = NY1
            IF (RNY2.GT.NY2) RNY2 = NY2
         ENDIF
         IF (NFMOD.EQ.3) THEN
            RNZ1  = ZMIN
            RNZ2  = ZMAX
          ELSE
            RNZ1  = (RNZM1-ZMIN0)/ZT + NZ1
            RNZ2  = (RNZM2-ZMIN0)/ZT + NZ1
            IF (RNZ1.LT.NZ1) RNZ1 = NZ1
            IF (RNZ2.GT.NZ2) RNZ2 = NZ2
         ENDIF
      ENDIF

      IF (ND.NE.0) THEN
         DD = 1.D0/DBLE(ND)
        ELSE 
         DD = 0.2D0
      ENDIF
      NN = 1

      IF (NMAX.LT.0) THEN
         NMAX0 = -NMAX
       ELSE
         NMAX0 = NMAX
      ENDIF

      IF (NFMOD.EQ.2.AND.MODEGEOM.EQ.2) GO TO 1100

      X0  = (X(1)-XMIN0)/XT + NX1
      Y0  = (Y(1)-YMIN0)/YT + NY1
      Z0  = (Z(1)-ZMIN0)/ZT + NZ1

      DO M = 2, NMAX0
         CALL FLOWVALUE3D(X0,Y0,Z0,FX0,FY0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) GO TO 1000

         FA  = FX0*FX0 + FY0*FY0 + FZ0*FZ0
         IF (FA.LE.FMIN) GO TO 1000

         DH  = DD/SQRT(FA)
         DH2 = 0.5D0*DH

         DX1 = FX0*DH2
         DY1 = FY0*DH2
         DZ1 = FZ0*DH2
         X1  = X0 + DX1
         Y1  = Y0 + DY1
         Z1  = Z0 + DZ1
         CALL FLOWVALUE3D(X1,Y1,Z1,FX0,FY0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) GO TO 800

         DX2 = FX0*DH2
         DY2 = FY0*DH2
         DZ2 = FZ0*DH2
         X1  = X0 + DX2
         Y1  = Y0 + DY2
         Z1  = Z0 + DZ2
         CALL FLOWVALUE3D(X1,Y1,Z1,FX0,FY0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) THEN
            DX1 = DX2
            DY1 = DY2
            DZ1 = DZ2
            GO TO 800
         ENDIF

         DX3 = FX0*DH
         DY3 = FY0*DH
         DZ3 = FZ0*DH
         X1  = X0 + DX3
         Y1  = Y0 + DY3
         Z1  = Z0 + DZ3
         CALL FLOWVALUE3D(X1,Y1,Z1,FX0,FY0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) THEN
            DX1 = DX3
            DY1 = DY3
            DZ1 = DZ3
            GO TO 800
         ENDIF

         DX4 = FX0*DH2
         DY4 = FY0*DH2
         DZ4 = FZ0*DH2
         X0  = X0 + (DX1 + DX2 + DX2 + DX3 + DX4)/3.D0
         Y0  = Y0 + (DY1 + DY2 + DY2 + DY3 + DY4)/3.D0
         Z0  = Z0 + (DZ1 + DZ2 + DZ2 + DZ3 + DZ4)/3.D0

         NN     = NN + 1
         X(NN)  = (X0-NX1)*XT + XMIN0
         Y(NN)  = (Y0-NY1)*YT + YMIN0
         Z(NN)  = (Z0-NZ1)*ZT + ZMIN0
      ENDDO

*      CALL FRAMESERROR('EXCEED MAXIMUM FIELD LINE STEP - FLOW3DLINE')
      GO TO 1000

  800 CONTINUE      
      IF (IND.EQ.1) THEN
         Y0 = Y0 + DY1*(RNX1-X0)/DX1
         Z0 = Z0 + DZ1*(RNX1-X0)/DX1
         X0 = RNX1
       ELSE IF (IND.EQ.2) THEN
         Y0 = Y0 + DY1*(RNX2-X0)/DX1
         Z0 = Z0 + DZ1*(RNX2-X0)/DX1
         X0 = RNX2
       ELSE IF (IND.EQ.4) THEN
         X0 = X0 + DX1*(RNY1-Y0)/DY1
         Z0 = Z0 + DZ1*(RNY1-Y0)/DY1
         Y0 = RNY1
       ELSE IF (IND.EQ.8) THEN
         X0 = X0 + DX1*(RNY2-Y0)/DY1
         Z0 = Z0 + DZ1*(RNY2-Y0)/DY1
         Y0 = RNY2
       ELSE IF (IND.EQ.16) THEN
         X0 = X0 + DX1*(RNZ1-Z0)/DZ1
         Y0 = Y0 + DY1*(RNZ1-Z0)/DZ1
         Z0 = RNZ1
       ELSE
         X0 = X0 + DX1*(RNZ2-Z0)/DZ1
         Y0 = Y0 + DY1*(RNZ2-Z0)/DZ1
         Z0 = RNZ2
      ENDIF
      NN     = NN + 1
      X(NN)  = (X0-NX1)*XT + XMIN0
      Y(NN)  = (Y0-NY1)*YT + YMIN0
      Z(NN)  = (Z0-NZ1)*ZT + ZMIN0

 1000 CONTINUE
      IF (NMAX.LT.0) THEN
         NMAX = NN
       ELSE IF (NN.GT.1) THEN
         CALL FR_GRAPH3D(X,Y,Z,NN,ICOL,1)
      ENDIF

      RETURN

 1100 CONTINUE

      R0  = (SQRT(X(1)**2+Y(1)**2)-XMIN0)/XT + NX1
      T0  = ATAN2(Y(1),X(1))
      Z0  = (Z(1)-ZMIN0)/ZT + NZ1

      DO M = 2, NMAX0
         CALL FLOWVALUE3D(R0,0.D0,Z0,FR0,FT0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) GO TO 2000

         FA  = FR0*FR0 + FT0*FT0 + FZ0*FZ0
         IF (FA.LE.FMIN) GO TO 2000

         DH  = DD/SQRT(FA)
         DH2 = 0.5D0*DH

         DR1 = FR0*DH2
         DT1 = FT0*DH2/R0
         DZ1 = FZ0*DH2
         R1  = R0 + DR1
         T1  = T0 + DT1
         Z1  = Z0 + DZ1
         CALL FLOWVALUE3D(R1,0.D0,Z1,FR0,FT0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) GO TO 1800

         DR2 = FR0*DH2
         DT2 = FT0*DH2/R1
         DZ2 = FZ0*DH2
         R1  = R0 + DR2
         T1  = T0 + DT2
         Z1  = Z0 + DZ2
         CALL FLOWVALUE3D(R1,0.D0,Z1,FR0,FT0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) THEN
            DR1 = DR2
            DT1 = DT2
            DZ1 = DZ2
            GO TO 1800
         ENDIF

         DR3 = FR0*DH
         DT3 = FT0*DH/R1
         DZ3 = FZ0*DH
         R1  = R0 + DR3
         T1  = T0 + DT3
         Z1  = Z0 + DZ3
         CALL FLOWVALUE3D(R1,0.D0,Z1,FR0,FT0,FZ0,XFLD,YFLD,ZFLD
     ,                                  ,NXMAX,NYMAX,NZMAX,IND)
         IF (IND.NE.0) THEN
            DR1 = DR3
            DT1 = DT3
            DZ1 = DZ3
            GO TO 1800
         ENDIF

         DR4 = FR0*DH2
         DT4 = FT0*DH2/R1
         DZ4 = FZ0*DH2
         R0  = R0 + (DR1 + DR2 + DR2 + DR3 + DR4)/3.D0
         T0  = T0 + (DT1 + DT2 + DT2 + DT3 + DT4)/3.D0
         Z0  = Z0 + (DZ1 + DZ2 + DZ2 + DZ3 + DZ4)/3.D0

         NN     = NN + 1
         RR     = (R0-NX1)*XT + XMIN0
         X(NN)  = RR*COS(T0)
         Y(NN)  = RR*SIN(T0)
         Z(NN)  = (Z0-NZ1)*ZT + ZMIN0
      ENDDO

*      CALL FRAMESERROR('EXCEED MAXIMUM FIELD LINE STEP - FLOW3DLINE')
      GO TO 2000

 1800 CONTINUE      
      IF (IND.EQ.1) THEN
         T0 = T0 + DT1*(RNX1-R0)/DR1
         Z0 = Z0 + DZ1*(RNX1-R0)/DR1
         R0 = RNX1
       ELSE IF (IND.EQ.2) THEN
         T0 = T0 + DT1*(RNX2-R0)/DR1
         Z0 = Z0 + DZ1*(RNX2-R0)/DR1
         R0 = RNX2
       ELSE IF (IND.EQ.4) THEN
         R0 = R0 + DR1*(RNY1-T0)/DT1
         Z0 = Z0 + DZ1*(RNY1-T0)/DT1
         T0 = RNY1
       ELSE IF (IND.EQ.8) THEN
         R0 = R0 + DR1*(RNY2-T0)/DT1
         Z0 = Z0 + DZ1*(RNY2-T0)/DT1
         T0 = RNY2
       ELSE IF (IND.EQ.16) THEN
         R0 = R0 + DR1*(RNZ1-Z0)/DZ1
         T0 = T0 + DT1*(RNZ1-Z0)/DZ1
         Z0 = RNZ1
       ELSE
         R0 = R0 + DR1*(RNZ2-Z0)/DZ1
         T0 = T0 + DT1*(RNZ2-Z0)/DZ1
         Z0 = RNZ2
      ENDIF
      NN     = NN + 1
      RR     = (R0-NX1)*XT + XMIN0
      X(NN)  = RR*COS(T0)
      Y(NN)  = RR*SIN(T0)
      Z(NN)  = (Z0-NZ1)*ZT + ZMIN0

 2000 CONTINUE
      IF (NMAX.LT.0) THEN
         NMAX = NN
       ELSE IF (NN.GT.1) THEN
         CALL FR_GRAPH3D(X,Y,Z,NN,ICOL,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_FLOW3DRGN(RXMIN,RXMAX,RYMIN,RYMAX,RZMIN,RZMAX)
      COMMON /FLRREGIONCOM3D/ RNXM1,RNXM2,RNYM1,RNYM2,RNZM1,RNZM2,NFCHK
      COMMON /FLRREGION32COM/ RRXM1,RRXM2,RRYM1,RRYM2,RRZM1,RRZM2
      REAL*8 RXMIN,RXMAX,RYMIN,RYMAX,RZMIN,RZMAX

      RNXM1    = RXMIN
      RNXM2    = RXMAX
      RNYM1    = RYMIN
      RNYM2    = RYMAX
      RNZM1    = RZMIN
      RNZM2    = RZMAX
      IF (NFCHK.EQ.0) THEN
         RRXM1 = RXMIN
         RRXM2 = RXMAX
         RRYM1 = RYMIN
         RRYM2 = RYMAX
         RRZM1 = RZMIN
         RRZM2 = RZMAX
      ENDIF        
      NFCHK    = 1

      RETURN
      END
      SUBROUTINE FR_3DFLOWBOX(RXMIN,RXMAX,RYMIN,RYMAX,RZMIN,RZMAX,MASK)
      COMMON /FLRREGIONCOM3D/ RNXM1,RNXM2,RNYM1,RNYM2,RNZM1,RNZM2,NFCHK
      COMMON /FLRREGION32COM/ RRXM1,RRXM2,RRYM1,RRYM2,RRZM1,RRZM2
      REAL*8 RXMIN,RXMAX,RYMIN,RYMAX,RZMIN,RZMAX

      RNXM1    = RXMIN
      RNXM2    = RXMAX
      RNYM1    = RYMIN
      RNYM2    = RYMAX
      RNZM1    = RZMIN
      RNZM2    = RZMAX
      IF (NFCHK.EQ.0) THEN
         RRXM1 = RXMIN
         RRXM2 = RXMAX
         RRYM1 = RYMIN
         RRYM2 = RYMAX
         RRZM1 = RZMIN
         RRZM2 = RZMAX
      ENDIF        
      NFCHK    = 1

      RETURN
      END

      SUBROUTINE FLOWVALUE3D(X,Y,Z,FX,FY,FZ
     ,                  ,XFLD,YFLD,ZFLD,NXMAX,NYMAX,NZMAX,IND)
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 XFLD(0:NXMAX-1,0:NYMAX-1,0:NZMAX-1)
     +      ,YFLD(0:NXMAX-1,0:NYMAX-1,0:NZMAX-1)
     +      ,ZFLD(0:NXMAX-1,0:NYMAX-1,0:NZMAX-1)
      COMMON /FLUIDREGIONCOM3D/ RNX1,RNX2,RNY1,RNY2,RNZ1,RNZ2
     ,                         ,NX1,NX2,NY1,NY2,NZ1,NZ2,NFMOD
      REAL RNX1,RNX2,RNY1,RNY2,RNZ1,RNZ2
      
      IF (X.LT.RNX1) THEN
         IND = 1
         GO TO 999
       ELSE IF (X.GT.RNX2) THEN
         IND = 2
         GO TO 999
       ELSE IF (Y.LT.RNY1) THEN
         IND = 4
         GO TO 999
       ELSE IF (Y.GT.RNY2) THEN
         IND = 8
         GO TO 999
       ELSE IF (Z.LT.RNZ1) THEN
         IND = 16
         GO TO 999
       ELSE IF (Z.GT.RNZ2) THEN
         IND = 32
         GO TO 999
      ENDIF

      IF (NFMOD.EQ.1) THEN
         IX  = 0
         DX  = 0
       ELSE
         IX  = X
         DX  = X - IX
      ENDIF
      IF (NFMOD.EQ.2) THEN
         IY  = 0
         DY  = 0
       ELSE
         IY  = Y
         DY  = Y - IY
      ENDIF
      IF (NFMOD.EQ.3) THEN
         IZ  = 0
         DZ  = 0
       ELSE
         IZ  = Z
         DZ  = Z - IZ
      ENDIF
      IF (IZ.EQ.NZ2) THEN
         IF (IX.EQ.NX2) THEN
            IF (IY.EQ.NY2) THEN
               FX   = XFLD(IX,IY,IZ)
               FY   = YFLD(IX,IY,IZ)
               FZ   = ZFLD(IX,IY,IZ)
             ELSE
               FX = (1.D0 - DY)*XFLD(IX,IY,IZ) + DY*XFLD(IX,IY+1,IZ)
               FY = (1.D0 - DY)*YFLD(IX,IY,IZ) + DY*YFLD(IX,IY+1,IZ)
               FZ = (1.D0 - DY)*ZFLD(IX,IY,IZ) + DY*ZFLD(IX,IY+1,IZ)
            ENDIF
          ELSE IF (IY.EQ.NY2) THEN
            FX   = (1.D0 - DX)*XFLD(IX,IY,IZ) + DX*XFLD(IX+1,IY,IZ)
            FY   = (1.D0 - DX)*YFLD(IX,IY,IZ) + DX*YFLD(IX+1,IY,IZ)
            FZ   = (1.D0 - DX)*ZFLD(IX,IY,IZ) + DX*ZFLD(IX+1,IY,IZ)
          ELSE
            FXC1 = (1.D0 - DY)*XFLD(IX,IY,IZ)   + DY*XFLD(IX,IY+1,IZ)
            FXC2 = (1.D0 - DY)*XFLD(IX+1,IY,IZ) + DY*XFLD(IX+1,IY+1,IZ)
            FX   = (1.D0 - DX)*FXC1 + DX*FXC2
            FYC1 = (1.D0 - DY)*YFLD(IX,IY,IZ)   + DY*YFLD(IX,IY+1,IZ)
            FYC2 = (1.D0 - DY)*YFLD(IX+1,IY,IZ) + DY*YFLD(IX+1,IY+1,IZ)
            FY   = (1.D0 - DX)*FYC1 + DX*FYC2
            FZC1 = (1.D0 - DY)*ZFLD(IX,IY,IZ)   + DY*ZFLD(IX,IY+1,IZ)
            FZC2 = (1.D0 - DY)*ZFLD(IX+1,IY,IZ) + DY*ZFLD(IX+1,IY+1,IZ)
            FZ   = (1.D0 - DX)*FZC1 + DX*FZC2
         ENDIF
       ELSE
         IF (IX.EQ.NX2) THEN
            IF (IY.EQ.NY2) THEN
               FX = (1.D0 - DZ)*XFLD(IX,IY,IZ) + DZ*XFLD(IX,IY,IZ+1)
               FY = (1.D0 - DZ)*YFLD(IX,IY,IZ) + DZ*YFLD(IX,IY,IZ+1)
               FZ = (1.D0 - DZ)*ZFLD(IX,IY,IZ) + DZ*ZFLD(IX,IY,IZ+1)
             ELSE
               FXC1 = (1.D0-DY)*XFLD(IX,IY,IZ)  +DY*XFLD(IX,IY+1,IZ)
               FXC2 = (1.D0-DY)*XFLD(IX,IY,IZ+1)+DY*XFLD(IX,IY+1,IZ+1)
               FX   = (1.D0-DZ)*FXC1 + DZ*FXC2
               FYC1 = (1.D0-DY)*YFLD(IX,IY,IZ)  +DY*YFLD(IX,IY+1,IZ)
               FYC2 = (1.D0-DY)*YFLD(IX,IY,IZ+1)+DY*YFLD(IX,IY+1,IZ+1)
               FY   = (1.D0-DZ)*FYC1 + DZ*FYC2
               FZC1 = (1.D0-DY)*ZFLD(IX,IY,IZ)  +DY*ZFLD(IX,IY+1,IZ)
               FZC2 = (1.D0-DY)*ZFLD(IX,IY,IZ+1)+DY*ZFLD(IX,IY+1,IZ+1)
               FZ   = (1.D0-DZ)*FZC1 + DZ*FZC2
            ENDIF
          ELSE IF (IY.EQ.NY2) THEN
            FXC1 = (1.D0 - DX)*XFLD(IX,IY,IZ)   + DX*XFLD(IX+1,IY,IZ)
            FXC2 = (1.D0 - DX)*XFLD(IX,IY,IZ+1) + DX*XFLD(IX+1,IY,IZ+1)
            FX   = (1.D0 - DZ)*FXC1 + DZ*FXC2
            FYC1 = (1.D0 - DX)*YFLD(IX,IY,IZ)   + DX*YFLD(IX+1,IY,IZ)
            FYC2 = (1.D0 - DX)*YFLD(IX,IY,IZ+1) + DX*YFLD(IX+1,IY,IZ+1)
            FY   = (1.D0 - DZ)*FYC1 + DZ*FYC2
            FZC1 = (1.D0 - DX)*ZFLD(IX,IY,IZ)   + DX*ZFLD(IX+1,IY,IZ)
            FZC2 = (1.D0 - DX)*ZFLD(IX,IY,IZ+1) + DX*ZFLD(IX+1,IY,IZ+1)
            FZ   = (1.D0 - DZ)*FZC1 + DZ*FZC2
          ELSE
            FXC1 = (1.D0 - DY)*XFLD(IX,IY,IZ)   + DY*XFLD(IX,IY+1,IZ)
            FXC2 = (1.D0 - DY)*XFLD(IX+1,IY,IZ) + DY*XFLD(IX+1,IY+1,IZ)
            FX1  = (1.D0 - DX)*FXC1 + DX*FXC2
            FYC1 = (1.D0 - DY)*YFLD(IX,IY,IZ)   + DY*YFLD(IX,IY+1,IZ)
            FYC2 = (1.D0 - DY)*YFLD(IX+1,IY,IZ) + DY*YFLD(IX+1,IY+1,IZ)
            FY1  = (1.D0 - DX)*FYC1 + DX*FYC2
            FZC1 = (1.D0 - DY)*ZFLD(IX,IY,IZ)   + DY*ZFLD(IX,IY+1,IZ)
            FZC2 = (1.D0 - DY)*ZFLD(IX+1,IY,IZ) + DY*ZFLD(IX+1,IY+1,IZ)
            FZ1  = (1.D0 - DX)*FZC1 + DX*FZC2

            FXC1 = (1.D0-DY)*XFLD(IX,IY,IZ+1)  +DY*XFLD(IX,IY+1,IZ+1)
            FXC2 = (1.D0-DY)*XFLD(IX+1,IY,IZ+1)+DY*XFLD(IX+1,IY+1,IZ+1)
            FX2  = (1.D0-DX)*FXC1 + DX*FXC2
            FYC1 = (1.D0-DY)*YFLD(IX,IY,IZ+1)  +DY*YFLD(IX,IY+1,IZ+1)
            FYC2 = (1.D0-DY)*YFLD(IX+1,IY,IZ+1)+DY*YFLD(IX+1,IY+1,IZ+1)
            FY2  = (1.D0-DX)*FYC1 + DX*FYC2
            FZC1 = (1.D0-DY)*ZFLD(IX,IY,IZ+1)  +DY*ZFLD(IX,IY+1,IZ+1)
            FZC2 = (1.D0-DY)*ZFLD(IX+1,IY,IZ+1)+DY*ZFLD(IX+1,IY+1,IZ+1)
            FZ2  = (1.D0-DX)*FZC1 + DX*FZC2
            
            FX   = (1.D0 - DZ)*FX1 + DZ*FX2
            FY   = (1.D0 - DZ)*FY1 + DZ*FY2
            FZ   = (1.D0 - DZ)*FZ1 + DZ*FZ2
         ENDIF
      ENDIF

      IND  = 0
      
  999 RETURN
      END

