/*********************************************************
 *                 F r a m e s  V.7.3                    *
 *               ISOSURFACE Core Routine                 *
 *               Programed by T. Taguchi                 *
 *                  September 16, 2012                   *
 *********************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "frames.h"

#ifndef CompaqVisual
extern void isotriangles(float *,float *,float *,float *,float *,float *
								,int *,int *,int *,int *,int *,int *);
extern void dsfill3dtriangs(double *,double *,double *,float *,float *
								,float *,float *,int *,int *,int *,int *);
extern void dsfill3dwithvect(double *,double *,double *,float *,float *
								,float *,float *,int *,int *,int *,int *);
extern void rdnormpoints(double *,double *,double *,double *,double *
								,double *,double *,double *,double *);
extern void trisurfacemain(double *,double *,double *,double *,int *,int *,int *
								,int *,int *,int *,float *,int *);
#endif

#define NEIGHBOR(X)		(((X)==1) || ((X)==2) || ((X)==4))
#define ABS(X)			((X)<0?(-(X)):(X))
#define SGNDIR(X,N)		((X)>0?(-(N)):(N))
#define INCPOINT		1024
#define INCSURF			1024
#define nothing

typedef int			NODE3[3];
typedef struct surf_link {  int surface;	int next;  } SURFLINK;

static NODE3		*node=NULL;
static int			*ptlink=NULL;
static SURFLINK		*sflink=NULL;
static float		*xx=NULL,*yy=NULL,*zz=NULL,X0,Y0,Z0,DX,DY,DZ;
static float		*ndx=NULL,*ndy=NULL,*ndz=NULL;
static int			maxsf=0,maxpt=0,maxlink=0,errorno,I0,J0,K0;
static int			MAXPOINT=0,MAXSURF=0,MODESAVE=-1;
static signed char	dir[8]={1,-1,-1,1,-1,1,1,-1};

static void clear_memories(void)
{
	free(xx);	free(yy);	free(zz);
	xx=yy=zz=NULL;			node=NULL;
	MAXSURF=MAXPOINT=maxsf=maxpt=0;
	if (ndx!=NULL) {
		free(ndx);	free(ndy);	free(ndz);
		ndx=ndy=ndz=NULL;
	}
}

static int alloc_points(void)
{
	MAXPOINT+=INCPOINT;
	xx=(float *)realloc(xx,sizeof(float)*MAXPOINT);
	yy=(float *)realloc(yy,sizeof(float)*MAXPOINT);
	zz=(float *)realloc(zz,sizeof(float)*MAXPOINT);
	if (xx==NULL || yy==NULL || zz==NULL) return 1;
	return 0;
}

static int alloc_surfaces(void)
{
	MAXSURF+=INCSURF;
	node=(NODE3 *)realloc(node,sizeof(NODE3)*MAXSURF);
	if (node==NULL) return 1;
	return 0;
}

static double interpolate(double *f,double x,double y,double z)
{
	return (	 ((f[0]*(1-x)+f[1]*x)*(1-y)
				+ (f[2]*(1-x)+f[3]*x)*y		)*(1-z)
				+((f[4]*(1-x)+f[5]*x)*(1-y)
				+ (f[6]*(1-x)+f[7]*x)*y		)*z		);
}

static void	quadrilateral(double *f,double f0,float xx[], float yy[],float zz[],int m0)
{
	int i;
	double t,u,x1,y1,z1;

	x1=(xx[0]+xx[2])/2;		y1=(yy[0]+yy[2])/2;		z1=(zz[0]+zz[2])/2;
	t=interpolate(f,x1,y1,z1)-f0;
	x1=(xx[1]+xx[3])/2;		y1=(yy[1]+yy[3])/2;		z1=(zz[1]+zz[3])/2;
	u=interpolate(f,x1,y1,z1)-f0;

	m0++;
	if (ABS(t)<ABS(u)) {
		node[maxsf][0]=m0;
		node[maxsf][1]=m0+1;
		node[maxsf][2]=m0+2;
		maxsf++;
		node[maxsf][0]=m0;
		node[maxsf][1]=m0+2;
		node[maxsf][2]=m0+3;
		maxsf++;
	  }
	  else {
		node[maxsf][0]=m0;
		node[maxsf][1]=m0+1;
		node[maxsf][2]=m0+3;
		maxsf++;
		node[maxsf][0]=m0+1;
		node[maxsf][1]=m0+2;
		node[maxsf][2]=m0+3;
		maxsf++;
	}

	for (i=0;i<4;i++) {
		xx[i]=X0+DX*(I0+xx[i]);
		yy[i]=Y0+DY*(J0+yy[i]);
		zz[i]=Z0+DZ*(K0+zz[i]);
	}
}

static void	pentagon(double *f,double f0,float xx[], float yy[],float zz[],int m0)
{
	int i,j,k,l;
	double t[5],x1,y1,z1;

	for (i=0;i<5;i++) {
		j=(i+2)%5;
		x1=(xx[i]+xx[j])/2;		y1=(yy[i]+yy[j])/2;		z1=(zz[i]+zz[j])/2;
		t[i]=interpolate(f,x1,y1,z1)-f0;
		t[i]=ABS(t[i]);
	}
	for (x1=t[0],i=1,j=0;i<5;i++) {
		if (t[i]<x1) {
			x1=t[i];	j=i;
		}
	}

	i=j;	l=(i+2)%5;	j=(i+3)%5;	k=(i+4)%5;		m0++;
	node[maxsf][0]=m0+i;
	node[maxsf][1]=m0+(i+1)%5;
	node[maxsf][2]=m0+l;
	maxsf++;
	if (t[j]<t[l]) {
		node[maxsf][0]=m0+i;
		node[maxsf][1]=m0+l;
		node[maxsf][2]=m0+j;
		maxsf++;
		node[maxsf][0]=m0+i;
		node[maxsf][1]=m0+j;
		node[maxsf][2]=m0+k;
		maxsf++;
	  }
	  else {
		node[maxsf][0]=m0+i;
		node[maxsf][1]=m0+l;
		node[maxsf][2]=m0+k;
		maxsf++;
		node[maxsf][0]=m0+l;
		node[maxsf][1]=m0+j;
		node[maxsf][2]=m0+k;	
		maxsf++;
	}

	for (i=0;i<5;i++) {
		xx[i]=X0+DX*(I0+xx[i]);
		yy[i]=Y0+DY*(J0+yy[i]);
		zz[i]=Z0+DZ*(K0+zz[i]);
	}
}

static void	hexiagon(double *f,double f0,float xx[], float yy[],float zz[],int m0)
{
	int i,j,k,l,in[6];
	double t[9],u[5],x1,y1,z1;

	for (i=0;i<6;i++) {
		j=(i+2)%6;
		x1=(xx[i]+xx[j])/2;		y1=(yy[i]+yy[j])/2;		z1=(zz[i]+zz[j])/2;
		t[i]=interpolate(f,x1,y1,z1)-f0;
		t[i]=ABS(t[i]);
	}
	for (i=0;i<3;i++) {
		j=(i+3)%6;
		x1=(xx[i]+xx[j])/2;		y1=(yy[i]+yy[j])/2;		z1=(zz[i]+zz[j])/2;
		x1=interpolate(f,x1,y1,z1)-f0;
		t[6+i]=ABS(x1);
	}
	for (x1=t[0],i=1,j=0;i<9;i++) {
		if (t[i]<x1) {
			x1=t[i];	j=i;
		}
	}

	m0++;

	if (j<6) {
		node[maxsf][0]=m0+j;
		node[maxsf][1]=m0+(j+1)%6;
		node[maxsf][2]=m0+(j+2)%6;
		maxsf++;
		for (i=0;i<5;i++) in[i]=(j+2+i)%6;
		for (i=0;i<3;i++) u[i]=t[in[i]];
		u[3]=t[in[0]%3+6];		u[4]=t[in[1]%3+6];
		for (x1=u[0],i=1,j=0;i<5;i++) {
			if (u[i]<x1) {
				x1=u[i];	j=i;
			}
		}

		i=j;	l=(i+2)%5;	j=(i+3)%5;	k=(i+4)%5;
		node[maxsf][0]=m0+in[i];
		node[maxsf][1]=m0+in[(i+1)%5];
		node[maxsf][2]=m0+in[l];
		maxsf++;
		if (u[j]<u[l]) {
			node[maxsf][0]=m0+in[i];
			node[maxsf][1]=m0+in[l];
			node[maxsf][2]=m0+in[j];
			maxsf++;
			node[maxsf][0]=m0+in[i];
			node[maxsf][1]=m0+in[j];
			node[maxsf][2]=m0+in[k];
			maxsf++;
		  }
		  else {
			node[maxsf][0]=m0+in[i];
			node[maxsf][1]=m0+in[l];
			node[maxsf][2]=m0+in[k];
			maxsf++;
			node[maxsf][0]=m0+in[l];
			node[maxsf][1]=m0+in[j];
			node[maxsf][2]=m0+in[k];
			maxsf++;
		}
	  }
	  else {
		for (i=0;i<6;i++) in[i]=(j+i)%6;
		if (t[in[0]]<t[in[1]]) {
			node[maxsf][0]=m0+in[0];
			node[maxsf][1]=m0+in[1];
			node[maxsf][2]=m0+in[2];
			maxsf++;
			node[maxsf][0]=m0+in[0];
			node[maxsf][1]=m0+in[2];
			node[maxsf][2]=m0+in[3];
			maxsf++;
		  }
		  else {
			node[maxsf][0]=m0+in[0];
			node[maxsf][1]=m0+in[1];
			node[maxsf][2]=m0+in[3];
			maxsf++;
			node[maxsf][0]=m0+in[1];
			node[maxsf][1]=m0+in[2];
			node[maxsf][2]=m0+in[3];
			maxsf++;
		}
		if (t[in[3]]<t[in[4]]) {
			node[maxsf][0]=m0+in[3];
			node[maxsf][1]=m0+in[4];
			node[maxsf][2]=m0+in[5];
			maxsf++;
			node[maxsf][0]=m0+in[3];
			node[maxsf][1]=m0+in[5];
			node[maxsf][2]=m0+in[0];
			maxsf++;
		  }
		  else {
			node[maxsf][0]=m0+in[3];
			node[maxsf][1]=m0+in[4];
			node[maxsf][2]=m0+in[0];
			maxsf++;
			node[maxsf][0]=m0+in[4];
			node[maxsf][1]=m0+in[5];
			node[maxsf][2]=m0+in[0];
			maxsf++;
		}
	}

	for (i=0;i<6;i++) {
		xx[i]=X0+DX*(I0+xx[i]);
		yy[i]=Y0+DY*(J0+yy[i]);
		zz[i]=Z0+DZ*(K0+zz[i]);
	}
}

static void make1tri(double *f,double f0,int ip)
{
	double x,y,z,df;
	int i,j,k;

/*	printf("1: %d\n",ip);	*/

	df=f[ip]-f0;
	if (df==0) return;
	x=df/(f[ip]-f[ip^1]);
	y=df/(f[ip]-f[ip^2]);
	z=df/(f[ip]-f[ip^4]);

	i=ip&1;		j=(ip>>1)&1;	k=(ip>>2)&1;
	if (i&1) x=-x;
	if (j&1) y=-y;
	if (k&1) z=-z;

	if (maxpt+2>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	xx[maxpt]=X0+DX*(I0+i+x);	yy[maxpt]=Y0+DY*(J0+j);		zz[maxpt++]=Z0+DZ*(K0+k);
	xx[maxpt]=X0+DX*(I0+i);		yy[maxpt]=Y0+DY*(J0+j+y);	zz[maxpt++]=Z0+DZ*(K0+k);
	xx[maxpt]=X0+DX*(I0+i);		yy[maxpt]=Y0+DY*(J0+j);		zz[maxpt++]=Z0+DZ*(K0+k+z);
/*	if (df*dir[ip]>0) {		*/
	if (SGNDIR(df,dir[ip])>0) {
		node[maxsf][0]=maxpt-2;
		node[maxsf][1]=maxpt-1;
		node[maxsf][2]=maxpt;	
	  }
	  else {
		node[maxsf][0]=maxpt-1;
		node[maxsf][1]=maxpt-2;
		node[maxsf][2]=maxpt;	
	}
	maxsf++;
}
	
static void make2tri(double *f,double f0,int ip0,int ip1)
{
	double t,u,v,w,df0,df1;
	int i0,j0,k0,i1,j1,k1,ip01,ip02,ip11,ip12,ipp;
	int m0;

	df0=f[ip0]-f0;
	df1=f[ip1]-f0;
	if (df0==0) {
		if (df1!=0) make1tri(f,f0,ip1);
		return;
	}
	if (df1==0) {
		make1tri(f,f0,ip0);
		return;
	}

/*	printf("2: %d-%d\n",ip0,ip1);	*/

	ipp=ip0^ip1;
	if (ipp==1) {
		ip01=ip0^2;		ip02=ip0^4;
		ip11=ip1^2;		ip12=ip1^4;
	  }
	  else if (ipp==2) {
		ip01=ip0^1;		ip02=ip0^4;
		ip11=ip1^1;		ip12=ip1^4;
	  }
	  else {
		ip01=ip0^1;		ip02=ip0^2;
		ip11=ip1^1;		ip12=ip1^2;
	}

	t=df0/(f[ip0]-f[ip01]);
	u=df0/(f[ip0]-f[ip02]);
	v=df1/(f[ip1]-f[ip11]);
	w=df1/(f[ip1]-f[ip12]);

	i0=ip0&1;		j0=(ip0>>1)&1;		k0=(ip0>>2)&1;
	i1=ip1&1;		j1=(ip1>>1)&1;		k1=(ip1>>2)&1;

	if (maxpt+4>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf+2>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	if (ipp==1) {
		if (j0&1) t=-t;
		if (k0&1) u=-u;
		if (j1&1) v=-v;
		if (k1&1) w=-w;
		if (SGNDIR(df0,dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0+t;		zz[maxpt++]=k0;
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+u;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+w;
			xx[maxpt]=i1;		yy[maxpt]=j1+v;		zz[maxpt++]=k1;
		  }
		  else {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+u;
			xx[maxpt]=i0;		yy[maxpt]=j0+t;		zz[maxpt++]=k0;
			xx[maxpt]=i1;		yy[maxpt]=j1+v;		zz[maxpt++]=k1;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+w;
		}
	  }
	  else if (ipp==2) {
		if (i0&1) t=-t;
		if (k0&1) u=-u;
		if (i1&1) v=-v;
		if (k1&1) w=-w;
		if (SGNDIR(df0,dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+u;
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i1+v;		yy[maxpt]=j1;		zz[maxpt++]=k1;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+w;
		  }
		  else {
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+u;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+w;
			xx[maxpt]=i1+v;		yy[maxpt]=j1;		zz[maxpt++]=k1;
		}
	  }
	  else {
		if (i0&1) t=-t;
		if (j0&1) u=-u;
		if (i1&1) v=-v;
		if (j1&1) w=-w;
		if (SGNDIR(df0,dir[ip0])>0) {
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i0;		yy[maxpt]=j0+u;		zz[maxpt++]=k0;
			xx[maxpt]=i1;		yy[maxpt]=j1+w;		zz[maxpt++]=k1;
			xx[maxpt]=i1+v;		yy[maxpt]=j1;		zz[maxpt++]=k1;
		  }
		  else {
			xx[maxpt]=i0;		yy[maxpt]=j0+u;		zz[maxpt++]=k0;
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i1+v;		yy[maxpt]=j1;		zz[maxpt++]=k1;
			xx[maxpt]=i1;		yy[maxpt]=j1+w;		zz[maxpt++]=k1;
		}
	}

	m0=maxpt-4;
	quadrilateral(f,f0,&xx[m0],&yy[m0],&zz[m0],m0);
}

static void make3tri(double *f,double f0,int ip0,int ip1,int ip2)
{
	double s,t,u,v,w,df0,df1,df2;
	int i0,j0,k0,i1,j1,k1,i2,j2,k2,ip01,ip02,ip11,ip21,ip22,ipp1,ipp2;

	df0=f[ip0]-f0;
	df1=f[ip1]-f0;
	df2=f[ip2]-f0;
	if (df1==0) {
		if (df0!=0) make1tri(f,f0,ip0);
		if (df2!=0) make1tri(f,f0,ip2);
		return;
	}
	if (df0==0) {
		make2tri(f,f0,ip1,ip2);
		return;
	}
	if (df2==0) {
		make2tri(f,f0,ip0,ip1);
		return;
	}

/*	printf("3: %d-%d-%d\n",ip0,ip1,ip2);	*/

	ipp1=ip0^ip1;	ipp2=ip1^ip2;
	if (ipp1>ipp2) {
		i0=ip0;			ip0=ip2;			ip2=i0;
		i0=ipp1;		ipp1=ipp2;			ipp2=i0;
	}
	if (ipp1==1) {
		ip01=ip0^2;		ip02=ip0^4;
	  }
	  else{
		ip01=ip0^1;		ip02=ip0^4;
	}
	ip11=ip1^((ipp1|ipp2)^7);
	if (ipp2==2) {
		ip21=ip2^1;		ip22=ip2^4;
	  }
	  else {
		ip21=ip2^1;		ip22=ip2^2;
	}

	s=(f[ip0]-f0)/(f[ip0]-f[ip01]);
	t=(f[ip0]-f0)/(f[ip0]-f[ip02]);
	u=(f[ip1]-f0)/(f[ip1]-f[ip11]);
	v=(f[ip2]-f0)/(f[ip2]-f[ip21]);
	w=(f[ip2]-f0)/(f[ip2]-f[ip22]);

	i0=ip0&1;		j0=(ip0>>1)&1;		k0=(ip0>>2)&1;
	i1=ip1&1;		j1=(ip1>>1)&1;		k1=(ip1>>2)&1;
	i2=ip2&1;		j2=(ip2>>1)&1;		k2=(ip2>>2)&1;

	if (maxpt+5>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf+3>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	if (ipp1==1) {
		if (j0&1) s=-s;
		if (k0&1) t=-t;
		if (i2&1) v=-v;
		if (ipp2==2) {
			if (k1&1) u=-u;
			if (k2&1) w=-w;
			if (SGNDIR(df0,dir[ip0])>0) {
				xx[maxpt]=i0;		yy[maxpt]=j0+s;		zz[maxpt++]=k0;
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
				xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+u;
				xx[maxpt]=i2;		yy[maxpt]=j2;		zz[maxpt++]=k2+w;
				xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			  }
			  else {
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
				xx[maxpt]=i0;		yy[maxpt]=j0+s;		zz[maxpt++]=k0;
				xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
				xx[maxpt]=i2;		yy[maxpt]=j2;		zz[maxpt++]=k2+w;
				xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+u;
			}
		  }
		  else {
			if (j1&1) u=-u;
			if (j2&1) w=-w;
			if (SGNDIR(df0,dir[ip0])>0) {
				xx[maxpt]=i0;		yy[maxpt]=j0+s;		zz[maxpt++]=k0;
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
				xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
				xx[maxpt]=i2;		yy[maxpt]=j2+w;		zz[maxpt++]=k2;
				xx[maxpt]=i1;		yy[maxpt]=j1+u;		zz[maxpt++]=k1;
			  }
			  else {
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
				xx[maxpt]=i0;		yy[maxpt]=j0+s;		zz[maxpt++]=k0;
				xx[maxpt]=i1;		yy[maxpt]=j1+u;		zz[maxpt++]=k1;
				xx[maxpt]=i2;		yy[maxpt]=j2+w;		zz[maxpt++]=k2;
				xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			}
		}
	  }
	  else {
		if (i0&1) s=-s;
		if (k0&1) t=-t;
		if (i1&1) u=-u;
		if (i2&1) v=-v;
		if (j2&1) w=-w;
		if (SGNDIR(df0,dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
			xx[maxpt]=i0+s;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i1+u;		yy[maxpt]=j1;		zz[maxpt++]=k1;
			xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			xx[maxpt]=i2;		yy[maxpt]=j2+w;		zz[maxpt++]=k2;
		  }
		  else {
			xx[maxpt]=i0+s;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
			xx[maxpt]=i2;		yy[maxpt]=j2+w;		zz[maxpt++]=k2;
			xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			xx[maxpt]=i1+u;		yy[maxpt]=j1;		zz[maxpt++]=k1;
		}
	}

	i0=maxpt-5;
	pentagon(f,f0,&xx[i0],&yy[i0],&zz[i0],i0);
}

static void make4sqr(double *f,double f0,int ip0,int ip1,int ip2,int ip3)
{
	double t,u,v,w,df;
	int i0,j0,k0,i1,j1,k1,i2,j2,k2,i3,j3,k3,ip01,ip11,ip21,ip31,ipp1,ipp2;
	int m0;

/*	printf("4: %d-%d-%d-%d->>\n",ip0,ip1,ip2,ip3);	*/

	ipp1=ip1^ip2;	ipp2=ip0^ip1;
	ipp1=(ipp1|ipp2)^7;
	if (ipp1==1) {
		ip01=ip0^1;		ip11=ip1^1;
		ip21=ip2^1;		ip31=ip3^1;
	  }
	  else if (ipp1==2) {
		ip01=ip0^2;		ip11=ip1^2;
		ip21=ip2^2;		ip31=ip3^2;
	  }
	  else {
		ip01=ip0^4;		ip11=ip1^4;
		ip21=ip2^4;		ip31=ip3^4;
	}

	df=f[ip0]-f[ip01];
	t=(f[ip0]-f0)/(f[ip0]-f[ip01]);
	u=(f[ip1]-f0)/(f[ip1]-f[ip11]);
	v=(f[ip2]-f0)/(f[ip2]-f[ip21]);
	w=(f[ip3]-f0)/(f[ip3]-f[ip31]);

	i0=ip0&1;		j0=(ip0>>1)&1;		k0=(ip0>>2)&1;
	i1=ip1&1;		j1=(ip1>>1)&1;		k1=(ip1>>2)&1;
	i2=ip2&1;		j2=(ip2>>1)&1;		k2=(ip2>>2)&1;
	i3=ip3&1;		j3=(ip3>>1)&1;		k3=(ip3>>2)&1;

	if (maxpt+4>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf+2>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	if (ipp1==1) {
		if (i0&1) t=-t;
		if (i1&1) u=-u;
		if (i2&1) v=-v;
		if (i3&1) w=-w;
		if (ipp2==2) ipp2=1;
			else	 ipp2=-1;
		if (SGNDIR(df,ipp2*dir[ip0])>0) {
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i1+u;		yy[maxpt]=j1;		zz[maxpt++]=k1;
			xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			xx[maxpt]=i3+w;		yy[maxpt]=j3;		zz[maxpt++]=k3;
		  }
		  else {
			xx[maxpt]=i0+t;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i3+w;		yy[maxpt]=j3;		zz[maxpt++]=k3;
			xx[maxpt]=i2+v;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			xx[maxpt]=i1+u;		yy[maxpt]=j1;		zz[maxpt++]=k1;
		}
	  }
	  else if (ipp1==2) {
		if (j0&1) t=-t;
		if (j1&1) u=-u;
		if (j2&1) v=-v;
		if (j3&1) w=-w;
		if (ipp2==4) ipp2=1;
			else	 ipp2=-1;
		if (SGNDIR(df,ipp2*dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0+t;		zz[maxpt++]=k0;
			xx[maxpt]=i1;		yy[maxpt]=j1+u;		zz[maxpt++]=k1;
			xx[maxpt]=i2;		yy[maxpt]=j2+v;		zz[maxpt++]=k2;
			xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
		  }
		  else {
			xx[maxpt]=i0;		yy[maxpt]=j0+t;		zz[maxpt++]=k0;
			xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
			xx[maxpt]=i2;		yy[maxpt]=j2+v;		zz[maxpt++]=k2;
			xx[maxpt]=i1;		yy[maxpt]=j1+u;		zz[maxpt++]=k1;
		}
	  }
	  else {
		if (k0&1) t=-t;
		if (k1&1) u=-u;
		if (k2&1) v=-v;
		if (k3&1) w=-w;
		if (ipp2==1) ipp2=1;
			else	 ipp2=-1;
		if (SGNDIR(df,ipp2*dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+u;
			xx[maxpt]=i2;		yy[maxpt]=j2;		zz[maxpt++]=k2+v;
			xx[maxpt]=i3;		yy[maxpt]=j3;		zz[maxpt++]=k3+w;
		  }
		  else {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+t;
			xx[maxpt]=i3;		yy[maxpt]=j3;		zz[maxpt++]=k3+w;
			xx[maxpt]=i2;		yy[maxpt]=j2;		zz[maxpt++]=k2+v;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+u;
		}
	}

	m0=maxpt-4;
	quadrilateral(f,f0,&xx[m0],&yy[m0],&zz[m0],m0);
}

static void make4lin(double *f,double f0,int ip0,int ip1,int ip2,int ip3)
{
	double q,s,t,u,v,w,df0,df1,df2,df3;
	int i0,j0,k0,i1,j1,k1,i2,j2,k2,i3,j3,k3;
	int ip01,ip02,ip11,ip21,ip31,ip32,ipp1,ipp2,ipp3;

	df0=f[ip0]-f0;
	df1=f[ip1]-f0;
	df2=f[ip2]-f0;
	df3=f[ip3]-f0;

	if (df0==0) {
		make3tri(f,f0,ip1,ip2,ip3);
		return;
	}
	if (df3==0) {
		make3tri(f,f0,ip0,ip1,ip2);
		return;
	}
	if (df1==0) {
		make1tri(f,f0,ip0);
		make2tri(f,f0,ip2,ip3);
		return;
	}
	if (df2==0) {
		make1tri(f,f0,ip3);
		make2tri(f,f0,ip0,ip1);
		return;
	}

/*	printf("4: %d-%d-%d-%d\n",ip0,ip1,ip2,ip3);		*/

	ipp1=ip0^ip1;	ipp2=ip1^ip2;	ipp3=ip2^ip3;
	if (ipp1>ipp3) {
		i0=ip0;			ip0=ip3;			ip3=i0;
		i0=ip1;			ip1=ip2;			ip2=i0;
		i0=ipp1;		ipp1=ipp3;			ipp3=i0;
		s=df0;			df0=df3;			df3=s;
		s=df1;			df1=df2;			df2=s;
	}
	if (ipp1==1) {
		ip01=ip0^2;		ip02=ip0^4;
		if (ipp2==2) {
			ip11=ip1^4;		ip21=ip2^1;
			ip31=ip3^1;		ip32=ip3^2;
		  }
		  else {
			ip11=ip1^2;		ip21=ip2^1;
			ip31=ip3^1;		ip32=ip3^4;
		}
	  }
	  else{
		ip01=ip0^1;		ip02=ip0^4;
		ip11=ip1^4;		ip21=ip2^2;
		ip31=ip3^1;		ip32=ip3^2;
	}

	q=df0/(f[ip0]-f[ip01]);
	s=df0/(f[ip0]-f[ip02]);
	t=df1/(f[ip1]-f[ip11]);
	u=df2/(f[ip2]-f[ip21]);
	v=df3/(f[ip3]-f[ip31]);
	w=df3/(f[ip3]-f[ip32]);

	i0=ip0&1;		j0=(ip0>>1)&1;		k0=(ip0>>2)&1;
	i1=ip1&1;		j1=(ip1>>1)&1;		k1=(ip1>>2)&1;
	i2=ip2&1;		j2=(ip2>>1)&1;		k2=(ip2>>2)&1;
	i3=ip3&1;		j3=(ip3>>1)&1;		k3=(ip3>>2)&1;

	if (maxpt+6>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf+4>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	if (ipp1==1) {
		if (j0&1) q=-q;
		if (k0&1) s=-s;
		if (i2&1) u=-u;
		if (i3&1) v=-v;
		if (ipp2==2) {
			if (k1&1) t=-t;
			if (j3&1) w=-w;
			if (SGNDIR(df0,dir[ip0])>0) {
				xx[maxpt]=i0;		yy[maxpt]=j0+q;		zz[maxpt++]=k0;
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
				xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+t;
				xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
				xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
				xx[maxpt]=i2+u;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			  }
			  else {
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
				xx[maxpt]=i0;		yy[maxpt]=j0+q;		zz[maxpt++]=k0;
				xx[maxpt]=i2+u;		yy[maxpt]=j2;		zz[maxpt++]=k2;
				xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
				xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
				xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+t;
			}
		  }
		  else {
			if (j1&1) t=-t;
			if (k3&1) w=-w;
			if (SGNDIR(df0,dir[ip0])>0) {
				xx[maxpt]=i0;		yy[maxpt]=j0+q;		zz[maxpt++]=k0;
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
				xx[maxpt]=i2+u;		yy[maxpt]=j2;		zz[maxpt++]=k2;
				xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
				xx[maxpt]=i3;		yy[maxpt]=j3;		zz[maxpt++]=k3+w;
				xx[maxpt]=i1;		yy[maxpt]=j1+t;		zz[maxpt++]=k1;
			  }
			  else {
				xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
				xx[maxpt]=i0;		yy[maxpt]=j0+q;		zz[maxpt++]=k0;
				xx[maxpt]=i1;		yy[maxpt]=j1+t;		zz[maxpt++]=k1;
				xx[maxpt]=i3;		yy[maxpt]=j3;		zz[maxpt++]=k3+w;
				xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
				xx[maxpt]=i2+u;		yy[maxpt]=j2;		zz[maxpt++]=k2;
			}
		  }
	  }
	  else {
		if (i0&1) q=-q;
		if (k0&1) s=-s;
		if (k1&1) t=-t;
		if (j2&1) u=-u;
		if (i3&1) v=-v;
		if (j3&1) w=-w;
		if (SGNDIR(df0,dir[ip0])>0) {
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
			xx[maxpt]=i0+q;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i2;		yy[maxpt]=j2+u;		zz[maxpt++]=k2;
			xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
			xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+t;
		  }
		  else {
			xx[maxpt]=i0+q;		yy[maxpt]=j0;		zz[maxpt++]=k0;
			xx[maxpt]=i0;		yy[maxpt]=j0;		zz[maxpt++]=k0+s;
			xx[maxpt]=i1;		yy[maxpt]=j1;		zz[maxpt++]=k1+t;
			xx[maxpt]=i3+v;		yy[maxpt]=j3;		zz[maxpt++]=k3;
			xx[maxpt]=i3;		yy[maxpt]=j3+w;		zz[maxpt++]=k3;
			xx[maxpt]=i2;		yy[maxpt]=j2+u;		zz[maxpt++]=k2;
		}
	}

	i0=maxpt-6;
	hexiagon(f,f0,&xx[i0],&yy[i0],&zz[i0],i0);
}

static void make4tri(double *f,double f0,int ip0)
{
	double q,s,t,u,v,w,df1,df2,df3;
	int ip1,ip2,ip3;
	int i1,j1,k1,i2,j2,k2,i3,j3,k3;
	int ip11,ip12,ip21,ip22,ip31,ip32;
	int m0;

	ip1=ip0^1;		ip2=ip0^2;		ip3=ip0^4;
	df1=f[ip1]-f0;
	df2=f[ip2]-f0;
	df3=f[ip3]-f0;

	if (df1==0) {
		make3tri(f,f0,ip2,ip0,ip3);
		return;
	}
	if (df2==0) {
		make3tri(f,f0,ip3,ip0,ip1);
		return;
	}
	if (df3==0) {
		make3tri(f,f0,ip1,ip0,ip2);
		return;
	}

/*	printf("4: %d-%d-%d=%d\n",ip0,ip1,ip2,ip3);	*/

	ip11=ip1^2;		ip12=ip1^4;
	ip21=ip2^1;		ip22=ip2^4;
	ip31=ip3^1;		ip32=ip3^2;

	q=df1/(f[ip1]-f[ip11]);
	s=df1/(f[ip1]-f[ip12]);
	t=df2/(f[ip2]-f[ip21]);
	u=df2/(f[ip2]-f[ip22]);
	v=df3/(f[ip3]-f[ip31]);
	w=df3/(f[ip3]-f[ip32]);

	i1=ip1&1;		j1=(ip1>>1)&1;		k1=(ip1>>2)&1;
	i2=ip2&1;		j2=(ip2>>1)&1;		k2=(ip2>>2)&1;
	i3=ip3&1;		j3=(ip3>>1)&1;		k3=(ip3>>2)&1;

	if (maxpt+6>=MAXPOINT && alloc_points()) {
		errorno=1;	return;
	}
	if (maxsf+4>=MAXSURF  && alloc_surfaces()) {
		errorno=1;	return;
	}
	if (j1&1) q=-q;
	if (k1&1) s=-s;
	if (i2&1) t=-t;
	if (k2&1) u=-u;
	if (i3&1) v=-v;
	if (j3&1) w=-w;
	if (SGNDIR(df1,dir[ip0])>0) {
		xx[maxpt]=i1;	yy[maxpt]=j1+q;	zz[maxpt++]=k1;
		xx[maxpt]=i2+t;	yy[maxpt]=j2;	zz[maxpt++]=k2;
		xx[maxpt]=i2;	yy[maxpt]=j2;	zz[maxpt++]=k2+u;
		xx[maxpt]=i3;	yy[maxpt]=j3+w;	zz[maxpt++]=k3;
		xx[maxpt]=i3+v;	yy[maxpt]=j3;	zz[maxpt++]=k3;
		xx[maxpt]=i1;	yy[maxpt]=j1;	zz[maxpt++]=k1+s;
	  }
	  else {
		xx[maxpt]=i1;	yy[maxpt]=j1+q;	zz[maxpt++]=k1;
		xx[maxpt]=i1;	yy[maxpt]=j1;	zz[maxpt++]=k1+s;
		xx[maxpt]=i3+v;	yy[maxpt]=j3;	zz[maxpt++]=k3;
		xx[maxpt]=i3;	yy[maxpt]=j3+w;	zz[maxpt++]=k3;
		xx[maxpt]=i2;	yy[maxpt]=j2;	zz[maxpt++]=k2+u;
		xx[maxpt]=i2+t;	yy[maxpt]=j2;	zz[maxpt++]=k2;
	}

	m0=maxpt-6;
	hexiagon(f,f0,&xx[m0],&yy[m0],&zz[m0],m0);
}

static void isovalued_cube(double *f,double f0)
{
	int i,n,ind[8],is,ip[8],nn,nn1;

	errorno=0;
	for (n=0,i=0;i<8;i++) {
		if (f[i]>=f0) { ind[i]=1;	n++;  }
			else		ind[i]=0;
	}

	if (n>4) is=0;
		else is=1;

	if (n>=8 || n<=0) return;

	for (i=0,n=0;i<8;i++) {
		if (ind[i]==is) ip[n++]=i;
	}

	if (n==1) make1tri(f,f0,ip[0]);
	  else if (n==2) {
		nn=ip[0]^ip[1];
		if (NEIGHBOR(nn)) make2tri(f,f0,ip[0],ip[1]);
		  else {
			make1tri(f,f0,ip[0]);
			make1tri(f,f0,ip[1]);
		}
	  }
	  else if (n==3) {
		nn=ip[0]^ip[1];
		if (NEIGHBOR(nn)) {
			nn=ip[1]^ip[2];
			if (NEIGHBOR(nn)) make3tri(f,f0,ip[0],ip[1],ip[2]);
			  else {
				nn=ip[0]^ip[2];
				if (NEIGHBOR(nn)) make3tri(f,f0,ip[1],ip[0],ip[2]);
				  else {
					make2tri(f,f0,ip[0],ip[1]);
					make1tri(f,f0,ip[2]);
				}
			}
		  }
		  else {
			nn=ip[1]^ip[2];		nn1=ip[0]^ip[2];
			if (NEIGHBOR(nn)) {
				if (NEIGHBOR(nn1)) make3tri(f,f0,ip[0],ip[2],ip[1]);
				  else {
					make2tri(f,f0,ip[1],ip[2]);
					make1tri(f,f0,ip[0]);
				}
			  }
			  else {
				if (NEIGHBOR(nn1)) {
					make2tri(f,f0,ip[0],ip[2]);
					make1tri(f,f0,ip[1]);
				  }
				  else {
					make1tri(f,f0,ip[0]);
					make1tri(f,f0,ip[1]);
					make1tri(f,f0,ip[2]);
				}
			}
		}
	  }
	  else {
		nn=ip[0]^ip[1];
		if (NEIGHBOR(nn)) {
			nn=ip[1]^ip[2];
			if (NEIGHBOR(nn)) {
				nn=ip[2]^ip[3];		nn1=ip[3]^ip[0];
				if (NEIGHBOR(nn)) {
					if (NEIGHBOR(nn1)) make4sqr(f,f0,ip[0],ip[1],ip[2],ip[3]);
						else make4lin(f,f0,ip[0],ip[1],ip[2],ip[3]);
				  }
				  else {
					if (NEIGHBOR(nn1)) make4lin(f,f0,ip[3],ip[0],ip[1],ip[2]);
					  else {
						nn=ip[1]^ip[3];
						if (NEIGHBOR(nn)) make4tri(f,f0,ip[1]);
						  else {
							make3tri(f,f0,ip[0],ip[1],ip[2]);
							make1tri(f,f0,ip[3]);
						}
					}
				}
			  }
			  else {
				nn=ip[0]^ip[3];
				if (NEIGHBOR(nn)) {
					nn=ip[3]^ip[2];
					if (NEIGHBOR(nn)) make4lin(f,f0,ip[1],ip[0],ip[3],ip[2]);
					  else {
						nn=ip[0]^ip[2];
						if (NEIGHBOR(nn)) make4tri(f,f0,ip[0]);
						  else {
							make3tri(f,f0,ip[1],ip[0],ip[3]);
							make1tri(f,f0,ip[2]);
						}
					}
				  }
				  else {
					nn=ip[1]^ip[3];
					if (NEIGHBOR(nn)) {
						nn=ip[2]^ip[3];		nn1=ip[2]^ip[0];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4sqr(f,f0,ip[0],ip[2],ip[3],ip[1]);
								else make4lin(f,f0,ip[0],ip[1],ip[3],ip[2]);
						  }
						  else {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[2],ip[0],ip[1],ip[3]);
							  else {
								make3tri(f,f0,ip[0],ip[1],ip[3]);
								make1tri(f,f0,ip[2]);
							}
						}
					  }
					  else {
						nn=ip[0]^ip[2];		nn1=ip[2]^ip[3];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[1],ip[0],ip[2],ip[3]);
							  else {
								make3tri(f,f0,ip[1],ip[0],ip[2]);
								make1tri(f,f0,ip[3]);
							}
						  }
						  else {
							if (NEIGHBOR(nn1)) {
								make2tri(f,f0,ip[0],ip[1]);
								make2tri(f,f0,ip[2],ip[3]);
							  }
							  else {
							/* This part will never be used. */
								make2tri(f,f0,ip[0],ip[1]);
								make1tri(f,f0,ip[2]);
								make1tri(f,f0,ip[3]);
							}
						}
					}
				}
			}
		  }
		  else {
			nn=ip[1]^ip[2];
			if (NEIGHBOR(nn)) {
				nn=ip[2]^ip[3];
				if (NEIGHBOR(nn)) {
					nn=ip[3]^ip[0];
					if (NEIGHBOR(nn)) make4lin(f,f0,ip[1],ip[2],ip[3],ip[0]);
					  else {
						nn=ip[2]^ip[0];
						if (NEIGHBOR(nn)) make4tri(f,f0,ip[2]);
						  else {
							make3tri(f,f0,ip[1],ip[2],ip[3]);
							make1tri(f,f0,ip[0]);
						}
					}
				  }
				  else {
					nn=ip[1]^ip[3];
					if (NEIGHBOR(nn)) {
						nn=ip[0]^ip[3];		nn1=ip[2]^ip[0];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4sqr(f,f0,ip[0],ip[2],ip[1],ip[3]);
								else make4lin(f,f0,ip[0],ip[3],ip[1],ip[2]);
						  }
						  else {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[0],ip[2],ip[1],ip[3]);
							  else {
								make3tri(f,f0,ip[2],ip[1],ip[3]);
								make1tri(f,f0,ip[0]);
							}
						}
					  }
					  else {
						nn=ip[0]^ip[2];		nn1=ip[0]^ip[3];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[1],ip[2],ip[0],ip[3]);
							  else {
								make3tri(f,f0,ip[0],ip[2],ip[1]);
								make1tri(f,f0,ip[3]);
							}
						  }
						  else {
							if (NEIGHBOR(nn1)) {
								make2tri(f,f0,ip[0],ip[3]);
								make2tri(f,f0,ip[1],ip[2]);
							  }
							  else {
							/* This part will never be used. */
								make2tri(f,f0,ip[1],ip[2]);
								make1tri(f,f0,ip[0]);
								make1tri(f,f0,ip[3]);
							}
						}
					}
				}
			  }
			  else {
				nn=ip[0]^ip[3];
				if (NEIGHBOR(nn)) {
					nn=ip[2]^ip[3];
					if (NEIGHBOR(nn)) {
						nn=ip[1]^ip[3];
						if (NEIGHBOR(nn)) make4tri(f,f0,ip[3]);
						  else {
							make3tri(f,f0,ip[0],ip[3],ip[2]);
							make1tri(f,f0,ip[1]);
						}
					  }
					  else {
						nn=ip[2]^ip[0];		nn1=ip[1]^ip[3];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[2],ip[0],ip[3],ip[1]);
							  else {
								make3tri(f,f0,ip[2],ip[0],ip[3]);
								make1tri(f,f0,ip[1]);
							}
						  }
						  else {
							if (NEIGHBOR(nn1)) {
								make3tri(f,f0,ip[0],ip[3],ip[1]);
								make1tri(f,f0,ip[2]);
							  }
							  else {
							/* This part will never be used. */
								make2tri(f,f0,ip[0],ip[3]);
								make1tri(f,f0,ip[1]);
								make1tri(f,f0,ip[2]);
							}
						}
					}
				  }
				  else {
					nn=ip[0]^ip[2];
					if (NEIGHBOR(nn)) {
						nn=ip[2]^ip[3];		nn1=ip[1]^ip[3];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) make4lin(f,f0,ip[0],ip[2],ip[3],ip[1]);
							  else {
								make3tri(f,f0,ip[0],ip[2],ip[3]);
								make1tri(f,f0,ip[1]);
							}
						  }
						  else {
							if (NEIGHBOR(nn1)) {
								make2tri(f,f0,ip[0],ip[2]);
								make2tri(f,f0,ip[1],ip[3]);
							  }
							  else {
							/* This part will never be used. */
								make2tri(f,f0,ip[0],ip[2]);
								make1tri(f,f0,ip[1]);
								make1tri(f,f0,ip[3]);
							}
						}
					  }
					  else {
						nn=ip[2]^ip[3];		nn1=ip[1]^ip[3];
						if (NEIGHBOR(nn)) {
							if (NEIGHBOR(nn1)) {
								make3tri(f,f0,ip[1],ip[3],ip[2]);
								make1tri(f,f0,ip[0]);
							  }
							  else {
							/* This part will never be used. */
								make2tri(f,f0,ip[2],ip[3]);
								make1tri(f,f0,ip[0]);
								make1tri(f,f0,ip[1]);
							}
						  }
						  else {
							if (NEIGHBOR(nn1)) {
							/* This part will never be used. */
								make2tri(f,f0,ip[1],ip[3]);
								make1tri(f,f0,ip[0]);
								make1tri(f,f0,ip[2]);
							  }
							  else {
								make1tri(f,f0,ip[0]);
								make1tri(f,f0,ip[1]);
								make1tri(f,f0,ip[2]);
								make1tri(f,f0,ip[3]);
							}
						}
					}
				}
			}
		}
	}
}

static int get_normals(void)
{
/*		Caution !!   The node values have an offset 1 for fortran routine.		*/
	int *index,*origin;
	int i,j,ls,np,ns,n1,n2,n3,n0,sb1[32],sb2[32];
	double dx1,dy1,dz1,dx2,dy2,dz2,dx,dy,dz,dd,errx,erry,errz;

/*	First step:  Positional Sorting.	*/
	index=(int *)malloc(sizeof(int)*maxpt);
	origin=(int *)malloc(sizeof(int)*maxpt);
	for (np=0;np<maxpt;np++) origin[np]=np;

	errx=fabs(DX)*1e-6;		erry=fabs(DY)*1e-6;		errz=fabs(DZ)*1e-6;
/*
	for (j=0;j<maxpt-1;j++) {
		for (i=j+1;i<maxpt;i++) {
			if (fabs(xx[i]-xx[j])<=errx) {
				if (fabs(yy[i]-yy[j])<=errx) {
					if (zz[i]<zz[j]) {
						np=origin[j];	origin[j]=origin[i];	origin[i]=np;
						dd=xx[j];		xx[j]=xx[i];			xx[i]=dd;
						dd=yy[j];		yy[j]=yy[i];			yy[i]=dd;
						dd=zz[j];		zz[j]=zz[i];			zz[i]=dd;
					}
				  }
				  else if (yy[i]<yy[j]) {
					np=origin[j];	origin[j]=origin[i];	origin[i]=np;
					dd=xx[j];		xx[j]=xx[i];			xx[i]=dd;
					dd=yy[j];		yy[j]=yy[i];			yy[i]=dd;
					dd=zz[j];		zz[j]=zz[i];			zz[i]=dd;
				}
			  }
			  else if (xx[i]<xx[j]) {
				np=origin[j];	origin[j]=origin[i];	origin[i]=np;
				dd=xx[j];		xx[j]=xx[i];			xx[i]=dd;
				dd=yy[j];		yy[j]=yy[i];			yy[i]=dd;
				dd=zz[j];		zz[j]=zz[i];			zz[i]=dd;
			}
		}
	}
*/

	n0=0;		sb1[0]=0;	sb2[0]=maxpt-1;
	while (n0>=0) {
		n1 = sb1[n0];		n2 = sb2[n0];		n0--;
		while (n1<n2) {
			i=n1;		j=n2;
			dx1=xx[(n1+n2)/2];		dy1=yy[(n1+n2)/2];		dz1=zz[(n1+n2)/2];
			while (i<=j) {
				while (1) {
					if (fabs(xx[i]-dx1)<=errx) {
						if (fabs(yy[i]-dy1)<=erry) {
							if (zz[i]<dz1) i++;
								else break;
						  }
						  else if (yy[i]<dy1) i++;
						  else break;
					  }
					  else if (xx[i]<dx1) i++;
					  else break;
				}
				while (1) {
					if (fabs(xx[j]-dx1)<=errx) {
						if (fabs(yy[j]-dy1)<=erry) {
							if (zz[j]>dz1) j--;
								else break;
						  }
						  else if (yy[j]>dy1) j--;
						  else break;
					  }
					  else if (xx[j]>dx1) j--;
					  else break;
				}
				if (i<=j) {
					np=origin[j];	origin[j]=origin[i];	origin[i]=np;
					dd=xx[j];		xx[j]=xx[i];			xx[i]=dd;
					dd=yy[j];		yy[j]=yy[i];			yy[i]=dd;
					dd=zz[j];		zz[j]=zz[i];			zz[i]=dd;
					i++;	j--;
				}
			}
			if (j-n1<n2-i) {
				if (i<n2) {
					sb1[++n0]=i;		sb2[n0]=n2;
				}
				n2=j;
			  }
			  else {
				if (n1<j) {
					sb1[++n0]=n1;		sb2[n0]=j;
				}
				n1=i;
			}
		}
	}

/*	Second step:  Remove Identical Points.	*/
	index[origin[0]]=0;
	for (i=0,np=1;np<maxpt;np++) {
/*		printf("%05d : %15.10f  %15.10f  %15.10f\n",np,xx[np],yy[np],zz[np]);		*/
		if (fabs(xx[i]-xx[np])>errx || fabs(yy[i]-yy[np])>erry || fabs(zz[i]-zz[np])>=errz) {
			++i;	xx[i]=xx[np];		yy[i]=yy[np];		zz[i]=zz[np];
		}
		index[origin[np]]=i;
	}
	maxpt=i+1;
/*
	for (np=0;np<maxpt;np++) {
		printf("%05d : %15.10f  %15.10f  %15.10f\n",np,xx[np],yy[np],zz[np]);
	}
	printf("Points=%d,  Surface=%d\n",maxpt,maxsf);
*/
	for (ns=0;ns<maxsf;ns++) {
		n1=node[ns][0]-1;		n2=node[ns][1]-1;		n3=node[ns][2]-1;
		node[ns][0]=index[n1]+1;
		node[ns][1]=index[n2]+1;
		node[ns][2]=index[n3]+1;
	}
	free(index);		free(origin);

	ndx=(float *)malloc(sizeof(float)*maxpt);
	ndy=(float *)malloc(sizeof(float)*maxpt);
	ndz=(float *)malloc(sizeof(float)*maxpt);
	ptlink=(int *)malloc(sizeof(int)*maxpt);
	sflink=(SURFLINK *)malloc(sizeof(SURFLINK)*3*maxsf);
	if (ndx==NULL || ndy==NULL || ndz==NULL || ptlink==NULL || sflink==NULL) return 1;

	for (np=0;np<maxpt;np++) ptlink[np]=-1;

/*	Third step:  Make Linked List.	*/
	maxlink=0;
	for (ns=0;ns<maxsf;ns++) {
		np=node[ns][0]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
		np=node[ns][1]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
		np=node[ns][2]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
	}

/*	Fourth step:  Calculate Normal Vectors.	*/
	for (np=0;np<maxpt;np++) {
		ls=ptlink[np];
		dx=dy=dz=0;
		while (ls>=0) {
			ns=sflink[ls].surface;
			n1=node[ns][0]-1;		n2=node[ns][1]-1;		n3=node[ns][2]-1;
			if (n2==np) {  n2=n3;  n3=n1;  }
			if (n3==np) {  n3=n2;  n2=n1;  }
			dx1 = xx[n2]-xx[np];
			dy1 = yy[n2]-yy[np];
			dz1 = zz[n2]-zz[np];
			dx2 = xx[n3]-xx[np];
			dy2 = yy[n3]-yy[np];
			dz2 = zz[n3]-zz[np];
			dd = 1/sqrt((dx1*dx1+dy1*dy1+dz1*dz1)*(dx2*dx2+dy2*dy2+dz2*dz2));
			dx += (dy1*dz2-dy2*dz1)*dd;
			dy += (dz1*dx2-dz2*dx1)*dd;
			dz += (dx1*dy2-dx2*dy1)*dd;
			ls=sflink[ls].next;
		}
		ndx[np]=dx;		ndy[np]=dy;		ndz[np]=dz;
	}

	free(ptlink);		free(sflink);

	return 0;
}

void isosurfsetting(int mode)
{
	MODESAVE=mode;
}

void isosurfacecore(double *f,int *imax,int *jmax,int *kmax
					,int *ib,double *bb,double *f0,int *ic,int *ind)
{
	double fd[8];
	int imax0=*imax,jmax0=*jmax,kmax0=*kmax;
	int i,j,k,n,ijmax=imax0*jmax0,*ws=NULL;
	int imax1=imax0+1,ijmax1=ijmax+1,ijmaximax=ijmax+imax0;
	int ijmaximax1=ijmaximax+1;
	int nx1,nx2,ny1,ny2,nz1,nz2,nj,nk,ns,ns0,n1,n2,n3;
	double dx1,dx2,dy1,dy2,dz1,dz2,dx,dy,dz;

	if (MODESAVE==2) goto draw;
	if (xx!=NULL) clear_memories();

	nx1=ib[0];	nx2=ib[1];	ny1=ib[2];	ny2=ib[3];	nz1=ib[4];	nz2=ib[5];
	X0=bb[0];	Y0=bb[2];	Z0=bb[4];
	DX=(bb[1]-bb[0])/(imax0-1);
	DY=(bb[3]-bb[2])/(jmax0-1);
	DZ=(bb[5]-bb[4])/(kmax0-1);
	for (k=nz1;k<nz2;k++) {
		K0=k;
		for (nk=jmax0*k,j=ny1;j<ny2;j++) {
			J0=j;
			for (nj=imax0*(nk+j),i=nx1;i<nx2;i++) {
				I0=i;
				n=nj+i;
				fd[0]=f[n];
				fd[1]=f[n+1];
				fd[2]=f[n+imax0];
				fd[3]=f[n+imax1];
				fd[4]=f[n+ijmax];
				fd[5]=f[n+ijmax1];
				fd[6]=f[n+ijmaximax];
				fd[7]=f[n+ijmaximax1];
				isovalued_cube(fd,*f0);
				if (errorno) {
					*ind=1;
					/*	printf("Points=%d,  Surface=%d, (i,j,k)=(%d,%d,%d)\n",maxpt,maxsf,i,j,k);	*/
					return;
				}
			}
		}
	}

/*	printf("Points=%d,  Surface=%d\n",maxpt,maxsf);		*/

	for (ns=ns0=0;ns<maxsf;ns++) {
/*		Caution !!   The node values have an offset 1 for fortran routine.		*/
		n1=node[ns][0]-1;		n2=node[ns][1]-1;		n3=node[ns][2]-1;
		dx1=xx[n2]-xx[n1];
		dy1=yy[n2]-yy[n1];
		dz1=zz[n2]-zz[n1];
		dx2=xx[n3]-xx[n1];
		dy2=yy[n3]-yy[n1];
		dz2=zz[n3]-zz[n1];
		dx=dy1*dz2-dy2*dz1;
		dy=dz1*dx2-dz2*dx1;
		dz=dx1*dy2-dx2*dy1;
		if (dx!=0 || dy!=0 || dz!=0) {
			node[ns0][0]=n1+1;
			node[ns0][1]=n2+1;
			node[ns0][2]=n3+1;
			ns0++;
		}
	}
	maxsf=ns0;

draw:
	n=0;
	if (maxsf>0) {
		if (*ind) {
			if (*ind==1) ws=(int *)malloc(sizeof(int)*(4*maxpt+3*maxsf));
				else	 ws=(int *)malloc(sizeof(int)*(3*maxpt+2*maxsf));
			if (*ind==3) {
				if (get_normals()) n=1;
			}
		}
		isotriangles(xx,yy,zz,ndx,ndy,ndz,&maxpt,(int *)node,&maxsf,ic,ind,ws);
		free(ws);
		if (MODESAVE<0) clear_memories();
	}
	*ind=n;
}

void withnormalvector(double *xp,double *yp,double *zp,float *fs,int *hs,int *maxp,int *maxs,NODE3 *node,int *mode)
{
	int *index,*origin;
	int i,j,k,ls,np,ns,n1,n2,n3,n0,sb1[32],sb2[32];
	double dx1,dy1,dz1,dx2,dy2,dz2,dx,dy,dz,dd,errx,erry,errz;
	double xmin,xmax;
	int maxpt=*maxp,maxsf=*maxs,maxp0;

/*	First step:  Positional Sorting.	*/
	index=(int *)malloc(sizeof(int)*maxpt);
	origin=(int *)malloc(sizeof(int)*maxpt);
	for (np=0;np<maxpt;np++) origin[np]=np;

	for (np=1,xmin=xmax=xp[0];np<maxpt;np++) {
		if (xmin>xp[np]) xmin=xp[np];
		if (xmax<xp[np]) xmax=xp[np];
	}
	errx=(xmax-xmin)*1e-7;
	for (np=1,xmin=xmax=yp[0];np<maxpt;np++) {
		if (xmin>yp[np]) xmin=yp[np];
		if (xmax<yp[np]) xmax=yp[np];
	}
	erry=(xmax-xmin)*1e-7;
	for (np=1,xmin=xmax=zp[0];np<maxpt;np++) {
		if (xmin>zp[np]) xmin=zp[np];
		if (xmax<zp[np]) xmax=zp[np];
	}
	errz=(xmax-xmin)*1e-7;

	n0=0;		sb1[0]=0;	sb2[0]=maxpt-1;
	while (n0>=0) {
		n1 = sb1[n0];		n2 = sb2[n0];		n0--;
		while (n1<n2) {
			i=n1;			j=n2;				k=origin[(n1+n2)/2];
			dx1=xp[k];		dy1=yp[k];			dz1=zp[k];
			while (i<=j) {
				while (1) {
					if (fabs(xp[origin[i]]-dx1)<=errx) {
						if (fabs(yp[origin[i]]-dy1)<=erry) {
							if (zp[origin[i]]<dz1) i++;
								else break;
						  }
						  else if (yp[origin[i]]<dy1) i++;
						  else break;
					  }
					  else if (xp[origin[i]]<dx1) i++;
					  else break;
				}
				while (1) {
					if (fabs(xp[origin[j]]-dx1)<=errx) {
						if (fabs(yp[origin[j]]-dy1)<=erry) {
							if (zp[origin[j]]>dz1) j--;
								else break;
						  }
						  else if (yp[origin[j]]>dy1) j--;
						  else break;
					  }
					  else if (xp[origin[j]]>dx1) j--;
					  else break;
				}
				if (i<=j) {
					np=origin[j];	origin[j]=origin[i];	origin[i]=np;
					i++;	j--;
				}
			}
			if (j-n1<n2-i) {
				if (i<n2) {
					sb1[++n0]=i;		sb2[n0]=n2;
				}
				n2=j;
			  }
			  else {
				if (n1<j) {
					sb1[++n0]=n1;		sb2[n0]=j;
				}
				n1=i;
			}
		}
	}

/*	Second step:  Remove Identical Points.	*/
	i=origin[0];		index[i]=i;
	for (j=1,np=1;np<maxpt;np++) {
/*		printf("%05d : %15.10f  %15.10f  %15.10f\n",np,xp[np],yp[np],zp[np]);		*/
		n0=origin[np];
		if (fabs(xp[i]-xp[n0])>errx || fabs(yp[i]-yp[n0])>erry || fabs(zp[i]-zp[n0])>=errz) {  i=n0;   j++;  }
		index[n0]=i;
	}
	maxp0=j;
/*
	for (np=0;np<maxpt;np++) {
		printf("%05d, %05d, %05d : %15.10f  %15.10f  %15.10f\n",np,index[origin[np]],origin[np],xp[origin[np]],yp[origin[np]],zp[origin[np]]);
		printf("%05d, %05d, %05d\n",np,index[origin[np]],origin[np]);
	}
	printf("Points=%d,  Points=%d,  Surface=%d\n",*maxp,maxpt,maxsf);
*/

	if (maxpt > maxp0) {
		for (ns=0;ns<maxsf;ns++) {
			n1=node[ns][0]-1;		n2=node[ns][1]-1;		n3=node[ns][2]-1;
			node[ns][0]=index[n1]+1;
			node[ns][1]=index[n2]+1;
			node[ns][2]=index[n3]+1;
/*			printf("%07d, %07d, %07d, %07d\n",ns,node[ns][0],node[ns][1],node[ns][2]);		*/
		}
	}
	free(index);		free(origin);

	if (ndx!=NULL) {
		free(ndx);	free(ndy);	free(ndz);
		ndx=ndy=ndz=NULL;
	}

	ndx=(float *)malloc(sizeof(float)*maxpt);
	ndy=(float *)malloc(sizeof(float)*maxpt);
	ndz=(float *)malloc(sizeof(float)*maxpt);
	ptlink=(int *)malloc(sizeof(int)*maxpt);
	sflink=(SURFLINK *)malloc(sizeof(SURFLINK)*3*maxsf);
/*	if (ndx==NULL || ndy==NULL || ndz==NULL || ptlink==NULL || sflink==NULL) return 1;	*/

	for (np=0;np<maxpt;np++) ptlink[np]=-1;

/*	Third step:  Make Linked List.	*/
	maxlink=0;
	for (ns=0;ns<maxsf;ns++) {
		np=node[ns][0]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
		np=node[ns][1]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
		np=node[ns][2]-1;				ls=ptlink[np];
		sflink[maxlink].next=ls;		sflink[maxlink].surface=ns;
		ptlink[np]=maxlink++;
	}

/*	Fourth step:  Calculate Normal Vectors.	*/
	for (np=0;np<maxpt;np++) {
		ls=ptlink[np];
		if (ls<0) continue;		/*  Note here, ndx,ndy,ndz are imcomplete  */
		dx=dy=dz=0;
		while (ls>=0) {
			ns=sflink[ls].surface;
			n1=node[ns][0]-1;		n2=node[ns][1]-1;		n3=node[ns][2]-1;
			if (n2==np) {  n2=n3;  n3=n1;  }
			if (n3==np) {  n3=n2;  n2=n1;  }
			dx1 = xp[n2]-xp[np];
			dy1 = yp[n2]-yp[np];
			dz1 = zp[n2]-zp[np];
			dx2 = xp[n3]-xp[np];
			dy2 = yp[n3]-yp[np];
			dz2 = zp[n3]-zp[np];
			dd = 1/sqrt((dx1*dx1+dy1*dy1+dz1*dz1)*(dx2*dx2+dy2*dy2+dz2*dz2));
			dx += (dy1*dz2-dy2*dz1)*dd;
			dy += (dz1*dx2-dz2*dx1)*dd;
			dz += (dx1*dy2-dx2*dy1)*dd;
			ls=sflink[ls].next;
		}
		if (*mode==0) {
			rdnormpoints(&(xp[np]),&(yp[np]),&(zp[np]),&dx,&dy,&dz,&dx1,&dy1,&dz1);
			ndx[np]=dx1;		ndy[np]=dy1;		ndz[np]=dz1;
		  }
		  else {
			ndx[np]=dx;		ndy[np]=dy;		ndz[np]=dz;
		}
	}

	free(ptlink);		free(sflink);
	if (*mode==0) {
		dsfill3dtriangs(xp,yp,zp,ndx,ndy,ndz,fs,hs,maxp,maxs,(int *)node);
	  }
	  else {
		dsfill3dwithvect(xp,yp,zp,ndx,ndy,ndz,fs,hs,maxp,maxs,(int *)node);
	}
	free(ndx);			free(ndy);			free(ndz);
	ndx=ndy=ndz=NULL;
}

void malloctrisurfacecore(double *x,double *y,double *z,double *f,int *np,int *node1,int *ns
												,int *ic,int *m1,int *m2,int *ind,int *ier)
{
	float *ws;
	int *hs,np1=*np;

	*ier=0;
	if (*m2) np1>>=1;
	if (*ic<0 || *ind>4) {
		ws=(float *)malloc(sizeof(float)*np1*3);
		hs=(int *)malloc(sizeof(int)*(*ns)*2);
	  }
	  else if (*ind<5) {
		ws=(float *)malloc(sizeof(float)*np1*4);
		hs=(int *)malloc(sizeof(int)*(*ns)*4);
	  }
	  else {
	  	*ier=1;
		return;
	}
	if (ws==NULL || hs==NULL) {
		*ier=2;
		return;
	}
	trisurfacemain(x,y,z,f,np,node1,ns,ic,m1,ind,ws,hs);

	free(ws);	free(hs);
}
