*
* DISPLAY: all
* cvswitch1.plt: basic, logsin, field, tconsq
* cvswitch2.gif: drawsin, polygn, tcont2
* cvswitch3.plt: sincos, bruss, tcont, tcontr
* cvswitch3.gif: sincos, bruss, tcont, tcontr
*
      IMPLICIT REAL*8 (A-H,O-Z)

      CALL FR_GINIT
      CALL FR_OPENCANVAS ( 1, 'cvswitch1', 11)
      call fr_gwsize(500,400,0,0)
      CALL FR_OPENCANVAS ( 2, 'cvswitch2',101)
      call fr_gwsize(400,350,0,0)
      CALL FR_OPENCANVAS ( 3, 'cvswitch3',-211)

      CALL FR_GNOTES('#canvas switch Test')
      CALL FR_GNOTES('xmin=10   xmax=100')

      CALL FR_CANVAS(1)
      CALL BASIC

      CALL NEXT(3)
      CALL SINCOS

      CALL NEXT(2)
      CALL DRAWSIN

      CALL NEXT(1)
      CALL LOGSIN

      CALL NEXT(2)
      CALL POLYGN

      CALL NEXT(3)
      CALL BRUSS

      CALL NEXT(1)
      CALL FIELD

      CALL NEXT(3)
      CALL TCONT

      CALL NEXT(2)
      CALL TCONT2

      CALL NEXT(1)
      CALL TCONSQ

      CALL NEXT(3)
      CALL TCONTR

      CALL FR_GEND

      STOP
      END

      SUBROUTINE NEXT(ICAN)
      CALL FR_GPAUSE
      CALL FR_CANVAS(ICAN)
      RETURN
      END

      SUBROUTINE BASIC
      CALL FR_FPLINE(200.D0,100.D0,400.D0,100.D0,7,0)
      CALL FR_FPLINE(200.D0,80.D0,200.D0,120.D0,7,0)
      CALL FR_FPCHARS(200.D0,100.D0,'100',4,0,0,0,0)
      CALL FR_FPLINE(240.D0,80.D0,240.D0,120.D0,7,0)
      CALL FR_FPCHARS(240.D0,100.D0,'100',6,1,1,0,0)
      CALL FR_FPLINE(280.D0,80.D0,280.D0,120.D0,7,0)
      CALL FR_FPCHARS(280.D0,100.D0,'100',3,1,-1,0,0)
      CALL FR_FPLINE(360.D0,80.D0,360.D0,120.D0,7,0)
      CALL FR_FPCHARS(360.D0,100.D0,'100',1,-1,0,0,0)

      CALL FR_FPLINE(200.D0,200.D0,400.D0,200.D0,7,0)
      CALL FR_FPLINE(200.D0,180.D0,200.D0,220.D0,7,0)
      CALL FR_FPCHARS(200.D0,200.D0,'100',1,-1,0,1,0)
      CALL FR_FPLINE(240.D0,180.D0,240.D0,220.D0,7,0)
      CALL FR_FPCHARS(240.D0,200.D0,'100',2,1,0,-1,0)
      CALL FR_FPLINE(320.D0,180.D0,320.D0,220.D0,7,0)
      CALL FR_FPCHARS(320.D0,200.D0,'100',3,-1,0,1,0)
      CALL FR_FPLINE(360.D0,180.D0,360.D0,220.D0,7,0)
      CALL FR_FPCHARS(360.D0,200.D0,'100',4,1,0,-1,0)

      CALL FR_FPLINE(200.D0,240.D0,400.D0,240.D0,7,0)
      CALL FR_FPLINE(200.D0,220.D0,200.D0,260.D0,7,0)
      CALL FR_FPCHARS(350.D0,240.D0,'   |',1,1,-1,0,0)
      CALL FR_FPCHARS(1.D0,0.D0,'ABCDEFGHIJKLMNOPQR',1,1,1,0,1)
      DO I = 1, 5
        CALL FR_FPCHARS(0.D0,1.D0,'ABCDEFGHIJKLMNOPQR',I+1,1,1,0,1)
      ENDDO

      CALL FR_FPCHARS(0.D0,1.D0,'ABCDEFGHIJKLMNOPQR',7,-1,1,0,1)
      DO I = 1, 3
        CALL FR_FPCHARS(0.D0,-1.D0,'ABCDEFGHIJKLMNOPQR',I+1,-1,1,0,1)
      ENDDO

      CALL FR_FPCHARS(-1.D0,0.D0,'ABCDEFGHIJKLMNOPQR',1,-1,1,0,1)
      DO I = 1, 3
        CALL FR_FPCHARS(0.D0,2.D0,'ABCDEFGHIJKLMNOPQR',I+1,-1,1,0,1)
      ENDDO

      RETURN
      END

***********************
*   2D GRAPHIC TEST   *
***********************
      SUBROUTINE SINCOS
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (N=5)
      REAL*8 X(2),Y(0:N),Y1(0:N)

      XMIN = 0.D0
      XMAX = 5.D0
      YMAX = 1.2D0

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_FRAME2D(XMIN,XMAX,-YMAX,YMAX,10)
      CALL FR_XYNAME('X-AXIS','Y-DATAS')

      DX = (XMAX-XMIN)/N
      DO I = 0, N
         Y(I) = 0.1D0*SIN(10*(DX*I+XMIN))
      ENDDO

      NN = 7
      DY = 2.D0/NN
      X(1) = XMIN
      X(2) = XMAX
      DO I = 1, NN
         YY=DY*I-1.2D0
         CALL FR_SETCIRCLE(20*DY*I)
         DO J = 0, N
            Y1(J) = YY + Y(J)
         ENDDO
         CALL FR_GRAPH2D(X,Y1,N+1,I,101)
         CALL FR_GRAPH2D(X,Y1,N+1,I,103)
      ENDDO

      RETURN
      END

***********************
*     2D DRAW TEST    *
***********************
      SUBROUTINE DRAWSIN
      IMPLICIT REAL*8 (A-H,O-Z)

      N    = 100
      XMIN = 0.D0
      XMAX = 10.D0
      YMAX = 1.5D0

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_FRAME2D(XMIN,XMAX,-YMAX,YMAX,10)
      CALL FR_XYNAME('X-AXIS','Y-DATAS')
      DX   = XMAX/N

      CALL FR_DRAW2D(0.D0,0.D0,4,0)
      DO 10 I = 1, N
         X = DX*I
         CALL FR_DRAW2D(X,10.D0*EXP(-0.7D0*X)*SIN(10.D0*X),4,1)
  10   CONTINUE

      RETURN
      END

******************************
*   2D LGAXIS GRAPHIC TEST   *
******************************
      SUBROUTINE LOGSIN
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (N=1000)
      REAL*8 X(0:N),Y(0:N)


      XMAX = 5.D0
      YMAX = 2.D0

      DX   = 2*XMAX/N
      DO 10 I=0,N
          X(I)=DX*I-XMAX
          Y(I)=SIN(10*X(I))
  10   CONTINUE
      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_FRAME2D(-XMAX,XMAX,-YMAX,YMAX,12)
      CALL FR_LOGAXIS(3)
      CALL FR_XYNAME('X-AXIS','Y-DATAS')
      CALL FR_GRAPH2D(X,Y,N+1,6,2)
*      CALL FR_GRAPH2D(X,Y,N+1,2,3)

*      CALL FR_G2TOFP(X(1),Y(1),SX,SY)
      CALL FR_2DMOVE(1.D0,Y(N),1)
*      CALL FR_2DMOVE(1.D0,0.D0,3)
      CALL FR_FPCHARS(-5.D0,0.D0,'TEST FOR FPCHRS',3,-1,0,0,30)

      RETURN
      END

******************************
*     POLYGONS AND CIRCLES   *
******************************
      SUBROUTINE POLYGN
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 XX(10),YY(10)
      PARAMETER (N=6)

      XMIN = 0.D0
      XMAX = 2.D0
      YMAX = 3.D0
      
      DL    = 14.D0
      DD    = 32.D0
      DTH   = 2.D0*3.141592D0/N
      DO I = 1, N
         XX(I) = DL*COS(DTH*(I-1))
         YY(I) = DL*SIN(DTH*(I-1))
      ENDDO

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_FRAME2D(XMIN,XMAX,-YMAX,YMAX,10)
      CALL FR_XYNAME('X-AXIS','Y-DATAS')

      NN=20
      DX = XMAX/NN
      DO I = 1, NN
         XXX=DX*I
         YYY=2.D0*SIN(5*XXX)
         CALL FR_2DMOVE(XXX,YYY,0)
*         CALL FR_FPCIRCLE(0.D0,0.D0,DD,DD,MOD(I-1,6)+1,31)
*         CALL FR_FPPOLYGON(XX,YY,N,MOD(I-1,6)+1,32)
         CALL FR_FPCIRCLE(0.D0,0.D0,DD,DD,-I*6,31)
         CALL FR_FPPOLYGON(XX,YY,N,-I*6,32)
      ENDDO

      RETURN
      END

*******************************
*         BRUSSELATOR         *
*       TEST OF VECTORS       *
*******************************
      SUBROUTINE BRUSS
      REAL*8 X,R,Y(2),F(2)
      REAL*8 XX(500),YY(500),XF(0:20,0:20),YF(0:20,0:20)

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
      CALL FR_FRAME2D(0.0D0,5.0D0,0.0D0,5.0D0,10)
      CALL FR_XYNAME('X','Y')
*      CALL FR_SETARROW(20.D0,20.D0)
      X = 0.D0
      R = 0.05D0
      DO 20 J = 0, 20
         DO 20 I = 0, 20
            Y(1) = 0.25D0*I
            Y(2) = 0.25D0*J
            CALL HANNOU(Y,F)
            CALL FR_VECTOR2D(Y(1),Y(2),R*F(1),R*F(2),2,0)
            XF(I,J) = F(1)
            YF(I,J) = F(2)
   20      CONTINUE

      DO I = 1, 10
         XX(1) = 0.4D0*I
         YY(1) = 0.2D0*I
*         YY(1) = 0.2D0
         CALL FR_FLOW2DLINE(XX,YY,500,XF,YF,21,21,4,1.D-5,5)
      ENDDO

      RETURN
      END

      SUBROUTINE HANNOU(F,DF)
      REAL*8 F(2),DF(2)

      DF(1) = 0.5D0 + F(1)*(F(1)*F(2) - 3.0D0)
      DF(2) = F(1)*(2.0 - F(1)*F(2))

      RETURN
      END

********************************
*        DIPOLE FIELD          *
*       TEST OF FLOW LINE      *
********************************
      SUBROUTINE FIELD
      IMPLICIT REAL*8(A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0)
      PARAMETER (IFMAX=31,ITMAX=40,IMAX=30,JMAX=40)
      REAL*8 XX(500),YY(500)
      REAL*8 BX(-IMAX:IMAX,0:JMAX),BY(-IMAX:IMAX,0:JMAX)
      REAL*8 F(IFMAX),TH(ITMAX)

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
      CALL FR_FRAME2D(-0.25D0*IMAX,0.25D0*IMAX,0.0D0,0.25D0*JMAX,0)
      CALL FR_XYNAME('X','Y')
      DO 10 J = 0, JMAX
         DO 10 I = -IMAX, IMAX
            X  = 0.25D0*I
            Y  = 0.25D0*J
            CALL DIPOLE(X,Y,BX(I,J),BY(I,J))
   10      CONTINUE

      R = 1.0D0
      DO 20 I = 1, IFMAX
         TH1 = PI*(I-1)/DBLE(IFMAX-1)
         CALL DIPOLE(R*COS(TH1),R*SIN(TH1),X,Y)
         F(I) = X*COS(TH1)+Y*SIN(TH1)
   20  CONTINUE
      
      TH(1)     = 0.D0
      TH(ITMAX) = PI
      CALL FR_FLOWSPACE(F,IFMAX,TH,ITMAX,AREA,0)

*      DO 21 I = 1, ITMAX
*         TH(I) = PI*(I-1)/DBLE(ITMAX-1)
*   21  CONTINUE

      CALL FR_FLOW2DRGN(0.D0,0.25D0*IMAX,0.D0,0.25D0*JMAX)
      DO 30 I = 1, ITMAX/2
         XX(1) = R*COS(TH(I))
         YY(1) = R*SIN(TH(I))
         CALL FR_FLOW2DLINE(XX,YY,500,BX,BY,2*IMAX+1,JMAX+1,4,1.D-7,5)
   30  CONTINUE
      CALL FR_FLOW2DRGN(-0.25D0*IMAX,0.D0,0.D0,0.25D0*JMAX)
      DO 40 I = ITMAX/2+1, ITMAX
         XX(1) = R*COS(TH(I))
         YY(1) = R*SIN(TH(I))
         CALL FR_FLOW2DLINE(XX,YY,500,BX,BY,2*IMAX+1,JMAX+1,6,1.D-7,-5)
   40  CONTINUE

      RETURN
      END

      SUBROUTINE DIPOLE(X,Y,BX,BY)
      REAL*8 X,Y,R2,R5,BX,BY

      R2 = X*X+Y*Y
      IF (R2.EQ.0) THEN
         BX = 0.D0
         BY = 0.D0
       ELSE
         R5 = R2**2.5D0
         BX = (3.D0*X*X-R2)/R5
         BY = 3.D0*X*Y/R5
      ENDIF
      RETURN
      END

*******************************
*       TEST OF CONTOURS      *
*******************************
      SUBROUTINE TCONT
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=50,JMAX=50)
      REAL*8 F(0:IMAX,0:JMAX)
      REAL*8 YY(2),FF(2)

      XMIN = -3.D0
      XMAX =  3.D0
      YMIN = -2.D0
      YMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      DO J = 0, JMAX
          DO I = 0, IMAX
              X=DX*I+XMIN
              Y=DY*J+YMIN
              F(I,J)=EXP(-0.5*((X-1)**2+(Y-.5)**2))
     +              +EXP(-1.2*((X+1.5)**2+(Y+.5)**2))
            ENDDO
        ENDDO

      CALL FR_MARGIN2D(50,30,50,70)
      CALL FR_ASPECT2D(1.0D0,1.D0,1)
      CALL FR_FRAME2D(XMIN,XMAX,YMIN,YMAX,0)
      CALL FR_XYNAME('RE','IM')

      CALL FR_SETCONTOUR(0.D0,2.D0,2)
      CALL FR_SETCONTOUR(0.5D0,0.D0,3)
*      CALL FR_SET2RGN(50,100,50,100)
      CALL FR_CONTOUR(F,IMAX+1,JMAX+1,30,205)

      RETURN
      END

************************************
*       TEST OF FILL CONTOURS      *
************************************
      SUBROUTINE TCONT2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=20)
      REAL*8 F(0:IMAX,0:JMAX)

      XMIN = -3.D0
      XMAX =  3.D0
      YMIN = -2.D0
      YMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX

      X0 = 1.0d0
      Y0 = 0.0d0

      DO J = 0, JMAX
         DO I = 0, IMAX
            X=DX*I+XMIN
            Y=DY*J+YMIN
            F(I,J)=EXP(-0.5*((X-X0)**2+(Y-Y0)**2))
     +              -EXP(-1.2*((X-1.5)**2+(Y-0.5)**2))
         ENDDO
      ENDDO

      CALL FR_MARGIN2D(80,50,80,70)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
      CALL FR_FRAME2D(XMIN,XMAX,YMIN,YMAX,0)
      CALL FR_XYNAME('RE','IM')
      CALL FR_CONTOUR(F,IMAX+1,JMAX+1,20,-2)
      CALL FR_2DMOVE(0.5D0,1.0D0,3)
      CALL FR_COLORBAR(-50,-25,100,15,321)
*      CALL FR_2DMOVE(1.0D0,1.0D0,3)
*      CALL FR_COLORBAR(-50,-25,100,15,311)
      CALL FR_2DMOVE(1.0D0,0.5D0,3)
      CALL FR_COLORBAR(10,-50,15,100,322)
*      CALL FR_2DMOVE(1.0D0,0.0D0,3)
*      CALL FR_COLORBAR(10,-50,15,100,312)

      RETURN
      END

********************************************************
*       TEST OF FILL CONTOURS FOR ARBITRARY MESH       *
********************************************************
      SUBROUTINE TCONSQ
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=15,JMAX=30)
      REAL*8 F(0:IMAX,0:JMAX),X(0:IMAX,0:JMAX),Y(0:IMAX,0:JMAX)
      real*8 sh(5),sl(5),ss(5)
      integer ndiv(4)

      RMIN =  0.5D0
      RMAX =  3.D0
      TMIN =  0.D0
      TMAX =  8.D0*ATAN(1.D0)
      DR   = (RMAX - RMIN)/IMAX
      DT   = (TMAX - TMIN)/JMAX
      DO J = 0, JMAX
         DO I = 0, IMAX
            R=DR*I+RMIN
            T=DT*J+TMIN
            X(I,J) = R*COS(T)
            Y(I,J) = R*SIN(T)
            f(i,j)=exp(-0.5*((x(I,J)-1)**2+(y(I,J)-.5)**2))
     +              -exp(-1.2*((x(I,J)+1.5)**2+(y(I,J)+.5)**2))
         ENDDO
      ENDDO
      sh(1) = 240.d0
      sh(2) = 240.d0
      sh(3) = 0.d0
      sh(4) = 0.d0
      sl(1) = 0.2d0
      sl(2) = 0.95d0
      sl(3) = 0.95d0
      sl(4) = 0.2d0
      ss(1) = 1.d0
      ss(2) = 1.d0
      ss(3) = 1.d0
      ss(4) = 1.d0
      ndiv(1) = 64
      ndiv(2) = 0
      ndiv(3) = 64
      call FR_HLSSET(sh,sl,ss,ndiv,3)

      CALL FR_MARGIN2D(100,50,100,70)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
*      CALL FR_FRAME2D(-3.D0,3.D0,-3.D0,3.D0,2)
*      CALL FR_XYNAME('RE','IM')
      CALL FR_SETCONTOUR(-1.D0,1.0D0,2)
*      call FR_SET2RGN(50,100,50,100)

      CALL FR_SQRCONTOUR(X,Y,F,IMAX+1,JMAX+1,30,-2,7)
      CALL FR_2DMOVE(1.0D0,0.5D0,3)
      CALL FR_COLORBAR(10,-100,20,200,322)

      RETURN
      END

********************************************************
*       TEST OF FILL CONTOURS FOR TRIANGLE MESH        *
********************************************************
      SUBROUTINE TCONTR
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NPD=300,NSD=500)
      REAL*8 X(NPD),Y(NPD),F(NPD)
      INTEGER NDX(3,NSD)
      real*8 sh(3),sl(3),ss(3)
      integer ndiv(2)

      XMIN = -3.D0
      XMAX =  3.D0
      YMIN = -2.D0
      YMAX =  2.D0
      NI   = 10
      NJ   = 10
      DY = (YMAX-YMIN)/NJ

      NP = 0
      NS = 0
      CALL GENMESH(XMIN,0.D0,YMIN,YMAX,NI,NJ,X,Y,NDX,NP,NS)
      CALL GENMESH(0.D0,XMAX,YMIN,-DY,NI,NJ/2-1
     ,                                    ,X,Y,NDX,NP,NS)
      CALL GENMESH(0.6D0,XMAX,0.D0,YMAX,NI,NJ,X,Y,NDX,NP,NS)

      DO I = 1, NP
         F(I)=-exp(-5.0*((X(I)-1.8)**2+(Y(I)-1.1)**2))
     +              +exp(-0.7*((X(I)+1.3)**2+(Y(I)+.5)**2))
      ENDDO
*      write(*,*) np,ns

      sh(1) = 130.d0
      sh(2) = 340.d0
      sh(3) = 340.d0
      sl(1) = 0.5d0
      sl(2) = 0.5d0
      sl(3) = 0.0d0
      ss(1) = 1.d0
      ss(2) = 1.d0
      ss(3) = 1.d0
      ndiv(1) = 64
      ndiv(2) = 64
      call FR_HLSSET(sh,sl,ss,ndiv,2)

      CALL FR_MARGIN2D(50,50,50,50)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
      CALL FR_FRAME2D(XMIN,XMAX,YMIN,YMAX,1)
*      CALL FR_SETCONTOUR(-1.D0,1.0D0,2)

      CALL FR_TRICONTOUR(X,Y,F,NP,NDX,NS,20,-2,7)
      CALL FR_2DMOVE(0.5D0,1.0D0,3)
      CALL FR_COLORBAR(-100,-30,200,20,321)

      RETURN
      END

      SUBROUTINE GENMESH(X1,X2,Y1,Y2,NI,NJ,X,Y,NODE,IP,IS)
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 X(*),Y(*)
      INTEGER NODE(3,*)

      DX = (X2-X1)/NI
      DY = (Y2-Y1)/NJ
      
      NP = IP
      DO J = 0, NJ
         DO I = 0, NI
            NP = NP + 1
            X(NP) = X1 + I*DX
            Y(NP) = Y1 + J*DY
         ENDDO
      ENDDO

      NS  = IS
      NP0 = IP
      DO J = 0, NJ-1
         DO I = 0, NI-1
            NS  = NS + 1
            NP0 = NP0 + 1
            NODE(1,NS) = NP0
            NODE(2,NS) = NP0 + NI + 1
            NODE(3,NS) = NP0 + NI + 2
            NS  = NS + 1
            NODE(1,NS) = NP0
            NODE(2,NS) = NP0 + 1
            NODE(3,NS) = NP0 + NI + 2
         ENDDO
         NP0 = NP0 + 1
      ENDDO

      IP = NP
      IS = NS

      RETURN
      END
