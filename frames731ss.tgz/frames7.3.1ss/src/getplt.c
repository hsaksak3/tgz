/****************************************************
 *               F r a m e s  V.7.3.1               *
 *      Data Restoring Routine from PLT File        *
 *            Programed by T. Taguchi               *
 *               February 11, 2012                  *
 ****************************************************
*/
#include <stdio.h>
/*#ifdef SOLARIS*/
#include <unistd.h>
/*#endif*/
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>
#include "frames_plt.h"

#ifdef SOLARIS
enum version {libm_ieee = -1, c_issue_4, ansi_1, strict_ansi};
const enum version _lib_version;
#endif

#define MAX				1000
#define BUFSIZE 		1024
#define XMAX			1.e5
#define BEEP()  		fputc(0x07,stderr)
#define min(x,y)  		(((x)>=(y))?y:(x))
#define nothing
#define MAXNCHAR		128
#define MAXNCHAR2		256
#define ONECMAPP		100
#define ONECMAPP5		(-(ONECMAPP+5))

#define XTC		36.e-5
#define YTC		1.e-6
#define ZTC		1.e-6

#define DOUBLE_1D		1
#define DOUBLE_2D		2
#define DOUBLE_3D		3
#define STRING_1D		4
#define STRING_2D		5
#define STRING_3D		6
#define INTEGER_1D		8
#define FIELD1_TRI		DOUBLE_3D

static int 		FADR0,FADR1,FOFF;
static double	XTAN,YTAN,ZTAN,X0,Y0,Z0;
static char		BUFFER[BUFSIZE],filename[MAXNCHAR],str[MAXNCHAR2+1];
static int  	ENDFILE=1,DRAWED=0,VERSION=2;

static jmp_buf	env;
static int 		fr_com=0,cur_level=DEFAULT_LEVEL,next_data=0,unget_data=0;
static unsigned char 	com_level[128],com_spec[128];

#ifdef HP
static FILE 	*fpg;
#else
static int		FDIO;
#endif


static void check_ext(char *str1,char *str2,char *ext)
{
	int j=1;
	char c;
	while (c=(*str1++)) {
		if (c=='.') j=0;
		(*str2++)=c;
	  }
	if (j) {
		(*str2++)='.';
		while (*ext) (*str2++)=*ext++;
	  }
	*str2=0;
}

static void error_end(char *s,int n)
{
	fprintf(stderr,"%s  !!! \n",s);
	if (n) {
#ifdef HP
		fclose(fpg);
#else
		close(FDIO);
#endif
	}
}

static int seekfadr(int adr)
{
	if (adr<FADR0 || adr>=FADR1) {
#ifdef HP
		if (fseek(fpg,adr,SEEK_SET)) {
#else
		if ((FADR0=FADR1=lseek(FDIO,adr,SEEK_SET))==-1) {
#endif
			error_end("Cannot seek this address",1);
			return 1;
		  }
#ifdef HP
		  else FADR0=FADR1=adr;
#endif
	}
	FOFF=adr-1;
	return 0;
}

static void getbyte(void *bp,int n)
{
	char *b;
	int i;
	unsigned int nb;

	b=(char *)bp;
#ifndef BIGENDIAN
	for (i=0;i<n;i++) {
		FOFF++;
		if (FOFF>=FADR1) {
			nb=read(FDIO,BUFFER,BUFSIZE);
			if (nb==0) {
				ENDFILE=1;
				/* error_end("Reached to End Of File",1);*/ 
				longjmp(env,1);
	    	  }
			FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
		  }
		b[i]=BUFFER[FOFF-FADR0];
	  }
#else
	if (n<0) {
		for (i=0;i<-n;i++) {
			FOFF++;
			if (FOFF>=FADR1) {
# ifdef HP
				nb=fread(BUFFER,1,BUFSIZE,fpg);
# else
				nb=read(FDIO,BUFFER,BUFSIZE);
# endif
				if (nb==0) {
					ENDFILE=1;
					/* error_end("Reached to End Of File",1);*/ 
					longjmp(env,1);
		    	  }
				FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
			  }
			b[i]=BUFFER[FOFF-FADR0];
		  }
	   }
/*    special for unix & mac	*/
	  else if (n>0) {
		for (i=1;i<=n;i++) {
			FOFF++;
			if (FOFF>=FADR1) {
# ifdef HP
				nb=fread(BUFFER,1,BUFSIZE,fpg);
# else
				nb=read(FDIO,BUFFER,BUFSIZE);
# endif
				if (nb==0) {
					ENDFILE=1;
					/* error_end("Reached to End Of File",1);*/ 
					longjmp(env,1);
		    	  }
				FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
			  }
			b[n-i]=BUFFER[FOFF-FADR0];
		  }
	}
#endif
}

unsigned char getubyte(void)
{
	unsigned char c;
	getbyte(&c,1);
	return c;
}

static int getint()
{
	short w;
	getbyte(&w,2);
	return (int)w;
}

static int getint3()
{
	int w;
	getbyte(&w,3);
#ifdef BIGENDIAN
	w>>=8;
#endif
	return (int)w;
}

double getsreal()
{
	union linteg { char c[4];	signed int l; } b;
	int i;

	b.l=0;
	
#ifndef BIGENDIAN
   	getbyte(&b,3);
   	if ((b.c[0])&1) {
		for (i=3;i>0;i--) b.c[i]=b.c[i-1];
	  }
	  else {
		b.l<<=1;
		if (b.c[3]) b.c[3]=0xff;
    }
#else
	getbyte(&b,3);
	if (((b.c[2])&1)==0) b.l>>=8;
#endif

	return (double)(b.l);
}

static int get1int()
{
	union linteg { char c[4];	int l; } b;

	b.l=0;
#ifndef BIGENDIAN
    getbyte(&b,2);
    if ((b.c[0])&1) {
        getbyte(&b.c[2],1);
        if ((b.c[2])&0x80) b.c[3]=0xff;
    }
#else
	getbyte(&(b.c[2]),2);
	if ((b.c[3])&1) {
		getbyte(&b.c[1],1);
		if ((b.c[1])&0x80) b.c[0]=0xff;
	  }
#endif

	return b.l;
}

static int getnint(int n)
{
	union linteg { char c[4];	int l; } b;

	b.l=0;
#ifndef BIGENDIAN
    getbyte(&b,n);
#else
	getbyte(&b.c[4-n],n);
#endif

	return b.l;
}

static double getdouble1()
{
	signed char 	b1;
	char	ch[20];
	int	n1;

    n1=0;
    getbyte(&n1,3);
#ifdef BIGENDIAN
	n1>>=8;
#endif
    b1=n1&0x3f;       n1>>=6;
    if (b1&0x20) b1|=0xc0;
    if (n1&0x20000) n1|=0xfffc0000;
/*    sprintf(ch,"%7lde%d",n1,b1);		*/
    sprintf(ch,"%7de%d",n1,b1);
    ch[0]=ch[1];	ch[1]='.';
	return atof(ch);
}

static double getddouble1()
{
	signed char	b1;
	char 	ch[20];
	int		n1;

	getbyte(&n1,4);
	if (n1) {
	  getbyte(&b1,1);
/*	  sprintf(ch,"%11lde%d",n1,b1);		*/
	  sprintf(ch,"%11de%d",n1,b1);
	  ch[0]=ch[1];	ch[1]='.';
	  return atof(ch);
	 }
	 else {
	  getbyte(&b1,1);
	  return 0;
	}
}

static void get8byte(double *x,double *y,int n,int mode,int ind)
{
	int	i;
	double x0;

	if (VERSION<5) goto v0;

	if (ind) {
		if (mode<=0) {
			x[0]=getddouble1();
			if (mode==0) y[0]=getddouble1();
		  }
		  else if (mode==1) {
			for (i=0;i<n;i++) {
	        	x[i]=XTAN*getsreal()+X0;
    	     	y[i]=YTAN*getsreal()+Y0;
			}
		  }
		  else if (mode==2) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
				y[i]=getdouble1();
			}
		  }
		  else if (mode==3) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
			}
		  }
		  else if (mode==4) {
			if (VERSION<5) {
				x[0]=getddouble1();
				for (i=1;i<n;i++) {
					x[i]=x[0]+getdouble1();
				}
			  }
			  else {
				x0=getddouble1();
				for (i=0;i<n;i++) {
					x[i]=x0+getdouble1();
				}
			}
		  }
		  else if (mode==5) {
			for (i=0;i<n;i++) {
 	    	   	x[i]=XTAN*getsreal()+X0;
			}
		  }
		  else if (mode==6) {
			for (i=0;i<n;i++) {
 	        	y[i]=YTAN*getsreal()+Y0;
			}
		}
	  }
	  else {
		if (mode<=0) {
			getddouble1();
			if (mode==0) getddouble1();
		  }
		  else if (mode==1) {
			for (i=0;i<n*2;i++) getsreal();
		  }
		  else if (mode==2) {
			for (i=0;i<n*2;i++) getdouble1();
		  }
		  else if (mode==3) {
			for (i=0;i<n;i++) getdouble1();
		  }
		  else if (mode==4) {
			getddouble1();
			if (VERSION<5) {
				for (i=1;i<n;i++) getdouble1();
			  }
			  else {
				for (i=0;i<n;i++) getdouble1();
			}
		  }
		  else if (mode==5 || mode==6) {
			for (i=0;i<n;i++) getsreal();
		}
	}
	return;
	
v0:
	if (ind) {
		if (mode<=0) {
			x[0]=getddouble1();
			if (mode==0) y[0]=getddouble1();
		  }
		  else if (mode==1) {
			for (i=0;i<n;i++) {
	        	x[i]=XTAN*get1int()+X0;
    	     	y[i]=YTAN*get1int()+Y0;
			}
		  }
		  else if (mode==2) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
				y[i]=getdouble1();
			}
		  }
		  else if (mode==3) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
			}
		  }
		  else if (mode==4) {
			if (VERSION<5) {
				x[0]=getddouble1();
				for (i=1;i<n;i++) {
					x[i]=x[0]+getdouble1();
				}
			  }
			  else {
				x0=getddouble1();
				for (i=0;i<n;i++) {
					x[i]=x0+getdouble1();
				}
			}
		  }
		  else if (mode==5) {
			for (i=0;i<n;i++) {
 	    	   	x[i]=XTAN*get1int()+X0;
			}
		  }
		  else if (mode==6) {
			for (i=0;i<n;i++) {
 	        	y[i]=YTAN*get1int()+Y0;
			}
		}
	  }
	  else {
		if (mode<=0) {
			getddouble1();
			if (mode==0) getddouble1();
		  }
		  else if (mode==1) {
			for (i=0;i<n*2;i++) get1int();
		  }
		  else if (mode==2) {
			for (i=0;i<n*2;i++) getdouble1();
		  }
		  else if (mode==3) {
			for (i=0;i<n;i++) getdouble1();
		  }
		  else if (mode==4) {
			getddouble1();
			for (i=1;i<n;i++) getdouble1();
		  }
		  else if (mode==5 || mode==6) {
			for (i=0;i<n;i++) get1int();
		}
	}
}

static void get38byte(double *x,double *y,double *z,int n,int mode,int ind)
{
	int	i;

	if (VERSION<5) goto v0;

	if (ind) {
		if (mode==0) {
			for (i=0;i<n;i++) {
        	 	z[i]=ZTAN*getsreal()+Z0;
			}
		  }
		  else if (mode==1) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*getsreal()+X0;
         		y[i]=YTAN*getsreal()+Y0;
	         	z[i]=ZTAN*getsreal()+Z0;
			}
		  }
		  else if (mode==2) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
				y[i]=getdouble1();
				z[i]=getdouble1();
			}
		  }
		  else if (mode==5) {
			for (i=0;i<n;i++) {
        	 	y[i]=YTAN*getsreal()+Y0;
         		z[i]=ZTAN*getsreal()+Z0;
			}
		  }
		  else if (mode==6) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*getsreal()+X0;
         		z[i]=ZTAN*getsreal()+Z0;
			}
		  }
		  else if (mode==7) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*getsreal()+X0;
         		y[i]=YTAN*getsreal()+Y0;
			}
		  }
		  else if (mode==8) {
			for (i=0;i<n;i++) {
        		x[i]=XTC*getsreal();
         		y[i]=YTC*getsreal();
  	    	   	z[i]=ZTC*getsreal();
		  	}
		}
	  }
	  else {
		if (mode==0) {
			for (i=0;i<n;i++) getsreal();
		  }
		  else if (mode==1 || mode==8) {
			for (i=0;i<n*3;i++) getsreal();
		  }
		  else if (mode==2) {
			for (i=0;i<n*3;i++) getdouble1();
		  }
		  else if (mode==5 || mode==6 || mode==7) {
			for (i=0;i<n*2;i++) getsreal();
		}
	}
	return;
	
v0:
	if (ind) {
		if (mode==0) {
			for (i=0;i<n;i++) {
        	 	z[i]=ZTAN*get1int()+Z0;
			}
		  }
		  else if (mode==1) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*get1int()+X0;
         		y[i]=YTAN*get1int()+Y0;
	         	z[i]=ZTAN*get1int()+Z0;
			}
		  }
		  else if (mode==2) {
			for (i=0;i<n;i++) {
				x[i]=getdouble1();
				y[i]=getdouble1();
				z[i]=getdouble1();
			}
		  }
		  else if (mode==5) {
			for (i=0;i<n;i++) {
        	 	y[i]=YTAN*get1int()+Y0;
         		z[i]=ZTAN*get1int()+Z0;
			}
		  }
		  else if (mode==6) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*get1int()+X0;
         		z[i]=ZTAN*get1int()+Z0;
			}
		  }
		  else if (mode==7) {
			for (i=0;i<n;i++) {
        		x[i]=XTAN*get1int()+X0;
         		y[i]=YTAN*get1int()+Y0;
			}
		  }
		  else if (mode==8) {
			for (i=0;i<n;i++) {
        		x[i]=XTC*get1int();
         		y[i]=YTC*get1int();
  	    	   	z[i]=ZTC*get1int();
		  	}
		}
	  }
	  else {
		if (mode==0) {
			for (i=0;i<n;i++) get1int();
		  }
		  else if (mode==1 || mode==8) {
			for (i=0;i<n*3;i++) get1int();
		  }
		  else if (mode==2) {
			for (i=0;i<n*3;i++) getdouble1();
		  }
		  else if (mode==5 || mode==6 || mode==7) {
			for (i=0;i<n*2;i++) get1int();
		}
	}
}

static int alloc_data(frames_data *dat,int dim,int size,int n)
{
	size*=n;
  	if (dim>0) {
  		if (dat->X!=NULL) free(dat->X);
  		dat->X=(double *)malloc(size);
  		if (dat->X==NULL) return -1;
  	}
  	if (dim>1) {
  		if (dat->Y!=NULL) free(dat->Y);
  		dat->Y=(double *)malloc(size);
  		if (dat->Y==NULL) return -1;
  	}
  	if (dim>2 || dim==-2) {
  		if (dat->Z!=NULL) free(dat->Z);
  		dat->Z=(double *)malloc(size);
  		if (dat->Z==NULL) return -1;
  	}
  	if (dim==-1) {
  		if (dat->W!=NULL) free(dat->W);
  		dat->W=(int *)malloc(size);
  		if (dat->W==NULL) return -1;
  		dat->wsize=n;
  		return 0;
  	}
  	dat->size=n;
  	return 0;
}

static int alloc_fdata(frames_data *dat,int size,int n)
{
	size*=n;
	if (dat->F!=NULL) free(dat->F);
	dat->F=(double *)malloc(size);
	if (dat->F==NULL) return -1;
	return 0;
}

int open_plt_file(char *name)
{
	char b1[5],c1;
	static char b[4]={42,84,65,71};
	static char ver[3]={42,43,44};
	int i,bx,by,ox,oy,rgb[3];

	*filename='\0';
	check_ext(name,filename,"plt");

#ifdef HP
	if ((fpg=fopen(filename,"rb"))==NULL) {
#else
	if ((FDIO=open(filename,O_RDONLY))==-1) {
#endif
		error_end("Cannot open this file",0);
		return 1;
	}

	ENDFILE=0;		DRAWED=0;
	FADR0=FADR1=0L;

#ifndef BIGENDIAN
	getbyte(b1,5);
#else
	getbyte(b1,-5);
#endif
	for (i=0;i<4;i++) {
		if (b1[i]!=b[i]) goto err;
	}
	if (b1[4]==ver[2]) {
#ifndef BIGENDIAN
		getbyte(b1,2);
#else
		getbyte(b1,-2);
#endif
		VERSION=b1[0];
		if (b1[1]==2) {
			bx=getint();		by=getint();
			ox=getint();		oy=getint();
		  }
		  else if (b1[1]!=1) goto err;
		if (VERSION>=5) {
			getbyte(&c1,1);
			if (VERSION>=7) {
				getbyte(&c1,1);
				if (c1&2) {
					rgb[0]=getint3();
					rgb[1]=getint3();
					rgb[2]=getint3();
				  }
				  else rgb[0]=-1;
/*				if (c1&4) CHARSIZE=getint()/((double)(BASECOLVAL));		*/
				if (c1&4) getint();
			}
		}
	  }
	  else if (b1[4]==ver[1]) {
#ifndef BIGENDIAN
		getbyte(b1,1);
#else
		getbyte(b1,-1);
#endif
		if (b1[0]==2) {
			bx=getint();		by=getint();
			ox=getint();		oy=getint();
		  }
		  else if (b1[0]!=1) goto err;
		VERSION=1;
	  }
	  else if (b1[4]==ver[0]) VERSION=0;
	  else goto err;

	fr_com=-1;		cur_level=DEFAULT_LEVEL;		next_data=0;
	unget_data=0;

	for (i=0;i<128;i++) {
		com_level[i]=NONCOM_LEVEL;
		com_spec[i]=0;
	}
	com_level[FRAMES_VIEW2D]=VIEW_LEVEL;			/*	fr_view2d(&ix1,&iy1,&ix2,&iy2);				*/
	com_level[FRAMES_FRAME2D]=FRAME_LEVEL;			/*	fr_frame2d(&x1,&x2,&y1,&y2,&ind);			*/
	com_level[FRAMES_XYNAME]=LABEL_LEVEL;			/*	fr_xyname(chx,chy);							*/
	com_spec[FRAMES_XYNAME]=STRING_2D;
	com_level[FRAMES_GRAPH2D]=DATA_LEVEL;			/*	fr_graph2d(X,Y,&n,&ic,&ind);				*/
	/*com_spec[FRAMES_GRAPH2D]=DOUBLE_2D;*/
	com_level[FRAMES_DRAW2D]=DATA_LEVEL;			/*	fr_draw2d(&x1,&y1,&ic,&ind);				*/
	com_level[FRAMES_VECTOR2D]=DATA_LEVEL;			/*	fr_vector2d(&x1,&y1,&x2,&y2,&ic,&ind);		*/
	com_level[FRAMES_ASPECT2D]=VIEW_LEVEL;			/*	fr_aspect2d(&x1,&y1,&ind);					*/
	com_level[FRAMES_2DPOLYGON]=DATA_LEVEL;			/*	fr_2dpolygon(X,Y,&n,&ic,&ind);				*/

	com_level[FRAMES_CONTOUR]=DATA_LEVEL;			/*	fr_setcontour(X,&ix1,&iy1,&ind,&ic);		*/
	com_spec[FRAMES_CONTOUR]=DOUBLE_1D;
	com_level[FRAMES_SETCONTOUR]=SET_LEVEL;			/*	fr_setcontour(&x1,&x2,&ind);				*/
	com_level[FRAMES_LOGAXIS]=FRAME_LEVEL;			/*	fr_logaxis(&ind);							*/
	com_level[FRAMES_COLORBAR]=VIEW_LEVEL;			/*	fr_colorbar(&ix1,&iy1,&ix2,&iy2,&ind);		*/
	com_level[FRAMES_TRICONTOUR]=DATA_LEVEL;		/*	fr_tricontour(X,Y,Z,&nx,WS,&ny,&ix1,&ic,&iy1);	*/
	com_spec[FRAMES_TRICONTOUR]=FIELD1_TRI;
	com_level[FRAMES_SQRCONTOUR]=DATA_LEVEL;		/*	fr_sqrcontour(X,Y,Z,&ix1,&iy1,&ix2,&ic,&ind);	*/
	com_spec[FRAMES_SQRCONTOUR]=DOUBLE_3D;

	com_level[FRAMES_PMVIEW]=VIEW_LEVEL;			/*	fr_pmview(&ix1,&iy1,&ix2,&iy2,&iz1,&iz2);	*/
	com_level[FRAMES_PMFRAME]=FRAME_LEVEL;			/*	fr_pmframe(&x1,&x2,&y1,&y2,&z1,&z2,&ind);	*/
	com_level[FRAMES_XYZNAME]=LABEL_LEVEL;			/*	fr_xyzname(chx,chy,chz);					*/
	com_spec[FRAMES_XYZNAME]=STRING_3D;
	com_level[FRAMES_PMGRAPH]=DATA_LEVEL;			/*	fr_pmgraph(X,Y,Z,&n,&ic,&ind);				*/
	com_level[FRAMES_PMDRAW]=DATA_LEVEL;			/*	fr_pmdraw(&x1,&y1,&ic,&ind);				*/

	com_level[FRAMES_PMSET]=FRAME_LEVEL;			/*	fr_pmset(&z1);								*/
	com_level[FRAMES_HCLEAR]=SET_LEVEL;				/*	fr_hclear(&ind);							*/

	com_level[FRAMES_PROFILE]=DATA_LEVEL;			/*	fr_profile(X,&ix1,&iy1,&ic,&ind);			*/
	com_spec[FRAMES_PROFILE]=DOUBLE_1D;
	com_level[FRAMES_SURFACE]=DATA_LEVEL;			/*	fr_surface(X,Y,Z,&ix1,&iy1,&ic,&ind);	*/
	com_spec[FRAMES_SURFACE]=DOUBLE_3D;

	com_level[FRAMES_VIEW3D]=VIEW_LEVEL;			/*	fr_view3d(&ix1,&iy1,&ix2,&iy2);				*/
	com_level[FRAMES_ANGLE3D]=VIEW_LEVEL;			/*	fr_angle3d(&x1,&x2);						*/
	com_level[FRAMES_ASPECT3D]=VIEW_LEVEL;			/*	fr_aspect3d(&x1,&y1,&z1,&ind);				*/
	com_level[FRAMES_ROTATE]=VIEW_LEVEL;			/*	fr_rotate(&x1,&x2,&ind);					*/
	com_level[FRAMES_FRAME3D]=FRAME_LEVEL;			/*	fr_frame3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);	*/
	com_level[FRAMES_GRAPH3D]=DATA_LEVEL;			/*	fr_graph3d(X,Y,Z,&n,&ic,&ind);				*/
	/*com_spec[FRAMES_GRAPH3D]=DOUBLE_3D;*/
	com_level[FRAMES_DRAW3D]=DATA_LEVEL;			/*	fr_draw3d(&x1,&y1,&z1,&ic,&ind);			*/
	com_level[FRAMES_VECTOR3D]=DATA_LEVEL;			/*	fr_vector3d(&x1,&y1,&z1,&x2,&y2,&z2,&ic,&ind);	*/
	com_level[FRAMES_PROJECT]=VIEW_LEVEL;			/*	fr_project(&z1,&ind);						*/
	com_level[FRAMES_SLICES]=DATA_LEVEL;			/*	fr_slices(X,&nx,&ny,&nz,&z1,&n,i,&c,&ind);	*/
	com_spec[FRAMES_SLICES]=DOUBLE_1D;
	com_level[FRAMES_TRISURFACE]=DATA_LEVEL;		/*	fr_trisurface(X,Y,Z,&nx,WS,&ny,&ic,&ind);	*/
	com_spec[FRAMES_TRISURFACE]=FIELD1_TRI;
	com_level[FRAMES_ISOSURFACE]=DATA_LEVEL;		/*	fr_isosurface(X,&ix2,&iy2,&iz2,&z1,&ic,&ind);	*/
	com_spec[FRAMES_ISOSURFACE]=DOUBLE_1D;
	com_level[FRAMES_CLIP3D]=VIEW_LEVEL;			/*	fr_clip3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);		*/
	com_level[FRAMES_VOLRENDER]=DATA_LEVEL;			/*	fr_volrender(X,&ix2,&iy2,&iz2,&ic,&ind);		*/
	com_spec[FRAMES_VOLRENDER]=DOUBLE_1D;
	com_level[FRAMES_3DLINE]=DATA_LEVEL;			/*	fr_3dline(&x1,&y1,&z1,&x2,&y2,&z2,&ic,&ind);	*/
	com_level[FRAMES_3DCIRCLE]=DATA_LEVEL;			/*	fr_3dcircle(&x1,&y1,&z1,&x2,&y2,&z2,&r1,&ph,&th,&ic,&ind);	*/
	com_level[FRAMES_3DDOTS]=DATA_LEVEL;			/*	fr_3ddots(X,Y,Z,&ic,&n,&ind);				*/

	com_level[FRAMES_FPLINE]=PRIM_LEVEL;			/*	fr_fpline(&x1,&y1,&x2,&y2,&ic,&ind);		*/
	com_level[FRAMES_FPCIRCLE]=PRIM_LEVEL;			/*	fr_fpcircle(&x1,&y1,&x2,&y2,&ic,&ind);		*/
	com_level[FRAMES_FPMARK]=PRIM_LEVEL;			/*	fr_fpmark(&x1,&y1,&x2,&y2,&ix1,&ic,&ind);	*/
	com_level[FRAMES_FPPOLYGON]=PRIM_LEVEL;			/*	fr_fppolygon(X,Y,&n,&ic,&ind);				*/
	com_spec[FRAMES_FPPOLYGON]=DOUBLE_2D;
	com_level[FRAMES_FPCHARS]=PRIM_LEVEL;			/*	fr_fpchars(&x1,&y1,chx,&ic,&ix1,&iy1,&ind);	*/
	com_spec[FRAMES_FPCHARS]=STRING_1D;
	com_level[FRAMES_FPDOTS]=PRIM_LEVEL;			/*	fr_fpdots(X,Y,WS,&n,&ind);					*/
	com_spec[FRAMES_FPDOTS]=DOUBLE_2D;
	com_level[FRAMES_2DMOVE]=PRIM_LEVEL;			/*	fr_2dmove(&x1,&y1,&ind);					*/
	com_level[FRAMES_3DMOVE]=PRIM_LEVEL;			/*	fr_3dmove(&x1,&y1,&z1,&ind);				*/
	com_level[FRAMES_3DPOLYGON]=PRIM_LEVEL;			/*	fr_3dpolygon(X,Y,Z,&n,&ic,&ind);			*/

	com_level[FRAMES_SETCIRCLE]=SET_LEVEL;			/*	fr_setcircle(&x1);							*/
	com_level[FRAMES_SETMARK]=SET_LEVEL;			/*	fr_setmark(&x1,&y1,&ind);					*/
	com_level[FRAMES_SETBAR]=SET_LEVEL;				/*	fr_setbar(&x1,&ind);					*/
	com_level[FRAMES_SETARROW]=SET_LEVEL;			/*	fr_setarrow(&x1,&y1);						*/
	com_level[FRAMES_SET2DRGN]=SET_LEVEL;			/*	fr_set2drgn(&ix1,&ix2,&iy1,&iy2);			*/
	com_level[FRAMES_SET3DRGN]=SET_LEVEL;			/*	fr_set3drgn(&ix1,&ix2,&iy1,&iy2,&iz1,&iz2);	*/
	com_level[FRAMES_SETSTEP]=SET_LEVEL;			/*	fr_setstep(&ix1);							*/
	com_level[FRAMES_SETFRAME]=SET_LEVEL;			/*	fr_setframe(&ix1,&ind);						*/
	com_level[FRAMES_SETLIGHT]=SET_LEVEL;			/*	fr_setlight(&th,&ph,&ind);					*/
	com_level[FRAMES_SETSURFACE]=SET_LEVEL;			/*	fr_setsurface(&x1,&x2,&ind);				*/
	com_level[FRAMES_SETVOLUME]=SET_LEVEL;			/*	fr_setvolume(&x1,&x2,&y1,&y2);				*/

	com_level[FRAMES_GNOTES]=INLAY_LEVEL;			/*	fr_gnotes	*/
	com_spec[FRAMES_GNOTES]=STRING_1D;
	com_level[FRAMES_FILECHAR]=INLAY_LEVEL;			/*	fr_filechar	*/
	com_spec[FRAMES_FILECHAR]=STRING_1D;
	com_level[FRAMES_FILEINT]=INLAY_LEVEL;			/*	fr_fileint	*/
	com_level[FRAMES_FILEDBLE]=INLAY_LEVEL;			/*	fr_filedble	*/

	com_level[FRAMES_HLSSET]=SET_LEVEL;				/*	fr_hlsset(csh,csl,css,cn,&ic);				*/
	com_spec[FRAMES_HLSSET]=DOUBLE_3D;
	com_level[FRAMES_GPAGEC]=CNTL_LEVEL;			/*	fr_gpage(&ix1,&ix2);						*/
	com_level[FRAMES_GPAGE]=CNTL_LEVEL;				/*	fr_gpage(&ix1,&ix2);						*/
	com_level[FRAMES_GCLEAR]=CNTL_LEVEL;			/*	fr_pagesw(&ind);							*/
	com_level[FRAMES_GEND]=END_LEVEL;				/*	fr_gend();									*/

	return 0;
err:
	error_end("This is not a plt file",1);
	return 1;
}

static void close_plt_file()
{
#ifdef HP
	fclose(fpg);
#else
	close(FDIO);
#endif
}

int get_frames_command(int mode)
{
	signed char c1;
	int fpoff;

	if (ENDFILE) return -1;
	if (unget_data) {
		unget_data=0;
		return fr_com;
	}
	if (next_data) {
		if (get_frames_data(NULL)!=0) goto err;
	}

	fpoff=FOFF+1;
	while (1) {
		getbyte(&c1,1);
		fr_com=c1;
		if (c1<=0 || com_level[fr_com]==NONCOM_LEVEL) goto err;
		if (com_level[fr_com]==END_LEVEL) {
			close_plt_file();
			return 0;
		}
		if (mode==1 && com_level[fr_com]==CNTL_LEVEL && DRAWED) {
			if (get_frames_data(NULL)!=0) goto err;
			DRAWED=0;
			return fr_com-127;
		}
		if (com_level[fr_com]<=cur_level) {
			next_data=1;
			return fr_com;
		}
		if (get_frames_data(NULL)!=0) break;
	}
err:
	fprintf(stderr,"Command No. %d ---  Adress %08x ---\n",c1,fpoff);
	error_end("The command is not supported yet",1);
	close_plt_file();
	return 0;
}

void unget_frames_command(void)
{
	unget_data=1;
}

void change_frames_level(int level)
{
	cur_level=level;
}

static void free_frames_xyz(frames_data *dat)
{
	if (dat->X!=NULL) {  free(dat->X);  dat->X=NULL;  }
	if (dat->Y!=NULL) {  free(dat->Y);  dat->Y=NULL;  }
	if (dat->Z!=NULL) {  free(dat->Z);  dat->Z=NULL;  }
	dat->size=0;
}

void free_frames_data(frames_data *dat)
{
	if (dat!=NULL && dat->com>0) {
		dat->com=0;
		free_frames_xyz(dat);
		if (dat->W!=NULL) {  free(dat->W);  dat->W=NULL;  }
		dat->wsize=0;
	}
}

int get_frames_data(frames_data *dat)
{
	char	*chx,*chy,*chz;
	int		i,nx,ny,nz,n,c,ind,iprof,fpoff,spec,nn[3],n0;
	double 	x1,x2,x3,y1,y2,y3,z1,z2,z3,r1,xx[3],yy[3];
	signed 	char c1,c2;

	if (ENDFILE) return -1;
	if (setjmp(env)) return -1;

	fpoff=FOFF+1;
	c1=fr_com;
	if (dat!=NULL) {
		if (dat->com<=0) {
			dat->X=dat->Y=dat->Z=dat->F=NULL;
			dat->W=NULL;
			dat->size=dat->wsize=0;
			spec=com_spec[fr_com];
		  }
		  else {
			spec=(dat->com)&0x0000ffff;
			if (((dat->com)>>16)!=fr_com) {
				if (com_spec[fr_com]>0) {
			  		if (com_spec[fr_com]!=spec) {
						free_frames_xyz(dat);
						spec=com_spec[fr_com];
					}
				}
			}
		}
		dat->com=(fr_com<<16)|spec;
	}

		switch (c1/10) {
		  case 0:
		  	switch (c1) {
			  case FRAMES_VIEW2D:
			  	if (dat==NULL) {
			  		for (i=0;i<4;i++) getint();
			  	  }
			  	  else {
					dat->n=getint();			dat->c=getint();
					dat->nx=getint();			dat->ny=getint();
				}
				/*	fr_view2d(&n,&c,&nx,&ny);				*/
				goto next;

			  case FRAMES_FRAME2D:
				DRAWED++;
				getbyte(&c1,1);
				if (VERSION>=5) getbyte(&c2,1);
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				XTAN=(x2-x1)/XMAX;		X0=min(x1,x2);
				YTAN=(y2-y1)/XMAX;		Y0=min(y1,y2);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
				}
				/*	fr_frame2d(&x1,&x2,&y1,&y2,&nz);			*/
				goto next;

			  case FRAMES_XYNAME:
				DRAWED++;
				nx=getint();		ny=getint();
				if (dat==NULL) {
#ifndef BIGENDIAN
					getbyte(str,nx);	getbyte(str,ny);
#else
					getbyte(str,-nx);	getbyte(str,-ny);
#endif
				  }
				  else {
				  	if (dat->size!=MAXNCHAR) {
					  	alloc_data(dat,2,sizeof(char),MAXNCHAR);
					}
					dat->nx=nx;				dat->ny=ny;
				  	chx=(char *)dat->X;		chy=(char *)dat->Y;
#ifndef BIGENDIAN
					getbyte(chx,nx);		getbyte(chy,ny);
#else
					getbyte(chx,-nx);		getbyte(chy,-ny);
#endif
					chx[nx]='\0';			chy[ny]='\0';
				}
				/*	fr_xyname(chx,chy);						*/
				goto next;
			  case FRAMES_GRAPH2D:
				DRAWED++;
				if (VERSION==0) {	getbyte(&c1,1);		i=c1;	 }
					else		i=getint();
				nx=abs(i/100);
				c=getint();			getbyte(&n,4);
				if (dat!=NULL) {
					dat->c=c;		dat->md=i;		dat->n=n;
					if (nx==0) {
						if (spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
				  		if (dat->size<n) {
							if (spec==DOUBLE_3D) free_frames_xyz(dat);
						  	alloc_data(dat,2,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_2D;
						}
						get8byte(dat->X,dat->Y,n,1,1);
					  }
					  else {
						get8byte(&x1,&y1,1,0,1);
						dat->x1=x1;		dat->x2=y1;
						if (spec!=DOUBLE_1D && spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
				  		if (dat->size<n) {
							if (spec==DOUBLE_2D || spec==DOUBLE_3D) free_frames_xyz(dat);
						  	alloc_data(dat,1,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_1D;
						}
						if (nx==2) get8byte(dat->X,NULL,n,5,1);
							else   get8byte(NULL,dat->X,n,6,1);
					}
				  }
				  else {
					if (nx==0) {
						get8byte(NULL,NULL,n,1,0);
					  }
					  else {
						get8byte(&x1,&y1,1,0,0);
						get8byte(NULL,NULL,n,5,0);
					}
				}
				/*	fr_graph2d(X,Y,&n,&c,&nz);					*/
				goto next;
			  case FRAMES_DRAW2D:
				DRAWED++;
				getbyte(&c1,1);		c=getint();
				get8byte(&x1,&y1,1,1,1);
				if (dat!=NULL) {
					dat->md=c1;		dat->c=c;
					dat->x1=x1;		dat->y1=y1;
				}
				/*	fr_draw2d(&x1,&y1,&c,&nz);					*/
				goto next;
			  case FRAMES_VECTOR2D:
				DRAWED++;
				getbyte(&c1,1);		c=getint();
				get8byte(&x1,&y1,1,1,1);
				get8byte(&x2,&y2,1,2,1);
				if (dat!=NULL) {
					dat->md=c1;		dat->c=c;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
				}
      			/*	fr_vector2d(&x1,&y1,&x2,&y2,&c,&nz);		*/
				goto next;
			  case FRAMES_ASPECT2D:
				getbyte(&c1,1);
				y1=getddouble1();
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=1;		dat->y1=y1;
				}
				/*	fr_aspect2d(&x1,&y1,&nz);					*/
				goto next;
			  case FRAMES_2DPOLYGON:
				DRAWED++;
				getbyte(&c1,1);		c=getint();		getbyte(&n,4);
				if (dat!=NULL) {
					dat->c=c;		dat->md=c1;
				  	if (dat->size<n) {
					  	alloc_data(dat,2,sizeof(double),n);
					}
					dat->n=n;
					get8byte(dat->X,dat->Y,n,2,1);
				  }
				  else get8byte(NULL,NULL,n,2,0);
				/*	fr_2dpolygon(X,Y,&n,&ic,&ind);				*/
				goto next;
			}
		   	goto error;

		  case 1:
		  case 3:
		  	switch (c1) {
			  case FRAMES_CONTOUR:
				DRAWED++;
				c=getint();			nz=getint();
				getbyte(&nx,4);		getbyte(&ny,4);
				n=nx*ny;
				if (VERSION>=3) {
					get8byte(&x1,&x2,1,0,1);
					get8byte(&y1,&y2,1,0,1);
				}
				if (dat!=NULL) {
					dat->c=c;		dat->n=nz;
				  	if (dat->size<n) {
					  	alloc_data(dat,1,sizeof(double),n);
					}
					dat->nx=nx;		dat->ny=ny;
					get8byte(dat->X,NULL,n,4,1);
				  }
				  else get8byte(NULL,NULL,n,4,0);
				/*	fr_contour(X,&nx,&ny,&n,&c);				*/
				goto next;
			  case FRAMES_SETCONTOUR:
				nz=getint();
			    if (VERSION<2) {
					if (nz<5) get8byte(&x1,&y1,1,0,1);
				  }
				  else {
				    if (nz>0 && nz<5) get8byte(&x1,&y1,1,0,1);
				}
				if (dat!=NULL) {
					dat->md=nz;
					if (nz<5) {	dat->x1=x1;		dat->y1=y1;		}
				}
				/*	fr_setcontour(&x1,&x2,&nz);					*/
				goto next;
			  case FRAMES_LOGAXIS:
				DRAWED++;
				getbyte(&c1,1);
				if (dat!=NULL) dat->md=c1;
				/*	fr_logaxis(&nz);							*/
				goto next;
			  case FRAMES_COLORBAR:
				DRAWED++;
				if (VERSION<3) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
//				if (VERSION<9) ind/=10;
			  	if (dat==NULL) {
			  		for (i=0;i<4;i++) getint();
			  	  }
			  	  else {
			  		dat->md=ind;
					dat->n=getint();			dat->c=getint();
					dat->nx=getint();			dat->ny=getint();
				}
				/*	fr_colorbar(&n,&c,&nx,&ny,&nz);				*/
				goto next;
			  case FRAMES_TRICONTOUR:
				DRAWED++;
				c=getint();			nz=getint();		i=getint();
				getbyte(&nx,4);		getbyte(&ny,4);
				if (nx<256) 				n=1;
					else if (nx<65536)		n=2;
					else if (nx<16777216) 	n=3;
					else 					n=4;
				if (dat!=NULL) {
					dat->c=c;		dat->n=nz;		dat->md=i;
				  	if (dat->size<nx) {
					  	alloc_data(dat,3,sizeof(double),nx);
					}
					get8byte(dat->X,dat->Y,nx,1,1);		get8byte(dat->Z,dat->Y,nx,4,1);
				  	if (dat->wsize<ny*3) {
					  	alloc_data(dat,-1,sizeof(int),ny*3);
					}
					for (i=0;i<ny*3;i++) dat->W[i]=getnint(n);
				  }
				  else {
					get8byte(NULL,NULL,nx,1,0);		get8byte(NULL,NULL,nx,4,0);
					for (i=0;i<ny*3;i++) getnint(n);
				}
				/*	fr_tricontour(X,Y,Z,&nx,W,&ny,&n,&c,&nz);		*/
				goto next;
			  case FRAMES_SQRCONTOUR:
				DRAWED++;
				c=getint();			nz=getint();		i=getint();
				getbyte(&nx,4);		getbyte(&ny,4);
				n=nx*ny;
				if (dat!=NULL) {
					dat->c=c;		dat->n=nz;		dat->md=i;
				  	if (dat->size<n) {
					  	alloc_data(dat,3,sizeof(double),n);
					}
					dat->nx=nx;		dat->ny=ny;
					get8byte(dat->X,dat->Y,n,1,1);		get8byte(dat->Z,dat->Y,n,4,1);
				  }
				  else {
					get8byte(NULL,NULL,n,1,0);		get8byte(NULL,NULL,n,4,0);
				}
				/*	fr_sqrcontour(X,Y,Z,&nx,&ny,&n,&c,&nz);	*/
				goto next;

			  case FRAMES_PMVIEW:
			  	if (dat==NULL) {
			  		for (i=0;i<6;i++) getint();
			  	  }
			  	  else {
					dat->n=getint();			dat->c=getint();
					dat->nx=getint();			dat->ny=getint();
					dat->size=getint();			dat->wsize=getint();
				}
				/*	fr_pmview(&n,&c,&nx,&ny,&size,&wsize);		*/
				goto next;
			  case FRAMES_PMFRAME:
				DRAWED++;
				getbyte(&c1,1);
				if (VERSION>=5) getbyte(&c2,1);
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				XTAN=(x2-x1)/XMAX;		X0=min(x1,x2);
				YTAN=(y2-y1)/XMAX;		Y0=min(y1,y2);
				ZTAN=(z2-z1)/XMAX;		Z0=min(z1,z2);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
					dat->z1=z1;		dat->z2=z2;
				}
				/*	fr_pmframe(&x1,&x2,&y1,&y2,&z1,&z2,&nz);	*/
				goto next;

			  case FRAMES_XYZNAME:
				DRAWED++;
				nx=getint();		ny=getint();		nz=getint();
				if (dat==NULL) {
#ifndef BIGENDIAN
					getbyte(str,nx);	getbyte(str,ny);	getbyte(str,nz);
#else
					getbyte(str,-nx);	getbyte(str,-ny);	getbyte(str,-nz);
#endif
				  }
				  else {
				  	if (dat->size!=MAXNCHAR) {
					  	alloc_data(dat,3,sizeof(char),MAXNCHAR);
					}
					dat->nx=nx;				dat->ny=ny;				dat->nz=nz;
				  	chx=(char *)dat->X;		chy=(char *)dat->Y;		chz=(char *)dat->Z;
#ifndef BIGENDIAN
					getbyte(chx,nx);		getbyte(chy,ny);		getbyte(chz,nz);
#else
					getbyte(chx,-nx);		getbyte(chy,-ny);		getbyte(chz,-nz);
#endif
					chx[nx]='\0';			chy[ny]='\0';			chz[nz]='\0';
				}
				/*	fr_xyzname(chx,chy,chz);					*/
				goto next;
			  case FRAMES_PMGRAPH:
				DRAWED++;
				if (VERSION==0) {	getbyte(&c1,1);		i=c1;	 }
					else		i=getint();
				nx=abs(i/100);	ny=i%100;
				c=getint();		getbyte(&n,4);
				nz=ny/10;
				if (nz) {
					if (dat!=NULL) {
						dat->c=c;		dat->md=i;
						dat->n=n;		dat->nx=nz;
						if (nx==0) {
							if (spec!=DOUBLE_3D) free_frames_xyz(dat);
					  		if (dat->size<n) {
						  		alloc_data(dat,3,sizeof(double),n);
								dat->com=(fr_com<<16)|DOUBLE_3D;
							}
							get38byte(dat->X,dat->Y,dat->Z,n,1,1);
						  }
						  else {
							if (spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
				 	 		if (dat->size<n) {
								if (spec==DOUBLE_3D) free_frames_xyz(dat);
						  		alloc_data(dat,2,sizeof(double),n);
								dat->com=(fr_com<<16)|DOUBLE_2D;
							}
							get8byte(&x1,&y1,1,0,1);
							dat->x1=x1;		dat->x2=y1;
						  	if (nx==2) get38byte(dat->X,NULL,dat->Y,n,6,1);
							  else 	   get38byte(NULL,dat->X,dat->Y,n,5,1);
						}
					  }
					  else {
						if (nx==0) {
					  		get38byte(NULL,NULL,NULL,n,1,0);
						  }
						  else {
							get8byte(&x1,&y1,1,0,0);
						  	get38byte(NULL,NULL,NULL,n,5,0);
						}
					}
					/*	fr_pmgraph(X,Y,Z,&n,&c,&nz);				*/
				  }
				  else {
					if (dat!=NULL) {
						get38byte(&z1,&z1,&z1,1,0,1);
						dat->c=c;		dat->md=i;
						dat->z1=z1;		dat->n=n;		  	dat->nx=nz;
						if (nx==0) {
							if (spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
					  		if (dat->size<n) {
								if (spec==DOUBLE_3D) free_frames_xyz(dat);
						  		alloc_data(dat,2,sizeof(double),n);
								dat->com=(fr_com<<16)|DOUBLE_2D;
							}
							get8byte(dat->X,dat->Y,n,1,1);
						  }
						  else {
							if (spec!=DOUBLE_1D && spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
				 	 		if (dat->size<n) {
								if (spec==DOUBLE_2D || spec==DOUBLE_3D) free_frames_xyz(dat);
						  		alloc_data(dat,1,sizeof(double),n);
								dat->com=(fr_com<<16)|DOUBLE_1D;
							}
							get8byte(&x1,&y1,1,0,1);
							dat->x1=x1;		dat->x2=y1;
						  	if (nx==2) get8byte(dat->X,NULL,n,5,1);
							  else 	   get8byte(NULL,dat->X,n,6,1);
						}
					  }
					  else {
						get38byte(&z1,&z1,&z1,1,0,0);
						if (nx==0) {
							get8byte(NULL,NULL,n,1,0);
						  }
						  else {
							get8byte(&x1,&y1,1,0,0);
						  	get8byte(NULL,NULL,n,5,0);
						}
					}
					/*	fr_pmgraph(X,Y,&z1,&n,&c,&nz);				*/
				  }
				goto next;
			  case FRAMES_PMDRAW:
				DRAWED++;
				getbyte(&c1,1);		c=getint();
				get8byte(&x1,&y1,1,1,1);
				if (dat!=NULL) {
					dat->md=c1;		dat->c=c;
					dat->x1=x1;		dat->y1=y1;
				}
				/*	fr_pmdraw(&x1,&y1,&c,&nz);					*/
				goto next;
			}
			goto error;

		  case 4:
		  case 5:
		  	switch (c1) {
			  case FRAMES_PMSET:
				get38byte(&z1,&z1,&z1,1,0,1);
				if (dat!=NULL) dat->z1=z1;
				/*	fr_pmset(&z1);								*/
				goto next;
			  case FRAMES_HCLEAR:
				getbyte(&c1,1);
				if (dat!=NULL) dat->md=c1;
				/*	fr_hclear(&nz);							*/
				goto next;

			  case FRAMES_PROFILE:
				DRAWED++;
				if (VERSION<8) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				c=getint();
				getbyte(&nx,4);			getbyte(&ny,4);
				n=nx*ny;
				if (VERSION>=3) {
					get8byte(&x1,&x2,1,0,1);
					get8byte(&y1,&y2,1,0,1);
				}
				if (iprof==0) {
					if (dat!=NULL) {
						dat->c=c;		dat->md=ind;
						if (dat->size<n) {
							alloc_data(dat,1,sizeof(double),n);
						}
						dat->nx=nx;		dat->ny=ny;
						get8byte(dat->X,NULL,n,4,1);
					  }
					  else get8byte(NULL,NULL,n,4,0);
				  }
				  else {
					if (dat!=NULL) {
						dat->c=c;		dat->md=ind;
						if (dat->size<n) {
							alloc_data(dat,2,sizeof(double),n);
						}
						dat->nx=nx;		dat->ny=ny;
						get8byte(dat->X,NULL,n,4,1);
						get8byte(dat->Y,NULL,n,4,1);
					  }
					  else {
						get8byte(NULL,NULL,n,4,0);
						get8byte(NULL,NULL,n,4,0);
					}
				}
				/*		if (iprof==0) fr_profile(X,&nx,&ny,&c,&nz);
						else	  fr_mapprofile(X,Y,&ix2,&iy2,&ic,&ind);			*/
				goto next;
			  case FRAMES_SURFACE:
				DRAWED++;
				if (VERSION<3) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				c=getint();
				getbyte(&nx,4);			getbyte(&ny,4);
				n=nx*ny;
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;			dat->nx=nx;			dat->ny=ny;
					nx=abs(ind/100);		ny=ind%10;
					if (iprof) {
						alloc_fdata(dat,sizeof(double),n);
						get8byte(dat->F,NULL,n,4,1);
					}
					if (nx==0) {
						if (spec!=DOUBLE_3D) free_frames_xyz(dat);
			  			if (dat->size<n) {
				  			alloc_data(dat,3,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_3D;
						}
						get38byte(dat->X,dat->Y,dat->Z,n,1,1);
					  }
					  else if (nx==3 || nx==5 || nx==6) {
						if (spec!=DOUBLE_1D && spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
			 	 		if (dat->size<n) {
							if (spec==DOUBLE_2D || spec==DOUBLE_3D) free_frames_xyz(dat);
					  		alloc_data(dat,1,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_1D;
						}
						get8byte(xx,yy,3,2,1);
						dat->x1=xx[0];		dat->y1=xx[1];		dat->z1=xx[2];
						dat->x2=yy[0];		dat->y2=yy[1];		dat->z2=yy[2];
						if (nx==3) 		  get38byte(NULL,NULL,dat->X,n,0,1);
						  else if (nx==5) get8byte(NULL,dat->X,n,6,1);
						  else			  get8byte(dat->X,NULL,n,5,1);
					  }
					  else {
						if (spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
					  	if (dat->size<n) {
							if (spec==DOUBLE_3D) free_frames_xyz(dat);
						  	alloc_data(dat,2,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_2D;
						}
						get8byte(xx,yy,3,3,1);
						dat->x1=xx[0];		dat->y1=xx[1];		dat->z1=xx[2];
					  	if (nx==1) 		  get38byte(NULL,dat->X,dat->Y,n,5,1);
						  else if (nx==2) get38byte(dat->X,NULL,dat->Y,n,6,1);
						  else 			  get38byte(dat->X,dat->Y,NULL,n,7,1);
					}
				  }
				  else {
					nx=abs(ind/100);		ny=ind%10;
					if (iprof) {
						get8byte(NULL,NULL,n,4,0);
					}
					if (nx==0) get38byte(NULL,NULL,NULL,n,1,0);
					  else if (nx==3 || nx==5 || nx==6) {
						get8byte(xx,yy,3,2,0);
						get8byte(NULL,NULL,n,5,0);
					  }
					  else {
						get8byte(xx,yy,3,3,0);
					  	get38byte(NULL,NULL,NULL,n,5,0);
					}
				}
				/*	fr_surface(X,Y,xx,&ix1,&iy1,&ic,&ind);	*/
				goto next;
			}
		   	goto error;

		  case 6:
		  case 7:
		  	switch (c1) {
			  case FRAMES_VIEW3D:
			  	if (dat==NULL) {
			  		for (i=0;i<4;i++) getint();
			  	  }
			  	  else {
					dat->n=getint();			dat->c=getint();
					dat->nx=getint();			dat->ny=getint();
				}
				/*	fr_view3d(&n,&c,&nx,&ny);					*/
				goto next;
			  case FRAMES_ANGLE3D:
				get8byte(&x1,&x2,1,0,1);
				if (dat!=NULL) {
					dat->x1=x1;		dat->x2=x2;
				}
				/*	fr_angle3d(&x1,&x2);						*/
				goto next;
			  case FRAMES_ASPECT3D:
				getbyte(&c1,1);
				get8byte(&y1,&z1,1,0,1);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=1;		dat->y1=y1;		dat->z1=z1;
				}
				/*	fr_aspect3d(&x1,&y1,&z1,&nz);				*/
				goto next;
			  case FRAMES_ROTATE:
				getbyte(&c1,1);
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				r1=getddouble1();
				XTAN=(x2-x1)/XMAX;		X0=min(x1,x2);
				YTAN=(y2-y1)/XMAX;		Y0=min(y1,y2);
				ZTAN=(z2-z1)/XMAX;		Z0=min(z1,z2);
				get8byte(&x1,&x2,1,0,1);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->x2=x2;
				}
				/*	fr_rotate(&x1,&x2,&nz);					*/
				goto next;
			  case FRAMES_FRAME3D:
				DRAWED++;
				getbyte(&c1,1);
				if (VERSION>=5) getbyte(&c2,1);
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				XTAN=(x2-x1)/XMAX;		X0=min(x1,x2);
				YTAN=(y2-y1)/XMAX;		Y0=min(y1,y2);
				ZTAN=(z2-z1)/XMAX;		Z0=min(z1,z2);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
					dat->z1=z1;		dat->z2=z2;
				}
				/*	fr_frame3d(&x1,&x2,&y1,&y2,&z1,&z2,&nz);	*/
				goto next;
			  case FRAMES_GRAPH3D:
				DRAWED++;
				if (VERSION==0) {	getbyte(&c1,1);		i=c1;	 }
					else		i=getint();
				nx=abs(i/100);
				if (i==-13) {
					getbyte(&n,4);
				  }
				  else {
					c=getint();		getbyte(&n,4);
				}
				if (dat!=NULL) {
					dat->md=i;
					if (i==-13) {
						if (dat->wsize<n) {
						alloc_data(dat,-1,sizeof(int),n);
						}
						for (i=0;i<n;i++) {  getbyte(&c1,1);	dat->W[i]=c1;	}
					}
					dat->c=c;			dat->n=n;
					if (nx==0) {
						if (spec!=DOUBLE_3D) free_frames_xyz(dat);
			  			if (dat->size<n) {
				  			alloc_data(dat,3,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_3D;
						}
						get38byte(dat->X,dat->Y,dat->Z,n,1,1);
					  }
					  else if (nx==3 || nx==5 || nx==6) {
						if (spec!=DOUBLE_1D && spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
			 	 		if (dat->size<n) {
							if (spec==DOUBLE_2D || spec==DOUBLE_3D) free_frames_xyz(dat);
					  		alloc_data(dat,1,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_1D;
						}
						get8byte(&x1,&y1,1,0,1);
						dat->x1=x1;		dat->x2=y1;
						get8byte(&x1,&y1,1,0,1);
						dat->y1=x1;		dat->y2=y1;
						if (nx==3) 		  get38byte(NULL,NULL,dat->X,n,0,1);
						  else if (nx==5) get8byte(NULL,dat->X,n,6,1);
						  else			  get8byte(dat->X,NULL,n,5,1);
					  }
					  else {
						if (spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
					  	if (dat->size<n) {
							if (spec==DOUBLE_3D) free_frames_xyz(dat);
						  	alloc_data(dat,2,sizeof(double),n);
							dat->com=(fr_com<<16)|DOUBLE_2D;
						}
						get8byte(&x1,&y1,1,0,1);
						dat->x1=x1;		dat->x2=y1;
					  	if (nx==1) 		  get38byte(NULL,dat->X,dat->Y,n,5,1);
						  else if (nx==2) get38byte(dat->X,NULL,dat->Y,n,6,1);
						  else 			  get38byte(dat->X,dat->Y,NULL,n,7,1);
					}
				  }
				  else {
					if (i==-13) {
						for (i=0;i<n;i++) getbyte(&c1,1);
					}
					if (nx==0) get38byte(NULL,NULL,NULL,n,1,0);
					  else if (nx==3 || nx==5 || nx==6) {
						get8byte(&x1,&y1,1,0,0);
						get8byte(&x1,&y1,1,0,0);
						get8byte(NULL,NULL,n,5,0);
					  }
					  else {
						get8byte(&x1,&y1,1,0,0);
					  	get38byte(NULL,NULL,NULL,n,5,0);
					}
				}
				/*	fr_graph3d(X,Y,Z,&n,&c,&nz);				*/
				goto next;
			  case FRAMES_DRAW3D:
				DRAWED++;
				getbyte(&c1,1);		c=getint();
				get38byte(&x1,&y1,&z1,1,1,1);
				if (dat!=NULL) {
					dat->md=c1;		dat->c=c;
					dat->x1=x1;		dat->y1=y1;		dat->z1=z1;
				}
				/*	fr_draw3d(&x1,&y1,&z1,&c,&nz);			*/
				goto next;
			  case FRAMES_VECTOR3D:
				DRAWED++;
				getbyte(&c1,1);		c=getint();
				get38byte(&x1,&y1,&z1,1,1,1);
				get38byte(&x2,&y2,&z2,1,2,1);
				if (dat!=NULL) {
					dat->md=c1;		dat->c=c;
					dat->x1=x1;		dat->y1=y1;		dat->z1=z1;
					dat->x2=x2;		dat->y2=y2;		dat->z2=z2;
				}
				/*	fr_vector3d(&x1,&y1,&z1,&x2,&y2,&z2,&c,&nz);	*/
				goto next;
			  case FRAMES_PROJECT:
				getbyte(&c1,1);		z1=getdouble1();
				if (dat!=NULL) {
					dat->md=c1;		dat->z1=z1;
				}
				/*	fr_project(&z1,&nz);						*/
				goto next;
			  case FRAMES_SLICES:
				DRAWED++;
				ind=getint();			c=getint();			i=getint();
				if (VERSION<8) {
					nn[0]=ind/100;		ind=ind%100;
					if (nn[0]<0) nn[0]=1;
				  }
				  else {
				  	nn[0]=getint();		nn[1]=getint();		nn[2]=getint();
				}
				getbyte(&nx,4);			getbyte(&ny,4);
				if (VERSION>=3) {
					getbyte(&nz,4);
					n=nx*ny*nz;
					get8byte(&x1,&x2,1,0,1);
					get8byte(&y1,&y2,1,0,1);
					get8byte(&z1,&z2,1,0,1);
				  }
				  else {
					nz=1;
					n=nx*ny;
				}
				if (VERSION>=8) {
					xx[0]=getddouble1();	xx[1]=getddouble1();	xx[2]=getddouble1();
				  }
				  else if (VERSION>=3 || c/10==0) xx[0]=getddouble1();
				if (dat!=NULL) {
					dat->c=c;		dat->n=i;		dat->md=ind;
				  	if (dat->size<n) {
					  	alloc_data(dat,1,sizeof(double),n);
					}
					dat->nx=nx;		dat->ny=ny;		dat->nz=nz;
					get8byte(dat->X,NULL,n,4,1);
				  }
				  else get8byte(NULL,NULL,n,4,0);
				/*	fr_slices(X,&nx,&ny,&nz,&z1,&n,i,&c,&ind);	*/
				goto next;
			  case FRAMES_TRISURFACE:
				DRAWED++;
				if (VERSION<9) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				c=getint();
				getbyte(&nx,4);		getbyte(&ny,4);
				if (nx<256) 				n=1;
					else if (nx<65536)		n=2;
					else if (nx<16777216) 	n=3;
					else 					n=4;
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
					if (iprof) {
						alloc_fdata(dat,sizeof(double),nx);
						get8byte(dat->F,NULL,nx,4,1);
					}
				  	if (dat->size<nx) {
					  	alloc_data(dat,3,sizeof(double),nx);
					}
					get38byte(dat->X,dat->Y,dat->Z,nx,1,1);
				  	if (dat->wsize<ny*3) {
					  	alloc_data(dat,-1,sizeof(int),ny*3);
					}
					dat->nx=nx;		dat->ny=ny;
					for (i=0;i<ny*3;i++) dat->W[i]=getnint(n);
				  }
				  else {
					if (iprof) {
						get8byte(NULL,NULL,nx,4,0);
					}
					get38byte(NULL,NULL,NULL,nx,1,0);
					for (i=0;i<ny*3;i++) getnint(n);
				}
				/*	fr_trisurface(X,Y,Z,&nx,W,&ny,&c,&nz);*/
				goto next;
			  case FRAMES_ISOSURFACE:
				DRAWED++;
				ind=getint();			c=getint();
				getbyte(&nx,4);			getbyte(&ny,4);			getbyte(&nz,4);
				n=nx*ny*nz;
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				n0=1;
				if (VERSION>=10) n0=getint();
				z1=getddouble1();
				for (i=1;i<n0;i++) {
					getint();		getddouble1();
				}
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
				  	if (dat->size<n) {
					  	alloc_data(dat,1,sizeof(double),n);
					}
					dat->nx=nx;		dat->ny=ny;		dat->nz=nz;
					get8byte(dat->X,NULL,n,4,1);
				  }
				  else get8byte(NULL,NULL,n,4,0);
				/*	fr_isosurface(X,&ix2,&iy2,&iz2,&z1,&ic,&ind);	*/
				goto next;
			  case FRAMES_CLIP3D:
				getbyte(&c1,1);
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
					dat->z1=z1;		dat->z2=z2;
				}
				/*	fr_clip3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);		*/
				goto next;
			  case FRAMES_VOLRENDER:
				DRAWED++;
				ind=getint();			c=getint();
				getbyte(&nx,4);			getbyte(&ny,4);			getbyte(&nz,4);
				n=nx*ny*nz;
				get8byte(&x1,&x2,1,0,1);
				get8byte(&y1,&y2,1,0,1);
				get8byte(&z1,&z2,1,0,1);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
				  	if (dat->size<n) {
					  	alloc_data(dat,1,sizeof(double),n);
					}
					dat->nx=nx;		dat->ny=ny;		dat->nz=nz;
					get8byte(dat->X,NULL,n,4,1);
				  }
				  else get8byte(NULL,NULL,n,4,0);
				/*	fr_volrender(X,&ix2,&iy2,&iz2,&ic,&ind);	*/
				goto next;
			}
			goto error;

		  case 8:
		  case 9:
			switch (c1) {
			  case FRAMES_FPLINE:
			  case FRAMES_FPCIRCLE:
				DRAWED++;
				ind=getubyte();			c=getint();
				get8byte(&x1,&y1,1,2,1);
				get8byte(&x2,&y2,1,2,1);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
					dat->x1=x1;		dat->y1=y1;
					if (VERSION==0) {
						x2*=2;		y2*=2;
					}
					dat->x2=x2;		dat->y2=y2;
				}
				/*	fr_fpline(&x1,&y1,&x2,&y2,&c,&md);			*/
				/*	fr_fpcircle(&x1,&y1,&x2,&y2,&c,&md);			*/
				goto next;
			  case FRAMES_FPPOLYGON:
				DRAWED++;
				ind=getubyte();		c=getint();		getbyte(&n,4);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
				  	if (dat->size<n) {
					  	alloc_data(dat,2,sizeof(double),n);
					}
					dat->n=n;
					get8byte(dat->X,dat->Y,n,2,1);
				  }
				  else get8byte(NULL,NULL,n,2,0);
				/*	fr_fppolygon(X,Y,&n,&c,&nz);					*/
				goto next;
			  case FRAMES_FPMARK:
				DRAWED++;
				ind=getubyte();		c=getint();		nx=getint();
				get8byte(&x1,&y1,1,2,1);
				get8byte(&x2,&y2,1,2,1);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;		dat->n=nx;
					dat->x1=x1;		dat->y1=y1;
					dat->x2=x2;		dat->y2=y2;
				}
				/*	fr_fpmark(&x1,&y1,&x2,&y2,&c,&md);			*/
				goto next;
			  case FRAMES_FPCHARS:
				DRAWED++;
				if (VERSION>=3) {
					ind=getubyte();
				  }
				  else ind=0;
				getbyte(&c1,1);			nx=c1;
				getbyte(&c1,1);			ny=c1;
				getbyte(&c1,1);			nz=c1;
				c=getint();
				get8byte(&x1,&y1,1,2,1);
				n=getint();
				if (dat==NULL) {
#ifndef BIGENDIAN
					getbyte(str,n);
#else
					getbyte(str,-n);
#endif
				  }
				  else {
				  	if (dat->size!=MAXNCHAR) {
					  	alloc_data(dat,1,sizeof(char),MAXNCHAR);
					}
					dat->n=n;			dat->md=ind;	chx=(char *)dat->X;
					dat->nx=nx;			dat->ny=ny;		dat->x1=nz;
					
#ifndef BIGENDIAN
					getbyte(chx,n);
#else
					getbyte(chx,-n);
#endif
					chx[n]='\0';
				}
				/*	fr_fpchars(&x1,&y1,chx,&c,&nx,&ny,&nz,&nz);	*/
				goto next;
			  case FRAMES_FPDOTS:
				DRAWED++;
				ind=getubyte();		getbyte(&n,4);
				if (dat!=NULL) {
					dat->md=ind;
				  	if (dat->size<n) {
					  	alloc_data(dat,2,sizeof(double),n);
					}
					dat->n=n;
					get8byte(dat->X,dat->Y,n,2,1);
					if (ind==0) dat->c=getint();
					  else {
					  	if (dat->wsize<n) {
						  	alloc_data(dat,-1,sizeof(int),n);
						}
						for (i=0;i<n;i++) dat->W[i]=getint();
					}
				  }
				  else {
					get8byte(NULL,NULL,n,2,0);
					if (ind==0) getint();
					  else {
						for (i=0;i<n;i++) getint();
					}
				}
				/*	fr_fpdots(X,Y,&ic,&n,&ind);					*/
				goto next;
			  case FRAMES_2DMOVE:
				getbyte(&c1,1);
				get8byte(&x1,&y1,1,2,1);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->y1=y1;
				}
				/*	fr_2dmove(&x1,&y1,&ind);						*/
				goto next;
			  case FRAMES_3DMOVE:
				getbyte(&c1,1);
				get38byte(&x1,&y1,&z1,1,2,1);
				if (dat!=NULL) {
					dat->md=c1;
					dat->x1=x1;		dat->y1=y1;		dat->z1=z1;
				}
				/*	fr_3dmove(&x1,&y1,&z1,&ind);					*/
				goto next;
			  case FRAMES_3DPOLYGON:
				DRAWED++;
				ind=getubyte();		c=getint();		getbyte(&n,4);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
					dat->n=n;
					if (spec!=DOUBLE_3D) free_frames_xyz(dat);
		  			if (dat->size<n) {
			  			alloc_data(dat,3,sizeof(double),n);
						dat->com=(fr_com<<16)|DOUBLE_3D;
					}
					get38byte(dat->X,dat->Y,dat->Z,n,2,1);
				  }
				  else get38byte(NULL,NULL,NULL,n,2,0);
				/*  fr_3dpolygon(X,Y,Z,&n,&ic,&ind);				*/
				goto next;
			  case FRAMES_3DLINE:
				DRAWED++;
				ind=getubyte();		c=getint();
				get38byte(&x1,&y1,&z1,1,2,0);
				get38byte(&x2,&y2,&z2,1,2,0);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
					dat->z1=z1;		dat->z2=z2;
				  }
				/*  fr_3dline(&x1,&y1,&z1,&x2,&y2,&z2,&ic,&ind);				*/
				goto next;
			  case FRAMES_3DCIRCLE:
				DRAWED++;
				ind=getubyte();		c=getint();
				get38byte(&x1,&y1,&z1,1,2,0);
				get38byte(&x2,&y2,&z2,1,2,0);
				get38byte(&x3,&y3,&z3,1,2,0);
				if (dat!=NULL) {
					dat->c=c;		dat->md=ind;
					dat->x1=x1;		dat->x2=x2;
					dat->y1=y1;		dat->y2=y2;
					dat->z1=z1;		dat->z2=z2;
				  }
				/*  fr_3dcircle(&x1,&y1,&z1,&x2,&y2,&z2,&x3,&y3,&z3,&ic,&ind);				*/
				goto next;

			  case FRAMES_3DDOTS:
				DRAWED++;
				ind=getubyte();		getbyte(&n,4);
				if (dat!=NULL) {
					dat->md=ind;
					if (dat->size<n) {
						alloc_data(dat,3,sizeof(double),n);
					}
					dat->n=n;
					get38byte(dat->X,dat->Y,dat->Z,n,2,1);
					if (ind==0) dat->c=getint();
					  else {
						if (dat->wsize<n) {
							alloc_data(dat,-1,sizeof(int),n);
						}
						for (i=0;i<n;i++) dat->W[i]=getint();
					}
				  }
				  else {
					get38byte(NULL,NULL,NULL,n,2,0);
					if (ind==0) getint();
					  else {
						for (i=0;i<n;i++) getint();
					}
				}
				/*	fr_3ddots(X,Y,Z,&ic,&n,&ind);				*/
				goto next;
			}
		   	goto error;

		  default:
			   switch (c1) {
				  case FRAMES_SETCIRCLE:
				   	/*	n=getint();	*/
				  	if (VERSION==0) {
						nx=getint();		x1=nx*2;
					  }
					  else get8byte(&x1,&x2,1,-1,1);
			  		if (dat!=NULL) dat->x1=x1;
					/*	fr_setcircle(&x1);							*/
					goto next;
				  case FRAMES_SETMARK:
					nx=getint();
					get8byte(&x1,&x2,1,0,1);
			  		if (dat!=NULL) {
						dat->md=nx;
			  			dat->x1=x1;		dat->x2=x2;
			  		}
					/*	fr_setmark(&x1,&x2,&nx);					*/
					goto next;
				  case FRAMES_SETBAR:
					getbyte(&c1,1);
					get8byte(&x1,&x2,1,-1,1);
					if (dat!=NULL) {
						dat->md=c1;		dat->x1=x1;
					}
					/*	fr_setbar(&x1,&ind);						*/
					goto next;
				  case FRAMES_SETARROW:
					/*	nx=getint();	ny=getint();	*/
				  	if (VERSION==0) {
						nx=getint();	ny=getint();
						x1=nx;			x2=ny;
					  }
					  else get8byte(&x1,&x2,1,0,1);
			  		if (dat!=NULL) {
			  			dat->x1=x1;		dat->x2=x2;
			  		}
					/*	fr_setarrow(&x1,&x2);						*/
					goto next;
				  case FRAMES_SET2DRGN:
					getbyte(&n,4);
					if (n>0) getbyte(&nx,4);
					    else   nx=n+1;
					getbyte(&c,4);
					if (c>0) getbyte(&ny,4);
					    else   ny=c+1;
			  		if (dat!=NULL) {
			  			dat->n=n;		dat->c=c;
			  			dat->nx=nx;		dat->ny=ny;
			  		}
					/*	fr_set2drgn(&n,&nx,&c,&ny);						*/
					goto next;
				  case FRAMES_SET3DRGN:
					getbyte(&n,4);
					if (n>0) getbyte(&nx,4);
					    else   nx=n+1;
					getbyte(&c,4);
					if (c>0) getbyte(&ny,4);
					    else   ny=c+1;
					getbyte(&i,4);
					if (i>0) getbyte(&nz,4);
					    else   nz=i+1;
			  		if (dat!=NULL) {
			  			dat->n=n;		dat->c=c;		dat->md=i;
			  			dat->nx=nx;		dat->ny=ny;		dat->nz=nz;
			  		}
					/*	fr_set3drgn(&n,&nx,&c,&ny,&i,&nz);				*/
					goto next;
				  case FRAMES_SETSTEP:
					getbyte(&n,4);
			  		if (dat!=NULL) dat->n=n;
					/*	fr_setstep(&n);									*/
					goto next;
				  case FRAMES_SETFRAME:
					getbyte(&n,4);
					if (n>=100) {  n-=100;  nz=2;  }
					   else       nz=1;
			  		if (dat!=NULL) {
			  			dat->n=n;		dat->md=nz;
			  		}
					/*	fr_setframe(&n,&nz);							*/
					goto next;
				  case FRAMES_SETLIGHT:
					getbyte(&c1,1);
					get8byte(&x1,&x2,1,0,1);
					if (dat!=NULL) {
						dat->md=c1;
						dat->x1=x1;		dat->x2=x2;
					}
					/*	fr_setlight(&th,&ph,&ind);						*/
					goto next;
				  case FRAMES_SETSURFACE:
					getbyte(&c1,1);
					get8byte(&x1,&x2,1,0,1);
					if (dat!=NULL) {
						dat->md=c1;
						dat->x1=x1;		dat->x2=x2;
					}
					/*	fr_setsurface(&x1,&x2,&ind);					*/
					goto next;
				  case FRAMES_SETVOLUME:
					get8byte(&x1,&x2,1,0,1);
					get8byte(&y1,&y2,1,0,1);
					if (dat!=NULL) {
						dat->x1=x1;		dat->x2=x2;
						dat->y1=y1;		dat->y2=y2;
					}
					/*	fr_setvolume(&x1,&x2,&y1,&y2);					*/
					goto next;

				  case FRAMES_GNOTES:		/*	fr_gnotes	*/
				  case FRAMES_FILECHAR:		/*	fr_filechar	*/
					getbyte(&c1,1);		n=(unsigned char)c1;
					if (dat==NULL) {
#ifndef BIGENDIAN
						getbyte(str,n);
#else
						getbyte(str,-n);
#endif
					  }
					  else {
					  	if (dat->size!=MAXNCHAR2) {
						  	alloc_data(dat,1,sizeof(char),MAXNCHAR2);
						}
						dat->n=n;			chx=(char *)dat->X;
#ifndef BIGENDIAN
						getbyte(chx,n);
#else
						getbyte(chx,-n);
#endif
						chx[n]='\0';
					}
					goto next;

				  case FRAMES_FILEINT:		/*	fr_fileint	*/
					getbyte(&c1,1);		n=(unsigned char)c1;
				  	if (dat==NULL) {
				  		for (i=0;i<n;i++) getnint(4);
				  	  }
				  	  else {
						dat->n=n;
				  	  	if (n<=3) {
							if (n>0) dat->nx=getnint(4);
								else goto next;
							if (n>1) dat->ny=getnint(4);
								else goto next;
							if (n>2) dat->nz=getnint(4);
				  	  	  }
				  	  	  else {
						  	if (dat->wsize<n) {
							  	alloc_data(dat,-1,sizeof(int),n);
							}
							for (i=0;i<n;i++) dat->W[i]=getnint(4);
						}
					}
					goto next;

				  case FRAMES_FILEDBLE:		/*	fr_filedble	*/
					getbyte(&c1,1);		n=(unsigned char)c1;
				  	if (dat==NULL) {
				  		for (i=0;i<n;i++) getddouble1();
				  	  }
				  	  else {
						dat->n=n;
				  	  	if (n<=6) {
							if (n>0) dat->x1=getddouble1();
								else goto next;
							if (n>1) dat->y1=getddouble1();
								else goto next;
							if (n>2) dat->z1=getddouble1();
								else goto next;
							if (n>3) dat->x2=getddouble1();
								else goto next;
							if (n>4) dat->y2=getddouble1();
								else goto next;
							if (n>5) dat->z2=getddouble1();
				  	  	  }
				  	  	  else {
				  	  	  	if (spec!=DOUBLE_1D && spec!=DOUBLE_2D && spec!=DOUBLE_3D) free_frames_xyz(dat);
						  	if (dat->size<n) {
				  	  	  		if (spec==DOUBLE_2D || spec==DOUBLE_3D) free_frames_xyz(dat);
							  	alloc_data(dat,1,sizeof(double),n);
								dat->com=(fr_com<<16)|DOUBLE_1D;
							}
							for (i=0;i<n;i++) dat->X[i]=getddouble1();
						}
					}
					goto next;

				  case FRAMES_HLSSET:
					if (VERSION<2) {
						c=getint();			n=getint();
					  }
					  else {
				getc1:	getbyte(&c1,1);
						if (c1<=-2) {
							if (c1==ONECMAPP5) c=getint()-1;
								else c=-c1-3;
							if (dat!=NULL) {
								dat->c=c1;		dat->n=c;
							}
							/*	hlsset(X,Y,Z,&iy1,&ic);		*/
							goto next;
						}
						if (c1==-1) {
							c=-1;
							if (dat!=NULL) dat->c=c1;
							goto next;
						}
						while (c1==3 || c1==4) {
							if (c1==3) {
								getbyte(&c1,1);		c=c1;
							  }
							  else c=getint();
							n=getint();
/*							if (FOFF>FOFFHLS) {
								FOFFHLS=FOFF;
								fc=create_colormap(ic);
								fc->cn[0]=iy1;
								if (ic>0) {
									for (i=1;i<ic;i++) fc->cn[i]=getint();
									get38byte(fc->csh,fc->csl,fc->css,ic+1,8);
								  }
							  }
							  else if (ic>0) {	*/
							if (c>0) {
								for (i=1;i<c;i++) getint();
								for (i=0;i<3*(c+1);i++) getsreal();
							}
							getbyte(&c1,1);
						}
						if (c1==5) goto getc1;
						if (c1==1) {
							getbyte(&c1,1);		c=c1;
						  }
						  else c=getint();
						n=getint();
					}
					if (c>0) {
						if (dat!=NULL) {
							dat->c=c;		dat->n=n;
							if (c>1) {
							  	if (dat->wsize<c) {
								  	alloc_data(dat,-1,sizeof(int),c);
								}
								dat->W[0]=n;
								for (i=1;i<c;i++) dat->W[i]=getint();
							}
							if (dat->size<c+1) {
						  		alloc_data(dat,3,sizeof(double),c+1);
							}
							if (VERSION<5) {
								getbyte(&c1,1);
								get8byte(&x1,&x2,1,0,1);
								get8byte(&y1,&y2,1,0,1);
								get8byte(&z1,&z2,1,0,1);
								XTAN=(x2-x1)/XMAX;		X0=min(x1,x2);
								YTAN=(y2-y1)/XMAX;		Y0=min(y1,y2);
								ZTAN=(z2-z1)/XMAX;		Z0=min(z1,z2);
								get38byte(dat->X,dat->Y,dat->Z,c+1,1,1);
							  }
							  else get38byte(dat->X,dat->Y,dat->Z,c+1,8,1);
						  }
						  else {
							for (i=1;i<c;i++) getint();
							if (VERSION<5) {
								getbyte(&c1,1);
								get8byte(&x1,&x2,1,0,1);
								get8byte(&y1,&y2,1,0,1);
								get8byte(&z1,&z2,1,0,1);
								get38byte(NULL,NULL,NULL,c+1,1,0);
							  }
							  else get38byte(NULL,NULL,NULL,c+1,8,0);
						}
						/*	fr_hlsset(csh,csl,css,cn,&c);				*/
					  }
					  /*	else fr_hlsset(X,Y,Z,n or W,&c);		*/
					goto next;
	  			  case FRAMES_GPAGEC:
	  			  case FRAMES_GPAGE:
					getbyte(&c1,1);
					if (dat!=NULL) dat->md=c1;
					goto next;
				  case FRAMES_GCLEAR:
				  case FRAMES_GEND:
					goto next;
			}

	error:
			fprintf(stderr,"Command No. %d ---  Adress %08x ---\n",c1,fpoff);
			error_end("The command is not supported yet",1);
		  }

next:
	next_data=0;		unget_data=0;
	return 0;
}
