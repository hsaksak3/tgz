******************************************
*          F  R  A  M  E  S  V.7         *
*             FOR C CHARACTERS           *
******************************************

      SUBROUTINE REMOVEEXTENTION(NAME,NAME1)
      PARAMETER (MAXCHR=1024)
      CHARACTER NAME*(*),NAME1*(*)
      CHARACTER C*1

      N  = 1
      IC = 0
      ID = 0
      NC = 0
      ND = 0
      DO 10 I = 1, MAXCHR
         IF (NAME(I:I).EQ.CHAR(0)) GO TO 110
         C = NAME(I:I)
         IF (C.EQ.' ') GO TO 10
*         IF (C.EQ.'\\') C  = '/'
         IF (C.EQ.'.')  THEN
            IC = 1
            NC = I
          ELSE IF (C.EQ.'/') THEN
            ID = 1
            ND = I+1
         ENDIF
         NAME1(N:N) = C
         N = N + 1
   10   CONTINUE

  110 IF (IC.EQ.1.AND.ND.LE.NC) N = NC
      NAME1(N:N) = CHAR(0)

      RETURN
      END

      INTEGER FUNCTION CHRLENGTH(CH)
      PARAMETER (MAXCHR=1024)
      CHARACTER CH*(*)

      N = 0
      DO 10 I = 1, MAXCHR
         IF (CH(I:I).EQ.CHAR(0)) GO TO 110
         N = N + 1
   10   CONTINUE

  110 CHRLENGTH = N
      RETURN
      END
