***************************************************
*           F   R   A   M   E   S   V.7           *
*    CONTOUR  FOR AN ARBITRARY MESH SUBROUTINE    *
*            PROGRAMMED BY T.TAGUCHI              *
***************************************************

*      GIVEN DIMENSION IS X(IMAX,JMAX),Y(IMAX,JMAX),F(IMAX,JMAX)

      SUBROUTINE FR_SQRCONTOUR(X,Y,F,IMAX,JMAX,ND0,ICOL,MCOL)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 X(0:IMAX-1,0:JMAX-1),Y(0:IMAX-1,0:JMAX-1)
      REAL*8 F(0:IMAX-1,0:JMAX-1),FM1,FM2
      REAL   XP(6),YP(6)

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('SQR CONTOUR PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF
      
      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - SQRCONTOUR')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - SQRCONTOUR')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      XM1 = X(NX1,NY1)
      XM2 = XM1

      DO 10 J = NY1, NY2
         DO 110 I = NX1, NX2
            IF (X(I,J).LT.XM1) XM1 = X(I,J)
            IF (X(I,J).GT.XM2) XM2 = X(I,J)
  110   CONTINUE
   10   CONTINUE

      IF (XM2.EQ.XM1) RETURN

      YM1 = Y(NX1,NY1)
      YM2 = YM1

      DO 11 J = NY1, NY2
         DO 111 I = NX1, NX2
            IF (Y(I,J).LT.YM1) YM1 = Y(I,J)
            IF (Y(I,J).GT.YM2) YM2 = Y(I,J)
  111   CONTINUE
   11   CONTINUE

      IF (YM2.EQ.YM1) RETURN

      IF (IFRAM.EQ.0) THEN
*         IFRAM = 999
         IF (IDFFR2.LT.0) THEN
            IDFR = 1
          ELSE
            IDFR = IDFFR2
         ENDIF
         CALL FR_FRAME2D(DBLE(XM1),DBLE(XM2),DBLE(YM1),DBLE(YM2),IDFR)
      ENDIF

      IF (ICOL.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP

      FM1 = F(0,0)
      FM2 = FM1
      DO 12 J = 0, JMAX-1
         DO 112 I = 0, IMAX-1
            IF (F(I,J).LT.FM1) FM1 = F(I,J)
            IF (F(I,J).GT.FM2) FM2 = F(I,J)
  112     CONTINUE
   12     CONTINUE

      ND = ND0
      IF (IGPLT.GT.0) THEN
         IF (IFCONT.EQ.0) CALL FR_SETCONTOUR(0.D0,0.D0,-1)
         CALL GSENDBYTE(16,1)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(MCOL,2)
         CALL GSENDBYTE(ND,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSEND8BYTE(X,Y,IMAX*JMAX,1)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (MCOL.NE.0.AND.(ICOL.GT.-2.OR.ICOL.EQ.-4)) THEN
         CALL GWIOCOLOR(2,MCOL)
         DO 13 J = NY1, NY2
            XX = XTAN*X(NX1,J) + X0
            YY = YTAN*Y(NX1,J) + Y0
            DO 113 I = NX1+1, NX2
               XX1 = XTAN*X(I,J) + X0
               YY1 = YTAN*Y(I,J) + Y0
               CALL GWIOLINE(XX,YY,XX1,YY1,0)
               XX  = XX1
               YY  = YY1
  113     CONTINUE
   13     CONTINUE
         DO 14 I = NX1, NX2
            XX = XTAN*X(I,NY1) + X0
            YY = YTAN*Y(I,NY1) + Y0
            DO 114 J = NY1+1, NY2
               XX1 = XTAN*X(I,J) + X0
               YY1 = YTAN*Y(I,J) + Y0
               CALL GWIOLINE(XX,YY,XX1,YY1,0)
               XX  = XX1
               YY  = YY1
  114     CONTINUE
   14     CONTINUE
      ENDIF

      IF (ICOL.EQ.0) GO TO 1000

      CALL FGWIOCOLORSET(ICOL,ND,FM1,FM2)
      NSFINE = -MOD(ICOL/10,10)

      IF (FM2.EQ.FM1.AND.IFIND.NE.-2) GO TO 1000
      IF (ND.LE.0.AND.IFIND.NE.-2) GO TO 1000

      IF (IFIND.EQ.-4.OR.(IFIND.EQ.-3.AND.NSFINE.EQ.1)) THEN
         DO I = NX1, NX2-1
            DO J = NY1, NY2-1
               F00   = F(I,J)
               XP(1) = XTAN*X(I,J)     + X0
               YP(1) = YTAN*Y(I,J)     + Y0
               XP(2) = XTAN*X(I,J+1)   + X0
               YP(2) = YTAN*Y(I,J+1)   + Y0
               XP(3) = XTAN*X(I+1,J+1) + X0
               YP(3) = YTAN*Y(I+1,J+1) + Y0
               XP(4) = XTAN*X(I+1,J)   + X0
               YP(4) = YTAN*Y(I+1,J)   + Y0
*               RNF = (F(I,J) - FMIN)/DF
*               NF  = RNF + 0.5
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,F00)
            ENDDO
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-3) THEN
         DO I = NX1, NX2-1
            DO J = NY1, NY2-1
               F00   = F(I,J)+F(I,J+1)+F(I+1,J)+F(I+1,J+1)
               XP(1) = XTAN*X(I,J)     + X0
               YP(1) = YTAN*Y(I,J)     + Y0
               XP(2) = XTAN*X(I,J+1)   + X0
               YP(2) = YTAN*Y(I,J+1)   + Y0
               XP(3) = XTAN*X(I+1,J+1) + X0
               YP(3) = YTAN*Y(I+1,J+1) + Y0
               XP(4) = XTAN*X(I+1,J)   + X0
               YP(4) = YTAN*Y(I+1,J)   + Y0
*               RNF = (F00/4 - FMIN)/DF
*               NF  = RNF + 0.5
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,F00/4)
            ENDDO
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-5) THEN
         DO I = NX1, NX2
            DO J = NY1, NY2
               F00 = F(I,J)
               XP1 = XTAN*X(I,J) + X0
               YP1 = YTAN*Y(I,J) + Y0
*               RNF = (F(I,J) - FMIN)/DF
*               NF  = RNF + 0.5
               CALL FGWIOPSET(XP1,YP1,F00)
            ENDDO
         ENDDO
         GO TO 999
      ENDIF

      DO 20 I = NX1, NX2-1
         DO 21 J = NY1, NY2-1
            CFX(0) = XTAN*X(I,J)     + X0
            CFX(1) = XTAN*X(I,J+1)   + X0
            CFX(2) = XTAN*X(I+1,J)   + X0
            CFX(3) = XTAN*X(I+1,J+1) + X0
            CFY(0) = YTAN*Y(I,J)     + Y0
            CFY(1) = YTAN*Y(I,J+1)   + Y0
            CFY(2) = YTAN*Y(I+1,J)   + Y0
            CFY(3) = YTAN*Y(I+1,J+1) + Y0
            F0(0)  = F(I,J)
            F0(1)  = F(I,J+1)
            F0(2)  = F(I+1,J)
            F0(3)  = F(I+1,J+1)
            DO 40 K = 0, 3
               I0(K) = K
   40        CONTINUE
            DO 50 K = 0, 2
               DO 51 K1 = K+1, 3
                  IF (F0(K).GT.F0(K1)) THEN
                     IT      = I0(K)
                     I0(K)   = I0(K1)
                     I0(K1)  = IT
                     FF      = CFX(K)
                     CFX(K)  = CFX(K1)
                     CFX(K1) = FF
                     FF      = CFY(K)
                     CFY(K)  = CFY(K1)
                     CFY(K1) = FF
                     FF      = F0(K)
                     F0(K)   = F0(K1)
                     F0(K1)  = FF
                  ENDIF
   51         CONTINUE
   50         CONTINUE
            IF (IFIND.EQ.-2.AND.IFBASE.LT.0) THEN
               IF (F0(0).GE.FBASE.AND.F0(3).LE.FBASE1) GO TO 21
            ENDIF
            IF (I0(0)+I0(2).EQ.3) THEN
               F00 = F0(0)
               F03 = F0(3)
               NF  = (F00 - FMIN)/DF - 1
               IF (IFIND.EQ.-2) THEN
                  NPG   = 1
                  XP(1) = CFX(0)
                  YP(1) = CFY(0)
               ENDIF
   61          FD = NF*DF + FMIN
               IF (FD.LT.F00) THEN
                  NF = NF + 1
                  GO TO 61
               ENDIF
               DDX = CFX(3) - CFX(0)
               DDY = CFY(3) - CFY(0)
               IN0 = 0
               IN1 = 1

   70           CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F03) THEN
                  IF (IFIND.EQ.-2) THEN
                     IF (IN0.EQ.0) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(1)
                        YP(NPG) = CFY(1)
                     ENDIF
                     IF (IN0.NE.2) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(2)
                        YP(NPG) = CFY(2)
                     ENDIF
                  ENDIF
                  GO TO 79
               ENDIF
               DI = (FD - F00)/(F03 - F00)
   71          IF (FD.GT.F0(IN1)) THEN
                  IN0 = IN0 + 1
                  IN1 = IN1 + 1
                  IF (IFIND.EQ.-2) THEN
                     NPG     = NPG + 1
                     XP(NPG) = CFX(IN0)
                     YP(NPG) = CFY(IN0)
                  ENDIF
                  GO TO 71
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 78
               DJ = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
               XX0 = CFX(0) + DDX*DI
               YY0 = CFY(0) + DDY*DI
               XX1 = CFX(IN0) + (CFX(IN1) - CFX(IN0))*DJ
               YY1 = CFY(IN0) + (CFY(IN1) - CFY(IN0))*DJ
               IF (IFIND.EQ.-2) THEN
                  NPG       = NPG + 2
                  XP(NPG-1) = XX1
                  YP(NPG-1) = YY1
                  XP(NPG)   = XX0
                  YP(NPG)   = YY0
                  CALL FGWIOPOLYS(XP,YP,NPG)
                ELSE
                  CALL FGWIOLINE(XX0,YY0,XX1,YY1)
               ENDIF
   78          NF = NF + 1
               GO TO 70
   79          CONTINUE
               IF (IFIND.EQ.-2) THEN
                  NPG   = NPG + 1
                  XP(NPG) = CFX(3)
                  YP(NPG) = CFY(3)
                  CALL FGWIOPOLYS(XP,YP,NPG)
               ENDIF
             ELSE IF (I0(0)+I0(3).EQ.3) THEN
               NF  = (F0(0) - FMIN)/DF - 1
               IF (IFIND.EQ.-2) THEN
                  NPG   = 1
                  XP(1) = CFX(0)
                  YP(1) = CFY(0)
               ENDIF
   81          FD = NF*DF + FMIN
               IF (FD.LT.F0(0)) THEN
                  NF = NF + 1
                  GO TO 81
               ENDIF
               IN0 = 0
               IN1 = 1
               JN0 = 0
               JN1 = 2
   80          CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F0(3)) THEN
                  IF (IFIND.EQ.-2) THEN
                     IF (IN0.EQ.0) THEN
                        DO II = NPG, 1, -1
                           XP(II+1) = XP(II)
                           YP(II+1) = YP(II)
                        ENDDO
                        XP(1) = CFX(1)
                        YP(1) = CFY(1)
                        NPG   = NPG + 1
                        IF (JN0.EQ.0) THEN
                           NPG     = NPG + 1
                           XP(NPG) = CFX(2)
                           YP(NPG) = CFY(2)
                        ENDIF
                      ELSE IF (JN0.EQ.0) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(2)
                        YP(NPG) = CFY(2)
                     ENDIF
                  ENDIF
                  GO TO 89
               ENDIF
               IF (FD.GT.F0(IN1)) THEN
                  IN0 = 1
                  IN1 = 3
                  IF (IFIND.EQ.-2) THEN
                     DO II = NPG, 1, -1
                        XP(II+1) = XP(II)
                        YP(II+1) = YP(II)
                     ENDDO
                     XP(1) = CFX(1)
                     YP(1) = CFY(1)
                     NPG   = NPG + 1
                  ENDIF
               ENDIF
               IF (FD.GT.F0(JN1)) THEN
                  JN0 = 2
                  JN1 = 3
                  IF (IFIND.EQ.-2) THEN
                     NPG     = NPG + 1
                     XP(NPG) = CFX(2)
                     YP(NPG) = CFY(2)
                  ENDIF
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 88
               IF (F0(JN1).EQ.F0(JN0)) GO TO 88
               DI = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
               DJ = (FD - F0(JN0))/(F0(JN1) - F0(JN0))
               XX0 = CFX(IN0) + (CFX(IN1) - CFX(IN0))*DI
               YY0 = CFY(IN0) + (CFY(IN1) - CFY(IN0))*DI
               XX1 = CFX(JN0) + (CFX(JN1) - CFX(JN0))*DJ
               YY1 = CFY(JN0) + (CFY(JN1) - CFY(JN0))*DJ
               IF (IFIND.EQ.-2) THEN
                  NPG       = NPG + 2
                  XP(NPG-1) = XX1
                  YP(NPG-1) = YY1
                  XP(NPG)   = XX0
                  YP(NPG)   = YY0
                  CALL FGWIOPOLYS(XP,YP,NPG)
                ELSE
                  CALL FGWIOLINE(XX0,YY0,XX1,YY1)
               ENDIF
   88          NF = NF + 1
               GO TO 80
   89            CONTINUE
               IF (IFIND.EQ.-2) THEN
                  NPG   = NPG + 1
                  XP(NPG) = CFX(3)
                  YP(NPG) = CFY(3)
                  CALL FGWIOPOLYS(XP,YP,NPG)
               ENDIF
             ELSE IF (I.GT.NX1.AND.I.LT.NX2-1
     +              .AND.J.GT.NY1.AND.J.LT.NY2-1) THEN
               B1 = F(I-1,J-1) + F(I+2,J+2) - F(I,J) - F(I+1,J+1)
               B2 = F(I-1,J+2) + F(I+2,J-1) - F(I,J+1) - F(I+1,J)
               IF (B1.GE.0.AND.B2.GE.0) THEN
                  IND = 0
                ELSE IF (B1*B2.GE.0) THEN
                  IND = 1
                ELSE 
                  IND = 2
                  FMID = (8*(F0(0)+F0(1)+F0(2)+F0(3))-B1-B2)/32
                  IF (FMID.GE.F0(2)) THEN
                     IND = 1
                   ELSE IF (FMID.LE.F0(1)) THEN
                     IND = 0
                  ENDIF
               ENDIF
               IF (IND.EQ.0) THEN
                  CALL TRIANGCONTOUR(0,2,0,1)
                  CALL TRIANGCONTOUR(0,3,0,1)
                ELSE IF (IND.EQ.1) THEN
                  CALL TRIANGCONTOUR(0,3,0,2)
                  CALL TRIANGCONTOUR(1,3,1,2)
                ELSE
                  F0(4)  = FMID
                  I0(4)  = 4
                  CFX(4) = (CFX(0)+CFX(1)+CFX(2)+CFX(3))/4.0
                  CFY(4) = (CFY(0)+CFY(1)+CFY(2)+CFY(3))/4.0
                  DO 90 K = 0, 1
                     DO 91 K1 = 2, 3
                        CALL TRIANGCONTOUR(K,K1,K,4)
   91                 CONTINUE
   90                 CONTINUE
               ENDIF
             ELSE
               F0(4)  = (F0(0)+F0(1)+F0(2)+F0(3))/4
               I0(4)  = 4
               CFX(4) = (CFX(0)+CFX(1)+CFX(2)+CFX(3))/4.0
               CFY(4) = (CFY(0)+CFY(1)+CFY(2)+CFY(3))/4.0
               DO 95 K = 0, 1
                   DO 96 K1 = 2, 3
                      CALL TRIANGCONTOUR(K,K1,K,4)
   96            CONTINUE
   95            CONTINUE
         ENDIF
   21   CONTINUE
   20   CONTINUE

  999 IF (MCOL.NE.0.AND.ICOL.LE.-2.AND.ICOL.NE.-5) THEN
         CALL GWIOCOLOR(2,MCOL)
         DO 30 J = NY1, NY2
            XX = XTAN*X(NX1,J) + X0
            YY = YTAN*Y(NX1,J) + Y0
            DO 130 I = NX1+1, NX2
               XX1 = XTAN*X(I,J) + X0
               YY1 = YTAN*Y(I,J) + Y0
               CALL GWIOLINE(XX,YY,XX1,YY1,0)
               XX  = XX1
               YY  = YY1
  130     CONTINUE
   30     CONTINUE
         DO 31 I = NX1, NX2
            XX = XTAN*X(I,NY1) + X0
            YY = YTAN*Y(I,NY1) + Y0
            DO 131 J = NY1+1, NY2
               XX1 = XTAN*X(I,J) + X0
               YY1 = YTAN*Y(I,J) + Y0
               CALL GWIOLINE(XX,YY,XX1,YY1,0)
               XX  = XX1
               YY  = YY1
  131     CONTINUE
   31     CONTINUE
      ENDIF

 1000 CALL GWIOBDFLUSH(1)

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME2D(0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      RETURN
      END
