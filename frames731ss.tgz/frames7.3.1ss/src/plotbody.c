/*********************************************************
 *                 F r a m e s  V.7.3                    *
 *             tplot  core  routine  V.7.3               *
 *            Redraw, Dump & PS Conversion               *
 *                   for X-Frames                        *
 *               Programed by T. Taguchi                 *
 *                  September 17, 2012                    *
 *********************************************************
*/

#include <stdio.h>
/*#ifdef SOLARIS*/
#include <unistd.h>
/*#endif*/
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>
#include <sys/types.h>
#include <time.h>
#include <sys/time.h>

/*
#ifdef GIF
#include "gd.h"
#endif
*/
/*
#define TEMPORAL
#define TT_SPECIAL
#define TT_SPECIAL2
#define TT_SPECIAL_LOG
#define TT_GRAPH_LOG
#define TT_OLD
*/
/*#define TT_TEMPO_FRAME*/
#define TESTREALLOC
/*
#define EXTRA_1
#define SCALE_KEEP
*/

#define CLIP2DX
/*#define PROF2CONT*/
/*#define PROF23D*/

#ifdef SOLARIS
enum version {libm_ieee = -1, c_issue_4, ansi_1, strict_ansi};
const enum version _lib_version;
#endif

#define PLT_NOFUNCTIONS
#define NOT_USED_TPLOT
#include "frames_plt.h"
#include "frames_canvas.h"
#include "frames.h"

typedef struct {
	int num;			int *cn;
	double *csh;		double *csl;		double *css;
} frames_colormap;

extern void wpicdrawsetdisplaymode(int *);
extern void gwiodefaultsizes(int *, int *);
extern void fr_3ddots(double *, double *, double *, int *, int *, int *);

extern void gwiomodes(int *,int *,int *,float *);
extern void gwiopause(int *);
extern void gwioclearpage(void);
extern void framesgcanvas(int *);
extern void gwiocolor(int *,int *);
extern void gwioratio(int *,int *,int *,int *,int *,int *,int *);
extern void gwiosetwsize(int *,int *,int *,int *,int *,int *,int *);
extern void gwiochangeclip(int *);
extern void setrotateratio(double *,double *,double *,double *,double *,double *,double *);
extern void setwindowratio(int *);
extern void getcontorparm(double *,double *,double *,int *);
extern void setregion2dim(int *,int *,int *);
extern void setregion3dim(int *,int *,int *,int *);
extern void setregionxydim(double *,double *,double *,double *,int *);
extern void setregionxyzdim(double *,double *,double *,double *,double *,double *,int *);
extern void screengraph2d(double *,double *,double *,double *);
extern void settingsinput(double *,double *,double *,double *,int *);
extern void isosurfsetting(int);
extern void getlightsettings(double *,double *,double *,double *,int *);

extern void put_comment(char *);
extern void recreate_window(int, int);
extern void option_set(char *,int);
extern int	get_pref(char *);
extern void	get_windowsize(int *, int *, int *, int *, int *);
extern void	wpicdrawclosewindow(void);
extern void	wpicdrawbufwaitflush(void);
extern void	wpicdrawbufnowaitflush(void);
extern void	wpicdrawcolormode(int *);
extern int	window_idnumber(void);
extern void finish_drawframes(void);
extern void xwindow_clear(void);
extern void change_drawcolormode(int);
extern void set_basic_colormode(int, int *);
extern void set_character_size(double);
extern void clear_colmap_table(void);

extern void postscriptinit(int,int,int,int,int,int,int,int);
extern void postscriptstyle(int,char *,char *,int,int);
extern void postscriptend(void);
extern void postscriptnext(void);


#ifdef GIF
extern void giffile_init(int);
extern void giffilestyle(int,char *,char *,int,int);
extern void giffileend(int);
extern void gifframeclear(void);
extern void giffilenext(int);
extern void gifcolormode(int);
extern void gifgraycolormode(int);
extern void giftransparentmode(int);
extern void gifinterlacemode(int);
extern void gifdelaytiming(int);
extern void gifloopcount(int);
extern void gif_setaamode(int,int);
/*	extern void gif_aamode_init(void);		*/
#endif

void	alloc_data(int,int);
void	getbyte(void *,int);
unsigned char getubyte(void);
int		getint(void);
int		getint3(void);
void	seek8byte(int,int);
void	get8byte(double *,double *,int,int);
void	get38byte(double *,double *,double *,int,int);
int 	getnint(int),get1int(void);
double 	getsreal(void),getdouble1(void),getddouble1(void);
void 	set_counter(void);
void 	seekftadr(off_t);
int 	skip_frame_pages(int,int);
int		next_frame_page(signed char *,int,int);
int		next_frame_main(int);

#define BUFSIZE 		4096
#define XMAXBASE0		1.e5
#define XMAXBASE		2.e7
#define BEEP()  		fputc(0x07,stderr)
#define min(x,y)  		(((x)>=(y))?y:(x))
#define nothing
#define MAXNCHAR		128
#define MAXNCOL			10
#define ONEFILEP		100
#define ONECMAPP		100
#define ONECMAPP5		(-(ONECMAPP+5))
#define MAXPAGE			9999999
#define MAXGRAD			1.e10
#define LOGMIN			1.e-30
#define seekfadr(X)		seekftadr(FILEP[X])
#define INTERVALMAX		5000

extern int		TGMODE;

double	*X=NULL,*Y=NULL,*Z=NULL,*F=NULL;
int		*WS=NULL,NFILEP,NFILEP0,MAXFILEP;
int		NXALLOC=0,NYALLOC=0,NZALLOC=0;
int		CLRSTOP=1;
int 	SCALE2STEP=1,CONTOR2STEP=1,SCALE2STEP0=1,CONTOR2STEP0=1,NOWS=0,NOWC=0;
off_t	*FILEP=NULL,FADR0,FADR1,FOFF,FOFFHLS=0;

#ifdef NOPAGESWITCH
int		page_switching=0;
#else
int		page_switching=1;
#endif

#ifdef NOPSON
int		PSWRITE=0,PSPIPE=0,PSFILE=0,PSFMODE=0;
#else
int		PSWRITE=1,PSPIPE=0,PSFILE=0,PSFMODE=1;
#endif

#ifdef PSC3
int		PSCOLMODE=3;
#else
int		PSCOLMODE=1;
#endif

#ifdef USSIZE
int		PAPERSIZE=2;	/*	US Letter	*/
#else
int		PAPERSIZE=0;	/*	A4 Paper	*/
#endif

int 	PREFFILE=0,VERSION=2;
int		DRAWED=0,GRAPHNO=0,D3MODE=0,DISPMODE=0,USE0COL=0;
int		PSMODE=0,WINMODE=1,HARDNO=0,HARDMODE=0,GRAPHSTEP=1,GRAPHEACH=1;
int		C256MODE=0,CONTCOLOR=0,DISPINFO=0,GRAPHSTEP0=1,GRAPHEACH0=1;
int		VECTORMODE=1,CHARMODE=1,NOFPAGE=MAXPAGE,PSSIZEMODE=1;
int		PAPERDIR=0,PLOTLMAX=2,PLOTRMAX=1,STARTPAGE=0,GWIDTH=0,GHEIGHT=0,GXOFF=0,GYOFF=0;
int		WWIDTH,WHEIGHT,WRMODE,LMARG=-1,BMARG=-1,BWREVMODE=0,GWINFIX=0;
int		IGXOFF=0,IGYOFF=0,GWRNUM=WINRATE,GWRDEN=2;
float	PSYOFF;
double	XTAN,YTAN,ZTAN,X0,Y0,Z0;
int  	ENDFILE,ENDPAGE,GRAPHSPEC=0,SURFACEMODE=0;
int		SCALE2DMODE[MAXSCALENO],SCALE3DMODE[MAXSCALENO];
int		CONTOR2DMODE[MAXSCALENO],CONTOR3DMODE[MAXSCALENO],LOG2DMODE[MAXSCALENO];
double 	SC2DX1[MAXSCALENO],SC2DX2[MAXSCALENO],SC2DY1[MAXSCALENO],SC2DY2[MAXSCALENO];
double 	SC3DX1[MAXSCALENO],SC3DX2[MAXSCALENO],SC3DY1[MAXSCALENO],SC3DY2[MAXSCALENO];
double 	SC3DZ1[MAXSCALENO],SC3DZ2[MAXSCALENO],SC3DPH[MAXSCALENO],SC3DTH[MAXSCALENO];
double	CTRDF1[MAXSCALENO],CTRDF2[MAXSCALENO],CTRDDF[MAXSCALENO],CTRDT0[MAXSCALENO];
int		CTRDND[MAXSCALENO],CTRDDIM[MAXSCALENO],CTRDNUM[MAXSCALENO];
int     ANALYZEMODE=0,ANACOL,ANAORDER,NANA_DATA,LIGHTINGMODE=0,SURFACECOLOR=-1;
double  ANA2DX1,ANA2DX2,ANA_DATA[10];
double	ARROWLEN=1,ARROWHEAD=1,CIRCRAD=1,LINELIMIT=0,DOTRESOLVE=0,MOVIESPEED=15; /*0.002*/
double	LIGHTALT,LIGHTAZIM,LIGHTAMB,LIGHTDIFF,CHARSIZE=1;
int		DOTSKIP=1,REANGLE3D=0,MSECINTVAL=0,LIGHTNSPEC;
int		SETTINGMODE=0,COLORSEL=0x7f,COLORNOW=0,CLIP2DMODE=0,CLIP3DMODE=0,PROJ3DMODE=0,D3XYZMODE=0;
char	BUFFER[BUFSIZE],filename[MAXNCHAR],prefname[MAXNCHAR],**filelist=NULL;
frames_colormap **FRCOLP=NULL;
int		MAXCOLMAP=0,CURCOLMAP=0,NGSERIAL=0,CURHLSTABLE=-1,flistno=0;

#ifdef GIF
int		GIFMODE=0,GIFANIME=0,GIFWRITE=1,GIFCOLMODE=3,GIFFILE=0,GIFSTEP=1,GIFSTEPNO=1,GIFNCLEAR=0;
int		GIFSETT=-1,GIFSETB=0,GIFSETI=0,GIFBWREVMODE=1,GIFGRAYMODE=0,GIFADELAY=GIFBASEDELAY;
int		GIFCOLTABLE=1,GIFALOOP=GIFBASELOOP,GIFAAMODE=0,GIFAARESOLVE=GIFBASERESOL,PPMMODE=0;
char    gifname[MAXNCHAR];

extern int		gif_h, gif_w;
extern double	gif_n;

#else
int		GIFMODE=0;

#endif

struct timeval 	next_time;
jmp_buf	env;
int 	seq_no=0;
int		step_no=1, step_off=1, step_each=1, start_page=1, end_page=MAXPAGE, step_angle=15;
int		log2d_mode=0, log3d_mode=0, threed_mode=0, number2d_mode, number3d_mode=0;
char	plotrc[]=".tplotrc";
char    filtername[80]="filter_dump",fname[80],psname[MAXNCHAR];
char	line_style[9]={0,1,2,3,4,5,6,7,0};
char	gray_style[9]={0,1,2,3,4,5,6,7,0};

char	color_name[9][8]={"Black  ","Blue   ","Red    ","Magenta","Green  ",
						  "Cyan   ","Yellow ","White  ","Black  "};
char	line_name[9][14]={"Solid        ","Dot          ","Short Dash   ","Medium Dash  ",
				 		  "Long Dash    ","Broken       ","Double Broken","Solid        ",
				 		  "Solid        "};

#ifdef HP
static FILE 	*fpg;
#else
static int		FDIO;
#endif

static int next_ok=0,skip_ok=0,serial_no=0,counter_on,back_rgb[3];
static int 	argc0;
static char **argv0;

void error_end(char *s,int n)
{
	fprintf(stderr,"%s  !!! \n",s);
	if (n) {
#ifdef HP
		fclose(fpg);
#else
		close(FDIO);
#endif

		if (PSMODE || PSWRITE==2) postscriptend();
#ifdef GIF
		if (GIFMODE || GIFWRITE==2) giffileend(GRAPHNO);
#endif
		if (WINMODE) wpicdrawclosewindow();
	}
	BEEP();
	exit(1);
}

void set_displaymode(int ind)
{
	wpicdrawsetdisplaymode(&ind);
}

frames_colormap *create_colormap(int num)
{
	frames_colormap **frc,*fc;
	int i;
 
	fc=(frames_colormap*)malloc(sizeof(frames_colormap));
	if (fc==NULL) error_end("Memory is not enough for colormap",1);

	fc->num=num;
	if (num>0) {
		fc->cn=(int *)malloc(sizeof(int)*num);
		fc->csh=(double *)malloc(3*sizeof(double)*(num+1));
		if (fc->csh==NULL) error_end("Memory is not enough for colormap",1);
		fc->csl=&(fc->csh[num+1]);
		fc->css=&(fc->csl[num+1]);
	  }
	  else {
	  	fc->cn=(int *)malloc(sizeof(int));
		if (fc->cn==NULL) error_end("Memory is not enough for colormap",1);
	}
	if (CURCOLMAP>=MAXCOLMAP) {
		MAXCOLMAP+=ONECMAPP;
#ifdef TESTREALLOC
		frc=(frames_colormap **)realloc(FRCOLP,MAXCOLMAP*sizeof(frames_colormap *));
		if (frc==NULL) error_end("Memory is not enough for colormap",1);
		for (i=MAXCOLMAP-ONECMAPP;i<MAXCOLMAP;i++) frc[i]=NULL;
#else
		frc=(frames_colormap **)malloc(MAXCOLMAP*sizeof(frames_colormap *));
		if (frc==NULL) error_end("Memory is not enough for colormap",1);
		for (i=0;i<MAXCOLMAP-ONECMAPP;i++) frc[i]=FRCOLP[i];
		for (   ;i<MAXCOLMAP;i++) frc[i]=NULL;
		if (FRCOLP!=NULL) free(FRCOLP);
#endif
		FRCOLP=frc;
	}
	FRCOLP[CURCOLMAP++]=fc;
	return fc;
}

void recall_colormap(int cn)
{
	int i;
/*	printf("  %d %d\n",cn,FRCOLP[cn]->num);
	for (i=0;i<FRCOLP[cn]->num;i++) printf("%f %f %f %d\n",FRCOLP[cn]->csh[i],FRCOLP[cn]->csl[i],FRCOLP[cn]->css[i],FRCOLP[cn]->cn[i]);
	printf("%f %f %f\n",FRCOLP[cn]->csh[i],FRCOLP[cn]->csl[i],FRCOLP[cn]->css[i]);*/
	CURHLSTABLE=cn+1;
	fr_hlsset(FRCOLP[cn]->csh,FRCOLP[cn]->csl,FRCOLP[cn]->css,FRCOLP[cn]->cn,&(FRCOLP[cn]->num));
}

int get_current_tphlstable( )
{
	if (VERSION>=8) return CURHLSTABLE;
	return -2;
}

void clear_colormap(void)
{
	int i;

	if (FRCOLP!=NULL) {
		for (i=0;i<MAXCOLMAP && FRCOLP[i]!=NULL;i++) {
			free(FRCOLP[i]->cn);
			if (FRCOLP[i]->num>0) free(FRCOLP[i]->csh);
			free(FRCOLP[i]);
		}
		FRCOLP=NULL;	MAXCOLMAP=0;	CURCOLMAP=0;
	}
	FOFFHLS=0;
}

void initialize_page(void)
{
	DRAWED=0;	GRAPHSPEC=0;	SURFACEMODE=0;
}

void set_scale(double x1,double x2,double y1,double y2,double z1,double z2,int ind)
{
 	if (VERSION<5) {
		XTAN=(x2-x1)/XMAXBASE0;		X0=min(x1,x2);
		YTAN=(y2-y1)/XMAXBASE0;		Y0=min(y1,y2);
		if (ind==3) {
			ZTAN=(z2-z1)/XMAXBASE0;		Z0=min(z1,z2);
		}
	  }
	  else {
		XTAN=(x2-x1)/XMAXBASE;		X0=(x1+x2)/2;
		YTAN=(y2-y1)/XMAXBASE;		Y0=(y1+y2)/2;
		if (ind==3) {
			ZTAN=(z2-z1)/XMAXBASE;		Z0=(z1+z2)/2;
		}
	}
}

int check_ext(char *str1,char *str2,char *ext)
{
	int n=0,j=0,d=0,nj=0,nd=0;
	char c,*s=str2;

	while (1) {
		c=*str1;
		if (c!=' ' && c!='\t') break;
		str1++;
	}
	if (c<' ') return -1;

	while (c=(*str1++)) {
		if (c=='.') {  j=1;  nj=n;  }
		  else if (c=='/') {  d=1;  nd=n+1;  }
		(*str2++)=c;	n++;
	}

	if (j==0 || nd>nj) {
		(*str2++)='.';		nj=n;
		while (*ext) (*str2++)=*ext++;
	}
	*str2='\0';

	s[nj]='\0';
	strcpy(fname,&s[nd]);
	if (PSPIPE==0 && PSFILE<=0) {
		strcpy(psname,&s[nd]);
		PSFILE=-1;
	}

#ifdef GIF
	if (GIFFILE<=0) {
		strcpy(gifname,&s[nd]);
		GIFFILE=-1;
	}
#endif

	s[nj]='.';
	return 0;
}

static void reset_timecount(void)
{
	struct timeval r;

	if (MOVIESPEED>=30) {
		MSECINTVAL=0;	MOVIESPEED=30;
		return;
	  }
	  else {
	  	if (MOVIESPEED<1) MOVIESPEED=1;
		MSECINTVAL=INTERVALMAX/exp(MOVIESPEED*log(10.0)/10);
	}

	gettimeofday(&r, NULL);
	next_time.tv_sec = r.tv_sec+(MSECINTVAL/1000);
	next_time.tv_usec = r.tv_usec+(MSECINTVAL%1000)*1000;
	if (next_time.tv_usec >= 1000000) {
		next_time.tv_usec -= 1000000;
		next_time.tv_sec++;
    }
}

static int check_timecount(int n)
{
	struct timeval r;

	if (MSECINTVAL<=0) return 1;

	gettimeofday(&r, NULL);
	if (next_time.tv_sec<=r.tv_sec && next_time.tv_usec<=r.tv_usec) {
/*		if (n==0) {
			MSECINTVAL=0;
			return 1;
		}*/
		next_time.tv_sec = r.tv_sec+(MSECINTVAL/1000);
		next_time.tv_usec = r.tv_usec+(MSECINTVAL%1000)*1000;
		if (next_time.tv_usec >= 1000000) {
			next_time.tv_usec -= 1000000;
			next_time.tv_sec++;
    	}
		return 1;
	  }
	  else return 0;
}

void clear_scales(void)
{
	int i;

	for (i=0;i<MAXSCALENO;i++) {
		SCALE2DMODE[i]=SCALE3DMODE[i]=CONTOR2DMODE[i]=CONTOR3DMODE[i]=LOG2DMODE[i]=0;
		SC2DX1[i]=SC2DX2[i]=SC2DY1[i]=SC2DY2[i]=0;
		SC3DX1[i]=SC3DX2[i]=SC3DY1[i]=SC3DY2[i]=SC3DZ1[i]=SC3DZ2[i]=0;
	}
}

void clear_step(int mode)
{
	if (mode==0) {
		step_no=1;			start_page=1;
		step_each=1;		end_page=ENDPAGE;
		step_off=step_no;	SCALE2STEP=1;		CONTOR2STEP=1;
	  }
	  else {
		ENDPAGE=STARTPAGE+NOFPAGE;
		if (TGMODE) {
			GRAPHSTEP=GRAPHSTEP0;		step_no=GRAPHSTEP;
			GRAPHEACH=GRAPHEACH0;		step_each=GRAPHEACH;
			SCALE2STEP=SCALE2STEP0;
			CONTOR2STEP=CONTOR2STEP0;
			start_page=STARTPAGE+1;
			end_page=ENDPAGE;
			step_off=step_no-(start_page-1)%step_no;
		  }
		  else serial_no=0;
#ifdef GIF
		GIFSTEP=GIFSTEPNO;
#endif
	}
}

void set_app_initialize(int argc,char **argv)
{
	char   	str[MAXNCHAR];
	int		i,ind;
	FILE	*fp;

	GWIDTH=WINWIDTH;		GHEIGHT=WINHEIGHT;
	ind=WINRATE;			setwindowratio(&ind);

	ind=0;
	if ((fp=fopen(plotrc,"r"))!=NULL) ind=1;
	  else {
		sprintf(str,"%s/%s",getenv("HOME"),plotrc);
		if ((fp=fopen(str,"r"))!=NULL) ind=1;
	}

	if (ind) {
		while (fscanf(fp,"%s",str)!=EOF) {
			if (str[0]=='-') option_set(str,0);
		}
		fclose(fp);
	}

	*filename='\0';
	while (--argc>0) {
		if (**(++argv)!='-') {
			if (check_ext(*argv,filename,"plt")==0) break;
		   }
		  else option_set(*argv,0);
	}
	if (argc>1) {
		flistno=argc;		filelist=argv;
	}

	clear_scales();
	if (PREFFILE) {
		get_pref(prefname);
		PREFFILE=0;
	}
	
	argc0=argc;		argv0=argv;
	gwioratio(&GWRNUM,&GWRDEN,&GWIDTH,&GHEIGHT,&GXOFF,&GYOFF,&GWINFIX);

	GRAPHSTEP0=GRAPHSTEP;		GRAPHEACH0=GRAPHEACH;
	SCALE2STEP0=SCALE2STEP;		CONTOR2STEP0=CONTOR2STEP;
	if (GRAPHSTEP0<1) GRAPHSTEP0=1;
	if (GRAPHEACH0<1) GRAPHEACH0=1;
	if (SCALE2STEP0<1) SCALE2STEP0=1;
	if (CONTOR2STEP0<1) CONTOR2STEP0=1;
	if (GRAPHEACH0>=GRAPHSTEP0) GRAPHSTEP0=GRAPHEACH0=1;
	serial_no=0;
}

static void set_filep(off_t fpx)
{
	int i;
	off_t *fp0;

/*	NFILEP==GRAPHNO-1,  NFILEP0== no. of already stored	file points 	*/

	NFILEP++;
	if (NFILEP>=NFILEP0) {
		NFILEP0=NFILEP+1;
		if (NFILEP>=MAXFILEP) {
			MAXFILEP+=ONEFILEP;
#ifdef TESTREALLOC
			fp0=realloc(FILEP,MAXFILEP*sizeof(off_t));
#else
			fp0=malloc(MAXFILEP*sizeof(off_t));
			for (i=0;i<NFILEP;i++) fp0[i]=FILEP[i];
			free(FILEP);
#endif
			FILEP=fp0;
		}
		FILEP[NFILEP]=fpx;
	}
/*	printf(" set  %d %d %04x\n",NFILEP,NFILEP0,(int)FILEP[NFILEP]);		*/
}

int goto_filep(int mode,int nfp,int mg,int *err)
{
	int nf=NFILEP,gf=GRAPHNO;

/*	printf(" gogo %d %d %d %04x %d %d\n",NFILEP,nfp,NFILEP0,(int)FILEP[NFILEP],GRAPHNO,ENDPAGE);	*/
	if (skip_ok || next_ok) return 0xff;
	if (nfp<0 || nfp>=ENDPAGE) return 0;
	  else if (nfp>=NFILEP0) {
  		NFILEP=NFILEP0-1;  		seekfadr(NFILEP);
        *err=skip_frame_pages(nfp,10);
        if (*err==0xff) return 0xff;
        if (*err<=0) {
			if (mg==0) {
        		NFILEP=nf;		GRAPHNO=gf;
      			return 0;
			}
			seekfadr(NFILEP);
        }
  		return 1;
	  }
	  else if (mode && nfp==NFILEP) return 1;
	  else {
	  	NFILEP=nfp;
		seekfadr(NFILEP);
		return -1;
	}
}

void start_file(void)
{
	char b1[5],buf[1024],c1;
	static char b[4]={42,84,65,71};
	static char ver[3]={42,43,44};
	int i,bx,by,ox,oy,rn,rd;

	if (*filename=='\0') {
		/*	option_menu(filename,str);	*/
		fputs("Input Frames plt File Name  :> ",stderr);
		scanf("%s",buf);
		if (check_ext(buf,filename,"plt")){
			error_end("Invarid input file name !!!\n",0);
		}
/*		error_end("Specify at least 1 file name  --->  tplot filename\n   See help by tplot -?\n",0);
*/
	}

#ifdef HP
	if ((fpg=fopen(filename,"rb"))==NULL) 
					error_end("Cannot open this file",0);
#else
	if ((FDIO=open(filename,O_RDONLY))==-1) 
					error_end("Cannot open this file",0);
#endif

	if (FILEP==NULL) {
		FILEP=malloc(ONEFILEP*sizeof(off_t));
		MAXFILEP=ONEFILEP;
	}

	ENDFILE=0;
	FADR0=FADR1=0L;
	if (setjmp(env)) goto err;

	clear_step(1);

#ifndef BIGENDIAN
	getbyte(b1,5);
#else
	getbyte(b1,-5);
#endif
	for (i=0;i<4;i++) {
		if (b1[i]!=b[i]) goto err;
	}
	if (b1[4]==ver[2]) {
#ifndef BIGENDIAN
		getbyte(b1,2);
#else
		getbyte(b1,-2);
#endif
		VERSION=b1[0];
		if (b1[1]==2) {
			bx=getint();			by=getint();
			if (by==330) by=500;	/*testing			*/
			ox=getint()-GXOFF;		oy=getint()-GYOFF;
		  }
		  else if (b1[1]!=1) goto err;
		  else {
			bx=WINWIDTH;			by=WINHEIGHT;
			ox=-GXOFF;				oy=-GYOFF;
		}
		gwiosetwsize(&bx,&by,&ox,&oy,&rn,&rd,&GWINFIX);
		IGXOFF=-ox;		IGYOFF=-oy;
		if (VERSION>=5) {
			getbyte(&c1,1);
			if (c1>0) {
				step_no=c1;
				SCALE2STEP=step_no;	CONTOR2STEP=step_no;
#ifdef GIF
				if (GIFSTEPNO<=1) GIFSTEP=c1;
#endif
			}
			BWREVMODE=0;
			if (VERSION>=7) {
				getbyte(&c1,1);
				if (c1&1) BWREVMODE=1;
				if (c1&2) {
					back_rgb[0]=getint3();
					back_rgb[1]=getint3();
					back_rgb[2]=getint3();
/*					printf("%d %d %d\n",back_rgb[0],back_rgb[1],back_rgb[2]);	*/
				  }
				  else back_rgb[0]=-1;
				if (c1&4) CHARSIZE=getint()/((double)(BASECOLVAL));
					else  CHARSIZE=1;
#ifdef GIF
				GIFBWREVMODE=BWREVMODE;
#endif
			}
		}
	  }
	  else if (b1[4]==ver[1]) {
#ifndef BIGENDIAN
		getbyte(b1,1);
#else
		getbyte(b1,-1);
#endif
		if (b1[0]==2) {
			bx=getint();		by=getint();
			ox=getint();		oy=getint();
		  }
		  else if (b1[0]!=1) goto err;
		  else {
			bx=640;			by=480;
			ox=0;			oy=30;
		}
		gwiosetwsize(&bx,&by,&ox,&oy,&rn,&rd,&GWINFIX);
		VERSION=1;
	  }
	  else if (b1[4]==ver[0]) {
		bx=640;			by=480;
		ox=0;			oy=30;
		gwiosetwsize(&bx,&by,&ox,&oy,&rn,&rd,&GWINFIX);
		VERSION=0;
	  }
	  else goto err;

	GWIDTH=bx;		GHEIGHT=by;
	GXOFF=ox;		GYOFF=oy;
	GWRNUM=rn;		GWRDEN=rd;
#ifdef GIF
	if (GIFMODE || GIFWRITE==2) {
		giffileend(-1);
		GIFWRITE=1;		GIFNCLEAR=0;
	}
/*	printf("%f %d\n",gif_n,GIFWRITE);		*/
	if (gif_n==1) {
		gif_n=(double)GWRNUM/((double)GWRDEN);
	}
	gif_w=GWIDTH;		gif_h=GHEIGHT;
#endif

	NFILEP=-1;	NFILEP0=0;
	set_filep(FOFF+1);

	initialize_page();
	MAXCOLMAP=0;
	return;

err:
	error_end("This is not a plt file",0);
}

static void set_init(int ind)
{
	int n1,n2,n3,num,den;

	n1=WINMODE;		n2=PSMODE;		n3=GIFMODE;

	if (WINMODE) set_character_size(CHARSIZE);
	gwiomodes(&n1,&n2,&n3,&PSYOFF);
	if (WINMODE==1 && n1!=1) {
		fprintf(stderr,"Graphic Workstation not opened -- Skip Graphic Routines\n");
	}

	WINMODE=n1;
	if (WINMODE!=1) {
		WINMODE=0;		CLRSTOP=0;
	}
	if (DISPMODE==2 || page_switching) set_displaymode(1);

	if (ind && WINMODE) {
		get_windowsize(&WWIDTH,&WHEIGHT,&num,&den,&WRMODE);
		if (GWIDTH!=WWIDTH || GHEIGHT!=WHEIGHT) recreate_window(num,den);
	}
	if (WINMODE) set_basic_colormode(BWREVMODE, back_rgb);
	clear_colmap_table();
	n1=1;
	gwiodefaultsizes(&n1,&n1);


	if (PSMODE) {
		postscriptinit(GRAPHNO,PAPERDIR,PAPERSIZE,PLOTLMAX,PLOTRMAX,LMARG,BMARG,0);
		postscriptstyle(PSCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
	}

#ifdef GIF
	if (GIFMODE) {
		giffile_init(0);
		giffilestyle(GIFCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
	}
#endif
}

void set_frames_initialize(int ind)
{
	int n1;
	if (ind==0) {
		n1=9999;		gwiomodes(&n1,&n1,&n1,&PSYOFF);		/* Set init = 0		*/
		fr_ginit();
		LIGHTNSPEC=0;
		getlightsettings(&LIGHTALT,&LIGHTAZIM,&LIGHTAMB,&LIGHTDIFF,&LIGHTNSPEC);
	}

	ENDPAGE=STARTPAGE+NOFPAGE;
	if (STARTPAGE>0) skip_frame_pages(STARTPAGE,0);
	set_init(ind);

	start_page=STARTPAGE+1;
	end_page=ENDPAGE;
	counter_on=TGMODE;

	next_frame_main(0);
}

void get_next_file(void)
{

#ifdef HP
	fclose(fpg);
#else
	close(FDIO);
#endif
	start_file();
}

void quit_main(void)
{
	int		ind;

#ifdef HP
	fclose(fpg);
#else
	close(FDIO);
#endif

/*	if (PSMODE==1) {	*/
	if (WINMODE==0) {
		*filename='\0';		STARTPAGE=0;
  		while ((--argc0)>0) {
			if (**(++argv0)!='-') {
				if (check_ext(*argv0,filename,"plt")==0) break;
			  }
			  else option_set(*argv0,1);
		}
/*
		ENDPAGE=STARTPAGE+NOFPAGE;
		if (GRAPHEACH>=GRAPHSTEP) GRAPHSTEP=GRAPHEACH=1;
		serial_no=0;
*/
		if (*filename) {
			GRAPHNO=0;
			start_file();
			if (STARTPAGE>0) skip_frame_pages(STARTPAGE,0);
			set_init(1);
			next_frame_main(0);
			return;
		}
	}

	if (PSMODE || PSWRITE==2) postscriptend();
#ifdef GIF
	if (GIFMODE || GIFWRITE==2) giffileend(GRAPHNO);
#endif

/*    special for X 	*/
	if (CLRSTOP==0 && DISPMODE==0) {
		ind=103;
		gwiopause(&ind);
	}
	if (WINMODE) wpicdrawclosewindow();
	exit(0);
}

int hard_copy(int n)
{
	int c;
	char str[256];

	c=window_idnumber();
	if (c>0) {
		if (n==1) {
			sprintf(str,"hard_copy %d",c);
			if (system(str)!=0) {
				fprintf(stderr,"Prepare Script - \"hard_copy id\" \n");
				return 1;
			}
		  }
		 else {
		 	sprintf(str,"%s %d %04d %04d %s",filtername,c,GRAPHNO,++HARDNO,fname);
			if (system(str)!=0) {
				fprintf(stderr,"Prepare Script - \"%s id graphno copyno fname\" \n",filtername);
				return 1;
			}
		}
	}
	return 0;
}

int sequence_frame_main(int n)
{
	int ind,clr=CLRSTOP, psw=PSMODE, disp=DISPMODE, hard=HARDMODE;
	int n1,n2,n3,ns=step_no,nd, gifw=GIFMODE, gifan;

	if (seq_no) {
		seq_no++;
		return -1;
	}

	switch (n) {
		case 0:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=2;		HARDMODE=0;		n2=0;
					set_displaymode(1);
					seq_no++;
/*					next_frame_main(1);		*/
					reset_timecount();
			seq1:	while (1) {
						n1=0;
						while (check_timecount(n1)==0) n1++;
						if (step_each>1) {
							nd=(NFILEP+step_off-1)%step_no+1;
							if (nd<step_each) ns=1;
								else ns=step_no-nd+1;
						}
						if (NFILEP+ns>end_page) break;
						if (next_frame_main(ns)<=0) break;
						wpicdrawbufwaitflush();
						if (seq_no>1) break;
						n2++;
					}
					if (n2==0) {
						n2=((GRAPHNO-1)%step_no);
						goto_filep(0,n2,0,&n2);
						if (next_frame_main(1)>0) {
							wpicdrawbufwaitflush();
							n2=1;
							goto seq1;
						}
					}
					break;
		case 1:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=3;		HARDMODE=1;
					seq_no++;
					while (1) {
						if (hard_copy(1)) goto err;
						if (step_each>1) {
							nd=(NFILEP+step_off-1)%step_no+1;
							if (nd<step_each) ns=1;
								else ns=step_no-nd+1;
						}
						if (NFILEP+ns>end_page) break;
						if (next_frame_main(ns)<=0) break;
						wpicdrawbufwaitflush();
						if (seq_no>1) break;
					}
					break;
		case 2:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=4;		HARDMODE=2;
					seq_no++;
					while (1) {
						if (hard_copy(2)) goto err;
						if (step_each>1) {
							nd=(NFILEP+step_off-1)%step_no+1;
							if (nd<step_each) ns=1;
								else ns=step_no-nd+1;
						}
						if (NFILEP+ns>end_page) break;
						if (next_frame_main(ns)<=0) break;
   						wpicdrawbufwaitflush();
						if (seq_no>1) break;
					}
					break;
		case 3:		if (PSWRITE==0) return 1;
					CLRSTOP=1;		DISPMODE=0;		HARDMODE=0;		GIFMODE=0;
					if (PSWRITE==1) {
						postscriptinit(GRAPHNO,PAPERDIR,PAPERSIZE,PLOTLMAX,PLOTRMAX,LMARG,BMARG,0);
						postscriptstyle(PSCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
						PSWRITE=2;
					}
					PSMODE=2;
					n1=0;		n2=11;		n3=GIFMODE;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					gwioclearpage();
/*					seekfadr(NFILEP);	*/
					if (step_each>1) nd=(NFILEP+step_off-1)%step_no+1;
						else nd=step_each;
					if (nd<=step_each) next_frame_main(-1);
					while (1) {
						if (step_each>1) {
							nd=(NFILEP+step_off-1)%step_no+1;
							if (nd<step_each) ns=1;
								else ns=step_no-nd+1;
						}
						if (NFILEP+ns>end_page) break;
						if (next_frame_main(ns)<=0) break;
						if (seq_no>1) break;
					}
					n1=0;		n2=10;		n3=gifw;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					break;
#ifdef GIF
		case 4:
		case 5:		if (GIFWRITE==0) return 1;
					CLRSTOP=1;		DISPMODE=0;		HARDMODE=0;
					if (GIFWRITE==1) {
						giffile_init(0);
						giffilestyle(GIFCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
						GIFWRITE=2;
					}
					GIFMODE=2;		gifan=GIFANIME;		GIFANIME=n-4;
					n1=0;			n2=PSMODE;			n3=11;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
/*					gif_aamode_init();		*/
					gwioclearpage();
					gifframeclear();
/*					seekfadr(NFILEP);	*/
					if (step_each>1) nd=(NFILEP+step_off-1)%step_no+1;
						else nd=step_each;
					if (nd<=step_each) next_frame_main(-1);
					while (1) {
						if (step_each>1) {
							nd=(NFILEP+step_off-1)%step_no+1;
							if (nd<step_each) ns=1;
								else ns=step_no-nd+1;
						}
						if (NFILEP+ns>end_page) break;
						if (next_frame_main(ns)<=0) break;
						if (seq_no>1) break;
					}
					n1=0;		n2=psw;			n3=10;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					GIFANIME=gifan;
					break;
#endif
	}

	CLRSTOP=clr;		PSMODE=psw;		GIFMODE=gifw;
	DISPMODE=disp;		HARDMODE=hard;
	seq_no=0;
	return 0;

err:
	CLRSTOP=clr;		PSMODE=psw;
	DISPMODE=disp;		HARDMODE=hard;
	seq_no=0;
	return 1;
}

int rotate_frame_main(int n)
{
	int ind,clr=CLRSTOP, psw=PSMODE, disp=DISPMODE, hard=HARDMODE;
	int n1,n2,n3,ns=step_no,nd, gifw=GIFMODE, gifan;
	int angle,anglemin,anglemax;

	if (seq_no) {
		seq_no++;
		return -1;
	}
	SCALE3DMODE[NOWS]|=8;		REANGLE3D=0;
	angle=SC3DPH[NOWS];			anglemin=angle-360;			anglemax=angle+360;
	counter_on=0;

	switch (n) {
		case 0:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=2;		HARDMODE=0;
					set_displaymode(1);
					seq_no++;
/*					next_frame_main(1);		*/
					reset_timecount();
					SC3DPH[NOWS]=angle;
					while (1) {
						angle+=step_angle;
						next_frame_main(-1);
						wpicdrawbufwaitflush();
						if (seq_no>1) break;
						n1=0;
						while (check_timecount(n1)==0) n1++;
						if (angle>anglemax || angle<anglemin) break;
						SC3DPH[NOWS]=angle;
						if (SC3DPH[NOWS]> 180) SC3DPH[NOWS]-=360;
						if (SC3DPH[NOWS]<-180) SC3DPH[NOWS]+=360;
					}
					break;
		case 1:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=3;		HARDMODE=1;
					seq_no++;
					while (1) {
						next_frame_main(-1);
						if (next_frame_main(ns)<=0) break;
						wpicdrawbufwaitflush();
						if (seq_no>1) break;
						angle+=step_angle;
						if (angle>anglemax || angle<anglemin) break;
						SC3DPH[NOWS]=angle;
					}
					break;
		case 2:		CLRSTOP=1;		PSMODE=0;		GIFMODE=0;
					DISPMODE=4;		HARDMODE=2;
					seq_no++;
					while (1) {
						next_frame_main(-1);
						wpicdrawbufwaitflush();
						if (seq_no>1) break;
						angle+=step_angle;
						if (angle>anglemax || angle<anglemin) break;
						SC3DPH[NOWS]=angle;
					}
					break;
		case 3:		if (PSWRITE==0) return 1;
					CLRSTOP=1;		DISPMODE=0;		HARDMODE=0;		GIFMODE=0;
					if (PSWRITE==1) {
						postscriptinit(GRAPHNO,PAPERDIR,PAPERSIZE,PLOTLMAX,PLOTRMAX,LMARG,BMARG,0);
						postscriptstyle(PSCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
						PSWRITE=2;
					}
					PSMODE=2;
					n1=0;		n2=11;		n3=GIFMODE;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					gwioclearpage();
/*					seekfadr(NFILEP);	*/
					while (1) {
						next_frame_main(-1);
						if (seq_no>1) break;
						angle+=step_angle;
						if (angle>anglemax || angle<anglemin) break;
						SC3DPH[NOWS]=angle;
					}
					n1=0;		n2=10;		n3=gifw;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					break;
#ifdef GIF
		case 4:
		case 5:		if (GIFWRITE==0) return 1;
					CLRSTOP=1;		DISPMODE=0;		HARDMODE=0;
					if (GIFWRITE==1) {
						giffile_init(0);
						giffilestyle(GIFCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
						GIFWRITE=2;
					}
					GIFMODE=2;		gifan=GIFANIME;		GIFANIME=n-4;
					n1=0;			n2=PSMODE;			n3=11;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
/*					gif_aamode_init();		*/
					gwioclearpage();
					gifframeclear();
					while (1) {
						next_frame_main(-1);
						if (seq_no>1) break;
						angle+=step_angle;
						if (angle>anglemax || angle<anglemin) break;
						SC3DPH[NOWS]=angle;
					}
					n1=0;		n2=psw;			n3=10;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
					GIFANIME=gifan;
					break;
#endif
	}

	CLRSTOP=clr;		PSMODE=psw;		GIFMODE=gifw;
	DISPMODE=disp;		HARDMODE=hard;
	seq_no=0;
	counter_on=TGMODE;
	SC3DPH[NOWS]=((int)SC3DPH[NOWS])%360;
	return 0;
}

void color_exchange(int cmd)
{
	if (BWREVMODE!=cmd) {
		change_drawcolormode(cmd);
		BWREVMODE=cmd;
#ifdef GIF
		gifcolormode(cmd);
#endif
	}
}

int ps_output(void)
{
	int n1,n2,n3,gifw=GIFMODE;

	if (PSWRITE==0 || DRAWED==0) return 1;

	if (PSWRITE==1) {
		postscriptinit(GRAPHNO,PAPERDIR,PAPERSIZE,PLOTLMAX,PLOTRMAX,LMARG,BMARG,PSFMODE);
		postscriptstyle(PSCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
		PSWRITE=2;
	}
	PSMODE=2;		GIFMODE=0;
	n1=0;			n2=11;		n3=GIFMODE;		gwiomodes(&n1,&n2,&n3,&PSYOFF);

	xwindow_clear();
	next_frame_main(-1);

	PSMODE=0;		GIFMODE=gifw;
	n1=0;			n2=10;		n3=GIFMODE;		gwiomodes(&n1,&n2,&n3,&PSYOFF);

	return 0;
}

void ps_setting_proc(int pssize,int psfm,int pscol)
{
	int md=0;
	if (PSSIZEMODE!=pssize) {
		if (pssize==2) {
			PAPERDIR=1;		PLOTLMAX=1;		PLOTRMAX=1;		PSSIZEMODE=2;
		  }
		  else if (pssize==0) {
			PAPERDIR=1;		PLOTLMAX=2;		PLOTRMAX=2;		PSSIZEMODE=0;
		  }
		  else {
			PAPERDIR=0;		PLOTLMAX=2;		PLOTRMAX=1;		PSSIZEMODE=1;
		}
		md++;
	}
	if (PSFMODE!=psfm) {
		PSFMODE=psfm;
		md++;
	}
	if (PSCOLMODE!=pscol) {
		PSCOLMODE=pscol;
		md++;
	}
	if (md>0 && PSWRITE==2) postscriptend();
}

#ifdef GIF
int gif_output(void)
{
	int n1,n2,n3,psw=PSMODE;
	char outgiffilename[100];

	if (GIFWRITE==0 || DRAWED==0) return 1;

	if (GIFWRITE==1) {
		giffile_init(GIFNCLEAR);
		giffilestyle(GIFCOLMODE,line_style,gray_style,VECTORMODE,CHARMODE);
		GIFWRITE=2;		GIFNCLEAR=0;
	}
	GIFMODE=3;		PSMODE=0;
	n1=0;			n2=PSMODE;		n3=11;		gwiomodes(&n1,&n2,&n3,&PSYOFF);

/*	gif_aamode_init();		*/
	xwindow_clear();
	gifframeclear();
	next_frame_main(-1);

	GIFMODE=0;		PSMODE=psw;
	n1=0;			n2=PSMODE;		n3=10;		gwiomodes(&n1,&n2,&n3,&PSYOFF);
	if (PPMMODE) {
		giffileend(-1);
		PPMMODE=0;		GIFWRITE=1;		GIFNCLEAR=1;
	}

	return 0;
}

void gif_setting_proc(int gray,int trans,int inter,int delay,int loop,int aamode)
{
/*	if (bw!=GIFBWREVMODE) gifcolormode(bw);		*/
	if (gray!=GIFGRAYMODE) gifgraycolormode(gray);
	if (trans!=GIFSETB) giftransparentmode(trans);
	if (inter!=GIFSETI) gifinterlacemode(inter);
	if (delay!=GIFADELAY) gifdelaytiming(delay);
	if (loop!=GIFALOOP) gifloopcount(loop);
	if ((aamode&1)!=GIFAAMODE || (aamode>>1)!=GIFAARESOLVE) gif_setaamode(aamode&1,aamode>>1);
}
#endif

int scale_output(void)
{
	if (DRAWED==0) return 1;

	gwioclearpage();
	next_frame_main(-1);

	return 0;
}

int analyze_output(void)
{
	if (DRAWED==0) return 1;

	NANA_DATA=0;
	gwioclearpage();
	next_frame_main(-1);

	return 0;
}

int analyze_linear(double *x,double *y,int n,int ic,double xmin,double xmax,double *res
							,int ind)
{
/*
 	  line fit to ax+by=c
		res[0] ... x av
		res[1] ... y av
		res[2] ... x std
		res[3] ... y std
		res[4] ... xy std
		res[5] ... a
		res[6] ... b
		res[7] ... c
		res[8] ... d
		res[9] ... r
*/
	int i,n0,nn,cc;
	double a,b,c;
	double x0,y0,xa,ya,x2a,y2a,xya,sa,a1,b1,d1,d2;
	double dd1,dd2,xx[2],yy[2];
/*	double ym1,ym2;*/

	if (ic!=ANACOL) return -2;
	if (n<=1) return -1;

	xa=ya=x2a=y2a=xya=0;	n0=0;
	
	if (ind==0) {
		for (i=0; i<n; i++) {
			if (x[i]>=xmin && x[i]<=xmax) {
				xa += x[i];	  ya += y[i];
				n0++;
/*						  ym1=y[i];*/
			}
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;
/*		ym2=ym1;*/

		for (i=0; i<n; i++) {
			if (x[i]>=xmin && x[i]<=xmax) {
				x2a += (x[i]-xa)*(x[i]-xa);		y2a += (y[i]-ya)*(y[i]-ya);
				xya += (x[i]-xa)*(y[i]-ya);
/*				if (y[i]<ym1) ym1=y[i];
				if (y[i]>ym2) ym2=y[i];*/
			}
		}
	  }
	  else if (ind==1) {
	  	dd1=(x[1]-x[0])/(n-1);
		for (i=0; i<n-1; i++) {
			x0=x[0]+dd1*i;
			if (x0>=xmin && x0<=xmax) {
				xa += x0;	  ya += y[i];
				n0++;
			}
		}
		x0=x[1];	i=n-1;
		if (x0>=xmin && x0<=xmax) {
			xa += x0;	  ya += y[i];
			n0++;
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;

		for (i=0; i<n-1; i++) {
			x0=x[0]+dd1*i;
			if (x0>=xmin && x0<=xmax) {
				x2a += (x0-xa)*(x0-xa);		y2a += (y[i]-ya)*(y[i]-ya);
				xya += (x0-xa)*(y[i]-ya);
			}
		}
		x0=x[1];	i=n-1;
		if (x0>=xmin && x0<=xmax) {
			x2a += (x0-xa)*(x0-xa);		y2a += (y[i]-ya)*(y[i]-ya);
			xya += (x0-xa)*(y[i]-ya);
		}
	  }
	  else {
	  	dd1=(y[1]-y[0])/(n-1);
		for (i=0; i<n; i++) {
			y0=y[0]+dd1*i;
			if (x[i]>=xmin && x[i]<=xmax) {
				xa += x[i];	  ya += y0;
				n0++;
			}
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;

		for (i=0; i<n; i++) {
			y0=y[0]+dd1*i;
			if (x[i]>=xmin && x[i]<=xmax) {
				x2a += (x[i]-xa)*(x[i]-xa);		y2a += (y0-ya)*(y0-ya);
				xya += (x[i]-xa)*(y0-ya);
			}
		}
	}

	sa = x2a-y2a;
	d1 = sqrt(4*xya*xya+sa*sa);
	dd1 = (x2a+y2a)/2-d1/2;
	dd2 = (x2a+y2a)/2+d1/2;
	if (xya!=0) {
		d2 = sa/d1;
		a  = sqrt((1-d2)/2);
		b  = sqrt((1+d2)/2);
		if (xya>0) b=-b;
	  }
	  else {
		if (x2a>=y2a) {
			a=0;	b=1;
		  }
		  else {
			a=1;	b=0;
		}
	}

	c=a*xa+b*ya;
	if (fabs(a)<=MAXGRAD*fabs(b)) {
		a/=b;				c/=b;				b=1;
		xx[0]=xmin;			xx[1]=xmax;
		yy[0]=-a*xx[0]+c;	yy[1]=-a*xx[1]+c;
	  }
	  else {
		b/=a;				c/=a;				a=1;
		yy[0]=SC2DY1[NOWS];	yy[1]=SC2DY2[NOWS];
		xx[0]=-b*yy[0]+c;	xx[1]=-b*yy[1]+c;
	}
	res[0]=xa;					res[1]=ya;
	res[2]=sqrt(x2a/n0);		res[3]=sqrt(y2a/n0);		res[4]=xya/n0;
	res[5]=a;					res[6]=b;					res[7]=c;
	res[8]=sqrt(dd1)/n0;		res[9]=sqrt(dd1/dd2);
	nn=2;	cc=7;	ind=1;
	fr_graph2d(xx,yy,&nn,&cc,&ind);
/*	res[2]=ym1;res[3]=ym2;*/
	return n0;
}

#define MAXPOINTS		50
#define POLYORDER		8

static void regulate(double *a0,int n,double xa,double *x0)
{
	double p,dp,xx=xa,dx,ad[10];
	int i,j,it;

	for (i=0;i<n;i++) ad[i]=a0[i+1]*(i+1);
	for (it=0;it<100;it++) {
		p=ad[n-1];	dp=0;
		for (i=n-2;i>=0;i--) {
			dp=xx*dp+p;
			p=xx*p+ad[i];
		}
		dx=-p/dp;		xx+=dx;
		if (fabs(dx)<1.e-14) break;
	}

	for (i=n;i>=1;i--) {
		for (j=n-1;j>=n-i;j--) a0[j]+=a0[j+1]*xx;
	}
	*x0=xx;
}

static void compct(double *a,double *b,int n,int n1,double *y,double *det,int mata,int *kai)
{
	int i,j,k,imax,kh,ik,*ipivot,i1,n11=n1+1;
	double s,temp,quot,*ap,*bp;

	ipivot=(int*)malloc(sizeof(int)*n);

	if (mata<=0) {
		*det =1;
		for (k=0;k<n;k++) {
			temp =0;
			for (i=k;i<n;i++) {
				s =0;	i1=i*n1+k;	ap=&a[i*n1];	bp=&a[k];
				for (j=0;j<=k-1;j++,bp+=n1) s+=(*ap++)*(*bp);
				a[i1]-=s;
				if (fabs(a[i1])>temp) {
					temp =fabs(a[i1]);
					imax =i;
				}
			}
			ipivot[k]=imax;
			if (imax!=k) {
				*det =-(*det);
				for (j=0;j<n;j++) {
					temp =a[k*n1+j];
					a[k*n1+j]=a[imax*n1+j];
					a[imax*n1+j]=temp;
				}
				temp =b[k];		b[k]=b[imax];	b[imax]=temp;
			}
			if (a[k*n11]==0) {
				*kai =0;
				goto end;
			}

			quot =1/a[k*n11];
			for (i=k+1;i<n;i++) a[i*n1+k]*=quot;
			for (j=k+1;j<n;j++) {
				s =0;	ap=&a[k*n1];	bp=&a[j];
				for (kh=0;kh<=k-1;kh++,bp+=n1) s+=(*ap++)*(*bp);
				a[k*n1+j]-=s;
			}
			s =0;	ap=&a[k*n1];	bp=b;
			for (kh=0;kh<=k-1;kh++) s+=(*ap++)*(*bp++);
			b[k]-=s;
		}
	} else {
		for (k=0;k<n;k++) {
			ik =ipivot[k];
			temp =b[ik];	b[ik]=b[k];		b[k]=temp;
			s =0;	ap=&a[k*n1];	bp=b;
			for (kh=0;kh<=k-1;kh++) s+=(*ap++)*(*bp++);
			b[k]-=s;
		}
	}

	for (k=0;k<n;k++) {
		if (mata==0) *det *=a[k*n11];
		s =0;	ap=&a[(n-k-1)*n1+n-k];	bp=&y[n-k];
		for (kh=n-k;kh<n;kh++) s+=(*ap++)*(*bp++);
		y[n-k-1]=(b[n-k-1]-s)/a[(n-k-1)*n11];
	}
	*kai =1;

end:
	free(ipivot);
}

int analyze_poly(double *x,double *y,int n,int ic,double xmin,double xmax,double *res,int ind)
{
/*
 	  POLYORDER'th polynomial fit to ax+by=c
		res[0] ... x av
		res[1] ... y av
		res[2] ... x std
		res[3] ... y std
		res[4] ... xy std
		res[5] ... a0
		res[6] ... a1
		res[7] ... a2
		res[8] ... a3
		res[9] ... a4
*/
	int i,n0,nn,cc,j,k,kai,im;
	double a,b,c,d,om,g;
	double x0,y0,xa,ya,x2a,y2a,xya,sa,xd0;
	double dd1,dd2,xx[MAXPOINTS],yy[MAXPOINTS];
	double aa[POLYORDER+1][POLYORDER+1],bb[POLYORDER+1],dd[POLYORDER+1];
	double det,s,t;

	if (ic!=ANACOL) return -2;
	if (n<=1) return -1;

	xa=ya=x2a=y2a=xya=0;	n0=0;
	
	if (ind==0) {
		for (i=0; i<n; i++) {
			if (x[i]>=xmin && x[i]<=xmax) {
				xa += x[i];	  ya += y[i];
				n0++;
			}
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;

		for (i=0; i<n; i++) {
			if (x[i]>=xmin && x[i]<=xmax) {
				x2a += (x[i]-xa)*(x[i]-xa);		y2a += (y[i]-ya)*(y[i]-ya);
				xya += (x[i]-xa)*(y[i]-ya);
			}
		}
	  }
	  else if (ind==1) {
	  	dd1=(x[1]-x[0])/(n-1);
		for (i=0; i<n-1; i++) {
			x0=x[0]+dd1*i;
			if (x0>=xmin && x0<=xmax) {
				xa += x0;	  ya += y[i];
				n0++;
			}
		}
		x0=x[1];	i=n-1;
		if (x0>=xmin && x0<=xmax) {
			xa += x0;	  ya += y[i];
			n0++;
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;

		for (i=0; i<n-1; i++) {
			x0=x[0]+dd1*i;
			if (x0>=xmin && x0<=xmax) {
				x2a += (x0-xa)*(x0-xa);		y2a += (y[i]-ya)*(y[i]-ya);
				xya += (x0-xa)*(y[i]-ya);
			}
		}
		x0=x[1];	i=n-1;
		if (x0>=xmin && x0<=xmax) {
			x2a += (x0-xa)*(x0-xa);		y2a += (y[i]-ya)*(y[i]-ya);
			xya += (x0-xa)*(y[i]-ya);
		}
	  }
	  else {
	  	dd1=(y[1]-y[0])/(n-1);
		for (i=0; i<n; i++) {
			y0=y[0]+dd1*i;
			if (x[i]>=xmin && x[i]<=xmax) {
				xa += x[i];	  ya += y0;
				n0++;
			}
		}
		if (n0<=1) return -1;
		xa=xa/n0;	ya=ya/n0;

		for (i=0; i<n; i++) {
			y0=y[0]+dd1*i;
			if (x[i]>=xmin && x[i]<=xmax) {
				x2a += (x[i]-xa)*(x[i]-xa);		y2a += (y0-ya)*(y0-ya);
				xya += (x[i]-xa)*(y0-ya);
			}
		}
	}

	for (k=0;k<=POLYORDER;k++) {
		for (j=k;j<=POLYORDER;j++) {
			for (i=0,s=0; i<n; i++) {
				if (x[i]>=xmin && x[i]<=xmax) {
					s += pow(x[i]-xa,j+k);
				}
			}
			aa[k][j]=aa[j][k]=s;
		}
		for (i=0,t=0; i<n; i++) {
			if (x[i]>=xmin && x[i]<=xmax) {
#ifdef TT_SPECIAL_LOG
				t += pow(x[i]-xa,k)*pow(10.0,y[i]);
#else
				t += pow(x[i]-xa,k)*y[i];
#endif
			}
		}
		bb[k]=t;
	}
	
	compct((double*)aa,bb,POLYORDER+1,POLYORDER+1,dd,&det,0,&kai);
	for (i=0,im=-1;i<MAXPOINTS;i++) {
		xx[i]=xmin+i*(xmax-xmin)/(MAXPOINTS-1);
		yy[i]=0;
		for (j=POLYORDER;j>=0;j--) yy[i]=(xx[i]-xa)*yy[i]+dd[j];
		if (i>2) {
			if (yy[i]<yy[i-1] && yy[i-1]>yy[i-2]) im=i;
		}
	}

	if (im>0) {
		regulate(dd,POLYORDER,xx[im-1]-xa,&xd0);
#ifdef TT_SPECIAL2
		for (k=0;k<=POLYORDER;k++) {
			for (j=k;j<=POLYORDER;j++) {
				for (i=0,s=0; i<n; i++) {
					if (x[i]>=xmin && x[i]<=xmax) {
						s += pow(x[i]-xa-xd0,j+k)+pow(-(x[i]-xa-xd0),j+k);
					}
				}
				aa[k][j]=aa[j][k]=s;
			}
			for (i=0,t=0; i<n; i++) {
				if (x[i]>=xmin && x[i]<=xmax) {
					t += pow(x[i]-xa-xd0,k)*y[i]+pow(-(x[i]-xa-xd0),k)*y[i];
				}
			}
			bb[k]=t;
		}
		compct(aa,bb,POLYORDER+1,POLYORDER+1,dd,&det,0,&kai);
#endif
	  }
	  else xd0=0;

	for (i=0,im=-1;i<MAXPOINTS;i++) {
		xx[i]=xmin+i*(xmax-xmin)/(MAXPOINTS-1);
		yy[i]=0;
		for (j=POLYORDER;j>=0;j--) yy[i]=(xx[i]-xa-xd0)*yy[i]+dd[j];
#ifdef TT_SPECIAL_LOG
		yy[i]=log10(yy[i]);
#endif
	}

	nn=MAXPOINTS;	cc=7;	ind=1;
	fr_graph2d(xx,yy,&nn,&cc,&ind);

#ifdef TT_SPECIAL
	om=sqrt(-12*dd[4]/dd[2]);	b=dd[2]*dd[2]/(6*dd[4]);
	a=dd[0]-b;					g=-1.5*dd[3]/dd[2];
	d=xa+xd0+g/(om*om);
	for (i=0,im=-1;i<MAXPOINTS;i++) {
		xx[i]=xmin+i*(xmax-xmin)/(MAXPOINTS-1);
		yy[i]=a+b*exp(-g*(xx[i]-d))*cos(om*(xx[i]-d));
#ifdef TT_SPECIAL_LOG
		yy[i]=log10(yy[i]);
#endif
	}
	nn=MAXPOINTS;	cc=5;	ind=1;
	fr_graph2d(xx,yy,&nn,&cc,&ind);
#endif

	res[0]=xa;					res[1]=ya;
	res[2]=sqrt(x2a/n0);		res[3]=sqrt(y2a/n0);		res[4]=xa+xd0;
	res[5]=dd[0];				res[6]=dd[1];				res[7]=dd[2];
	res[8]=dd[3];				res[9]=dd[4];
	return n0;
}

int analyze_data(double *x,double *y,int n,int ic,double xmin,double xmax,double *res,
							int order,int ind)
{
	int ret;
	if (order==2) ret=analyze_poly(x,y,n,ic,xmin,xmax,res,ind);
		else ret=analyze_linear(x,y,n,ic,xmin,xmax,res,ind);
	return ret;
}

void sparse_dots(double *xx,double *yy,int *nn,double dd,int skip)
{
	char *box,*chk;
	int i,j,k,n=*nn,imax,jmax,dn;
	double xmin=*xx,ymin=*yy,xmax=*xx,ymax=*yy;

	if (skip>1) {
		for (i=j=0;i<n;i+=skip,j++) {
			xx[j]=xx[i];		yy[j]=yy[i];
		}
		*nn=j;
	}
	if (dd<=0) return;

	for (k=0;k<n;k++) {
		if (xx[k]<xmin) xmin=xx[k];
		if (xx[k]>xmax) xmax=xx[k];
		if (yy[k]<ymin) ymin=yy[k];
		if (yy[k]>ymax) ymax=yy[k];
	}
	imax=(xmax-xmin)/dd+1;	jmax=(ymax-ymin)/dd+1;

	box=(char*)calloc(imax*jmax,sizeof(char));
	if (box==NULL) return;
/*
	for (k=0;k<n;k++) {
		i=(xx[k]-xmin)/dd;
		j=(yy[k]-ymin)/dd;
		box[i+imax*j]=1;
	}
	for(dn=k=0;k<imax*jmax;k++) {
		if (box[k]) dn++;
	}
	dn=n/dn;

	if (dn>1) {
		printf("%d %d %d\n",imax,jmax,dn);
		for (i=j=0;i<n;i+=dn,j++) {
			xx[j]=xx[i];		yy[j]=yy[i];
		}
		*nn=j;
	}
	free(box);
*/
	chk=(char*)calloc(n,sizeof(char));
	if (chk==NULL) return;
	for (k=dn=0;k<n;k++) {
		i=(xx[k]-xmin)/dd;
		j=(yy[k]-ymin)/dd;
		if (box[i+imax*j]) chk[k]=1;
		  else {
			box[i+imax*j]=1;
			dn++;
		}
	}

	if (dn>1) {
/*		printf("%d %d %d\n",imax,jmax,dn);	*/
		for (i=j=0;i<n;i++) {
			if (chk[i]==0) {
				xx[j]=xx[i];		yy[j]=yy[i];
				j++;
			}
		}
		*nn=j;
	}
	free(box);	free(chk);
}

void clear_settings(void)
{
	double x=0;

	CIRCRAD=1;		ARROWLEN=1;		ARROWHEAD=1;	LINELIMIT=0;
	SETTINGMODE=0;
	COLORSEL=0x7f;	CLIP2DMODE=CLIP3DMODE=PROJ3DMODE=D3XYZMODE=REANGLE3D=0;
	settingsinput(&x,&x,&x,&x,&SETTINGMODE);
/*	LIGHTNSPEC=-1;
	getlightsettings(&LIGHTALT,&LIGHTAZIM,&LIGHTAMB,&LIGHTDIFF,&LIGHTNSPEC);	*/
}

void settings_input(void)
{
	settingsinput(&ARROWLEN,&ARROWHEAD,&CIRCRAD,&LINELIMIT,&SETTINGMODE);
}

int next_frame_page(signed char *cmd,int tmd,int skip)
{
	signed 	char c1;
	char   	chx[MAXNCHAR],chy[MAXNCHAR],chz[MAXNCHAR],*p;
	int		i,j,nx,ny,nz,show,iprof,nn[3];
	int		ind,ic,n,ix1,ix2,iy1,iy2,iz1,iz2,ic1,icc[50];
	off_t	fpoff;
	double 	x1,x2,y1,y2,z1,z2,r1,xx[3],yy[3],zz[3],ph,th,ff[50];
	static 	double 	xx1,xx2,yy1,yy2;
	static 	double nxmin,nxmax,nymin,nymax,fiso,*fisop=NULL;
	static 	int npr=0,niso=0,ngra=0,maxiso=0;
#ifdef TEMPORAL
	static 	int ixmin,ixmax,iymin,iymax;
#endif
	static	frames_colormap *fc=NULL;

	GRAPHNO=NFILEP+1;
	if (skip==0) {
		NOWS=NFILEP%SCALE2STEP;
		NOWC=NFILEP%CONTOR2STEP;
	}
	if (tmd) set_counter();
	NGSERIAL=0;

/*	while (1) {*/
next:
		fpoff=FOFF+1;		getbyte(&c1,1);
		/*		printf("b:%d %x %x %x\n",c1,(int)FOFF,(int)FADR0,(int)FADR1);	*/
		switch (c1/10) {
		  case 0:
		  	switch (c1) {
			  case FRAMES_VIEW2D:
				ix1=getint();			iy1=getint();
				ix2=getint();			iy2=getint();
				fr_view2d(&ix1,&iy1,&ix2,&iy2);
				goto next;

			  case FRAMES_FRAME2D:
				DRAWED++;	GRAPHSPEC=FRAME_2D;
				getbyte(&c1,1);			ind=c1;
				if (VERSION>=5) {
#ifdef TT_OLD
					c1=0;
#else
					getbyte(&c1,1);
#endif
					log2d_mode=c1%8;		number2d_mode=c1/8;
				  }
				  else {
				  	log2d_mode=0;		number2d_mode=0;
				}

				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				set_scale(x1,x2,y1,y2,z1,z2,2);
				if (skip) goto frame2;
				if (NOWS>=0) {
					if (SCALE2DMODE[NOWS]==0) {
						SC2DX1[NOWS]=x1;		SC2DX2[NOWS]=x2;
						SC2DY1[NOWS]=y1;		SC2DY2[NOWS]=y2;
						nxmin=x1;				nxmax=x2;
						nymin=y1;				nymax=y2;
						LOG2DMODE[NOWS]=log2d_mode;
#ifdef TEMPORAL
						ixmin=ixmax=iymin=iymax=0;
#endif
					  }
#ifdef SCALE_KEEP
					  else if (SCALE2DMODE[NOWS]&16) {
						x1=SC2DX1[NOWS];		x2=SC2DX2[NOWS];
						y1=SC2DY1[NOWS];		y2=SC2DY2[NOWS];
					  }
					  else {
						if (SCALE2DMODE[NOWS]&1) {
							x1=SC2DX1[NOWS];		x2=SC2DX2[NOWS];
						}
						if (SCALE2DMODE[NOWS]&2) {
							y1=SC2DY1[NOWS];		y2=SC2DY2[NOWS];
						}
#else
					  else {
						if (SCALE2DMODE[NOWS]&1) {
							x1=SC2DX1[NOWS];		x2=SC2DX2[NOWS];
						  }
						  else {
							SC2DX1[NOWS]=x1;		SC2DX2[NOWS]=x2;
							LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfe)|(log2d_mode&1);
						}
						if (SCALE2DMODE[NOWS]&2) {
							y1=SC2DY1[NOWS];		y2=SC2DY2[NOWS];
						  }
						  else {
							SC2DY1[NOWS]=y1;		SC2DY2[NOWS]=y2;
							LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfd)|(log2d_mode&2);
						}
#endif
					}
				}
				ix1=LOG2DMODE[NOWS]+10*number2d_mode;
				fr_setaxis(&ix1);
#ifdef TT_TEMPO_FRAME
				if (ind==2) ind=0;
					else if (ind==12) ind=10;
#endif
				if (SETTINGMODE&16) {
					ix1=CLIP2DMODE;
					if (CLIP2DMODE>1) ix1=1;
					ind=ix1*10+(ind%10);
				  }
				  else CLIP2DMODE=ind/10;
/*		CLIP2DMODE=1;			ind=CLIP2DMODE*10+(ind%10);*/
			frame2:
				fr_frame2d(&x1,&x2,&y1,&y2,&ind);
#ifdef CLIP2DX
				if (CLIP2DMODE==2) {
					ind=2;
					gwiochangeclip(&ind);
				}
#endif
				xx1=x1;		xx2=x2;
				yy1=y1;		yy2=y2;
				goto next;

			  case FRAMES_XYNAME:
				DRAWED++;
				nx=getint();		ny=getint();
#ifndef BIGENDIAN
				getbyte(chx,nx);	getbyte(chy,ny);
#else
				getbyte(chx,-nx);	getbyte(chy,-ny);
#endif
				chx[nx]='\0';		chy[ny]='\0';
				fr_xyname(chx,chy);
				goto next;
			  case FRAMES_GRAPH2D:
			/*		DRAWED++;	GRAPHSPEC=GRAPH_2D;		*/
				DRAWED++;	GRAPHSPEC|=GRAPH_2D;
				if (VERSION==0) {	getbyte(&c1,1);		ind=c1;	 }
					else		ind=getint();
				ix1=abs(ind/100);
				ic=getint();		getbyte(&n,4);
				ic1=ic%10;
				if (ANACOL==0 && ic1>0 && ic1<=7) ANACOL=ic1;
				if (skip) show=0;
				  else if (ic1>0 && ic1<=7) {
					COLORNOW|=(1<<(ic1-1));
					show=(1<<(ic1-1))&COLORSEL;
				  }
				  else show=0x100;
				if (ix1==0) {
					if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
					get8byte(X,Y,n,1);
#ifdef TT_GRAPH_LOG
					for (i=0,ny=0;i<n;i++) {
						if (X[i]>0) {
							if (Y[i]>0) {
								X[ny]=log10(sqrt(1+X[i]*X[i])-1);
								Y[ny]=log10(Y[i]);
								ny++;
							}
						}
					}
					n=ny;
#endif
					if (show) {
						if (SCALE2DMODE[NOWS]&1) {
							if ((LOG2DMODE[NOWS]&1)==0 && (log2d_mode&1)) {
								for (i=0;i<n;i++) X[i]=pow(10.0,X[i]);
							  }
							  else if ((LOG2DMODE[NOWS]&1) && (log2d_mode&1)==0) {
								for (i=0;i<n;i++) {
									if (X[i]<LOGMIN) X[i]=LOGMIN;
									X[i]=log10(X[i]);
								}
							}
						}
						if (SCALE2DMODE[NOWS]&2) {
							if ((LOG2DMODE[NOWS]&2)==0 && (log2d_mode&2)) {
								for (i=0;i<n;i++) Y[i]=pow(10.0,Y[i]);
							  }
							  else if ((LOG2DMODE[NOWS]&2) && (log2d_mode&2)==0) {
								for (i=0;i<n;i++) {
									if (Y[i]<LOGMIN) Y[i]=LOGMIN;
									Y[i]=log10(Y[i]);
								}
							}
						}
						if (SETTINGMODE&128 && ind==2 && (DOTSKIP>1 || DOTRESOLVE>0)) {
							sparse_dots(X,Y,&n,DOTRESOLVE,DOTSKIP);
						}
						if (SETTINGMODE&128 && ind==2 && DOTRESOLVE<0) {
							ind=3;		x1=-DOTRESOLVE;		fr_setcircle(&x1);
						}
						NGSERIAL++;
#ifdef EXTRA_2
						nx=(NGSERIAL-1)%11+1;
						printf("%d %lf\n",nx,Y[100]);
						if (nx>4) {
							ic=nx-4;
							if (nx==6) {
								for (i=0;i<n;i++) Y[i]/=2;
							  }
							  else if (nx == 11) {
								for (i=0;i<n;i++) Y[i]+=0.5;
							}
						}
#endif
						fr_graph2d(X,Y,&n,&ic,&ind);
#ifdef EXTRA_1
		for (x1=y1=0,x2=(X[1]-X[0])/2,i=0;i<n;i++) {
			z1=pow(10.0,Y[i]);	x1+=z1;	y1+=(X[i]+x2)*z1;
			if (ic==-4 && z1>1e-6) printf("%lf %lf\n",X[i],z1);
		}
		printf("Sum = %lf,  Average = %lf,  Color = %d   Numb = %d\n",x1,y1/x1,ic,n);
#endif
						if (ANALYZEMODE) {
							nx=analyze_data(X,Y,n,ic,ANA2DX1,ANA2DX2,ANA_DATA,ANAORDER,0);
							if (nx>0) NANA_DATA=nx;
						}
					}
				  }
				  else {
					get8byte(&x1,&y1,1,0);
					xx[0]=x1;	xx[1]=y1;
					if (n>NXALLOC) alloc_data(n,1);
				  	if (ix1==2) {
						get8byte(X,Y,n,5);
						if (show) {
							if (SCALE2DMODE[NOWS]&1) {
								if ((LOG2DMODE[NOWS]&1)==0 && (log2d_mode&1)) {
									for (i=0;i<n;i++) X[i]=pow(10.0,X[i]);
								  }
								  else if ((LOG2DMODE[NOWS]&1) && (log2d_mode&1)==0) {
									for (i=0;i<n;i++) {
										if (X[i]<LOGMIN) X[i]=LOGMIN;
										X[i]=log10(X[i]);
									}
								}
							}
							fr_graph2d(X,xx,&n,&ic,&ind);
							if (ANALYZEMODE) {
								nx=analyze_data(X,xx,n,ic,ANA2DX1,ANA2DX2,ANA_DATA,ANAORDER,2);
								if (nx>0) NANA_DATA=nx;
							}
						}
				  	  }
					  else {
						get8byte(Y,X,n,6);
						if (show) {
							if (SCALE2DMODE[NOWS]&2) {
								if ((LOG2DMODE[NOWS]&2)==0 && (log2d_mode&2)) {
									for (i=0;i<n;i++) X[i]=pow(10.0,X[i]);
								  }
								  else if ((LOG2DMODE[NOWS]&2) && (log2d_mode&2)==0) {
									for (i=0;i<n;i++) {
										if (X[i]<LOGMIN) X[i]=LOGMIN;
										X[i]=log10(X[i]);
									}
								}
							}
							fr_graph2d(xx,X,&n,&ic,&ind);
							if (ANALYZEMODE) {
								nx=analyze_data(xx,X,n,ic,ANA2DX1,ANA2DX2,ANA_DATA,ANAORDER,1);
								if (nx>0) NANA_DATA=nx;
							}
						}
					}
				}
				goto next;
			  case FRAMES_DRAW2D:
				DRAWED++;
				getbyte(&c1,1);		ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,1);
				if (show) {
					if (SCALE2DMODE[NOWS]&1) {
						if ((LOG2DMODE[NOWS]&1)==0 && (log2d_mode&1)) {
							x1=pow(10.0,x1);
						  }
						  else if ((LOG2DMODE[NOWS]&1) && (log2d_mode&1)==0) {
							if (x1<LOGMIN) x1=LOGMIN;
							x1=log10(x1);
						}
					}
					if (SCALE2DMODE[NOWS]&2) {
						if ((LOG2DMODE[NOWS]&2)==0 && (log2d_mode&2)) {
							y1=pow(10.0,y1);
						  }
						  else if ((LOG2DMODE[NOWS]&2) && (log2d_mode&2)==0) {
							if (y1<LOGMIN) y1=LOGMIN;
							y1=log10(y1);
						}
					}
					fr_draw2d(&x1,&y1,&ic,&ind);
				}
				goto next;
			  case FRAMES_VECTOR2D:
				DRAWED++;
				getbyte(&c1,1);			ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,1);
				get8byte(&x2,&y2,1,2);
				if (show) {
					if (SCALE2DMODE[NOWS]&1) {
						if ((LOG2DMODE[NOWS]&1)==0 && (log2d_mode&1)) {
							x1=pow(10.0,x1);
						  }
						  else if ((LOG2DMODE[NOWS]&1) && (log2d_mode&1)==0) {
							if (x1<LOGMIN) x1=LOGMIN;
							x1=log10(x1);
						}
					}
					if (SCALE2DMODE[NOWS]&2) {
						if ((LOG2DMODE[NOWS]&2)==0 && (log2d_mode&2)) {
							y1=pow(10.0,y1);
						  }
						  else if ((LOG2DMODE[NOWS]&2) && (log2d_mode&2)==0) {
							if (y1<LOGMIN) y1=LOGMIN;
							y1=log10(y1);
						}
					}
					fr_vector2d(&x1,&y1,&x2,&y2,&ic,&ind);
				}
				goto next;
			  case FRAMES_ASPECT2D:
				getbyte(&c1,1);			ind=c1;
				y1=getddouble1();		x1=1;
				fr_aspect2d(&x1,&y1,&ind);
				goto next;
			  case FRAMES_2DPOLYGON:
				DRAWED++;
				getbyte(&c1,1);		ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&n,4);
				if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
				get8byte(X,Y,n,2);
				if (show) fr_2dpolygon(X,Y,&n,&ic,&ind);
				goto next;
			}
		   	goto error;

		  case 1:
		  case 3:
			switch (c1) {
			  case FRAMES_CONTOUR:
				DRAWED++;	GRAPHSPEC=CONTOR_2D;
				ic=getint();			ind=getint();
				show=0;
				if (skip==0) {
					if (ic%100>0 && ic%100<=7) {
						COLORNOW|=(1<<(ic%100-1));
						if ((1<<(ic%100-1))&COLORSEL) show=1;
					  }
					  else show=1;
					show<<=1;
					if (ic/100>0 && ic/100<=7) {
						COLORNOW|=(1<<(ic/100-1));
						if ((1<<(ic/100-1))&COLORSEL) show|=1;
					}
				}
				getbyte(&ix2,4);		getbyte(&iy2,4);
				n=ix2*iy2;
				if (VERSION>=3) {
					get8byte(&x1,&x2,1,0);
					get8byte(&y1,&y2,1,0);
					ix1=1;
					setregionxydim(&x1,&x2,&y1,&y2,&ix1);
				}
				if (show && ind>0) {
					if (C256MODE<0) ic=-2;
						else if (C256MODE>0) {
							ind=C256MODE;
							if (CONTCOLOR<0) ic=-1;
								else 		 ic=CONTCOLOR&0xff;
					}
					if (CONTOR2DMODE[NOWC]) {
						if ((CONTOR2DMODE[NOWC]&2)==2) {
							iy1=2;
							fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iy1);
						  } 
						  else if ((CONTOR2DMODE[NOWC]&1)==1) {
							iy1=1;
							fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iy1);
						}
						if (CONTOR2DMODE[NOWC]&4) {
							ind=CTRDND[NOWC];
							if (ind<0) {
								ic=ind;
								ind=1;
							  }
//							  else if (ic==-2) ic=-1;
						}
					}
				}
#ifdef TEMPORAL
/* The following scaling works only for integer coordinates */
				if (show && SCALE2DMODE[NOWS]!=0) {
					if (SCALE2DMODE[NOWS]&16) {
						nx=SC2DX1[NOWS]-nxmin+1;		ix1=SC2DX2[NOWS]-nxmin+1;
						ny=SC2DY1[NOWS]-nymin+1;		iy1=SC2DY2[NOWS]-nymin+1;
						if (ixmin>1) {  nx+=ixmin-1;  ix1+=ixmin-1;  }
						if (iymin>1) {  ny+=iymin-1;  iy1+=iymin-1;  }
					  }
					  else {
						if (SCALE2DMODE[NOWS]&1) {
							nx=SC2DX1[NOWS]-nxmin+1;		ix1=SC2DX2[NOWS]-nxmin+1;
							if (ixmin>1) {  nx+=ixmin-1;  ix1+=ixmin-1;  }
						  }
						  else nx=0;
						if (SCALE2DMODE[NOWS]&2) {
							ny=SC2DY1[NOWS]-nymin+1;		iy1=SC2DY2[NOWS]-nymin+1;
							if (iymin>1) {  ny+=iymin-1;  iy1+=iymin-1;  }
						  }
						  else ny=0;
					}
					fr_set2drgn(&nx,&ix1,&ny,&iy1);
					fprintf(stderr,"%d %d %d %d %d\n",nx,ny,ix1,iy1,SCALE2DMODE[NOWS]);
				}
#endif
				if (show) {
					if (n>NXALLOC) alloc_data(n,1);
					get8byte(X,Y,n,4);
					if (SCALE2DMODE[NOWS]!=0) {
						nx=-1;
						setregion2dim(&ix2,&iy2,&nx);
					}
					fr_contour(X,&ix2,&iy2,&ind,&ic);
					if (ind>0 && CONTOR2DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
					}
				  }
				  else {
					seek8byte(n,4);
				}
				goto next;
			  case FRAMES_SETCONTOUR:
				ind=getint();
				if (VERSION<2) {
					if (ind<5) get8byte(&x1,&x2,1,0);
				  }
				  else {
					if (ind>0 && ind<5) get8byte(&x1,&x2,1,0);
				}
				fr_setcontour(&x1,&x2,&ind);
				goto next;
			  case FRAMES_LOGAXIS:
				DRAWED++;
				getbyte(&c1,1);			ind=c1;
				if (skip) goto next;
			  	log2d_mode=(ind&3)|8;
				if (((SCALE2DMODE[NOWS]&1) && (LOG2DMODE[NOWS]&1)!=(log2d_mode&1)) ||
						((SCALE2DMODE[NOWS]&2) && (LOG2DMODE[NOWS]&2)!=(log2d_mode&2))) {
					ind=92;
					fr_frame2d(&xx1,&xx2,&yy1,&yy2,&ind);
					if ((SCALE2DMODE[NOWS]&1)==0) LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfe)|(log2d_mode&1);
					if ((SCALE2DMODE[NOWS]&2)==0) LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfd)|(log2d_mode&2);
					ind=LOG2DMODE[NOWS];
					fr_logaxis(&ind);
				  }
				  else {
				  	fr_logaxis(&ind);
				  	LOG2DMODE[NOWS]=log2d_mode&3;
				}
				goto next;
			  case FRAMES_COLORBAR:
				DRAWED++;
				if (VERSION<3) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (VERSION<9) ind/=10;
				ix1=getint();			iy1=getint();
				ix2=getint();			iy2=getint();
				fr_colorbar(&ix1,&iy1,&ix2,&iy2,&ind);
				goto next;
			  case FRAMES_TRICONTOUR:
				DRAWED++;	GRAPHSPEC=CONTOR_2D;
				ic=getint();		ix1=getint();		ind=getint();
				show=0;
				if (skip==0) {
					if (ic%100>0 && ic%100<=7) {
						COLORNOW|=(1<<(ic%100-1));
						if ((1<<(ic%100-1))&COLORSEL) show=1;
					  }
					  else show=1;
					show<<=1;
					if (ic/100>0 && ic/100<=7) {
						COLORNOW|=(1<<(ic/100-1));
						if ((1<<(ic/100-1))&COLORSEL) show|=1;
					}
					if (ix1>0 && ix1<=7) {
						COLORNOW|=(1<<(ix1-1));
						if (((1<<(ix1-1))&COLORSEL)==0) ix1=0;
					}
				}
				getbyte(&nx,4);		getbyte(&ny,4);
				if (nx>NXALLOC || nx>NYALLOC || nx>NZALLOC) alloc_data(nx,3);
				get8byte(X,Y,nx,1);		get8byte(Z,Y,nx,4);
				WS=malloc(ny*3*sizeof(int));
				if (WS==NULL) 
					error_end("Memory is not enough for allocation",1);
				if (nx<256) 				ix2=1;
					else if (nx<65536)		ix2=2;
					else if (nx<16777216) 	ix2=3;
					else 					ix2=4;
				for (i=0;i<ny*3;i++) WS[i]=getnint(ix2);
				if (show) {
					if (C256MODE<0) ic=-2;
						else if (C256MODE>0) {
							ind=C256MODE;
							if (CONTCOLOR<0) {	ic=-1; 	ix1=-CONTCOLOR/256;	}
								else 		 {	ic=CONTCOLOR&0xff; 	ix1=CONTCOLOR/256;	}
					}
					if (CONTOR2DMODE[NOWC]) {
						if ((CONTOR2DMODE[NOWC]&2)==2) {
							iy1=2;
							fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iy1);
						  }
						  else if ((CONTOR2DMODE[NOWC]&1)==1) {
							iy1=1;
							fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iy1);
						}
						if (CONTOR2DMODE[NOWC]&4) {
							ind=CTRDND[NOWC];
							if (ind<0) {
								ic=ind;
								ind=1;
							  }
//							  else if (ic==-2) ic=-1;
						}
					}
					fr_tricontour(X,Y,Z,&nx,WS,&ny,&ind,&ic,&ix1);
					if (CONTOR2DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
					}
				}
				free(WS);
				goto next;
			  case FRAMES_SQRCONTOUR:
				DRAWED++;	GRAPHSPEC=CONTOR_2D;
				ic=getint();			ix1=getint();		ind=getint();
				show=0;
				if (skip==0) {
					if (ic%100>0 && ic%100<=7) {
						COLORNOW|=(1<<(ic%100-1));
						if ((1<<(ic%100-1))&COLORSEL) show=1;
					  }
					  else show=1;
					show<<=1;
					if (ic/100>0 && ic/100<=7) {
						COLORNOW|=(1<<(ic/100-1));
						if ((1<<(ic/100-1))&COLORSEL) show|=1;
					}
					if (ix1>0 && ix1<=7) {
						COLORNOW|=(1<<(ix1-1));
						if (((1<<(ix1-1))&COLORSEL)==0) ix1=0;
					}
				}
				getbyte(&ix2,4);		getbyte(&iy2,4);
				nx=ix2*iy2;
				if (nx>NXALLOC || nx>NYALLOC || nx>NZALLOC) alloc_data(nx,3);
				get8byte(X,Y,nx,1);		get8byte(Z,Y,nx,4);
				if (show) {
					if (C256MODE<0) ic=-2;
						else if (C256MODE>0) {
							ind=C256MODE;
							if (CONTCOLOR<0) {	ic=-1; 	ix1=-CONTCOLOR/256;	}
								else 		 {	ic=CONTCOLOR&0xff; 	ix1=CONTCOLOR/256;	}
					}
					if (CONTOR2DMODE[NOWC]) {
						if ((CONTOR2DMODE[NOWC]&2)==2) {
							iy1=2;
							fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iy1);
						  } 
						  else if ((CONTOR2DMODE[NOWC]&1)==1) {
							iy1=1;
							fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iy1);
						}
						if (CONTOR2DMODE[NOWC]&4) {
							ind=CTRDND[NOWC];
							if (ind<0) {
								ic=ind;
								ind=1;
							  }
//							  else if (ic==-2) ic=-1;
						}
					}
					fr_sqrcontour(X,Y,Z,&ix2,&iy2,&ind,&ic,&ix1);
					if (CONTOR2DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
					}
				}
				goto next;

			  case FRAMES_PMVIEW:
				threed_mode=0;
				ix1=getint();			iy1=getint();
				ix2=getint();			iy2=getint();
				iz1=getint();			iz2=getint();
				fr_pmview(&ix1,&iy1,&ix2,&iy2,&iz1,&iz2);
				goto next;
			  case FRAMES_PMFRAME:
				threed_mode=0;
				DRAWED++;	GRAPHSPEC=FRAME_3D;
				getbyte(&c1,1);			ind=c1;
				if (VERSION>=5) {
#ifdef TT_OLD
					c1=0;
#else
					getbyte(&c1,1);
#endif
					log3d_mode=c1%8;		number3d_mode=c1/8;
				  }
				  else {
				  	log3d_mode=0;		number3d_mode=0;
				}

				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				set_scale(x1,x2,y1,y2,z1,z2,3);
				if (skip) goto next;
				if (NOWS>=0) {
					if (SCALE3DMODE[NOWS]==0) {
						SC3DX1[NOWS]=x1;		SC3DX2[NOWS]=x2;
						SC3DY1[NOWS]=y1;		SC3DY2[NOWS]=y2;
						SC3DZ1[NOWS]=z1;		SC3DZ2[NOWS]=z2;
						nxmin=x1;		nxmax=x2;
						nymin=y1;		nymax=y2;
#ifdef TEMPORAL
						ixmin=ixmax=iymin=iymax=0;
#endif
					  }
#ifdef SCALE_KEEP
					  else if (SCALE3DMODE[NOWS]&16) {
						x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
						y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
						z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
					  }
#endif
					  else {
					  	if (SCALE3DMODE[NOWS]&1) {
							x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
						  }
						  else {
							SC3DX1[NOWS]=x1;		SC3DX2[NOWS]=x2;
						}
						if (SCALE3DMODE[NOWS]&2) {
							y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
						  }
						  else {
							SC3DY1[NOWS]=y1;		SC3DY2[NOWS]=y2;
						}
					  	if (SCALE3DMODE[NOWS]&4) {
							z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
						  }
						  else {
							SC3DZ1[NOWS]=z1;		SC3DZ2[NOWS]=z2;
						}
					}
				}
				ix1=log3d_mode+10*number3d_mode;
				fr_setaxis(&ix1);
				fr_pmframe(&x1,&x2,&y1,&y2,&z1,&z2,&ind);
				goto next;

			  case FRAMES_XYZNAME:
				DRAWED++;
				nx=getint();		ny=getint();		nz=getint();
#ifndef BIGENDIAN
				getbyte(chx,nx);	getbyte(chy,ny);	getbyte(chz,nz);
#else
				getbyte(chx,-nx);	getbyte(chy,-ny);	getbyte(chz,-nz);
#endif
				chx[nx]='\0';		chy[ny]='\0';		chz[nz]='\0';
				fr_xyzname(chx,chy,chz);
				goto next;
			  case FRAMES_PMGRAPH:
				DRAWED++;
				if (VERSION==0) {	getbyte(&c1,1);		ind=c1;	 }
					else		ind=getint();
				ix1=abs(ind/100);	ix2=ind%100;
				ic=getint();		getbyte(&n,4);
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				nz=ix2/10;
				if (nz) {
					if (ix1==0) {
						if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
						get38byte(X,Y,Z,n,1);
						if (show) fr_pmgraph(X,Y,Z,&n,&ic,&ind);
					  }
					  else {
						if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
						get8byte(&x1,&y1,1,0);
						xx[0]=x1;	xx[1]=y1;
					  	if (ix1==2) {
							get38byte(X,Z,Y,n,6);
							if (show) fr_pmgraph(X,xx,Y,&n,&ic,&ind);
						  }
						  else {
							get38byte(Z,X,Y,n,5);
							if (show) fr_pmgraph(xx,X,Y,&n,&ic,&ind);
						}
					}
				 }
				 else {
					get38byte(&z1,&z1,&z1,1,0);
					if (ix1==0) {
						if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
						get8byte(X,Y,n,1);
						if (show) fr_pmgraph(X,Y,&z1,&n,&ic,&ind);
					  }
					  else {
						if (n>NXALLOC) alloc_data(n,1);
						get8byte(&x1,&y1,1,0);
						xx[0]=x1;	xx[1]=y1;
					  	if (ix1==2) {
							get8byte(X,Y,n,5);
							if (show) fr_pmgraph(X,xx,&z1,&n,&ic,&ind);
						  }
						  else {
							get8byte(Y,X,n,6);
							if (show) fr_pmgraph(xx,X,&z1,&n,&ic,&ind);
						}
					}
				}
				goto next;
			  case FRAMES_PMDRAW:
				DRAWED++;
				getbyte(&c1,1);		ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,1);
				if (show) fr_pmdraw(&x1,&y1,&ic,&ind);
				goto next;
			}
			goto error;

		  case 4:
		  case 5:
			switch (c1) {
			  case FRAMES_PMSET:
				get38byte(&z1,&z1,&z1,1,0);
				fr_pmset(&z1);
				goto next;
			  case FRAMES_HCLEAR:
				getbyte(&c1,1);		ind=c1;
				fr_hclear(&ind);
				goto next;

			  case FRAMES_PROFILE:
				DRAWED++;
				if (VERSION<8) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				if (ic<0) {  GRAPHSPEC=CONTOR_3D;	SURFACEMODE=-1;  }
				  else if (ind>4) SURFACEMODE=1;
				if (LIGHTINGMODE&4) ic=SURFACECOLOR+(ic/100)*100;
					else if (ind%10>4 && ic>0 && ic<=7) SURFACECOLOR=ic;
					else SURFACECOLOR=-1;
				getbyte(&ix2,4);		getbyte(&iy2,4);
				n=ix2*iy2;
				if (VERSION>=3) {
					get8byte(&x1,&x2,1,0);
					get8byte(&y1,&y2,1,0);
					ix1=2;
					setregionxydim(&x1,&x2,&y1,&y2,&ix1);
				}
#ifdef TEMPORAL
/* The following scaling works only for integer coordinates */
				if (skip==0 && SCALE3DMODE[NOWS]!=0) {
					if (SCALE3DMODE[NOWS]&16) {
						nx=SC3DX1[NOWS]-nxmin+1;		ix1=SC3DX2[NOWS]-nxmin+1;
						ny=SC3DY1[NOWS]-nymin+1;		iy1=SC3DY2[NOWS]-nymin+1;
						if (ixmin>1) {  nx+=ixmin-1;  ix1+=ixmin-1;  }
						if (iymin>1) {  ny+=iymin-1;  iy1+=iymin-1;  }
					  }
					  else {
						if (SCALE3DMODE[NOWS]&1) {
							nx=SC3DX1[NOWS]-nxmin+1;		ix1=SC3DX2[NOWS]-nxmin+1;
							if (ixmin>1) {  nx+=ixmin-1;  ix1+=ixmin-1;  }
						  }
						  else nx=0;
						if (SCALE3DMODE[NOWS]&2) {
							ny=SC3DY1[NOWS]-nymin+1;		iy1=SC3DY2[NOWS]-nymin+1;
							if (iymin>1) {  ny+=iymin-1;  iy1+=iymin-1;  }
						  }
						  else ny=0;
					}
					fr_set2drgn(&nx,&ix1,&ny,&iy1);
					fprintf(stderr,"%d %d %d %d %d\n",nx,ny,ix1,iy1,SCALE3DMODE[NOWS]);
				}
#endif
				if (show) {
					if (iprof==0) {
						if (n>NXALLOC) alloc_data(n,1);
						get8byte(X,Y,n,4);
					  }
					  else {
						if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
						get8byte(X,Z,n,4);
						get8byte(Y,Z,n,4);
						if (ic<0) {
							if (CONTOR3DMODE[NOWC]) {
								if ((CONTOR3DMODE[NOWC]&2)==2) {
									iz1=2;
									fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iz1);
								  } 
								  else if ((CONTOR3DMODE[NOWC]&1)==1) {
									iz1=1;
									fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iz1);
								}
								if (CONTOR3DMODE[NOWC]&4) {
									iz1=CTRDND[NOWC];
									if (iz1<0) {
										ic=iz1;
									  }
//									  else if (ic<=-2) ic=-1;
								}
							}
						}
					}
#if defined(PROF2CONT)
					gwioclearpage();
					x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
					y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];	ind=0;
					fr_frame2d(&x1,&x2,&y1,&y2,&ind);
					x1=SC3DZ1[NOWS];		x2=SC3DZ2[NOWS];	ind=2;
					fr_setcontour(&x1,&x2,&ind);
					ic=-2;		ind=20;
					fr_contour(X,&ix2,&iy2,&ind,&ic);
#elif defined(PROF23D)
					if (SCALE3DMODE[NOWS]!=0) {
						nx=0;
						setregion3dim(&ix2,&iy2,&iz2,&nx);
					}
					xx[0]=240;		xx[1]=-60;
					yy[0]=yy[1]=0.5;
					zz[0]=zz[1]=1;
					nx=128;			ind=1;
					fr_hlsset(xx,yy,zz,&nx,&ind);
					x1=0;	x2=0.1;		ind=2;
					fr_setcontour(&x1,&x2,&ind);
					if (n>NYALLOC || n>NZALLOC) alloc_data(n,4);
					ind=706;	ic=-2;
					if (show) fr_surface(Y,Z,X,&ix2,&iy2,&ic,&ind);
#else
					if (SCALE3DMODE[NOWS]!=0) {
						nx=0;
						setregion3dim(&ix2,&iy2,&iz2,&nx);
					}
/*					xx[0]=240;		xx[1]=-60;
					yy[0]=yy[1]=0.5;
					zz[0]=zz[1]=1;
					nx=128;			ind=1;
					fr_hlsset(xx,yy,zz,&nx,&ind);
					x1=0;	x2=0.1;		ind=2;
					fr_setcontour(&x1,&x2,&ind);
					ind=5;		ic=-2;
*/
					if (iprof==0) fr_profile(X,&ix2,&iy2,&ic,&ind);
						else	  fr_mapprofile(X,Y,&ix2,&iy2,&ic,&ind);
#endif
					if (CONTOR3DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
						CTRDDIM[NOWC]=0;
					}
				  }
				  else {
					seek8byte(n,4);
					if (iprof) seek8byte(n,4);
				}
				goto next;
			  case FRAMES_SURFACE:
				DRAWED++;
				if (VERSION<3) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				ic=getint();
				nx=-1;		ic1=ic%100;
				ix2=abs(ind/100);		iy2=(ind-1)%10+1;
				if (ic1<0) {
					GRAPHSPEC=CONTOR_3D;	SURFACEMODE=-1;
				  }
				  else if (iy2>4) SURFACEMODE=1;
				  else if (ic/100==0) nx=0;
				if (skip) show=0;
				  else if (ic1>0 && ic1<=7) {
					COLORNOW|=(1<<(ic1-1));
					show=(1<<(ic1-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&ix1,4);		getbyte(&iy1,4);
				n=ix1*iy1;
				if (D3MODE) iy2=4;
				if (LIGHTINGMODE&4) ic=SURFACECOLOR+(ic/100)*100;
					else if (ind%10>4 && ic1>0 && ic1<=7) SURFACECOLOR=ic1;
					else SURFACECOLOR=-1;
				if (iprof) {
					F=(double *)malloc(n*sizeof(double));
					get8byte(F,Z,n,4);
					iy2=3;
					if (ic1<0) {
						if (show) {
							if (CONTOR3DMODE[NOWC]) {
								if ((CONTOR3DMODE[NOWC]&2)==2) {
									iz1=2;
									fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iz1);
								  } 
								  else if ((CONTOR3DMODE[NOWC]&1)==1) {
									iz1=1;
									fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iz1);
								}
								if (CONTOR3DMODE[NOWC]&4) {
									iz1=CTRDND[NOWC];
									if (iz1<0) {
										ic=iz1;
									  }
//									  else if (ic==-2) ic=-1;
								}
							}
						}
					}
				}
				if (iy2<3) {
					if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
					get38byte(X,Y,Z,n,1);
					if (show) fr_surface(X,Y,Z,&ix1,&iy1,&ic,&ind);
				  }
				  else {
					if (ix2==0) {
						if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
						get38byte(X,Y,Z,n,1);
						if (show) {
							if (iprof==0) fr_surface(X,Y,Z,&ix1,&iy1,&ic,&ind);
							  else {
								fr_mapsurface(X,Y,Z,F,&ix1,&iy1,&ic,&ind);
								free(F);
							}
						}
					  }
					  else if (ix2==7) {
						get8byte(&x1,&x2,1,0);
						get8byte(&y1,&y2,1,0);
						ix2=2;
						setregionxydim(&x1,&x2,&y1,&y2,&ix2);
						if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
						get38byte(Y,Y,X,n,0);
						if (show) fr_surface(Y,Z,X,&ix1,&iy1,&ic,&ind);
					  }
					  else if (ix2==3 || ix2==5 || ix2==6) {
						if (n>NXALLOC) alloc_data(n,1);
						get8byte(xx,yy,3,2);
						if (ix2==3) {
							get38byte(Y,Y,X,n,0);
							if (show) fr_surface(xx,yy,X,&ix1,&iy1,&ic,&ind);
						  }
						  else if (ix2==5) {
							get8byte(Y,X,n,6);
							if (show) fr_surface(xx,X,yy,&ix1,&iy1,&ic,&ind);
						  }
						  else {
							get8byte(X,Y,n,5);
							if (show) fr_surface(X,xx,yy,&ix1,&iy1,&ic,&ind);
						  }
					  }
					  else {
						if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
						get8byte(xx,yy,3,3);
					  	if (ix2==1) {
							get38byte(Z,X,Y,n,5);
							if (show) fr_surface(xx,X,Y,&ix1,&iy1,&ic,&ind);
						  }
						  else if (ix2==2) {
							get38byte(X,Z,Y,n,6);
							if (show) fr_surface(X,xx,Y,&ix1,&iy1,&ic,&ind);
						  }
						  else {
							get38byte(X,Y,Z,n,7);
							if (show) fr_surface(X,Y,xx,&ix1,&iy1,&ic,&ind);
						}
					}
				}
				if (show) {
					if (CONTOR3DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
						CTRDDIM[NOWC]=0;
					}
				}
				goto next;
			}
		   	goto error;

		  case 6:
		  case 7:
			switch (c1) {
			  case FRAMES_VIEW3D:
				threed_mode=1;
				ix1=getint();			iy1=getint();
				ix2=getint();			iy2=getint();
				fr_view3d(&ix1,&iy1,&ix2,&iy2);
				goto next;
			  case FRAMES_ANGLE3D:
				threed_mode=1;
				get8byte(&th,&ph,1,0);
				if (skip==0 && SCALE3DMODE[NOWS]==0) {
					SC3DPH[NOWS]=ph;		SC3DTH[NOWS]=th;
				}
				fr_angle3d(&th,&ph);
				goto next;
			  case FRAMES_ASPECT3D:
				threed_mode=1;
				getbyte(&c1,1);			ind=c1;
				get8byte(&y1,&z1,1,0);
				x1=1;
				fr_aspect3d(&x1,&y1,&z1,&ind);
				goto next;
			  case FRAMES_ROTATE:
				threed_mode=1;
				DRAWED++;	GRAPHSPEC=FRAME_3D;
				getbyte(&c1,1);			ind=c1;
				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				r1=getddouble1();
				set_scale(x1,x2,y1,y2,z1,z2,3);
				get8byte(&th,&ph,1,0);
				if (skip) goto next;
				if (SCALE3DMODE[NOWS]==0) {
					SC3DX1[NOWS]=x1;		SC3DX2[NOWS]=x2;
					SC3DY1[NOWS]=y1;		SC3DY2[NOWS]=y2;
					SC3DZ1[NOWS]=z1;		SC3DZ2[NOWS]=z2;
					nxmin=x1;			nxmax=x2;
					nymin=y1;			nymax=y2;
#ifdef TEMPORAL
					ixmin=ixmax=iymin=iymax=0;
#endif
				  }
#ifdef SCALE_KEEP
				  else if (SCALE3DMODE[NOWS]&16) {
					x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
					y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
					z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
				  }
#endif
				  else {
					if (SCALE3DMODE[NOWS]&1) {
						x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
					}
					if (SCALE3DMODE[NOWS]&2) {
						y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
					}
					if (SCALE3DMODE[NOWS]&4) {
						z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
					}
				}
				setrotateratio(&x1,&x2,&y1,&y2,&z1,&z2,&r1);
				if (SCALE3DMODE[NOWS]==0) {
					SC3DPH[NOWS]=ph;		SC3DTH[NOWS]=th;
				  }
				  else if (SCALE3DMODE[NOWS]&16) {
					ph=SC3DPH[NOWS];		th=SC3DTH[NOWS];
				  }
				  else {
				  	if (SCALE3DMODE[NOWS]&8) {
						ph=SC3DPH[NOWS];		th=SC3DTH[NOWS];
					}
				}
				if (SETTINGMODE&32) {
					ind=CLIP3DMODE*10+(ind%10);
				  }
				  else CLIP3DMODE=ind/10;
				fr_rotate(&th,&ph,&ind);
				goto next;
			  case FRAMES_FRAME3D:
				DRAWED++;	GRAPHSPEC=FRAME_3D;
				getbyte(&c1,1);			ind=c1;
				if (VERSION>=5) {
#ifdef TT_OLD
					c1=0;
#else
					getbyte(&c1,1);
#endif
					log3d_mode=c1%8;		number3d_mode=c1/8;
				  }
				  else {
				  	log3d_mode=0;		number3d_mode=0;
				}
				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				set_scale(x1,x2,y1,y2,z1,z2,3);
				if (skip) goto next;
				if (SCALE3DMODE[NOWS]==0) {
					SC3DX1[NOWS]=x1;		SC3DX2[NOWS]=x2;
					SC3DY1[NOWS]=y1;		SC3DY2[NOWS]=y2;
					SC3DZ1[NOWS]=z1;		SC3DZ2[NOWS]=z2;
					nxmin=x1;			nxmax=x2;
					nymin=y1;			nymax=y2;
#ifdef TEMPORAL
					ixmin=ixmax=iymin=iymax=0;
#endif
				  }
#ifdef SCALE_KEEP
				  else if (SCALE3DMODE[NOWS]&16) {
					x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
					y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
					z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
				  }
#endif
				  else {
				  	if (SCALE3DMODE[NOWS]&1) {
						x1=SC3DX1[NOWS];		x2=SC3DX2[NOWS];
					}
				  	if (SCALE3DMODE[NOWS]&2) {
						y1=SC3DY1[NOWS];		y2=SC3DY2[NOWS];
					}
				  	if (SCALE3DMODE[NOWS]&4) {
						z1=SC3DZ1[NOWS];		z2=SC3DZ2[NOWS];
					}
				}
				if (SETTINGMODE&32) {
					ind=CLIP3DMODE*10+(ind%10);
				  }
				  else CLIP3DMODE=ind/10;
				ix1=log3d_mode+10*number3d_mode;
				fr_setaxis(&ix1);
				if ((SCALE3DMODE[NOWS]&16) || (SCALE3DMODE[NOWS]&8)) {
					if (REANGLE3D) {
						ph=SC3DPH[NOWS];		th=SC3DTH[NOWS];
						fr_angle3d(&th,&ph);
						fr_frame3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);
					  }
					  else {
						n=10001;
						fr_frame3d(&x1,&x2,&y1,&y2,&z1,&z2,&n);
						ph=SC3DPH[NOWS];		th=SC3DTH[NOWS];
						fr_rotate(&th,&ph,&ind);
					}
				  }
				  else fr_frame3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);
				goto next;
			  case FRAMES_GRAPH3D:
				DRAWED++;
				if (VERSION==0) {	getbyte(&c1,1);		ind=c1;	 }
					else		ind=getint();
				ix1=abs(ind/100);
				if (ind==-13) {
					getbyte(&n,4);
					WS=malloc(n*sizeof(int));
					if (WS==NULL) error_end("Memory is not enough for allocation",1);
					for (i=0;i<n;i++) {  getbyte(&c1,1);	WS[i]=c1;	}
				  }
				  else {
					ic=getint();		getbyte(&n,4);
				}
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				if (ix1==0) {
					if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
					get38byte(X,Y,Z,n,1);
					if (show) {
						if (ind==-13) {
							fr_graph3d(X,Y,Z,&n,WS,&ind);
							free(WS);
						  }
						  else fr_graph3d(X,Y,Z,&n,&ic,&ind);
					}
				  }
				  else if (ix1==3 || ix1==5 || ix1==6) {
					if (n>NXALLOC) alloc_data(n,1);
					get8byte(&x1,&y1,1,0);
					xx[0]=x1;	xx[1]=y1;
					get8byte(&x1,&y1,1,0);
					yy[0]=x1;	yy[1]=y1;
					if (ix1==3) {
						get38byte(Y,Y,X,n,0);
						if (show) fr_graph3d(xx,yy,X,&n,&ic,&ind);
					  }
					  else if (ix1==5) {
						get8byte(Y,X,n,6);
						if (show) fr_graph3d(xx,X,yy,&n,&ic,&ind);
					  }
					  else {
						get8byte(X,Y,n,5);
						if (show) fr_graph3d(X,xx,yy,&n,&ic,&ind);
					  }
				  }
				  else {
					if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
					get8byte(&x1,&y1,1,0);
					xx[0]=x1;	xx[1]=y1;
				  	if (ix1==1) {
						get38byte(Z,X,Y,n,5);
						if (show) fr_graph3d(xx,X,Y,&n,&ic,&ind);
					  }
					  else if (ix1==2) {
						get38byte(X,Z,Y,n,6);
						if (show) fr_graph3d(X,xx,Y,&n,&ic,&ind);
					  }
					  else {
						get38byte(X,Y,Z,n,7);
						if (show) fr_graph3d(X,Y,xx,&n,&ic,&ind);
					}
				}
				goto next;
			  case FRAMES_DRAW3D:
				DRAWED++;
				getbyte(&c1,1);		ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get38byte(&x1,&y1,&z1,1,1);
				if (show) fr_draw3d(&x1,&y1,&z1,&ic,&ind);
				goto next;
			  case FRAMES_VECTOR3D:
				DRAWED++;
				getbyte(&c1,1);		ind=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get38byte(&x1,&y1,&z1,1,1);
				get38byte(&x2,&y2,&z2,1,2);
				if (show) fr_vector3d(&x1,&y1,&z1,&x2,&y2,&z2,&ic,&ind);
				goto next;
			  case FRAMES_PROJECT:
				getbyte(&c1,1);		ind=c1;
				z1=getdouble1();
				if (SETTINGMODE&64) {
					ind=PROJ3DMODE;
					if (ind) z1=5;
					ind+=10*D3XYZMODE;
				  }
				  else {
				  	PROJ3DMODE=ind%10;
				  	D3XYZMODE=ind/10;
				}
				fr_project(&z1,&ind);
				goto next;
			  case FRAMES_SLICES:
				DRAWED++;	GRAPHSPEC=CONTOR_3D;
				iz1=getint();		ic=getint();			ind=getint();
				if (VERSION<8) {
					nn[0]=iz1/100;		iz1=iz1%100;
					if (nn[0]<0) nn[0]=1;
				  }
				  else {
				  	nn[0]=getint();		nn[1]=getint();		nn[2]=getint();
				}
				show=0;
				if (skip==0) {
					if (ic%100>0 && ic%100<=7) {
						COLORNOW|=(1<<(ic%100-1));
						if ((1<<(ic%100-1))&COLORSEL) show=1;
					  }
					  else show=1;
					show<<=1;
					if (ic/100>0 && ic/100<=7) {
						COLORNOW|=(1<<(ic/100-1));
						if ((1<<(ic/100-1))&COLORSEL) show|=1;
					}
				}
				getbyte(&ix2,4);		getbyte(&iy2,4);
				if (VERSION>=3) {
					getbyte(&iz2,4);
					n=ix2*iy2*iz2;
					get8byte(&x1,&x2,1,0);
					get8byte(&y1,&y2,1,0);
					get8byte(&z1,&z2,1,0);
					ix1=1;
					setregionxyzdim(&x1,&x2,&y1,&y2,&z1,&z2,&ix1);
				  }
				  else {
					iz2=1;
					n=ix2*iy2;
				}
				if (VERSION<5) {
					if (n>NXALLOC) alloc_data(n,1);
					get8byte(X,Y,n,4);
					if (VERSION>=3 || iz1/10==0) xx[0]=getddouble1();
				  }
				  else if (VERSION<8) xx[0]=getddouble1();
				  else {
				  	xx[0]=getddouble1();	xx[1]=getddouble1();	xx[2]=getddouble1();
				}
				if (show) {
					if (VERSION>=5) {
						if (n>NXALLOC) alloc_data(n,1);
						get8byte(X,Y,n,4);
					}
					if (C256MODE<0) ic=-2;
						else if (C256MODE>0) {
							ind=C256MODE;
							if (CONTCOLOR<0) ic=-1;
								else ic=CONTCOLOR&0xff;
					}
					if (CONTOR3DMODE[NOWC]) {
						if ((CONTOR3DMODE[NOWC]&2)==2) {
							iy1=2;
							fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iy1);
						  } 
						  else if ((CONTOR3DMODE[NOWC]&1)==1) {
							iy1=1;
							fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iy1);
						}
						if (CONTOR3DMODE[NOWC]&4) {
							ind=CTRDND[NOWC];
							if (ind<0) {
								ic=ind;
								ind=1;
							  }
//							  else if (ic==-2) ic=-1;
						}
						if (CONTOR3DMODE[NOWC]&8) {
							xx[0]=CTRDT0[NOWC];
							if (CTRDDIM[NOWC]<10) {
								nn[0]=CTRDNUM[NOWC];			iz1=CTRDDIM[NOWC];
							}
						}
						if (CONTOR3DMODE[NOWC]&16) nn[0]=CTRDNUM[NOWC];
					}
					if (SCALE3DMODE[NOWS]!=0) {
						nx=1;
						setregion3dim(&ix2,&iy2,&iz2,&nx);
					}
					if (VERSION<8) fr_contour3d(X,&ix2,&iy2,&iz2,xx,&ind,&ic,&iz1);
						else 	  fr_slices(X,&ix2,&iy2,&iz2,xx,nn,&ind,&ic,&iz1);

					if (ind>0 && CONTOR3DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
						CTRDNUM[NOWC]=nn[0];	iz1%=10;
						if (ix2==1) 		 iz1=10;
							else if (iy2==1) iz1=20;
							else if (iz2==1) iz1=30;
							else if (iz1>3)  {
								iz1=1;	ix1=ix2;
								if (iy2>ix1) {	iz1=2;	ix1=iy2;	}
								if (iz2>ix1) iz1=3;
							}
							else if (iz1<1)  {
								iz1=1;	ix1=ix2;
								if (iy2<ix1) {	iz1=2;	ix1=iy2;	}
								if (iz2<ix1) iz1=3;
							}
						CTRDT0[NOWC]=xx[0];		CTRDDIM[NOWC]=iz1;
					}
				  }
				  else if (VERSION>=5) {
					seek8byte(n,4);
				}
				goto next;
			  case FRAMES_TRISURFACE:
				DRAWED++;
				if (VERSION<9) {
					getbyte(&c1,1);		ind=c1;
				  }
				  else ind=getint();
				ic=getint();
				if (VERSION<7) {
					if (ic<0) {
						if (ic>-100) {
							ic=-ic;		ind=5;
						  }
						  else {
							ic=-2;		ind=5;
						}
					}
				}
				if (ind>=10000) {
					iprof=1;		ind-=10000;
				  }
				  else iprof=0;
				nz=-1;		ic1=ic%100;
				if (ic1<0) {  GRAPHSPEC=CONTOR_3D;	SURFACEMODE=-1;  }
				  else if (ind>4) SURFACEMODE=1;
				  else if (ic/100==0) nz=0;
				if (skip) show=0;
				  else if (ic1>0 && ic1<=7) {
					COLORNOW|=(1<<(ic1-1));
					show=(1<<(ic1-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&nx,4);		getbyte(&ny,4);
				if (nx>NXALLOC || nx>NYALLOC || nx>NZALLOC) alloc_data(nx,3);
				get38byte(X,Y,Z,nx,1);
				if (D3MODE) ind=4;
				if (LIGHTINGMODE&4) ic=SURFACECOLOR+(ic/100)*100;
					else if (ind>4 && ic1>0 && ic1<=7) SURFACECOLOR=ic1;
					else SURFACECOLOR=-1;
				if (iprof) {
					F=(double *)malloc(nx*sizeof(double));
					get8byte(F,Z,nx,4);
					iy2=3;
					if (ic1<0) {
						if (show) {
							if (CONTOR3DMODE[NOWC]) {
								if ((CONTOR3DMODE[NOWC]&2)==2) {
									iz1=2;
									fr_setcontour(&CTRDF1[NOWC],&CTRDF2[NOWC],&iz1);
								  } 
								  else if ((CONTOR3DMODE[NOWC]&1)==1) {
									iz1=1;
									fr_setcontour(&CTRDF1[NOWC],&CTRDDF[NOWC],&iz1);
								}
								if (CONTOR3DMODE[NOWC]&4) {
									iz1=CTRDND[NOWC];
									if (iz1<0) {
										ic=iz1;
									  }
//									  else if (ic==-2) ic=-1;
								}
							}
						}
					}
				}
				WS=malloc(3*ny*sizeof(int));
				if (WS==NULL) error_end("Memory is not enough for allocation",1);
				if (nx<256) 				ix2=1;
					else if (nx<65536)		ix2=2;
					else if (nx<16777216) 	ix2=3;
					else 					ix2=4;
				for (i=0;i<ny*3;i++) WS[i]=getnint(ix2);
				if (show) {
					if (iprof==0) fr_trisurface(X,Y,Z,&nx,WS,&ny,&ic,&ind);
					  else {
						fr_maptrisurface(X,Y,Z,F,&nx,WS,&ny,&ic,&ind);
						free(F);
					}
					if (CONTOR3DMODE[NOWC]==0) {
						getcontorparm(&CTRDF1[NOWC],&CTRDF2[NOWC],&CTRDDF[NOWC],&CTRDND[NOWC]);
						if (ic<=-2) CTRDND[NOWC]=ic;
						CTRDDIM[NOWC]=0;
					}
				}
				free(WS);
				goto next;
			  case FRAMES_ISOSURFACE:
				DRAWED++;			GRAPHSPEC=ISOSURF;
				ind=getint();		ic=getint();
				ic1=ic%100;
				if (ic1<0 || ind>4) SURFACEMODE=1;
				if (LIGHTINGMODE&4) {
					if (ic<0) ind=6+(ind/10)*10;
					ic=SURFACECOLOR+(ic/100)*100;
				  }
				  else if (ind>4 && ic1>0 && ic1<=7) SURFACECOLOR=ic1;
				  else if (ic1<0) SURFACECOLOR=-ic1;
				  else SURFACECOLOR=-1;
				if (skip) show=0;
				  else if (ic1>0 && ic1<=7) {
					COLORNOW|=(1<<(ic1-1));
					show=(1<<(ic1-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&ix2,4);		getbyte(&iy2,4);		getbyte(&iz2,4);
				n=ix2*iy2*iz2;
				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				ix1=1;
				setregionxyzdim(&x1,&x2,&y1,&y2,&z1,&z2,&ix1);
				iy1=1;
				if (VERSION>=10) iy1=getint();
				z1=getddouble1();
				icc[0]=ic;		ff[0]=z1;
				for (i=1;i<iy1;i++) {
					icc[i]=getint();		ff[i]=getddouble1();
				}
				if (show) {
					if (CONTOR3DMODE[NOWC]&32) {
						z1=CTRDT0[NOWC];
					}
					if (SCALE3DMODE[NOWS]) {
						nx=1;
						setregion3dim(&ix2,&iy2,&iz2,&nx);
					}
					if (ngra!=GRAPHNO || niso!=DRAWED) {
						isosurfsetting(0);
						ngra=GRAPHNO;	niso=DRAWED;	fiso=z1;
						if (n>maxiso) {
							if (fisop!=NULL) free(fisop);
							fisop=(double *)malloc(n*sizeof(double));
							maxiso=n;
						}
						get8byte(fisop,Y,n,4);
					  }
					  else {
						seek8byte(n,4);
					  	if (z1!=fiso) {
							isosurfsetting(1);
							fiso=z1;
						  }
						  else {
							isosurfsetting(2);
						}
					}
					fr_isosurface(fisop,&ix2,&iy2,&iz2,ff,icc,&ind);
					if (CONTOR3DMODE[NOWC]==0) CTRDT0[NOWC]=z1;
				  }
				  else {
					seek8byte(n,4);
				}
				goto next;

			  case FRAMES_CLIP3D:
				getbyte(&c1,1);		ind=c1;
				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				fr_clip3d(&x1,&x2,&y1,&y2,&z1,&z2,&ind);
				goto next;

			  case FRAMES_VOLRENDER:
				DRAWED++;			GRAPHSPEC=VRENDER;
				ind=getint();		ic=getint();
				if (skip) show=0;
				  else if (ic1>0 && ic1<=7) {
					COLORNOW|=(1<<(ic1-1));
					show=(1<<(ic1-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&ix2,4);		getbyte(&iy2,4);		getbyte(&iz2,4);
				n=ix2*iy2*iz2;
				get8byte(&x1,&x2,1,0);
				get8byte(&y1,&y2,1,0);
				get8byte(&z1,&z2,1,0);
				ix1=1;
				setregionxyzdim(&x1,&x2,&y1,&y2,&z1,&z2,&ix1);
				if (show) {
					if (SCALE3DMODE[NOWS]) {
						nx=1;
						setregion3dim(&ix2,&iy2,&iz2,&nx);
					}
					if (ngra!=GRAPHNO || niso!=DRAWED) {
						ngra=GRAPHNO;	niso=DRAWED;
						if (n>maxiso) {
							if (fisop!=NULL) free(fisop);
							fisop=(double *)malloc(n*sizeof(double));
							maxiso=n;
						}
						get8byte(fisop,Y,n,4);
					  }
					  else {
						seek8byte(n,4);
					}
					fr_volrender(fisop,&ix2,&iy2,&iz2,&ic,&ind);
				  }
				  else {
					seek8byte(n,4);
				}
				goto next;
			}
			goto error;

		  case 8:
		  case 9:
			switch (c1) {
			  case FRAMES_FPLINE:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,2);
				get8byte(&x2,&y2,1,2);
				if (show) fr_fpline(&x1,&y1,&x2,&y2,&ic,&ind);
				goto next;
			  case FRAMES_FPCIRCLE:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,2);
				get8byte(&x2,&y2,1,2);
				if (VERSION==0) {
					x2*=2;		y2*=2;
				}
				if (show) fr_fpcircle(&x1,&y1,&x2,&y2,&ic,&ind);
				goto next;
			  case FRAMES_FPPOLYGON:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&n,4);
				if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
				get8byte(X,Y,n,2);
				if (show) fr_fppolygon(X,Y,&n,&ic,&ind);
				goto next;
			  case FRAMES_FPMARK:
				DRAWED++;
				ind=getubyte();			ic=getint();			ix1=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,2);
				get8byte(&x2,&y2,1,2);
				if (show) fr_fpmark(&x1,&y1,&x2,&y2,&ix1,&ic,&ind);
				goto next;
			  case FRAMES_FPCHARS:
				DRAWED++;
				if (VERSION>=3) ind=getubyte();
				  else ind=0;
				getbyte(&c1,1);			ix1=c1;
				getbyte(&c1,1);			iy1=c1;
				getbyte(&c1,1);			iy2=c1;
				ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get8byte(&x1,&y1,1,2);
				nx=getint();
#ifndef BIGENDIAN
				getbyte(chx,nx);
#else
				getbyte(chx,-nx);
#endif
				chx[nx]='\0';
				if (show) fr_fpchars(&x1,&y1,chx,&ic,&ix1,&iy1,&iy2,&ind);
				goto next;
			  case FRAMES_FPDOTS:
				DRAWED++;
				ind=getubyte();			getbyte(&n,4);
				if (n>NXALLOC || n>NYALLOC) alloc_data(n,2);
				get8byte(X,Y,n,2);
				if (ind==0) {
					ic=getint();
					if (skip) show=0;
					  else if (ic>0 && ic<=7) {
						COLORNOW|=(1<<(ic-1));
						show=(1<<(ic-1))&COLORSEL;
					  }
					  else show=0x100;
					if (show) fr_fpdots(X,Y,&ic,&n,&ind);
				  }
				  else {
					WS=malloc(n*sizeof(int));
					if (WS==NULL) 
						error_end("Memory is not enough for allocation",1);
					for (i=0;i<n;i++) WS[i]=getint();
					fr_fpdots(X,Y,WS,&n,&ind);
					free(WS);
				}
				goto next;
			  case FRAMES_2DMOVE:
				getbyte(&c1,1);		ind=c1;
				get8byte(&x1,&y1,1,2);
				if (skip) goto next;
				if (SCALE2DMODE[NOWS]&1) {
					if ((ind&1)==0) {
						if ((LOG2DMODE[NOWS]&1)==0 && (log2d_mode&1)) {
							x1=pow(10.0,x1);
						  }
						  else if ((LOG2DMODE[NOWS]&1) && (log2d_mode&1)==0) {
							if (x1<LOGMIN) x1=LOGMIN;
							x1=log10(x1);
						}
					}
				}
				if (SCALE2DMODE[NOWS]&2) {
					if ((ind&2)==0) {
						if ((LOG2DMODE[NOWS]&2)==0 && (log2d_mode&2)) {
							y1=pow(10.0,y1);
						  }
						  else if ((LOG2DMODE[NOWS]&2) && (log2d_mode&2)==0) {
							if (y1<LOGMIN) y1=LOGMIN;
							y1=log10(y1);
						}
					}
				}
				fr_2dmove(&x1,&y1,&ind);
				goto next;
			  case FRAMES_3DMOVE:
				getbyte(&c1,1);		ind=c1;
				get38byte(&x1,&y1,&z1,1,2);
				fr_3dmove(&x1,&y1,&z1,&ind);
				goto next;
			  case FRAMES_3DPOLYGON:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				getbyte(&n,4);
				if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
				get38byte(X,Y,Z,n,2);
				if (show) fr_3dpolygon(X,Y,Z,&n,&ic,&ind);
				goto next;

			  case FRAMES_3DLINE:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get38byte(&x1,&y1,&z1,1,2);
				get38byte(&x2,&y2,&z2,1,2);
				if (show) fr_3dline(&x1,&y1,&z1,&x2,&y2,&z2,&ic,&ind);
				goto next;

			  case FRAMES_3DCIRCLE:
				DRAWED++;
				ind=getubyte();			ic=getint();
				if (skip) show=0;
				  else if (ic>0 && ic<=7) {
					COLORNOW|=(1<<(ic-1));
					show=(1<<(ic-1))&COLORSEL;
				  }
				  else show=0x100;
				get38byte(&x1,&y1,&z1,1,2);
				get38byte(&x2,&y2,&z2,1,2);
				get38byte(&r1,&ph,&th,1,2);
				if (show) fr_3dcircle(&x1,&y1,&z1,&x2,&y2,&z2,&r1,&ph,&th,&ic,&ind);
				goto next;

			  case FRAMES_3DDOTS:
				DRAWED++;
				ind=getubyte();			getbyte(&n,4);
				if (n>NXALLOC || n>NYALLOC || n>NZALLOC) alloc_data(n,3);
				get38byte(X,Y,Z,n,2);
				if (ind==0) {
					ic=getint();
					if (skip) show=0;
					  else if (ic>0 && ic<=7) {
						COLORNOW|=(1<<(ic-1));
						show=(1<<(ic-1))&COLORSEL;
					  }
					  else show=0x100;
					if (show) fr_3ddots(X,Y,Z,&ic,&n,&ind);
				  }
				  else {
					WS=malloc(n*sizeof(int));
					if (WS==NULL) 
						error_end("Memory is not enough for allocation",1);
					for (i=0;i<n;i++) WS[i]=getint();
					fr_3ddots(X,Y,Z,WS,&n,&ind);
					free(WS);
				}
				goto next;
			}
			goto error;

		  default:
			if (c1<FRAMES_GPAGEC) {
			   switch (c1) {
				  case FRAMES_SETCIRCLE:
					if (VERSION==0) {
						ix1=getint();		x1=ix1*2;
					  }
					  else get8byte(&x1,&x2,1,-1);
					fr_setcircle(&x1);
					goto next;
				  case FRAMES_SETMARK:
					nx=getint();
					get8byte(&x1,&x2,1,0);
					fr_setmark(&x1,&x2,&nx);
					goto next;
				  case FRAMES_SETBAR:
					getbyte(&c1,1);		ind=c1;
					get8byte(&x1,&x2,1,-1);
					fr_setbar(&x1,&ind);
					goto next;
				  case FRAMES_SETARROW:
					if (VERSION==0) {
						ix1=getint();	iy1=getint();
						x1=ix1;			x2=iy1;
					  }
					  else get8byte(&x1,&x2,1,0);
					fr_setarrow(&x1,&x2);
					goto next;
				  case FRAMES_SET2DRGN:
					getbyte(&ix1,4);
					if (ix1>0) getbyte(&ix2,4);
					    else   ix2=ix1+1;
					getbyte(&iy1,4);
					if (iy1>0) getbyte(&iy2,4);
					    else   iy2=iy1+1;
					fr_set2drgn(&ix1,&ix2,&iy1,&iy2);
#ifdef TEMPORAL
					ixmin=ix1;	ixmax=ix2;
					iymin=iy1;	iymax=iy2;
#endif
					goto next;
				  case FRAMES_SET3DRGN:
					getbyte(&ix1,4);
					if (ix1>0) getbyte(&ix2,4);
					    else   ix2=ix1+1;
					getbyte(&iy1,4);
					if (iy1>0) getbyte(&iy2,4);
					    else   iy2=iy1+1;
					getbyte(&iz1,4);
					if (iz1>0) getbyte(&iz2,4);
					    else   iz2=iz1+1;
					fr_set3drgn(&ix1,&ix2,&iy1,&iy2,&iz1,&iz2);
					goto next;
				  case FRAMES_SETSTEP:
					getbyte(&ix1,4);
					fr_setstep(&ix1);
					goto next;
				  case FRAMES_SETFRAME:
					getbyte(&ix1,4);
					if (ix1>=100) {  ix1-=100;  ind=2;  }
					   else       ind=1;
					fr_setframe(&ix1,&ind);
					goto next;
				  case FRAMES_SETLIGHT:
					getbyte(&c1,1);		ind=c1;
					get8byte(&th,&ph,1,0);
					if (LIGHTINGMODE&1) {
						th=LIGHTALT;		ph=LIGHTAZIM;
					  }
					  else {
						LIGHTALT=th;		LIGHTAZIM=ph;
					}
					fr_setlight(&th,&ph,&ind);
					goto next;
				  case FRAMES_SETSURFACE:
					getbyte(&c1,1);		ind=c1;
					get8byte(&x1,&x2,1,0);
					if (LIGHTINGMODE&2) {
						x1=LIGHTAMB;		x2=LIGHTDIFF;		ind=LIGHTNSPEC;
					  }
					  else {
						LIGHTAMB=x1;		LIGHTDIFF=x2;		LIGHTNSPEC=ind;
					}
					fr_setsurface(&x1,&x2,&ind);
					goto next;
				  case FRAMES_SETVOLUME:
					get8byte(&x1,&x2,1,0);
					get8byte(&y1,&y2,1,0);
					fr_setvolume(&x1,&x2,&y1,&y2);
					goto next;

				  case FRAMES_GNOTES:
				  case FRAMES_FILECHAR:
				  	ind=c1;
					getbyte(&c1,1);		nx=(unsigned char)c1;
#ifndef BIGENDIAN
					getbyte(chy,nx);
#else
					getbyte(chy,-nx);
#endif
					chy[nx]='\0';
					if (ind==FRAMES_GNOTES && TGMODE) put_comment(chy);
					goto next;

				  case FRAMES_FILEINT:
					getbyte(&c1,1);		nx=(unsigned char)c1;
					for (i=0;i<nx;i++) getnint(4);
					goto next;

				  case FRAMES_FILEDBLE:
					getbyte(&c1,1);		nx=(unsigned char)c1;
					for (i=0;i<nx;i++) getddouble1();
					goto next;

				  case FRAMES_HLSSET:
					if (VERSION<2) {
						ic=getint();			iy1=getint();
					  }
					  else {
				getc1:	getbyte(&c1,1);			/*	printf("c1=%d\n",c1);	*/
						if (c1<=-2) {
							if (c1==ONECMAPP5) ic=getint()-1;
								else		   ic=-c1-3;
							if (ic<0) {
								CURHLSTABLE=0;
								fr_hlsset(X,Y,Z,&iy1,&ic);
							  }
							  else {
/*
								register_colormap(ic,fc);
								fc=NULL;
*/
								recall_colormap(ic);
							}
							goto next;
						}
						if (c1==-1) {
							ic=-1;
							fr_hlsset(X,Y,Z,&iy1,&ic);
							goto next;
						}
						while (c1==3 || c1==4) {
							if (c1==3) {
								getbyte(&c1,1);		ic=c1;
							  }
							  else ic=getint();
							iy1=getint();
							if (FOFF>FOFFHLS) {
								FOFFHLS=FOFF;
								fc=create_colormap(ic);
								fc->cn[0]=iy1;
								if (ic>0) {
									for (i=1;i<ic;i++) fc->cn[i]=getint();
									get38byte(fc->csh,fc->csl,fc->css,ic+1,8);
								  }
							  }
							  else if (ic>0) {
								for (i=1;i<ic;i++) getint();
								for (i=0;i<3*(ic+1);i++) getsreal();
							}
							getbyte(&c1,1);
						}
						if (c1==5) goto getc1;
						if (c1==1) {
							getbyte(&c1,1);		ic=c1;	/*	printf("c2=%d\n",c1);	*/
						  }
						  else ic=getint();
						iy1=getint();	/*	printf("iy1=%d\n",iy1);		*/
					}
/*					fc=create_colormap(ic,fc);			*/
					if (VERSION<5) {
						FOFFHLS=FOFF;
						fc=create_colormap(ic);
						fc->cn[0]=iy1;
						if (ic>0) {
							for (i=1;i<ic;i++) fc->cn[i]=getint();
							getbyte(&c1,1);
							get8byte(&x1,&x2,1,0);
							get8byte(&y1,&y2,1,0);
							get8byte(&z1,&z2,1,0);
							set_scale(x1,x2,y1,y2,z1,z2,3);
							get38byte(fc->csh,fc->csl,fc->css,ic+1,1);
						  }
						if (VERSION<4) fr_hlsset(fc->csh,fc->csl,fc->css,fc->cn,&ic);
					  }
					  else if (FOFF>FOFFHLS) {
						FOFFHLS=FOFF;
						fc=create_colormap(ic);
						fc->cn[0]=iy1;
						if (ic>0) {
							for (i=1;i<ic;i++) fc->cn[i]=getint();
							get38byte(fc->csh,fc->csl,fc->css,ic+1,8);
						  }
					  }
					  else if (ic>0) {
						for (i=1;i<ic;i++) getint();
						for (i=0;i<3*(ic+1);i++) getsreal();
					}
					goto next;
				}
			  }
		  	  else {
				goto end;
			}

	error:
			fprintf(stderr,"Command No. %d ---  Adress %08x %d ---\n",c1,(int)fpoff,(int)fpoff);
			error_end("The command is not supported yet",1);
		  }
/*	  }*/

end:
  	*cmd=c1;
	if (c1==FRAMES_GEND) return 0;
	return 1;
}

int skip_frame_pages(int n,int winm)
{
/*	winm=0	...	With initialize		(Associated by set_init)
	winm=10 ...	Without initialize	(SW off only)
*/
	int ind,n1,n2,n3,err=0;
	signed char cmd=0;

	if (skip_ok || next_ok) return 0xff;
	if (WINMODE) skip_ok=1;
	n1=0;	framesgcanvas(&n1);
/*	n1=winm;	n2=n3=0;
	gwiomodes(&n1,&n2,&n3,&PSYOFF);		*/

	if (setjmp(env)) {
		err=-1;
		ENDPAGE=GRAPHNO;
		goto end;
	}

	DRAWED=0;
	while (NFILEP<n) {
/*		printf("skip %d %d %d %d %d\n",(int)FOFF,(int)FILEP[NFILEP],NFILEP,GRAPHNO,n);	*/
		err=next_frame_page(&cmd,0,1);
		if (err) {
			if (DRAWED) set_filep(FOFF);
		  }
		  else {
			ENDPAGE=GRAPHNO;
/*			if (DRAWED) NFILEP++;	*/
			break;
		}
		DRAWED=0;
	}
end:
	n1=1;	framesgcanvas(&n1);
/*	if (winm==10) {
		n1=12-WINMODE;		n2=PSMODE;	n3=GIFMODE;
		gwiomodes(&n1,&n2,&n3,&PSYOFF);
	}	*/
	skip_ok=0;
	return err;
}

int next_frame_main(int mode)
{
	int chk,err;
	signed char cmd=0;

	if (next_ok || skip_ok) return 1;
	if (mode<0) seekfadr(--NFILEP);
	if (NFILEP>=ENDPAGE) return 0;

	if (mode>1) {
		switch (goto_filep(1,NFILEP+mode-1,0,&err)) {
			case 0: return 0;
			case 0xff:
					return 1;
			case 1:
					if (err<=0) return 0;
		}
	}

	gwioclearpage();

	if (WINMODE) next_ok=1;
	if (setjmp(env)) {
		err=-1;
		goto end;
	}

	chk=1;
	while (NFILEP<ENDPAGE) {
/*		printf("next %x %d %d %d\n",(int)FOFF,NFILEP,GRAPHNO,ENDPAGE);	*/
		if(chk>=0) initialize_page();
		err=next_frame_page(&cmd,counter_on,0);
		if (WINMODE) wpicdrawbufnowaitflush();
/*		printf("DRAWED=%d %d %d %d\n",DRAWED,mode,GRAPHNO,ENDPAGE);		*/
		if (err==0) {
			if (GRAPHNO<ENDPAGE) ENDPAGE=GRAPHNO;
			if (DRAWED) {
				if (PSMODE) postscriptnext();
#ifdef GIF
				if (GIFMODE) giffilenext(GRAPHNO);
#endif
				NFILEP++;
			}
			break;
		}
		if (DRAWED==0) continue;
		set_filep(FOFF);
		if (PSMODE) postscriptnext();
#ifdef GIF
		if (GIFMODE) giffilenext(GRAPHNO);
#endif
		if (CLRSTOP) break;
		if (DISPINFO && WINMODE==0) fprintf(stderr,"Page %.4d has been processed.\n",GRAPHNO);

		if (GRAPHSTEP>1) {
			serial_no++;
			if (serial_no>=GRAPHEACH) {
				switch (goto_filep(1,NFILEP+GRAPHSTEP-GRAPHEACH,0,&err)) {
					case 0: 	goto end1;
					case 0xff:	return 1;
					case 1:
						if (err<=0) goto end1;
				}
				serial_no=0;
			  }
		}

		gwioclearpage();
		chk=1;
	}

end1:
	err=1;
end:
	if (DRAWED && WINMODE) finish_drawframes();
	next_ok=0;
	return err;
}

void alloc_data(int n,int m)
{
	if (m==1) {
		while (1) {
			if (X!=NULL) free(X);
			X=malloc(n*sizeof(double));
			if (X==NULL) {
				if (Y==NULL && Z==NULL)
					error_end("Memory is not enough for allocation",1);
				if (Y!=NULL) {	free(Y);	Y=NULL;	 NYALLOC=0;  }
				if (Z!=NULL) {	free(Z);	Z=NULL;  NZALLOC=0;  }
			  }
			 else break;
		  }
		NXALLOC=n;
	  }
	 else if (m==2) {
		while (1) {
			if (X!=NULL) free(X);
			if (Y!=NULL) free(Y);
			X=malloc(n*sizeof(double));		Y=malloc(n*sizeof(double));
			if (X==NULL || Y==NULL) {
				if (Z==NULL)
					error_end("Memory is not enough for allocation",1);
				free(Z);	Z=NULL;  NZALLOC=0;
			  }
			 else break;
		  }
		NXALLOC=NYALLOC=n;
	  }
	 else if (m==3) {
		if (X!=NULL) free(X);
		if (Y!=NULL) free(Y);
		if (Z!=NULL) free(Z);
		X=malloc(n*sizeof(double));	Y=malloc(n*sizeof(double));	Z=malloc(n*sizeof(double));
		if (X==NULL || Y==NULL || Z==NULL)
				error_end("Memory is not enough for allocation",1);
		NXALLOC=NYALLOC=NZALLOC=n;
	  }
	 else if (m==4) {
		if (Y!=NULL) free(Y);
		if (Z!=NULL) free(Z);
		Y=malloc(n*sizeof(double));		Z=malloc(n*sizeof(double));
		if (Y==NULL || Z==NULL) error_end("Memory is not enough for allocation",1);
		NYALLOC=NZALLOC=n;
	  }
}

void seekftadr(off_t fadr)
{
	if (fadr<FADR0 || fadr>=FADR1) {
#ifdef HP
		if (fseek(fpg,fadr,SEEK_SET)) {
#else
		if (lseek(FDIO,fadr,SEEK_SET)==-1) {
#endif
			error_end("Cannot seek this address",1);
		}
		FADR0=FADR1=fadr;
	}
	FOFF=fadr-1;
}

void getbyte(void *bp,int n)
{
	char *b;
	int i;
	unsigned int nb;

	b=(char *)bp;
#ifndef BIGENDIAN
	for (i=0;i<n;i++) {
		FOFF++;
		if (FOFF>=FADR1) {
			nb=read(FDIO,BUFFER,BUFSIZE);
			if (nb==0) {
				ENDFILE=1;
				/* error_end("Reached to End Of File",1);*/ 
				longjmp(env,1);
	    	  }
			FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
		  }
		b[i]=BUFFER[FOFF-FADR0];
	  }
#else
	if (n<0) {
		for (i=0;i<-n;i++) {
			FOFF++;
			if (FOFF>=FADR1) {
# ifdef HP
				nb=fread(BUFFER,1,BUFSIZE,fpg);
# else
				nb=read(FDIO,BUFFER,BUFSIZE);
# endif
				if (nb==0) {
					ENDFILE=1;
					/* error_end("Reached to End Of File",1);*/ 
					longjmp(env,1);
		    	  }
				FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
			  }
			b[i]=BUFFER[FOFF-FADR0];
		  }
	   }
/*    special for unix & mac	*/
	  else if (n>0) {
		for (i=1;i<=n;i++) {
			FOFF++;
			if (FOFF>=FADR1) {
# ifdef HP
				nb=fread(BUFFER,1,BUFSIZE,fpg);
# else
				nb=read(FDIO,BUFFER,BUFSIZE);
# endif
				if (nb==0) {
					ENDFILE=1;
					/* error_end("Reached to End Of File",1);*/ 
					longjmp(env,1);
		    	  }
				FOFF=FADR0=FADR1;   FADR1=FADR0+nb;   
			  }
			b[n-i]=BUFFER[FOFF-FADR0];
		  }
	}
#endif

}
unsigned char getubyte(void)
{
	unsigned char c;
	getbyte(&c,1);
	return c;
}

int getint()
{
	short w;
	getbyte(&w,2);
	return (int)w;
}

int getint3()
{
	int w;
	getbyte(&w,3);
#ifdef BIGENDIAN
	w>>=8;
#endif
	return (int)w;
}

void seek8byte(int n,int mode)
{
	off_t fadr;
	if (mode==4) {
		if (VERSION<5) 	fadr=FOFF+(n-1)*3+5;
			else		fadr=FOFF+n*3+5;
	}
	seekftadr(fadr+1);
}
void get8byte(double *x,double *y,int n,int mode)
{
	int	i;
	double x0;

	if (VERSION<5) goto v0;

	if (mode<=0) {
		x[0]=getddouble1();
		if (mode==0) y[0]=getddouble1();
	  }
	  else if (mode==1) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*getsreal()+X0;
			y[i]=YTAN*getsreal()+Y0;
		}
	  }
	  else if (mode==2) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
			y[i]=getdouble1();
		}
	  }
	  else if (mode==3) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
		}
	  }
	  else if (mode==4) {
		x0=getddouble1();
		for (i=0;i<n;i++) {
			x[i]=x0+getdouble1();
		}
	  }
	  else if (mode==5) {
		for (i=0;i<n;i++) {
        	x[i]=XTAN*getsreal()+X0;
		}
	  }
	  else if (mode==6) {
		for (i=0;i<n;i++) {
			y[i]=YTAN*getsreal()+Y0;
		}
	}
	return;

v0:
	if (mode<=0) {
		x[0]=getddouble1();
		if (mode==0) y[0]=getddouble1();
	  }
	  else if (mode==1) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*get1int()+X0;
			y[i]=YTAN*get1int()+Y0;
		}
	  }
	  else if (mode==2) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
			y[i]=getdouble1();
		}
	  }
	  else if (mode==3) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
		}
	  }
	  else if (mode==4) {
		x[0]=getddouble1();
		for (i=1;i<n;i++) {
			x[i]=x[0]+getdouble1();
		}
	  }
	  else if (mode==5) {
		for (i=0;i<n;i++) {
        	x[i]=XTAN*get1int()+X0;
		}
	  }
	  else if (mode==6) {
		for (i=0;i<n;i++) {
			y[i]=YTAN*get1int()+Y0;
		}
	}
}

#define HTC1	36.e-6
#define HTC		30.e-6
#define LTC		1.e-7
#define STC		LTC

void get38byte(double *x,double *y,double *z,int n,int mode)
{
	int	i;

	if (VERSION<5) goto v0;

	if (mode==0) {
		for (i=0;i<n;i++) {
			z[i]=ZTAN*getsreal()+Z0;
		}
	  }
	  else if (mode==1) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*getsreal()+X0;
			y[i]=YTAN*getsreal()+Y0;
			z[i]=ZTAN*getsreal()+Z0;
		}
	  }
	  else if (mode==2) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
			y[i]=getdouble1();
			z[i]=getdouble1();
		}
	  }
	  else if (mode==5) {
		for (i=0;i<n;i++) {
			y[i]=YTAN*getsreal()+Y0;
			z[i]=ZTAN*getsreal()+Z0;
		  }
	  }
	  else if (mode==6) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*getsreal()+X0;
			z[i]=ZTAN*getsreal()+Z0;
		}
	  }
	  else if (mode==7) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*getsreal()+X0;
			y[i]=YTAN*getsreal()+Y0;
		}
	  }
	  else if (mode==8) {
	  	if (VERSION<6) {
			for (i=0;i<n;i++) {
				x[i]=HTC1*getsreal();
				y[i]=LTC *getsreal();
				z[i]=STC *getsreal();
			}
		  }
		  else {
			for (i=0;i<n;i++) {
				x[i]=HTC*getsreal();
				y[i]=LTC*getsreal();
				z[i]=STC*getsreal();
			}
		}
	  }
	return;

v0:
	if (mode==0) {
		for (i=0;i<n;i++) {
			z[i]=ZTAN*get1int()+Z0;
		}
	  }
	  else if (mode==1) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*get1int()+X0;
			y[i]=YTAN*get1int()+Y0;
			z[i]=ZTAN*get1int()+Z0;
		}
	  }
	  else if (mode==2) {
		for (i=0;i<n;i++) {
			x[i]=getdouble1();
			y[i]=getdouble1();
			z[i]=getdouble1();
		}
	  }
	  else if (mode==5) {
		for (i=0;i<n;i++) {
			y[i]=YTAN*get1int()+Y0;
			z[i]=ZTAN*get1int()+Z0;
		  }
	  }
	  else if (mode==6) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*get1int()+X0;
			z[i]=ZTAN*get1int()+Z0;
		}
	  }
	  else if (mode==7) {
		for (i=0;i<n;i++) {
			x[i]=XTAN*get1int()+X0;
			y[i]=YTAN*get1int()+Y0;
		}
	}
}

double getsreal()
{
/*	Require 3 bytes		*/
	union linteg { char c[4];	signed int l; } b;
	int i;

	b.l=0;
	
#ifndef BIGENDIAN
   	getbyte(&(b.c[1]),3);
	if (((b.c[1])&1)==0) b.l>>=7;
#else
	getbyte(&b,3);
	if (((b.c[2])&1)==0) b.l>>=7;
/*
	getbyte(&(b.c[1]),3);
	if ((b.c[3])&1) {
		for (i=0;i<3;i++) b.c[i]=b.c[i+1];
	  }
	  else {
		b.l<<=1;
		if (b.c[0]) b.c[0]=0xff;
	}
*/
#endif

	return (double)(b.l);
}

int get1int()
{
	union linteg { char c[4];	int l; } b;

	b.l=0;
#ifndef BIGENDIAN
    getbyte(&b,2);
    if ((b.c[0])&1) {
        getbyte(&b.c[2],1);
        if ((b.c[2])&0x80) b.c[3]=0xff;
    }
#else
	getbyte(&(b.c[2]),2);
	if ((b.c[3])&1) {
		getbyte(&b.c[1],1);
		if ((b.c[1])&0x80) b.c[0]=0xff;
	}
#endif

	return b.l;
}

int getnint(int n)
{
	union linteg { char c[4];	int l; } b;

	b.l=0;
#ifndef BIGENDIAN
    getbyte(&b,n);
#else
	getbyte(&b.c[4-n],n);
#endif

	return b.l;
}

double getdouble1()
{
/*	Require 3 bytes		*/
	signed char 	b1;
	char	ch[20];
	int	n1;

    n1=0;
    getbyte(&n1,3);
#ifdef BIGENDIAN
	n1>>=8;
#endif
    b1=n1&0x3f;       n1>>=6;
    if (b1&0x20) b1|=0xc0;
    if (n1&0x20000) n1|=0xfffc0000;
/*    sprintf(ch,"%7lde%d",n1,b1);		*/
    sprintf(ch,"%7de%d",n1,b1);
    ch[0]=ch[1];	ch[1]='.';
	return atof(ch);
}

double getddouble1()
{
/*	Require 5 bytes		*/
	signed char	b1;
	char 	ch[20];
	int		n1;

	getbyte(&n1,4);
	if (n1) {
	  getbyte(&b1,1);
/*	  sprintf(ch,"%11lde%d",n1,b1);		*/
	  sprintf(ch,"%11de%d",n1,b1);
	  ch[0]=ch[1];	ch[1]='.';
	  return atof(ch);
	 }
	 else {
	  getbyte(&b1,1);
	  return 0;
	}
}
