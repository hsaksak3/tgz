************************************
*      F  R  A  M  E  S  V.6       *
*   TESTS OF GRAPHICAL ANIMATION   *
*     PROGRAMMED BY T.TAGUCHI      *
************************************
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 SH(4),SL(4),SS(4)
      INTEGER NDIV(3)

      CALL FR_GINIT
      CALL FR_GWSIZE(480,460,0,0)
      CALL FR_GFILE('ganim',1)
*      CALL FR_GIFANIMATION(-1,'ganim',1001,0,0)

      SH(1) = 230.D0
      SH(2) = 230.D0
      SH(3) = 0.D0
      SH(4) = 0.D0
      SL(1) = 0.8D0
      SL(2) = 0.D0
      SL(3) = 0.D0
      SL(4) = 0.8D0
      SS(1) = 1.D0
      SS(2) = 1.D0
      SS(3) = 1.D0
      SS(4) = 1.D0
      NDIV(1) = 64
      NDIV(2) = 0
      NDIV(3) = 64
      CALL FR_HLSSET(SH,SL,SS,NDIV,3)

      NMAX = 30

      DO I = 0, NMAX-1
         CALL TCONT(I,NMAX)
         CALL FR_GPAUSE
      ENDDO

      CALL FR_GEND

      STOP
      END

      SUBROUTINE TCONT(IS,ISMAX)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=50,JMAX=50)
      REAL*8 F(0:IMAX,0:JMAX)

      CALL FR_GCLEAR

      XMIN = -2.5D0
      XMAX =  2.5D0
      YMIN = -2.5D0
      YMAX =  2.5D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      R1   = 1.D0
      R2   = 1.3D0
      PI2  =  8.D0*ATAN(1.D0)
      DT1  = 1*PI2/ISMAX
      DT2  = 2*PI2/ISMAX

      DO J = 0, JMAX
         DO I = 0, IMAX
            X1 = R2*COS(DT1*IS)
            Y1 = R2*SIN(DT1*IS)
            X2 = R2*COS(DT2*IS)
            Y2 = -R2*SIN(DT2*IS)
            X=DX*I+XMIN
            Y=DY*J+YMIN
            F(I,J)=EXP(-1.0*((X-X1)**2+(Y-Y1)**2))
     +              -EXP(-5.0*((X-X2)**2+(Y-Y2)**2))
         ENDDO
      ENDDO

      CALL FR_SETCONTOUR(-0.8D0,0.8D0,2)
      CALL FR_VIEW2D(40,30,400,400)
      CALL FR_ASPECT2D(1.0D0,1.D0,0)
      CALL FR_FRAME2D(XMIN,XMAX,YMIN,YMAX,6)
      CALL FR_XYNAME('X','Y')
      CALL FR_CONTOUR(F,IMAX+1,JMAX+1,20,-2)
      CALL FR_2DMOVE(1.0D0,0.5D0,3)
      CALL FR_COLORBAR(10,-130,15,260,322)

      RETURN
      END
