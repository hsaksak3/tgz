!*********************************************
!            F  r  a  m  e  s  V.7           *
!   Tests of Parametric 3D View subroutines  *
!          Programmed by T. Taguchi          *
!*********************************************
program frames_pmtest
   implicit none

   call fr_ginit
   call fr_gfile('gtest3',0)

   call drawave
     call next
   call grwave
     call next
   call pfwave
     call next
   call torus

   call fr_gend

end program frames_pmtest

subroutine next
   call fr_gpause
   call fr_gclear
   return
end subroutine next

!*******************************
!   Prametric Graphic Test 1   *
!*******************************
subroutine drawave
   implicit none
   real, parameter :: vec=50.0
   integer, parameter :: imax=100, jmax=50
   real  func,xmin,xmax,ymin,ymax,zmin,zmax,x,y,z,t,dx,dz,dt
   integer i,j

   xmin = -15.0
   xmax =  15.0
   ymin = -10.0
   ymax =  10.0
   zmin = -15.0
   zmax =  15.0

   dt = 0.5/vec
   dx = (xmax-xmin)/imax
   dz = (zmax-zmin)/jmax

!   call fr_pmview(70,150,430,370,550,250)
   call fr_xyzname('x-axis','z-axis','y-axis')
   call fr_pmframe(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_hclear(1)

   t = 0.0
   do j = 0, jmax
      z = dz*j + zmin
      call fr_pmset(z)
      y = func(xmin,z,t)
      call fr_pmdraw(xmin,y,6,-2)
      do i = 1, imax
         x = dx*i + xmin
         y = func(x,z,t)
         call fr_pmdraw(x,y,6,-1)
      enddo
   enddo

end subroutine drawave

!*******************************
!   Prametric Graphic Test 2   *
!*******************************
subroutine grwave
   implicit none
   integer, parameter :: imax=100, jmax=50
   real  x(0:imax),y(0:imax),func
   real  xmin,xmax,ymin,ymax,zmin,zmax,z,dx,dz
   integer i,j

   xmin = -15.0
   xmax =  15.0
   ymin = -10.0
   ymax =  10.0
   zmin = -15.0
   zmax =  15.0

   dx = (xmax-xmin)/imax
   dz = (zmax-zmin)/jmax

   call fr_pmview(50,180,400,390,500,180)
   call fr_xyzname('x-axis','z-axis','y-axis')
   call fr_pmframe(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_hclear(1)

   x(0) = xmin
   x(1) = xmax
   do j = 0, jmax
      z = dz*j + zmin
      do i = 0, imax
!         x(i) = dx*i+xmin
         y(i) = func(dx*i+xmin,z,0.0)
      enddo
!      call fr_pmgraph(x,y,z,imax+1,2,-1)
      call fr_pmgraph(x,y,z,imax+1,2,-101)
   enddo

end subroutine grwave

!*******************************
!   Prametric Graphic Test 3   *
!*******************************
subroutine pfwave
   implicit none
   integer, parameter :: imax=50, jmax=50
   real  t2(0:imax,0:jmax),func
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,z,dx,dz
   integer i,j

   xmin = -15.0
   xmax =  15.0
   ymin = -10.0
   ymax =  10.0
   zmin = -15.0
   zmax =  15.0

   dx = (xmax-xmin)/imax
   dz = (zmax-zmin)/jmax
   call fr_pmview(50,180,400,390,600,280)
   call fr_xyzname('x-axis','y-axis','z-axis')
   call fr_pmframe(xmin,xmax,ymin,ymax,zmin,zmax,3)

   do i = 0, imax
      x = dx*i + xmin
      do j = 0, jmax
         z = dz*j + zmin
         t2(i,j) = func(x,z,0.0)
      enddo
   enddo
   
   call fr_set2drgn(0,30,0,25)
   call fr_profile(t2,imax+1,jmax+1,5,1)

end subroutine pfwave

function func(x,y,t)
   implicit none
   real, parameter :: vec=50.0
   real  func,x,y,t,exp0,xx

   xx = x*x + y*y
   func = 15.0*cos(sqrt(xx)-vec*t)*exp0(-(0.01*xx+50*t*t))

end function func

function exp0(x)
   implicit none
   real  exp0,x

   exp0 = 0.0
   if (abs(x) <= 20.0) exp0 = exp(x)

end function exp0

!**************************
!      Torus Display      *
!**************************
subroutine torus
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: imax=30, jmax=31
   real  x(imax,jmax),y(imax,jmax),z(imax,jmax)
   real  u,v,du,dv
   integer i,j

   du = 2*pi/(imax-1)
   dv = 2*pi/(jmax-1)

   do j = 1, jmax
      v = dv*j
      do i = 1, imax
         u      = du*i
         x(i,j) = (2+0.75*cos(v))*cos(u)
         y(i,j) = (2+0.75*cos(v))*sin(u)
         z(i,j) = 0.75*sin(v)
      enddo
   enddo

   call fr_setaxis(3)
   call fr_pmview(60,130,460,390,580,180)
   call fr_xyzname('x-axis','y-axis','z-axis')
   call fr_pmframe(-3.0,3.0,-1.0,2.0,-3.0,3.0,0)

   call fr_surface(x,y,z,imax,jmax,4,4)

end subroutine torus
