/**********************************************************************
 *                    F    r    a    m    e    s                      *
 *      Graphic Core Routines for X Windows  Ver0.953 (02/08/93)      *
 *                                              By T. Samezima        *
 *                       ->     Ver0.9992 (11/17/06)                  *
 *                                              By T. Taguchi         *
 **********************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include 	<math.h>

/*#define TEST_ROUTINES		*/

#define WINDRAW_END				0							/* End reading */
#define WINDRAW_DOT				10							/* Dot */
#define WINDRAW_DOTS			11							/* Several dots */
#define WINDRAW_DRAW			19							/* draw */
#define WINDRAW_LINE			20							/* Line */
#define WINDRAW_SEGMENTS		21							/* Separate lines */
#define WINDRAW_LINKS			22							/* Linked lines */
#define WINDRAW_FILLPOLYGON		23							/* Closed linked lines and Fill */
#define WINDRAW_CIRCLE			30							/* Circle */
#define WINDRAW_FILLCIRCLE		35							/* Fill circle */
#define WINDRAW_GRADCIRCLE		36							/* Gradient fill circle */
#define WINDRAW_BOX				40							/* Box */
#define WINDRAW_FILLBOX			45							/* Fill box */
#define WINDRAW_GRADFILLBOX		46							/* Gradient fill box */
#define WINDRAW_CHAR			81							/* Characters */
#define WINDRAW_XORCHAR			82							/* XOR Characters */
#define WINDRAW_FINECHAR		83							/* Fine Position Characters */
#define WINDRAW_BASECOLMAP		90							/* Base of the Current Colormap */
#define WINDRAW_BASICCOL		91							/* Basic color setting */
#define WINDRAW_EXTENDCOL		92							/* Extended color setting */
#define WINDRAW_EXTEND2COL		93							/* Extended color setting */

#define NGBUFFER				4096
#define NCHRBUFFER				1024
#define MAXMEMSIZE				40960			/* Buffer size to allocate at one time        */
#define BFSMAX					(MAXMEMSIZE-sizeof(short)+1)
#define IFSMAX					(MAXMEMSIZE-sizeof(int)+1)
#define BORDERWIDTH				10

#ifndef NOX

#include	<X11/Xlib.h>
#include	<X11/Xutil.h>
#include	<X11/Xatom.h>
#include	<X11/keysym.h>

#ifdef TOOLKIT
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#endif

#ifdef GTK
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
typedef struct {
	gint16 x;
	gint16 y;
	guint16 width;
	guint16 height;
	gint16 angle1,angle2;            // angle in degrees*64
} GdkArc;
#endif
#endif

#define NOT_USED_TPLOT
#include "frames.h"

#ifndef NOX
#include "frames_canvas.h"

#define	Nothing		
#define rgbmax 			65536
#define ONEBUFFER		250		/* Buffer increase size (about 10MB) -- 1 unit 40k        */
#define BASE_NPIXEL		256
#define MAXCOLMAPS		(MAXDEFCUMAPP+MAXSYSCOLMAP)
/*#define XSERVER_CHECK		*/

#ifdef ALPHA
typedef int				PIXELTYPE;
#else
typedef long			PIXELTYPE;
#endif

typedef struct {
#ifdef GTK
	GdkWindow		*win;
	GtkWidget		*topwin;
	GtkWidget		*area;
	GdkPixmap		*pix;
	GdkGC			*gc;
	GdkDrawable		*drw;
#else
	Window			win;
#ifdef TOOLKIT
	Window			topwin;
#endif
	Pixmap			pix;
	GC				gc;
	Drawable		drw;
#endif
	unsigned int	width, height;			/* Display window size */
	unsigned int	owidth, oheight;		/* Original window size */
	int				chsize;					/* Character Magnification */
	int				bfmmax;
	char			**grbuf, *bmap;			/* Array for buffer access */
	int				draw_mode;				/* Drawed items (0 means nothing)  			  */
	int				bfmad, bfsad;			/* Arrays to manage buffers (for 2 pages)     */
	int				nfont, fontheight, fontwidth;	/* Current using font number and size */
	int				ccmap;					/* Current Color map  						  */
#ifdef GTK
	GdkColor 		bcolor[10];
	GdkColor		*pixels;				/* Pointer to color table                      */
#else
	unsigned int	bcolor[10];				/* Basic color number                         */
	PIXELTYPE		*pixels;				/* Pointer to color table                      */
#endif
//	unsigned int	pixpt[MAXCOLMAPS];		/* Pointer to the pixel array				  */
//	int				cmapnum[MAXCOLMAPS];	/* Assign to the Frames color table number	  */
	PIXELTYPE		*lpixels;				/* Local color number                         */
} FRAMESWINDOW;

#ifdef GTK
static FRAMESWINDOW		*frwin[MAXFP];
int				TGMODE=1;
GdkColor		*gpixels=NULL;				/* Global color tables						  */
GdkColor		*gsphept[7];
#else
PIXELTYPE		*gpixels=NULL;				/* Global color tables						  */
PIXELTYPE		*gsphept[7];
#endif
unsigned int	gpixpt[MAXCOLMAPS];			/* Global Pointer to the pixel array		  */
int				gcmapnum[MAXCOLMAPS];		/* Assign to the Frames color table number	  */
int				max_colmap=-1, max_gpixels=-1, current_hlstable=0, def_colmap=0;

#define xchg(xx)		(int)(((double)(xx)*magni)+revx+0.5)
#define ychg(yy)		(int)(((double)(yy)*magni)+revy+0.5)
#define rchg(rr)		(int)(((double)(rr)*magni)+0.5)
#define xrchg(xx)		(int)(((double)(xx)-revx)/magni+0.5)
#define yrchg(yy)		(int)(((double)(yy)-revy)/magni+0.5)
#define dxrchg(xx)		(((double)(xx)-revx)/magni)
#define dyrchg(yy)		(((double)(yy)-revy)/magni)

#ifndef TOOLKIT
/*#define ColorSet		1*/
static FRAMESWINDOW		*frwin[MAXFP];
static Atom				num_frames;
#else
/*#define ColorSet		0*/
extern int				TGMODE;
extern XtAppContext		app_con;
extern Widget			toplevel, xframes, seq_button, mode_button;
extern Widget			ctoggle[7], cradio[7], lradio[7];
extern char				filename[];
#endif
#ifdef GTK
extern GtkWidget		*framesarea, *mainwindow;
#endif

static FRAMESWINDOW		*cwin, *dwin;
#ifdef GTK
static GdkColormap		*cmap=NULL, *dcmap;
static GdkFont			*fontst;
#else
static Colormap			cmap=0, dcmap;
static XFontStruct		*fontst;
static XCharStruct		charst;
#endif

static Display			*dpID;
static int				maxwindow=0;			/* Maximum Window Number                           */
static int				display_mode=1;			/* Display mode (0: step by step, 1: draw at once) */
static Atom				wm_delete_window;

static unsigned int		border_width, display_width, display_height;
static int				xyratiomode;
static int				color_num, dp_ncolor, max_colors, max_acolors, color_set, color_mode=0;
static int				dp_cells, dp_planes, dp_depth, dp_class, dp_mincmap, dp_maxcmap;
static int				*dp_sh=NULL,*dp_sl,*dp_ss,*dp_div,dp_mode;
static int				shmin0,shmax0,slmin0,slmax0,ssmin0,ssmax0;

static int				eventmask;				/* Mask for getting events                    */
static int				revx, revy;				/* Offset coordinates for the window position */
static double			magni,magnix,magniy,grate;		/* (Display size) / (Virtual size)            */
static int				magnum, magden;
#ifdef GTK
static GdkColor			colplt[11];				/* Basic color palette                        */
#else
static unsigned int		colplt[11];				/* Basic color palette                        */
#endif
static int				colbkup=0;				/* Present color number                       */
static int				polyshape=Nonconvex;
static int				error_draw=0,true_color=0;
static int				huesave[BASE_NPIXEL],satsave[BASE_NPIXEL],ligsave[BASE_NPIXEL];

/*   3 Definitions of Font Name Lists   */

#ifdef FONT1
static char				*fontname[10]={ "courB08", "courB10",
										"courB12", "courB14",
										"courB18", "courB18",
										"courB18", "courB24",
										"courB24", "courB24" };
#else
#ifdef FONT2
static char				*fontname[10]={ "-adobe-courier-medium-r-normal--*-80-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-80-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-100-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-120-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-140-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-180-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-180-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-240-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-240-*-*-m-*-iso8859-1",
										"-adobe-courier-medium-r-normal--*-240-*-*-m-*-iso8859-1"};
#else
static char				*fontname[10]={ "5x8", "6x10",
										"6x12", "7x14",
										"8x16", "8x16",
										"10x20", "10x20",
										"12x24", "12x24" };
#endif
#endif

#ifndef TOOLKIT
static int 	keydist(KeySym, unsigned int);
static void eventandmousechk(XEvent, int *, int *, int *, int *, int *);
#endif

#ifdef GTK
void update_frame(GtkWidget *widget);
#endif

static void redraw_pics(FRAMESWINDOW *cw);

#ifdef TEST_ROUTINES
static char *event_type(int type)
{
	static char str[80];

	switch (type) {
		case Expose:						/* When window expose */
			strcpy(str,"Expose");
			break;
		case KeyPress:						/* When key down */
			strcpy(str,"KeyPress");
			break;
		case ButtonPress:					/* When press mouse button */
			strcpy(str,"ButtonPress");
			break;
		case ButtonRelease:					/* When release mouse button */
			strcpy(str,"ButtonRelease");
			break;
		case DestroyNotify:					/* When destroy window */
			strcpy(str,"DestroyNotify");
			break;
		case ConfigureNotify:				/* When change window size */
			strcpy(str,"ConfigureNotify");
			break;
		case ClientMessage:					/* When Window delete message sent by WM */
			strcpy(str,"ClientMessage");
			break;
		case MapNotify:
			strcpy(str,"MapNotify");
			break;
		case UnmapNotify:
			strcpy(str,"UnmapNotify");
			break;
		case CirculateNotify:
			strcpy(str,"CirculateNotify");
			break;
		case GravityNotify:
			strcpy(str,"GravityNotify");
			break;
		case ReparentNotify:
			strcpy(str,"ReparentNotify");
			break;
		default:
			strcpy(str,"Others");
	}
	return str;
}
#endif

/**************************************************************
*   Special for Alpha machine
*   added by Sakagami,H. 95/06/02 to supress unalign error msg
***************************************************************/
#ifdef ALPHA
#include <sys/types.h>
#include <sys/sysinfo.h>
static void suppressunaligned (void)
{
	int buffer[2];
	buffer[0] = SSIN_UACPROC;
	buffer[1] = 1;
	if (setsysinfo(SSI_NVPAIRS, buffer, 1, NULL, NULL) < 0 ) perror(" ");
}
#endif

/******************************************************************
*    Calcurate Offset Coordinate and Display/Virtual Window Ratio
*******************************************************************/
static void set_magnification(FRAMESWINDOW *cw)
{
	double dw, dh;
	int    num,num1;

	dw=(double)(cw->width)/(double)(cw->owidth);	/* Selection of appropriate font for window size */
	dh=(double)(cw->height)/(double)(cw->oheight);

	if ( dw > dh ) {									/* Calcurate Offset Coordinate and Window Ratio */
		dw=(double)(cw->width);
		magni = dh;
		revx = (unsigned int)( (dw-(double)(cw->owidth)*magni)/2 );
		revy = 0;
		magnum=WINRATE*(cw->height);		magden=cw->oheight;
	  }
	  else {
		dh=(double)(cw->height);
		magni = dw;
		revx = 0;
		revy = (unsigned int)( (dh-(double)(cw->oheight)*magni)/2 );
		magnum=WINRATE*cw->width;		magden=cw->owidth;
	}
/*      printf("mag=%d %d %d %d %d %d\n",magnum,magden,cw->width,cw->owidth,cw->owidth,cw->chsize);		*/

	if (xyratiomode>0) 			num=((int)(cw->height)-240)*10/WINHEIGHT;
		else if (xyratiomode<0) num=((int)(cw->width)*magnix-320)*10/WINWIDTH;
		else {
			num=((int)((cw->width)*(cw->chsize)/BASECOLVAL)-320)*10/WINWIDTH;
			num1=((int)((cw->height)*(cw->chsize)/BASECOLVAL)-240)*10/WINHEIGHT;
			if (num1>num) num=num1;
	}

/*		printf("%d %d %d %d\n",xyratiomode,cw->height,cw->width,num);	*/

	if (num<0) num=0;
	  else if (num>9) num=9;

	if ( num != cw->nfont ) {				/* Set font */
#ifdef GTK		// fontGTK
//		if (cw->nfont >= 0) XUnloadFont(dpID, fontst->fid);
		cw->nfont= num;
		fontst = gdk_font_load(fontname[cw->nfont]);
//		XSetFont(dpID, &(cw->gc), fontst->fid);
		cw->fontwidth=gdk_char_width(fontst,'Z');
		cw->fontheight=fontst->ascent+fontst->descent;
#else
		if (cw->nfont >= 0) XUnloadFont(dpID, fontst->fid);
		cw->nfont= num;
		fontst = XLoadQueryFont(dpID, fontname[cw->nfont]);
		XSetFont(dpID, cw->gc, fontst->fid);
		cw->fontwidth=fontst->max_bounds.width;
		cw->fontheight=fontst->max_bounds.ascent+fontst->max_bounds.descent;
#endif
	}
}

/***********************************************
*    Initialize Basic Color Setting
***********************************************/
#ifdef GTK
static GdkColor color_from_rgb(int r, int g, int b, int  *rt)
{
	GdkColor cc;

	*rt = 0;
	cc.red=r;		cc.green=g;		cc.blue=b;
	gdk_color_alloc(dcmap,&cc);
	return cc;
}
#else
static unsigned int color_from_name(char *color, int  *rt)
{
	XColor col, exa;
	PIXELTYPE pla[2], pix[2];

	*rt = 0;
	if ( XAllocNamedColor (dpID, dcmap, color, &col, &exa) == True ) return col.pixel;
	if ( XAllocColorCells (dpID, dcmap, False, (unsigned long*)pla, 0, (unsigned long*)pix, 1) == True  ) {
		XStoreNamedColor (dpID, dcmap, color, pix[0], DoRed | DoGreen | DoBlue );
		return pix[0];
	}
	*rt = 1;
	return WhitePixel(dpID, 0);
}

static unsigned int color_from_rgb(int r, int g, int b, int  *rt)
{
	XColor cc;
	PIXELTYPE pla[2], pix[2];

	*rt = 0;
	cc.red=r;		cc.green=g;		cc.blue=b;
	if ( XAllocColor (dpID, dcmap, &cc) == True ) return cc.pixel;
	if ( XAllocColorCells (dpID, dcmap, False, (unsigned long*)pla, 0, (unsigned long*)pix, 1) == True  ) {
		cc.flags=DoRed | DoGreen | DoBlue;
		XStoreColor (dpID, dcmap, &cc);
		return cc.pixel;
	}
	*rt = 1;
	return WhitePixel(dpID, 0);
}
#endif

#ifdef NEC
static char colname[8][8] = { "black"  , "blue"   , "red"    , "magenta",
							  "green"  , "cyan"   , "gold" , "white"    };
static void set_basiccolor(void)
{
	int  rt=0, i=0, colnum=8;

#else

static void set_basiccolor()
{
	int  i, rt=0, colnum=8;
	char *colname[] = { "black"  , "blue"   , "red"    , "magenta",
						"green"  , "cyan"   , "gold" , "white"    };
#endif

	for (i=0; i<colnum; i++) {
#ifdef GTK
		colplt[i].blue=0xffff*(i%2);
		colplt[i].red=0xffff*((i/2)%2);
		colplt[i].green=0xffff*(i/4);
		if (i==6) colplt[i].green=0xc0ff;

//		gdk_colormap_alloc_color(dcmap,&gkbcolor[i],FALSE,TRUE);
		gdk_color_alloc(dcmap,&colplt[i]);
#else
		colplt[i] = color_from_name(colname[i], &rt);
#endif
		if (rt) break;
	}
	colplt[8]=colplt[0];
	colplt[9]=colplt[7];
	if ( i<colnum ) fprintf(stderr,"Color Allocation Error -- Basic Color !!!\n");
}

/***********************************************
*			convert hls to rgb
	<arguments>
		fh : hue
		fl : lightness
		fs : saturation
		ir : red   intensity (0-65535)
		ig : green intensity (0-65535)
		ib : blue  intensity (0-65535)

	<remarks>
	  values must be in the range as follows.
		0 <= fh <= 360
		0 <= fs <= 1
		0 <= fl <= 1
		0 <= fr <= 1
		0 <= fg <= 1
		0 <= fb <= 1

		hue:		0=red, 120=green, 240=blue
		saturation:	0=black, 1=color
		lightness:	0=black, 1=white

	coded by sakagami,h. ( isr ) 88/02/10
	modified into C by T. Taguchi 97/07/16
***********************************************/

/*  Real number version  0<=fh<=360   0<=fl,fs<=1
#define weps 		1.0e-3
#define rgbmax 		65535.999
static void hls2rgb(double fh,double fl,double fs,int *ir,int *ig,int *ib)
{
	double w1,w2,wh;

	if ( fl <= 0.5 ) w2 = fl*(1.0+fs);
				else w2 = fl+fs-fl*fs;
	w1 = 2.0*fl-w2;

	if ( fs <= weps ) {
		*ir = fl*rgbmax;   *ig = fl*rgbmax;    *ib = fl*rgbmax;
	  }
	  else {
		wh = fh+120.0;
		if( wh > 360.0 ) wh-=360.0;
		if( wh <   0.0 ) wh+=360.0;

		*ir =rgbmax*(  wh<=60.0?  w1+(w2-w1)*wh/60.0:
					 ( wh<=180.0? w2:
					  (wh<=240.0? w1+(w2-w1)*(240.0-wh)/60.0: w1 )));

		*ig =rgbmax*(  fh<=60.0?  w1+(w2-w1)*fh/60.0:
					 ( fh<=180.0? w2:
	                   (fh<=240.0? w1+(w2-w1)*(240.0-fh)/60.0: w1 )));

		wh = fh-120.0;
		if( wh > 360.0 ) wh-=360.0;
		if( wh <   0.0 ) wh+=360.0;

		*ib =rgbmax*(  wh<=60.0?  w1+(w2-w1)*wh/60.0:
					 ( wh<=180.0? w2:
					  (wh<=240.0? w1+(w2-w1)*(240.0-wh)/60.0: w1 )));
	}
}
*/

/*  Integer number version  0<=dh<=6*2^16   0<=dl,ds<=2^16  */
#define rgbmax1		(rgbmax-1)
#define rgbmax6 	(6*rgbmax)
static void hls2rgb(int dh,int dl,int ds,int *ir,int *ig,int *ib)
{
	unsigned int w1,w2,fh,fl,fs;
	int wh;

	fh=dh;	fl=dl;	fs=ds;
//	if ( fl < rgbmax/2 ) w2 = fl*(rgbmax+fs)/rgbmax;
//				else     w2 = rgbmax1-(rgbmax-fs)*(rgbmax-fl)/rgbmax;
	if ( fl < rgbmax/2 ) w2 = fl + fs*fl/rgbmax1;
				else     w2 = fl + fs*(rgbmax1-fl)/rgbmax1;
	w1 = 2*fl-w2;

	if ( fs < rgbmax/1024 ) *ir = *ig = *ib = fl;
	  else {
		wh = fh+2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ir = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
			   ( wh < 3*rgbmax? w2:
				(wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));

		*ig = (  fh <   rgbmax? w1+(w2-w1)*fh/rgbmax:
			   ( fh < 3*rgbmax? w2:
				(fh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-fh)/rgbmax: w1 )));

		wh = fh-2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ib = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
			   ( wh < 3*rgbmax? w2:
				(wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));
	}
}
/*
myhandler(Display *d,XErrorEvent *err)
{
	char msg[80];
	XGetErrorText(d,err->error_code,msg,80);
	fprintf(stderr,"Error code --%s--\n",msg);
}
  ...    XSetErrorHandler(myhandler);
*/

/***********************************************
*   Set 256 color by linear interporation
***********************************************/
static void check_Xserver()
{
/*	PIXELTYPE pix;
	Status result;	*/
	Screen *s;
	Visual *vis;
	        
	dp_cells=DisplayCells(dpID,0);
	dp_planes=DisplayPlanes(dpID,0);
	dp_depth=DefaultDepth(dpID,0);
	vis=DefaultVisual(dpID,0);
	dp_class=vis->class;

#ifndef GTK
#ifdef TOOLKIT
	if (TGMODE) s=XtScreen(xframes);
	  else {
#endif
		s=XScreenOfDisplay(dpID,0);
#ifdef TOOLKIT
	}
#endif

	dp_mincmap=MinCmapsOfScreen(s);
	dp_maxcmap=MaxCmapsOfScreen(s);
#endif

	max_colors=(dp_depth<=8?dp_cells:1<<dp_depth);
	max_acolors=(dp_depth<=8?max_colors-8:max_colors);
	if (max_acolors>BASE_NPIXEL) max_acolors=BASE_NPIXEL;
	if (dp_depth!=1) {
		switch (dp_class) {
			case PseudoColor:
			case GrayScale:
			case DirectColor:
				true_color=0;
				break;
			case TrueColor:
				true_color=1;
		}
	}
/*
	if (dp_depth!=1) {
		switch (dp_class) {
			case PseudoColor:
			case GrayScale:
			case DirectColor:
				result=XAllocColorCells (dpID, dcmap, False, NULL, 0, &pix, 1);
				if (result) {
					XFreeColors(dpID, dcmap, &pix, 1, 0);
					dp_ncolor=pix;
				  }
				  else dp_ncolor=0;
				printf("%d \n",dp_ncolor);
				break;
			case TrueColor:		dp_ncolor=0;
		}
	}
*/

#ifdef XSERVER_CHECK
	printf("cells=%d   planes=%d   depth=%d   used colors=%d\n",dp_cells,dp_planes,dp_depth,dp_ncolor);
	if (dp_depth==1) printf("B/W\n");
		else {
			switch (dp_class) {
				case PseudoColor:	printf("PseudoColor\n");	break; 
				case GrayScale:		printf("GrayScale\n");		break; 
				case DirectColor:	printf("DirectColor\n");	break; 
				case TrueColor:		printf("TrueColor\n");		break; 
			}
	}
	printf("MinCmaps=%d   MaxCmaps=%d\n",dp_mincmap,dp_maxcmap);
#endif
}

#ifndef GTK
static void set_colormap(void)
{
	char index[256];
	int i,j,c,k,ii,jj,kk,dpn,cnm,kkk,nc,mc;
	int hue,lig,sat;
	XColor cc;

	if (cmap==0) {
		cmap=XCreateColormap(dpID,RootWindow(dpID,0),DefaultVisual(dpID,0),AllocAll);
	}

	if (cwin->lpixels == NULL) {
		if (cwin->lpixels != NULL) free(cwin->lpixels);
		cwin->lpixels = (PIXELTYPE *)malloc(sizeof(PIXELTYPE)*BASE_NPIXEL);
	}

	if (color_num>max_acolors) cnm=max_acolors;
		else cnm=color_num;

/*		for (i=0;i<dp_ncolor;i++) {	*/
	for (i=0;i<max_acolors;i++) {
		cc.pixel=i;
		XQueryColor(dpID,dcmap,&cc);
		cc.flags=DoRed | DoGreen | DoBlue;
		XStoreColor(dpID, cmap, &cc);
	}
/*
	if (dp_ncolor+cnm>max_acolors) dpn=max_acolors-cnm;
		else dpn=dp_ncolor;
*/
	for (i=0;i<256;i++) index[i]=0;
	for (c=0;c<8;c++) index[colplt[c]]=1;

	if (dp_mode==1) {
		mc=color_num-1;
		if (mc<1) mc=1;
		for (i=0,c=max_colors,kkk=-1;i<color_num;i++) {
			k = i*cnm/color_num;
			if (k!=kkk) {
				hue = (shmin0+i*(shmax0-shmin0)/mc)%rgbmax6;
				lig =  slmin0+i*(slmax0-slmin0)/mc;
				sat =  ssmin0+i*(ssmax0-ssmin0)/mc;
				if( hue<0 ) hue+=rgbmax6;
				if (lig<0) lig=0;
					else if (lig>rgbmax1) lig=rgbmax1;
				if (sat<0) sat=0;
					else if (sat>rgbmax1) sat=rgbmax1;
				hls2rgb(hue,lig,sat,&ii,&jj,&kk);
				cc.red=ii;		cc.green=jj;		cc.blue=kk;
				while (index[--c]) Nothing;
				cc.pixel=c;
				cc.flags=DoRed | DoGreen | DoBlue;
				XStoreColor(dpID, cmap, &cc);
				kkk=k;
			}
			cwin->lpixels[i]=cc.pixel;
		}
	  }
	  else {
		mc=dp_div[0]-1;
		if (mc<1) mc=1;
		for (i=j=nc=0,c=max_colors,kkk=-1;i<color_num;i++,j++) {
			k = i*cnm/color_num;
			while (j>=dp_div[nc]) {
				nc++;	j=1;
				mc=dp_div[nc]-1;		/*	dp_div[nc]>=2	*/
			}
			if (k!=kkk) {
				hue = (dp_sh[nc]+j*(dp_sh[nc+1]-dp_sh[nc])/mc)%rgbmax6;
				lig =  dp_sl[nc]+j*(dp_sl[nc+1]-dp_sl[nc])/mc;
				sat =  dp_ss[nc]+j*(dp_ss[nc+1]-dp_ss[nc])/mc;
				if( hue<0 ) hue+=rgbmax6;
				if (lig<0) lig=0;
					else if (lig>rgbmax1) lig=rgbmax1;
				if (sat<0) sat=0;
					else if (sat>rgbmax1) sat=rgbmax1;
				hls2rgb(hue,lig,sat,&ii,&jj,&kk);
				cc.red=ii;		cc.green=jj;		cc.blue=kk;
				while (index[--c]) Nothing;
				cc.pixel=c;
				cc.flags=DoRed | DoGreen | DoBlue;
				XStoreColor(dpID, cmap, &cc);
				kkk=k;
			}
			cwin->lpixels[i]=cc.pixel;
		}
	}
}
#endif

static void alloc_colors(void)
{
	int i,j,k,ii,jj,kk,cnm,kkk,nc,mc;
	int hue,sat,lig;
#ifdef GTK
	GdkColor cc;
#else
	XColor cc;
#endif
	double *sh0;
	int *mode0;

#ifdef GTK
	if (cmap==NULL) cmap=dcmap;
#else
	if (cmap==0) cmap=dcmap;
#endif

/*	printf("win current_hlstable = %d\n",current_hlstable);		*/
#ifdef WINLIB
	for (i=0;i<def_colmap;i++) {
		if (gcmapnum[i]==current_hlstable) {
			cwin->pixels=&gpixels[gpixpt[i]];
			cwin->ccmap=i;
			return;
		}
	}

	if (color_num>max_acolors) cnm=max_acolors;
		else cnm=color_num;

	if (max_colmap<0) {
		if (gpixels != NULL) free(gpixels);
		max_colmap=0;
		max_gpixels=BASE_NPIXEL;
#ifdef GTK
		gpixels = (GdkColor *)malloc(sizeof(GdkColor)*max_gpixels);
#else
		gpixels = (PIXELTYPE *)malloc(sizeof(PIXELTYPE)*max_gpixels);
#endif
	  }
	  else if (max_colmap+cnm>max_gpixels) {
		max_gpixels+=BASE_NPIXEL;
#ifdef GTK
		gpixels = (GdkColor *)realloc(gpixels, sizeof(GdkColor)*max_gpixels);
#else
		gpixels = (PIXELTYPE *)realloc(gpixels, sizeof(PIXELTYPE)*max_gpixels);
#endif
		for (i=0;i<def_colmap;i++) {
			if (gcmapnum[i]>=MINSPHERECOL && gcmapnum[i]<MAXSPHERECOL) {
				gsphept[gcmapnum[i]-MINSPHERECOL]=&gpixels[gpixpt[i]];
			}
		}
	}

	cwin->ccmap=def_colmap;
	gcmapnum[def_colmap]=current_hlstable;
	gpixpt[def_colmap++]=max_colmap;
	cwin->pixels=&gpixels[max_colmap];
	max_colmap+=cnm;
	if (current_hlstable>=MINSPHERECOL 
			&& current_hlstable<MAXSPHERECOL) gsphept[current_hlstable-MINSPHERECOL]=cwin->pixels;
#else
	if (current_hlstable>=0) {
		for (i=0;i<def_colmap;i++) {
			if (gcmapnum[i]==current_hlstable) {
				cwin->pixels=&gpixels[gpixpt[i]];
				cwin->ccmap=i;
				return;
			}
		}
	}

	if (color_num>max_acolors) cnm=max_acolors;
		else cnm=color_num;

	if (max_colmap<0) {
		if (gpixels != NULL) free(gpixels);
		max_colmap=0;
		max_gpixels=BASE_NPIXEL;
#ifdef GTK
		gpixels = (GdkColor *)malloc(sizeof(GdkColor)*max_gpixels);
#else
		gpixels = (PIXELTYPE *)malloc(sizeof(PIXELTYPE)*max_gpixels);
#endif
	  }
	  else if (max_colmap+cnm>max_gpixels) {
		max_gpixels+=BASE_NPIXEL;
#ifdef GTK
		gpixels = (GdkColor *)realloc(gpixels, sizeof(GdkColor)*max_gpixels);
#else
		gpixels = (PIXELTYPE *)realloc(gpixels, sizeof(PIXELTYPE)*max_gpixels);
#endif
		for (i=0;i<def_colmap;i++) {
			if (gcmapnum[i]>=MINSPHERECOL && gcmapnum[i]<MAXSPHERECOL) {
				gsphept[gcmapnum[i]-MINSPHERECOL]=&gpixels[gpixpt[i]];
			}
		}
	}

	cwin->ccmap=def_colmap;
	if (def_colmap>=MAXCOLMAPS) {
		if (gpixels != NULL) free(gpixels);
		max_colmap=0;
		max_gpixels=BASE_NPIXEL;
#ifdef GTK
		gpixels = (GdkColor *)malloc(sizeof(GdkColor)*max_gpixels);
#else
		gpixels = (PIXELTYPE *)malloc(sizeof(PIXELTYPE)*max_gpixels);
#endif
		def_colmap=0;
	}
	gcmapnum[def_colmap]=current_hlstable;
	gpixpt[def_colmap++]=max_colmap;
	cwin->pixels=&gpixels[max_colmap];
	max_colmap+=cnm;
	if (current_hlstable>=MINSPHERECOL 
			&& current_hlstable<MAXSPHERECOL) gsphept[current_hlstable-MINSPHERECOL]=cwin->pixels;
#endif

/*		printf("ccmap=%d   max_colmap=%d   Ncolmap=%d\n",cwin->ccmap,max_colmap,cnm);		*/

	if (dp_mode==1) {
		mc=color_num-1;
		if (mc<1) mc=1;
		for (i=0,kkk=-1;i<color_num;i++) {
			k = i*cnm/color_num;
			if (k!=kkk) {
				hue = (shmin0+i*(shmax0-shmin0)/mc)%rgbmax6;
				lig =  slmin0+i*(slmax0-slmin0)/mc;
				sat =  ssmin0+i*(ssmax0-ssmin0)/mc;
				if( hue<0 ) hue+=rgbmax6;
				if (lig<0) lig=0;
					else if (lig>rgbmax1) lig=rgbmax1;
				if (sat<0) sat=0;
					else if (sat>rgbmax1) sat=rgbmax1;
				hls2rgb(hue,lig,sat,&ii,&jj,&kk);
				cc.red=ii;		cc.green=jj;		cc.blue=kk;
#ifdef GTK
				gdk_color_alloc(cmap,&cc);
#else
				XAllocColor(dpID, cmap, &cc);
#endif
				kkk=k;
			}
			huesave[i]=hue;
			ligsave[i]=lig;
			satsave[i]=sat;
#ifdef GTK
			cwin->pixels[i]=cc;
#else
			cwin->pixels[i]=cc.pixel;
#endif
		}
	  }
	  else {
		mc=dp_div[0]-1;
		if (mc<1) mc=1;
		for (i=j=nc=0,kkk=-1;i<color_num;i++,j++) {
			k = i*cnm/color_num;
			while (j>=dp_div[nc]) {
				nc++;	j=1;
				mc=dp_div[nc]-1;		/*	dp_div[nc]>=2	*/
			}
			if (k!=kkk) {
				hue = (dp_sh[nc]+j*(dp_sh[nc+1]-dp_sh[nc])/mc)%rgbmax6;
				lig =  dp_sl[nc]+j*(dp_sl[nc+1]-dp_sl[nc])/mc;
				sat =  dp_ss[nc]+j*(dp_ss[nc+1]-dp_ss[nc])/mc;
				if( hue<0 ) hue+=rgbmax6;
				if (lig<0) lig=0;
					else if (lig>rgbmax1) lig=rgbmax1;
				if (sat<0) sat=0;
					else if (sat>rgbmax1) sat=rgbmax1;
				hls2rgb(hue,lig,sat,&ii,&jj,&kk);
				cc.red=ii;		cc.green=jj;		cc.blue=kk;
#ifdef GTK
				gdk_color_alloc(cmap,&cc);
#else
				XAllocColor(dpID, cmap, &cc);
#endif
				kkk=k;
			}
			huesave[i]=hue;
			ligsave[i]=lig;
			satsave[i]=sat;
#ifdef GTK
			cwin->pixels[i]=cc;
#else
			cwin->pixels[i]=cc.pixel;
#endif
//			printf("%d %ld\n",i,cc.pixel);
		}
	}
}
#endif

#ifndef NOX
/***********************************************
*    Return Window ID
***********************************************/
int window_idnumber(void)
{
	int cn;

#ifdef GTK
	cn = GDK_WINDOW_XWINDOW(cwin->win);
#else
	cn = cwin->win;
#endif
	return cn;
}

/***********************************************
*    Save Drawed Picture
***********************************************/
void finish_drawframes(void)
{
#ifdef GTK
	GdkRectangle rect;

	rect.x=rect.y=0;
	rect.width=cwin->width;
	rect.height=cwin->height;
	gtk_widget_draw(cwin->area,&rect);					//	Expose event
#else
	XEvent ev;

	if (cwin->draw_mode==0) return;
	XFlush(dpID);
	if (display_mode) {
		XCopyArea (dpID, cwin->pix, cwin->win, cwin->gc, 0, 0, cwin->width, cwin->height, 0, 0);
	  }
	  else {
		XCopyArea (dpID, cwin->win, cwin->pix, cwin->gc, 0, 0, cwin->width, cwin->height, 0, 0);
	}

	while (1) {
#ifdef TOOLKIT
		if (TGMODE) XtAppNextEvent(app_con,&ev);
		  else {
#endif
			XNextEvent(dpID, &ev);
#ifdef TOOLKIT
	}
#endif
/*		printf("%d %d %d\n",NoExpose,GraphicsExpose,Expose);
		printf("ev %d\n",ev.type);	*/
		switch (ev.type) {
			case NoExpose:
			case GraphicsExpose:
								return;

#ifdef TOOLKIT
			case Expose:		if (ev.xany.window==cwin->win) break;
			default:			XtDispatchEvent(&ev);
#endif
		}
	}
#endif
}

static void make_pixmap(FRAMESWINDOW *cw)
{
#ifdef GTK
	static int init=0;
//	if (init) return;
	if (cw->pix) gdk_pixmap_unref (cw->pix);
//	printf("make_pixmap %d %d\n", cw->width, cw->height);
	if (cw->area==NULL) {
		cw->area = framesarea;
		cw->win = framesarea->window;
	}
	cw->pix=gdk_pixmap_new(cw->win, cw->width, cw->height, -1);
	init=1;
//	gdk_gc_set_foreground(cw->gc, &(cw->bcolor[0]));
//	gdk_draw_rectangle(cw->pix, cw->gc,TRUE,0,0, cw->width, cw->height);
#else
	if (cw->pix) XFreePixmap (dpID, cw->pix);
	cw->pix = XCreatePixmap (dpID, cw->win, cw->width, cw->height, DefaultDepth(dpID, 0));
	XSetForeground (dpID, cw->gc, cw->bcolor[0]);
	XFillRectangle (dpID, cw->pix, cw->gc, 0, 0, cw->width, cw->height);
#endif
	if (display_mode) cw->drw=cw->pix;
}

#ifdef GTK

static int init_configure=0;

gint configure_event(GtkWidget *widget, GdkEventConfigure *event, gint *data)
{

//	printf("configure %d %x\n",init_configure,cwin);
	if (init_configure) return TRUE;
	if (cwin->pix) {
		gdk_pixmap_unref(cwin->pix);
		cwin->pix=NULL;
	}

	cwin->width  = widget->allocation.width;
	cwin->height = widget->allocation.height;
	set_magnification(cwin);
	make_pixmap(cwin);
//	redraw_pics(cwin);
	update_frame(cwin->area);
	init_configure=1;
	return TRUE;
}

gint expose_event(GtkWidget *widget, GdkEventExpose *event, gint *data)
{
//	printf("expose\n");
	if (cwin->pix) {
		gdk_draw_pixmap(widget->window,
					widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
					cwin->pix,
					event->area.x,event->area.y,
					event->area.x,event->area.y,
					event->area.width,event->area.height);
	}
	return FALSE;
}

#else
static int configure_frames(FRAMESWINDOW *cw, XConfigureEvent ev)
{
#ifndef TOOLKIT
	int format, *data;
	Atom type;
	unsigned long nitems, left;

	if (cw->win != ev.window) {
		XGetWindowProperty (dpID, ev.window, num_frames, 0, 1, False, XA_INTEGER
											, &type, &format, &nitems, &left, (void *)&data);
		cw = frwin[*data];
	}
#endif
	if (cw->width==ev.width && cw->height==ev.height) return 0;
	  else {
		border_width = ev.border_width;
		cw->width  = ev.width;
		cw->height = ev.height;
		set_magnification(cw);
		make_pixmap(cw);
		redraw_pics(cw);
		return 1;
	}
}

static void expose_frames(FRAMESWINDOW *cw, XExposeEvent ev)
{
#ifndef TOOLKIT
	int format, *data;
	Atom type;
	unsigned long nitems, left;

	if (cw->win != ev.window) {
		XGetWindowProperty (dpID, ev.window, num_frames, 0, 1, False, XA_INTEGER
											, &type, &format, &nitems, &left, (void *)&data);
		cw = frwin[*data];
	}
#endif
	if (cw->draw_mode) {
		XCopyArea (dpID, cw->pix, cw->win, cw->gc, 
							ev.x,ev.y,ev.width,ev.height,ev.x,ev.y);
	}
}
#endif

/***********************************************
*    Read from buffer
***********************************************/
static int increasebuf(FRAMESWINDOW *cw)
{
	int nb=cw->bfmmax;
	char **gbuf;

	cw->bfmmax+=ONEBUFFER;
	gbuf=(char **)realloc(cw->grbuf,sizeof(char *)*(cw->bfmmax));
	if (gbuf==NULL) {
		cw->bfmmax=nb;
		return -1;
	}
	cw->grbuf=gbuf;
/*	if (nb>0) printf("increse buffer to %d\n",cw->bfmmax);	*/

	return 0;
}

static int bufreadshort(int *mad, int *sad)
{
	int  rt;

#ifdef SETSHORT
	if (*sad >= BFSMAX) {
		*sad = 0;		(*mad)++;
	}
	rt = (int)( *( (short *)&(dwin->grbuf[ *mad ][ *sad ]) ) );
#else
	char *add;
	union _integs_ { short x; char b[2]; } add1;

	if (*sad >= BFSMAX) {
		*sad = 0;		(*mad)++;
	}
	add = dwin->grbuf[ *mad ];
	add1.b[0] = add[ *sad ];
	add1.b[1] = add[ *sad+1 ];
	rt = add1.x;
#endif
	*sad += sizeof(short);
	return rt;
}

static int bufreadint(int *mad, int *sad)
{
	int  rt;

	char *add;
	union _integ_ { signed int x; char b[4]; } add1;

	if (*sad >= IFSMAX) {
		*sad = 0;		(*mad)++;
	}
	add = dwin->grbuf[ *mad ];
	add1.b[0] = add[ *sad ];
	add1.b[1] = add[ *sad+1 ];
	add1.b[2] = add[ *sad+2 ];
	add1.b[3] = add[ *sad+3 ];
	rt = add1.x;
	*sad += sizeof(int);
	return rt;
}

static int bufreadchar(int *mad, int *sad)
{
	int  rt;

	if (*sad >= MAXMEMSIZE) {
		*sad = 0;		(*mad)++;
	}
	rt = (int)( dwin->grbuf[ *mad ][ *sad ] );
	*sad += sizeof(char);
	return rt;
}

/***********************************************
*    Re-draw routine
***********************************************/
#ifdef GTK
static GdkGC			*gcID;
static GdkDrawable		*drwID;
#else
static GC			gcID;
static Drawable		drwID;
#endif

/*
static int isqrt(unsigned int x)
{
	unsigned int s,t;
	if (x==0) return 0;
	s=1;	t=x;
	while (s<t) { s<<=1;	t>>=1;  }
	do {
		t=s;
		s=(x/s+s)>>1;
	} while (s<t);
	return t;
}
*/
static void grad_fill_rectangle(int xs,int ys,int xe,int ye,int icn0,int icn1,int icn2,int icn3)
{
	double a,b,c,d1,d2;
	int x,y,ff,cn;

	a=b=c=0;
	if (xs!=xe) {
	  	b=((double)(icn2-icn0))/(xe-xs);
		if (ys!=ye) {
	  		c=((double)(icn1-icn0))/(ye-ys);
			a=((double)(icn3+icn0-icn2-icn1))/((xe-xs)*(ye-ys));
		}
	  }
	  else if (ys!=ye) {
		c=((double)(icn1-icn0))/(ye-ys);
	}

	for (y=ys;y<=ye;y++) {
		d1=a*(y-ys)+b;		d2=c*(y-ys)+icn0;
		for (x=xs;x<=xe;x++) {
			ff=d1*(x-xs)+d2;
			if (ff<0) ff=0;
			cn=(ff>>16);
//			if (cn>=color_num) cn=color_num-1;
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, x, y);
#endif
		}
	}
}

static void put_graddot(int x, int y, int xc, int yc, int cn2, double dcn)
{
	double rr;
	int cn;
	rr=sqrt((double)(xc*xc+yc*yc));
	cn=(cn2-dcn*rr);
//	cn+=(cwin->bpixel);
#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
	gdk_draw_point (cwin->drw, cwin->gc, x, y);
#else
	XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
	XDrawPoint (dpID, cwin->drw, cwin->gc, x, y);
#endif
}

static void put_gradcircle_peri( int xx, int yy, int x1, int y1, int xc, int yc, int cn2, double dcn)
{
	put_graddot( xx + x1, yy + y1 , x1-xc, y1-yc, cn2, dcn);
	put_graddot( xx - x1, yy + y1 , x1+xc, y1-yc, cn2, dcn);
	put_graddot( xx + x1, yy - y1 , x1-xc, y1+yc, cn2, dcn);
	put_graddot( xx - x1, yy - y1 , x1+xc, y1+yc, cn2, dcn);
	put_graddot( xx + y1, yy + x1 , y1-xc, x1-yc, cn2, dcn);
	put_graddot( xx - y1, yy + x1 , y1+xc, x1-yc, cn2, dcn);
	put_graddot( xx + y1, yy - x1 , y1-xc, x1+yc, cn2, dcn);
	put_graddot( xx - y1, yy - x1 , y1+xc, x1+yc, cn2, dcn);
}

static void grad_fill_circle(int xx,int yy,int dr,int ic)
{
	int x1,y1,p,r;
	int x,y,y2,cn,xc,yc,cn1,cn2;
	double dcn,rr;

	if (ic<=0) {
		cn1=color_num*0.05;			cn2=color_num*0.95;
	  }
	  else {
//		cn1=(ic-1)*SPHERECOLNUM;	cn2=cn1+(SPHERECOLNUM-1);
		cwin->pixels=gsphept[ic-1];
		cn1=0;						cn2=SPHERECOLNUM-1;
	}
	dcn = 6*(cn2-cn1)/((double)dr*5);

	xc=dr/6;	yc=-dr/6;	r=dr/2;
	x1 = 0;
	y1 = r;
	p  = 3-(r<<1);
	while ( x1 < y1 ) {
		for (x=-y1, y=yy+x1, y2=(x1-yc)*(x1-yc); x<=y1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
		for (x=-y1, y=yy-x1, y2=(x1+yc)*(x1+yc); x<=y1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
		for (x=-x1, y=yy-y1, y2=(y1+yc)*(y1+yc); x<=x1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
		for (x=-x1, y=yy+y1, y2=(y1-yc)*(y1-yc); x<=x1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
		if ( p < 0 ) p += (x1<<2)+6;
		  else {
			p += ((x1-y1)<<2)+10;
			y1--;
		}
		x1++;
	}
	if ( x1 == y1 ) {
		for (x=-x1, y=yy-y1, y2=(y1+yc)*(y1+yc); x<=x1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
		for (x=-x1, y=yy+y1, y2=(y1-yc)*(y1-yc); x<=x1; x++) {
			rr=sqrt((double)((x-xc)*(x-xc)+y2));
			cn=(cn2-dcn*rr);
//			cn+=(cwin->bpixel);
#ifdef GTK
			gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
			gdk_draw_point (cwin->drw, cwin->gc, xx+x, y);
#else
			XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
			XDrawPoint (dpID, cwin->drw, cwin->gc, xx+x, y);
#endif
		}
	}
	if (r == 6) put_gradcircle_peri( xx, yy, x1, y1+1, xc, yc, cn2, dcn);
	if (r == 5) put_gradcircle_peri( xx, yy, x1, x1 ,xc, yc, cn2, dcn);
}

//grad_color_setting(int color, int grad)
void grad_color_setting(int color, int grad, int *rr, int *gg, int *bb)
{
	int lig,sat;
#ifdef GTK
	GdkColor cc;
#else
	XColor cc;
#endif

	lig=ligsave[color]*(grad)/32;
	if (lig>rgbmax1) lig=rgbmax1;
	sat=satsave[color];
	hls2rgb(huesave[color],lig,sat,rr,gg,bb);
//	hls2rgb(huesave[color],ligsave[color],lig,rr,gg,bb);
	cc.red=*rr;		cc.green=*gg;		cc.blue=*bb;
#ifdef GTK
	gdk_color_alloc(cmap,&cc);
	gdk_gc_set_foreground(cwin->gc, &cc);
#else
	XAllocColor(dpID, cmap, &cc);
	XSetForeground (dpID, cwin->gc, cc.pixel);
#endif
}

void set_grad_color(int rr, int gg, int bb)
{
#ifdef GTK
	GdkColor cc;
#else
	XColor cc;
#endif

	cc.red=rr;		cc.green=gg;		cc.blue=bb;
#ifdef GTK
	gdk_color_alloc(cmap,&cc);
	gdk_gc_set_foreground(cwin->gc, &cc);
#else
	XAllocColor(dpID, cmap, &cc);
	XSetForeground (dpID, cwin->gc, cc.pixel);
#endif
}

#ifdef GTK
static void drawptsb(GdkPoint *pxy, int *pn)
{
	gdk_draw_points(drwID, gcID, pxy, *pn);
	*pn = 0;
}

static void drawlnsb(GdkSegment *lxy, int *ln)
{
	gdk_draw_segments(drwID, gcID, lxy, *ln);
	*ln = 0;
}

static void drawflnsb(GdkPoint *pfxy, int *pfn)
{
	gdk_draw_polygon(drwID, gcID, TRUE, pfxy, *pfn);
	*pfn = 0;
}

static void drawcrsb(GdkArc *cxy, int *cn)
{
	int i;
	for (i=0;i<*cn;i++) {
		gdk_draw_arc (drwID, gcID, FALSE, cxy[i].x, cxy[i].y, 
						cxy[i].width, cxy[i].height, cxy[i].angle1, cxy[i].angle2);
	}
	*cn = 0;
}

static void drawcrflsb(GdkArc *cxy, int *cn)
{
	int i;
	for (i=0;i<*cn;i++) {
		gdk_draw_arc (drwID, gcID, TRUE, cxy[i].x, cxy[i].y, 
						cxy[i].width, cxy[i].height, cxy[i].angle1, cxy[i].angle2);
	}
	*cn = 0;
}

static void drawcrgflsb(GdkArc *cxy, int *cn)
{
	int i;
	for (i=0;i<*cn;i++) {
		grad_fill_circle(cxy[i].x,cxy[i].y,cxy[i].width,cxy[i].angle1);
	}
	*cn = 0;
}

static void drawbxsb(GdkRectangle *bxy, int *bn)
{
	int i;
	for (i=0;i<*bn;i++) {
		gdk_draw_rectangle(drwID, gcID, FALSE, bxy[i].x, bxy[i].y, bxy[i].width, bxy[i].height);
	}
	*bn = 0;
}

static void drawbxflsb(GdkRectangle *bxy, int *bn)
{
	int i;
	for (i=0;i<*bn;i++) {
		gdk_draw_rectangle(drwID, gcID, TRUE, bxy[i].x, bxy[i].y, bxy[i].width, bxy[i].height);
	}
	*bn = 0;
}

#else
static void drawptsb(XPoint *pxy, int *pn)
{
	XDrawPoints(dpID, drwID, gcID, pxy, *pn, CoordModeOrigin);
	*pn = 0;
}

static void drawlnsb(XSegment *lxy, int *ln)
{
	XDrawSegments(dpID, drwID, gcID, lxy, *ln);
	*ln = 0;
}

static void drawflnsb(XPoint *pfxy, int *pfn)
{
	XFillPolygon(dpID, drwID, gcID, pfxy, *pfn, polyshape, CoordModeOrigin);
	*pfn = 0;
}

static void drawcrsb(XArc *cxy, int *cn)
{
	XDrawArcs(dpID, drwID, gcID, cxy, *cn);
	*cn = 0;
}

static void drawcrflsb(XArc *cfxy, int *cfn)
{
	XFillArcs(dpID, drwID, gcID, cfxy, *cfn);
	*cfn = 0;
}

static void drawcrgflsb(XArc *cfxy, int *cfn)
{
	int i;
	for (i=0;i<*cfn;i++) {
		grad_fill_circle(cfxy[i].x,cfxy[i].y,cfxy[i].width,cfxy[i].angle1);
	}
	*cfn = 0;
}

static void drawbxsb(XRectangle *bxy, int *bn)
{
	XDrawRectangles(dpID, drwID, gcID, bxy, *bn);
	*bn = 0;
}

static void drawbxflsb(XRectangle *bfxy, int *bfn)
{
	XFillRectangles(dpID, drwID, gcID, bfxy, *bfn);
	*bfn = 0;
}
#endif

static void finish_drawsb(FRAMESWINDOW *cw)
{
	if (cw->draw_mode==0) return;
#ifdef GTK
	update_frame(cw->area);
#else
	XFlush(dpID);
	if (display_mode) {
		XCopyArea (dpID, cw->pix, cw->win, cw->gc, 0, 0, cw->width, cw->height, 0, 0);
	  }
	  else {
		XCopyArea (dpID, cw->win, cw->pix, cw->gc, 0, 0, cw->width, cw->height, 0, 0);
	}
#endif
}

static void redraw_pics(FRAMESWINDOW *cw)	/* Drawing window ID or Pixmap ID */
{
#ifdef GTK
	GdkSegment   lxy[NGBUFFER];
	GdkArc       cxy[NGBUFFER], cfxy[1], cgfxy[1];
	GdkPoint     pxy[NGBUFFER], pfxy[1024];
	GdkRectangle bxy[NGBUFFER], bfxy[1];
#else
	XSegment   lxy[NGBUFFER];
	XArc       cxy[NGBUFFER], cfxy[1], cgfxy[1];
	XPoint     pxy[NGBUFFER], pfxy[1024];
	XRectangle bxy[NGBUFFER], bfxy[1];
#endif
	char       chr[NCHRBUFFER];
	int  ln=0, cn=0, pn=0, bn=0, cfn=0, cgfn=0, bfn=0, pfn=0;
	int  mode, x0, y0, x1, y1, rx, ry, dx, dy, color, grad, rr, gg, bb;
	int  mad=0, sad=0, wfont=cw->fontwidth, hfont=cw->fontheight;
	int  i, cnt, icn[4];
	static int xx,yy;

	dwin = cw;
	drwID = cw->drw;
	gcID = cw->gc;
	while (1) {
		mode=bufreadchar(&mad, &sad);				/* Read buffer data */
		switch (mode) {
		case WINDRAW_END:								/* End reading */
			if (ln > 0) drawlnsb (lxy, &ln);
			if (cn > 0) drawcrsb (cxy, &cn);
			if (pn > 0) drawptsb (pxy, &pn);
			if (bn > 0) drawbxsb (bxy, &bn);
			if (cfn > 0) drawcrflsb (cfxy, &cfn);
			if (cgfn > 0) drawcrgflsb (cgfxy, &cgfn);
			if (bfn > 0) drawbxflsb (bfxy, &bfn);
#ifdef GTK
			gdk_gc_set_foreground(gcID, &(cw->bcolor[colbkup]));
#else
			XSetForeground (dpID, gcID, cw->bcolor[colbkup]);
#endif
			finish_drawsb(cw);
			return;

		case WINDRAW_DOT:							/* Dot */
			pxy[pn  ].x=(short)(xchg(bufreadshort(&mad, &sad)));
			pxy[pn++].y=(short)(ychg(bufreadshort(&mad, &sad)));
			if (pn >= NGBUFFER) drawptsb (pxy, &pn);
			break;
		case WINDRAW_DOTS:							/* Several dots */
			cnt=bufreadshort(&mad, &sad);
			for( i = 0; i < cnt; i++) {
				pxy[pn  ].x=(short)(xchg(bufreadshort(&mad, &sad)));
				pxy[pn++].y=(short)(ychg(bufreadshort(&mad, &sad)));
				if (pn >= NGBUFFER) drawptsb (pxy, &pn);
			}
			break;

		case WINDRAW_DRAW:							/* Line */
			lxy[ln  ].x1 = xx;
			lxy[ln  ].y1 = yy;
			goto line2;

		case WINDRAW_LINE:							/* Line */
			lxy[ln  ].x1 = xchg( bufreadshort(&mad, &sad) );
			lxy[ln  ].y1 = ychg( bufreadshort(&mad, &sad) );
		  line2:
			xx           = xchg( bufreadshort(&mad, &sad) );
			yy           = ychg( bufreadshort(&mad, &sad) );
			lxy[ln  ].x2 = xx;
			lxy[ln++].y2 = yy;
			if (ln >= NGBUFFER) drawlnsb (lxy, &ln);
			break;

		case WINDRAW_SEGMENTS:						/* Separate lines */
			cnt=bufreadshort(&mad, &sad);
			i = 0;
			for (i = 0; i < cnt ; i += 2 ) {
				lxy[ln  ].x1 = xchg( bufreadshort(&mad, &sad) );
				lxy[ln  ].y1 = ychg( bufreadshort(&mad, &sad) );
				lxy[ln  ].x2 = xchg( bufreadshort(&mad, &sad) );
				lxy[ln++].y2 = ychg( bufreadshort(&mad, &sad) );
				if (ln >= NGBUFFER) drawlnsb (lxy, &ln);
			}
			break;

		case WINDRAW_LINKS:							/* Linked lines */
			cnt=bufreadshort(&mad, &sad);
			lxy[ln  ].x1 = xchg( bufreadshort(&mad, &sad) );
			lxy[ln  ].y1 = ychg( bufreadshort(&mad, &sad) );
			x0           = xchg( bufreadshort(&mad, &sad) );
			y0           = ychg( bufreadshort(&mad, &sad) );
			lxy[ln  ].x2 = x0;
			lxy[ln++].y2 = y0;
			if (ln >= NGBUFFER) drawlnsb (lxy, &ln);
			for (i = 2; i < cnt ; i++ ) {
				lxy[ln  ].x1 = x0;
				lxy[ln  ].y1 = y0;
				x0           = xchg( bufreadshort(&mad, &sad) );
				y0           = ychg( bufreadshort(&mad, &sad) );
				lxy[ln  ].x2 = x0;
				lxy[ln++].y2 = y0;
				if (ln >= NGBUFFER) drawlnsb (lxy, &ln);
			}
			break;

		case WINDRAW_FILLPOLYGON:					/* Closed linked lines and Fill */
			cnt=bufreadshort(&mad, &sad);
			for( i = 0; i < cnt; i++) {
				pfxy[pfn  ].x=(short)(xchg(bufreadshort(&mad, &sad)));
				pfxy[pfn++].y=(short)(ychg(bufreadshort(&mad, &sad)));
			}
			drawflnsb (pfxy, &pfn);
			break;

		case WINDRAW_CIRCLE:						/* Circle */
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			rx= rchg( bufreadshort(&mad, &sad) );
			ry= rchg( bufreadshort(&mad, &sad) );
			cxy[cn  ].x      = (short)(x0-rx/2);
			cxy[cn  ].y      = (short)(y0-ry/2);
			cxy[cn  ].width  = (unsigned short)(rx);
			cxy[cn  ].height = (unsigned short)(ry);
			cxy[cn  ].angle1 = 0;
			cxy[cn++].angle2 = 360*64;
			if (cn >= NGBUFFER) drawcrsb (cxy, &cn);
			break;

		case WINDRAW_FILLCIRCLE:					/* Fill circle */
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			rx= rchg( bufreadshort(&mad, &sad) );
			ry= rchg( bufreadshort(&mad, &sad) );
			cfxy[cfn  ].x      = (short)(x0-rx/2);
			cfxy[cfn  ].y      = (short)(y0-ry/2);
			cfxy[cfn  ].width  = (unsigned short)(rx);
			cfxy[cfn  ].height = (unsigned short)(ry);
			cfxy[cfn  ].angle1 = 0;
			cfxy[cfn++].angle2 = 360*64;
			drawcrflsb (cfxy, &cfn);
			break;

		case WINDRAW_GRADCIRCLE:					/* Gradient fill circle */
			color= bufreadchar(&mad, &sad);
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			rx= rchg( bufreadshort(&mad, &sad) );
			cgfxy[cgfn  ].x      = (short)x0;
			cgfxy[cgfn  ].y      = (short)y0;
			cgfxy[cgfn  ].width  = (unsigned short)(rx);
			cgfxy[cgfn++].angle1 = color;
			drawcrgflsb (cgfxy, &cgfn);
			break;

		case WINDRAW_BOX:							/* Box */
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			x1= xchg( bufreadshort(&mad, &sad) );
			y1= ychg( bufreadshort(&mad, &sad) );
			bxy[bn  ].x      = x0;
			bxy[bn  ].y      = y0;
			bxy[bn  ].width  = (unsigned int)(x1-x0);
			bxy[bn++].height = (unsigned int)(y1-y0);
			if (bn >= NGBUFFER) drawbxsb (bxy, &bn);
			break;

		case WINDRAW_FILLBOX:						/* Fill box */
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			x1= xchg( bufreadshort(&mad, &sad) );
			y1= ychg( bufreadshort(&mad, &sad) );
			bfxy[bfn  ].x      = x0;
			bfxy[bfn  ].y      = y0;
			bfxy[bfn  ].width  = (unsigned int)(x1-x0);
			bfxy[bfn++].height = (unsigned int)(y1-y0);
			drawbxflsb (bfxy, &bfn);
			break;

		case WINDRAW_GRADFILLBOX:						/* Gradient fill box */
			x0= xchg( bufreadshort(&mad, &sad) );
			y0= ychg( bufreadshort(&mad, &sad) );
			x1= xchg( bufreadshort(&mad, &sad) );
			y1= ychg( bufreadshort(&mad, &sad) );
			icn[0] = bufreadint(&mad, &sad);
			icn[1] = bufreadint(&mad, &sad);
			icn[2] = bufreadint(&mad, &sad);
			icn[3] = bufreadint(&mad, &sad);
			grad_fill_rectangle(x0, y0, x1, y1,icn[0],icn[1],icn[2],icn[3]);
			break;

		case WINDRAW_CHAR:							/* Characters */
		case WINDRAW_XORCHAR:						/* XOR Characters */
			x0= bufreadshort(&mad, &sad);
			y0= bufreadshort(&mad, &sad);
			rx= bufreadshort(&mad, &sad);
			ry= bufreadshort(&mad, &sad);
			cnt=bufreadshort(&mad, &sad);
			for ( i = 0; i < cnt; i++ ) chr[i] = (char)bufreadchar(&mad, &sad);
			x1 = xchg(x0)+((rx*wfont)>>7);
			y1 = ychg(y0)+((ry*hfont)>>7);
#ifdef GTK	// fontGTK
			gdk_draw_text(drwID, fontst, gcID, x1, y1, chr, cnt);
#else
			if (mode==WINDRAW_XORCHAR) XSetFunction(dpID, gcID, GXxor);
			XDrawString(dpID, drwID, gcID, x1, y1, chr, cnt);
			if (mode==WINDRAW_XORCHAR) XSetFunction(dpID, gcID, GXcopy);
#endif
			break;

		case WINDRAW_FINECHAR:						/* Fine Position Characters */
			x0= bufreadshort(&mad, &sad);
			y0= bufreadshort(&mad, &sad);
			rx= bufreadshort(&mad, &sad);
			ry= bufreadshort(&mad, &sad);
			dx= bufreadshort(&mad, &sad);
			dy= bufreadshort(&mad, &sad);
			cnt=bufreadshort(&mad, &sad);
			for ( i = 0; i < cnt; i++ ) chr[i] = (char)bufreadchar(&mad, &sad);
			x1 = xchg(x0)+((rx*wfont)>>7)+((dx*hfont)>>7);
			y1 = ychg(y0)+((ry*hfont)>>7)+((dy*wfont)>>7);
#ifdef GTK		// fontGTK
			gdk_draw_text(drwID, fontst, gcID, x1, y1, chr, cnt);
#else
			XDrawString(dpID, drwID, gcID, x1, y1, chr, cnt);
#endif
			break;

		case WINDRAW_BASECOLMAP:						/* Base of the Current Colormap */
			cw->ccmap=bufreadint(&mad, &sad);
			if (true_color==1) {
//				printf("%d %d\n",cw->ccmap,gpixpt[cw->ccmap]);
				cw->pixels=&gpixels[gpixpt[cw->ccmap]];
			}
//			cw->bpixel =bufreadint(&mad, &sad);
			break;

		case WINDRAW_BASICCOL:						/* Basic color setting */
			if (ln > 0) drawlnsb (lxy, &ln);
			if (cn > 0) drawcrsb (cxy, &cn);
			if (pn > 0) drawptsb (pxy, &pn);
			if (bn > 0) drawbxsb (bxy, &bn);
			if (cfn > 0) drawcrflsb (cfxy, &cfn);
			if (cgfn > 0) drawcrgflsb (cgfxy, &cgfn);
			if (bfn > 0) drawbxflsb (bfxy, &bfn);
			color =bufreadchar(&mad, &sad);
#ifdef GTK
			gdk_gc_set_foreground(gcID, &(cw->bcolor[color]));
#else
			XSetForeground (dpID, gcID, cw->bcolor[color]);
#endif
			break;

		case WINDRAW_EXTENDCOL:						/* Extended color setting */
			if (ln > 0) drawlnsb (lxy, &ln);
			if (cn > 0) drawcrsb (cxy, &cn);
			if (pn > 0) drawptsb (pxy, &pn);
			if (bn > 0) drawbxsb (bxy, &bn);
			if (cfn > 0) drawcrflsb (cfxy, &cfn);
			if (cgfn > 0) drawcrgflsb (cgfxy, &cgfn);
			if (bfn > 0) drawbxflsb (bfxy, &bfn);
			color =bufreadshort(&mad, &sad);
#ifdef GTK
			gdk_gc_set_foreground(gcID, &(cw->pixels[color]));
#else
			XSetForeground (dpID, gcID, cw->pixels[color]);
#endif
			break;

		case WINDRAW_EXTEND2COL:					/* Graditent Extended color setting */
			if (ln > 0) drawlnsb (lxy, &ln);
			if (cn > 0) drawcrsb (cxy, &cn);
			if (pn > 0) drawptsb (pxy, &pn);
			if (bn > 0) drawbxsb (bxy, &bn);
			if (cfn > 0) drawcrflsb (cfxy, &cfn);
			if (cgfn > 0) drawcrgflsb (cgfxy, &cgfn);
			if (bfn > 0) drawbxflsb (bfxy, &bfn);
			rr =bufreadshort(&mad, &sad);
			gg =bufreadshort(&mad, &sad);
			bb =bufreadshort(&mad, &sad);
			set_grad_color(rr, gg, bb);
			break;

		default:							/* Undefined command */
			fprintf(stderr,"Invarid Buffer Data\n");
		}
	}
}

/***********************************************
*    Write on buffer
***********************************************/
static int buffercheck(int maxsize)			/* Check buffer capacity */
{
	if (cwin->bfsad >= maxsize) { /* Allocate new region if all memories are used */
		cwin->bfsad = 0;
		cwin->bfmad++;
		if (cwin->bfmad >= cwin->bfmmax) {
			if (increasebuf(cwin)) {
				fprintf(stderr,"Buffer Overflow buffercheck !!\n");
				return 1;
			}
		}
		cwin->grbuf[ cwin->bfmad ] = (char *)malloc(sizeof(char)*MAXMEMSIZE);
		cwin->bmap = cwin->grbuf[ cwin->bfmad ];
		if (cwin->bmap==NULL) {
			fprintf(stderr,"Buffer Overflow buffercheck !!\n");
			return 1;
		}
	}
	return 0;
}

static void bufsetshort(int ad)
{
#ifdef SETSHORT
	error_draw=buffercheck(BFSMAX);							/* Check buffer capacity */
	if (error_draw) return; 								/* Return if full buffer */
	*( (short *)&(cwin->bmap[ cwin->bfsad ]) ) = (short)ad; 	/* Write on the buffer */
	cwin->bfsad += sizeof(short);	 						/* Shift the writing point */
#else
	char *add;
	union _integs_ { short x; char b[2]; } add1;

	error_draw=buffercheck(BFSMAX);							/* Check buffer capacity */
	if (error_draw) return; 			/* Return if full buffer */
	add=cwin->bmap;		 				/* Set the first memory address which latest allocated */
	add1.x=(short)ad;
	add[ cwin->bfsad ]   = add1.b[0];
	add[ cwin->bfsad+1 ] = add1.b[1]; 	/* Write on the buffer */
	cwin->bfsad += sizeof(short);		/* Shift the writing point */
#endif
}

static void bufsetint(int ad)
{
	char *add;
	union _integ_ { signed int x; char b[4]; } add1;

	error_draw=buffercheck(IFSMAX);		/* Check buffer capacity */
	if (error_draw) return; 			/* Return if full buffer */
	add=cwin->bmap;		 				/* Set the first memory address which latest allocated */
	add1.x=(int)ad;
	add[ cwin->bfsad ]   = add1.b[0];
	add[ cwin->bfsad+1 ] = add1.b[1]; 	/* Write on the buffer */
	add[ cwin->bfsad+2 ] = add1.b[2];
	add[ cwin->bfsad+3 ] = add1.b[3]; 	/* Write on the buffer */
	cwin->bfsad += sizeof(int);		/* Shift the writing point */
}

static void bufsetchar(int ad)
{
	error_draw=buffercheck(MAXMEMSIZE);			/* Check buffer capacity */
	if (error_draw) return; 					/* Return if full buffer */
	cwin->bmap[ cwin->bfsad ] = (char)ad;
	cwin->bfsad += sizeof(char);
}

static void bufsetbytes(char *chr, int n)
{
	int i;

	for (i=0;i<n;i++) {
		error_draw=buffercheck(MAXMEMSIZE);		/* Check buffer capacity */
		if (error_draw) return; 				/* Return if full buffer */
		cwin->bmap[ cwin->bfsad ] = *chr++;
		cwin->bfsad += sizeof(char);
	}
}

static void bufputchar(int ad)		/* This routine does not shift the writing position */
{
	error_draw=buffercheck(MAXMEMSIZE);			/* Check buffer capacity */
	if (error_draw) return; 					/* Return if full buffer */
	cwin->bmap[ cwin->bfsad ] = (char)ad;
}

/***********************************************
*    Clear buffer
***********************************************/
static void bufclear(void)
{
	int i;

	for(i = 0; i <= cwin->bfmad; i++) free( cwin->grbuf[i] );
	cwin->bfmad = 0;		cwin->bfsad = 0;
	cwin->grbuf[ cwin->bfmad ] = (char *)malloc(sizeof(char)*MAXMEMSIZE);
	cwin->bmap = cwin->grbuf[ cwin->bfmad ];
	if (cwin->bmap == NULL) {
		fprintf(stderr,"Buffer Overflow -- bufclear!!\n");
		error_draw=1;
		return; /* Return if full buffer */
	}
	cwin->bmap[ cwin->bfsad ] = 0;
}

#ifdef TOOLKIT
/***********************************************
*    Redraw & Resize Window 
***********************************************/
#ifndef GTK
void redraw_window(Widget w, XEvent *event)
{
	XEvent ev;
	int    i;
	static int first_time=1;
	void frames_first_page(int);

	switch (event->type) {
		case Expose:						/* When window expose */
			if (cwin->draw_mode) expose_frames(cwin, event->xexpose);
			  else if (first_time) {
				frames_first_page(0);	first_time=0;
			}
			break;

		case ConfigureNotify:				/* When change window size */
			if (cwin->draw_mode) configure_frames(cwin, event->xconfigure);
			break;
	}
}
#endif

/***********************************************
*    Get mouse position 
***********************************************/
void get_mouse_position(double *x0, double *y0)
{
#ifdef GTK
	gint wx,wy;
	GdkModifierType mask;
	gdk_window_get_pointer (cwin->win, &wx, &wy, &mask);
#else
	Window root,child;
	int rx,ry,wx,wy;
	unsigned int mask;
	XQueryPointer(dpID,cwin->win,&root,&child,&rx,&ry,&wx,&wy,&mask);
#endif
	*x0=dxrchg(wx);
	*y0=dyrchg(wy);
}

/*
wait_events(int eve,int wai)
{
	XEvent ev;
	
	while (1) {
		if (wai && XtAppPending(app_con)==0) break;
		XtAppNextEvent(app_con,&ev);
/ *		printf("ev1 %d\n",ev.type);	* /
		XtDispatchEvent(&ev);
		if (ev.xany.window==cwin->win && ev.type==eve) break;
	}
}
*/
#endif

#endif

/***********************************************
*    Get Events and Handle
***********************************************/

/******    Change   Here    *******/
void wpicdraweventchk(int *rtprm, int *ind)
{
#ifndef NOX
#ifndef TOOLKIT
	int x0=-1, y0=-1, x1=-1, y1=-1;
	XEvent event;
	int m=0;

	if (*ind) {
		if (*rtprm==99999) {
			*rtprm = 0;
			while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) {
							eventandmousechk(event,rtprm, &x0, &y0, &x1, &y1);
			}
		}
		*rtprm = 0;
		x0    = -1;			y0    = -1;
		x1    = -1;			y1    = -1;
		XNextEvent(dpID, &event);
		eventandmousechk(event,rtprm, &x0, &y0, &x1, &y1);
	  }
	  else if (*rtprm==-99999) {
		*rtprm = 0;
		if ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) {
			eventandmousechk(event,rtprm, &x0, &y0, &x1, &y1);
		}
	  }
	  else if (*rtprm==-999999) {
		*rtprm = 0;
		while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) {
			eventandmousechk(event,rtprm, &x0, &y0, &x1, &y1);
/*			printf("%s\n",event_type(event.type));		*/
		}
	  }
	  else {
		*rtprm = 0;
		while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) {
			eventandmousechk(event,rtprm, &x0, &y0, &x1, &y1);
		}
	}
#endif
#endif
}

#ifndef TOOLKIT
#ifndef NOX

static void eventandmousechk(XEvent event, int *rtprm, int *x0, int *y0, int *x1, int *y1)
{
	XKeyEvent *kev;
	KeySym key;
	int    prm=0;
	int n=2;
/*
	while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False)
	{
*/

	switch (event.type) {
		case Expose:						/* When window expose */
			expose_frames(cwin, event.xexpose);
/*			printf("Expose %d\n",event.type);	*/
			break;
		case KeyPress:						/* When key down */
			kev=(XKeyEvent*)&event;
			key = XLookupKeysym(kev, 0);
			*rtprm = (int)( keydist(key,kev->state) );
			break;
		case ButtonPress:					/* When press mouse button */
			*x0 = xrchg(event.xbutton.x);	/* Convert mouse position to virtual display coordinates */
			*y0 = yrchg(event.xbutton.y);
			if(*rtprm > 6) break;
			if(prm != 0) prm = 6;
			if(event.xbutton.button == 1) *rtprm = 1+prm;
			if(event.xbutton.button == 2) *rtprm = 2+prm;
			if(event.xbutton.button == 3) *rtprm = 3+prm;
			prm++;
			break;
		case ButtonRelease:					/* When release mouse button */
			*x1 = xrchg(event.xbutton.x);	/* Convert mouse position to virtual display coordinates */
			*y1 = yrchg(event.xbutton.y);
			if(*rtprm > 6) break;
			if(prm != 0) prm = 3;
			if(event.xbutton.button == 1) *rtprm = 4+prm;
			if(event.xbutton.button == 2) *rtprm = 5+prm;
			if(event.xbutton.button == 3) *rtprm = 6+prm;
			prm++;
			break;
		case DestroyNotify:					/* When destroy window */
			*rtprm=3;
			break;
		case ConfigureNotify:				/* When change window size */
			configure_frames(cwin, event.xconfigure);
/*			printf("Configure %d\n",event.type);		*/
			break;
		case ClientMessage:					/* When Window delete message sent by WM */
			*rtprm = 512;
			break;
/*
		case MapNotify:
			printf("MapNotify %d\n",event.type);
			break;
		case UnmapNotify:
			printf("UnmapNotify %d\n",event.type);
			break;
		case CirculateNotify:
			printf("CirculateNotify %d\n",event.type);
			break;
		case GravityNotify:
			printf("GravityNotify %d\n",event.type);
			break;
		case ReparentNotify:
			printf("ReparentNotify %d\n",event.type);
			break;
*/
		default:	Nothing;
		}
/*
	}
*/
}

static int keyset(KeySym key,unsigned int mask)
{
	int prm=(0x10000)|key;
	if (mask&ShiftMask) prm=(0x20000)|prm;
	if (mask&ControlMask) prm=(0x40000)|prm;
	if (mask&Mod1Mask) prm=(0x80000)|prm;
	return prm;
}

static int keydist(KeySym key,unsigned int mask)
{
	int prm;
/*
	KeySym s1,s2;
	char *s;
	s1=XStringToKeysym("F10");
	if (s1==NoSymbol) printf("No\n");
	s2=XStringToKeysym("A");
	if (s2==NoSymbol) printf("No\n");
	s=XKeysymToString(key);
	printf("%04x %04x %04x %04x %s\n",key,mask,s1,s2,s);
*/
	switch (key) {
		case XK_F1:			prm = 11; break;
		case XK_F2:			prm = 12; break;
		case XK_F3:			prm = 13; break;
		case XK_F4:			prm = 14; break;
		case XK_F5:			prm = 15; break;
		case XK_F6:			prm = 16; break;
		case XK_F7:			prm = 17; break;
		case XK_F8:			prm = 18; break;
		case XK_F9:			prm = 19; break;
		case XK_F10:		prm = 20; break;
		case XK_F11: 		prm = 21; break;
		case XK_F12:		prm = 22; break;
		case XK_Escape:		prm = 27; break;
		default:			prm=keyset(key,mask);
	}
	return prm;
}
#endif

void wpicdrawkeyset(char *str,int *n,int *key)
{
#ifndef NOX
	unsigned int mask=0;
	char s[2];

	if (str[0]=='^') mask=ControlMask;
	s[0]=str[1];	s[1]='\0';
	*key=keyset(XStringToKeysym(s),mask);
#endif
}
#endif

/********************************************************
*    Flush X Buffer (wait for the process termination)
*********************************************************/
void wpicdrawbufwaitflush(void)
{
#ifndef NOX
#ifndef GTK
	XSync(dpID, False);
#endif
#endif
}

/********************************************************
*    Flush X Buffer (no wait for the process termination)
*********************************************************/
void wpicdrawbufnowaitflush(void)
{

#ifndef NOX
#ifndef GTK
#ifdef TOOLKIT
	XEvent ev;

	XFlush(dpID);
	while (TGMODE) {
		if (XtAppPending(app_con)==0) return;
		XtAppNextEvent(app_con,&ev);
		if (ev.xany.window == cwin->win) continue;
		XtDispatchEvent(&ev);
	}
#else
	XFlush(dpID);
#endif
#endif
#endif
}

/********************************************************
*    Display Controls
*********************************************************/

void wpicdrawfinishdrawing(void)
{
#ifndef NOX
	if (cwin->draw_mode==0) return;
#ifdef GTK
printf("cc3\n");
	update_frame(cwin->area);
#else
	XFlush(dpID);
	XRaiseWindow(dpID, cwin->win);
	if (display_mode) {
		XCopyArea (dpID, cwin->pix, cwin->win, cwin->gc, 0, 0, cwin->width, cwin->height, 0, 0);
	  }
	  else {
		XCopyArea (dpID, cwin->win, cwin->pix, cwin->gc, 0, 0, cwin->width, cwin->height, 0, 0);
	}
#endif
#endif
}

void wpicdrawsetdisplaymode(int *mode)
{
#ifndef NOX
	if (display_mode != *mode) {
		wpicdrawfinishdrawing();
		display_mode=*mode;
		if (display_mode) cwin->drw=cwin->pix;
#ifdef GTK
			else		  cwin->drw=cwin->win;
#else
			else		  cwin->drw=cwin->win;
#endif
	}
#endif
}

/***********************************************
*    Set foreground color (drawing palette)
***********************************************/
void wpicdrawbasiccolor(int *cnum)
{
#ifndef NOX
	int cn=(*cnum);

	bufsetchar(WINDRAW_BASICCOL);			/* Set basic color to buffer */
	bufsetchar(cn);
	bufputchar(WINDRAW_END);

	colbkup = cn;
#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->bcolor[cn]));
#else
	XSetForeground (dpID, cwin->gc, cwin->bcolor[cn]);
#endif
#endif
}

#ifndef NOX
static void color_install(int mode)
{
	if (dp_depth!=1) {
		switch (dp_class) {
			case PseudoColor:
			case GrayScale:
			case DirectColor:
#ifdef GTK
				fprintf(stderr,"GTK mode needs TrueColor machine !!!\n");
				exit(1);
#else
				set_colormap();
#ifdef TOOLKIT
				if (TGMODE) XSetWindowColormap(dpID, cwin->topwin, cmap);
#endif
				XSetWindowColormap(dpID, cwin->win, cmap);
				XInstallColormap(dpID, cmap);
#endif
				break;
			case TrueColor:
				alloc_colors();
				bufsetchar(WINDRAW_BASECOLMAP);
				bufsetint(cwin->ccmap);
				bufputchar(WINDRAW_END);
		}
	}

	color_set=1;

}
#endif

void wpicdrawextendcolor(int *cnum)
{
#ifndef NOX
	int cn;

/*	printf("color_set = %d %d\n",color_set,*cnum);		*/
	if (color_set==0) color_install(0);

	cn=(*cnum);
//	cn=(*cnum)+(cwin->bpixel);
	bufsetchar(WINDRAW_EXTENDCOL);			/* Set extended color to buffer */
	bufsetshort(cn);
	bufputchar(WINDRAW_END);

	colbkup = cn;
#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
#else
	XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
#endif
#endif
}

void wpicdrawextend2color(int *cnum, int *ncs)
{
#ifndef NOX
	int cn,ii,jj,kk;

/*	printf("ex_color_set = %d %d %d\n",color_set,*cnum,cwin->bpixel);	*/
	if (color_set==0) color_install(1);

	if (true_color==1) {
		cn=*cnum;
		grad_color_setting(cn, *ncs, &ii, &jj, &kk);
		bufsetchar(WINDRAW_EXTEND2COL);			/* Set extended color to buffer */
		bufsetshort(ii);
		bufsetshort(jj);
		bufsetshort(kk);
		bufputchar(WINDRAW_END);
		colbkup = cn;
	  }
	  else {
		cn=*cnum;
//		cn=(*cnum)+(cwin->bpixel);
		bufsetchar(WINDRAW_EXTENDCOL);			/* Set extended color to buffer */
		bufsetshort(cn);
		bufputchar(WINDRAW_END);
		colbkup = cn;
#ifdef GTK
		gdk_gc_set_foreground(cwin->gc, &(cwin->pixels[cn]));
#else
		XSetForeground (dpID, cwin->gc, cwin->pixels[cn]);
#endif
	}
#endif
}

/***********************************************
 *    Set color table
 ***********************************************/
void wpicdrawsethlscolor(double *sh0,double *sl0,double *ss0,int *div0,int *mode0,int *cdef,int *csys)
{
#ifndef NOX
	int i,*mode=mode0,mc,nc;

#ifdef WINLIB
	nc=get_current_hlstable(&sh0,&mode);
	if (nc>0) {
		div0=mode+1;
		if (*mode>0) {
			sl0=sh0+*mode+1;		ss0=sl0+*mode+1;
		}
		current_hlstable=nc;
	  }
	  else if (nc<0) {
		current_hlstable=-nc;
	  }
	  else current_hlstable=0;
#else
	current_hlstable=get_current_tphlstable();
	if (current_hlstable>-2 && *csys>0) {
		current_hlstable=*csys+MAXDEFCUMAPP;
	}
#endif
/*	printf("wpic current_hlstable = %d %d\n",current_hlstable,dp_mode);			*/

	if (*mode<=0 || *div0<=0) {
		dp_mode=1;
		if (*mode<0 || *div0<=0) color_num=*cdef;
		  else					 color_num=*div0;
		shmin0=5*rgbmax;       shmax0=0;
		slmin0=slmax0=rgbmax/2;
		ssmin0=ssmax0=rgbmax1;
	  }
	  else {
		dp_mode=*mode;
		if (dp_mode==1) {
			color_num=*div0;
			shmin0=(sh0[0])*rgbmax/60;			shmax0=(sh0[1])*rgbmax/60;
			slmin0=(sl0[0])*rgbmax1;			slmax0=(sl0[1])*rgbmax1;
			ssmin0=(ss0[0])*rgbmax1;			ssmax0=(ss0[1])*rgbmax1;
		  }
		  else {
			if (dp_sh!=NULL) free(dp_sh);
			dp_sh=(int *)malloc(sizeof(int)*((dp_mode+1)*3+dp_mode));
			if (dp_sh== NULL) {
				fprintf(stderr,"Memory Full - Set HLS Color\n");
				exit(0);
			}
			dp_sl=dp_sh+(dp_mode+1);
			dp_ss=dp_sl+(dp_mode+1);
			dp_div=dp_ss+(dp_mode+1);
			for (i=0;i<=dp_mode;i++) {
				dp_sh[i]=sh0[i]*rgbmax/60;
				dp_sl[i]=sl0[i]*rgbmax1;
				dp_ss[i]=ss0[i]*rgbmax1;
			}
/*	color setting point		*/
			for (i=color_num=0;i<dp_mode;i++) {
				mc=div0[i]-1;
				if (mc<0) mc=1;
				color_num+=mc;
				dp_div[i]=mc+1;
			}
			color_num++;
		}
	}

	color_set=0;
	if (current_hlstable>=MINSPHERECOL && current_hlstable<MAXSPHERECOL) color_install(0);

#ifndef WINLIB
	*mode0=color_num;
#endif

#else
	int i,cn,dpm,mc;

	if (*mode0<=0 || *div0<=0) {
		if (*mode0<0 || *div0<=0) cn=*cdef;
		  else					  cn=*div0;
	  }
	  else {
		dpm=*mode0;
		if (dpm==1) {
			cn=*div0;
		  }
		  else {
/*	color setting point		*/
			for (i=cn=0;i<dpm;i++) {
				mc=div0[i]-1;
				if (mc<0) mc=1;
				cn+=mc;
			}
			cn++;
		}
	}
	*mode0=cn;
#endif
}

/***********************************************
*    Clear screen
***********************************************/
void wpicdrawgclear(void)
{
#ifndef NOX
//	int prm;
#ifdef GTK
		gdk_gc_set_foreground(cwin->gc, &(cwin->bcolor[0]));
		gdk_draw_rectangle(cwin->pix, cwin->gc,TRUE,0,0, cwin->width, cwin->height);
#else
	if ( display_mode == 0 ) XClearWindow (dpID, cwin->win);
	  else {
		XSetForeground (dpID, cwin->gc, cwin->bcolor[0]);
		XFillRectangle (dpID, cwin->pix, cwin->gc, 0, 0, cwin->width, cwin->height);
	}
#endif

	bufclear();
//	prm = (int)colbkup;
	wpicdrawbasiccolor( &colbkup );
	cwin->draw_mode=0;
	if (true_color==1) {
		color_set=0;
//		cwin->bpixel=-1;		color_set=0;
	}
#endif
}

/***********************************************
*    Set color mode
***********************************************/
#ifndef NOX
static void colormodeset(int md)
{
	int i, cnt=8;

	switch (md) {
		case 1:		/* Exchange white and black color mapping (to make white background) */
			cwin->bcolor[0] = colplt[7];
			cwin->bcolor[7] = colplt[0];
			for( i = 1; i < cnt-1; i++) cwin->bcolor[i] = colplt[i];
			break;
		case 10:		/* Set all color other than black to white (B/W mode) */
			cwin->bcolor[0] = colplt[0];
			for( i = 1; i < cnt; i++) cwin->bcolor[i] = colplt[7];
			break;
		case 11:		/* Exchange white and black color mapping and Set all color 
							other than white to black (B/W mode and make white background) */
			cwin->bcolor[0] = colplt[7];
			for( i = 1; i < cnt; i++) cwin->bcolor[i] = colplt[0];
			break;
		default:		/* Normal color mode */
			for( i = 0; i < cnt; i++) cwin->bcolor[i] = colplt[i];
	}
	cwin->bcolor[8] = colplt[8];
	cwin->bcolor[9] = colplt[9];
	color_mode = md;
#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->bcolor[0]));
#else
	XSetWindowBackground(dpID, cwin->win, cwin->bcolor[0]);
#endif
}
#endif

void wpicdrawcolormode(int *mode)
{
#ifndef NOX
	colormodeset( (int)(*mode) );
#endif
}

/***********************************************
*    Draw a segment
***********************************************/
void wpicdrawsegment(int *x0, int *y0, int *x1, int *y1)
{
#ifndef NOX
	int xs=*x0, ys=*y0, xe=*x1, ye=*y1;
	static int xx, yy;

	if (cwin->draw_mode==1 && xx==xs && yy==ys) bufsetchar(WINDRAW_DRAW);
	  else {
		bufsetchar(WINDRAW_LINE);			/* Set coordinates of the line to buffer */
		bufsetshort(xs);
		bufsetshort(ys);
	}
	bufsetshort(xe);
	bufsetshort(ye);
	bufputchar(WINDRAW_END);
	cwin->draw_mode=1;
	xx=xe;		yy=ye;

	xs = xchg(xs);			/* Transformation of coordinate */
	ys = ychg(ys);
	xe = xchg(xe);
	ye = ychg(ye);
#ifdef GTK
//	printf("wpicdrawsegment %d %d %d %d\n",*x0, *y0, *x1, *y1);
	gdk_draw_line (cwin->drw, cwin->gc, xs, ys, xe, ye);
#else
	XDrawLine (dpID, cwin->drw, cwin->gc, xs, ys, xe, ye);
#endif

#endif
}


/***********************************************
*    Draw lines (separeted or linked)
***********************************************/
void wpicdrawlines(int *xx, int *yy, int *cn, int *md)
/*
 *   cn:  Number of coordinates
 *   mode
 *     0: Separate lines described by coordinate pairs ( draw cn/2 lines )
 *     1: Linked lines                                 ( draw cn-1 lines )
 *     2: Closed linked lines and fill it              ( draw cn   lines )
 */
{
#ifndef NOX
	int      cnt=*cn, mode=*md, i, j;
#ifdef GTK
	GdkSegment sxy[NGBUFFER];
	GdkPoint   pxy[NGBUFFER];
#else
	XSegment sxy[NGBUFFER];
	XPoint   pxy[NGBUFFER];
#endif

	if (cnt <= 1) return; 

	cwin->draw_mode=11;

	switch (mode) {
	case 0:				/* Separate lines */
		bufsetchar(WINDRAW_SEGMENTS);
		bufsetshort(cnt);
		i = 0;
		while( i < cnt ) {
			bufsetshort( (int)xx[i  ] );		bufsetshort( (int)yy[i++] );
			bufsetshort( (int)xx[i  ] );		bufsetshort( (int)yy[i++] );
		}
		bufputchar(WINDRAW_END);

		i = j = 0;
		while ( i < cnt) {
			sxy[j  ].x1 = xchg( (int)xx[i  ] );		sxy[j  ].y1 = ychg( (int)yy[i++] );
			sxy[j  ].x2 = xchg( (int)xx[i  ] );		sxy[j++].y2 = ychg( (int)yy[i++] );
			if (j >= NGBUFFER) {
#ifdef GTK
				gdk_draw_segments(cwin->drw, cwin->gc, sxy, j);
#else
				XDrawSegments(dpID, cwin->drw, cwin->gc, sxy, j);
#endif
				j = 0;
			}
		}
#ifdef GTK
		if ( j != 0 ) gdk_draw_segments(cwin->drw, cwin->gc, sxy, j);
#else
		if ( j != 0 ) XDrawSegments(dpID, cwin->drw, cwin->gc, sxy, j);
#endif
		break;

	case 1:				/* Linked lines */
		bufsetchar(WINDRAW_LINKS);
		bufsetshort(cnt);
		for( i = 0; i < cnt; i++) {
			bufsetshort( (int)xx[i] );
			bufsetshort( (int)yy[i] );
		}
		bufputchar(WINDRAW_END);

		i = j = 0;
		while ( i < cnt) {
			pxy[j  ].x = (short)(xchg( (int)xx[i  ] ));
			pxy[j++].y = (short)(ychg( (int)yy[i++] ));
			if (j >= NGBUFFER) {
#ifdef GTK
				gdk_draw_lines(cwin->drw, cwin->gc, pxy, j);
#else
				XDrawLines(dpID, cwin->drw, cwin->gc, pxy, j, CoordModeOrigin);
#endif
				j = 0;
			}
		}
#ifdef GTK
		if ( j != 0 ) gdk_draw_lines(cwin->drw, cwin->gc, pxy, j);
#else
		if ( j != 0 ) XDrawLines(dpID, cwin->drw, cwin->gc, pxy, j, CoordModeOrigin);
#endif
		break;

	case 2:				/* Closed linked lines and fill */
		bufsetchar(WINDRAW_FILLPOLYGON);
		bufsetshort(cnt);
		for( i = 0; i < cnt; i++) {
			bufsetshort( (int)xx[i] );
			bufsetshort( (int)yy[i] );
		}
		bufputchar(WINDRAW_END);

		i = j = 0;
		while ( i < cnt) {
			pxy[j  ].x = (short)(xchg( (int)xx[i  ] ));
			pxy[j++].y = (short)(ychg( (int)yy[i++] ));
			if (j >= NGBUFFER) {
				fprintf(stderr,"Maximum Number Exceeded - Fill Polygon\n");
			}
		}
#ifdef GTK
		gdk_draw_polygon(cwin->drw, cwin->gc, TRUE, pxy, j);
#else
		XFillPolygon(dpID, cwin->drw, cwin->gc, pxy, j, polyshape, CoordModeOrigin);
#endif
		break;

	default:  Nothing;
	}
#endif
}


/***********************************************
*    Draw a rectangle
***********************************************/
void wpicdrawrectangle(int *x0, int *y0, int *x1, int *y1, int *md)
/*
 *   mode
 *     0: Normal
 *     1: Fill
 */
{
#ifndef NOX
	int          xs=*x0, ys=*y0, xe=*x1, ye=*y1, mode=*md, t;
	unsigned int bwid, bhei;

	if ( (mode < 0) || (mode > 1) ) return;

	cwin->draw_mode=21;

	if (xs>xe) {  t=xe;  xe=xs;  xs=t;  }
	if (ys>ye) {  t=ye;  ye=ys;  ys=t;  }

	if (mode == 1)	bufsetchar(WINDRAW_FILLBOX);
		else		bufsetchar(WINDRAW_BOX);
	bufsetshort(xs);		bufsetshort(ys);
	bufsetshort(xe);		bufsetshort(ye);
	bufputchar(WINDRAW_END);

	xs = xchg(xs);		ys = ychg(ys);
	xe = xchg(xe);		ye = ychg(ye);
	bwid = (unsigned int)(xe-xs);
	bhei = (unsigned int)(ye-ys);

#ifdef GTK
	if (mode == 1)	gdk_draw_rectangle(cwin->drw, cwin->gc, TRUE, xs, ys, bwid, bhei);
		else		gdk_draw_rectangle(cwin->drw, cwin->gc, FALSE, xs, ys, bwid, bhei);
#else
	if (mode == 1)	XFillRectangle(dpID, cwin->drw, cwin->gc, xs, ys, bwid, bhei);
		else		XDrawRectangle(dpID, cwin->drw, cwin->gc, xs, ys, bwid, bhei);
#endif
#endif
}

/***********************************************
*    Draw a rectangle with linear gradient fill
***********************************************/
void wpicdrawgradrectangle(int *x0, int *y0, int *x1, int *y1, float *cnc)
{
#ifndef NOX
	int xs=*x0, ys=*y0, xe=*x1, ye=*y1;
	int cn,icn[4],ff,i;

	if (color_set==0) color_install(0);

	cwin->draw_mode=22;

/*		printf("bpixel = %d\n",cwin->bpixel);		*/
	for (i=0;i<4;i++) icn[i]=cnc[i]*65536;
	if (xs>xe) {
		ff=xe;		xe=xs;			xs=ff;
		ff=icn[0];	icn[0]=icn[2];	icn[2]=ff;
		ff=icn[1];	icn[1]=icn[3];	icn[3]=ff;
	}
	if (ys>ye) {
		ff=ye;		ye=ys;			ys=ff;
		ff=icn[0];	icn[0]=icn[1];	icn[1]=ff;
		ff=icn[2];	icn[2]=icn[3];	icn[3]=ff;
	}

	bufsetchar(WINDRAW_GRADFILLBOX);
	bufsetshort(xs);		bufsetshort(ys);
	bufsetshort(xe);		bufsetshort(ye);
	for (i=0;i<4;i++) bufsetint(icn[i]);
	bufputchar(WINDRAW_END);

	xs = xchg(xs);		ys = ychg(ys);
	xe = xchg(xe);		ye = ychg(ye);

	grad_fill_rectangle(xs,ys,xe,ye,icn[0],icn[1],icn[2],icn[3]);
/*
	if (xs>xe) {
		if (ys>ye) {
			grad_fill_rectangle(xe,ye,xs,ys,icn[3],icn[2],icn[1],icn[0]);
		  }
		  else {
			grad_fill_rectangle(xe,ys,xs,ye,icn[2],icn[3],icn[0],icn[1]);
		}
	  }
	  else {
		if (ys>ye) {
			grad_fill_rectangle(xs,ye,xe,ys,icn[1],icn[0],icn[3],icn[2]);
		  }
		  else {
			grad_fill_rectangle(xs,ys,xe,ye,icn[0],icn[1],icn[2],icn[3]);
		}
	}
*/
#endif
}


/***********************************************
*    Draw a circle
***********************************************/
void wpicdrawcircle(int *x0, int *y0, int *dx, int *dy, int *md)
/*
 *   mode
 *     0: Normal
 *     1: Fill
 */
{
#ifndef NOX
	int xx=*x0, yy=*y0, drx=*dx, dry=*dy, mode=*md;

	if ( (mode < 0) || (mode > 1) ) return;

	cwin->draw_mode=2;

	if (mode == 1)	bufsetchar(WINDRAW_FILLCIRCLE);
		else		bufsetchar(WINDRAW_CIRCLE);
	bufsetshort(xx);		bufsetshort(yy);
	bufsetshort(drx);		bufsetshort(dry);
	bufputchar(WINDRAW_END);

	drx = rchg(drx);
	dry = rchg(dry);
	xx  = xchg(xx)-drx/2;
	yy  = ychg(yy)-dry/2;
#ifdef GTK
	if (mode == 1)	gdk_draw_arc (cwin->drw, cwin->gc, TRUE, xx, yy, (unsigned int)drx, (unsigned int)dry, 0, 360*64);
		else		gdk_draw_arc (cwin->drw, cwin->gc, FALSE, xx, yy, (unsigned int)drx, (unsigned int)dry, 0, 360*64);
#else
	if (mode == 1)	XFillArc (dpID, cwin->drw, cwin->gc, xx, yy, (unsigned int)drx, (unsigned int)dry, 0, 360*64);
		else		XDrawArc (dpID, cwin->drw, cwin->gc, xx, yy, (unsigned int)drx, (unsigned int)dry, 0, 360*64);
#endif
#endif
}

/***********************************************
*    Draw a circle with circular gradient fill
***********************************************/
void wpicdrawgradcircle(int *x0, int *y0, int *dd, int *icol)
{
#ifndef NOX
	int xx=*x0, yy=*y0, dr=*dd, ic=*icol;

	if (color_set==0) color_install(0);

	cwin->draw_mode=31;

	bufsetchar(WINDRAW_GRADCIRCLE);
	bufsetchar(ic);
	bufsetshort(xx);		bufsetshort(yy);
	bufsetshort(dr);
	bufputchar(WINDRAW_END);

	xx  = xchg(xx);			yy  = ychg(yy);
	dr  = rchg(dr);
	grad_fill_circle(xx,yy,dr,ic);
#endif
}


/***********************************************
*    Draw a dot
***********************************************/
void wpicdrawapoint(int *x0, int *y0)
{
#ifndef NOX
	int xx=*x0, yy=*y0;

	cwin->draw_mode=3;

	bufsetchar(WINDRAW_DOT);
	bufsetshort(xx);		bufsetshort(yy);
	bufputchar(WINDRAW_END);

	xx = xchg(xx);		yy = ychg(yy);
#ifdef GTK
	gdk_draw_point (cwin->drw, cwin->gc, xx, yy);
#else
	XDrawPoint (dpID, cwin->drw, cwin->gc, xx, yy);
#endif
#endif
}


/***********************************************
*    Draw dots at a time
***********************************************/
void wpicdrawpoints(int *xx, int *yy, int *cn)
{
#ifndef NOX
	int cnt=*cn, i, j;
#ifdef GTK
	GdkPoint pxy[NGBUFFER];
#else
	XPoint pxy[NGBUFFER];
#endif

	if (cnt < 1) return;

	cwin->draw_mode=13;

	bufsetchar(WINDRAW_DOTS);
	bufsetshort(cnt);
	for( i = 0; i < cnt; i++) {
		bufsetshort( (int)xx[i] );
		bufsetshort( (int)yy[i] );
	}
	bufputchar(WINDRAW_END);

	i = j = 0;
	while ( i < cnt) {
		pxy[j  ].x = (short)(xchg( (int)xx[i  ] ));
		pxy[j++].y = (short)(ychg( (int)yy[i++] ));
		if (j >= NGBUFFER) {
#ifdef GTK
			gdk_draw_points (cwin->drw, cwin->gc, pxy, j);
#else
			XDrawPoints (dpID, cwin->drw, cwin->gc, pxy, j, CoordModeOrigin);
#endif
			j = 0;
		}
	}
#ifdef GTK
	if ( j != 0 ) gdk_draw_points (cwin->drw, cwin->gc, pxy, j);
#else
	if ( j != 0 ) XDrawPoints (dpID, cwin->drw, cwin->gc, pxy, j, CoordModeOrigin);
#endif
	return;
#endif
}


/***********************************************
*    Draw graphic characters
***********************************************/
void wpicdrawcharacters(int *x0, int *y0, char *chr, int *cn
						, int *cdx, int *cdy, int *dcx, int *dcy, int *md)
/*
 *   mode : meaning of old version
 *     0: Normal font
 *     (1: Samezima font, not supported now *md)
 *   In current version
 *   md = 0   : write in Copy
 *   md = 1   : write in Xor
 *   cdx, cdy : 1/128 font width and height
 *   dcx, dcy : 1/128 font adjustment in width or height
 *   Base Point is Bottom Left
 */
{
#ifndef NOX
	int    cnt=*cn, xx=*x0, yy=*y0, icx=*cdx, icy=*cdy, idx=*dcx, idy=*dcy, md0=*md, mode=0;

/*font
	int    xxf, mfdt, mfct;
	int   fx[512], fy[512], fct, prm=1;
	double fmxl, fmyl;
	char   code;
*/

	if (md0==0 && (idx || idy)) mode=1;
/*font
	fmxl= 1;
	fmyl= 1;

	if ( (mode < 0) || (mode > 1) ) return;
*/
	if (cnt < 1) return;

	cwin->draw_mode=4;

		if (md0==0) {
			if (mode==0) bufsetchar(WINDRAW_CHAR);
				else	 bufsetchar(WINDRAW_FINECHAR);
		  }
		  else	bufsetchar(WINDRAW_XORCHAR);
		bufsetshort(xx);		bufsetshort(yy);
		bufsetshort(icx);		bufsetshort(icy);
		if (mode) {
			bufsetshort(idx);		bufsetshort(idy);
		}
		bufsetshort(cnt);
		bufsetbytes(chr, cnt);
		bufputchar(WINDRAW_END);
		xx = xchg(xx)+((icx*(cwin->fontwidth))>>7)+((idx*(cwin->fontheight))>>7);
		yy = ychg(yy)+((icy*(cwin->fontheight))>>7)+((idy*(cwin->fontwidth))>>7);
#ifdef GTK		// fontGTK
		gdk_draw_text(cwin->drw, fontst, cwin->gc, xx, yy, chr, cnt);
#else
		if (md0) XSetFunction(dpID, cwin->gc, GXxor);
		XDrawString(dpID, cwin->drw, cwin->gc, xx, yy, chr, cnt);
		if (md0) XSetFunction(dpID, cwin->gc, GXcopy);
#endif

#endif
}

#ifndef NOX
/******************************************************************
*    Initialize and Destloy Window Parameters
*******************************************************************/
static void initialize_frames_window(FRAMESWINDOW *cw)
{
	cw->win=0;
#ifdef GTK
	cw->pix=NULL;
	cw->area=NULL;
#else
	cw->pix=0;
#ifdef TOOLKIT
	cw->topwin=0;
#endif
#endif
	cw->bfmmax=0;		cw->grbuf = NULL;

	cw->bfmad = cw->bfsad = 0;
	cw->nfont = -1;

	cw->grbuf=NULL;
	increasebuf(cw);
	cw->grbuf[0] = (char *)malloc(sizeof(char)*MAXMEMSIZE);
	cw->bmap = cw->grbuf[0];
	cw->grbuf[0][0] = 0;
	cw->draw_mode = 0;

	cw->ccmap=-1;
//	cw->bpixel = -1;
/*	cw->pixels = NULL;		*/
}

void destroy_frames_window(FRAMESWINDOW *cw)
{
	int i;

	for(i=0; i<=cw->bfmad; i++) free( cw->grbuf[i] );
#ifdef GTK
	if (cw->area) gtk_widget_destroy(cw->area);
	if (cw->pix) gdk_pixmap_unref (cw->pix);
#else
	if (cw->win) XDestroyWindow(dpID, cw->win);
	if (cw->pix) XFreePixmap(dpID, cw->pix);
#endif
	cw->bfmad=-1;		cw->win=0;		cw->pix=0;
	cw->ccmap=-1;
//	cw->bpixel = -1;
/*	if (cw->pixels != NULL) free(cw->pixels);
	cw->pixels = NULL;								*/
}

void set_basic_colormode(int mode, int rgb[])
{
	int rt;
	if (rgb[0] >= 0) {
		if (mode&1) {
			colplt[7]=color_from_rgb(rgb[0], rgb[1], rgb[2], &rt);
			colplt[0]=colplt[8];
		  }
		  else {
			colplt[0]=color_from_rgb(rgb[0], rgb[1], rgb[2], &rt);
			colplt[7]=colplt[9];
		}
	  }
	  else {
		if (mode&1) {
			colplt[7]=colplt[9];
			colplt[0]=colplt[8];
		  }
		  else {
			colplt[0]=colplt[8];
			colplt[7]=colplt[9];
		}
	}
	colormodeset(mode);
}

void clear_colmap_table()
{
	int i;
	max_colmap=-1;		max_gpixels=-1;		current_hlstable=0;		def_colmap=0;
//	for (i=0;i<7;i++) gsphept[i]=NULL;
}
#ifdef TOOLKIT
static char *body_name(char *name)
{
	int i, n=strlen(name);
	char *s;

	for (i=n-2,s=&name[n-2];i>=1;i--,s--) {
		if (*s=='/') {  s++;  break;  }
	}
	if (*s=='/') s++;
	return s;
}

void set_title_name(int ind)
{
	char framesname[300];

#ifdef GTK
	if (ind==0) {
		strcpy(framesname,"GTK-tplot: ");
		strcat(framesname,body_name(filename));
		gtk_window_set_title(GTK_WINDOW(mainwindow), framesname);
	  }
	  else {
		strcpy(framesname,"GTK-Frames: ");
		strcat(framesname,body_name(filename));
		gtk_window_set_title(GTK_WINDOW(mainwindow), framesname);
	}
#else
	if (ind==0) {
		strcpy(framesname,"X-tplot: ");
		strcat(framesname,body_name(filename));
		XStoreName(dpID, cwin->topwin, framesname);
		XSetIconName(dpID, cwin->topwin, "X-tplot");
	  }
	  else {
		strcpy(framesname,"X-Frames: ");
		strcat(framesname,body_name(filename));
		XStoreName(dpID, cwin->win, framesname);
		XSetIconName(dpID, cwin->win, "X-Frames");
	}
#endif
}

#ifndef GTK
void fix_window(Widget w, Position x, Position y)
{
	XSizeHints myhints;
	unsigned int  wd, hg, bwd, dp;
	int ii,jj;
	Window root;

	XGetGeometry(XtDisplay(w),XtWindow(w),&root,&ii,&jj,&wd,&hg,&bwd,&dp);
	myhints.x            = x;
	myhints.y            = y;
	myhints.width        = wd;
	myhints.height       = hg;
	myhints.min_width    = wd;
	myhints.min_height   = hg;
	myhints.max_width    = wd;
	myhints.max_height   = hg;
	myhints.flags        = PPosition | PMinSize | PMaxSize;
	XSetNormalHints(XtDisplay(w), XtWindow(w), &myhints);
}
#endif

void clear_frames_window(void)
{
	cwin->draw_mode = 0;
#ifdef GTK
	if (cwin->win) gtk_widget_destroy(cwin->topwin);
#else
	XClearWindow (dpID, cwin->win);
	XDestroyWindow(dpID, cwin->topwin);
	while (1) {
		XEvent ev;
		XtAppNextEvent(app_con,&ev);
		XtDispatchEvent(&ev);
		if (ev.type==DestroyNotify) break;
	}
	XtDestroyWidget(toplevel);
#endif
	destroy_frames_window(cwin);
}

#ifndef GTK
void set_color_toggles(void)
{
	int i;
	for (i=0;i<7;i++) XtVaSetValues(ctoggle[i],XtNforeground,colplt[i+1]
											  ,XtNbackground,colplt[8],NULL);
	for (i=0;i<7;i++) XtVaSetValues(cradio[i],XtNforeground,colplt[i+1]
											  ,XtNbackground,colplt[8],NULL);
	for (i=0;i<7;i++) XtVaSetValues(lradio[i],XtNforeground,colplt[i+1]
											  ,XtNbackground,colplt[8],NULL);
}
#endif

void exchange_window(int wid, int hei, int num, int den)
{
	XSizeHints myhints;
	unsigned int  wd, hg, bwd, dp;
	int ii,jj;
	Window root;


#ifdef GTK
	dpID = GDK_DISPLAY();
	cwin->topwin = mainwindow;
	cwin->area = framesarea;
	cwin->win = framesarea->window;
#else
	dpID = XtDisplay(xframes);
	cwin->win  = XtWindow(xframes);
	cwin->topwin = XtWindow(toplevel);
#endif

	cwin->owidth = (unsigned int)(WINRATE*wid);
	cwin->oheight= (unsigned int)(WINRATE*hei);
/*	XGetGeometry(dpID,cwin->win,&root,&ii,&jj,&(cwin->width),&(cwin->height),&bwd,&dp);*/
	cwin->width = (unsigned int)wid*num/den;
	cwin->height= (unsigned int)hei*num/den;
	make_pixmap(cwin);
	set_magnification(cwin);
	magnix  = WINWIDTH/(double)(cwin->width);
	magniy  = WINHEIGHT/(double)(cwin->height);

#ifndef GTK
	XGetGeometry(dpID,cwin->topwin,&root,&ii,&jj,&wd,&hg,&bwd,&dp);
	myhints.width        = wd;
	myhints.height       = hg;
	myhints.min_width    = wd/2;
	myhints.min_height   = hg/2;
	myhints.min_aspect.x = wd;
	myhints.min_aspect.y = hg;
	myhints.max_aspect.x = wd;
	myhints.max_aspect.y = hg;
	myhints.flags        = PMinSize | PAspect;
	XSetNormalHints(dpID, cwin->topwin, &myhints);
	set_color_toggles();
#endif
}

void get_windowsize(int *wid, int *hei, int *num, int *den, int *rmode)
{
	*wid=(cwin->owidth)/grate;		*hei=(cwin->oheight)/grate;
	*num=magnum;			*den=magden;
	*rmode=xyratiomode;
}

int get_colormode(void)
{
	return color_mode;
}

void set_character_size(double csize)
{
	cwin->chsize=(int)(csize*BASECOLVAL);
}

void xwindow_clear(void)
{
#ifdef GTK
	gdk_window_clear (cwin->win);
	#else
	XClearWindow (dpID, cwin->win);
#endif
}

void change_drawcolormode(int mode)
{
	colormodeset( mode );
#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->bcolor[0]));
	gdk_draw_rectangle(cwin->pix, cwin->gc,TRUE,0,0, cwin->width, cwin->height);
#else
	XSetForeground (dpID, cwin->gc, cwin->bcolor[0]);
	XFillRectangle (dpID, cwin->pix, cwin->gc, 0, 0, cwin->width, cwin->height);
#endif
	redraw_pics(cwin);
}

void initialize_tplot_frames(void)
{
#ifdef GTK
	int i;
	for (i=0;i<MAXFP;i++) frwin[i]=NULL;
#else
	cwin  = (FRAMESWINDOW *)malloc(sizeof(FRAMESWINDOW));
	initialize_frames_window(cwin);
#endif
}

#ifdef GTK
void gtk_frame_initialize()
{
	init_configure=0;
	frwin[maxwindow]=(FRAMESWINDOW *)malloc(sizeof(FRAMESWINDOW));
	cwin = frwin[maxwindow];
	initialize_frames_window(cwin);
	maxwindow++;
}
#endif

void wpicdrawopenwindow(int *n_wid, int *n_heig, int *wid, int *heig, int *rmode, int *stat)
/*
	n_wid :  Virtual window width
	n_heig:  Virtual window height
	wid   :  Display window width
	heig  :  Display window height
	rmode :  Mode selector for xy dimension ratio
	stat  :  if failed, return by stat=-1
*/
{
	XSizeHints myhints;
	unsigned int  wd, hg, bwd, dp;
	int i,ii,jj;
	Window root;
	XEvent event;

/* added by Sakagami,H. 95/06/02 to supress unalign error msg */
#ifdef ALPHA
	suppressunaligned();
#endif

//	printf("wpicdrawopenwindow tplot\n");
	*stat = 0;
	border_width = BORDERWIDTH;

	if (TGMODE) {
#ifdef GTK
		dpID = GDK_DISPLAY();
#else
		dpID = XtDisplay(xframes);
#endif
	  }
	  else {
		dpID = XOpenDisplay (NULL);
		if (dpID == NULL) {
			*stat = -1;		/* if failed, return by stat=-1 */
			return;
		}
	}

#ifdef GTK
	dcmap = gdk_colormap_get_system();
#else
	dcmap = DefaultColormap (dpID, 0);
#endif
	set_basiccolor();
	check_Xserver();

//	if (true_color == 0) cwin->bpixel=0;
	cwin->owidth  = (unsigned int)(*n_wid);
	cwin->oheight = (unsigned int)(*n_heig);
	cwin->width   = (unsigned int)(*wid);
	cwin->height  = (unsigned int)(*heig);

/*	printf("op=%f %d %d %d %d\n",grate,cwin->width,cwin->height,cwin->owidth,cwin->oheight);
	fprintf(stderr,"Window Size is %dx%d\n",cwin->width,cwin->height);	*/

	if (TGMODE==0) {
		display_width = DisplayWidth(dpID,0);
		display_height = DisplayHeight(dpID,0);
		if ( (display_width*5/6 < cwin->width) || (display_height*5/6 < cwin->height) ) {
			cwin->height=(cwin->height)*5*display_width/(6*(cwin->width));		/* Limit window size at least 5/6 of screen size */
			cwin->width =5*display_width/6;
		}
	}

	xyratiomode=*rmode;
	magnix  = WINWIDTH/(double)(cwin->width);
	magniy  = WINHEIGHT/(double)(cwin->height);
	grate   = (double)(*n_wid)/((double)(*wid));

#ifdef GTK
	cwin->topwin = mainwindow;
	cwin->area = framesarea;
	cwin->win = framesarea->window;
	cwin->gc = gdk_gc_new(cwin->win);
#else
	if (TGMODE) {
		cwin->win  = XtWindow(xframes);
		cwin->topwin = XtWindow(toplevel);
	  }
	  else {
		cwin->win = XCreateSimpleWindow (dpID, DefaultRootWindow(dpID),80,80,
										cwin->width, cwin->height, border_width,
										WhitePixel(dpID, 0),
										BlackPixel(dpID, 0) );
	}
	cwin->gc = XCreateGC (dpID, cwin->win, 0, 0);
#endif

	colormodeset(0);
	if (display_mode==0) cwin->drw=cwin->win;
	make_pixmap(cwin);

#ifdef GTK
	gdk_gc_set_foreground(cwin->gc, &(cwin->bcolor[7]));
	gdk_gc_set_background(cwin->gc, &(cwin->bcolor[0]));
//	gdk_gc_set_foreground(cw->gc, &(cw->bcolor[0]));
	gdk_draw_rectangle(cwin->pix, cwin->gc, TRUE,0,0, cwin->width, cwin->height);
#else
	XSetForeground(dpID, cwin->gc, cwin->bcolor[7]);
	XSetBackground(dpID, cwin->gc, cwin->bcolor[0]);
	XSetFunction(dpID, cwin->gc, GXcopy);
	XSetLineAttributes(dpID, cwin->gc, 0, LineSolid, CapButt, JoinMiter);
	XSetFillRule(dpID, cwin->gc, WindingRule);
#endif

	set_magnification(cwin);

#ifndef GTK
	eventmask=  ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask ;
	XSelectInput (dpID, cwin->win, eventmask );

/******    Change   Here    *******/
	if (TGMODE) {
		XGetGeometry(dpID,cwin->topwin,&root,&ii,&jj,&wd,&hg,&bwd,&dp);
		myhints.width        = wd;
		myhints.height       = hg;
		myhints.min_width    = wd/2;
		myhints.min_height   = hg/2;
		myhints.min_aspect.x = wd;
		myhints.min_aspect.y = hg;
		myhints.max_aspect.x = wd;
		myhints.max_aspect.y = hg;
		myhints.flags        = PMinSize | PAspect;
		XSetNormalHints(dpID, cwin->topwin, &myhints);
		set_color_toggles();
	  }
	  else {
		set_title_name(1);
		myhints.width        = cwin->width;
		myhints.height       = cwin->height;
		myhints.min_width    = cwin->width/2;
		myhints.min_height   = cwin->height/2;
		myhints.min_aspect.x = cwin->owidth;
		myhints.min_aspect.y = cwin->oheight;
		myhints.max_aspect.x = cwin->owidth;
		myhints.max_aspect.y = cwin->oheight;
		myhints.flags        = PMinSize | PAspect;
		XSetNormalHints(dpID, cwin->win, &myhints);

		XMapWindow(dpID, cwin->win);
		XSync(dpID, True);

		wm_delete_window = XInternAtom(dpID, "WM_DELETE_WINDOW", False);
		XSetWMProtocols (dpID, cwin->win, &wm_delete_window, 1);
	}

/*	Clear Event Buffer	*/
	if (TGMODE==0) {
/*		while ( XCheckWindowEvent(dpID, cwin->win, ExposureMask, &event) == False) Nothing;		*/
		while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) Nothing;
	}
#endif
}

void wpicdrawclosewindow(void)
{
#ifdef GTK
	gtk_widget_destroy(cwin->area);
#else
	XDestroyWindow(dpID, cwin->win);
#endif
}
#endif
#endif

#ifndef TOOLKIT
void wpicdrawopendisplay(int *stat)
/*	stat  :  if failed, return by stat=-1		*/
{
#ifndef NOX
	int i;

	if (*stat == 0) return;		/* If *stat==0, just check the NOX */

/* added by Sakagami,H. 95/06/02 to supress unalign error msg */
#ifdef ALPHA
	suppressunaligned();
#endif

	*stat = 0;
	dpID = XOpenDisplay (NULL);
	if (dpID == NULL) {
		*stat = -1;		/* if failed, return by stat=-1 */
		return;
	}
	for (i=0;i<MAXFP;i++) frwin[i]=NULL;
	dcmap = DefaultColormap (dpID, 0);
	check_Xserver();
	set_basiccolor();
	border_width = BORDERWIDTH;
	display_width = DisplayWidth(dpID,0);
	display_height = DisplayHeight(dpID,0);
	wm_delete_window = XInternAtom(dpID, "WM_DELETE_WINDOW", False);
	num_frames = XInternAtom(dpID, "Frames_Window_Number", False);

#else
	*stat = 1;			/* if you do not use any X routines, return by stat=1 */
#endif
}

#ifndef NOX
int check_window_size(int wid, int heig)
{
	int i;
	for (i=0;i<maxwindow;i++) {
		if (frwin[i] == NULL) continue;
		if (frwin[i]->width == wid && frwin[i]->height == heig) break;
	}
	if (i < maxwindow) return i;
		else		   return -1;
}
#endif

void wpicdrawsetwindow(int *win, int *color, int *stat)
{
#ifndef NOX
	int rgb[3],col=*color;
	if (*win >=0 && *win < maxwindow) cwin = frwin[*win];
	if (display_mode==0) cwin->drw=cwin->win;
	if (col) col=1;
	get_canvas_rgb(rgb);
	get_canvas_charsize(&(cwin->chsize));
	set_basic_colormode(col,rgb);
	make_pixmap(cwin);
	set_magnification(cwin);
#endif
}

void wpicdrawopenwindow(char *name, int *nn, int *n_wid, int *n_heig, int *wid, int *heig
										, int *rmode, int *color, int *stat)
/*
	n_wid :  Virtual window width
	n_heig:  Virtual window height
	wid   :  Display window width
	heig  :  Display window height
	rmode :  Mode selector for xy dimension ratio
*/
{
#ifndef NOX
	XSizeHints myhints;
	int i,col=*color,rgb[3];
	char framesname[300]="X-Frames: ";
	XEvent event;

	if (col) col=1;
	if (*stat == 0) {
//		if (frwin[maxwindow]!=NULL) destroy_frames_window(frwin[maxwindow]);
		frwin[maxwindow]=(FRAMESWINDOW *)malloc(sizeof(FRAMESWINDOW));
		cwin = frwin[maxwindow];
		initialize_frames_window(cwin);
		*stat = maxwindow;
		maxwindow++;
	  }
	  else if (*stat == 2) {
		*stat = check_window_size(*wid, *heig);
		if (*stat < 0) {
			frwin[maxwindow]=(FRAMESWINDOW *)malloc(sizeof(FRAMESWINDOW));
			cwin = frwin[maxwindow];
			initialize_frames_window(cwin);
			*stat = maxwindow;
			maxwindow++;
		  }
		  else {
			cwin = frwin[*stat];
			get_canvas_rgb(rgb);
			get_canvas_charsize(&(cwin->chsize));
			set_basic_colormode(col,rgb);
			return;
		}
	  }
	  else {
		if (frwin[maxwindow]==NULL) {
			frwin[maxwindow]=(FRAMESWINDOW *)malloc(sizeof(FRAMESWINDOW));
			cwin = frwin[maxwindow];
			initialize_frames_window(cwin);
			*stat = maxwindow;
		  }
		  else {
			*stat = maxwindow;
			get_canvas_rgb(rgb);
			get_canvas_charsize(&(cwin->chsize));
			set_basic_colormode(col,rgb);
			return;
		}
	}

//	if (true_color == 0) cwin->bpixel=0;
	cwin->owidth  = (unsigned int)(*n_wid);
	cwin->oheight = (unsigned int)(*n_heig);
	cwin->width   = (unsigned int)(*wid);
	cwin->height  = (unsigned int)(*heig);

/*	printf("op=%f %d %d %d %d\n",grate,cwin->width,cwin->height,cwin->owidth,cwin->oheight);
	fprintf(stderr,"Window Size is %dx%d\n",cwin->width,cwin->height);	*/
	if ( (display_width*5/6 < cwin->width) || (display_height*5/6 < cwin->height) ) {
		cwin->height=(cwin->height)*5*display_width/(6*(cwin->width));	/* Limit window size at least 5/6 of screen size */
		cwin->width =5*display_width/6;
	}

	cwin->win = XCreateSimpleWindow (dpID, DefaultRootWindow(dpID),80,80,
										cwin->width, cwin->height, border_width,
										WhitePixel(dpID, 0),
										BlackPixel(dpID, 0) );
	cwin->gc = XCreateGC (dpID, cwin->win, 0, 0);
	XChangeProperty (dpID, cwin->win, num_frames, XA_INTEGER, 32, PropModeReplace, (void *)stat, 1);

	xyratiomode=*rmode;
	magnix  = WINWIDTH/(double)(cwin->width);
	magniy  = WINHEIGHT/(double)(cwin->height);
	grate   = (double)(*n_wid)/((double)(*wid));

	get_canvas_rgb(rgb);
	set_basic_colormode(col,rgb);
	get_canvas_charsize(&(cwin->chsize));

	XSetForeground(dpID, cwin->gc, cwin->bcolor[7]);
	XSetBackground(dpID, cwin->gc, cwin->bcolor[0]);
	XSetFunction(dpID, cwin->gc, GXcopy);
	XSetLineAttributes(dpID, cwin->gc, 0, LineSolid, CapButt, JoinMiter);
	XSetFillRule(dpID, cwin->gc, WindingRule);

	if (display_mode==0) cwin->drw=cwin->win;
	make_pixmap(cwin);
	set_magnification(cwin);

	eventmask= ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask ;
	XSelectInput (dpID, cwin->win, eventmask );

/******    Change   Here    *******/
	if (*nn == 0) XStoreName(dpID, cwin->win, "X-Frames");
	  else {
		for (i=0;i<*nn;i++) framesname[10+i] = name[i];
		framesname[10+*nn]='\0';
		XStoreName(dpID, cwin->win, framesname);
	}
	XSetIconName(dpID, cwin->win, "X-Frames");

	myhints.width        = cwin->width;
	myhints.height       = cwin->height;
	myhints.min_width    = cwin->width/2;
	myhints.min_height   = cwin->height/2;
	myhints.min_aspect.x = cwin->owidth;
	myhints.min_aspect.y = cwin->oheight;
	myhints.max_aspect.x = cwin->owidth;
	myhints.max_aspect.y = cwin->oheight;
	myhints.flags        = PMinSize | PAspect;
	XSetNormalHints(dpID, cwin->win, &myhints);

	XMapWindow(dpID, cwin->win);
	XSync(dpID, True);

	XSetWMProtocols (dpID, cwin->win, &wm_delete_window, 1);

/*	Clear Event Buffer	*/
/*	while ( XCheckWindowEvent(dpID, cwin->win, ExposureMask, &event) == False) Nothing;		*/
	while (1) {
		if (XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) {
			if (event.type == MapNotify) break;
		}
	}
	while ( XCheckWindowEvent(dpID, cwin->win, eventmask, &event) != False) Nothing;
#endif
}

/***********************************************
*    Close the window
***********************************************/
void wpicdrawclosewindow(void)
{
#ifndef NOX
	int i;
	for (i=0;i<MAXFP;i++) {
		if (frwin[i]!=NULL) destroy_frames_window(frwin[i]);
	}
#endif
}
#endif
