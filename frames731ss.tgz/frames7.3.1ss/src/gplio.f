*******************************************************
*                F r a m e s  V.7.2.2                 *
*      Graphic Interface for Frames on X Windows      *
*     Modified for tplot.c to include PostScripts     *
*******************************************************

      SUBROUTINE FRAMESINITIAL(MAXCOL,STATE,NFP)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpwratio/ gpnum,gpden,bxw,byw,iwin,jwin,rmode,gwmode
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgp0border/ bx01,by01,bx02,by02,clipsw
      real bx01,by01,bx02,by02
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comarrows/ arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      common /comlinelim/ linelim
      real linelim
      save /comgpwinio/,/comgpcolor/,/comgpborder/,/commarking/
      save /com256color/,/comgpwratio/
      save /comarrows/,/comlinelim/,/comgp0border/

      windsw = -1
      delay  = 0

      tcolor    = -999999
      lcolor    = -999998
      col256    = -1
      maxcolmax = 256
      maxcol0   = 128
      maxcol256 = maxcol0
      call wpicdrawsethlscolor(0.d0,0.d0,0.d0,0,maxcol256,maxcol0,0)

      clip   = 0
      clipsw = 0

      CALL GWIODEFAULTSIZES(1,1)

      MAXCOL = maxcol256
      STATE  = -1

      RETURN
      END

      SUBROUTINE GWIOINITIAL(IND)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpwratio/ gpnum,gpden,bxw,byw,iwin,jwin,rmode,gwmode
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgp0border/ bx01,by01,bx02,by02,clipsw
      real bx01,by01,bx02,by02
      common /comwinratio/ winrate

      data init/0/
      save init

      if (ind.eq.9999) then
         init = 0
         return
      endif

      if (init.gt.0) return

*     initialization of workstation
      grate  = winrate
      bxr    = grate*bx0
      byr    = grate*by0
      stat   = 0
      if (ind.eq.1) then
         call wpicdrawopenwindow(bxr,byr,bxw,byw,rmode,stat)
      endif

*      call wpicdrawcolormode(1)

      bx01   = bx1
      by01   = by1
      bx02   = bx2
      by02   = by2
      clipsw = 1
      gwmode = 1
      windsw = ind
      init   = ind

      if (stat.ne.0) then
*          write(*,*) 'Graphic Workstation not opened'
*     +                       ,' -- Skip Graphic Routines'
         windsw = 99
         return
      endif

*     set view port and window
      show     = 0

      RETURN
      END

      SUBROUTINE GWIOTERMINATE
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate

      if (windsw.ne.1) return
      call wpicdrawbufwaitflush
***      if (show.eq.0) go to 100

*     request of function keys
      n     = 99999
   1  call wpicdraweventchk(n,1)
      if (n.ne.3.and.n.ne.13) go to 1

*     close workstation
  100 call wpicdrawclosewindow
      call GWIOINITIAL(9999)

      RETURN
      END

      SUBROUTINE GWIOPAUSE(KEY)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      integer ichar

      if (windsw.ne.1) return
      call wpicdrawbufwaitflush

*     request of function keys
      ichar = 0
      if (key.lt.0) then
        n     = 0
        call wpicdraweventchk(n,0)
       else if (key.gt.100) then
        key1 = key - 100
        n    = 99999
   1    call wpicdraweventchk(n,1)
        if (n.ne.key1) go to 1
       else
        CALL GWIOCOLOR(1,6)
        ypos = grate*495
        ichar = 1
        call wpicdrawcharacters(0,ypos
     ,           ,'Click right button to go next',29,0,0,0,0,1)
        call wpicdrawbufwaitflush
        n     = 99999
   2    call wpicdraweventchk(n,1)
        if (n.ne.3.and.n.ne.13) go to 2
        show = 0
      endif

      if (ichar.eq.1) then
         call wpicdrawcharacters(0,ypos
     ,             ,'Click right button to go next',29,0,0,0,0,1)
         call wpicdrawbufwaitflush
      endif
      RETURN
      END

      SUBROUTINE GWIODEFAULTSIZES(MARK,ALLOW)
      IMPLICIT INTEGER (A-Z)
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comarrows/ arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      common /comlinelim/ linelim
      real linelim

      IF (MARK.NE.0) THEN
         diamx     = 6
         diamy     = 6
         diammag   = 1
         diam1     = diamx
         diam2     = diamy
         mkspec    = 0
      ENDIF
      IF (ALLOW.NE.0) THEN
         arrowl    = 8
         arrowh    = 2
         arrowr    = arrowh/arrowl
         arrowmin  = 1
         arrowmag  = 1
         arhead    = 1
      ENDIF
      IF (MARK.NE.0.AND.ALLOW.NE.0) linelim = 0

      RETURN
      END

      SUBROUTINE GWIOVIEW(X1,Y1,X2,Y2,CA,CB)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2

*      if (windsw.ne.1) then
*          if (windsw.eq.0) call GWIOINITIAL(1)
*          if (windsw.ne.1) return
*        endif

      bx1 = x1 - ixoff
      bx2 = x2 - ixoff
      by1 = y1 - iyoff
      by2 = y2 - iyoff

      RETURN
      END

      SUBROUTINE GWIOCLEARPAGE
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate

      CALL CLEARGSETTINGS

*      if (windsw.ne.1) then
*         if (windsw.eq.0) call GWIOINITIAL(1)
         if (windsw.ne.1) return
*       endif

      call wpicdrawbufwaitflush
      call wpicdrawgclear
      show = 0

      n     = 0
      call wpicdraweventchk(n,0)

      RETURN
      END

      SUBROUTINE GWIOADDCLIP(XMIN,YMIN,XMAX,YMAX)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      real XMIN,YMIN,XMAX,YMAX

      bx1  = xmin
      by1  = ymin
      bx2  = xmax
      by2  = ymax
      clip = 1

      RETURN
      END

      SUBROUTINE GWIONOCLIP
      IMPLICIT INTEGER (A-Z)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgp0border/ bx01,by01,bx02,by02,clipsw
      real bx01,by01,bx02,by02

      if (clipsw.eq.0) return
      bx1  = bx01
      by1  = by01
      bx2  = bx02
      by2  = by02
      clip = 0

      RETURN
      END

      SUBROUTINE GWIOCLIP2D(X1,Y1,X2,Y2,IC)
      IMPLICIT INTEGER (A-Z)
      real x1,y1,x2,y2,x,y
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2

      ik = 0
    1   continue
      if (x1.lt.bx1) then
         c1 = 1
       else if (x1.gt.bx2) then
         c1 = 2
       else
         c1 = 0
      endif
      if (clip.eq.1) then
         if (y1.lt.by1) then
            c1 = c1 + 4
          else if (y1.gt.by2) then
            c1 = c1 + 8
         endif
      endif

      if (ik.ne.0) go to 3
    2   continue
      if (x2.lt.bx1) then
         c2 = 1
       else if (x2.gt.bx2) then
         c2 = 2
       else
         c2 = 0
      endif
      if (clip.eq.1) then
         if (y2.lt.by1) then
            c2 = c2 + 4
          else if (y2.gt.by2) then
            c2 = c2 + 8
         endif
      endif

    3   continue
      ic = 1
      if (c1.eq.0.and.c2.eq.0) return
      if (iand(c1,c2).ne.0) then
         ic = 0
         return
      endif
      if (c1.ne.0) then
         c = c1
       else
         c = c2
      endif
      if (x1.eq.x2) then
         if (clip.eq.1) then
            if (y1.lt.by1) then
               y1 = by1
             else if (y1.gt.by2) then
               y1 = by2
            endif
            if (y2.lt.by1) then
               y2 = by1
             else if (y2.gt.by2) then
               y2 = by2
            endif
         endif
         return
       else if (y1.eq.y2) then
         if (x1.lt.bx1) then
            x1 = bx1
          else if (x1.gt.bx2) then
            x1 = bx2
         endif
         if (x2.lt.bx1) then
            x2 = bx1
          else if (x2.gt.bx2) then
            x2 = bx2
         endif
         return
       else if (iand(c,1).ne.0) then
         y = y1 + (y2-y1)*(bx1-x1)/(x2-x1)
         x = bx1
       else if (iand(c,2).ne.0) then
         y = y1 + (y2-y1)*(bx2-x1)/(x2-x1)
         x = bx2
       else if (iand(c,4).ne.0) then
         x = x1 + (x2-x1)*(by1-y1)/(y2-y1)
         y = by1
       else if (iand(c,8).ne.0) then
         x = x1 + (x2-x1)*(by2-y1)/(y2-y1)
         y = by2
      endif

      if (c.eq.c1) then
         x1 = x
         y1 = y
         ik = 1
         go to 1
      endif
      x2 = x
      y2 = y
      go to 2

      END

      SUBROUTINE GWIOCLIP2DWORLD(X1,Y1,X2,Y2,IC)
      IMPLICIT INTEGER (A-Z)
      real x1,y1,x2,y2,x,y
      real bx1,by1,bx2,by2
      parameter (maxnumber=2**15-1)

      bx1 = -maxnumber
      bx2 =  maxnumber
      by1 = -maxnumber
      by2 =  maxnumber

      ik = 0
    1   continue
      if (x1.lt.bx1) then
         c1 = 1
       else if (x1.gt.bx2) then
         c1 = 2
       else
         c1 = 0
      endif
      if (clip.eq.1) then
         if (y1.lt.by1) then
            c1 = c1 + 4
          else if (y1.gt.by2) then
            c1 = c1 + 8
         endif
      endif

      if (ik.ne.0) go to 3
    2   continue
      if (x2.lt.bx1) then
         c2 = 1
       else if (x2.gt.bx2) then
         c2 = 2
       else
         c2 = 0
      endif
      if (clip.eq.1) then
         if (y2.lt.by1) then
            c2 = c2 + 4
          else if (y2.gt.by2) then
            c2 = c2 + 8
         endif
      endif

    3   continue
      ic = 1
      if (c1.eq.0.and.c2.eq.0) return
      if (iand(c1,c2).ne.0) then
         ic = 0
         return
      endif
      if (c1.ne.0) then
         c = c1
       else
         c = c2
      endif
      if (x1.eq.x2) then
         if (clip.eq.1) then
            if (y1.lt.by1) then
               y1 = by1
             else if (y1.gt.by2) then
               y1 = by2
            endif
            if (y2.lt.by1) then
               y2 = by1
             else if (y2.gt.by2) then
               y2 = by2
            endif
         endif
         return
       else if (y1.eq.y2) then
         if (x1.lt.bx1) then
            x1 = bx1
          else if (x1.gt.bx2) then
            x1 = bx2
         endif
         if (x2.lt.bx1) then
            x2 = bx1
          else if (x2.gt.bx2) then
            x2 = bx2
         endif
         return
       else if (iand(c,1).ne.0) then
         y = y1 + (y2-y1)*(bx1-x1)/(x2-x1)
         x = bx1
       else if (iand(c,2).ne.0) then
         y = y1 + (y2-y1)*(bx2-x1)/(x2-x1)
         x = bx2
       else if (iand(c,4).ne.0) then
         x = x1 + (x2-x1)*(by1-y1)/(y2-y1)
         y = by1
       else if (iand(c,8).ne.0) then
         x = x1 + (x2-x1)*(by2-y1)/(y2-y1)
         y = by2
      endif

      if (c.eq.c1) then
         x1 = x
         y1 = y
         ik = 1
         go to 1
      endif
      x2 = x
      y2 = y
      go to 2

      END

      SUBROUTINE GWIOBDFREEZ(IER)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /compsmode/ mdps
      common /comgifmode/ mdgif

      ier = 0
*      if (windsw.ne.1) then
*         if (windsw.eq.0) call GWIOINITIAL(1)
         if (windsw.ne.1) then
            if (mdps.eq.0 .and. mdgif.eq.0) ier = -1
         endif
*      endif

      RETURN
      END

      SUBROUTINE GWIOBDFLUSH(IPS)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /compsmode/ mdps
      common /comgifmode/ mdgif

      if (ips.ne.0.and.mdps.ne.0) then
         call postscriptlinestroke
      endif

      if (mdgif.ge.2) then
         call giffileaaspaceflush(1,0,0)
         mdgif = 1
      endif

      RETURN
      END

      SUBROUTINE GWIOCOLOR(N,PAL)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /compsmode/ mdps
      common /comgifmode/ mdgif

*      n=0... both,  n=1... text,  n=2... lines
*      n=256... 256 Color

      if (n.ne.256) then
         pal1 = abs(mod(pal,10))
         ip = 0
         if (col256.ge.0) ip = 1
*         if (n.ne.2.and.pal1.ne.tcolor) then
         if (pal1.ne.tcolor) then
            tcolor = pal1
            ip = 1
         endif
*         if (n.ne.1.and.pal1.ne.lcolor) then
         if (pal1.ne.lcolor) then
            lcolor = pal1
            ip = 1
         endif
         if (windsw.eq.1) then
            if (ip.eq.1) call wpicdrawbasiccolor(pal1)
         endif
         col256 = -1

         if (mdps.ne.0) then
            call postscriptcolor(n,pal)
         endif
         if (mdgif.ne.0) then
            call giffilecolor(n,pal)
         endif
       else
         if (col256.lt.0.or.pal.ne.col256) then
            col256 = pal
            if (col256.lt.0)   col256 = 0
            if (col256.ge.maxcol256) col256 = maxcol256-1
            if (windsw.eq.1) then
               call wpicdrawextendcolor(col256)
            endif

            if (mdps.ne.0) then
               call postscriptcolor(n,col256)
            endif
            if (mdgif.ne.0) then
               call giffilecolor(n,col256)
            endif
         endif
      endif

      RETURN
      END

      SUBROUTINE GWIOGRADCOLOR(N,PAL,CS)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      REAL CS

      ncs = cs*32

*      n=0... both,  n=1... text,  n=2... lines
*      n=256... 256 Color

      if (col256.lt.0.or.pal.ne.col256) then
         col256 = pal
         if (col256.lt.0)   col256 = 0
         if (col256.ge.maxcol256) col256 = maxcol256-1
         if (windsw.eq.1) then
            call wpicdrawextend2color(col256,ncs)
         endif

         if (mdps.ne.0) then
            call postscriptcolor(n,col256)
         endif
         if (mdgif.ne.0) then
            call giffilecolor(n,col256)
         endif
      endif

      RETURN
      END

      SUBROUTINE GWIOPSET(X,Y)
      IMPLICIT INTEGER (A-Z)
      real x,y
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /compsmode/ mdps
      common /comgifmode/ mdgif

*      if (windsw.ne.1) then
*         if (windsw.eq.0) call GWIOINITIAL(1)
*         if (windsw.ne.1.and.windsw.ne.-1) return
*       endif

      if (clip.ne.0) then
        if (x.lt.bx1.or.x.gt.bx2.or.y.lt.by1.or.y.gt.by2) return
      endif

      if (windsw.eq.1) then
         show = 1
         x0 = grate*(x + ixoff) + 0.5
         y0 = grate*(y + iyoff) + 0.5
         call wpicdrawapoint(x0,y0)
      endif

      if (mdps.ne.0) then
         call postscriptdot(x,y)
      endif
      if (mdgif.ne.0) then
         call giffiledot(x,y)
      endif

      RETURN
      END

      SUBROUTINE GWIOIPSET(X,Y)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgifmode/ mdgif

      if (windsw.ne.1) then
         if (windsw.lt.0) call GWIOINITIAL(1)
*         if (windsw.ne.1.and.mdgif.eq.0) return
      endif

      if (clip.ne.0) then
        if (x.lt.bx1.or.x.gt.bx2.or.y.lt.by1.or.y.gt.by2) return
      endif

         show = 1
      if (windsw.eq.1) then
*         show = 1
         x0   = grate*(x + ixoff) + 0.5
         y0   = grate*(y + iyoff) + 0.5
         call wpicdrawapoint(x0,y0)
      endif
*      if (mdgif.ne.0) then
*         call giffiledot(x,y)
*      endif

      RETURN
      END

      SUBROUTINE GWIOLINE(X1,Y1,X2,Y2,DC0)
      IMPLICIT INTEGER (A-Z)
      real x1,y1,x2,y2,r,cs,sn,vx,vy
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comarrows/ arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      common /comlinelim/ linelim
      real linelim
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      integer xx(3),yy(3)
      real xr1,xr2,yr1,yr2,xr0,yr0,len

      if (dc0.eq.-100) then
         if (mdps.ne.0) then
            call postscriptcnline(xr1,yr1,xr2,yr2,1)
         endif
         return
      endif

*      if (windsw.ne.1) then
*         if (windsw.eq.0) call GWIOINITIAL(1)
*         if (windsw.ne.1.and.windsw.ne.-1) return
*      endif

      dc   = dc0
      if (dc0.eq.100) dc = 0
      xr1  = x1
      yr1  = y1
      xr2  = x2
      yr2  = y2
      icv  = 0
      if (windsw.eq.1) show = 1
      if (dc.eq.0) then
         if (clip.ne.0) then
            call gwioclip2d(xr1,yr1,xr2,yr2,ic)
            if (ic.eq.0) return
          else
            call gwioclip2dworld(xr1,yr1,xr2,yr2,ic)
            if (ic.eq.0) return
         endif
         if (linelim.gt.0) then
            len = (xr1-xr2)**2+(yr1-yr2)**2
            if (len.gt.linelim) return
         endif
         if (windsw.eq.1) then
            xx1  = grate*(xr1 + ixoff) + 0.5
            yy1  = grate*(yr1 + iyoff) + 0.5
            xx2  = grate*(xr2 + ixoff) + 0.5
            yy2  = grate*(yr2 + iyoff) + 0.5
            call wpicdrawsegment(xx1,yy1,xx2,yy2)
         endif
       else if (dc.eq.1.or.dc.eq.2) then
         if (clip.ne.0) then
            xr1 = min(x1,x2)
            xr2 = max(x1,x2)
            yr1 = min(y1,y2)
            yr2 = max(y1,y2)
            if (xr1.gt.bx2.or.xr2.lt.bx1
     +               .or.yr1.gt.by2.or.yr2.lt.by1) return
            xr1 = max(xr1,bx1)
            xr2 = min(xr2,bx2)
            yr1 = max(yr1,by1)
            yr2 = min(yr2,by2)
         endif
         if (windsw.eq.1) then
            xx1  = grate*(xr1 + ixoff) + 0.5
            yy1  = grate*(yr1 + iyoff) + 0.5
            xx2  = grate*(xr2 + ixoff) + 0.5
            yy2  = grate*(yr2 + iyoff) + 0.5
            call wpicdrawrectangle(xx1,yy1,xx2,yy2,dc-1)
         endif
       else
         xr2  = x1 + arrowmag*(x2-x1)
         yr2  = y1 + arrowmag*(y2-y1)
         xr0  = xr2
         yr0  = yr2
         if (clip.ne.0) then
             call gwioclip2d(xr1,yr1,xr2,yr2,ic)
             if (ic.eq.0) return
         endif
         xx1  = grate*(xr1 + ixoff) + 0.5
         yy1  = grate*(yr1 + iyoff) + 0.5
         xx2  = grate*(xr2 + ixoff) + 0.5
         yy2  = grate*(yr2 + iyoff) + 0.5
         cs   = xr0 - xr1
         sn   = yr0 - yr1
         r    = sqrt(cs*cs + sn*sn)
         if (xr0.ne.xr2.or.yr0.ne.yr2) then
            icv = 1
          else if (r.gt.0.d0) then
            if (arrowl*arhead.gt.r) then
               vx = r
               vy = r*arrowr
             else
               vx = arrowl*arhead
               vy = arrowh*arhead
            endif
            cs = cs/r
            sn = sn/r
          else
            vx = 0.d0
         endif
         if (windsw.eq.1) then
            if (r.ge.arrowmin) then
               call wpicdrawsegment(xx1,yy1,xx2,yy2)
               if (icv.eq.0.and.r.gt.0.0) then
                  xx(1) = grate*(xr2 - vx*cs - vy*sn + ixoff)+0.5
                  yy(1) = grate*(yr2 - vx*sn + vy*cs + iyoff)+0.5
                  xx(2) = grate*(xr2 - vx*cs + vy*sn + ixoff)+0.5
                  yy(2) = grate*(yr2 - vx*sn - vy*cs + iyoff)+0.5
                  xx(3) = xx2
                  yy(3) = yy2
                  call wpicdrawlines(xx,yy,3,2)
               endif
            endif
         endif
      endif          

      if (mdps.ne.0) then
         if (dc0.eq.100) then
            call postscriptcnline(xr1,yr1,xr2,yr2,0)
          else if (dc.le.2) then
            call postscriptline(xr1,yr1,xr2,yr2,dc)
          else
            if (r.ge.arrowmin) then
               call postscriptarrow(xr1,yr1,xr2,yr2,vx,vy,cs,sn,icv)
            endif
         endif
      endif

      if (mdgif.ne.0) then
         if (dc.le.2) then
            call giffileline(xr1,yr1,xr2,yr2,dc)
          else
            if (r.ge.arrowmin) then
               call giffilearrow(xr1,yr1,xr2,yr2,vx,vy,cs,sn,icv)
            endif
         endif
      endif

      RETURN
      END

      SUBROUTINE GWIOSPLINE(X1,DX1,Y1,DY1,X2,DX2,Y2,DY2)
      IMPLICIT INTEGER (A-Z)
      parameter (maxnode=16)
      real x1,y1,x2,y2,dx1,dy1,dx2,dy2
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      real xr1,xr2,yr1,yr2,t,dt
      real wx0,wx1,wx2,wx3,wy0,wy1,wy2,wy3

*      if (windsw.ne.1) then
*         if (windsw.eq.0) call GWIOINITIAL(1)
*         if (windsw.ne.1.and.windsw.ne.-1) return
*      endif

      if (clip.ne.0) then
         xr1  = x1
         yr1  = y1
         xr2  = x2
         yr2  = y2
         call gwioclip2d(xr1,yr1,xr2,yr2,ic)
         if (ic.eq.0) return
      endif

      if (windsw.eq.1) show = 1
      wx0  = x1
      wx1  = dx1
      wx2  = 3*(x2-x1)-(2*dx1+dx2)
      wx3  = 2*(x1-x2)+dx1+dx2
      wy0  = y1
      wy1  = dy1
      wy2  = 3*(y2-y1)-(2*dy1+dy2)
      wy3  = 2*(y1-y2)+dy1+dy2

      dt = 1.0/maxnode

      if (windsw.eq.1) then
         xr1  = x1
         yr1  = y1
         xx1  = grate*(xr1 + ixoff) + 0.5
         yy1  = grate*(yr1 + iyoff) + 0.5
         do i = 1, maxnode
            t   = dble(i)*dt
            xr2 = wx0+t*(wx1+t*(wx2+t*wx3))
            yr2 = wy0+t*(wy1+t*(wy2+t*wy3))
            xx2 = grate*(xr2 + ixoff) + 0.5
            yy2 = grate*(yr2 + iyoff) + 0.5
            call wpicdrawsegment(xx1,yy1,xx2,yy2)
            xx1 = xx2
            yy1 = yy2
         enddo
      endif

      if (mdps.ne.0) then
         xr1  = x1
         yr1  = y1
         xr2  = x2
         yr2  = y2
         call postscriptspline(xr1,dx1,yr1,dy1,xr2,dx2,yr2,dy2)
      endif

      if (mdgif.ne.0) then
         xr1  = x1
         yr1  = y1
         do i = 1, maxnode
            t   = dble(i)*dt
            xr2 = wx0+t*(wx1+t*(wx2+t*wx3))
            yr2 = wy0+t*(wy1+t*(wy2+t*wy3))
            call giffileline(xr1,yr1,xr2,yr2,0)
            xr1 = xr2
            yr1 = yr2
         enddo
      endif

      RETURN
      END

      SUBROUTINE GWIOPOLYGON(X,Y,N,MD)
*     Maximum Polygon Node Number is 1000
      IMPLICIT INTEGER (A-Z)
      parameter (nodmax=1000)
      real x(n),y(n)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      real xr1,yr1,xr2,yr2
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      integer xx(nodmax+1),yy(nodmax+1)
      real    px(nodmax+1),py(nodmax+1)
      equivalence (px,xx),(py,yy)

*      if (windsw.ne.1) then
*          if (windsw.eq.0) call GWIOINITIAL(1)
*         if (windsw.ne.1.and.windsw.ne.-1) return
*      endif

      nn  = n
      n1  = nn
      if (nn.gt.nodmax) nn = nodmax
      mmd = md

      icl = nn
      if (clip.ne.0.and.mmd.gt.1) then
         do i = 1, nn
            if (x(i).lt.bx1.or.x(i).gt.bx2
     ,                .or.y(i).lt.by1.or.y(i).gt.by2) icl = icl-1
         enddo
      endif
      if (icl.le.0) return

      if (windsw.eq.1) then
         show = 1
         do i = 1, nn
            xx(i)  = grate*(x(i) + ixoff) + 0.5
            yy(i)  = grate*(y(i) + iyoff) + 0.5
         enddo
         if (mmd.eq.0) then
            mmd = 1
          else if (mmd.eq.1) then
            nn    = nn + 1
            xx(nn) = xx(1)
            yy(nn) = yy(1)
         endif

         if (clip.ne.0.and.mmd.eq.1) then
            do i = 1, n-1
               xr1  = x(i)
               yr1  = y(i)
               xr2  = x(i+1)
               yr2  = y(i+1)
               call gwioclip2d(xr1,yr1,xr2,yr2,ic)
               if (ic.ne.0) then
                  xx1  = grate*(xr1 + ixoff) + 0.5
                  yy1  = grate*(yr1 + iyoff) + 0.5
                  xx2  = grate*(xr2 + ixoff) + 0.5
                  yy2  = grate*(yr2 + iyoff) + 0.5
                  call wpicdrawsegment(xx1,yy1,xx2,yy2)
               endif
            enddo
            xr1  = x(n)
            yr1  = y(n)
            xr2  = x(1)
            yr2  = y(1)
            call gwioclip2d(xr1,yr1,xr2,yr2,ic)
            if (ic.ne.0) then
               xx1  = grate*(xr1 + ixoff) + 0.5
               yy1  = grate*(yr1 + iyoff) + 0.5
               xx2  = grate*(xr2 + ixoff) + 0.5
               yy2  = grate*(yr2 + iyoff) + 0.5
               call wpicdrawsegment(xx1,yy1,xx2,yy2)
            endif
          else if (mmd.eq.3) then
            call wpicdrawlines(xx,yy,nn,2)
            call wpicdrawlines(xx,yy,nn,1)
          else
            call wpicdrawlines(xx,yy,nn,mmd)
         endif
      endif

      if (mdps.ne.0) then
         do i = 1, n1
            px(i)  = x(i)
            py(i)  = y(i)
         enddo
         mmd = md
         if (mmd.eq.3) mmd = 2
         call postscriptpolygon(px,py,n1,mmd)
      endif
      if (mdgif.ne.0) then
         mmd = md
         if (mmd.eq.3) mmd = 2
         call giffilepolygon(x,y,n1,mmd)
      endif

      RETURN
      END

      SUBROUTINE GWIOGRADFILLBOX(X1,Y1,X2,Y2,CNC)
      IMPLICIT INTEGER (A-Z)
      real x1,y1,x2,y2,cnc(4)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      real xr1,xr2,yr1,yr2,ff,rx1,rx2,ry1,ry2,c1,c2,c3,c4,d,r1,r2

*      if (windsw.ne.1) then
*         if (windsw.lt.0) call GWIOOPENWINDOW(1)
*         if (windsw.ne.1.and.mdgif.eq.0) return
*      endif

      xr1  = x1
      yr1  = y1
      xr2  = x2
      yr2  = y2

      if (clip.ne.0) then
         xr1 = min(x1,x2)
         xr2 = max(x1,x2)
         yr1 = min(y1,y2)
         yr2 = max(y1,y2)
         if (xr1.gt.bx2.or.xr2.lt.bx1
     +               .or.yr1.gt.by2.or.yr2.lt.by1) return
         if (x1.gt.x2) then
            ff     = cnc(1)
            cnc(1) = cnc(3)
            cnc(3) = ff
            ff     = cnc(2)
            cnc(2) = cnc(4)
            cnc(4) = ff
         endif
         if (y1.gt.y2) then
            ff     = cnc(1)
            cnc(1) = cnc(2)
            cnc(2) = ff
            ff     = cnc(3)
            cnc(3) = cnc(4)
            cnc(4) = ff
         endif
         rx1 = xr1
         rx2 = xr2
         ry1 = yr1
         ry2 = yr2
         ind = 0
         if (xr1.lt.bx1) then
            xr1 = bx1
            ind = 1
         endif
         if (xr2.gt.bx2) then
            xr2 = bx2
            ind = 1
         endif
         if (yr1.lt.by1) then
            yr1 = by1
            ind = 1
         endif
         if (yr2.gt.by2) then
            yr2 = by2
            ind = 1
         endif
         if (ind.ne.0) then
            r1  = (yr1-ry1)*cnc(4)-(yr1-ry2)*cnc(3)
            r2  = (yr1-ry2)*cnc(1)-(yr1-ry1)*cnc(2)
            c1  = (xr1-rx1)*r1 + (xr1-rx2)*r2
            c3  = (xr2-rx1)*r1 + (xr2-rx2)*r2
            r1  = (yr2-ry1)*cnc(4)-(yr2-ry2)*cnc(3)
            r2  = (yr2-ry2)*cnc(1)-(yr2-ry1)*cnc(2)
            c2  = (xr1-rx1)*r1 + (xr1-rx2)*r2
            c4  = (xr2-rx1)*r1 + (xr2-rx2)*r2
            d   = (rx1-rx2)*(ry1-ry2)
            cnc(1) = c1/d
            cnc(2) = c2/d
            cnc(3) = c3/d
            cnc(4) = c4/d
         endif
      endif

      do 10 i = 1, 4
         if (cnc(i).lt.0)   cnc(i) = 0
         if (cnc(i).ge.maxcol256) cnc(i) = maxcol256-1
   10 continue
      col256 = cnc(1)

      if (windsw.eq.1) then
         show = 1
         xx1  = grate*(xr1 + ixoff) + 0.5
         yy1  = grate*(yr1 + iyoff) + 0.5
         xx2  = grate*(xr2 + ixoff) + 0.5
         yy2  = grate*(yr2 + iyoff) + 0.5
         call wpicdrawgradrectangle(xx1,yy1,xx2,yy2,cnc)
      endif

      if (mdps.ne.0) then
         xr1  = x1
         yr1  = y1
         xr2  = x2
         yr2  = y2
         call postscriptgradrectangle(xr1,yr1,xr2,yr2,cnc)
      endif

      if (mdgif.ne.0) then
         call giffilegradrectangle(xr1,yr1,xr2,yr2,cnc)
      endif

      RETURN
      END

      SUBROUTINE GWIOCIRCLE(CX,CY,MODE)
      IMPLICIT INTEGER (A-Z)
      real cx,cy
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /compsmode/ mdps
      common /comgifmode/ mdgif

*      if (windsw.ne.1) then
*          if (windsw.eq.0) call GWIOINITIAL(1)
*          if (windsw.ne.1.and.windsw.ne.-1) return
*        endif

      if (clip.ne.0) then
          if (cx.lt.bx1.or.cx.gt.bx2.or.cy.lt.by1.or.cy.gt.by2) return
      endif

      if (windsw.eq.1) then
         show = 1
         xx = grate*(cx + ixoff) + 0.5
         yy = grate*(cy + iyoff) + 0.5
         dx = grate*diamx*diammag
         dy = grate*diamy*diammag
         call wpicdrawcircle(xx,yy,dx,dy,mode)
      endif

      if (mdps.ne.0) then
         call postscriptcirc(cx,cy,diamx*diammag,diamy*diammag,mode)
      endif
      if (mdgif.ne.0) then
         call giffilecirc(cx,cy,diamx*diammag,diamy*diammag,mode)
      endif

      RETURN
      END

      SUBROUTINE GWIOGRADCIRCLE(CX,CY,ZP,MODE)
      IMPLICIT INTEGER (A-Z)
      real cx,cy,zp,dimg
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comgpcolor/ tcolor,lcolor,col256
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /compsmode/ mdps
      common /comgifmode/ mdgif

*      if (windsw.ne.1) then
*          if (windsw.eq.0) call GWIOINITIAL(1)
*          if (windsw.ne.1.and.windsw.ne.-1) return
*        endif

      if (clip.ne.0) then
          if (cx.lt.bx1.or.cx.gt.bx2.or.cy.lt.by1.or.cy.gt.by2) return
      endif

      col256 = maxcol256

      dimg = diammag*zp
      if (windsw.eq.1) then
         show = 1
         xx = grate*(cx + ixoff) + 0.5
         yy = grate*(cy + iyoff) + 0.5
         dx = grate*diamx*dimg
*         dy = grate*diamy*diammag
         call wpicdrawgradcircle(xx,yy,dx,mode)
      endif

      if (mdps.ne.0) then
         call postscriptgradcirc(cx,cy,diamx*dimg,diamy*dimg,mode)
      endif
      if (mdgif.ne.0) then
         call giffilegradcirc(cx,cy,diamx*dimg,mode)
      endif

      RETURN
      END

      SUBROUTINE GWIOMARKING(CX,CY,MODE)
      IMPLICIT INTEGER (A-Z)
      real cx,cy
      parameter (nodmax=30)
      real x(nodmax),y(nodmax)
      real dx(nodmax),dy(nodmax)
      real*8 pi,dth
      PARAMETER (PI=3.141592653589793D0)
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      save dx,dy

      if (mode.lt.0) then
         if (mkspec.eq.0) return
         dth = pi*2/mkspec
         do i = 0, mkspec-1, 2
            dx(i+1) = diammag*diam1*sin(dth*i)
            dy(i+1) = -diammag*diam1*cos(dth*i)
         enddo
         do i = 1, mkspec-1, 2
            dx(i+1) = diammag*diam2*sin(dth*i)
            dy(i+1) = -diammag*diam2*cos(dth*i)
         enddo
         return
      endif

      if (mkspec.eq.0) then
         call GWIOCIRCLE(CX,CY,MODE)
       else
         do i = 1, mkspec
            x(i) = cx + dx(i)
            y(i) = cy + dy(i)
         enddo
         call GWIOPOLYGON(X,Y,MKSPEC,MODE+1)
      endif

      RETURN
      END

      SUBROUTINE GWIOMODES(MW,MPS,MGIF,PSYOFF)
      IMPLICIT INTEGER (A-Z)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgpwratio/ gpnum,gpden,bxw,byw,iwin,jwin,rmode,gwmode
      real PSYOFF

      if (mw.eq.9999) then
         call GWIOINITIAL(9999)
         return
      endif

      mdps = mod(mps,10)
      if (mps.ge.10) return
      mdgif = mod(mgif,10)
      if (mdgif.ge.10) return
      md   = mw
      if (md.ge.10) then
         windsw = mod(md,10)
         if (windsw.eq.2) windsw = -1
         return
      endif
      if (md.ne.1) md = -1
      call GWIOINITIAL(md)
      mw      = windsw
      PSYOFF  = by2

      RETURN
      END

*     THIS ROUTINE CHANGE DEFAULT WINDOW SIZE
      SUBROUTINE GWIORATIO(ratenum,rateden,iw0,jw0,io0,jo0,rgmode)
      IMPLICIT INTEGER (A-Z)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgpwratio/ gpnum,gpden,bxw,byw,iwin,jwin,rmode,gwmode
      common /comgp0border/ bx01,by01,bx02,by02,clipsw
      real bx01,by01,bx02,by02
      common /comwinratio/ winrate

      gpnum  = ratenum*winrate
      gpden  = rateden
      rmode   = rgmode
      if (rmode.eq.1) rmode = 0
      gwmode  = 0
      if (rgmode.eq.3.or.rgmode.eq.-3) then
         iwin = ratenum
         jwin = rateden
       else
         iwin    = iw0
         jwin    = jw0
      endif
          
      RETURN
      END

*     THIS ROUTINE STORE WINDOW SIZE AND OFFSET
*     ONECE AFTER THEY STORED, THIS RECALLS CURRENT PARAMETERS
      SUBROUTINE GWIOSETWSIZE(BX,BY,XOFF,YOFF,RN,RD,GWM)
      IMPLICIT INTEGER (A-Z)
      common /comgpwratio/ gpnum,gpden,bxw,byw,iwin,jwin,rmode,gwmode
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      common /comgp0border/ bx01,by01,bx02,by02,clipsw
      real bx01,by01,bx02,by02
      common /comwinratio/ winrate

      if (gwm.eq.0) then
         bx0    = bx
         by0    = by
         ixoff  = xoff
         iyoff  = yoff
       else if (gwm.eq.1) then
         bx     = iwin
         by     = jwin
         bx0    = iwin
         by0    = jwin
         ixoff  = xoff
         iyoff  = yoff
       else if (gwm.eq.3) then
         bx0    = bx
         ixoff  = xoff
         iyoff  = yoff
         gpden  = bx0
         if (jwin.ne.0) then
            iyoff = yoff-(by-jwin)/2
            by    = bx*jwin/iwin
         endif
         by0    = by
       else if (gwm.eq.-3) then
         by0    = by
         ixoff  = xoff
         iyoff  = yoff
         gpden  = by0
         if (jwin.ne.0) then
            ixoff = xoff-(bx-jwin)/2
            bx    = by*jwin/iwin
         endif
         bx0    = bx
      endif

      bxw    = bx0*gpnum/(winrate*gpden)
      byw    = by0*gpnum/(winrate*gpden)
      rn     = gpnum/winrate
      rd     = gpden
           
      gwmode = 1
      bx1    = -ixoff
      by1    = -iyoff
      bx2    = bx0 - ixoff
      by2    = by0 - iyoff
      bx01   = bx1
      by01   = by1
      bx02   = bx2
      by02   = by2

      RETURN
      END

      SUBROUTINE GWIOCOLORSET(SH,SL,SS,NDIV,MODE,ICREQ,ICSYS)
      common /com256color/ maxcol256,maxcol0,maxcolmax
      common /compsmode/ mdps
      common /comgifmode/ mdgif
      REAL*8 SH(*),SL(*),SS(*)
      INTEGER NDIV(*)

      if (mdps.ne.0) then
         call postscriptsetrgb(SH,SL,SS,NDIV,MODE,maxcol0)
      endif
      if (mdgif.ne.0) then
         call giffilesetrgb(SH,SL,SS,NDIV,MODE,maxcol0,ICSYS)
      endif

      call wpicdrawsethlscolor(SH,SL,SS,NDIV,MODE,maxcol0,ICSYS)
      maxcol256 = MODE

      RETURN
      END

      SUBROUTINE GWIOSETAASPACE(MODE)
      IMPLICIT INTEGER (A-Z)
      common /comgifmode/ mdgif

      if (mdgif.ne.0) mdgif = 2+MODE

      RETURN
      END

      SUBROUTINE SCREENGRAPH2D(SX,SY,X,Y)
      common /comgpwinio/ grate,windsw,show,delay
      real grate
      integer windsw,show,delay
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      REAL*8 X,Y,SX,SY

      X  = (SX/grate-X0)/XTAN
      Y  = (SY/grate-Y0)/YTAN

      RETURN
      END

      SUBROUTINE SETTINGSINPUT(LEN,AHEAD,RAD,LINLIM,MODE)
      REAL*8 RAD,LEN,LINLIM
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comarrows/ arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      common /comlinelim/ linelim
      real linelim

      if (mode.eq.0) then
         arrowmag = 1
         diammag  = 1
         arhead   = 1
         linelim  = 0
         return
      endif

      if (mod(mode,2).eq.1) then
         arrowmag = len
         if (arrowmag.lt.0) arrowmag = 0
      endif
      if (mod(mode/2,2).eq.1) then
         diammag = rad
         if (diammag.lt.0) diammag = 0
      endif
      if (mod(mode/4,2).eq.1) then
         if (linlim.lt.0) then
            linelim = 0
          else
            linelim = linlim*linlim
         endif
      endif

      RETURN
      END

      SUBROUTINE GWIOCHANGECLIP(ICLIP)
      IMPLICIT INTEGER (A-Z)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2

      clip = ICLIP

      RETURN
      END
