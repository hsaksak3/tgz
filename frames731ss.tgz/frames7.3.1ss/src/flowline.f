*******************************************************
*              F  R  A  M  E  S   V.7                 *
*                DRAW  STREAM  LINE                   *
*           USING RUNGE-KUTTA APPROXIMATION           *
*         PROGRAMMED BY T. TAGUCHI (SETSUNAN)         *
*                 SINCE MAY/ 1/1999                   *
*******************************************************
      SUBROUTINE FR_FLOW2DLINE(X,Y,NMAX,XFLD,YFLD,NXMAX,NYMAX,ICOL
     ,                                        ,FMIN,ND)
      IMPLICIT REAL*8 (A-H)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,XA,YA,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      REAL*8 XFLD(NXMAX,NYMAX),YFLD(NXMAX,NYMAX)
      REAL*8 X(*),Y(*),FMIN
      REAL*8 X0,Y0,X1,Y1
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /FLUIDREGIONCOM/ RNX1,RNX2,RNY1,RNY2,NX1,NX2,NY1,NY2
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /FLRREGION2COM/ RRXM1,RRXM2,RRYM1,RRYM2
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      SAVE XMIN0,YMIN0

      IF (IGCANVAS.LT.0.AND.NMAX.GE.0) RETURN

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.NXMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - FLOW2DLINE')
            RETURN
         ENDIF
         IF (NX2.GE.NXMAX) NX2 = NXMAX - 1
       ELSE
         NX1 = 0
         NX2 = NXMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.NYMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - FLOW2DLINE')
            RETURN
         ENDIF
         IF (NY2.GE.NYMAX) NY2 = NYMAX - 1
       ELSE
         NY1 = 0
         NY2 = NYMAX - 1
      ENDIF

      IF (NMAX.GE.0) THEN
         IF (IFRAM.EQ.0) THEN
*            IFRAM = 999
            IF (IDFFR2.LT.0) THEN
               IDFR = 0
              ELSE
               IDFR = IDFFR2
            ENDIF
          CALL FR_FRAME2D(DBLE(NX1),DBLE(NX2),DBLE(NY1),DBLE(NY2),IDFR)
         ENDIF
         XT    = (XMAX-XMIN)/(NX2-NX1)
         YT    = (YMAX-YMIN)/(NY2-NY1)
         XMIN0 = XMIN
         YMIN0 = YMIN
       ELSE
         IF (IFRAM.NE.0) THEN
            XT    = (XMAX-XMIN)/(NX2-NX1)
            YT    = (YMAX-YMIN)/(NY2-NY1)
            XMIN0 = XMIN
            YMIN0 = YMIN
          ELSE IF (NFCHK.EQ.0) THEN
            XT    = 1
            YT    = 1
            XMIN0 = NX1
            YMIN0 = NY1
          ELSE
            XT    = (RRXM2-RRXM1)/(NX2-NX1)
            YT    = (RRYM2-RRYM1)/(NY2-NY1)
            XMIN0 = RRXM1
            YMIN0 = RRYM1
         ENDIF
      ENDIF

      IF (NFCHK.EQ.0) THEN
         RNX1  = NX1
         RNX2  = NX2
         RNY1  = NY1
         RNY2  = NY2
       ELSE
         RNX1  = (RNXM1-XMIN0)/XT + NX1
         RNX2  = (RNXM2-XMIN0)/XT + NX1
         RNY1  = (RNYM1-YMIN0)/YT + NY1
         RNY2  = (RNYM2-YMIN0)/YT + NY1
         IF (RNX1.LT.NX1) RNX1 = NX1
         IF (RNX2.GT.NX2) RNX2 = NX2
         IF (RNY1.LT.NY1) RNY1 = NY1
         IF (RNY2.GT.NY2) RNY2 = NY2
      ENDIF

      IF (ND.NE.0) THEN
         DD = 1.D0/DBLE(ND)
        ELSE 
         DD = 0.2D0
      ENDIF
      NN = 1

      IF (NMAX.LT.0) THEN
         NMAX0 = -NMAX
       ELSE
         NMAX0 = NMAX
      ENDIF

      X0  = (X(1)-XMIN0)/XT + NX1
      Y0  = (Y(1)-YMIN0)/YT + NY1

      DO M = 2, NMAX0

         CALL FLOWVALUE(X0,Y0,FX0,FY0,XFLD,YFLD,NXMAX,NYMAX,IND)
         IF (IND.NE.0) GO TO 1000

         FA  = FX0*FX0 + FY0*FY0
         IF (FA.LE.FMIN) GO TO 1000

         DH  = DD/SQRT(FA)
         DH2 = 0.5D0*DH

         DX1 = FX0*DH2
         DY1 = FY0*DH2
         X1  = X0 + DX1
         Y1  = Y0 + DY1
         CALL FLOWVALUE(X1,Y1,FX0,FY0,XFLD,YFLD,NXMAX,NYMAX,IND)
         IF (IND.NE.0) GO TO 800

         DX2 = FX0*DH2
         DY2 = FY0*DH2
         X1  = X0 + DX2
         Y1  = Y0 + DY2
         CALL FLOWVALUE(X1,Y1,FX0,FY0,XFLD,YFLD,NXMAX,NYMAX,IND)
         IF (IND.NE.0) THEN
            DX1 = DX2
            DY1 = DY2
            GO TO 800
         ENDIF

         DX3 = FX0*DH
         DY3 = FY0*DH
         X1  = X0 + DX3
         Y1  = Y0 + DY3
         CALL FLOWVALUE(X1,Y1,FX0,FY0,XFLD,YFLD,NXMAX,NYMAX,IND)
         IF (IND.NE.0) THEN
            DX1 = DX3
            DY1 = DY3
            GO TO 800
         ENDIF

         DX4 = FX0*DH2
         DY4 = FY0*DH2
         X0  = X0 + (DX1 + DX2 + DX2 + DX3 + DX4)/3.D0
         Y0  = Y0 + (DY1 + DY2 + DY2 + DY3 + DY4)/3.D0

         NN     = NN + 1
         X(NN)  = (X0-NX1)*XT + XMIN0
         Y(NN)  = (Y0-NY1)*YT + YMIN0
      ENDDO

*      CALL FRAMESERROR('EXCEED MAXIMUM FIELD LINE STEP - FLOW2DLINE')
      GO TO 1000

  800 CONTINUE      
      IF (IND.EQ.1) THEN
         Y0 = Y0 + DY1*(RNX1-X0)/DX1
         X0 = RNX1
       ELSE IF (IND.EQ.2) THEN
         Y0 = Y0 + DY1*(RNX2-X0)/DX1
         X0 = RNX2
       ELSE IF (IND.EQ.4) THEN
         X0 = X0 + DX1*(RNY1-Y0)/DY1
         Y0 = RNY1
       ELSE
         X0 = X0 + DX1*(RNY2-Y0)/DY1
         Y0 = RNY2
      ENDIF
      NN     = NN + 1
      X(NN)  = (X0-NX1)*XT + XMIN0
      Y(NN)  = (Y0-NY1)*YT + YMIN0

 1000 CONTINUE
      IF (NMAX.LT.0) THEN
         NMAX = NN
       ELSE IF (NN.GT.1) THEN
         CALL FR_GRAPH2D(X,Y,NN,ICOL,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_FLOW2DRGN(RXMIN,RXMAX,RYMIN,RYMAX)
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /FLRREGION2COM/ RRXM1,RRXM2,RRYM1,RRYM2
      REAL*8 RXMIN,RXMAX,RYMIN,RYMAX

      RNXM1    = RXMIN
      RNXM2    = RXMAX
      RNYM1    = RYMIN
      RNYM2    = RYMAX
      IF (NFCHK.EQ.0) THEN
         RRXM1 = RXMIN
         RRXM2 = RXMAX
         RRYM1 = RYMIN
         RRYM2 = RYMAX
      ENDIF        
      NFCHK    = 1

      RETURN
      END

      SUBROUTINE FR_2DFLOWBOX(RXMIN,RXMAX,RYMIN,RYMAX,MASK)
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /FLRREGION2COM/ RRXM1,RRXM2,RRYM1,RRYM2
      REAL*8 RXMIN,RXMAX,RYMIN,RYMAX

      RNXM1    = RXMIN
      RNXM2    = RXMAX
      RNYM1    = RYMIN
      RNYM2    = RYMAX
      IF (NFCHK.EQ.0) THEN
         RRXM1 = RXMIN
         RRXM2 = RXMAX
         RRYM1 = RYMIN
         RRYM2 = RYMAX
      ENDIF        
      NFCHK    = 1

      RETURN
      END

      SUBROUTINE FLOWVALUE(X,Y,FX,FY,XFLD,YFLD,NXMAX,NYMAX,IND)
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 XFLD(0:NXMAX-1,0:NYMAX-1),YFLD(0:NXMAX-1,0:NYMAX-1)
      COMMON /FLUIDREGIONCOM/ RNX1,RNX2,RNY1,RNY2,NX1,NX2,NY1,NY2
      REAL RNX1,RNX2,RNY1,RNY2
      
      IF (X.LT.RNX1) THEN
         IND = 1
         GO TO 999
       ELSE IF (X.GT.RNX2) THEN
         IND = 2
         GO TO 999
       ELSE IF (Y.LT.RNY1) THEN
         IND = 4
         GO TO 999
       ELSE IF (Y.GT.RNY2) THEN
         IND = 8
         GO TO 999
      ENDIF

      IX  = X
      IY  = Y
      DX  = X - IX
      DY  = Y - IY
      IF (IX.EQ.NX2) THEN
         IF (IY.EQ.NY2) THEN
            FX   = XFLD(IX,IY)
            FY   = YFLD(IX,IY)
          ELSE
            FX = (1.D0 - DY)*XFLD(IX,IY) + DY*XFLD(IX,IY+1)
            FY = (1.D0 - DY)*YFLD(IX,IY) + DY*YFLD(IX,IY+1)
         ENDIF
       ELSE IF (IY.EQ.NY2) THEN
         FX   = (1.D0 - DX)*XFLD(IX,IY) + DX*XFLD(IX+1,IY)
         FY   = (1.D0 - DX)*YFLD(IX,IY) + DX*YFLD(IX+1,IY)
       ELSE
         FXC1 = (1.D0 - DY)*XFLD(IX,IY)   + DY*XFLD(IX,IY+1)
         FXC2 = (1.D0 - DY)*XFLD(IX+1,IY) + DY*XFLD(IX+1,IY+1)
         FX   = (1.D0 - DX)*FXC1 + DX*FXC2
         FYC1 = (1.D0 - DY)*YFLD(IX,IY)   + DY*YFLD(IX,IY+1)
         FYC2 = (1.D0 - DY)*YFLD(IX+1,IY) + DY*YFLD(IX+1,IY+1)
         FY   = (1.D0 - DX)*FYC1 + DX*FYC2
      ENDIF

      IND  = 0
      
  999 RETURN
      END

      SUBROUTINE FR_FLOWSPACE(F,NMAX,X,IMAX,AREA,MODE)
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 F(*),X(*)
      SAVE DS
      DATA DS/0.D0/
*      FUN(Y) = (Y-1)*DXDY + X1

      AREA = 0.D0
      IF (NMAX.LT.2) THEN
         CALL FRAMESERROR('NMAX MUST BE GREATER THAN 1 - FLOWSPACE')
         RETURN
      ENDIF

      FS = 0.5D0*(ABS(F(1))+ABS(F(NMAX)))
      DO N = 2, NMAX-1
         FS = FS + ABS(F(N))
      ENDDO

      X1  = X(1)
      IF (IMAX.GT.1) THEN
         IF (X1.EQ.X(IMAX)) THEN
            DO I = 2, IMAX-1
               X(I) = X1
            ENDDO
            DS   = 0.D0
            RETURN
         ENDIF
         DXDY  = (X(IMAX)-X1)/(NMAX-1)
         DX    = ABS(DXDY)
         IF (MODE.EQ.1) THEN
            IMAX0 = IMAX+1
            DXX   = 0.5D0
            DS    = FS*DX/(IMAX-0.5D0)
            I1    = 1
          ELSE IF (MODE.EQ.2) THEN
            IMAX0 = IMAX+1
            DXX   = 1.D0
            DS    = FS*DX/(IMAX-0.5D0)
            I1    = 2
          ELSE IF (MODE.EQ.3) THEN
            IMAX0 = IMAX+2
            DXX   = 0.5D0
            DS    = FS*DX/IMAX
            I1    = 1
          ELSE
            IMAX0 = IMAX
            DXX   = 1.D0
            DS    = FS*DX/(IMAX-1)
            I1    = 2
         ENDIF
         IMX   = IMAX0-1
         AREA  = FS*DXDY
       ELSE IF (IMAX.GE.-1) THEN
         CALL FRAMESERROR('IMAX MUST BE GREATER THAN 1 - FLOWSPACE')
         RETURN
       ELSE
         IMX   = -IMAX
         IF (DS.EQ.0.D0) THEN
            DO I = 2, IMX
               X(I) = X1
            ENDDO
            IMAX  = IMX
            RETURN
         ENDIF
         DXDY  = (X(IMX)-X1)/(NMAX-1)
         DX    = ABS(DXDY)
         NMAX0 = NMAX
         IF (MODE.EQ.1.OR.MODE.EQ.3) THEN
            DXX = 0.5D0
            I1  = 1
          ELSE
            DXX = 1.D0
            I1  = 2
         ENDIF
         AREA  = FS*DXDY
      ENDIF

      N   = 1
      AF1 = ABS(F(1))*DX
      AF2 = ABS(F(2))*DX
      FS1 = 0.D0
      FS  = 0.5D0*(AF1+AF2)
      DO 10 I = I1, IMX
         SX = DS*(I-DXX)
  2      IF (SX.LT.FS) THEN
            DF = AF1+SQRT(AF1*AF1+2.D0*(AF2-AF1)*(SX-FS1))
            X(I) = (DBLE(N-1)+2.D0*(SX-FS1)/DF)*DXDY + X1
            GO TO 10
         ENDIF
         N = N+1
         IF (N.GE.NMAX) THEN
            IF (SX.EQ.FS) THEN
               X(I) = (DBLE(NMAX-1))*DXDY + X1

               IF (IMAX.LT.0) IMAX = I
             ELSE
               IF (IMAX.LT.0) IMAX = I-1
            ENDIF
            RETURN
         ENDIF
         AF1 = AF2
         AF2 = ABS(F(N+1))*DX
         FS1 = FS
         FS  = FS1 + 0.5D0*(AF1+AF2)
         GO TO 2
  10   CONTINUE

      RETURN
      END
