/*****************************************
 *          F  R  A  M  E  S  V.7        *
 *    Filing routines for unix machine   *
 *****************************************
*/
#include <stdio.h>

#define NOT_USED_TPLOT
#include "frames.h"
#include "frames_plt.h"
#include "frames_canvas.h"

/*     VERSION  = 3   FROM V6.0
 *     VERSION  = 4   FROM V6.2
 *     VERSION  = 5   FROM V6.3
 *     VERSION  = 6   FROM V7.0
 *     VERSION  = 7   FROM V7.1
 *     VERSION  = 8   FROM V7.2
 *     VERSION  = 9   FROM V7.3
 *     VERSION  = 10  FROM V7.3.1		*/
#define VERSION		10
#define BUFMAX		4096
#define NHEAD		7
#define IDIV		(BUFMAX/1024)

static int  one=1;

/*	header[0]=42;		header[1]=84;
	header[2]=65;		header[3]=71;

/ *	BUFFER[4]=42;   ! Before v5.4		* /
/ *	BUFFER[4]=43;   ! Before v6.1		* /
	header[4]=44;

/ *	BUFFER[6]=1;
	BUFFER[5]=2;    ! Before v6.0		* /
	header[5]=VERSION;		header[6]=2;	*/

static char header[NHEAD]={42,84,65,71,44,VERSION,2};
static char BUFFER[BUFMAX];
/*      MAXPAGE = 100000	*/
static int	IFP=0,IFPAGE=0,MAXPAGE=-1;

static char *add_plt(char *name)
{
	int i=0;
	static char pltname[1024];

	while(*name) {
		pltname[i++]=*name++;
	}
	pltname[i++]='.';
	pltname[i++]='p';
	pltname[i++]='l';
	pltname[i++]='t';
	pltname[i++]='\0';

	return pltname;
}


void plt_fileclose(FILE *fp)
{
	char buf=FRAMES_GEND;

	fwrite(&buf,1,1,fp);
	fclose(fp);
}

void setgfilemaxpage(int *maxp)
{
      MAXPAGE=*maxp;
}

static int flush_buffer_pages(int mode)
{
	int ind,rgb[3],ns,csize,err;
	char preamble[20];
	frames_canvas *gcanvas=get_gcanvasp();
/*
	if (mode==2) ;  Reset clear command
	if (mode==3) ;  Remove the last clear command
*/
	if (mode>=2) {
		if (IFP>0 && BUFFER[IFP-1]==FRAMES_GCLEAR) IFP--;
	}

	err=0;
	if (IFP>0) {
		if (MAXPAGE>0 && IFPAGE>=MAXPAGE) {
			err=MAXPAGE*IDIV;
			return err;
		}

		if (gcanvas->fp==NULL) {
			if ((gcanvas->fp=fopen(add_plt(gcanvas->fname),"wb"))==NULL) {
				return 1;
			}
			ind=fwrite(header,1,NHEAD,gcanvas->fp);
			preamble[0]=(gcanvas->width)&0xff;			preamble[1]=(gcanvas->width)>>8;
			preamble[2]=(gcanvas->height)&0xff;			preamble[3]=(gcanvas->height)>>8;
			preamble[4]=(gcanvas->xoff)&0xff;			preamble[5]=(gcanvas->xoff)>>8;
			preamble[6]=(gcanvas->yoff)&0xff;			preamble[7]=(gcanvas->yoff)>>8;
			preamble[8]=gcanvas->windowmode[0];			preamble[9]=(gcanvas->windowmode[1])&0x01;
			ns=10;
			get_canvas_rgb(rgb);
			if (rgb[0] >= 0) {
				preamble[9]|=0x02;
				preamble[10]=rgb[0]&0xff;	preamble[11]=(rgb[0]>>8)&0xff;	preamble[12]=rgb[0]>>16;
				preamble[13]=rgb[1]&0xff;	preamble[14]=(rgb[1]>>8)&0xff;	preamble[15]=rgb[1]>>16;
				preamble[16]=rgb[2]&0xff;	preamble[17]=(rgb[2]>>8)&0xff;	preamble[18]=rgb[2]>>16;
				ns+=9;
			}
			get_canvas_charsize(&csize);
			if (csize > 0) {
				preamble[9]|=0x04;
				preamble[ns]=csize&0xff;	preamble[ns+1]=csize>>8;
				ns+=2;
			}
			ind=fwrite(preamble,1,ns,gcanvas->fp);
		}

		IFPAGE++;
		ind=fwrite(BUFFER,1,IFP,gcanvas->fp);
		if (ind!=IFP) {
			return 1;
		}
		IFP=0;
		if (mode>=2) fflush(gcanvas->fp);
	}

	if (mode==2) BUFFER[IFP++]=FRAMES_GCLEAR;
	return err;
}

void flushbufferpages(int *err,int *ch)
{
	*err=flush_buffer_pages(*ch);
}

#ifndef BIGENDIAN
static void gsend_1bytechars(char b[],int nn,int *err)
{
	int i;

	*err=0;
	if (nn<0) nn=-nn;
	for (i=0;i<nn;i++) {
		if (IFP>=BUFMAX) {
			*err=flush_buffer_pages(1);
			if (*err) return;
		}
		BUFFER[IFP++]=b[i];
	}
}

static void gsend_prealproc(int n,int nn,int *err)
{
	union linteg { unsigned char c[4];	signed int l; } b;

/*     Require 3 Bytes	*/
	b.l=n;
	if (b.c[3]==0 || b.c[3]==0xff) {
		b.l=(b.l>>1)&0xfffffffe;
		gsend_1bytechars((char *)(b.c),nn,err);
	  }
	  else {
	  	b.l|=0x00000100;
		gsend_1bytechars((char *)(&(b.c[1])),nn,err);
	}
}

#else
static void gsend_1bytechars(char b[],int nn,int *err)
{
	int i;

	*err=0;
	if (nn<0) {
		for (i=0;i<-nn;i++) {
			if (IFP>=BUFMAX) {
				*err=flush_buffer_pages(1);
				if (*err) return;
			}
			BUFFER[IFP++]=b[i];
		}
	  }
	  else {
		for (i=0;i<nn;i++) {
			if (IFP>=BUFMAX) {
				*err=flush_buffer_pages(1);
				if (*err) return;
			}
			BUFFER[IFP++]=b[3-i];
		}
	}
}

static void gsend_prealproc(int n,int nn,int *err)
{
	union linteg { unsigned char c[4];	signed int l; } b;

	b.l=n;
/*     Require 3 Bytes	*/

	if (b.c[0]==0 || b.c[0]==0xff)  b.l=(b.l>>1)&0xfffffffe;
		else						b.l=(b.l>>8)|0x00000001;
	gsend_1bytechars((char *)(b.c),nn,err);
}
#endif

#ifdef CompaqVisual
void __stdcall GSEND1BYTECHARS(char b[],int length,int *n,int *err)
#else
void gsend1bytechars(char b[],int *n,int *err)
#endif
{
	gsend_1bytechars(b,*n,err);
}

void gsend1bytebytes(int *b,int *n,int *err)
{
	gsend_1bytechars((char *)b,*n,err);
}

void gsendsrealproc(int *n,int *nn,int *err)
{
	gsend_prealproc(*n,*nn,err);
}

/*#define HTC			1.0e6/36.0			*/
#define HTC			1.0e6/30.0
#define LTC			1.e7
#define STC			LTC
void gsendhlsdataproc(double *sh,double *sl,double *ss,int *ndiv,int *mode,int *err)
{
	int md=*mode,md1,n,i,j,nc,is,**ndiv1;
	double **sh1,*sl1,*ss1;
	frames_canvas *gcanvas=get_gcanvasp();

	get_canvas_hlstable(gcanvas->colset,&nc,&sh1,&ndiv1);

	for (j=0;j<nc;j++) {
		md1=ndiv1[j][0];
		if (md1<128) n=3;
			else n=4;
		gsend_1bytechars((char*)&n,1,err);			n-=2;
		gsend_1bytechars((char*)&md1,n,err);

		n=2;
		if (md1<=0) gsend_1bytechars((char*)&ndiv1[j][1],n,err);
		  else {
			sl1=sh1[j]+md1+1;		ss1=sl1+md1+1;
		  	for (i=1;i<=md1;i++) gsend_1bytechars((char*)&ndiv1[j][i],n,err);
			for (i=0;i<=md1;i++) {
			/*	printf("%f %f %f %d\n",sh1[j][i],sl1[i],ss1[i],ndiv1[j][i]);	*/
				gsend_prealproc((int)(HTC*sh1[j][i]+0.5),3,err);
				gsend_prealproc((int)(LTC*sl1[i]+0.5),3,err);
				gsend_prealproc((int)(STC*ss1[i]+0.5),3,err);
			}
		}
	}
	if (md==-999) {
		n=5;
		gsend_1bytechars((char*)&n,1,err);
		gcanvas->colset += nc;
		return;
	}

	if (md<128) n=1;
		else n=2;
	gsend_1bytechars((char*)&n,1,err);
	gsend_1bytechars((char*)mode,n,err);
	n=2;
	if (md<=0) gsend_1bytechars((char*)ndiv,n,err);
	  else {
		for (i=0;i<md;i++) gsend_1bytechars((char*)&ndiv[i],n,err);
		for (i=0;i<=md;i++) {
			gsend_prealproc((int)(HTC*sh[i]+0.5),3,err);
			gsend_prealproc((int)(LTC*sl[i]+0.5),3,err);
			gsend_prealproc((int)(STC*ss[i]+0.5),3,err);
		}
	}
	gcanvas->colset += nc+1;
}
