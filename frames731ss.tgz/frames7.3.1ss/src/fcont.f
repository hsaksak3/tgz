**************************************
*       F  R  A  M  E  S  V.7        *
*    CONTOUR  DRAWING  SUBROUTINE    *
*       PROGRAMMED BY T.TAGUCHI      *
**************************************

*      GIVEN DIMENSION IS F(IMAX,JMAX)

      SUBROUTINE FR_CONTOUR(F,IMAX,JMAX,ND0,ICOL)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 F(0:IMAX-1,0:JMAX-1),FM1,FM2
      REAL   XP(6),YP(6),CNC(4)

      COI(X) = X*TANI + SEPI
      COJ(X) = X*TANJ + SEPJ

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('CONTOUR PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - CONTOUR')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - CONTOUR')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      IF (IFRAM.EQ.0) THEN
*         IFRAM = 999
         IF (IDFFR2.LT.0) THEN
            IDFR = 2
          ELSE
            IDFR = IDFFR2
         ENDIF
         CALL FR_FRAME2D(DBLE(NX1),DBLE(NX2),DBLE(NY1),DBLE(NY2),IDFR)
      ENDIF

      IF (ICNREG.EQ.0) THEN
         CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
       ELSE IF (ICNREG.GT.2) THEN
         ICN = ICNREG-2
         IF (IAND(ICN,1).NE.0) THEN
            CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
            CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
      ENDIF

      IF (ICOL.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP

      FM1 = F(0,0)
      FM2 = FM1
      DO 10 J = 0, JMAX-1
         DO 11 I = 0, IMAX-1
            IF (F(I,J).LT.FM1) FM1 = F(I,J)
            IF (F(I,J).GT.FM2) FM2 = F(I,J)
   11     CONTINUE
   10     CONTINUE

      ND = ND0
      IF (IGPLT.GT.0) THEN
         IF (IFCONT.EQ.0) CALL FR_SETCONTOUR(0.D0,0.D0,-1)
         CALL GSENDBYTE(11,1)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(ND,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSEND8BYTE(DBLE(CNXMIN),DBLE(CNXMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNYMIN),DBLE(CNYMAX),1,0)         
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (ICOL.EQ.0) GO TO 1000

      CALL FGWIOCOLORSET(ICOL,ND,FM1,FM2)
      NSFINE = -MOD(ICOL/10,10)

      IF (FM2.EQ.FM1.AND.IFIND.GT.-2) RETURN
      IF (ND.LE.0.AND.IFIND.GT.-2) RETURN

*      IM1  = NX2 - NX1
*      JM1  = NY2 - NY1
*      TANI = DBLE(CIXMAX - CIXMIN)/IM1
*      TANJ = DBLE(CIYMIN - CIYMAX)/JM1
*      SEPI = CIXMIN - TANI*NX1
*      SEPJ = CIYMAX - TANJ*NY1

      TANI   = XTAN*(CNXMAX - CNXMIN)/(IMAX-1)
      TANJ   = YTAN*(CNYMAX - CNYMIN)/(JMAX-1)
      SEPI   = XTAN*CNXMIN + X0
      SEPJ   = YTAN*CNYMIN + Y0

      IF (IFIND.EQ.-2) THEN
         IDDX = ABS(IXMAX-IXMIN)
         IDDY = ABS(IYMAX-IYMIN)
         NDDX = (IXMAX-IXMIN)/TANI
         NDDY = (IYMAX-IYMIN)/TANJ
*         NDDX = ABS(NX2-NX1)
*         NDDY = ABS(NY2-NY1)
         IF (1.2*NDDX.GT.IDDX.AND.1.2*NDDY.GT.IDDY) IFIND = -3
         IF (NDDX.GT.IDDX.AND.NDDY.GT.IDDY) IFIND = -4
*         write(*,*) nddx,iddx,ifind,TANI,TANJ
*         ifind=-2
*         WRITE(*,*) IFIND,NDDX,IDDX,NDDY,IDDY
*         IDD = MAX(ABS(IXMAX-IXMIN),ABS(IYMAX-IYMIN))
*         NDD = MIN(ABS(NX2-NX1),ABS(NY2-NY1))
*         IF (1.5*NDD.GT.IDD) IFIND = -3
*         WRITE(*,*) IDD,1.5*NDD,NDD,IFIND
*       ELSE IF (IFIND.EQ.-5) THEN
*         IFIND = -2
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (IFIND.LE.-2.AND.IFIND.GT.-5) THEN
         CALL FGWIOBASECOL(F,IMAX,JMAX,COI(REAL(NX1)),COJ(REAL(NY1))
     ,                         ,COI(REAL(NX2)),COJ(REAL(NY2)))
      ENDIF

      IF (IFIND.EQ.-4.OR.(IFIND.EQ.-3.AND.NSFINE.EQ.1)) THEN
         DO I = NX1, NX2-1
            DO J = NY1, NY2-1
*               XP(1) = COI(REAL(I))
*               YP(1) = COJ(REAL(J))
*               XP(2) = XP(1)
*               YP(2) = COJ(REAL(J+1))
*               XP(3) = COI(REAL(I+1))
*               YP(3) = YP(2)
*               XP(4) = XP(3)
*               YP(4) = YP(1)
               XP(1)  = COI(REAL(I))
               YP(1)  = COJ(REAL(J))
               XP(2)  = COI(REAL(I+1))
               YP(2)  = COJ(REAL(J+1))
               F00    = F(I,J)
*               NPG = 4
*               RNF = (F(I,J) - FMIN)/DF
*               NF  = RNF + 0.5
*               CALL FGWIOPOLY(XP,YP,NPG,F00)
               CALL FGWIOCOLORBOX(XP,YP,F00)
            ENDDO
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-3) THEN
         DO I = NX1, NX2-1
            DO J = NY1, NY2-1
               F00 = F(I,J)+F(I,J+1)+F(I+1,J)+F(I+1,J+1)
*               XP(1) = COI(REAL(I))
*               YP(1) = COJ(REAL(J))
*               XP(2) = XP(1)
*               YP(2) = COJ(REAL(J+1))
*               XP(3) = COI(REAL(I+1))
*               YP(3) = YP(2)
*               XP(4) = XP(3)
*               YP(4) = YP(1)
               XP(1)  = COI(REAL(I))
               YP(1)  = COJ(REAL(J))
               XP(2)  = COI(REAL(I+1))
               YP(2)  = COJ(REAL(J+1))
*               NPG = 4
*               RNF = (F00/4 - FMIN)/DF
*               NF  = RNF + 0.5
*               CALL FGWIOPOLY(XP,YP,NPG,F00/4)
               CALL FGWIOCOLORBOX(XP,YP,F00/4)
            ENDDO
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-5) THEN
         DO I = NX1, NX2
            DO J = NY1, NY2
*               RNF = (F(I,J) - FMIN)/DF
*               NF  = RNF + 0.5
               F00    = F(I,J)
               CALL FGWIOPSET(COI(REAL(I)),COJ(REAL(J)),F00)
            ENDDO
         ENDDO
         GO TO 999
      ENDIF

      IF (IFIND.EQ.-2) THEN
         DO I = NX1, NX2-1
            DO J = NY1, NY2-1
               XP(1)  = COI(REAL(I))
               YP(1)  = COJ(REAL(J))
               XP(2)  = COI(REAL(I+1))
               YP(2)  = COJ(REAL(J+1))
               CNC(1) = F(I,J)
               CNC(2) = F(I,J+1)
               CNC(3) = F(I+1,J)
               CNC(4) = F(I+1,J+1)
               CALL FGWIOGRADFILLBOX(XP,YP,CNC)
            ENDDO
         ENDDO
         GO TO 999
      ENDIF

      CALL FGWIOLINESTART

      DO I = NX1, NX2-1
         DO 21 J = NY1, NY2-1
            F0(0) = F(I,J)
            F0(1) = F(I,J+1)
            F0(2) = F(I+1,J)
            F0(3) = F(I+1,J+1)
            F00 = F0(0)+F0(1)+F0(2)+F0(3)
            IF (F00.EQ.4*FMIN) THEN
               XP(1) = COI(REAL(I))
               YP(1) = COJ(REAL(J))
               XP(2) = XP(1)
               YP(2) = COJ(REAL(J+1))
               XP(3) = COI(REAL(I+1))
               YP(3) = YP(2)
               XP(4) = XP(3)
               YP(4) = YP(1)
*               RNF = (F00/4 - FMIN)/DF
*               NF  = RNF + 0.5
*               RNF = 0
*               NF  = 0
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,FMIN)
               GO TO 21
            ENDIF
            DO K = 0, 3
               I0(K) = K
            ENDDO
            DO K = 0, 2
               DO K1 = K+1, 3
                  IF (F0(K).GT.F0(K1)) THEN
                     IT     = I0(K)
                     I0(K)  = I0(K1)
                     I0(K1) = IT
                     FF     = F0(K)
                     F0(K)  = F0(K1)
                     F0(K1) = FF
                  ENDIF
               ENDDO
            ENDDO
            IF (IFIND.EQ.-2.AND.IFBASE.LT.0) THEN
               IF (F0(0).GE.FBASE.AND.F0(3).LE.FBASE1) GO TO 21
            ENDIF
            DO K = 0, 3
               CFX(K) = COI(REAL(I + I0(K)/2))
               CFY(K) = COJ(REAL(J + MOD(I0(K),2)))
            ENDDO
**            IF (F0(0).EQ.F0(1).AND.F0(1).EQ.F0(2)) THEN
**               IF (IFIND.EQ.-2) THEN
**                  XP(1) = CFX(0)
**                  YP(1) = CFY(0)
**                  XP(2) = CFX(1)
**                  YP(2) = CFY(1)
**                  XP(3) = CFX(2)
**                  YP(3) = CFY(2)
**                  RNF = (F0(0)+F0(1)+F0(2) - 3*FMIN)/(3*DF)
**                  NF  = RNF + 0.5
**                  NPG = 3
**                  CALL FGWIOPOLY(XP,YP,NPG,(F0(0)+F0(1)+F0(2))/3)
**               ENDIF
**               IF (I0(0)+I0(2).EQ.3) THEN
***                  CALL TRIANGCONTOUR(0,3,2,3)
**                  CALL TRIANGCONTOUR(0,2,0,3)
**                ELSE IF (I0(0)+I0(3).EQ.3) THEN
***                  CALL TRIANGCONTOUR(1,3,2,3)
**                  CALL TRIANGCONTOUR(1,2,1,3)
**                ELSE
***                  CALL TRIANGCONTOUR(0,3,1,3)
**                  CALL TRIANGCONTOUR(0,1,0,3)
**               ENDIF
**               GO TO 21
**            ENDIF
            IF (I0(0)+I0(2).EQ.3) THEN
               F00 = F0(0)
               F03 = F0(3)
               RNF = (F00 - FMIN)/DF
               NF  = RNF - 1
   61          FD = NF*DF + FMIN
               IF (FD.LT.F00) THEN
                  NF = NF + 1
                  GO TO 61
               ENDIF
               DDX = CFX(3) - CFX(0)
               DDY = CFY(3) - CFY(0)
               IN0 = 0
               IN1 = 1

   70           CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F03) THEN
                  GO TO 79
               ENDIF
               DI = (FD - F00)/(F03 - F00)
   71          IF (FD.GT.F0(IN1)) THEN
                  IN0 = IN0 + 1
                  IN1 = IN1 + 1
                  GO TO 71
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 78
               DJ = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
               XX0 = CFX(0) + DDX*DI
               YY0 = CFY(0) + DDY*DI
               XX1 = CFX(IN0) + (CFX(IN1) - CFX(IN0))*DJ
               YY1 = CFY(IN0) + (CFY(IN1) - CFY(IN0))*DJ
               CALL FGWIOLINE(XX0,YY0,XX1,YY1)
   78          NF = NF + 1
               GO TO 70
   79           CONTINUE
             ELSE IF (I0(0)+I0(3).EQ.3) THEN
               RNF = (F0(0) - FMIN)/DF
               NF  = RNF - 1
   81          FD = NF*DF + FMIN
               IF (FD.LT.F0(0)) THEN
                  NF = NF + 1
                  GO TO 81
               ENDIF
               IN0 = 0
               IN1 = 1
               JN0 = 0
               JN1 = 2
   80           CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F0(3)) THEN
                  GO TO 89
               ENDIF
               IF (FD.GT.F0(IN1)) THEN
                  IN0 = 1
                  IN1 = 3
               ENDIF
               IF (FD.GT.F0(JN1)) THEN
                  JN0 = 2
                  JN1 = 3
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 88
               IF (F0(JN1).EQ.F0(JN0)) GO TO 88
               DI = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
               DJ = (FD - F0(JN0))/(F0(JN1) - F0(JN0))
               XX0 = CFX(IN0) + (CFX(IN1) - CFX(IN0))*DI
               YY0 = CFY(IN0) + (CFY(IN1) - CFY(IN0))*DI
               XX1 = CFX(JN0) + (CFX(JN1) - CFX(JN0))*DJ
               YY1 = CFY(JN0) + (CFY(JN1) - CFY(JN0))*DJ
               CALL FGWIOLINE(XX0,YY0,XX1,YY1)
   88          NF = NF + 1
               GO TO 80
   89            CONTINUE
             ELSE IF (I.GT.NX1.AND.I.LT.NX2-1
     +                 .AND.J.GT.NY1.AND.J.LT.NY2-1) THEN
               B1 = F(I-1,J-1) + F(I+2,J+2) - F(I,J) - F(I+1,J+1)
               B2 = F(I-1,J+2) + F(I+2,J-1) - F(I,J+1) - F(I+1,J)
               IF (B1.GE.0.AND.B2.GE.0) THEN
                  IND = 0
                ELSE IF (B1*B2.GE.0) THEN
                  IND = 1
                ELSE 
                  IND = 2
                  FMID = (8*(F0(0)+F0(1)+F0(2)+F0(3))-B1-B2)/32
                  IF (FMID.GE.F0(2)) THEN
                     IND = 1
                   ELSE IF (FMID.LE.F0(1)) THEN
                     IND = 0
                  ENDIF
               ENDIF
               IF (IND.EQ.0) THEN
                  CALL TRIANGCONTOUR(0,2,0,1)
                  CALL TRIANGCONTOUR(0,3,0,1)
                ELSE IF (IND.EQ.1) THEN
                  CALL TRIANGCONTOUR(0,3,0,2)
                  CALL TRIANGCONTOUR(1,3,1,2)
                ELSE
                  F0(4)  = FMID
                  I0(4)  = 4
                  CFX(4) = COI(REAL(I + 0.5))
                  CFY(4) = COJ(REAL(J + 0.5))
                  DO K = 0, 1
                     DO K1 = 2, 3
                        CALL TRIANGCONTOUR(K,K1,K,4)
                     ENDDO
                  ENDDO
               ENDIF
            ELSE
               F0(4)  = (F0(0)+F0(1)+F0(2)+F0(3))/4
               I0(4)  = 4
               CFX(4) = COI(REAL(I + 0.5))
               CFY(4) = COJ(REAL(J + 0.5))
               DO K = 0, 1
                  DO K1 = 2, 3
                     CALL TRIANGCONTOUR(K,K1,K,4)
                  ENDDO
               ENDDO

            ENDIF
   21    CONTINUE
      ENDDO

  999 CALL GWIOBDFLUSH(1)
      CALL FGWIOLINEEND

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME2D(0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

 1000 RETURN
      END

      SUBROUTINE TRIANGCONTOUR(IN0,IN1,J0,J1)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL   XP(5),YP(5)

      RNF = (F0(IN0) - FMIN)/DF
      NF  = RNF - 1
   11 FD  = NF*DF + FMIN
      IF (IFIND.EQ.-2) THEN
         NPG   = 1
         XP(1) = CFX(IN0)
         YP(1) = CFY(IN0)
      ENDIF
      IF (FD.LT.F0(IN0)) THEN
         NF = NF + 1
         GO TO 11
      ENDIF

      JN0 = J0
      JN1 = J1
      XJ0 = CFX(J0)
      YJ0 = CFY(J0)
      XJ1 = CFX(J1)
      YJ1 = CFY(J1)

   10   CONTINUE
          FD = NF*DF + FMIN
          IF (FD.GT.FMAX.OR.FD.GT.F0(IN1)) THEN
             IF (IFIND.EQ.-2) THEN
                IF (JN0.EQ.J0) THEN
                   NPG     = NPG + 1
                   XP(NPG) = XJ1
                   YP(NPG) = YJ1
                ENDIF
             ENDIF
             GO TO 20
          ENDIF
          IF (FD.GT.F0(JN1)) THEN
            JN0 = JN1
            JN1 = IN1
            XJ0 = XJ1
            YJ0 = YJ1
            XJ1 = CFX(IN1)
            YJ1 = CFY(IN1)
            IF (IFIND.EQ.-2) THEN
               NPG     = NPG + 1
               XP(NPG) = XJ0
               YP(NPG) = YJ0
            ENDIF
          ENDIF
          IF (F0(IN1).EQ.F0(IN0)) GO TO 18
          IF (F0(JN1).EQ.F0(JN0)) GO TO 18
          DI = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
          DJ = (FD - F0(JN0))/(F0(JN1) - F0(JN0))
          XX0 = CFX(IN0) + (CFX(IN1) - CFX(IN0))*DI
          YY0 = CFY(IN0) + (CFY(IN1) - CFY(IN0))*DI
          XX1 = XJ0 + (XJ1 - XJ0)*DJ
          YY1 = YJ0 + (YJ1 - YJ0)*DJ
          IF (IFIND.EQ.-2) THEN
             NPG       = NPG + 2
             XP(NPG-1) = XX1
             YP(NPG-1) = YY1
             XP(NPG)   = XX0
             YP(NPG)   = YY0
             CALL FGWIOPOLYS(XP,YP,NPG)
           ELSE
             CALL FGWIOLINE(XX0,YY0,XX1,YY1)
          ENDIF
   18     NF = NF + 1
          GO TO 10

   20   CONTINUE
      IF (IFIND.EQ.-2) THEN
         NPG   = NPG + 1
         XP(NPG) = CFX(IN1)
         YP(NPG) = CFY(IN1)
         CALL FGWIOPOLYS(XP,YP,NPG)
      ENDIF
      RETURN
      END
