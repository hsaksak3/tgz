**********************************
*      F  R  A  M  E  S  V.7     *
*    THREE DIMENSIONAL PROFILE   *
*     PROGRAMMED BY T.TAGUCHI    *
**********************************

*      GIVEN DIMENSION IS F(IMAX,JMAX)

      SUBROUTINE FR_PROFILE(F,IMAX,JMAX,ICOL,MODE)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /PROFPARM3D/ DXPU,DXPV,DXP0,DYPU,DYPV,DYP0,DZPU,DZPV,DZP0
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 F(0:IMAX-1,0:JMAX-1),FM1,FM2,FM10,FM20
      REAL*8 DX,DY,X1,X2,X3,X4,Y1,Y2,Y3,Y4,Z1,Z2,Z3,Z4
      REAL   TRIX(3),TRIY(3),SQX(4),SQY(4),FH(4),XS(4),YS(4),ZS(4)
      INTEGER DI,DJ

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('PROFILE PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - PROFILE')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - PROFILE')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      ISETMAX = 0
      IF (IFRAM.EQ.0) THEN
         FM1 = F(NX1,NY1)
         FM2 = FM1
         DO J = NY1, NY2
            DO I = NX1, NX2
               IF (FM1.GT.F(I,J)) FM1 = F(I,J)
               IF (FM2.LT.F(I,J)) FM2 = F(I,J)
            ENDDO
         ENDDO
         ISETMAX = 1
         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 2
          ELSE
            IDFR = IDFFR3
         ENDIF
         IF (MODE3D.EQ.0) THEN
           CALL FR_PMFRAME(DBLE(NX1),DBLE(NX2),FM1,FM2
     ,                              ,DBLE(NY1),DBLE(NY2),IDFR)
          ELSE
           CALL FR_FRAME3D(DBLE(NX1),DBLE(NX2)
     ,                              ,DBLE(NY1),DBLE(NY2),FM1,FM2,IDFR)
         ENDIF
      ENDIF

      IF (IPRREG.EQ.0) THEN
         PRXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         PRXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         IF (MODE3D.EQ.0) THEN
            PRYMIN = (ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(ZMAX-ZMIN)+ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
          ELSE
            PRYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
       ELSE IF (IPRREG.GT.2) THEN
         ICN = IPRREG-2
         IF (IAND(ICN,1).NE.0) THEN
            PRXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            PRXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
          IF (MODE3D.EQ.0) THEN
            PRYMIN = (ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(ZMAX-ZMIN)+ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
           ELSE
            PRYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
          ENDIF
         ENDIF
      ENDIF

      IC       = MOD(ICOL,100)
      ICOLMODE = 0
      IF (MODE.GE.5.OR.IC.LT.0) THEN
         IF (MODE3D.EQ.0) THEN
            CALL FRAMESERROR
     +               ('LIGHTING PROFILE IS ONLY SUPPORTED IN 3D MODE')
            RETURN
         ENDIF
         NSMODE   = 0
         IF (IC.LT.0) THEN
            NBCOL  = -ICOL/100
            NSFINE = -MOD(ICOL/10,10)
            IC     = MOD(ICOL,10)
            IF (IC.EQ.-3) THEN
               NSMODE = 2000 + NSFINE
             ELSE IF (IC.EQ.-4) THEN
*               NSMODE = 2001
*             ELSE IF (IC.EQ.-5) THEN
               NSMODE = 3000 + NSFINE
             ELSE IF (IC.EQ.-5) THEN
               NSMODE = 4000
             ELSE
               NSMODE = 1000
            ENDIF
         ENDIF
         IF (ISETMAX.EQ.0) THEN
            FM1 = F(NX1,NY1)
            FM2 = FM1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (FM1.GT.F(I,J)) FM1 = F(I,J)
                  IF (FM2.LT.F(I,J)) FM2 = F(I,J)
               ENDDO
            ENDDO
         ENDIF
         ISU   = 1
         NBCOL = ICOL/100
         IF (NBCOL.EQ.0) NBCOL = -1
         IF (ICOL256.GE.0) THEN
            IF (IC.GE.0) THEN
               CALL ISHLSLIGHTSET(IC,1)
               ICOLMODE = 1
             ELSE IF (ICOL256.EQ.0) THEN
               CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC.GE.0) THEN
*       FOR TPLOT ONLY
            CALL ISHLSLIGHTSET(IC,-1)
         ENDIF
       ELSE
         ISU = 0
         IF (MODE.NE.0) THEN
            IND1 = MODE
            IF (IND1.GT.2) IND1 = IND1-2
         ENDIF
      ENDIF

      FM10 = F(0,0)
      FM20 = FM10
      DO J = 0, JMAX-1
         DO I = 0, IMAX-1
            IF (FM10.GT.F(I,J)) FM10 = F(I,J)
            IF (FM20.LT.F(I,J)) FM20 = F(I,J)
         ENDDO
      ENDDO

      IF (IGPLT.GT.0) THEN
         IF (ISU.NE.0) THEN
            IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
               CALL FR_SETCONTOUR(0.D0,0.D0,-1)
             ELSE
               IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
               IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
            ENDIF
         ENDIF
         CALL GSENDBYTE(51,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSEND8BYTE(DBLE(PRXMIN),DBLE(PRXMAX),1,0)
         CALL GSEND8BYTE(DBLE(PRYMIN),DBLE(PRYMAX),1,0)         
         CALL GSEND8BYTE(F,(FM10+FM20)/2,IMAX*JMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IND   = MODE

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (MODE3D.NE.0) GO TO 10000
      CALL GWIOCOLOR(2,IC)
      CALL FR_HCLEAR(IND1+10000)

      DX    = DBLE(IXMAX-IXMIN)/(NX2-NX1)
      DY0   = DBLE(IZXMAX-IXMAX)/(NY2-NY1)
      DY1   = DBLE(IZYMAX-IYMAX)/(NY2-NY1)
      Y0MIN = IXMIN - DY0*NY1 - DX*NX1
      Y1MIN = ZYTAN*ZMIN + ZY0 - DY1*NY1

      DX    = XTAN*(PRXMAX-PRXMIN)/(IMAX-1)
      DY0   = ZXTAN*(PRYMAX-PRYMIN)/(JMAX-1)
      DY1   = ZYTAN*(PRYMAX-PRYMIN)/(JMAX-1)
      Y0MIN = XTAN*PRXMIN  + ZXTAN*PRYMIN + ZX0
      Y1MIN = ZYTAN*PRYMIN + ZY0

      IF (IZXMAX.GE.IXMAX) THEN
         IM = NX1
         KM = NX2
         DI = 1
       ELSE
         IM = NX2
         KM = NX1
         DI = -1
      ENDIF

      YD0   = DY0*NY1 + Y0MIN
      YD1   = DY1*NY1 + Y1MIN
      PX    = DX*IM   + YD0
      PY    = YTAN*F(IM,NY1) + YD1
      PXMIN = PX
      PXMAX = PX

      DO I = IM+DI, KM, DI
         PX1 = DX*I + YD0
         PY1 = YTAN*F(I,NY1) + YD1
         IF (IND.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO

      YD0 = DX*KM + Y0MIN
      DO J = NY1+1, NY2
         PX1 = DY0*J + YD0
         PY1 = YTAN*F(KM,J) + DY1*J + Y1MIN
         IF (IND.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO
      IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)

      DI = -DI
      DO J = NY1+1, NY2
         YD0   = DY0*J + Y0MIN
         YD1   = DY1*J + Y1MIN
         PX    = DX*KM + YD0
         PY    = YTAN*F(KM,J) + YD1
         PXMIN = PX
         PXMAX = PX
         DO I = KM+DI, IM, DI
            PX1  = DX*I + YD0
            PY1  = YTAN*F(I,J) + YD1
            PX2  = DX*I + YD0 - DY0
            PY2  = YTAN*F(I,J-1) + YD1 - DY1
            IF (IND.EQ.0) THEN
               CALL GWIOLINE(PX,PY,PX1,PY1,0)
               CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
             ELSE IF (IND.GT.2) THEN
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
             ELSE   
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
               CALL HGWIOLINE(PX1,PY1,PX2,PY2)
               IF (PX2.GT.PXMAX) PXMAX = PX2
               IF (PX2.LT.PXMIN) PXMIN = PX2
            ENDIF
            PX   = PX1
            PY   = PY1
         ENDDO
         IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
      ENDDO
      GO TO 999

10000    CONTINUE

      IF (PHI.LE.-90.0) THEN
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.-135.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE IF (PHI.LT.0.0) THEN
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.-45.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
       ELSE IF (PHI.LT.90.0) THEN
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.45.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.135.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
      ENDIF

*      DX   = (XMAX-XMIN)/(NX2-NX1)
*      DY   = (YMAX-YMIN)/(NY2-NY1)
      DX   = (PRXMAX-PRXMIN)/(IMAX-1)
      DY   = (PRYMAX-PRYMIN)/(JMAX-1)
      DXPU = XPX*DX
      DXPV = XPY*DY
*      DXP0 = XPX*XMIN + XPY*YMIN + XP0 - DXPU*NX1 - DXPV*NY1
      DXP0 = XPX*PRXMIN + XPY*PRYMIN + XP0
      DYPU = YPX*DX
      DYPV = YPY*DY
*      DYP0 = YPX*XMIN + YPY*YMIN + YP0 - DYPU*NX1 - DYPV*NY1
      DYP0 = YPX*PRXMIN + YPY*PRYMIN + YP0
      IF (MDPROJ.NE.0) THEN
         DZPU = ZPX*DX
         DZPV = ZPY*DY
*         DZP0 = ZPX*XMIN + ZPY*YMIN + ZP0 - DZPU*NX1 - DZPV*NY1
         DZP0 = ZPX*PRXMIN + ZPY*PRYMIN + ZP0
      ENDIF

*     SIMPLE LINE HIDDEN ALGORISM
      IF (ISU.EQ.0) THEN
         CALL GWIOCOLOR(2,IC)
         CALL FR_HCLEAR(IND1+10000)

         CALL COORDINIJF(I2,J1,F(I2,J1),PX,PY)
         PXMAX = PX
         PXMIN = PX
         DO I = I2-DI, I1, -DI
            CALL COORDINIJF(I,J1,F(I,J1),PX1,PY1)
            IF (IND.EQ.0) THEN
               CALL GWIOLINE(PX,PY,PX1,PY1,0)
             ELSE
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
            ENDIF
            PX  = PX1
            PY  = PY1
         ENDDO

         DO J = J1+DJ, J2, DJ
            CALL COORDINIJF(I1,J,F(I1,J),PX1,PY1)
            IF (IND.EQ.0) THEN
               CALL GWIOLINE(PX,PY,PX1,PY1,0)
             ELSE
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
            ENDIF
            PX  = PX1
            PY  = PY1
         ENDDO

         IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)

         IF (IJ.EQ.1.OR.IND.GT.2) THEN
            DO J = J1+DJ, J2, DJ
               CALL COORDINIJF(I1,J,F(I1,J),PX,PY)
               PXMIN = PX
               PXMAX = PY
               DO I = I1+DI, I2, DI
                  CALL COORDINIJF(I,J,F(I,J),PX1,PY1)
                  CALL COORDINIJF(I,J-DJ,F(I,J-DJ),PX2,PY2)
                  IF (IND.EQ.0) THEN
                     CALL GWIOLINE(PX,PY,PX1,PY1,0)
                     CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
                   ELSE IF (IND.GT.2) THEN
                     CALL HGWIOLINE(PX,PY,PX1,PY1)
                     IF (PX1.GT.PXMAX) PXMAX = PX1
                     IF (PX1.LT.PXMIN) PXMIN = PX1
                   ELSE
                     CALL HGWIOLINE(PX,PY,PX1,PY1)
                     IF (PX1.GT.PXMAX) PXMAX = PX1
                     IF (PX1.LT.PXMIN) PXMIN = PX1
                     CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                     IF (PX2.GT.PXMAX) PXMAX = PX2
                     IF (PX2.LT.PXMIN) PXMIN = PX2
                  ENDIF
                  PX = PX1
                  PY = PY1
               ENDDO
               IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
            ENDDO
          ELSE
            DO I = I1+DI, I2, DI
               CALL COORDINIJF(I,J1,F(I,J1),PX,PY)
               PXMIN = PX
               PXMAX = PY
               DO J = J1+DJ, J2, DJ
                  CALL COORDINIJF(I,J,F(I,J),PX1,PY1)
                  CALL COORDINIJF(I-DI,J,F(I-DI,J),PX2,PY2)
                  IF (IND.EQ.0) THEN
                     CALL GWIOLINE(PX,PY,PX1,PY1,0)
                     CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
                   ELSE IF (IND.GT.2) THEN
                     CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                     IF (PX2.GT.PXMAX) PXMAX = PX2
                     IF (PX2.LT.PXMIN) PXMIN = PX2
                   ELSE
                     CALL HGWIOLINE(PX,PY,PX1,PY1)
                     IF (PX1.GT.PXMAX) PXMAX = PX1
                     IF (PX1.LT.PXMIN) PXMIN = PX1
                     CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                     IF (PX2.GT.PXMAX) PXMAX = PX2
                     IF (PX2.LT.PXMIN) PXMIN = PX2
                  ENDIF
                  PX = PX1
                  PY = PY1
               ENDDO
               IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
            ENDDO
         ENDIF
*     POLYGON PAINTING ALGORISM
       ELSE
         IF (NSMODE.GE.1000) THEN
            ICC = -2
*            IF (IC/10.NE.0) ICC = -12
            CALL FGWIOCOLORSET(ICC,0,FM10,FM20)
         ENDIF
         IF (NSMODE.EQ.1000) THEN
           IF (IJ.EQ.1) THEN
            DO J = J2-DJ, J1, -DJ
               CALL COORDINIJF(I2,J   ,F(I2,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I2,J+DJ,F(I2,J+DJ),SQX(4),SQY(4))
               FH(1) = F(I2,J   )
               FH(4) = F(I2,J+DJ)
               DO I = I2-DI, I1, -DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = F(I,J   )
                  FH(3) = F(I,J+DJ)
                  CALL FGWIOSQUARE(SQX,SQY,FH,NBCOL)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ELSE
            DO I = I2-DI, I1, -DI
               CALL COORDINIJF(I   ,J2,F(I   ,J2),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J2,F(I+DI,J2),SQX(4),SQY(4))
               FH(1) = F(I   ,J2)
               FH(4) = F(I+DI,J2)
               DO J = J2-DJ, J1, -DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = F(I   ,J)
                  FH(3) = F(I+DI,J)
                  CALL FGWIOSQUARE(SQX,SQY,FH,NBCOL)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ENDIF

          ELSE IF (NSMODE.GE.2000.AND.NSMODE.LE.2010) THEN
           IF (IJ.EQ.1) THEN
            DO J = J2-DJ, J1, -DJ
               CALL COORDINIJF(I2,J   ,F(I2,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I2,J+DJ,F(I2,J+DJ),SQX(4),SQY(4))
               FH(1) = F(I2,J   )
               FH(4) = F(I2,J+DJ)
               DO I = I2-DI, I1, -DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = F(I,J   )
                  FH(3) = F(I,J+DJ)
*                  CALL FGWIOSSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  CALL FGWIOAVSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ELSE
            DO I = I2-DI, I1, -DI
               CALL COORDINIJF(I   ,J2,F(I   ,J2),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J2,F(I+DI,J2),SQX(4),SQY(4))
               FH(1) = F(I   ,J2)
               FH(4) = F(I+DI,J2)
               DO J = J2-DJ, J1, -DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = F(I   ,J)
                  FH(3) = F(I+DI,J)
*                  CALL FGWIOSSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  CALL FGWIOAVSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ENDIF

          ELSE IF (NSMODE.GE.3000.AND.NSMODE.LE.3010) THEN
           IF (IJ.EQ.1) THEN
            DO J = J2-DJ, J1, -DJ
               CALL COORDINIJF(I2,J   ,F(I2,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I2,J+DJ,F(I2,J+DJ),SQX(4),SQY(4))
               FH(1) = F(I2,J   )
               FH(4) = F(I2,J+DJ)
               DO I = I2-DI, I1, -DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = F(I,J   )
                  FH(3) = F(I,J+DJ)
*                  CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ELSE
            DO I = I2-DI, I1, -DI
               CALL COORDINIJF(I   ,J2,F(I   ,J2),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J2,F(I+DI,J2),SQX(4),SQY(4))
               FH(1) = F(I   ,J2)
               FH(4) = F(I+DI,J2)
               DO J = J2-DJ, J1, -DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = F(I   ,J)
                  FH(3) = F(I+DI,J)
*                  CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
           ENDIF

          ELSE IF (NSMODE.EQ.4000) THEN
            CALL GETPROFNORMALIZE(FM1,FM2,DDX,DDY,DDZ)
           IF (IJ.EQ.1) THEN
            DO J = J2-DJ, J1, -DJ
               CALL COORDINIJF(I2,J   ,F(I2,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I2,J+DJ,F(I2,J+DJ),SQX(4),SQY(4))
               FH(1) = F(I2,J   )
               FH(4) = F(I2,J+DJ)
               XS(1) = DDX*I2
               XS(4) = DDX*I2
               YS(1) = DDY*J
               YS(4) = DDY*(J+DJ)
               ZS(1) = DDZ*F(I2,J   )
               ZS(4) = DDZ*F(I2,J+DJ)
               DO I = I2-DI, I1, -DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = F(I,J   )
                  FH(3) = F(I,J+DJ)
                  XS(2) = DDX*I
                  XS(3) = DDX*I
                  YS(2) = DDY*J
                  YS(3) = DDY*(J+DJ)
                  ZS(2) = DDZ*F(I,J   )
                  ZS(3) = DDZ*F(I,J+DJ)
                  CALL FGWIOLITSQUARE(SQX,SQY,FH,NBCOL,XS,YS,ZS)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
                  XS(1)  = XS(2)
                  XS(4)  = XS(3)
                  YS(1)  = YS(2)
                  YS(4)  = YS(3)
                  ZS(1)  = ZS(2)
                  ZS(4)  = ZS(3)
               ENDDO
            ENDDO
           ELSE
            DO I = I2-DI, I1, -DI
               CALL COORDINIJF(I   ,J2,F(I   ,J2),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J2,F(I+DI,J2),SQX(2),SQY(2))
               FH(1) = F(I   ,J2)
               FH(2) = F(I+DI,J2)
               XS(1) = DDX*I
               XS(2) = DDX*(I+DI)
               YS(1) = DDY*J2
               YS(2) = DDY*J2
               ZS(1) = DDZ*F(I   ,J2)
               ZS(2) = DDZ*F(I+DI,J2)
               DO J = J2-DJ, J1, -DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(4),SQY(4))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(4) = F(I   ,J)
                  FH(3) = F(I+DI,J)
                  XS(4) = DDX*I
                  XS(3) = DDX*(I+DI)
                  YS(4) = DDY*J
                  YS(3) = DDY*J
                  ZS(4) = DDZ*F(I   ,J)
                  ZS(3) = DDZ*F(I+DI,J)
                  CALL FGWIOLITSQUARE(SQX,SQY,FH,NBCOL,XS,YS,ZS)
                  SQX(1) = SQX(4)
                  SQY(1) = SQY(4)
                  FH(1)  = FH(4)
                  SQX(2) = SQX(3)
                  SQY(2) = SQY(3)
                  FH(2)  = FH(3)
                  XS(1)  = XS(4)
                  XS(2)  = XS(3)
                  YS(1)  = YS(4)
                  YS(2)  = YS(3)
                  ZS(1)  = ZS(4)
                  ZS(2)  = ZS(3)
               ENDDO
            ENDDO
           ENDIF

          ELSE

            CALL SETPROFILELIGHTING(RATE)

          IF (IJ.EQ.1) THEN
            DO J = J2-DJ, J1, -DJ
               Y1 = DY*J+PRYMIN
               Y3 = Y1+DY*DJ
               DO I = I2-DI, I1, -DI
                  X1 = DX*I+PRXMIN
                  Z1 = F(I,J)*RATE
                  X2 = X1+DX*DI
                  Y2 = Y1
                  Z2 = F(I+DI,J)*RATE
                  X3 = X1
                  Z3 = F(I,J+DJ)*RATE
                  X4 = X2
                  Y4 = Y3
                  Z4 = F(I+DI,J+DJ)*RATE
                 CALL DNORMSQUARES(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,CS,RS,CSS)
                 CALL COORDINIJF(I   ,J   ,F(I   ,J   ),TRIX(1),TRIY(1))
                 CALL COORDINIJF(I+DI,J,   F(I+DI,J   ),TRIX(2),TRIY(2))
                 CALL COORDINIJF(I   ,J+DJ,F(I   ,J+DJ),TRIX(3),TRIY(3))
                 CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
                 CALL DNORMSQUARES(X2,X4,X3,Y2,Y4,Y3,Z2,Z4,Z3,CS,RS,CSS)
                  SQX(1) = TRIX(1)
                  SQX(2) = TRIX(2)
                  SQX(4) = TRIX(3)
                  SQY(1) = TRIY(1)
                  SQY(2) = TRIY(2)
                  SQY(4) = TRIY(3)
                  TRIX(1) = TRIX(2)
                  TRIY(1) = TRIY(2)
                 CALL COORDINIJF(I+DI,J+DJ,F(I+DI,J+DJ),TRIX(2),TRIY(2))
                  CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
                  IF (NBCOL.GE.0) THEN
                     SQX(3) = TRIX(2)
                     SQY(3) = TRIY(2)
                     CALL SGWIOPOLYGON(SQX,SQY,4,2,NBCOL)
                  ENDIF
               ENDDO
            ENDDO
          ELSE
*            i2 = 15
*            i1 = 11
*            j2 = 5
*            j1 = 10
            DO I = I2-DI, I1, -DI
               X1 = DX*I+PRXMIN
               X2 = X1+DX*DI
               DO J = J2-DJ, J1, -DJ
                  Y1 = DY*J+PRYMIN
                  Z1 = F(I,J)*RATE
                  Y2 = Y1
                  Z2 = F(I+DI,J)*RATE
                  X3 = X1
                  Y3 = Y1+DY*DJ
                  Z3 = F(I,J+DJ)*RATE
                  X4 = X2
                  Y4 = Y3
                  Z4 = F(I+DI,J+DJ)*RATE
                 CALL DNORMSQUARES(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,CS,RS,CSS)
                 CALL COORDINIJF(I   ,J   ,F(I   ,J   ),TRIX(1),TRIY(1))
                 CALL COORDINIJF(I+DI,J,   F(I+DI,J   ),TRIX(2),TRIY(2))
                 CALL COORDINIJF(I   ,J+DJ,F(I   ,J+DJ),TRIX(3),TRIY(3))
                 CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
                 CALL DNORMSQUARES(X2,X4,X3,Y2,Y4,Y3,Z2,Z4,Z3,CS,RS,CSS)
                  SQX(1) = TRIX(1)
                  SQX(2) = TRIX(2)
                  SQX(4) = TRIX(3)
                  SQY(1) = TRIY(1)
                  SQY(2) = TRIY(2)
                  SQY(4) = TRIY(3)
                  TRIX(1) = TRIX(2)
                  TRIY(1) = TRIY(2)
                 CALL COORDINIJF(I+DI,J+DJ,F(I+DI,J+DJ),TRIX(2),TRIY(2))
                  CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
                  IF (NBCOL.GE.0) THEN
                     SQX(3) = TRIX(2)
                     SQY(3) = TRIY(2)
                     CALL SGWIOPOLYGON(SQX,SQY,4,2,NBCOL)
                  ENDIF
               ENDDO
            ENDDO
          ENDIF
         ENDIF
      ENDIF

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

999   CALL GWIOBDFLUSH(1)
*      IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)

      RETURN
      END

      SUBROUTINE FR_MAPPROFILE(F,S,IMAX,JMAX,ICOL,MODE)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /PROFPARM3D/ DXPU,DXPV,DXP0,DYPU,DYPV,DYP0,DZPU,DZPV,DZP0
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL*8 F(0:IMAX-1,0:JMAX-1),S(0:IMAX-1,0:JMAX-1),FM1,FM2,FS1,FS2
      REAL*8 DX,DY,FM10,FM20
      REAL    SQX(4),SQY(4),FH(4),XS(4),YS(4),ZS(4)
      INTEGER DI,DJ

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('PROFILE PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF
      
      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - PROFILE')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - PROFILE')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      FM1 = F(NX1,NY1)
      FM2 = FM1
      DO J = NY1, NY2
         DO I = NX1, NX2
            IF (FM1.GT.F(I,J)) FM1 = F(I,J)
            IF (FM2.LT.F(I,J)) FM2 = F(I,J)
         ENDDO
      ENDDO

*      FS1 = S(NX1,NY1)
*      FS2 = FS1
*      DO J = NY1, NY2
*         DO I = NX1, NX2
*            IF (FS1.GT.S(I,J)) FS1 = S(I,J)
*            IF (FS2.LT.S(I,J)) FS2 = S(I,J)
*         ENDDO
*      ENDDO
      FS1 = S(0,0)
      FS2 = FS1
      DO J = 0, JMAX-1
         DO I = 0, IMAX-1
            IF (FS1.GT.S(I,J)) FS1 = S(I,J)
            IF (FS2.LT.S(I,J)) FS2 = S(I,J)
         ENDDO
      ENDDO

      IF (IFRAM.EQ.0) THEN
         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 2
          ELSE
            IDFR = IDFFR3
         ENDIF
         IF (MODE3D.EQ.0) THEN
           CALL FR_PMFRAME(DBLE(NX1),DBLE(NX2),FM1,FM2
     ,                              ,DBLE(NY1),DBLE(NY2),IDFR)
          ELSE
           CALL FR_FRAME3D(DBLE(NX1),DBLE(NX2)
     ,                              ,DBLE(NY1),DBLE(NY2),FM1,FM2,IDFR)
         ENDIF
      ENDIF

      IND   = MODE

*      IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP

*      NBCOL    = -1
      NSMODE   = IND/10
      IC       = MOD(ICOL,10)
      NBCOL    = -ICOL/100
      IF (IC.LT.0) THEN
         NSFINE = -MOD(ICOL/10,10)
         IC     = MOD(ICOL,10)
         IF (IC.EQ.-3) THEN
            NSMODE = 2000 + NSFINE
          ELSE IF (IC.EQ.-4) THEN
*            NSMODE = 2001
*          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 3000 + NSFINE
          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 4000
          ELSE
            NSMODE = 1000
         ENDIF
       ELSE
            NSMODE = 1000
            NBCOL  = -NBCOL
      ENDIF
      IF (NBCOL.EQ.0) NBCOL = -1

      IF (NSMODE.LT.0) THEN
         CALL GWIOCOLOR(2,IC)
       ELSE IF (ICOL256.GE.0) THEN
         IF (IC.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 1
*          ELSE IF (IND.NE.0) THEN
*        NO MEANING IN 3D MODE
          ELSE
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (IC.GE.0) THEN
*        FOR TPLOT ONLY
         CALL ISHLSLIGHTSET(IC,-1)
      ENDIF

      IF (IPRREG.EQ.0) THEN
         PRXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         PRXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         IF (MODE3D.EQ.0) THEN
            PRYMIN = (ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(ZMAX-ZMIN)+ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
          ELSE
            PRYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
       ELSE IF (IPRREG.GT.2) THEN
         ICN = IPRREG-2
         IF (IAND(ICN,1).NE.0) THEN
            PRXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            PRXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
          IF (MODE3D.EQ.0) THEN
            PRYMIN = (ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(ZMAX-ZMIN)+ZMIN*NY2-ZMAX*NY1)/(NY2-NY1)
           ELSE
            PRYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            PRYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
          ENDIF
         ENDIF
      ENDIF

      FM10 = F(0,0)
      FM20 = FM10
      DO J = 0, JMAX-1
         DO I = 0, IMAX-1
            IF (FM10.GT.F(I,J)) FM10 = F(I,J)
            IF (FM20.LT.F(I,J)) FM20 = F(I,J)
         ENDDO
      ENDDO

      IF (IGPLT.GT.0) THEN
         IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
            CALL FR_SETCONTOUR(0.D0,0.D0,-1)
          ELSE
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(51,1)
         CALL GSENDBYTE(10000+MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSEND8BYTE(DBLE(PRXMIN),DBLE(PRXMAX),1,0)
         CALL GSEND8BYTE(DBLE(PRYMIN),DBLE(PRYMAX),1,0)         
         CALL GSEND8BYTE(F,(FM10+FM20)/2,IMAX*JMAX,4)
         CALL GSEND8BYTE(S,(FS1+FS2)/2,IMAX*JMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (IND.NE.0) THEN
         IND1 = IND
         IF (IND1.GT.2) IND1 = IND1-2
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(2,ICOL)

      IF (MODE3D.NE.0) GO TO 10000
      IF (IND.NE.0) CALL FR_HCLEAR(IND1+10000)

      DX    = DBLE(IXMAX-IXMIN)/(NX2-NX1)
      DY0   = DBLE(IZXMAX-IXMAX)/(NY2-NY1)
      DY1   = DBLE(IZYMAX-IYMAX)/(NY2-NY1)
      Y0MIN = IXMIN - DY0*NY1 - DX*NX1
      Y1MIN = ZYTAN*ZMIN + ZY0 - DY1*NY1

      DX    = XTAN*(PRXMAX-PRXMIN)/(IMAX-1)
      DY0   = ZXTAN*(PRYMAX-PRYMIN)/(JMAX-1)
      DY1   = ZYTAN*(PRYMAX-PRYMIN)/(JMAX-1)
      Y0MIN = XTAN*PRXMIN  + ZXTAN*PRYMIN + ZX0
      Y1MIN = ZYTAN*PRYMIN + ZY0

      IF (IZXMAX.GE.IXMAX) THEN
         IM = NX1
         KM = NX2
         DI = 1
       ELSE
         IM = NX2
         KM = NX1
         DI = -1
      ENDIF

      YD0   = DY0*NY1 + Y0MIN
      YD1   = DY1*NY1 + Y1MIN
      PX    = DX*IM   + YD0
      PY    = YTAN*F(IM,NY1) + YD1
      PXMIN = PX
      PXMAX = PX

      DO I = IM+DI, KM, DI
         PX1 = DX*I + YD0
         PY1 = YTAN*F(I,NY1) + YD1
         IF (IND.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO

      YD0 = DX*KM + Y0MIN
      DO J = NY1+1, NY2
         PX1 = DY0*J + YD0
         PY1 = YTAN*F(KM,J) + DY1*J + Y1MIN
         IF (IND.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO
      IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)

      DI = -DI
      DO J = NY1+1, NY2
         YD0   = DY0*J + Y0MIN
         YD1   = DY1*J + Y1MIN
         PX    = DX*KM + YD0
         PY    = YTAN*F(KM,J) + YD1
         PXMIN = PX
         PXMAX = PX
         DO I = KM+DI, IM, DI
            PX1  = DX*I + YD0
            PY1  = YTAN*F(I,J) + YD1
            PX2  = DX*I + YD0 - DY0
            PY2  = YTAN*F(I,J-1) + YD1 - DY1
            IF (IND.EQ.0) THEN
               CALL GWIOLINE(PX,PY,PX1,PY1,0)
               CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
             ELSE IF (IND.GT.2) THEN
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
             ELSE   
               CALL HGWIOLINE(PX,PY,PX1,PY1)
               IF (PX1.GT.PXMAX) PXMAX = PX1
               IF (PX1.LT.PXMIN) PXMIN = PX1
               CALL HGWIOLINE(PX1,PY1,PX2,PY2)
               IF (PX2.GT.PXMAX) PXMAX = PX2
               IF (PX2.LT.PXMIN) PXMIN = PX2
            ENDIF
            PX   = PX1
            PY   = PY1
         ENDDO
         IF (IND.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
      ENDDO
      GO TO 999

10000    CONTINUE

      IF (PHI.LE.-90.0) THEN
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.-135.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE IF (PHI.LT.0.0) THEN
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.-45.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
       ELSE IF (PHI.LT.90.0) THEN
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.45.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.135.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
      ENDIF

*      DX   = (XMAX-XMIN)/(NX2-NX1)
*      DY   = (YMAX-YMIN)/(NY2-NY1)
      DX   = (PRXMAX-PRXMIN)/(IMAX-1)
      DY   = (PRYMAX-PRYMIN)/(JMAX-1)
      DXPU = XPX*DX
      DXPV = XPY*DY
*      DXP0 = XPX*XMIN + XPY*YMIN + XP0 - DXPU*NX1 - DXPV*NY1
      DXP0 = XPX*PRXMIN + XPY*PRYMIN + XP0
      DYPU = YPX*DX
      DYPV = YPY*DY
*      DYP0 = YPX*XMIN + YPY*YMIN + YP0 - DYPU*NX1 - DYPV*NY1
      DYP0 = YPX*PRXMIN + YPY*PRYMIN + YP0
      IF (MDPROJ.NE.0) THEN
         DZPU = ZPX*DX
         DZPV = ZPY*DY
*         DZP0 = ZPX*XMIN + ZPY*YMIN + ZP0 - DZPU*NX1 - DZPV*NY1
         DZP0 = ZPX*PRXMIN + ZPY*PRYMIN + ZP0
      ENDIF

      ICC = -2
*      IF (MOD(ICOL/10,10).NE.0) ICC = -12
      CALL FGWIOCOLORSET(ICC,0,FS1,FS2)

      IF (NSMODE.EQ.1000) THEN
         IF (IJ.EQ.1) THEN
            DO J = J1, J2-DJ, DJ
               CALL COORDINIJF(I1,J   ,F(I1,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I1,J+DJ,F(I1,J+DJ),SQX(4),SQY(4))
               FH(1) = S(I1,J   )
               FH(4) = S(I1,J+DJ)
               DO I = I1+DI, I2, DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = S(I,J   )
                  FH(3) = S(I,J+DJ)
                  CALL FGWIOSQUARE(SQX,SQY,FH,NBCOL)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
          ELSE
            DO I = I1, I2-DI, DI
               CALL COORDINIJF(I   ,J1,F(I   ,J1),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J1,F(I+DI,J1),SQX(4),SQY(4))
               FH(1) = S(I   ,J1)
               FH(4) = S(I+DI,J1)
               DO J = J1+DJ, J2, DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = S(I   ,J)
                  FH(3) = S(I+DI,J)
                  CALL FGWIOSQUARE(SQX,SQY,FH,NBCOL)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
         ENDIF

       ELSE IF (NSMODE.GE.2000.AND.NSMODE.LE.2010) THEN
         IF (IJ.EQ.1) THEN
            DO J = J1, J2-DJ, DJ
               CALL COORDINIJF(I1,J   ,F(I1,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I1,J+DJ,F(I1,J+DJ),SQX(4),SQY(4))
               FH(1) = S(I1,J   )
               FH(4) = S(I1,J+DJ)
               DO I = I1+DI, I2, DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = S(I,J   )
                  FH(3) = S(I,J+DJ)
*                  CALL FGWIOSSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  CALL FGWIOAVSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
          ELSE
            DO I = I1, I2-DI, DI
               CALL COORDINIJF(I   ,J1,F(I   ,J1),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J1,F(I+DI,J1),SQX(4),SQY(4))
               FH(1) = S(I   ,J1)
               FH(4) = S(I+DI,J1)
               DO J = J1+DJ, J2, DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = S(I   ,J)
                  FH(3) = S(I+DI,J)
*                  CALL FGWIOSSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  CALL FGWIOAVSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
         ENDIF

       ELSE IF (NSMODE.EQ.4000) THEN
         CALL GETPROFNORMALIZE(FM1,FM2,DDX,DDY,DDZ)
         IF (IJ.EQ.1) THEN
            DO J = J1, J2-DJ, DJ
               CALL COORDINIJF(I1,J   ,F(I1,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I1,J+DJ,F(I1,J+DJ),SQX(4),SQY(4))
               FH(1) = S(I1,J   )
               FH(4) = S(I1,J+DJ)
               XS(1) = DDX*I1
               XS(4) = DDX*I1
               YS(1) = DDY*J
               YS(4) = DDY*(J+DJ)
               ZS(1) = DDZ*F(I1,J)
               ZS(4) = DDZ*F(I1,J+DJ)
               DO I = I1+DI, I2, DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = S(I,J   )
                  FH(3) = S(I,J+DJ)
                  XS(2) = DDX*I
                  XS(3) = DDX*I
                  YS(2) = DDY*J
                  YS(3) = DDY*(J+DJ)
                  ZS(2) = DDZ*F(I,J)
                  ZS(3) = DDZ*F(I,J+DJ)
                  CALL FGWIOLITSQUARE(SQX,SQY,FH,NBCOL,XS,YS,ZS)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
                  XS(1)  = XS(2)
                  XS(4)  = XS(3)
                  YS(1)  = YS(2)
                  YS(4)  = YS(3)
                  ZS(1)  = ZS(2)
                  ZS(4)  = ZS(3)
               ENDDO
            ENDDO
          ELSE
            DO I = I1, I2-DI, DI
               CALL COORDINIJF(I   ,J1,F(I   ,J1),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J1,F(I+DI,J1),SQX(4),SQY(4))
               FH(1) = S(I   ,J1)
               FH(4) = S(I+DI,J1)
               XS(1) = DDX*I
               XS(4) = DDX*(I+DI)
               YS(1) = DDY*J1
               YS(4) = DDY*J1
               ZS(1) = DDZ*F(I,J1)
               ZS(4) = DDZ*F(I+DI,J1)
               DO J = J1+DJ, J2, DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = S(I   ,J)
                  FH(3) = S(I+DI,J)
                  XS(2) = DDX*I
                  XS(3) = DDX*(I+DI)
                  YS(2) = DDY*J
                  YS(3) = DDY*J
                  ZS(2) = DDZ*F(I,J)
                  ZS(3) = DDZ*F(I+DI,J)
                  CALL FGWIOLITSQUARE(SQX,SQY,FH,NBCOL,XS,YS,ZS)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
                  XS(1)  = XS(2)
                  XS(4)  = XS(3)
                  YS(1)  = YS(2)
                  YS(4)  = YS(3)
                  ZS(1)  = ZS(2)
                  ZS(4)  = ZS(3)
               ENDDO
            ENDDO
         ENDIF

*       ELSE IF (NSMODE.GE.3000.AND.NSMODE.LE.3010) THEN
       ELSE
         IF (IJ.EQ.1) THEN
            DO J = J1, J2-DJ, DJ
               CALL COORDINIJF(I1,J   ,F(I1,J   ),SQX(1),SQY(1))
               CALL COORDINIJF(I1,J+DJ,F(I1,J+DJ),SQX(4),SQY(4))
               FH(1) = S(I1,J   )
               FH(4) = S(I1,J+DJ)
               DO I = I1+DI, I2, DI
                  CALL COORDINIJF(I,J   ,F(I,J   ),SQX(2),SQY(2))
                  CALL COORDINIJF(I,J+DJ,F(I,J+DJ),SQX(3),SQY(3))
                  FH(2) = S(I,J   )
                  FH(3) = S(I,J+DJ)
*                  CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
          ELSE
            DO I = I1, I2-DI, DI
               CALL COORDINIJF(I   ,J1,F(I   ,J1),SQX(1),SQY(1))
               CALL COORDINIJF(I+DI,J1,F(I+DI,J1),SQX(4),SQY(4))
               FH(1) = S(I   ,J1)
               FH(4) = S(I+DI,J1)
               DO J = J1+DJ, J2, DJ
                  CALL COORDINIJF(I   ,J,F(I   ,J),SQX(2),SQY(2))
                  CALL COORDINIJF(I+DI,J,F(I+DI,J),SQX(3),SQY(3))
                  FH(2) = S(I   ,J)
                  FH(3) = S(I+DI,J)
*                  CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
                  SQX(1) = SQX(2)
                  SQY(1) = SQY(2)
                  FH(1)  = FH(2)
                  SQX(4) = SQX(3)
                  SQY(4) = SQY(3)
                  FH(4)  = FH(3)
               ENDDO
            ENDDO
         ENDIF
      ENDIF

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

999   CALL GWIOBDFLUSH(1)
*      IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)

      RETURN
      END

      SUBROUTINE COORDINIJF(I,J,F,XP,YP)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFPARM3D/ DXPU,DXPV,DXP0,DYPU,DYPV,DYP0,DZPU,DZPV,DZP0
      REAL*8 F

      XP1 = DXPU*I + DXPV*J + XPZ*F + DXP0
      YP1 = DYPU*I + DYPV*J + YPZ*F + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*I + DZPV*J +ZPZ*F + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END

      SUBROUTINE SETPROFILELIGHTING(RATE)
      REAL*8 PI,TH,PH
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH

      XX1 = XPY*YPZ-YPY*XPZ
      YY1 = XPZ*YPX-YPZ*XPX
      ZZ1 = XPX*YPY-YPX*XPY
      IF (MDPROJ.EQ.0) THEN
         EEX = -XX1
         EEY = -YY1
         EEZ = -ZZ1
         RR  = SQRT(EEX**2+EEY**2+EEZ**2)
         EEX = EEX/RR
         EEY = EEY/RR
         EEZ = EEZ/RR
       ELSE
         XD0 = (XMAX+XMIN)/2
         YD0 = (YMAX+YMIN)/2
         ZD0 = (ZMAX+ZMIN)/2
         DET = ZPX*XX1+ZPY*YY1+ZPZ*ZZ1
         IF (ZMAX.LT.ZMIN) DET = -DET
         EEX = XD0 + XX1/DET
         EEY = YD0 + YY1/DET
         EEZ = ZD0 + ZZ1/DET
      ENDIF

      IF (IPROJ.EQ.2) THEN
         RATE = ABS((XMAX - XMIN)/(ZMAX - ZMIN))
       ELSE IF (IPROJ.EQ.3) THEN
         RATE = ABS((YMAX - YMIN)/(ZMAX - ZMIN))
       ELSE
         RATE = 1
      ENDIF
      EEZ=EEZ*RATE

      TH  = PI*LTH/180.D0
      PH  = PI*LPH/180.D0
      IF (MOD3DIR.EQ.1) THEN
         CLGY    =  COS(TH)*COS(PH)
         CLGZ    =  COS(TH)*SIN(PH)
         CLGX    =  SIN(TH)
       ELSE IF (MOD3DIR.EQ.2) THEN
         CLGZ    =  COS(TH)*COS(PH)
         CLGX    =  COS(TH)*SIN(PH)
         CLGY    =  SIN(TH)
       ELSE
         CLGX    =  COS(TH)*COS(PH)
         CLGY    =  COS(TH)*SIN(PH)
         CLGZ    =  SIN(TH)
         IF (ZMAX.LT.ZMIN) THEN
            CLGX = -CLGX
            CLGY = -CLGY
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE GETPROFNORMALIZE(FM1,FM2,DDX,DDY,DDZ)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      REAL*8 FM1,FM2

      DDX = 1/(PRXMAX-PRXMIN)
      DDY = RATIOXY/(PRYMAX-PRYMIN)
      DDZ = RATIOXZ/(FM2-FM1)

      RETURN
      END
