*****************************************
*         F  R  A  M  E  S  V.7         *
*       VOLUME RENDERING SUBROUTINE     *
*        PROGRAMMED BY T.TAGUCHI        *
*****************************************
      SUBROUTINE FR_VOLRENDER(F,IMAX,JMAX,KMAX,ICOL,MODE)
      REAL*8 F(IMAX,JMAX,KMAX)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      COMMON /VRENDERPARM3D/ DXPU,DXPV,DXPW,DXP0,DYPU,DYPV,DYPW,DYP0,
     ,               DZPU,DZPV,DZPW,DZP0,NX1,NX2,NY1,NY2,NZ1,NZ2
      COMMON /VOLUMERENDCOM/ FVRMIN,FVRMAX,ALPHA,BETA,BRMAX,INDBR
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 FM1,FM2

      IF (IGCANVAS.LT.0) RETURN

*     CAUTION !!!  SCALING IS DIFFERNT FROM CONTOUR ROUTINE

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX
         IF (NX1.GT.IMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - VOLRENDER')
            RETURN
         ENDIF
         IF (NX2.GT.IMAX) NX2 = IMAX
       ELSE
         NX1 = 0
         NX2 = IMAX
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX
         IF (NY1.GT.JMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - VOLRENDER')
            RETURN
         ENDIF
         IF (NY2.GT.JMAX) NY2 = JMAX
       ELSE
         NY1 = 0
         NY2 = JMAX
      ENDIF

      IF (NZDMIN.GT.0) THEN
         NZ1 = NZDMIN - 1
         NZ2 = NZDMAX
         IF (NZ1.GT.KMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF K REGION - VOLRENDER')
            RETURN
         ENDIF
         IF (NZ2.GT.KMAX) NZ2 = KMAX
       ELSE
         NZ1 = 0
         NZ2 = KMAX
      ENDIF

      IF (NX2.LE.NX1.OR.NY2.LE.NY1.OR.NZ2.LE.NZ1) THEN
         CALL FRAMESERROR('VOLRENDER PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (ICNREG.EQ.0) THEN
         CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNXMAX = (IMAX*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         CNYMAX = (JMAX*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
         CNZMAX = (KMAX*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
       ELSE IF (ICNREG.GT.2) THEN
         ICN = ICNREG-2
         IF (IAND(ICN,1).NE.0) THEN
            CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            CNXMAX = (IMAX*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
            CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            CNYMAX = (JMAX*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
         IF (IAND(ICN,4).NE.0) THEN
            CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
            CNZMAX = (KMAX*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
         ENDIF
      ENDIF

      ICOLMODE = 0
      MODE1    = MODE
      IF (ICOL256.GE.0) THEN
         IF (ICOL.GE.0) THEN
            CALL ISHLSLIGHTSET(ICOL,1)
            ICOLMODE = 3
          ELSE IF (ICOL256.EQ.0) THEN
            CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (ICOL.GE.0) THEN
*        FOR TPLOT ONLY
         CALL ISHLSLIGHTSET(ICOL,-1)
         IF (INDBR.NE.0) MODE1 = 1
      ENDIF

      IF (FVRMIN.GE.FVRMAX) THEN
         FM1 = F(1,1,1)
         FM2 = FM1
         DO 10 K = 1, KMAX
            DO 11 J = 1, JMAX
               DO 12 I = 1, IMAX
                  IF (F(I,J,K).LT.FM1) FM1 = F(I,J,K)
                  IF (F(I,J,K).GT.FM2) FM2 = F(I,J,K)
   12     CONTINUE
   11     CONTINUE
   10     CONTINUE
       ELSE
         FM1 = FVRMIN
         FM2 = FVRMAX
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL FR_SETVOLUME(FM1,FM2,-9999.D0,-9999.D0)
         CALL GSENDBYTE(74,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSENDBYTE(KMAX,4)
         CALL GSEND8BYTE(DBLE(CNXMIN),DBLE(CNXMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNYMIN),DBLE(CNYMAX),1,0)         
         CALL GSEND8BYTE(DBLE(CNZMIN),DBLE(CNZMAX),1,0)         
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX*KMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (ICOL.EQ.0) RETURN

      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR VOLRENDER')
         RETURN
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN

      DU   = (CNXMAX-CNXMIN)/IMAX
      DV   = (CNYMAX-CNYMIN)/JMAX
      DW   = (CNZMAX-CNZMIN)/KMAX

      DXPU = XPX*DU
      DXPV = XPY*DV
      DXPW = XPZ*DW
      DXP0 = XPX*CNXMIN + XPY*CNYMIN + XPZ*CNZMIN + XP0
      DYPU = YPX*DU
      DYPV = YPY*DV
      DYPW = YPZ*DW
      DYP0 = YPX*CNXMIN + YPY*CNYMIN + YPZ*CNZMIN + YP0
      IF (MDPROJ.NE.0) THEN
         DZPU = ZPX*DU
         DZPV = ZPY*DV
         DZPW = ZPZ*DW
         DZP0 = ZPX*CNXMIN + ZPY*CNYMIN + ZPZ*CNZMIN + ZP0
      ENDIF

      CALL GETVRBOXMINMAX(XPMIN,XPMAX,YPMIN,YPMAX)
      LMIN = XPMIN
      LMAX = XPMAX
      MMIN = YPMIN
      MMAX = YPMAX

      BRADJ = 0.85
      DD    = IMAX**2 + JMAX**2 + KMAX**2
      IF (MODE1.EQ.0) THEN
         BRMAX = 0
         DO M = MMIN, MMAX, 10
            DO L = LMIN, LMAX, 10
               XP = L
               YP = M
               CALL GETRAYEQUATIONS(XP,YP,XR0,YR0,ZR0,TRX,TRY,TRZ,IND)
               IF (IND.EQ.1) THEN
                  S1 = (-10-XR0)/TRX
                  S2 = (IMAX+10-XR0)/TRX
                ELSE IF (IND.EQ.2) THEN
                  S1 = (-10-YR0)/TRY
                  S2 = (JMAX+10-YR0)/TRY
                ELSE
                  S1 = (-10-ZR0)/TRZ
                  S2 = (KMAX+10-ZR0)/TRZ
               ENDIF
               IF (S2.LT.S1) THEN
                  SS = S1
                  S1 = S2
                  S2 = SS
               ENDIF
               X1 = XR0 + TRX*S1
               X2 = XR0 + TRX*S2
               Y1 = YR0 + TRY*S1
               Y2 = YR0 + TRY*S2
               Z1 = ZR0 + TRZ*S1
               Z2 = ZR0 + TRZ*S2
               CALL VRBOXCLIPPING(X1,Y1,Z1,X2,Y2,Z2,IC1,IC2)
               IF (IC1.GT.0) THEN
                  CALL VRRAYABSOUPTION(F,IMAX,JMAX,KMAX,
     ,                      X1,Y1,Z1,X2,Y2,Z2,TRX,TRY,TRZ,FM1,FM2,BR)
                  IF (BR.GT.BRMAX) BRMAX = BR
               ENDIF
            ENDDO
         ENDDO
         IF (BRMAX.EQ.0) THEN
            BETAD = 2*BETA/SQRT(DD)
          ELSE
            BETAD = BETA/BRMAX*BRADJ
            INDBR = 1
         ENDIF
       ELSE IF (MODE1.EQ.2) THEN
         IF (BRMAX.EQ.0) THEN
            BETAD = 2*BETA/SQRT(DD)
          ELSE
            BETAD = BETA/BRMAX*BRADJ
            INDBR = 1
         ENDIF
       ELSE IF (INDBR.GT.0) THEN
         BETAD = BETA/BRMAX*BRADJ
       ELSE
         BETAD = 2*BETA/SQRT(DD)
      ENDIF

*      BRMAX = 0
      DO M = MMIN, MMAX
         DO L = LMIN, LMAX
            XP = L
            YP = M
            CALL GETRAYEQUATIONS(XP,YP,XR0,YR0,ZR0,TRX,TRY,TRZ,IND)
            IF (IND.EQ.1) THEN
               S1 = (-10-XR0)/TRX
               S2 = (IMAX+10-XR0)/TRX
             ELSE IF (IND.EQ.2) THEN
               S1 = (-10-YR0)/TRY
               S2 = (JMAX+10-YR0)/TRY
             ELSE
               S1 = (-10-ZR0)/TRZ
               S2 = (KMAX+10-ZR0)/TRZ
            ENDIF
            IF (S2.LT.S1) THEN
               SS = S1
               S1 = S2
               S2 = SS
            ENDIF
            X1 = XR0 + TRX*S1
            X2 = XR0 + TRX*S2
            Y1 = YR0 + TRY*S1
            Y2 = YR0 + TRY*S2
            Z1 = ZR0 + TRZ*S1
            Z2 = ZR0 + TRZ*S2
            CALL VRBOXCLIPPING(X1,Y1,Z1,X2,Y2,Z2,IC1,IC2)
            IF (IC1.GT.0) THEN
               CALL VRRAYABSOUPTION(F,IMAX,JMAX,KMAX,
     ,                   X1,Y1,Z1,X2,Y2,Z2,TRX,TRY,TRZ,FM1,FM2,BR)
               BR = BR*BETAD
               IF (BR.GT.1) BR = 1
               NBR = BR*128
*               IF (BR.GT.BRMAX) BRMAX = BR
               CALL GWIOCOLOR(256,NBR)
               CALL GWIOPSET(XP,YP)
*               X1 = X1*DU + CNXMIN
*               X2 = X2*DU + CNXMIN
*               Y1 = Y1*DV + CNYMIN
*               Y2 = Y2*DV + CNYMIN
*               Z1 = Z1*DW + CNZMIN
*               Z2 = Z2*DW + CNZMIN
*               call FR_3DLINE(dble(X1),dble(Y1),dble(Z1)
*     ,                     ,dble(X2),dble(Y2),dble(Z2),6,0)
            ENDIF
         ENDDO
      ENDDO

      CALL GWIOBDFLUSH(1)

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(ICOL,0)

      RETURN
      END

      SUBROUTINE GETVRBOXMINMAX(XPMIN,XPMAX,YPMIN,YPMAX)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /VRENDERPARM3D/ DXPU,DXPV,DXPW,DXP0,DYPU,DYPV,DYPW,DYP0,
     ,               DZPU,DZPV,DZPW,DZP0,NX1,NX2,NY1,NY2,NZ1,NZ2

      XPMIN =  100000
      YPMIN =  100000
      XPMAX = -100000
      YPMAX = -100000

      XP1 = DXPU*NX1 + DXPV*NY1 + DXPW*NZ1 + DXP0
      YP1 = DYPU*NX1 + DYPV*NY1 + DYPW*NZ1 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX1 + DZPV*NY1 + DZPW*NZ1 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX2 + DXPV*NY1 + DXPW*NZ1 + DXP0
      YP1 = DYPU*NX2 + DYPV*NY1 + DYPW*NZ1 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX2 + DZPV*NY1 + DZPW*NZ1 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX1 + DXPV*NY2 + DXPW*NZ1 + DXP0
      YP1 = DYPU*NX1 + DYPV*NY2 + DYPW*NZ1 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX1 + DZPV*NY2 + DZPW*NZ1 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX2 + DXPV*NY2 + DXPW*NZ1 + DXP0
      YP1 = DYPU*NX2 + DYPV*NY2 + DYPW*NZ1 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX2 + DZPV*NY2 + DZPW*NZ1 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX1 + DXPV*NY1 + DXPW*NZ2 + DXP0
      YP1 = DYPU*NX1 + DYPV*NY1 + DYPW*NZ2 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX1 + DZPV*NY1 + DZPW*NZ2 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX2 + DXPV*NY1 + DXPW*NZ2 + DXP0
      YP1 = DYPU*NX2 + DYPV*NY1 + DYPW*NZ2 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX2 + DZPV*NY1 + DZPW*NZ2 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX1 + DXPV*NY2 + DXPW*NZ2 + DXP0
      YP1 = DYPU*NX1 + DYPV*NY2 + DYPW*NZ2 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX1 + DZPV*NY2 + DZPW*NZ2 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XP1 = DXPU*NX2 + DXPV*NY2 + DXPW*NZ2 + DXP0
      YP1 = DYPU*NX2 + DYPV*NY2 + DYPW*NZ2 + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*NX2 + DZPV*NY2 + DZPW*NZ2 + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      IF (XP1.LT.XPMIN) XPMIN = XP1
      IF (XP1.GT.XPMAX) XPMAX = XP1
      IF (YP1.LT.YPMIN) YPMIN = YP1
      IF (YP1.GT.YPMAX) YPMAX = YP1

      XPMIN = XPMIN + XPMID
      XPMAX = XPMAX + XPMID
      YPMIN = YPMIN + YPMID
      YPMAX = YPMAX + YPMID

      call getcanvaswindowsize(IBX,IBY,IOX,IOY)
      XXMIN   = -IOX
      YYMIN   = -IOY
      XXMAX   = IBX-IOX
      YYMAX   = IBY-IOY
      IF (XPMIN.LT.XXMIN) XPMIN = XXMIN
      IF (XPMAX.GT.XXMAX) XPMAX = XXMAX
      IF (YPMIN.LT.YYMIN) YPMIN = YYMIN
      IF (YPMAX.GT.YYMAX) YPMAX = YYMAX

      RETURN
      END

      SUBROUTINE GETRAYEQUATIONS(XP,YP,XR0,YR0,ZR0,TRX,TRY,TRZ,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /VRENDERPARM3D/ DXPU,DXPV,DXPW,DXP0,DYPU,DYPV,DYPW,DYP0,
     ,               DZPU,DZPV,DZPW,DZP0,NX1,NX2,NY1,NY2,NZ1,NZ2

      XP1 = XP - XPMID
      YP1 = YP - YPMID
      IF (MDPROJ.EQ.0) THEN
         DETX = DXPV*DYPW-DXPW*DYPV
         DETY = DXPW*DYPU-DXPU*DYPW
         DETZ = DXPU*DYPV-DXPV*DYPU
         DD  = ABS(DETX)
         IND = 1
         IF (ABS(DETY).GT.DD) THEN
            DD  = ABS(DETY)
            IND = 2
         ENDIF
         IF (ABS(DETZ).GT.DD) IND = 3
         TRX = DETX
         TRY = DETY
         TRZ = DETZ
         XP1 = XP1 - DXP0
         YP1 = YP1 - DYP0
         IF (IND.EQ.1) THEN
            DD  = 1/DETX
            XR0 = 0
            YR0 = (XP1*DYPW-DXPW*YP1)*DD
            ZR0 = (DXPV*YP1-XP1*DYPV)*DD
          ELSE IF (IND.EQ.2) THEN
            DD  = 1/DETY
            XR0 = (DXPW*YP1-XP1*DYPW)*DD
            YR0 = 0
            ZR0 = (XP1*DYPU-DXPU*YP1)*DD
          ELSE
            DD  = 1/DETZ
            XR0 = (XP1*DYPV-DXPV*YP1)*DD
            YR0 = (DXPU*YP1-XP1*DYPU)*DD
            ZR0 = 0
         ENDIF
       ELSE
         DXPU1 = DXPU + DZPU*XP1
         DXPV1 = DXPV + DZPV*XP1
         DXPW1 = DXPW + DZPW*XP1
         DXP01 = DXP0 + DZP0*XP1
         DYPU1 = DYPU + DZPU*YP1
         DYPV1 = DYPV + DZPV*YP1
         DYPW1 = DYPW + DZPW*YP1
         DYP01 = DYP0 + DZP0*YP1
         DETX = DXPV1*DYPW1-DXPW1*DYPV1
         DETY = DXPW1*DYPU1-DXPU1*DYPW1
         DETZ = DXPU1*DYPV1-DXPV1*DYPU1
         DD  = ABS(DETX)
         IND = 1
         IF (ABS(DETY).GT.DD) THEN
            DD  = ABS(DETY)
            IND = 2
         ENDIF
         IF (ABS(DETZ).GT.DD) IND = 3
         TRX = DETX
         TRY = DETY
         TRZ = DETZ
         XP1 = XP1 - DXP01
         YP1 = YP1 - DYP01
         IF (IND.EQ.1) THEN
            DD  = 1/DETX
            XR0 = 0
            YR0 = (XP1*DYPW1-DXPW1*YP1)*DD
            ZR0 = (DXPV1*YP1-XP1*DYPV1)*DD
          ELSE IF (IND.EQ.2) THEN
            DD  = 1/DETY
            XR0 = (DXPW1*YP1-XP1*DYPW1)*DD
            YR0 = 0
            ZR0 = (XP1*DYPU1-DXPU1*YP1)*DD
          ELSE
            DD  = 1/DETZ
            XR0 = (XP1*DYPV1-DXPV1*YP1)*DD
            YR0 = (DXPU1*YP1-XP1*DYPU1)*DD
            ZR0 = 0
         ENDIF
      ENDIF

      DN = DZPU*TRX + DZPV*TRY + DZPW*TRZ
      IF (DN.GT.0) THEN
         TRX = -TRX
         TRY = -TRY
         TRZ = -TRZ
      ENDIF

      RETURN
      END

      SUBROUTINE VRBOXCLIPPING(X1,Y1,Z1,X2,Y2,Z2,IC1,IC2)
      COMMON /VRENDERPARM3D/ DXPU,DXPV,DXPW,DXP0,DYPU,DYPV,DYPW,DYP0,
     ,               DZPU,DZPV,DZPW,DZP0,NX1,NX2,NY1,NY2,NZ1,NZ2
      INTEGER C1,C2

      IK   = 0
      IC1  = 0
      IC2  = 0
      TDX1 = NX1
      TDX2 = NX2
      TDY1 = NY1
      TDY2 = NY2
      TDZ1 = NZ1
      TDZ2 = NZ2

    1   CONTINUE
      IF (X1.LT.TDX1) THEN
         C1 = 1
       ELSE IF (X1.GT.TDX2) THEN
         C1 = 2
       ELSE
         C1 = 0
      ENDIF
      IF (Y1.LT.TDY1) THEN
         C1 = C1 + 4
       ELSE IF (Y1.GT.TDY2) THEN
         C1 = C1 + 8
      ENDIF
      IF (Z1.LT.TDZ1) THEN
         C1 = C1 + 16
       ELSE IF (Z1.GT.TDZ2) THEN
         C1 = C1 + 32
      ENDIF

      IF (X2.LT.TDX1) THEN
         C2 = 1
       ELSE IF (X2.GT.TDX2) THEN
         C2 = 2
       ELSE
         C2 = 0
      ENDIF
      IF (Y2.LT.TDY1) THEN
         C2 = C2 + 4
       ELSE IF (Y2.GT.TDY2) THEN
         C2 = C2 + 8
      ENDIF
      IF (Z2.LT.TDZ1) THEN
         C2 = C2 + 16
       ELSE IF (Z2.GT.TDZ2) THEN
         C2 = C2 + 32
      ENDIF

      IF (C1.EQ.0.AND.C2.EQ.0) RETURN
      IF (IAND(C1,C2).NE.0) THEN
         IC1 = -1
         RETURN
      ENDIF
      IF (X1.EQ.X2) THEN
         IF (Y1.EQ.Y2) THEN
            IF (Z1.LT.TDZ1) THEN
               Z1  = TDZ1
               IC1 = 5
             ELSE IF (Z1.GT.TDZ2) THEN
               Z1  = TDZ2
               IC1 = 6
            ENDIF
            IF (Z2.LT.TDZ1) THEN
               Z2  = TDZ1
               IC2 = 5
             ELSE IF (Z2.GT.TDZ2) THEN
               Z2  = TDZ2
               IC2 = 6
            ENDIF
            RETURN
          ELSE IF (Z1.EQ.Z2) THEN
            IF (Y1.LT.TDY1) THEN
               Y1  = TDY1
               IC1 = 3
             ELSE IF (Y1.GT.TDY2) THEN
               Y1  = TDY2
               IC1 = 4
            ENDIF
            IF (Y2.LT.TDY1) THEN
               Y2  = TDY1
               IC2 = 3
             ELSE IF (Y2.GT.TDY2) THEN
               Y2  = TDY2
               IC2 = 4
            ENDIF
            RETURN
          ELSE
            IF (C1.NE.0) THEN
               IF (IAND(C1,4).NE.0) THEN
                  Z1  = Z1 + (Z2-Z1)*(TDY1-Y1)/(Y2-Y1)
                  Y1  = TDY1
                  IC1 = 3
                ELSE IF (IAND(C1,8).NE.0) THEN
                  Z1  = Z1 + (Z2-Z1)*(TDY2-Y1)/(Y2-Y1)
                  Y1  = TDY2
                  IC1 = 4
                ELSE IF (IAND(C1,16).NE.0) THEN
                  Y1  = Y1 + (Y2-Y1)*(TDZ1-Z1)/(Z2-Z1)
                  Z1  = TDZ1
                  IC1 = 5
                ELSE IF (IAND(C1,32).NE.0) THEN
                  Y1  = Y1 + (Y2-Y1)*(TDZ2-Z1)/(Z2-Z1)
                  Z1  = TDZ2
                  IC1 = 6
               ENDIF
            ENDIF
            IF (C2.NE.0.AND.Y1.NE.Y2.AND.Z1.NE.Z2) THEN
               IF (IAND(C2,4).NE.0) THEN
                  Z2  = Z1 + (Z2-Z1)*(TDY1-Y1)/(Y2-Y1)
                  Y2  = TDY1
                  IC2 = 3
                ELSE IF (IAND(C2,8).NE.0) THEN
                  Z2  = Z1 + (Z2-Z1)*(TDY2-Y1)/(Y2-Y1)
                  Y2  = TDY2
                  IC2 = 4
                ELSE IF (IAND(C2,16).NE.0) THEN
                  Y2  = Y1 + (Y2-Y1)*(TDZ1-Z1)/(Z2-Z1)
                  Z2  = TDZ1
                  IC2 = 5
                ELSE IF (IAND(C2,32).NE.0) THEN
                  Y2  = Y1 + (Y2-Y1)*(TDZ2-Z1)/(Z2-Z1)
                  Z2  = TDZ2
                  IC2 = 6
               ENDIF
            ENDIF
         ENDIF
       ELSE IF (Y1.EQ.Y2) THEN
         IF (Z1.EQ.Z2) THEN
            IF (X1.LT.TDX1) THEN
               X1  = TDX1
               IC1 = 1
             ELSE IF (X1.GT.TDX2) THEN
               X1  = TDX2
               IC1 = 2
            ENDIF
            IF (X2.LT.TDX1) THEN
               X2  = TDX1
               IC2 = 1
             ELSE IF (X2.GT.TDX2) THEN
               X2  = TDX2
               IC2 = 2
            ENDIF
            RETURN
          ELSE
            IF (C1.NE.0) THEN
               IF (IAND(C1,1).NE.0) THEN
                  Z1  = Z1 + (Z2-Z1)*(TDX1-X1)/(X2-X1)
                  X1  = TDX1
                  IC1 = 1
                ELSE IF (IAND(C1,2).NE.0) THEN
                  Z1  = Z1 + (Z2-Z1)*(TDX2-X1)/(X2-X1)
                  X1  = TDX2
                  IC1 = 2
                ELSE IF (IAND(C1,16).NE.0) THEN
                  X1  = X1 + (X2-X1)*(TDZ1-Z1)/(Z2-Z1)
                  Z1  = TDZ1
                  IC1 = 5
                ELSE IF (IAND(C1,32).NE.0) THEN
                  X1  = X1 + (X2-X1)*(TDZ2-Z1)/(Z2-Z1)
                  Z1  = TDZ2
                  IC1 = 6
               ENDIF
            ENDIF
            IF (C2.NE.0.AND.X1.NE.X2.AND.Z1.NE.Z2) THEN
               IF (IAND(C2,1).NE.0) THEN
                  Z2  = Z1 + (Z2-Z1)*(TDX1-X1)/(X2-X1)
                  X2  = TDX1
                  IC2 = 1
                ELSE IF (IAND(C2,2).NE.0) THEN
                  Z2  = Z1 + (Z2-Z1)*(TDX2-X1)/(X2-X1)
                  X2  = TDX2
                  IC2 = 2
                ELSE IF (IAND(C2,16).NE.0) THEN
                  X2  = X1 + (X2-X1)*(TDZ1-Z1)/(Z2-Z1)
                  Z2  = TDZ1
                  IC2 = 5
                ELSE IF (IAND(C2,32).NE.0) THEN
                  X2  = X1 + (X2-X1)*(TDZ2-Z1)/(Z2-Z1)
                  Z2  = TDZ2
                  IC2 = 6
               ENDIF
            ENDIF
         ENDIF
       ELSE IF (Z1.EQ.Z2) THEN
         IF (C1.NE.0) THEN
            IF (IAND(C1,1).NE.0) THEN
               Y1  = Y1 + (Y2-Y1)*(TDX1-X1)/(X2-X1)
               X1  = TDX1
               IC1 = 1
             ELSE IF (IAND(C1,2).NE.0) THEN
               Y1  = Y1 + (Y2-Y1)*(TDX2-X1)/(X2-X1)
               X1  = TDX2
               IC1 = 2
             ELSE IF (IAND(C1,4).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDY1-Y1)/(Y2-Y1)
               Y1  = TDY1
               IC1 = 3
             ELSE IF (IAND(C1,8).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDY2-Y1)/(Y2-Y1)
               Y1  = TDY2
               IC1 = 4
            ENDIF
         ENDIF
         IF (C2.NE.0.AND.X1.NE.X2.AND.Y1.NE.Y2) THEN
            IF (IAND(C2,1).NE.0) THEN
               Y2  = Y1 + (Y2-Y1)*(TDX1-X1)/(X2-X1)
               X2  = TDX1
               IC2 = 1
             ELSE IF (IAND(C2,2).NE.0) THEN
               Y2  = Y1 + (Y2-Y1)*(TDX2-X1)/(X2-X1)
               X2  = TDX2
               IC2 = 2
             ELSE IF (IAND(C2,4).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDY1-Y1)/(Y2-Y1)
               Y2  = TDY1
               IC2 = 3
             ELSE IF (IAND(C2,8).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDY2-Y1)/(Y2-Y1)
               Y2  = TDY2
               IC2 = 4
            ENDIF
         ENDIF
       ELSE
         IF (C1.NE.0) THEN
            IF (IAND(C1,1).NE.0) THEN
               Y1  = Y1 + (Y2-Y1)*(TDX1-X1)/(X2-X1)
               Z1  = Z1 + (Z2-Z1)*(TDX1-X1)/(X2-X1)
               X1  = TDX1
               IC1 = 1
             ELSE IF (IAND(C1,2).NE.0) THEN
               Y1  = Y1 + (Y2-Y1)*(TDX2-X1)/(X2-X1)
               Z1  = Z1 + (Z2-Z1)*(TDX2-X1)/(X2-X1)
               X1  = TDX2
               IC1 = 2
             ELSE IF (IAND(C1,4).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDY1-Y1)/(Y2-Y1)
               Z1  = Z1 + (Z2-Z1)*(TDY1-Y1)/(Y2-Y1)
               Y1  = TDY1
               IC1 = 3
             ELSE IF (IAND(C1,8).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDY2-Y1)/(Y2-Y1)
               Z1  = Z1 + (Z2-Z1)*(TDY2-Y1)/(Y2-Y1)
               Y1  = TDY2
               IC1 = 4
             ELSE IF (IAND(C1,16).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDZ1-Z1)/(Z2-Z1)
               Y1  = Y1 + (Y2-Y1)*(TDZ1-Z1)/(Z2-Z1)
               Z1  = TDZ1
               IC1 = 5
             ELSE IF (IAND(C1,32).NE.0) THEN
               X1  = X1 + (X2-X1)*(TDZ2-Z1)/(Z2-Z1)
               Y1  = Y1 + (Y2-Y1)*(TDZ2-Z1)/(Z2-Z1)
               Z1  = TDZ2
               IC1 = 6
            ENDIF
         ENDIF
         IF (C2.NE.0.AND.X1.NE.X2.AND.Y1.NE.Y2.AND.Z1.NE.Z2) THEN
            IF (IAND(C2,1).NE.0) THEN
               Y2  = Y1 + (Y2-Y1)*(TDX1-X1)/(X2-X1)
               Z2  = Z1 + (Z2-Z1)*(TDX1-X1)/(X2-X1)
               X2  = TDX1
               IC2 = 1
             ELSE IF (IAND(C2,2).NE.0) THEN
               Y2  = Y1 + (Y2-Y1)*(TDX2-X1)/(X2-X1)
               Z2  = Z1 + (Z2-Z1)*(TDX2-X1)/(X2-X1)
               X2  = TDX2
               IC2 = 2
             ELSE IF (IAND(C2,4).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDY1-Y1)/(Y2-Y1)
               Z2  = Z1 + (Z2-Z1)*(TDY1-Y1)/(Y2-Y1)
               Y2  = TDY1
               IC2 = 3
             ELSE IF (IAND(C2,8).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDY2-Y1)/(Y2-Y1)
               Z2  = Z1 + (Z2-Z1)*(TDY2-Y1)/(Y2-Y1)
               Y2  = TDY2
               IC2 = 4
             ELSE IF (IAND(C2,16).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDZ1-Z1)/(Z2-Z1)
               Y2  = Y1 + (Y2-Y1)*(TDZ1-Z1)/(Z2-Z1)
               Z2  = TDZ1
               IC2 = 5
             ELSE IF (IAND(C2,32).NE.0) THEN
               X2  = X1 + (X2-X1)*(TDZ2-Z1)/(Z2-Z1)
               Y2  = Y1 + (Y2-Y1)*(TDZ2-Z1)/(Z2-Z1)
               Z2  = TDZ2
               IC2 = 6
            ENDIF
         ENDIF
      ENDIF

      GO TO 1

      END

      SUBROUTINE VRRAYABSOUPTION(F,IMAX,JMAX,KMAX,
     ,                   X1,Y1,Z1,X2,Y2,Z2,TRX,TRY,TRZ,FM1,FM2,BR)
      REAL*8 F(0:IMAX-1,0:JMAX-1,0:KMAX-1)
      COMMON /VRENDERPARM3D/ DXPU,DXPV,DXPW,DXP0,DYPU,DYPV,DYPW,DYP0,
     ,               DZPU,DZPV,DZPW,DZP0,NX1,NX2,NY1,NY2,NZ1,NZ2
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /VOLUMERENDCOM/ FVRMIN,FVRMAX,ALPHA,BETA,BRMAX,INDBR
      REAL*8 FM1,FM2
      REAL S(10000),S1(10000)

      DD = (X2-X1)**2+(Y2-Y1)**2+(Z2-Z1)**2
      BR = 0
      IF (DD.LT.1.E-4) RETURN

      IF (X2.GT.X1) THEN
         MX1 = X1
         IF (X1-MX1.GT.0) MX1 = MX1 + 1
         MX2 = X2
         IMX = 1
       ELSE
         MX1 = X1
         MX2 = X2
         IF (X2-MX2.GT.0) MX2 = MX2 + 1
         IMX = -1
      ENDIF
      IF (Y2.GT.Y1) THEN
         MY1 = Y1
         IF (Y1-MY1.GT.0) MY1 = MY1 + 1
         MY2 = Y2
         IMY = 1
       ELSE
         MY1 = Y1
         MY2 = Y2
         IF (Y2-MY2.GT.0) MY2 = MY2 + 1
         IMY = -1
      ENDIF
      IF (Z2.GT.Z1) THEN
         MZ1 = Z1
         IF (Z1-MZ1.GT.0) MZ1 = MZ1 + 1
         MZ2 = Z2
         IMZ = 1
       ELSE
         MZ1 = Z1
         MZ2 = Z2
         IF (Z2-MZ2.GT.0) MZ2 = MZ2 + 1
         IMZ = -1
      ENDIF

      IS = 0
      DO I = MX1, MX2, IMX
         IS = IS + 1
         S(IS) = (I-X1)/TRX
         YR = Y1 + TRY*S(IS)
         ZR = Z1 + TRZ*S(IS)
      ENDDO
      IS1 = IS
      DO J = MY1, MY2, IMY
         IS = IS + 1
         S(IS) = (J-Y1)/TRY
         XR = X1 + TRX*S(IS)
         ZR = Z1 + TRZ*S(IS)
      ENDDO
      IS2 = IS
      DO K = MZ1, MZ2, IMZ
         IS = IS + 1
         S1(IS) = (K-Z1)/TRZ
         XR = X1 + TRX*S1(IS)
         YR = Y1 + TRY*S1(IS)
      ENDDO

      IS0 = 0
      ISX = 1
      ISY = IS1 + 1
      DO I = 1, IS
         IF (ISX.GT.IS1) THEN
            DO I1 = ISY, IS2
               IS0 = IS0+1
               S1(IS0) = S(I1)
            ENDDO
            GO TO 100
          ELSE IF (ISY.GT.IS2) THEN
            DO I1 = ISX, IS1
               IS0 = IS0+1
               S1(IS0) = S(I1)
            ENDDO
            GO TO 100
         ENDIF
         IF (S(ISX).LT.S(ISY)) THEN
            IS0 = IS0 + 1
            S1(IS0) = S(ISX)
            ISX = ISX + 1
          ELSE IF (S(ISX).GT.S(ISY)) THEN
            IS0 = IS0 + 1
            S1(IS0) = S(ISY)
            ISY = ISY + 1
          ELSE
            IS0 = IS0 + 1
            S1(IS0) = S(ISX)
            ISX = ISX + 1
            ISY = ISY + 1
         ENDIF
      ENDDO
  100 IS1 = IS0

      IS0 = 0
      ISX = 1
      ISY = IS2 + 1
      IS2 = IS
      DO I = 1, IS
         IF (ISX.GT.IS1) THEN
            DO I1 = ISY, IS2
               IS0 = IS0+1
               S(IS0) = S1(I1)
            ENDDO
            GO TO 200
          ELSE IF (ISY.GT.IS2) THEN
            DO I1 = ISX, IS1
               IS0 = IS0+1
               S(IS0) = S1(I1)
            ENDDO
            GO TO 200
         ENDIF
         IF (S1(ISX).LT.S1(ISY)) THEN
            IS0 = IS0 + 1
            S(IS0) = S1(ISX)
            ISX = ISX + 1
          ELSE IF (S1(ISX).GT.S1(ISY)) THEN
            IS0 = IS0 + 1
            S(IS0) = S1(ISY)
            ISY = ISY + 1
          ELSE
            IS0 = IS0 + 1
            S(IS0) = S1(ISX)
            ISX = ISX + 1
            ISY = ISY + 1
         ENDIF
      ENDDO
 200  IS = IS0

      DD  = SQRT(DD)/S(IS)
      DDA = DD*ALPHA*0.01

      TRM = 1
      DFF = FM2-FM1
      IF (DFF.EQ.0) THEN
         DFF = 1
       ELSE
         DFF = 1/DFF
      ENDIF

      DO I = 1, IS-1
         SM  = (S(I)+S(I+1))/2
         MX  = X1 + TRX*SM
         MY  = Y1 + TRY*SM
         MZ  = Z1 + TRZ*SM
         FF  = (F(MX,MY,MZ)-FM1)*DFF
         IF (FF.LT.0) FF = 0
         BR  = BR + (S(I+1)-S(I))*FF*TRM
         TT  = DDA*(S(I+1)-S(I))*FF
         IF (TT.GT.1) TT = 1
         TRM = (1-TT)*TRM
      ENDDO

      BR  = DD*BR

      RETURN
      END
