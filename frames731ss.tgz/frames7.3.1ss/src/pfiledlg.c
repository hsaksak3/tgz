/*************************************************************
 *                   F r a m e s  V.7.2                      *
 *             File Selection Dialog for tplot               *
 *     Original List was published in UNIX User, 2000/2      *
 *                    Programed by Y. Seto                   *
 *      Modified and Extended for tplot by T. Taguchi        *
 *************************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <unistd.h> 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <glob.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Scrollbar.h>

extern Widget 	file_button;
extern Pixmap 	check_bmp, blank_bmp;
extern char		filename[],**filelist;
extern int		flistno;

static Widget 	file_top;
static Widget 	text1, text2;
static Widget 	flist1, flist2, vport2;
static Position xp=0, yp=0;
static int		cfile=0, nfile, file_on, name_on, scheckf=0;

#define check_width		16
#define check_height	16
#define MAX(X,Y)		((X)>=(Y)?(X):(Y))
#define MAXWIDTH		800
#define MAXHEIGHT		600
#define CWIDMAX			5

int		check_ext(char *,char *,char *);
void 	file_process(int);


static void text_out(Widget w, char *s)
{
/*  String str; 
	str=XtNewString(s);
	XtVaSetValues(w, XtNstring, str, NULL);		Xaw3d*/

	if (s==NULL) XtVaSetValues(w, XtNstring, "", NULL);  /*Xaw*/
	  else {
		XtVaSetValues(w, XtNdisplayCaret, False, NULL);
		XtVaSetValues(w, XtNstring, s, NULL);  /*Xaw*/
		XtVaSetValues(w, XtNdisplayCaret, True, NULL);
	}
}

static void file_window()
{
	String dir, fname;
	char buf[1024];

	if (name_on) {
		XtSetSensitive(file_button,TRUE);
		if (file_on==0) return;
	  }
	  else if (file_on==0) exit(0);

	XtVaGetValues(text1, XtNstring, &dir, NULL);
	XtVaGetValues(text2, XtNstring, &fname, NULL);
	sprintf(buf,"%s/%s",dir,fname);

	if (check_ext(buf,filename,"plt")) return;
	if (name_on) file_process(scheckf);
}

static void ok_btn_cb(Widget w, XtPointer w1, XtPointer w2)
{
/*	void (*main_ok_cb)();
	main_ok_cb=w1;			*/
	XtPopdown(file_top);
	file_on=1;
/*	(*main_ok_cb)((void *)dir, (void *)fname); 		*/
}

static void cancel_btn_cb(Widget w, XtPointer w1, XtPointer w2)
{
	XtPopdown(file_top);
	file_on=0;
}

static void list_clear(Widget list)
{
	String *strs;
	int i, n;

	XtVaGetValues(list, XtNnumberStrings, &n, XtNlist, &strs, NULL);
  
	for (i = 0; i < n; i++) XtFree((XtPointer) strs[i]);
	XtFree((XtPointer) strs);
}

static int checkext(char *name, char *ext)
{
	int i,n1=strlen(name),n2;

	if (ext==NULL) return 1;

	n2=strlen(ext);
	if (n1<=n2) return 0;
	if (strcmp(&name[n1-n2],ext)==0) return 1;
	return 0;
}	

static int sort_cmp(char **a, char **b)
{
	return strcmp(*a, *b);
}

static void file_number(char *dir_name, char *ext, int *cn, int *slenmax, int *fwid, int *fhei)
{
	DIR    *dir;
	struct dirent *pdire;
	struct stat sbuf;
	int    i,cnt=0,slen=0;
	XFontStruct     *fontst;

	XtVaGetValues(text2,XtNfont,&fontst,NULL);
	*fwid=fontst->max_bounds.width;
	if (*fwid == 0) *fwid=8;
	*fhei=fontst->max_bounds.ascent+fontst->max_bounds.descent;
	if (*fhei == 0) *fhei=16;

	if (flistno>1) {
		for (i=0;i<flistno;i++) {
			if (checkext(filelist[i],ext)) {
				cnt++;		slen=MAX(slen,strlen(filelist[i]));
			}
		}
		if (cnt>0) {
			*cn=cnt;		*slenmax=slen;
			return;
		}
		flistno=0;
	}
	if (*filename=='\0' || name_on) {
		dir=opendir(".");
		pdire=readdir(dir);
		while (pdire) {
			if (0 != strcmp(pdire->d_name, ".")) {
				stat(pdire->d_name, &sbuf);
				if (S_ISREG(sbuf.st_mode) && checkext(pdire->d_name,ext)) {
					cnt++;		slen=MAX(slen,strlen(pdire->d_name));
				}
			}
			pdire=readdir(dir);
		}
	  	*cn=cnt;		*slenmax=slen;
	  }
	  else {
	  	*cn=0;		*slenmax=0;
	}
}

static void file_set(char *dir_name, char *ext)
{
	static int fg=0;

	DIR    *dir;
	struct dirent *pdire;
	struct stat sbuf;
	int    cnt,i;
	String *list_file;
	static String nulstr[2]={"",NULL};
	glob_t globbuf;

	if (fg){  
		list_clear(flist2);
		fg=1;
	}

	if (flistno>1) {
		for (i=cnt=0;i<flistno;i++) {
			if (checkext(filelist[i],ext)) cnt++;
		}
		if (cnt) {
			list_file = (String *) XtCalloc(sizeof(String *), cnt);
			for (i=cnt=0;i<flistno;i++) {
				if (checkext(filelist[i],ext)) list_file[cnt++]=XtNewString(filelist[i]);
			}
		}
	  }
	  else if (*filename=='\0' || name_on) {
		dir=opendir(".");
		cnt=0;
		pdire=readdir(dir);
		while(pdire){
			if (0 != strcmp(pdire->d_name, ".")) {
				stat(pdire->d_name, &sbuf);
				if (S_ISREG(sbuf.st_mode) && checkext(pdire->d_name,ext)) cnt++;
			}
			pdire=readdir(dir);
		}
		if (cnt) list_file = (String *) XtCalloc(sizeof(String *), cnt);

		cnt=0;
		rewinddir(dir);
		pdire=readdir(dir);
		while(pdire){
			if (0 != strcmp(pdire->d_name, ".")){
				stat(pdire->d_name, &sbuf);
				if (S_ISREG(sbuf.st_mode) && checkext(pdire->d_name,ext))
						list_file[cnt++]=XtNewString(pdire->d_name);
			}
			pdire=readdir(dir);
		}
		closedir(dir);
	  }
	  else {
		globbuf.gl_offs=0;
		glob(filename,GLOB_DOOFFS,NULL,&globbuf);
		glob(filename,GLOB_DOOFFS|GLOB_APPEND,NULL,&globbuf);
		for (i=cnt=0;i<globbuf.gl_pathc;i++) {
			stat(globbuf.gl_pathv[i], &sbuf);
			if (S_ISREG(sbuf.st_mode) && checkext(globbuf.gl_pathv[i],ext)) cnt++;
		}
		if (cnt) list_file = (String *) XtCalloc(sizeof(String *), cnt);
		for (i=cnt=0;i<globbuf.gl_pathc;i++) {
			stat(globbuf.gl_pathv[i], &sbuf);
			if (S_ISREG(sbuf.st_mode) && checkext(globbuf.gl_pathv[i],ext))
						list_file[cnt++]=XtNewString(globbuf.gl_pathv[i]);
		}
		globfree(&globbuf);
	}

	if (cnt) {
		qsort(list_file, cnt, sizeof(String), (int (*)(const void *, const void *)) sort_cmp);
/*				(int (*)(_Xconst void *, _Xconst void *)) sort_cmp);	*/
		XawListChange(flist2, list_file, cnt, 0, True);
		XawListHighlight(flist2, cfile);
		text_out(text2, list_file[cfile]);
		XawTextSetInsertionPoint(text2, strlen(list_file[cfile]));
		nfile=cnt;
	  }
	  else {
		XawListChange(flist2, nulstr, cnt, 0, True);
		text_out(text2, NULL);
		nfile=1;
	}
	return;
}

static void dir_set(char *dir_name)
{
	static int fg=0;

	DIR    *dir;
	struct dirent *pdire;
	struct stat sbuf;
	int    cnt;
	String *list_dir;
	char   buff[1024];

	if (fg){
		list_clear(flist1);
		fg=1;
	}

	chdir(dir_name);
	getcwd(buff, sizeof(buff));
	text_out(text1, buff);
	XtVaSetValues(text1, XtNdisplayCaret, False, NULL);

	dir=opendir(".");
	cnt=0;
	pdire=readdir(dir);
	while(pdire){
		if (0 != strcmp(pdire->d_name, ".")){
			stat(pdire->d_name, &sbuf);
			if (S_ISDIR(sbuf.st_mode)) cnt++;
		}
		pdire=readdir(dir);
	}
	list_dir = (String *) XtCalloc(sizeof(String *), cnt);

	cnt=0;
	rewinddir(dir);
	pdire=readdir(dir);
	while(pdire){
		if (0 != strcmp(pdire->d_name, ".")){
			stat(pdire->d_name, &sbuf);
			if (S_ISDIR(sbuf.st_mode))
					list_dir[cnt++]=XtNewString(pdire->d_name);
		}
		pdire=readdir(dir);
	}
	closedir(dir);

	if (cnt){
		qsort(list_dir, cnt, sizeof(String), (int (*)(const void *, const void *)) sort_cmp);
/*				(int (*)(_Xconst void *, _Xconst void *)) sort_cmp);	*/
		XawListChange(flist1, list_dir, cnt, 0, True);
		XawListHighlight(flist1, 0);
		/*cfile=0;*/		yp=0;
	}

	file_set(".",".plt");
/*	file_set(".",NULL);		*/

	return;
}

void file_frame(Widget w, int n)
{
	name_on=n;
	dir_set(".");
	XawViewportSetCoordinates(vport2,xp,yp);
	XtPopup(file_top, XtGrabNonexclusive);
	XtSetKeyboardFocus(file_top, text2);
	if (n) XtSetSensitive(w,FALSE);
}

static void list1_cb(Widget w, XtPointer text1, XtPointer itemArg)
{
	XawListReturnStruct *item;

	item=(XawListReturnStruct *)itemArg;
	dir_set(item->string);
	cfile=0;
}

static void list2_cb(Widget w, XtPointer text1, XtPointer itemArg)
{
	XawListReturnStruct *item;

	item=(XawListReturnStruct *)itemArg;
	text_out(text2, item->string);
	XawTextSetInsertionPoint(text2, strlen(item->string));
}

void checkf_cb(Widget w, XtPointer pnt, XtPointer dmy)
{
	int no=(int)pnt;

	XtVaSetValues(w, XtNbitmap, blank_bmp, NULL);
	scheckf = !scheckf;
	if (scheckf) XtVaSetValues(w, XtNbitmap, check_bmp, NULL);
}

void updown_lkey_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	int n,cwid,ncol,nrow,nvrow,n1,n2,nsc=0;
	Dimension col,row,wid,wid1,hei,hei1,hhei,vhei;
	XawListReturnStruct *item;
/*	Widget sc;	*/
	XFontStruct     *fontst;

	if (nfile==0) return;

	XtVaGetValues(flist2,XtNcolumnSpacing,&col,XtNrowSpacing,&row
						,XtNinternalWidth,&wid1,XtNinternalHeight,&hei1
						,XtNwidth,&wid,XtNlongest,&cwid,XtNheight,&hei
						,XtNfont,&fontst,NULL);
	ncol=(wid-2*wid1)/(cwid+col);
	nrow=nfile/ncol;
	if (nfile%ncol) nrow++;
	ncol=nfile/nrow;
	if (nfile%nrow) ncol++;
	XtVaGetValues(vport2,XtNheight,&vhei,NULL);
/*
	sc=XtNameToWidget(vport2,"vertical");
	XtVaGetValues(sc,XtNheight,&hei1,NULL);
	hhei=hei1/2;
	XawScrollbarSetThumb(sc,(float)0.5,(float)yp);
	XtVaGetValues(sc,XtNtopOfThumb,&x,XtNshown,&yp,NULL);
	XawViewportSetLocation(vport2,0.5,0.5);
*/
	row=fontst->max_bounds.ascent+fontst->max_bounds.descent+row;
	nvrow=vhei/row;
	hhei=nvrow*row;

	item=XawListShowCurrent(flist2);
	XawListUnhighlight(flist2);
	n=item->list_index;
	n1=(n/nrow)*nrow;		n2=n1+nrow;
	if (n2>nfile) n2=nfile;
	if (*(vector[0])=='0') {
		n--;		if (n<n1) n++;
	  	if ((n-n1)*row<yp) nsc=-1;
	  }
	  else if (*(vector[0])=='1') {
	  	n++;		if (n>=n2) n--;
	  	if ((n-n1+1)*row>=yp+vhei) nsc=1;
	  }
	  else if (*(vector[0])=='2') {
	  	n-=nrow;	if (n<0) n+=nrow;
	  }
	  else if (*(vector[0])=='3') {
	  	n+=nrow;	if (n>=nfile) n-=nrow;
	  }	
	  else if (*(vector[0])=='4') nsc=-2;
	  else if (*(vector[0])=='5') nsc=+2;

	if (nsc<0) {
	  	yp-=hhei;
	  	if (yp<0) yp=0;
		if (n==-2) {  n-=nvrow;	if (n<n1) n=n1;  }
	  }
	  else if (nsc>0) {
	  	yp+=hhei;
	  	if (yp>=hei) yp-=hhei;
		  else {
	  		if (yp+vhei>=hei) yp=hei-vhei;
	  		if (nsc==2) {  n+=nvrow;	if (n>=n2) n=n2-1;  }
	  	}
	}

	XawViewportSetCoordinates(vport2,xp,yp);

	XawListHighlight(flist2, n);
	item=XawListShowCurrent(flist2);
	text_out(text2, item->string);
	XawTextSetInsertionPoint(text2, strlen(item->string));
	cfile=n;
}

void create_file_dialog(Widget top, XtAppContext app)
{
	static XtActionsRec actions[]={
		{"filewindow", (XtActionProc)file_window},
		{"cancel_fil", (XtActionProc)cancel_btn_cb},
		{"ok_cb", (XtActionProc)ok_btn_cb},
		{ "updown_lkey"  , (XtActionProc)updown_lkey_cb},
	};
	static XtTranslations trans,trans1,transl;
	static Atom wm_delete_window;

	Widget form0, form1, form2, form21, form22;
	Widget btn1, btn2, label1, check1;
	Widget vport1;
	int cn,slenmax,fheight,fwidth,i,fwid,fhei;

	XtAppAddActions(app, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Unmap>: filewindow()\n\
						<Message>WM_PROTOCOLS: cancel_fil()");

/*	PageUp--Prior,	PageDown--Next	*/
	trans = XtParseTranslationTable("#override\n\
						<Key>Return: ok_cb()\n\
						<Key>KP_Enter: ok_cb()\n\
						<Key>Linefeed: no-op()\n\
						<Key>Up:   updown_lkey(0)\n\
						<Key>Down: updown_lkey(1)\n\
						<Key>Left:   updown_lkey(2)\n\
						<Key>Right:   updown_lkey(3)\n\
						<Key>Prior:   updown_lkey(4)\n\
						<Key>Next:   updown_lkey(5)\n\
						Ctrl<Key>M: ok_cb()\n\
						Ctrl<Key>J: ok_cb()");

	transl = XtParseTranslationTable("#override\n\
						<Btn1Down>,<Btn1Up>: Set() Notify()\n\
						<Btn1Up>(2): ok_cb()\n\
						Ctrl<Key>J: ok_cb()");

	file_top=XtVaCreatePopupShell("file_top", transientShellWidgetClass, top,
                         XtNtranslations, trans1,
						XtNtitle, "File Dialog", NULL);

	form0 = XtVaCreateManagedWidget("fform0", formWidgetClass, file_top,
						XtNborderWidth, 0,
						NULL);
	form1 = XtVaCreateManagedWidget("fform1", formWidgetClass, form0, 
						XtNborderWidth, 0,
						XtNleft, XtChainLeft,
						XtNright, XtChainRight,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);

	form2 = XtVaCreateManagedWidget("fform2", formWidgetClass, form0, 
						XtNfromVert, form1,
						XtNleft, XtChainLeft,
						XtNright, XtChainRight,
						XtNtop, XtChainTop,
						XtNbottom, XtChainBottom,
						NULL);

	text1 = XtVaCreateManagedWidget("ftext1", asciiTextWidgetClass, form1,
						XtNborderWidth, 1,
						XtNwidth, 400,
						XtNleft, XtChainLeft,
						XtNright, XtChainRight,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	btn1=XtVaCreateManagedWidget("fok1", commandWidgetClass, form1,
						XtNlabel, " OK ",
						XtNfromHoriz, text1,
						XtNleft, XtChainRight,
						XtNright, XtChainRight,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNborderWidth, 1,
						NULL);

	XtAddCallback(btn1, XtNcallback, ok_btn_cb, NULL);

	btn2=XtVaCreateManagedWidget("fcancel1", commandWidgetClass, form1,
						XtNlabel, "Cancel",
						XtNfromHoriz, btn1,
						XtNleft, XtChainRight,
/*						XtNright, XtChainRight,		*/
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNborderWidth, 1,
						NULL);
						
	XtAddCallback(btn2, XtNcallback, cancel_btn_cb, NULL);

	text2 = XtVaCreateManagedWidget("ftext2", asciiTextWidgetClass, form1,
						XtNeditType, XawtextEdit,
						XtNfromVert, text1,
						XtNwidth, 340,
						XtNleft, XtChainLeft,
/*						XtNright, XtChainRight,		*/
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNtranslations, trans,
						NULL);

	label1 = XtVaCreateManagedWidget("fkeep", labelWidgetClass, form1,
						XtNlabel, "Keep Conditions?",
						XtNborderWidth, 0,
						XtNfromVert, text1,
						XtNfromHoriz, text2,
						XtNhorizDistance, 10,
						XtNvertDistance, 8,
						NULL);

	check1 = XtVaCreateManagedWidget("checkf", commandWidgetClass, form1, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, text1,
						XtNfromHoriz, label1,
						XtNvertDistance, 4,
						XtNborderWidth, 1, NULL);

	XtAddCallback(check1, XtNcallback, checkf_cb, (XtPointer)1);

	file_number(".", ".plt", &cn, &slenmax, &fwid, &fhei);
	fhei+=4;		fwid++;
	for (i=3;i<CWIDMAX;i++) {
		if ((cn-1)/i<=20) {
			fheight=MAX(200,fhei*((cn-1)/i+1));
			fwidth=MAX(300,(slenmax+1)*fwid*i);
			break;
		}
	}
	if (i >= CWIDMAX) {
		fheight=MAX(200,fhei*((cn-1)/CWIDMAX+1));
		fwidth=MAX(300,(slenmax+1)*fwid*CWIDMAX);
	}

	if (fheight>MAXHEIGHT) fheight=MAXHEIGHT;
	if (fwidth>MAXWIDTH) fwidth=MAXWIDTH;

	form21 = XtVaCreateManagedWidget("fform21", panedWidgetClass, form2,
						XtNborderWidth, 1,
						XtNwidth, 180,
						XtNheight, fheight,
						NULL);
	form22 = XtVaCreateManagedWidget("fform22", panedWidgetClass, form2,
						XtNfromHoriz, form21,
						XtNborderWidth, 1,
						XtNwidth, fwidth,
						XtNheight, fheight,
						NULL);

	vport1 = XtVaCreateManagedWidget("fvport1", viewportWidgetClass, form21,
						XtNallowVert, True,
						XtNallowHoriz, True,
						XtNuseRight, True,
						XtNuseBottom, True,
						NULL);
	flist1 = XtVaCreateManagedWidget("flist1", listWidgetClass, vport1,
						XtNverticalList, True,
						XtNcolumnSpacing, 10,
						NULL);
	XtAddCallback(flist1, XtNcallback, list1_cb, text1);

	vport2 = XtVaCreateManagedWidget("fvport2", viewportWidgetClass, form22,
						XtNallowVert, True,
						XtNallowHoriz, True,
						XtNuseRight, True,
						XtNuseBottom, True,
						NULL);
	flist2 = XtVaCreateManagedWidget("flist2", listWidgetClass, vport2,
						XtNverticalList, True,
						XtNcolumnSpacing, 10,
						XtNtranslations, transl,
						NULL);
	XtAddCallback(flist2, XtNcallback, list2_cb, text2);

	dir_set(".");

	XtRealizeWidget(file_top);
	if (scheckf) XtVaSetValues(check1, XtNbitmap, check_bmp, NULL);
		else 	 XtVaSetValues(check1, XtNbitmap, blank_bmp, NULL);
/*
	XtOverrideTranslations(file_top, XtParseTranslationTable ("<Message>WM_PROTOCOLS: cancel_fil()"));
*/
	wm_delete_window = XInternAtom(XtDisplay(file_top), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(file_top), XtWindow(file_top), &wm_delete_window, 1);
}
