***********************************
*     F  R  A  M  E  S  V.7       *
*    2D   FRAME  SUBROUTINES      *
*    PROGRAMMED BY T.TAGUCHI      *
***********************************

      SUBROUTINE FR_VIEW2D(XXMIN,YYMIN,XXMAX,YYMAX)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /GRAPHCOM3D/ XMIN3,XMAX3,YMIN3,YMAX3,XTAN3,YTAN3,X03,Y03
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN3,IXMAX3,IYMIN3,IYMAX3,IZXMAX,IZYMAX,IFRAM3,IVIEW3
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER XXMIN,YYMIN,XXMAX,YYMAX

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(1,1)
         CALL GSENDBYTE(XXMIN,2)
         CALL GSENDBYTE(YYMIN,2)
         CALL GSENDBYTE(XXMAX,2)
         CALL GSENDBYTE(YYMAX,2)
      ENDIF

      IXBMIN = XXMIN
      IYBMIN = YYMIN
      IXBMAX = XXMAX
      IYBMAX = YYMAX
      IFRAM  = 0
      IVIEW  = 1
      IVIEW3 = 0
      ICNREG = 0
      IF (IXBMIN.GT.IXBMAX) THEN
         II     = IXBMAX
         IXBMAX = IXBMIN
         IXBMIN = II
      ENDIF
      IF (IYBMIN.GT.IYBMAX) THEN
         II     = IYBMAX
         IYBMAX = IYBMIN
         IYBMIN = II
      ENDIF

      RETURN
      END

      SUBROUTINE FR_MARGIN2D(XLM,YLM,XUM,YUM)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER XXMIN,YYMIN,XXMAX,YYMAX,XLM,YLM,XUM,YUM

      IF (IGCANVAS.LT.0) RETURN

      call getcanvaswindowsize(IBX,IBY,IOX,IOY)
      XXMIN   = XLM-IOX
      YYMIN   = YLM-IOY
      XXMAX   = IBX-IOX-XUM
      YYMAX   = IBY-IOY-YUM

      CALL FR_VIEW2D(XXMIN,YYMIN,XXMAX,YYMAX)

      RETURN
      END

      SUBROUTINE FR_ASPECT2D(RTX,RTY,IND)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 RTX,RTY,RY

      IF (IGCANVAS.LT.0) RETURN

      IF (RTX.EQ.0.0D0.OR.RTY.EQ.0.0D0) THEN
         CALL FRAMESERROR('ILLEGAL SETTINGS FOR 2D ASPECT RATIO')
         RETURN
      ENDIF

      RY = RTY/RTX
      IF (IGPLT.GT.0) THEN
         IF (IVIEW.EQ.0) CALL FR_VIEW2D(IXBMIN,IYBMIN,IXBMAX,IYBMAX)
         CALL GSENDBYTE(7,1)
         CALL GSENDBYTE(IND,1)
         CALL GSEND8BYTE(RY,RY,1,-1)
         IVIEW = 2
      ENDIF

      RXY    = RY
      IASPEC = IND
      IFRAM  = 0
      IF (IASPEC.LT.0) THEN
         IXMIN = IXBMIN
         IXMAX = IXBMAX
         IYMIN = IYBMIN
         IYMAX = IYBMAX
      ENDIF

      RETURN
      END

      SUBROUTINE FR_FRAME2D(XXMIN0,XXMAX0,YYMIN0,YYMAX0,IND)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /AXISNAMECOM/ XNAME,YNAME,IXYNAME,LXNM,LYNM
      CHARACTER XNAME*128,YNAME*128
      REAL*8 XXMIN0,XXMAX0,YYMIN0,YYMAX0,XXMIN,XXMAX,YYMIN,YYMAX

      IF (IGCANVAS.LT.0) RETURN

      IOFR = 0
      IF (IND.EQ.99999) THEN
*         IOFR = 1
         IND1 = IFRAM - 1
         IF (IND1.EQ.0) THEN
            IND1 = 6
          ELSE IF (IND1.EQ.4) THEN
            IND1 = 7
          ELSE IF (IND1.EQ.5) THEN
            IND1 = 8
         ENDIF
         GO TO 100
      ENDIF

      IND0 = MOD(IND,100)
      IF (IVIEW.NE.2.AND.IND.GE.100) CALL FR_ASPECT2D(1.D0,1.D0,0)

      CALL REGULATEGREGION(XXMIN0,XXMAX0,XXMIN,XXMAX)
      CALL REGULATEGREGION(YYMIN0,YYMAX0,YYMIN,YYMAX)

      IF (IASPEC.EQ.0) THEN
         RX     = (IXBMAX - IXBMIN)/ABS(XXMAX - XXMIN)
         RY     = (IYBMAX - IYBMIN)/(ABS(YYMAX - YYMIN)*RXY)
         IF (RX.GE.RY) THEN
            IYMIN = IYBMIN
            IYMAX = IYBMAX
            IXMIN = 0.5*((IXBMIN+IXBMAX) - RY*ABS(XXMAX-XXMIN)) + 0.5
            IXMAX = 0.5*((IXBMIN+IXBMAX) + RY*ABS(XXMAX-XXMIN)) + 0.5
          ELSE
            IXMIN = IXBMIN
            IXMAX = IXBMAX
            IYMIN = 0.5*((IYBMIN+IYBMAX) - RX*ABS(YYMAX-YYMIN)*RXY)+0.5
            IYMAX = 0.5*((IYBMIN+IYBMAX) + RX*ABS(YYMAX-YYMIN)*RXY)+0.5
         ENDIF
        ELSE IF (IASPEC.EQ.1) THEN
         RX     = IXBMAX - IXBMIN
         RY     = (IYBMAX - IYBMIN)/RXY
         IF (RX.GE.RY) THEN
            IYMIN = IYBMIN
            IYMAX = IYBMAX
            IXMIN = 0.5*((IXBMIN+IXBMAX) - (IYBMAX-IYBMIN)/RXY) + 0.5
            IXMAX = 0.5*((IXBMIN+IXBMAX) + (IYBMAX-IYBMIN)/RXY) + 0.5
          ELSE
            IXMIN = IXBMIN
            IXMAX = IXBMAX
            IYMIN = 0.5*((IYBMIN+IYBMAX) - (IXBMAX-IXBMIN)*RXY) + 0.5
            IYMAX = 0.5*((IYBMIN+IYBMAX) + (IXBMAX-IXBMIN)*RXY) + 0.5
         ENDIF
        ELSE
         IXMIN = IXBMIN
         IYMIN = IYBMIN
         IXMAX = IXBMAX
         IYMAX = IYBMAX
      ENDIF

      XMIN = XXMIN
      XMAX = XXMAX
      YMIN = YYMIN
      YMAX = YYMAX
      XTAN = (IXMAX - IXMIN)/(XMAX - XMIN)
      YTAN = (IYMIN - IYMAX)/(YMAX - YMIN)
      X0   = IXMIN - XTAN*XMIN
      Y0   = IYMAX - YTAN*YMIN

      IF (IGPLT.GT.0) THEN
         IF (IVIEW.NE.2) CALL FR_ASPECT2D(1.D0,DBLE(RXY),IASPEC)
         IFRAM = 1
         IF (IFRAM.NE.999) THEN
            CALL GFILEFRAME(XXMIN,XXMAX,YYMIN,YYMAX,IND0)
*            IF (IFSW.EQ.2) RETURN
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) THEN
         LABELAX = 0
         RETURN
      ENDIF

      IND1  = MOD(IND0,10)
      IF (IND1.EQ.3) IND1 = 6
      ICLP1 = IND0/10
      IF (ICLP1.NE.9) ICLP = ICLP1
      IFRAM = IND1 + 1

 100  CALL GWIONOCLIP
      IF (IND1.EQ.1) GO TO 998

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(20)
      CALL GWIOCOLOR(0,-7)
      CALL GWIOLINE(REAL(IXMIN),REAL(IYMIN),REAL(IXMAX),REAL(IYMAX),1)

      IF (IND1.NE.2.AND.IOFR.EQ.0) CALL FRAMES2DAXIS(IND1,0)

      CALL GWIOBDFLUSH(1)
 998  IF (ICLP.NE.0) CALL GWIOADDCLIP(REAL(IXMIN),REAL(IYMIN)
     ,                                   ,REAL(IXMAX),REAL(IYMAX))
      IF (IND1.NE.1.AND.IXYNAME.NE.0) CALL FR_XYNAME(' ',' ')

      RETURN
      END

      SUBROUTINE FR_LOGAXIS(IND)
*     IND=0..LIN-LIN, 1..LIN-LOG, 2..LOG-LIN, 3..LOG-LOG
*     IF IND/10 = 1 THEN NO Y-AXIS NUMBERS
*     IF IND/10 = 2 THEN NO X-AXIS NUMBERS
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /AXISNAMECOM/ XNAME,YNAME,IXYNAME,LXNM,LYNM
      CHARACTER XNAME*128,YNAME*128

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(13,1)
         CALL GSENDBYTE(IND,1)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      LOGFORM = MOD(IND,10)
      IAX     = IND/10
      IFRAM   = 1

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIONOCLIP
      CALL GWIOSETAASPACE(20)
      CALL GWIOCOLOR(0,-7)
      CALL GWIOLINE(REAL(IXMIN),REAL(IYMIN),REAL(IXMAX),REAL(IYMAX),1)

      CALL FRAMES2DAXIS(0,IAX)

      CALL GWIOBDFLUSH(1)
      IF (ICLP.NE.0) CALL GWIOADDCLIP(REAL(IXMIN),REAL(IYMIN)
     ,                                   ,REAL(IXMAX),REAL(IYMAX))
      IF (IXYNAME.NE.0) CALL FR_XYNAME(' ',' ')

      RETURN
      END

      SUBROUTINE FRAMES2DAXIS(IND1,IAX)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      REAL LOGPOS(2:9)
      INTEGER INDS(2)
      CHARACTER CH*20,FORM*20
      DATA LOGPOS/0.3010300, 0.4771213,
     +            0.6020600, 0.6989700,
     +            0.7781513, 0.8450980,
     +            0.9030900, 0.9542425/


      INDS(1) = MOD(LOGFORM,2)
      INDS(2) = MOD(LOGFORM/2,2)
      IF (INDS(1).NE.0.AND.XMAX-XMIN.LT.1.0) INDS(1) = 0
      IF (INDS(2).NE.0.AND.YMAX-YMIN.LT.1.0) INDS(2) = 0
      LOGFORM = 0

      IZERO = 0
      IF (IND1.LT.3) IZERO = 1

      XX = 0
      IF (INDS(1).EQ.0) THEN
         IF (IXMIN+20.LT.X0.AND.X0.LT.IXMAX-20.AND.IZERO.NE.0) THEN
            XX = X0
            CALL GWIOLINE(XX,REAL(IYMIN),XX,REAL(IYMAX),1)
         ENDIF
      ENDIF

      YY = 0
      IF (INDS(2).EQ.0) THEN
         IF (IYMIN+20.LT.Y0.AND.Y0.LT.IYMAX-20.AND.IZERO.NE.0) THEN
            YY = Y0
            CALL GWIOLINE(REAL(IXMIN),YY,REAL(IXMAX),YY,0)
         ENDIF
      ENDIF

      IF (MOD(LABELAX,2).EQ.1) THEN
         IXNUM = 0
       ELSE
         IXNUM = 1
      ENDIF

      IF (LABELAX/2.EQ.1) THEN
         IYNUM = 0
       ELSE
         IYNUM = 1
      ENDIF
      LABELAX = 0

      DO 10 I = 1, 2
         IF (I.EQ.1) THEN
            ZMIN = XMIN
            ZMAX = XMAX
            ZTAN = XTAN
            Z0   = X0
          ELSE
            ZMIN = YMIN
            ZMAX = YMAX
            ZTAN = YTAN
            Z0   = Y0
         ENDIF
         IF (ZMIN.GT.ZMAX) THEN
            Z = ZMAX
            ZMAX = ZMIN
            ZMIN = Z
         ENDIF

         IF (INDS(I).EQ.0) THEN
            CALL AXISDELFORM(ZMIN,ZMAX,DZ,FORM,NS,NSC,NS1,NMZ,1)
            IF (NMZ.NE.0) THEN
               ZMIN = ZMIN*10.D0**(-NMZ)
               ZMAX = ZMAX*10.D0**(-NMZ)
               ZTAN = ZTAN*10.D0**(NMZ)
            ENDIF
          ELSE
            CALL LOGARLABEL(ZMIN,ZMAX,DZ,NS,NS2,NMZ)
            NSC = 1
         ENDIF

         ZMIN = ZMIN - 0.0001*DZ
         ZMAX = ZMAX + 0.0001*DZ
         NM   = INT(ZMIN/DZ) - 1
         ZZT  = NM*DZ

1000     IF (ZZT.LT.ZMIN) THEN
            NM  = NM + 1
            ZZT = DZ*NM
            GO TO 1000
         ENDIF
         Z1 = ZMIN
         IF (I.EQ.1) THEN
            PZ = IYMAX
1010        IF (ZZT.LT.ZMAX) THEN
               PZT = ZTAN*ZZT + Z0
               NT  = 4
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT*2
                  IF (MOD(NM,NSC).EQ.0.AND.IAX.NE.2) THEN
                     IF (IXNUM.EQ.1) THEN
                        IF (INDS(1).EQ.0) THEN
                           WRITE(CH,FORM) ZZT
                           CALL FWNUMBER(PZT,PZ,CH,NMZ,1,2,-1,2)
                         ELSE
                           CALL LGNUMBER(PZT,PZ,ZZT,NMZ,1,2,-1)
                        ENDIF
                     ENDIF
                   ELSE IF (NS1.EQ.1) THEN
                     NT = NT*3/4
                  ENDIF
               ENDIF
               CALL GWIOLINE(PZT,REAL(IYMAX),PZT,REAL(IYMAX-NT),0)
               CALL GWIOLINE(PZT,REAL(IYMIN),PZT,REAL(IYMIN+NT),0)
               IF (YY.NE.0) CALL GWIOLINE(PZT,YY-NT/2,PZT,YY+NT/2,0)
               IF (INDS(1).NE.0.AND.NS2.NE.0) THEN
                  Z2  = ZZT
                  LZ  = 2
                  NT  = 4
                  IF (NS2.EQ.5) LZ = 5
1015              ZZT = Z2 - 1.0 + LOGPOS(LZ)
                  PZT = ZTAN*ZZT + Z0
                  IF (ZZT.GT.Z1) THEN
                    CALL GWIOLINE(PZT,REAL(IYMAX),PZT,REAL(IYMAX-NT),0)
                    CALL GWIOLINE(PZT,REAL(IYMIN),PZT,REAL(IYMIN+NT),0)
                  ENDIF
                  LZ = LZ + NS2
                  IF (LZ.LT.10) GO TO 1015
                  Z1 = Z2
               ENDIF
               NM  = NM + 1
               ZZT = NM*DZ
               GO TO 1010
            ENDIF
            IF (INDS(1).NE.0.AND.NS2.NE.0) THEN
               Z2  = ZZT
               LZ  = 2
               NT  = 4
               IF (NS2.EQ.5) LZ = 5
1017           ZZT = Z2 - 1.0 + LOGPOS(LZ)
               IF (ZZT.LT.ZMAX) THEN
                  PZT = ZTAN*ZZT + Z0
                  IF (ZZT.GT.Z1) THEN
                     CALL GWIOLINE(PZT,REAL(IYMAX),PZT,REAL(IYMAX-NT),0)
                     CALL GWIOLINE(PZT,REAL(IYMIN),PZT,REAL(IYMIN+NT),0)
                  ENDIF
                  LZ = LZ + NS2
                  IF (LZ.LT.10) GO TO 1017
               ENDIF
            ENDIF
          ELSE
            PZ = IXMIN
1020        IF (ZZT.LT.ZMAX) THEN
               PZT = ZTAN*ZZT + Z0
               NT  = 4
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT*2
                  IF (MOD(NM,NSC).EQ.0.AND.IAX.NE.1) THEN
                     IF (IYNUM.EQ.1) THEN
                        IF (INDS(2).EQ.0) THEN
                           WRITE(CH,FORM) ZZT
                           CALL FWNUMBER(PZ,PZT,CH,NMZ,-1,0,-1,0)
                         ELSE
                           CALL LGNUMBER(PZ,PZT,ZZT,NMZ,-1,0,-1)
                        ENDIF
                     ENDIF
                   ELSE IF (NS1.EQ.1) THEN
                     NT = NT*3/4
                  ENDIF
               ENDIF
               CALL GWIOLINE(REAL(IXMAX),PZT,REAL(IXMAX-NT),PZT,0)
               CALL GWIOLINE(REAL(IXMIN),PZT,REAL(IXMIN+NT),PZT,0)
               IF (XX.NE.0) CALL GWIOLINE(XX-NT/2,PZT,XX+NT/2,PZT,0)
               IF (INDS(2).NE.0.AND.NS2.NE.0) THEN
                  Z2  = ZZT
                  LZ  = 2
                  NT  = 4
                  IF (NS2.EQ.5) LZ = 5
1025              ZZT = Z2 - 1.0 + LOGPOS(LZ)
                  PZT = ZTAN*ZZT + Z0
                  IF (ZZT.GT.Z1) THEN
                    CALL GWIOLINE(REAL(IXMAX),PZT,REAL(IXMAX-NT),PZT,0)
                    CALL GWIOLINE(REAL(IXMIN),PZT,REAL(IXMIN+NT),PZT,0)
                  ENDIF
                  LZ = LZ + NS2
                  IF (LZ.LT.10) GO TO 1025
                  Z1 = Z2
               ENDIF
               NM  = NM + 1
               ZZT = NM*DZ
               GO TO 1020
            ENDIF
            IF (INDS(2).NE.0.AND.NS2.NE.0) THEN
               Z2  = ZZT
               LZ  = 2
               NT  = 4
               IF (NS2.EQ.5) LZ = 5
1027           ZZT = Z2 - 1.0 + LOGPOS(LZ)
               IF (ZZT.LT.ZMAX) THEN
                  PZT = ZTAN*ZZT + Z0
                  IF (ZZT.GT.Z1) THEN
                     CALL GWIOLINE(REAL(IXMAX),PZT,REAL(IXMAX-NT),PZT,0)
                     CALL GWIOLINE(REAL(IXMIN),PZT,REAL(IXMIN+NT),PZT,0)
                  ENDIF
                  LZ = LZ + NS2
                  IF (LZ.LT.10) GO TO 1027
               ENDIF
            ENDIF
         ENDIF
  10    CONTINUE

      RETURN
      END

****************************************
*    IND  = 1 ... CONNECTED LINE       *
*           2 ... DOTS                 *
*           3 ... MARKS                *
*           4 ... CONNECTED PAIR DOTS  *
*           5 ... VECTORS              *
*           6 ... SPLINES              *
*           7 ... BAR GRAPH            *
****************************************
      SUBROUTINE FR_GRAPH2D(X,Y,N,ICOL,MODE)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /HISTGRAMCOM/ HIST0,MODHIST
      REAL*8 X(*),Y(*),X1,X2,Y1,Y2,DX,DY
      INTEGER ICOL(*),ICSP(7)

      IF (IGCANVAS.LT.0) RETURN

      IND = MOD(MODE,100)
      M1  = ABS(MODE/100)
      IC  = ICOL(1)
      IC1 = MOD(IC,100)
      IC2 = IC/100
      ICM = 2

      ICOLMODE = 0
      IF (IND.EQ.-3) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC1.GE.0) THEN
               CALL HLSSPHERECOLORSET(ICOL,1)
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC1.GE.0) THEN
            CALL HLSSPHERECOLORSET(ICOL,-1)
         ENDIF
       ELSE IF (IND.EQ.-13) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC1.GE.0) THEN
               DO 1 I = 1, 7
                  ICSP(I) = -1
    1          CONTINUE
               DO 2 I = 1, N
                  IF (ICOL(I).GE.1.AND.ICOL(I).LE.7) ICSP(ICOL(I)) = 1
    2          CONTINUE
               DO 3 I = 1, 7
                  IF (ICSP(I).EQ.1) CALL HLSSPHERECOLORSET(I,1)
    3          CONTINUE
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC1.GE.0) THEN
               DO 4 I = 1, 7
                  ICSP(I) = -1
    4          CONTINUE
               DO 5 I = 1, N
                  IF (ICOL(I).GE.1.AND.ICOL(I).LE.7) ICSP(ICOL(I)) = 1
    5          CONTINUE
               DO 6 I = 1, 7
                  IF (ICSP(I).EQ.1) CALL HLSSPHERECOLORSET(I,-1)
    6          CONTINUE
         ENDIF
       ELSE
         IF (IC.LT.0) THEN
            ICM = 256
            IC0 = -IC - 1
            IC1 = MOD(IC0,1000)
            IC2 = IC0/1000
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
          ELSE
            IC1 = MOD(IC,100)
            IC2 = IC/100
         ENDIF
      ENDIF

      IF (IFRAM.EQ.0) THEN
         IF (M1.EQ.0) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            DO 100 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
  100       CONTINUE
          ELSE IF (M1.EQ.2) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            IF (Y1.GT.Y(2)) Y1 = Y(2)
            IF (Y2.LT.Y(2)) Y2 = Y(2)
            DO 102 I = 2, N
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
  102       CONTINUE
          ELSE
            X1 = X(1)
            X2 = X1
            IF (X1.GT.X(2)) X1 = X(2)
            IF (X2.LT.X(2)) X2 = X(2)
            Y1 = Y(1)
            Y2 = Y1
            DO 101 I = 2, N
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
  101        CONTINUE
         ENDIF
*         IFRAM = 999
         IF (IDFFR2.LT.0) THEN
            IDFR = 0
          ELSE
            IDFR = IDFFR2
         ENDIF
         IF (X1.EQ.X2) THEN
            IF (X1.EQ.0) THEN
               X2 = 1
             ELSE IF (X1.GT.0) THEN
               X1 = 0
             ELSE
               X2 = 0
            ENDIF
          ELSE IF (Y1.EQ.Y2) THEN
            IF (Y1.EQ.0) THEN
               Y2 = 1
             ELSE IF (Y1.GT.0) THEN
               Y1 = 0
             ELSE
               Y2 = 0
            ENDIF
         ENDIF
         CALL FR_FRAME2D(X1,X2,Y1,Y2,IDFR)
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(4,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(N,4)
         IF (M1.EQ.0) THEN
            CALL GSEND8BYTE(X,Y,N,1)
          ELSE IF (M1.EQ.2) THEN
            CALL GSEND8BYTE(Y(1),Y(2),1,0)
            CALL GSEND8BYTE(X,Y,N,5)
          ELSE
            CALL GSEND8BYTE(X(1),X(2),1,0)
            CALL GSEND8BYTE(X,Y,N,6)
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      IF (NSTEP.GT.0) THEN
         NS = NSTEP
         NM = N
       ELSE IF (NSTEP.EQ.0) THEN
         NS = 1
         NM = N
       ELSE
         NS = -NSTEP
         NM = N*NS
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(1)
      CALL GWIOCOLOR(ICM,IC1)

      IF (M1.EQ.0) THEN
         IF (IND.EQ.2) THEN
            DO 20 I = 1, NM, NS
              XX = XTAN*X(I) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOPSET(XX,YY)
   20       CONTINUE
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
            DO 30 I = 1, NM, NS
              XX = XTAN*X(I) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOMARKING(XX,YY,IM)
   30       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 31 I = 1, NM, NS
                 XX = XTAN*X(I) + X0
                 YY = YTAN*Y(I) + Y0
                 CALL GWIOMARKING(XX,YY,0)
   31          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.-3) THEN
            DO 32 I = 1, NM, NS
               XX = XTAN*X(I) + X0
               YY = YTAN*Y(I) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,IC)
   32       CONTINUE
          ELSE IF (IND.EQ.-13) THEN
            DO 33 I = 1, NM, NS
               XX = XTAN*X(I) + X0
               YY = YTAN*Y(I) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,ICOL(I))
   33       CONTINUE
          ELSE IF (IND.EQ.4.OR.IND.EQ.5) THEN
            IF (IND.EQ.4) THEN
              IM = 0
             ELSE
              IM = 3
            ENDIF
            NS = NS + NS
            DO 40 I = 1, NM, NS
              XX  = XTAN*X(I) + X0
              YY  = YTAN*Y(I) + Y0
              XX1 = XTAN*X(I+1) + X0
              YY1 = YTAN*Y(I+1) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
   40       CONTINUE
            IF (IND.EQ.4.AND.IC2.NE.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 41 I = 1, NM, NS
                  XX  = XTAN*X(I) + X0
                  YY  = YTAN*Y(I) + Y0
                  CALL GWIOPSET(XX,YY)
   41          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.6) THEN
            NS = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*X(2)
            DY1 = YTAN*Y(2)
            DO 60 I = NS+1, NM, NS
              XX2 = XTAN*X(I) + X0
              YY2 = YTAN*Y(I) + Y0
              DX2 = XTAN*X(I+1)
              DY2 = YTAN*Y(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX2,YY2,DY2)
              XX1  = XX2
              YY1  = YY2
              DX1  = DX2
              DY1  = DY2
   60       CONTINUE
          ELSE IF (IND.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
            IF (MODHIST.LE.0) THEN
   71          XX  = XTAN*X(1) + X0
               YY  = YTAN*Y(1) + Y0
               YY1 = YTAN*HIST0 + Y0
               DO 70 I = NS+1, NM, NS
                 XX1 = XTAN*X(I) + X0
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                 XX  = XX1
                 YY  = YTAN*Y(I) + Y0
   70          CONTINUE
               IF (IM.EQ.2.AND.IC2.GT.0) THEN
                  IM = 1
                  CALL GWIOCOLOR(ICM,IC2)
                  GO TO 71
               ENDIF
             ELSE
   73          XX  = XTAN*X(1) + X0
               YY  = YTAN*Y(1) + Y0
               XX1 = XTAN*HIST0 + X0
               DO 72 I = NS+1, NM, NS
                 YY1 = YTAN*Y(I) + Y0
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                 XX  = XTAN*X(I) + X0
                 YY  = YY1
   72          CONTINUE
               IF (IM.EQ.2.AND.IC2.GT.0) THEN
                  IM = 1
                  CALL GWIOCOLOR(ICM,IC2)
                  GO TO 73
               ENDIF
            ENDIF
          ELSE IF (IND.EQ.8) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
            IF (MODHIST.LE.0) THEN
               DO 80 I = 1, NM, NS
                  XX  = XTAN*X(I) + X0
                  YY  = YTAN*Y(I) + Y0
                  YY1 = YTAN*HIST0 + Y0
                 CALL GWIOLINE(XX,YY,XX,YY1,0)
   80          CONTINUE
             ELSE
               DO 82 I = 1, NM, NS
                  XX  = XTAN*X(I) + X0
                  YY  = YTAN*Y(I) + Y0
                  XX1 = XTAN*HIST0 + X0
                 CALL GWIOLINE(XX,YY,XX1,YY,0)
   82          CONTINUE
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 10 I = NS+1, NM, NS
              XX1 = XTAN*X(I) + X0
              YY1 = YTAN*Y(I) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
   10       CONTINUE
         ENDIF

       ELSE IF (M1.EQ.2) THEN
         IF (NM.LE.1) THEN
            DY = 1
          ELSE
            DY = (Y(2)-Y(1))/(NM-1)
         ENDIF
         IF (IND.EQ.2) THEN
            DO 220 I = 1, NM, NS
              XX = XTAN*X(I) + X0
              YY = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOPSET(XX,YY)
  220       CONTINUE
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
            DO 230 I = 1, NM, NS
              XX = XTAN*X(I) + X0
              YY = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOMARKING(XX,YY,IM)
  230       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 231 I = 1, NM, NS
                 XX = XTAN*X(I) + X0
                 YY = YTAN*(DY*(I-1)+Y(1)) + Y0
                 CALL GWIOMARKING(XX,YY,0)
  231          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.-3) THEN
            DO 232 I = 1, NM, NS
               XX = XTAN*X(I) + X0
               YY = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,IC)
  232       CONTINUE
          ELSE IF (IND.EQ.-13) THEN
            DO 233 I = 1, NM, NS
               XX = XTAN*X(I) + X0
               YY = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,ICOL(I))
  233       CONTINUE
          ELSE IF (IND.EQ.4.OR.IND.EQ.5) THEN
            IF (IND.EQ.4) THEN
              IM = 0
             ELSE
              IM = 3
            ENDIF
            NS = NS + NS
            DO 240 I = 1, NM, NS
              XX  = XTAN*X(I) + X0
              YY  = YTAN*(DY*(I-1)+Y(1)) + Y0
              XX1 = XTAN*X(I+1) + X0
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  240       CONTINUE
            IF (IND.EQ.4.AND.IC2.NE.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 241 I = 1, NM, NS
                  XX  = XTAN*X(I) + X0
                  YY  = YTAN*(DY*(I-1)+Y(1)) + Y0
                  CALL GWIOPSET(XX,YY)
  241          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.6) THEN
            NS  = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*X(2)
            DY1 = YTAN*DY*2
            DO 260 I = NS+1, NM, NS
              XX2 = XTAN*X(I) + X0
              YY2 = YTAN*(DY*(I-1)+Y(1)) + Y0
              DX2 = XTAN*X(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX2,YY2,DY1)
              XX1  = XX2
              YY1  = YY2
              DX1  = DX2
  260       CONTINUE
          ELSE IF (IND.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
  271       XX  = XTAN*X(1) + X0
            YY  = YTAN*Y(1) + Y0
            XX1 = XTAN*HIST0 + X0
            DO 270 I = NS+1, NM, NS
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
              XX  = XTAN*X(I) + X0
              YY  = YY1
  270       CONTINUE
            IF (IM.EQ.2.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
               GO TO 271
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 210 I = NS+1, NM, NS
              XX1 = XTAN*X(I) + X0
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
  210       CONTINUE
         ENDIF

       ELSE
         IF (NM.LE.1) THEN
            DX = 1
          ELSE
            DX = (X(2)-X(1))/(NM-1)
         ENDIF
         IF (IND.EQ.2) THEN
            DO 120 I = 1, NM, NS
              XX = XTAN*(DX*(I-1)+X(1)) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOPSET(XX,YY)
  120       CONTINUE
          ELSE IF (IND.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
            DO 130 I = 1, NM, NS
              XX = XTAN*(DX*(I-1)+X(1)) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOMARKING(XX,YY,IM)
  130       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 131 I = 1, NM, NS
                 XX = XTAN*(DX*(I-1)+X(1)) + X0
                 YY = YTAN*Y(I) + Y0
                 CALL GWIOMARKING(XX,YY,0)
  131          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.-3) THEN
            DO 132 I = 1, NM, NS
               XX = XTAN*(DX*(I-1)+X(1)) + X0
               YY = YTAN*Y(I) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,IC)
  132       CONTINUE
          ELSE IF (IND.EQ.-13) THEN
            DO 133 I = 1, NM, NS
               XX = XTAN*(DX*(I-1)+X(1)) + X0
               YY = YTAN*Y(I) + Y0
              CALL GWIOGRADCIRCLE(XX,YY,1.0,ICOL(I))
  133       CONTINUE
          ELSE IF (IND.EQ.4.OR.IND.EQ.5) THEN
            IF (IND.EQ.4) THEN
              IM = 0
             ELSE
              IM = 3
            ENDIF
            NS = NS + NS
            DO 140 I = 1, NM, NS
              XX  = XTAN*(DX*(I-1)+X(1)) + X0
              YY  = YTAN*Y(I) + Y0
              XX1 = XTAN*(DX*(I-1)+X(1)) + X0
              YY1 = YTAN*Y(I+1) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  140       CONTINUE
            IF (IND.EQ.4.AND.IC2.NE.0) THEN
               CALL GWIOCOLOR(ICM,IC2)
               DO 141 I = 1, NM, NS
                  XX  = XTAN*(DX*(I-1)+X(1)) + X0
                  YY  = YTAN*Y(I) + Y0
                  CALL GWIOPSET(XX,YY)
  141          CONTINUE
            ENDIF
          ELSE IF (IND.EQ.6) THEN
            NS  = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*DX*2
            DY1 = YTAN*Y(2)
            DO 160 I = NS+1, NM, NS
              XX2 = XTAN*(DX*(I-1)+X(1)) + X0
              YY2 = YTAN*Y(I) + Y0
              DY2 = YTAN*Y(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX1,YY2,DY2)
              XX1  = XX2
              YY1  = YY2
              DY1  = DY2
  160       CONTINUE
          ELSE IF (IND.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
            ENDIF
  171       XX  = XTAN*X(1) + X0
            YY  = YTAN*Y(1) + Y0
            YY1 = YTAN*HIST0 + Y0
            DO 170 I = NS+1, NM, NS
              XX1 = XTAN*(DX*(I-1)+X(1)) + X0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
              XX  = XX1
              YY  = YTAN*Y(I) + Y0
  170       CONTINUE
            IF (IM.EQ.2.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(ICM,IC2)
               GO TO 171
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 110 I = NS+1, NM, NS
              XX1 = XTAN*(DX*(I-1)+X(1)) + X0
              YY1 = YTAN*Y(I) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
  110       CONTINUE
         ENDIF
      ENDIF

      CALL GWIOBDFLUSH(1)
  999 IF (ICOLMODE.NE.0) CALL HLSSPHERECOLORSET(IC,0)
      RETURN
      END

      SUBROUTINE FR_DRAW2D(X,Y,IC,IND)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 X,Y

      IF (IGCANVAS.LT.0) RETURN

      ICM      = 2
      IC1      = IC
      ICOLMODE = 0
      IF (IND.EQ.-3) THEN
         IF (ICOL256.GE.0) THEN
            IF (IC.GE.0) THEN
               CALL HLSSPHERECOLORSET(IC,1)
               ICOLMODE = 2
             ELSE
               IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
            ENDIF
          ELSE IF (IC.GE.0) THEN
            CALL HLSSPHERECOLORSET(IC,-1)
         ENDIF
       ELSE IF (IC.LT.0) THEN
         ICM = 256
         IC1 = -IC - 1
         IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      ENDIF
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(5,1)
         CALL GSENDBYTE(IND,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X,Y,1,1)
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      IF (IND.EQ.-3) CALL GWIOSETAASPACE(1)
      CALL GWIOCOLOR(ICM,IC1)

      IF (IND.EQ.0) THEN
         PX = XTAN*X + X0
         PY = YTAN*Y + Y0
       ELSE IF (IND.EQ.2) THEN
         PX = XTAN*X + X0
         PY = YTAN*Y + Y0
         CALL GWIOPSET(PX,PY)
       ELSE IF (IND.EQ.3) THEN
         PX   = XTAN*X + X0
         PY   = YTAN*Y + Y0
         CALL GWIOMARKING(PX,PY,1)
       ELSE IF (IND.EQ.-3) THEN
         PX   = XTAN*X + X0
         PY   = YTAN*Y + Y0
         CALL GWIOGRADCIRCLE(PX,PY,1.0,IC)
       ELSE IF (IND.EQ.5) THEN
         PX1 = XTAN*X + X0
         PY1 = YTAN*Y + Y0
         CALL GWIOLINE(PX,PY,PX1,PY1,3)
         PX  = PX1
         PY  = PY1
       ELSE IF (IND.EQ.6) THEN
         PX1 = XTAN*X + X0
         PY1 = YTAN*Y + Y0
         CALL GWIOLINE(PX,PY,PX1,PY1,1)
         PX  = PX1
         PY  = PY1
       ELSE IF (IND.EQ.7) THEN
         PX1 = XTAN*X + X0
         PY1 = YTAN*Y + Y0
         CALL GWIOLINE(PX,PY,PX1,PY1,2)
         PX  = PX1
         PY  = PY1
       ELSE
         PX1 = XTAN*X + X0
         PY1 = YTAN*Y + Y0
         CALL GWIOLINE(PX,PY,PX1,PY1,0)
         PX  = PX1
         PY  = PY1
      ENDIF

      CALL GWIOBDFLUSH(0)
  999 IF (ICOLMODE.NE.0) CALL HLSSPHERECOLORSET(IC,0)
      RETURN
      END

      SUBROUTINE FR_VECTOR2D(X,Y,DX,DY,IC,IND)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      REAL*8 X,Y,DX,DY
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(6,1)
         CALL GSENDBYTE(IND,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X,Y,1,1)
         CALL GSEND8BYTE(DX,DY,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(2,IC)

      PX  = XTAN*X + X0
      PY  = YTAN*Y + Y0
      IF (IND.EQ.0) THEN
         PX1 = XTAN*(X+DX) + X0
         PY1 = YTAN*(Y+DY) + Y0
       ELSE IF (IND.EQ.1) THEN
         PX1 = XTAN*DX + X0
         PY1 = YTAN*DY + Y0
       ELSE IF (IND.EQ.2) THEN
         PX1 = XTAN*X + X0 + DX
         PY1 = YTAN*Y + Y0 - DY
       ELSE IF (IND.EQ.3) THEN
         PX1 = XTAN*X + X0 + DX
         PY1 = YTAN*(Y+DY/XTAN) + Y0
      ENDIF

      CALL GWIOLINE(PX,PY,PX1,PY1,3)

      CALL GWIOBDFLUSH(0)
      RETURN
      END
