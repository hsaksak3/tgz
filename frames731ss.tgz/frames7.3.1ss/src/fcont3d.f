*****************************************
*         F  R  A  M  E  S  V.7         *
*   3D  CONTOUR  DRAWING  SUBROUTINE    *
*        PROGRAMMED BY T.TAGUCHI        *
*****************************************

      SUBROUTINE FR_CONTOUR3D(F,IMAX,JMAX,KMAX,TD0,ND0,ICOL,MODE)
      REAL*8 F(IMAX,JMAX,KMAX),TD0(*),TD1(3)
      INTEGER NSU(3)
*     M1=0  MIN(IMAX�CJMAX�CKMAX)
*     M1=1  X=T
*     M1=2  Y=T
*     M1=3  Z=T

      M1  = MOD(MODE,10)
      NS1 = MODE/100
      IF (NS1.EQ.0) NS1 = 1
      ID0 = 0
      IF (M1.EQ.0) THEN
         MM  = MIN(IMAX,JMAX,KMAX)
         IF (IMAX.EQ.MM) THEN
            M1  = 1
            IF (IMAX.EQ.1) ID0 = ID0 + 1
         ENDIF
         IF (JMAX.EQ.MM) THEN
            M1  = 2
            IF (JMAX.EQ.1) ID0 = ID0 + 1
         ENDIF
         IF (KMAX.EQ.MM) THEN
            M1  = 3
            IF (KMAX.EQ.1) ID0 = ID0 + 1
         ENDIF
       ELSE
         IF (IMAX.EQ.1) THEN
            ID0 = ID0 + 1
         ENDIF
         IF (JMAX.EQ.1) THEN
            ID0 = ID0 + 1
         ENDIF
         IF (KMAX.EQ.1) THEN
            ID0 = ID0 + 1
         ENDIF
      ENDIF

      IF (ID0.GT.1.OR.IMAX.LT.1.OR.JMAX.LT.1.OR.KMAX.LT.1) THEN
         CALL FRAMESERROR('3D CONTOUR PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (M1.EQ.1) THEN
         TD1(1) = TD0(1)
         NSU(1) = NS1
         NSU(2) = 0
         NSU(3) = 0
       ELSE IF (M1.EQ.2) THEN
         TD1(2) = TD0(1)
         NSU(1) = 0
         NSU(2) = NS1
         NSU(3) = 0
       ELSE IF (M1.EQ.3) THEN
         TD1(3) = TD0(1)
         NSU(1) = 0
         NSU(2) = 0
         NSU(3) = NS1
       ELSE IF (M1.EQ.4) THEN
         TD1(1) = TD0(1)
         TD1(2) = TD0(2)
         TD1(3) = TD0(3)
         NSU(1) = 1
         NSU(2) = 1
         NSU(3) = 1
      ENDIF

      MODE1 = MOD(MODE,100)/10
      CALL FR_SLICES(F,IMAX,JMAX,KMAX,TD1,NSU,ND0,ICOL,MODE1)

      RETURN
      END

      SUBROUTINE FR_SLICES(F,IMAX,JMAX,KMAX,TD0,NSU0,ND0,ICOL,MODE)
      REAL*8 F(IMAX,JMAX,KMAX),TD0(*)
      INTEGER NSU0(*)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      COMMON /CONTOUR3DMULT/ NCRX,NDTX,NX1,NX2,INX1,INX2,NCRY,NDTY
     +                 ,NY1,NY2,INY1,INY2,NCRZ,NDTZ,NZ1,NZ2,INZ1,INZ2
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 T0,TD,TDSX,TDSY,TDSZ

      IF (IGCANVAS.LT.0) RETURN

      ID0 = 0
      IF (IMAX.EQ.1) THEN
         ID0   = ID0 + 1
      ENDIF
      IF (JMAX.EQ.1) THEN
         ID0   = ID0 + 1
      ENDIF
      IF (KMAX.EQ.1) THEN
         ID0   = ID0 + 1
      ENDIF

      IDS = 0
      IF (NSU0(1).EQ.0.AND.NSU0(2).EQ.0) THEN
         IF (IMAX.EQ.1.OR.JMAX.EQ.1) ID0 = 2
         IDIM = 3
         TD   = TD0(3)
         NSU  = NSU0(3)
       ELSE IF (NSU0(3).EQ.0.AND.NSU0(1).EQ.0) THEN
         IF (KMAX.EQ.1.OR.IMAX.EQ.1) ID0 = 2
         IDIM = 2
         TD   = TD0(2)
         NSU  = NSU0(2)
       ELSE IF (NSU0(2).EQ.0.AND.NSU0(3).EQ.0) THEN
         IF (JMAX.EQ.1.OR.KMAX.EQ.1) ID0 = 2
         IDIM = 1
         TD   = TD0(1)
         NSU  = NSU0(1)
       ELSE
         IDS  = 1
         IDIM = 0
      ENDIF

      IF (ID0.GT.1.OR.IMAX.LT.1.OR.JMAX.LT.1.OR.KMAX.LT.1) THEN
         CALL FRAMESERROR
     +              ('3D SLICES PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IDM0 = IDIM
      IF (ID0.EQ.0) THEN
         IDM  = IDM0
         IDIM = IDM+3
       ELSE
         IDM = IDIM
      ENDIF

      IMN   = MOD(MODE,10)
*      IMN   = MOD(MODE/10,10)
*      IMN  = MOD(MODE,10)
*      IMNX = 0
*      IMNY = 0
*      IMNZ = 0
*      IF (MOD(IMN,2).EQ.1) IMNX = 1
*      IF (MOD(IMN/2,2).EQ.1) IMNY = 1
*      IF (IMN.GE.4) IMNZ = 1
      MODE1 = MODE

      IF (ICNREG.GE.2) THEN
         IF (IMN.EQ.0) IMN = 2
         MODE1 = IDM0+IMN*10
      ENDIF
      IMNX  = IMN
      IMNY  = IMN
      IMNZ  = IMN

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - CONTOUR3D')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - CONTOUR3D')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      IF (NZDMIN.GT.0) THEN
         NZ1 = NZDMIN - 1
         NZ2 = NZDMAX - 1
         IF (NZ1.GE.KMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF K REGION - CONTOUR3D')
            RETURN
         ENDIF
         IF (NZ2.GE.KMAX) NZ2 = KMAX - 1
       ELSE
         NZ1 = 0
         NZ2 = KMAX - 1
      ENDIF

      IF (ICNREG.EQ.0) THEN
         IF (NX1.GE.NX2) THEN
            CNXMIN = XMIN
            CNXMAX = XMAX
          ELSE
            CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (NY1.GE.NY2) THEN
            CNYMIN = YMIN
            CNYMAX = YMAX
          ELSE
            CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
         IF (NZ1.GE.NZ2) THEN
            CNZMIN = ZMIN
            CNZMAX = ZMAX
          ELSE
            CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
            CNZMAX = ((KMAX-1)*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
         ENDIF
       ELSE IF (ICNREG.GT.2) THEN
         ICN = ICNREG-2
         IF (IAND(ICN,1).NE.0) THEN
           IF (NX1.GE.NX2) THEN
             CNXMIN = XMIN
             CNXMAX = XMAX
           ELSE
             CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
             CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
          ENDIF
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
           IF (NY1.GE.NY2) THEN
             CNYMIN = YMIN
             CNYMAX = YMAX
           ELSE
             CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
             CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
           ENDIF
         ENDIF
         IF (IAND(ICN,4).NE.0) THEN
           IF (NZ1.GE.NZ2) THEN
             CNZMIN = ZMIN
             CNZMAX = ZMAX
           ELSE
             CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
             CNZMAX = ((KMAX-1)*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
           ENDIF
         ENDIF
      ENDIF

      IF (ICOL.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP

      FM1 = F(1,1,1)
      FM2 = FM1
      DO 10 K = 1, KMAX
        DO 11 J = 1, JMAX
          DO 12 I = 1, IMAX
             IF (F(I,J,K).LT.FM1) FM1 = F(I,J,K)
             IF (F(I,J,K).GT.FM2) FM2 = F(I,J,K)
   12     CONTINUE
   11     CONTINUE
   10     CONTINUE

      ND  = ND0
      IF (IGPLT.GT.0) THEN
         IF (IFCONT.EQ.0) CALL FR_SETCONTOUR(0.D0,0.D0,-1)
         CALL GSENDBYTE(70,1)
         CALL GSENDBYTE(MODE1,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(ND,2)
         CALL GSENDBYTE(NSU0(1),2)
         CALL GSENDBYTE(NSU0(2),2)
         CALL GSENDBYTE(NSU0(3),2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSENDBYTE(KMAX,4)
         CALL GSEND8BYTE(DBLE(CNXMIN),DBLE(CNXMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNYMIN),DBLE(CNYMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNZMIN),DBLE(CNZMAX),1,0)
         CALL GSEND8BYTE(TD0(1),TD0(1),1,-1)
         CALL GSEND8BYTE(TD0(2),TD0(2),1,-1)
         CALL GSEND8BYTE(TD0(3),TD0(3),1,-1)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX*KMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (ICOL.EQ.0) RETURN

      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR CONTOUR3D')
         RETURN
      ENDIF

      IF (IFRAM.EQ.0) THEN
         CALL FRAMESERROR('CALL FRAME3D BEFORE CALLING CONTOUR3D')
         RETURN
      ENDIF

      IF (IDM.EQ.1) THEN
         NNX1    = NY1
         NNX2    = NY2
         NNY1    = NZ1
         NNY2    = NZ2
       ELSE IF (IDM.EQ.2) THEN
         NNX1    = NX1
         NNX2    = NX2
         NNY1    = NZ1
         NNY2    = NZ2
       ELSE
         NNX1    = NX1
         NNX2    = NX2
         NNY1    = NY1
         NNY2    = NY2
      ENDIF

*     FOR THREE SURFACES IN DIFFERENT DIRECTIONS
      IF (IDS.NE.0) THEN
         ICMOD = 1
*        FIRST, NEED TO CHECK SCALES
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,TD,-1,ND,ICOL,-1)

         NSUX = NSU0(1)
         IF (NSUX.EQ.0) THEN
            INX1 = 0
            INX2 = -1
            NCRX = 0
            NDTX = 1
          ELSE
            IF (NSUX.GT.0) THEN
               IF (IMNX.EQ.0) THEN
                  TDSX = TD0(1)
                  DTX = (XMAX-XMIN)/NSUX
                ELSE IF (IMNX.EQ.1) THEN
                  TDSX = (XMAX-XMIN)*TD0(1)+XMIN
                  DTX = (XMAX-XMIN)/NSUX
                ELSE
                  TDSX = TD0(1)
                  DTX = (CNXMAX-CNXMIN)/NSUX
               ENDIF
             ELSE
               IF (IMNX.EQ.0) THEN
                  TDSX = TD0(1)
                  DTX  = TD0(4)
                ELSE IF (IMNX.EQ.1) THEN
                  TDSX = (XMAX-XMIN)*TD0(1)+XMIN
                  DTX  = TD0(4)
                ELSE
                  TDSX = TD0(1)
                  DTX  = TD0(4)
               ENDIF
            ENDIF
            NCRX  = (TDSX-CNXMIN)*(IMAX-1)/(CNXMAX-CNXMIN)+0.5
            NDTX  = ABS(DTX*(IMAX-1)/(CNXMAX-CNXMIN))+0.5
*            NDTX  = ABS(DTX*(IMAX+1)/(CNXMAX-CNXMIN))+0.5
            IF (NDTX.LT.1) NDTX = 1
            IF (NX1.LE.NCRX) THEN
               INX1  = (NX1-NCRX)/NDTX
             ELSE
               INX1  = (NX1-NCRX-(NX1-NCRX)*NDTX)/NDTX+NX1-NCRX
            ENDIF
            IF (NX2.GE.NCRX) THEN
               INX2  = (NX2-NCRX)/NDTX
             ELSE
               INX2  = (NX2-NCRX-(NX2-NCRX)*NDTX)/NDTX+NX2-NCRX
            ENDIF
            IF (INX2-INX1+1.GT.NSUX) THEN
               IF (INX2.EQ.NCRX) THEN
                  INX1 = INX1+1
                ELSE
                  INX2 = INX2-1
               ENDIF
            ENDIF
            INX1  = INX1*NDTX+NCRX
            INX2  = INX2*NDTX+NCRX
         ENDIF

         NSUY = NSU0(2)
         IF (NSUY.EQ.0) THEN
            INY1 = 0
            INY2 = -1
            NCRY = 0
            NDTY = 1
          ELSE
            IF (NSUY.GT.0) THEN
               IF (IMNY.EQ.0) THEN
                  TDSY = TD0(2)
                  DTY = (YMAX-YMIN)/NSUY
                ELSE IF (IMNY.EQ.1) THEN
                  TDSY = (YMAX-YMIN)*TD0(2)+YMIN
                  DTY = (YMAX-YMIN)/NSUY
                ELSE
                  TDSY = TD0(2)
                  DTY = (CNYMAX-CNYMIN)/NSUY
               ENDIF
             ELSE
               IF (IMNY.EQ.0) THEN
                  TDSY = TD0(2)
                  DTY  = TD0(5)
                ELSE IF (IMNY.EQ.1) THEN
                  TDSY = (YMAX-YMIN)*TD0(2)+YMIN
                  DTY  = TD0(5)
                ELSE
                  TDSY = TD0(2)
                  DTY  = TD0(5)
               ENDIF
            ENDIF
            NCRY  = (TDSY-CNYMIN)*(JMAX-1)/(CNYMAX-CNYMIN)+0.5
            NDTY  = ABS(DTY*(JMAX-1)/(CNYMAX-CNYMIN))+0.5
*            NDTY  = ABS(DTY*(JMAX+1)/(CNYMAX-CNYMIN))+0.5
            IF (NDTY.LT.1) NDTY = 1
            IF (NY1.LE.NCRY) THEN
               INY1  = (NY1-NCRY)/NDTY
             ELSE
               INY1  = (NY1-NCRY-(NY1-NCRY)*NDTY)/NDTY+NY1-NCRY
            ENDIF
            IF (NY2.GE.NCRY) THEN
               INY2  = (NY2-NCRY)/NDTY
             ELSE
               INY2  = (NY2-NCRY-(NY2-NCRY)*NDTY)/NDTY+NY2-NCRY
            ENDIF
            IF (INY2-INY1+1.GT.NSUY) THEN
               IF (INY2.EQ.NCRY) THEN
                  INY1 = INY1+1
                ELSE
                  INY2 = INY2-1
               ENDIF
            ENDIF
            INY1  = INY1*NDTY+NCRY
            INY2  = INY2*NDTY+NCRY
         ENDIF

         NSUZ = NSU0(3)
         IF (NSUZ.EQ.0) THEN
            INZ1 = 0
            INZ2 = -1
            NCRZ = 0
            NDTZ = 1
          ELSE
            IF (NSUZ.GT.0) THEN
               IF (IMNZ.EQ.0) THEN
                  TDSZ = TD0(3)
                  DTZ = (ZMAX-ZMIN)/NSUZ
                ELSE IF (IMNZ.EQ.1) THEN
                  TDSZ = (ZMAX-ZMIN)*TD0(3)+ZMIN
                  DTZ = (ZMAX-ZMIN)/NSUZ
                ELSE
                  TDSZ = TD0(3)
                  DTZ = (CNZMAX-CNZMIN)/NSUZ
               ENDIF
             ELSE
               IF (IMNZ.EQ.0) THEN
                  TDSZ = TD0(3)
                  DTZ  = TD0(6)
                ELSE IF (IMNZ.EQ.1) THEN
                  TDSZ = (ZMAX-ZMIN)*TD0(3)+ZMIN
                  DTZ  = TD0(6)
                ELSE
                  TDSZ = TD0(3)
                  DTZ  = TD0(6)
               ENDIF
            ENDIF
            NCRZ  = (TDSZ-CNZMIN)*(KMAX-1)/(CNZMAX-CNZMIN)+0.5
            NDTZ  = ABS(DTZ*(KMAX-1)/(CNZMAX-CNZMIN))+0.5
*            NDTZ  = ABS(DTZ*(KMAX+1)/(CNZMAX-CNZMIN))+0.5
            IF (NDTZ.LT.1) NDTZ = 1
            IF (NZ1.LE.NCRZ) THEN
               INZ1  = (NZ1-NCRZ)/NDTZ
             ELSE
               INZ1  = (NZ1-NCRZ-(NZ1-NCRZ)*NDTZ)/NDTZ+NZ1-NCRZ
            ENDIF
            IF (NZ2.GE.NCRZ) THEN
               INZ2  = (NZ2-NCRZ)/NDTZ
             ELSE
               INZ2  = (NZ2-NCRZ-(NZ2-NCRZ)*NDTZ)/NDTZ+NZ2-NCRZ
            ENDIF
            IF (INZ2-INZ1+1.GT.NSUZ) THEN
               IF (INZ2.EQ.NCRZ) THEN
                  INZ1 = INZ1+1
                ELSE
                  INZ2 = INZ2-1
               ENDIF
            ENDIF
            INZ1  = INZ1*NDTZ+NCRZ
            INZ2  = INZ2*NDTZ+NCRZ
         ENDIF

         CALL MULTIPLESLICES(F,IMAX,JMAX,KMAX,ND,ICOL)

*     SEVERAL SURFACES IN ONE DIRECTION
       ELSE IF (NSU.GT.0.AND.IDIM.GT.3) THEN
         ICMOD = 1
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,TD,-1,ND,ICOL,IDIM)
         IF (IDM.EQ.1) THEN
            Z1 = ZPX*XMIN + ZPY*YMIN + ZPZ*ZMIN
            Z2 = ZPX*XMAX + ZPY*YMIN + ZPZ*ZMIN
            IF (IMNX.EQ.0) THEN
               DT = (XMAX-XMIN)/NSU
               I1 = (XMIN-TD)/DT-1
               I2 = (XMAX-TD)/DT+1
             ELSE IF (IMNX.EQ.1) THEN
               DT = 1.0/NSU
               I1 = -TD/DT-1
               I2 = (1-TD)/DT+1
             ELSE
               DT = (CNXMAX-CNXMIN)/NSU
               I1 = (CNXMIN-TD)/DT-1
               I2 = (CNXMAX-TD)/DT+1
            ENDIF
          ELSE IF (IDM.EQ.2) THEN
            Z1 = ZPX*XMIN + ZPY*YMIN + ZPZ*ZMIN
            Z2 = ZPX*XMIN + ZPY*YMAX + ZPZ*ZMIN
            IF (IMNY.EQ.0) THEN
               DT = (YMAX-YMIN)/NSU
               I1 = (YMIN-TD)/DT-1
               I2 = (YMAX-TD)/DT+1
             ELSE IF (IMNY.EQ.1) THEN
               DT = 1.0/NSU
               I1 = -TD/DT-1
               I2 = (1-TD)/DT+1
             ELSE
               DT = (CNYMAX-CNYMIN)/NSU
               I1 = (CNYMIN-TD)/DT-1
               I2 = (CNYMAX-TD)/DT+1
            ENDIF
          ELSE
            Z1 = ZPX*XMIN + ZPY*YMIN + ZPZ*ZMIN
            Z2 = ZPX*XMIN + ZPY*YMIN + ZPZ*ZMAX
            IF (IMNZ.EQ.0) THEN
               DT = (ZMAX-ZMIN)/NSU
               I1 = (ZMIN-TD)/DT-1
               I2 = (ZMAX-TD)/DT+1
             ELSE IF (IMNZ.EQ.1) THEN
               DT = 1.0/NSU
               I1 = -TD/DT-1
               I2 = (1-TD)/DT+1
             ELSE
               DT = (CNZMAX-CNZMIN)/NSU
               I1 = (CNZMIN-TD)/DT-1
               I2 = (CNZMAX-TD)/DT+1
            ENDIF
         ENDIF
         IF (Z2.GE.Z1) THEN
            DO I = I1, I2
               T0 = DT*I + TD
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,-1,ND,ICOL,IDIM)
            ENDDO
          ELSE
            DO I = I2, I1, -1
               T0 = DT*I + TD
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,-1,ND,ICOL,IDIM)
            ENDDO
         ENDIF

*     ONLY ONE SURFACE
       ELSE
         ICMOD = 0
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,TD,-1,ND,ICOL,IDIM)
      ENDIF

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      RETURN
      END

      SUBROUTINE MULTIPLESLICES(F,IMAX,JMAX,KMAX,ND,ICOL)
      REAL*8 F(IMAX,JMAX,KMAX)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      COMMON /CONTOUR3DMULT/ NCRX,NDTX,NX1,NX2,INX1,INX2,NCRY,NDTY
     +                 ,NY1,NY2,INY1,INY2,NCRZ,NDTZ,NZ1,NZ2,INZ1,INZ2
      INTEGER DI,DJ,DK

      T0  = 0
*      IDX = 0
      IDM = 1
      JDM = 2
      KDM = 3
      IF (MOD3DIR.EQ.1) THEN
         IF (PHI.GT.-90.0.AND.PHI.LT.90.0) THEN
            JM1 = NY1
            JM2 = NY2
            J1  = INY1
            J2  = INY2
            DJ  = NDTY
          ELSE
            JM1 = NY2
            JM2 = NY1
            J1  = INY2
            J2  = INY1
            DJ  = -NDTY
         ENDIF
         IF (INY2.LT.0) THEN
            J1  = JM2
            J2  = JM1
            JDM = -2
         ENDIF
         IF (PHI.GE.0.0.AND.PHI.LT.180.0) THEN
            KM1 = NZ1
            KM2 = NZ2
            K1  = INZ1
            K2  = INZ2
            DK  = NDTZ
          ELSE
            KM1 = NZ2
            KM2 = NZ1
            K1  = INZ2
            K2  = INZ1
            DK  = -NDTZ
         ENDIF
         IF (INZ2.LT.0) THEN
            K1  = KM2
            K2  = KM1
            KDM = -3
         ENDIF
         IF (THETA.GE.0.0) THEN
            IM1 = NX1
            IM2 = NX2
            I1  = INX1
            I2  = INX2
            DI  = NDTX
          ELSE
            IM1 = NX2
            IM2 = NX1
            I1  = INX2
            I2  = INX1
            DI  = -NDTX
         ENDIF
         IF (INX2.LT.0) THEN
            I1  = IM2
            I2  = IM1
            IDM = -1
         ENDIF
       ELSE IF (MOD3DIR.EQ.2) THEN
         IF (PHI.GT.-90.0.AND.PHI.LT.90.0) THEN
            KM1 = NZ1
            KM2 = NZ2
            K1  = INZ1
            K2  = INZ2
            DK  = NDTZ
          ELSE
            KM1 = NZ2
            KM2 = NZ1
            K1  = INZ2
            K2  = INZ1
            DK  = -NDTZ
         ENDIF
         IF (INZ2.LT.0) THEN
            K1  = KM2
            K2  = KM1
            KDM = -3
         ENDIF
         IF (PHI.GE.0.0.AND.PHI.LT.180.0) THEN
            IM1 = NX1
            IM2 = NX2
            I1  = INX1
            I2  = INX2
            DI  = NDTX
          ELSE
            IM1 = NX2
            IM2 = NX1
            I1  = INX2
            I2  = INX1
            DI  = -NDTX
         ENDIF
         IF (INX2.LT.0) THEN
            I1  = IM2
            I2  = IM1
            IDM = -1
         ENDIF
         IF (THETA.GE.0.0) THEN
            JM1 = NY1
            JM2 = NY2
            J1  = INY1
            J2  = INY2
            DJ  = NDTY
          ELSE
            JM1 = NY2
            JM2 = NY1
            J1  = INY2
            J2  = INY1
            DJ  = -NDTY
         ENDIF
         IF (INY2.LT.0) THEN
            J1  = JM2
            J2  = JM1
            JDM = -2
         ENDIF
       ELSE
         IF (PHI.GT.-90.0.AND.PHI.LT.90.0) THEN
            IM1 = NX1
            IM2 = NX2
            I1  = INX1
            I2  = INX2
            DI  = NDTX
          ELSE
            IM1 = NX2
            IM2 = NX1
            I1  = INX2
            I2  = INX1
            DI  = -NDTX
         ENDIF
         IF (INX2.LT.0) THEN
            I1  = IM2
            I2  = IM1
            IDM = -1
         ENDIF
         IF (PHI.GE.0.0.AND.PHI.LT.180.0) THEN
            JM1 = NY1
            JM2 = NY2
            J1  = INY1
            J2  = INY2
            DJ  = NDTY
          ELSE
            JM1 = NY2
            JM2 = NY1
            J1  = INY2
            J2  = INY1
            DJ  = -NDTY
         ENDIF
         IF (INY2.LT.0) THEN
            J1  = JM2
            J2  = JM1
            JDM = -2
         ENDIF
         IF (THETA.GE.0.0) THEN
            KM1 = NZ1
            KM2 = NZ2
            K1  = INZ1
            K2  = INZ2
            DK  = NDTZ
          ELSE
            KM1 = NZ2
            KM2 = NZ1
            K1  = INZ2
            K2  = INZ1
            DK  = -NDTZ
         ENDIF
         IF (INZ2.LT.0) THEN
            K1  = KM2
            K2  = KM1
            KDM = -3
         ENDIF
      ENDIF

      IMM = -1
      JMM = -1
      KMM = -1
      IF (MDPROJ.NE.0) THEN
         IF (IDM.GT.0) THEN
            CALL COORDINIJK(IM1,0     ,0     ,XXP0,YYP0)
            CALL COORDINIJK(IM1,JMAX-1,0     ,XXP1,YYP1)
            CALL COORDINIJK(IM1,0     ,KMAX-1,XXP2,YYP2)
            DYZ1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            CALL COORDINIJK(IM2,0     ,0     ,XXP0,YYP0)
            CALL COORDINIJK(IM2,JMAX-1,0     ,XXP1,YYP1)
            CALL COORDINIJK(IM2,0     ,KMAX-1,XXP2,YYP2)
            DYZ2 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            IF (DYZ1*DYZ2.LT.0) THEN
               DO IA = I2, I1, -DI
                  CALL COORDINIJK(IA,0     ,0     ,XXP0,YYP0)
                  CALL COORDINIJK(IA,JMAX-1,0     ,XXP1,YYP1)
                  CALL COORDINIJK(IA,0     ,KMAX-1,XXP2,YYP2)
                  DYZ1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
                  IF (DYZ1*DYZ2.LE.0) GO TO 10
               ENDDO
               IA  = IM1
   10          IMM = IA
            ENDIF
         ENDIF

         IF (JDM.GT.0) THEN
            CALL COORDINIJK(0     ,JM1,0     ,XXP0,YYP0)
            CALL COORDINIJK(0     ,JM1,KMAX-1,XXP1,YYP1)
            CALL COORDINIJK(IMAX-1,JM1,0     ,XXP2,YYP2)
            DZX1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            CALL COORDINIJK(0     ,JM2,0     ,XXP0,YYP0)
            CALL COORDINIJK(0     ,JM2,KMAX-1,XXP1,YYP1)
            CALL COORDINIJK(IMAX-1,JM2,0     ,XXP2,YYP2)
            DZX2 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            IF (DZX1*DZX2.LT.0) THEN
               DO JA = J2, J1, -DJ
                  CALL COORDINIJK(0     ,JA,0     ,XXP0,YYP0)
                  CALL COORDINIJK(0     ,JA,KMAX-1,XXP1,YYP1)
                  CALL COORDINIJK(IMAX-1,JA,0     ,XXP2,YYP2)
                  DZX1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
                  IF (DZX1*DZX2.LE.0) GO TO 20
               ENDDO
               JA  = JM1
   20          JMM = JA
            ENDIF
         ENDIF

         IF (KDM.GT.0) THEN
            CALL COORDINIJK(0     ,0     ,KM1,XXP0,YYP0)
            CALL COORDINIJK(IMAX-1,0     ,KM1,XXP1,YYP1)
            CALL COORDINIJK(0     ,JMAX-1,KM1,XXP2,YYP2)
            DXY1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            CALL COORDINIJK(0     ,0     ,KM2,XXP0,YYP0)
            CALL COORDINIJK(IMAX-1,0     ,KM2,XXP1,YYP1)
            CALL COORDINIJK(0     ,JMAX-1,KM2,XXP2,YYP2)
            DXY2 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
            IF (DXY1*DXY2.LT.0) THEN
               DO KA = K2, K1, -DK
                  CALL COORDINIJK(0     ,0     ,KA,XXP0,YYP0)
                  CALL COORDINIJK(IMAX-1,0     ,KA,XXP1,YYP1)
                  CALL COORDINIJK(0     ,JMAX-1,KA,XXP2,YYP2)
                  DXY1 = (XXP2-XXP0)*(YYP1-YYP0)-(XXP1-XXP0)*(YYP2-YYP0)
                  IF (DXY1*DXY2.LE.0) GO TO 30
               ENDDO
               KA  = KM1
   30          KMM = KA
            ENDIF
         ENDIF
      ENDIF

      NPH = (PHI+225)/90
      PPH = PHI+180-NPH*90
*      write(*,*) phi-nph*90+180,theta
      IF (MOD3DIR.EQ.1) THEN
         LSW = IM1
         IM1 = JM1
         JM1 = KM1
         KM1 = LSW
         LSW = IM2
         IM2 = JM2
         JM2 = KM2
         KM2 = LSW
         LSW = I1
         I1  = J1
         J1  = K1
         K1  = LSW
         LSW = I2
         I2  = J2
         J2  = K2
         K2  = LSW
         LSW = DI
         DI  = DJ
         DJ  = DK
         DK  = LSW
         LSW = IMM
         IMM = JMM
         JMM = KMM
         KMM = LSW
         LSW = IDM
         IDM = JDM
         JDM = KDM
         KDM = LSW
       ELSE IF (MOD3DIR.EQ.2) THEN
         LSW = IM1
         IM1 = KM1
         KM1 = JM1
         JM1 = LSW
         LSW = IM2
         IM2 = KM2
         KM2 = JM2
         JM2 = LSW
         LSW = I1
         I1  = K1
         K1  = J1
         J1  = LSW
         LSW = I2
         I2  = K2
         K2  = J2
         J2  = LSW
         LSW = DI
         DI  = DK
         DK  = DJ
         DJ  = LSW
         LSW = IMM
         IMM = KMM
         KMM = JMM
         JMM = LSW
         LSW = IDM
         IDM = KDM
         KDM = JDM
         JDM = LSW
      ENDIF
      IF (THETA.GE.-45.0.AND.THETA.LE.45.0) THEN
         IF (ABS(THETA).GE.ABS(PPH)) THEN
            IF (MOD(NPH,2).EQ.0) THEN
               CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM )
             ELSE
               CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM )
            ENDIF
          ELSE
            IF (MOD(NPH,2).EQ.0) THEN
               CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM )
             ELSE
               CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM )
            ENDIF
         ENDIF
       ELSE
         IF (MOD(NPH,2).EQ.0) THEN
            CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM )
        ELSE
            CALL MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,                              ,JM1,JM2,J1,J2,DJ,JMM,JDM
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM
     ,                              ,KM1,KM2,K1,K2,DK,KMM,KDM )
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE MULTIPLEMAINSLICES(F,IMAX,JMAX,KMAX,ND,ICOL
     ,               ,KM1,KM2,K1,K2,DK,KMM,KDM,JM1,JM2,J1,J2,DJ,JMM,JDM
     ,                              ,IM1,IM2,I1,I2,DI,IMM,IDM)
      REAL*8 F(IMAX,JMAX,KMAX)
      REAL*8 T0
      INTEGER DK,DJ,DI

*      write(*,*) imm,jmm,kmm
*     FIRST DRAW MINOR SURFACE
      IF (JMM.LT.0) THEN
         IF (JDM.GT.0) THEN
            CALL MULTISLICEPIECES(IM1,I2,IDM,KM1,K2,KDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,J2,ND,ICOL,JDM)
         ENDIF
         IF (J2.NE.JM2) THEN
            CALL MULTISLICEPIECES(J2,JM2,JDM,KM1,K1,KDM)
            DO IA = I1, I2-DI, DI
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,IA,ND,ICOL,IDM)
            ENDDO
            DO KA = K1, K2-DK, DK
               CALL MULTISLICEPIECES(IM1,I2,IDM,J2,JM2,JDM)
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,KDM)
               DO IA = I1, I2-DI, DI
                  CALL MULTISLICEPIECES(J2,JM2,JDM,KA,KA+DK,KDM)
                  CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,IA,ND,ICOL,IDM)
               ENDDO
            ENDDO
         ENDIF
       ELSE IF (KMM.GE.0) THEN
         GO TO 1000
      ENDIF

*     SECOND DRAW MIDIUM SURFACE
      IF (KMM.LT.0) THEN
         IF (KDM.GT.0) THEN
            CALL MULTISLICEPIECES(IM1,I2,IDM,JM1,JM2,JDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,K2,ND,ICOL,KDM)
         ENDIF
         IF (K2.NE.KM2) THEN
            CALL MULTISLICEPIECES(IM1,I1,IDM,K2,KM2,KDM)
            DO JA = J1, J2, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO IA = I1, I2-DI, DI
               CALL MULTISLICEPIECES(JM1,JM2,JDM,K2,KM2,KDM)
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,IA,ND,ICOL,IDM)
               DO JA = J1, J2, DJ
                  CALL MULTISLICEPIECES(IA,IA+DI,IDM,K2,KM2,KDM)
                  CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
               ENDDO
            ENDDO
         ENDIF
      ENDIF

*     LAST DRAW MAJOR SURFACE
      IF (IDM.GT.0) THEN
         CALL MULTISLICEPIECES(JM1,JM2,JDM,KM1,KM2,KDM)
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,I2,ND,ICOL,IDM)
      ENDIF
      IF (I2.NE.IM2) THEN
         IF (JDM.GT.0.AND.K1.NE.KM1) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,KM1,K1,KDM)
            DO JA = J1, J2, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDIF
         IF (KDM.GT.0) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,K1,ND,ICOL,KDM)
            DO KA = K1+DK, K2, DK
               CALL MULTISLICEPIECES(I2,IM2,IDM,KA-DK,KA,KDM)
               DO JA = J1, J2, DJ
                  CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
               ENDDO
               CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,KDM)
            ENDDO
         ENDIF
         IF (JDM.GT.0.AND.K2.NE.KM2) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,K2,KM2,KDM)
            DO JA = J1, J2, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDIF
      ENDIF

      RETURN

*     DRAW MAJOR SURFACE IN THE SPECIAL CASE
 1000 IF (IDM.GT.0) THEN
         CALL MULTISLICEPIECES(JM1,JM2,JDM,KM1,KM2,KDM)
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,I2,ND,ICOL,IDM)
      ENDIF
      IF (I2.NE.IM2) THEN
         JMM1 = JMM + DJ
         IF ((JMM-J1)*DJ.LT.0) JMM1 = J1
         KMM1 = KMM + DK
         IF ((KMM-K1)*DK.LT.0) KMM1 = K1
         IF (JDM.LT.0) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,KDM)
            DO KA = K1, KMM, DK
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,KDM)
            ENDDO
            DO KA = K2, KMM1, -DK
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,JDM)
            ENDDO
            RETURN
         ENDIF
         IF (KDM.LT.0) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,KM1,KM2,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            RETURN
         ENDIF
         IF (K1.NE.KM1) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,KM1,K1,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDIF
         IF (K2.NE.KM2) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,K2,KM2,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDIF
         DO KA = K1, KMM-DK, DK
            CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,KDM)
            CALL MULTISLICEPIECES(I2,IM2,IDM,KA,KA+DK,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDDO
         IF (KMM1.NE.K1) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KMM,ND,ICOL,KDM)
         ENDIF
         DO KA = K2, KMM1+DK, -DK
            CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
            CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KA,ND,ICOL,KDM)
            CALL MULTISLICEPIECES(I2,IM2,IDM,KA-DK,KA,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDDO
         CALL MULTISLICEPIECES(I2,IM2,IDM,JM1,JM2,JDM)
         CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,KMM1,ND,ICOL,KDM)
         IF (KMM.NE.K2.AND.KMM.NE.KMM1) THEN
            CALL MULTISLICEPIECES(I2,IM2,IDM,KMM,KMM1,KDM)
            DO JA = J1, JMM, DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
            DO JA = J2, JMM1, -DJ
               CALL CONT3D2DMAIN(F,IMAX,JMAX,KMAX,T0,JA,ND,ICOL,JDM)
            ENDDO
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE MULTISLICEPIECES(IX1,IX2,IDX,IY1,IY2,IDY)
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2

      IF (ABS(IDX).LT.ABS(IDY)) THEN
         NNX1 = IX1
         NNX2 = IX2
         NNY1 = IY1
         NNY2 = IY2
       ELSE
         NNX1 = IY1
         NNX2 = IY2
         NNY1 = IX1
         NNY2 = IX2
      ENDIF

      RETURN
      END

*      GIVEN DIMENSION IS F(IMAX,JMAX,KMAX)
*      T GIVES THE POSITION OF THE REST DIRECTION
*      IDIM GIVES THE REST DIRECTION (1:X,2:Y,3:Z)

      SUBROUTINE CONT3D2DMAIN(F,IMAX,JMAX,KMAX,TD,NA,ND,ICOL,IDIM)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      REAL*8 F(0:IMAX*JMAX*KMAX-1),TD
      REAL   XP(6),YP(6)

*      COXI(I,J)    = DXPU*I + DXPV*J + DXP0
*      COYI(I,J)    = DYPU*I + DYPV*J + DYP0

      IDM = IDIM
      if (IDIM.GT.3) IDM = IDIM - 3

      IF (NNX1.GT.NNX2) THEN
         NN   = NNX1
         NNX1 = NNX2
         NNX2 = NN
      ENDIF
      IF (NNY1.GT.NNY2) THEN
         NN   = NNY1
         NNY1 = NNY2
         NNY2 = NN
      ENDIF

      IF (IDM.LT.0) THEN
         DU   = (CNXMAX-CNXMIN)/(IMAX-1)
         DV   = (CNYMAX-CNYMIN)/(JMAX-1)
         DW   = (CNZMAX-CNZMIN)/(KMAX-1)
         DXPU = XPX*DU
         DXPV = XPY*DV
         DXPW = XPZ*DW
         DXP0 = XPX*CNXMIN + XPY*CNYMIN + XPZ*CNZMIN + XP0
         DYPU = YPX*DU
         DYPV = YPY*DV
         DYPW = YPZ*DW
         DYP0 = YPX*CNXMIN + YPY*CNYMIN + YPZ*CNZMIN + YP0
         IF (MDPROJ.NE.0) THEN
            DZPU = ZPX*DU
            DZPV = ZPY*DV
            DZPW = ZPZ*DW
            DZP0 = ZPX*CNXMIN + ZPY*CNYMIN + ZPZ*CNZMIN + ZP0
         ENDIF

       ELSE IF (IDM.EQ.1) THEN
         DU   = (CNYMAX-CNYMIN)/(JMAX-1)
         DV   = (CNZMAX-CNZMIN)/(KMAX-1)
         IF (NA.GE.0) THEN
            T0  = NA*(CNXMAX-CNXMIN)/(IMAX-1)+CNXMIN
          ELSE IF (IMNX.EQ.1) THEN
            T0 = (XMAX-XMIN)*TD+XMIN
           ELSE
            T0 = TD
         ENDIF
         IF (ICMOD.EQ.0) THEN
            IF (CNXMIN.LE.CNXMAX) THEN
               IF (T0.GT.CNXMAX) T0 = CNXMAX
               IF (T0.LT.CNXMIN) T0 = CNXMIN
             ELSE
               IF (T0.LT.CNXMAX) T0 = CNXMAX
               IF (T0.GT.CNXMIN) T0 = CNXMIN
            ENDIF
          ELSE
            IF (CNXMIN.LE.CNXMAX) THEN
               IF (T0.GT.MIN(CNXMAX,XMAX)) RETURN
               IF (T0.LT.MAX(CNXMIN,XMIN)) RETURN
             ELSE
               IF (T0.LT.MAX(CNXMAX,XMAX)) RETURN
               IF (T0.GT.MIN(CNXMIN,XMIN)) RETURN
            ENDIF
         ENDIF
         IF (IMAX.EQ.1) THEN
            IA = 0
            DD = 0
          ELSE IF (NA.GE.0) THEN
            IA  = NA
            DD  = 0
          ELSE
            TA  = (T0-CNXMIN)*(IMAX-1)/(CNXMAX-CNXMIN)
            IA  = TA
            DD  = ABS(TA-IA)
            IF (IA.EQ.IMAX-1) DD = 0
            DD1 = 1-DD
         ENDIF
         DXPU = XPY*DU
         DXPV = XPZ*DV
         DXP0 = XPX*T0 + XPY*CNYMIN + XPZ*CNZMIN + XP0
         DYPU = YPY*DU
         DYPV = YPZ*DV
         DYP0 = YPX*T0 + YPY*CNYMIN + YPZ*CNZMIN + YP0
         IF (MDPROJ.NE.0) THEN
            DZPU = ZPY*DU
            DZPV = ZPZ*DV
            DZP0 = ZPX*T0 + ZPY*CNYMIN + ZPZ*CNZMIN + ZP0
         ENDIF

         IP1 = IMAX
         JP1 = IMAX*JMAX
         KP1 = 1
         JPP = JP1 - (NNX2-NNX1+1)*IMAX
         IJ0 = IA+IMAX*(NNX1+JMAX*NNY1)

       ELSE IF (IDM.EQ.2) THEN
         DU   = (CNXMAX-CNXMIN)/(IMAX-1)
         DV   = (CNZMAX-CNZMIN)/(KMAX-1)
         IF (NA.GE.0) THEN
            T0  = NA*(CNYMAX-CNYMIN)/(JMAX-1)+CNYMIN
          ELSE IF (IMNY.EQ.1) THEN
            T0 = (YMAX-YMIN)*TD+YMIN
           ELSE
            T0 = TD
         ENDIF 
         IF (ICMOD.EQ.0) THEN
            IF (CNYMIN.LE.CNYMAX) THEN
               IF (T0.GT.CNYMAX) T0 = CNYMAX
               IF (T0.LT.CNYMIN) T0 = CNYMIN
             ELSE
               IF (T0.LT.CNYMAX) T0 = CNYMAX
               IF (T0.GT.CNYMIN) T0 = CNYMIN
            ENDIF
          ELSE
            IF (CNYMIN.LE.CNYMAX) THEN
               IF (T0.GT.MIN(CNYMAX,YMAX)) RETURN
               IF (T0.LT.MAX(CNYMIN,YMIN)) RETURN
             ELSE
               IF (T0.LT.MAX(CNYMAX,YMAX)) RETURN
               IF (T0.GT.MIN(CNYMIN,YMIN)) RETURN
            ENDIF
         ENDIF
         IF (JMAX.EQ.1) THEN
            JA = 0
            DD = 0
          ELSE IF (NA.GE.0) THEN
            JA  = NA
            DD  = 0
          ELSE
            TA  = (T0-CNYMIN)*(JMAX-1)/(CNYMAX-CNYMIN)
            JA  = TA
            DD  = ABS(TA-JA)
            IF (JA.EQ.JMAX-1) DD = 0
            DD1 = 1-DD
         ENDIF
         DXPU = XPX*DU
         DXPV = XPZ*DV
         DXP0 = XPX*CNXMIN + XPY*T0 + XPZ*CNZMIN + XP0
         DYPU = YPX*DU
         DYPV = YPZ*DV
         DYP0 = YPX*CNXMIN + YPY*T0 + YPZ*CNZMIN + YP0
         IF (MDPROJ.NE.0) THEN
            DZPU = ZPX*DU
            DZPV = ZPZ*DV
            DZP0 = ZPX*CNXMIN + ZPY*T0 + ZPZ*CNZMIN + ZP0
         ENDIF

         IP1 = 1
         JP1 = IMAX*JMAX
         KP1 = IMAX
         JPP = JP1 - (NNX2-NNX1+1)
         IJ0 = NNX1+IMAX*(JA+JMAX*NNY1)

       ELSE
         DU   = (CNXMAX-CNXMIN)/(IMAX-1)
         DV   = (CNYMAX-CNYMIN)/(JMAX-1)
         IF (NA.GE.0) THEN
            T0  = NA*(CNZMAX-CNZMIN)/(KMAX-1)+CNZMIN
          ELSE IF (IMNZ.EQ.1) THEN
            T0 = (ZMAX-ZMIN)*TD+ZMIN
           ELSE
            T0 = TD
         ENDIF 
         IF (ICMOD.EQ.0) THEN
            IF (CNZMIN.LE.CNZMAX) THEN
               IF (T0.GT.CNZMAX) T0 = CNZMAX
               IF (T0.LT.CNZMIN) T0 = CNZMIN
             ELSE
               IF (T0.LT.CNZMAX) T0 = CNZMAX
               IF (T0.GT.CNZMIN) T0 = CNZMIN
            ENDIF
          ELSE
            IF (CNZMIN.LE.CNZMAX) THEN
               IF (T0.GT.MIN(CNZMAX,ZMAX)) RETURN
               IF (T0.LT.MAX(CNZMIN,ZMIN)) RETURN
             ELSE
               IF (T0.LT.MAX(CNZMAX,ZMAX)) RETURN
               IF (T0.GT.MIN(CNZMIN,ZMIN)) RETURN
            ENDIF
         ENDIF
         IF (KMAX.EQ.1) THEN
            KA = 0
            DD = 0
          ELSE IF (NA.GE.0) THEN
            KA  = NA
            DD  = 0
          ELSE
            TA  = (T0-CNZMIN)*(KMAX-1)/(CNZMAX-CNZMIN)
            KA  = TA
            DD  = ABS(TA-KA)
            IF (KA.EQ.KMAX-1) DD = 0
            DD1 = 1-DD
         ENDIF
         DXPU = XPX*DU
         DXPV = XPY*DV
         DXP0 = XPX*CNXMIN + XPY*CNYMIN + XPZ*T0 + XP0
         DYPU = YPX*DU
         DYPV = YPY*DV
         DYP0 = YPX*CNXMIN + YPY*CNYMIN + YPZ*T0 + YP0
         IF (MDPROJ.NE.0) THEN
            DZPU = ZPX*DU
            DZPV = ZPY*DV
            DZP0 = ZPX*CNXMIN + ZPY*CNYMIN + ZPZ*T0 + ZP0
         ENDIF

         IP1 = 1
         JP1 = IMAX
         KP1 = IMAX*JMAX
         JPP = JP1 - (NNX2-NNX1+1)
         IJ0 = NNX1+IMAX*(NNY1+JMAX*KA)

      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (ICMOD.LT.2) THEN
         CALL FGWIOCOLORSET(ICOL,ND,FM1,FM2)
         IF (ICMOD.EQ.1) THEN
            ICMOD = 2
            GO TO 1000
         ENDIF
       ELSE
         CALL GWIOCOLOR(2,0)
         CALL COORDINIJ(REAL(NNX1),REAL(NNY1),XP(1),YP(1))
         CALL COORDINIJ(REAL(NNX2),REAL(NNY1),XP(2),YP(2))
         CALL COORDINIJ(REAL(NNX2),REAL(NNY2),XP(3),YP(3))
         CALL COORDINIJ(REAL(NNX1),REAL(NNY2),XP(4),YP(4))
         CALL GWIOPOLYGON(XP,YP,4,2)
      ENDIF

*      IF (IFIND.EQ.-2.AND.IFIND.GT.-5) THEN
*         CALL FGWIOBASECOL(F,IMAX,JMAX,COI(REAL(NNX1)),COJ(REAL(NNY1))
*     ,                         ,COI(REAL(NNX2)),COJ(REAL(NNY2)))
*      ENDIF

      IF (FM2.EQ.FM1.AND.IFIND.NE.-2) GO TO 1000
      IF (ND.LE.0.AND.IFIND.NE.-2) GO TO 1000

      NSFINE = -MOD(ICOL/10,10)
      IF (IFIND.EQ.-4.OR.(IFIND.EQ.-3.AND.NSFINE.EQ.1)) THEN
         IJ1 = IJ0
         DO J = NNY1, NNY2-1
            DO I = NNX1, NNX2-1
               IF (DD.EQ.0) THEN
                  F00 = F(IJ1)
                ELSE
                  F00 = DD1*F(IJ1) + DD*F(IJ1+KP1)
               ENDIF
               CALL COORDINIJ(REAL(I  ),REAL(J  ),XP(1),YP(1))
               CALL COORDINIJ(REAL(I+1),REAL(J  ),XP(2),YP(2))
               CALL COORDINIJ(REAL(I+1),REAL(J+1),XP(3),YP(3))
               CALL COORDINIJ(REAL(I  ),REAL(J+1),XP(4),YP(4))
*               RNF = (F00 - FMIN)/DF
*               NF  = RNF + 0.5
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,F00)
               IJ1 = IJ1 + IP1
            ENDDO
            IJ1 = IJ1 + IP1 + JPP
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-3) THEN
         IJ1 = IJ0
         DO J = NNY1, NNY2-1
            DO I = NNX1, NNX2-1
               IF (DD.EQ.0) THEN
                  F00 = F(IJ1)+F(IJ1+JP1)+F(IJ1+IP1)+F(IJ1+IP1+JP1)
                ELSE
                  F01 = F(IJ1)+F(IJ1+JP1)+F(IJ1+IP1)+F(IJ1+IP1+JP1)
                  F02 = F(IJ1+KP1)+F(IJ1+JP1+KP1)
     +                            +F(IJ1+IP1+KP1)+F(IJ1+IP1+JP1+KP1)
                  F00 = DD1*F01 + DD*F02
               ENDIF
               CALL COORDINIJ(REAL(I  ),REAL(J  ),XP(1),YP(1))
               CALL COORDINIJ(REAL(I+1),REAL(J  ),XP(2),YP(2))
               CALL COORDINIJ(REAL(I+1),REAL(J+1),XP(3),YP(3))
               CALL COORDINIJ(REAL(I  ),REAL(J+1),XP(4),YP(4))
*               RNF = (F00/4 - FMIN)/DF
*               NF  = RNF + 0.5
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,F00/4)
               IJ1 = IJ1 + IP1
            ENDDO
            IJ1 = IJ1 + IP1 + JPP
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-5) THEN
         IJ1 = IJ0
         DO J = NNY1, NNY2-1
            DO I = NNX1, NNX2-1
               IF (DD.EQ.0) THEN
                  F00 = F(IJ1)
                ELSE
                  F00 = DD1*F(IJ1) + DD*F(IJ1+KP1)
               ENDIF
               CALL COORDINIJ(REAL(I),REAL(J),XP1,YP1)
*               RNF = (F00 - FMIN)/DF
*               NF  = RNF + 0.5
               CALL FGWIOPSET(XP1,YP1,F00)
               IJ1 = IJ1 + IP1
            ENDDO
            IJ1 = IJ1 + IP1 + JPP
         ENDDO
         GO TO 999
      ENDIF

      IJ1 = IJ0
      DO 20 J = NNY1, NNY2-1
         DO 21 I = NNX1, NNX2-1
            IF (DD.EQ.0) THEN
               F0(0) = F(IJ1)
               F0(1) = F(IJ1+JP1)
               F0(2) = F(IJ1+IP1)
               F0(3) = F(IJ1+IP1+JP1)
             ELSE
               F0(0) = DD1*F(IJ1)         + DD*F(IJ1+KP1)
               F0(1) = DD1*F(IJ1+JP1)     + DD*F(IJ1+JP1+KP1)
               F0(2) = DD1*F(IJ1+IP1)     + DD*F(IJ1+IP1+KP1)
               F0(3) = DD1*F(IJ1+IP1+JP1) + DD*F(IJ1+IP1+JP1+KP1)
            ENDIF
            F00 = F0(0)+F0(1)+F0(2)+F0(3)
            IF (F00.EQ.4*FMIN) THEN
               CALL COORDINIJ(REAL(I  ),REAL(J  ),XP(1),YP(1))
               CALL COORDINIJ(REAL(I+1),REAL(J  ),XP(2),YP(2))
               CALL COORDINIJ(REAL(I+1),REAL(J+1),XP(3),YP(3))
               CALL COORDINIJ(REAL(I  ),REAL(J+1),XP(4),YP(4))
*               RNF = 0
*               NF  = 0
               NPG = 4
               CALL FGWIOPOLY(XP,YP,NPG,F00/4)
               GO TO 211
            ENDIF
            DO 40 K = 0, 3
               I0(K) = K
   40       CONTINUE
            DO 50 K = 0, 2
               DO 51 K1 = K+1, 3
                  IF (F0(K).GT.F0(K1)) THEN
                     IT     = I0(K)
                     I0(K)  = I0(K1)
                     I0(K1) = IT
                     FF     = F0(K)
                     F0(K)  = F0(K1)
                     F0(K1) = FF
                  ENDIF
   51          CONTINUE
   50          CONTINUE
            IF (IFIND.EQ.-2.AND.IFBASE.LT.0) THEN
               IF (F0(0).GE.FBASE.AND.F0(3).LE.FBASE1) GO TO 211
            ENDIF
            DO 60 K = 0, 3
               CFX(K) = I + I0(K)/2
               CFY(K) = J + MOD(I0(K),2)
               CALL COORDINIJ(CFX(K),CFY(K),CFX(K),CFY(K))
   60       CONTINUE
            IF (I0(0)+I0(2).EQ.3) THEN
               F00 = F0(0)
               F03 = F0(3)
               RNF = (F00 - FMIN)/DF
               NF  = RNF - 1
               IF (IFIND.EQ.-2) THEN
                  NPG   = 1
                  XP(1) = CFX(0)
                  YP(1) = CFY(0)
               ENDIF
   61          FD = NF*DF + FMIN
               IF (FD.LT.F00) THEN
                  NF = NF + 1
                  GO TO 61
               ENDIF
               XF0 = CFX(0)
               YF0 = CFY(0)
               XF1 = CFX(3)
               YF1 = CFY(3)
               DFX = XF1 - XF0
               DFY = YF1 - YF0
               IN0 = 0
               IN1 = 1

   70           CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F03) THEN
                  IF (IFIND.EQ.-2) THEN
                     IF (IN0.EQ.0) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(1)
                        YP(NPG) = CFY(1)
                     ENDIF
                     IF (IN0.NE.2) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(2)
                        YP(NPG) = CFY(2)
                     ENDIF
                  ENDIF
                  GO TO 79
               ENDIF
               DI = (FD - F00)/(F03 - F00)
   71          IF (FD.GT.F0(IN1)) THEN
                  IN0 = IN0 + 1
                  IN1 = IN1 + 1
                  IF (IFIND.EQ.-2) THEN
                     NPG     = NPG + 1
                     XP(NPG) = CFX(IN0)
                     YP(NPG) = CFY(IN0)
                  ENDIF
                  GO TO 71
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 78
               DJ = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
                  
               XX0 = XF0 + DFX*DI
               YY0 = YF0 + DFY*DI
               XF2 = CFX(IN0)
               YF2 = CFY(IN0)
               XF3 = CFX(IN1)
               YF3 = CFY(IN1)
               XX1 = XF2 + (XF3 - XF2)*DJ
               YY1 = YF2 + (YF3 - YF2)*DJ
               IF (IFIND.EQ.-2) THEN
                  NPG       = NPG + 2
                  XP(NPG-1) = XX1
                  YP(NPG-1) = YY1
                  XP(NPG)   = XX0
                  YP(NPG)   = YY0
                  CALL FGWIOPOLYS(XP,YP,NPG)
                ELSE
                  CALL FGWIOLINE(XX0,YY0,XX1,YY1)
               ENDIF
   78          NF = NF + 1
               GO TO 70
   79           CONTINUE
               IF (IFIND.EQ.-2) THEN
                  NPG   = NPG + 1
                  XP(NPG) = CFX(3)
                  YP(NPG) = CFY(3)
                  CALL FGWIOPOLYS(XP,YP,NPG)
               ENDIF
             ELSE IF (I0(0)+I0(3).EQ.3) THEN
               RNF = (F0(0) - FMIN)/DF
               NF  = RNF - 1
               IF (IFIND.EQ.-2) THEN
                  NPG   = 1
                  XP(1) = CFX(0)
                  YP(1) = CFY(0)
               ENDIF
   81          FD = NF*DF + FMIN
               IF (FD.LT.F0(0)) THEN
                  NF = NF + 1
                  GO TO 81
               ENDIF
               IN0 = 0
               IN1 = 1
               JN0 = 0
               JN1 = 2
   80           CONTINUE
               FD = NF*DF + FMIN
               IF (FD.GT.FMAX.OR.FD.GT.F0(3)) THEN
                  IF (IFIND.EQ.-2) THEN
                     IF (IN0.EQ.0) THEN
                        DO II = NPG, 1, -1
                           XP(II+1) = XP(II)
                           YP(II+1) = YP(II)
                        ENDDO
                        XP(1) = CFX(1)
                        YP(1) = CFY(1)
                        NPG   = NPG + 1
                        IF (JN0.EQ.0) THEN
                           NPG     = NPG + 1
                           XP(NPG) = CFX(2)
                           YP(NPG) = CFY(2)
                        ENDIF
                      ELSE IF (JN0.EQ.0) THEN
                        NPG     = NPG + 1
                        XP(NPG) = CFX(2)
                        YP(NPG) = CFY(2)
                     ENDIF
                  ENDIF
                  GO TO 89
               ENDIF
               IF (FD.GT.F0(IN1)) THEN
                  IN0 = 1
                  IN1 = 3
                  IF (IFIND.EQ.-2) THEN
                     DO II = NPG, 1, -1
                        XP(II+1) = XP(II)
                        YP(II+1) = YP(II)
                     ENDDO
                     XP(1) = CFX(1)
                     YP(1) = CFY(1)
                     NPG   = NPG + 1
                  ENDIF
               ENDIF
               IF (FD.GT.F0(JN1)) THEN
                  JN0 = 2
                  JN1 = 3
                  IF (IFIND.EQ.-2) THEN
                     NPG     = NPG + 1
                     XP(NPG) = CFX(2)
                     YP(NPG) = CFY(2)
                  ENDIF
               ENDIF
               IF (F0(IN1).EQ.F0(IN0)) GO TO 88
               IF (F0(JN1).EQ.F0(JN0)) GO TO 88
               DI = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
               DJ = (FD - F0(JN0))/(F0(JN1) - F0(JN0))
               XF0 = CFX(IN0)
               YF0 = CFY(IN0)
               XF1 = CFX(IN1)
               YF1 = CFY(IN1)
               XX0 = XF0 + (XF1 - XF0)*DI
               YY0 = YF0 + (YF1 - YF0)*DI
               XF0 = CFX(JN0)
               YF0 = CFY(JN0)
               XF1 = CFX(JN1)
               YF1 = CFY(JN1)
               XX1 = XF0 + (XF1 - XF0)*DJ
               YY1 = YF0 + (YF1 - YF0)*DJ
               IF (IFIND.EQ.-2) THEN
                  NPG       = NPG + 2
                  XP(NPG-1) = XX1
                  YP(NPG-1) = YY1
                  XP(NPG)   = XX0
                  YP(NPG)   = YY0
                  CALL FGWIOPOLYS(XP,YP,NPG)
                ELSE
                  CALL FGWIOLINE(XX0,YY0,XX1,YY1)
               ENDIF
   88          NF = NF + 1
               GO TO 80
   89           CONTINUE
               IF (IFIND.EQ.-2) THEN
                  NPG     = NPG + 1
                  XP(NPG) = CFX(3)
                  YP(NPG) = CFY(3)
                  CALL FGWIOPOLYS(XP,YP,NPG)
               ENDIF
             ELSE IF (I.GT.NNX1.AND.I.LT.NNX2-1
     +                 .AND.J.GT.NNY1.AND.J.LT.NNY2-1) THEN
              B1=F(IJ1-IP1-JP1)+F(IJ1+2*(IP1+JP1))-F(IJ1)-F(IJ1+IP1+JP1)
              B2=F(IJ1-IP1+2*JP1)+F(IJ1+2*IP1-JP1)-F(IJ1+JP1)-F(IJ1+IP1)
               IF (DD.NE.0) THEN
                 B1=DD1*B1 + DD*(F(IJ1-IP1-JP1+KP1)
     +                          +F(IJ1+2*(IP1+JP1)+KP1)-F(IJ1+KP1)
     -                          -F(IJ1+IP1+JP1+KP1))
                 B2=DD1*B2 + DD*(F(IJ1-IP1+2*JP1+KP1)
     +                          +F(IJ1+2*IP1-JP1+KP1)-F(IJ1+JP1+KP1)
     -                          -F(IJ1+IP1+KP1))
               ENDIF
               IF (B1.GE.0.AND.B2.GE.0) THEN
                  IND = 0
                ELSE IF (B1*B2.GE.0) THEN
                  IND = 1
                ELSE 
                  IND = 2
                  FMID = (8*(F0(0)+F0(1)+F0(2)+F0(3))-B1-B2)/32
                  IF (FMID.GE.F0(2)) THEN
                     IND = 1
                   ELSE IF (FMID.LE.F0(1)) THEN
                     IND = 0
                  ENDIF
               ENDIF
               IF (IND.EQ.0) THEN
                  CALL TRIANGCONT3D(0,2,0,1)
                  CALL TRIANGCONT3D(0,3,0,1)
                ELSE IF (IND.EQ.1) THEN
                  CALL TRIANGCONT3D(0,3,0,2)
                  CALL TRIANGCONT3D(1,3,1,2)
                ELSE
                  F0(4)  = FMID
                  I0(4)  = 4
                  CFX(4) = I + 0.5
                  CFY(4) = J + 0.5
                  CALL COORDINIJ(CFX(4),CFY(4),CFX(4),CFY(4))
                  DO 90 K = 0, 1
                     DO 91 K1 = 2, 3
                        CALL TRIANGCONT3D(K,K1,K,4)
   91               CONTINUE
   90               CONTINUE
               ENDIF
             ELSE
               F0(4)  = (F0(0)+F0(1)+F0(2)+F0(3))/4
               I0(4)  = 4
               CFX(4) = I + 0.5
               CFY(4) = J + 0.5
               CALL COORDINIJ(CFX(4),CFY(4),CFX(4),CFY(4))
               DO 95 K = 0, 1
                  DO 96 K1 = 2, 3
                     CALL TRIANGCONT3D(K,K1,K,4)
   96           CONTINUE
   95           CONTINUE
            ENDIF
  211       CONTINUE
            IJ1 = IJ1 + IP1
   21     CONTINUE
         IJ1 = IJ1 + IP1 + JPP
   20     CONTINUE

 999  CALL GWIOCOLOR(2,7)
      CALL COORDINIJ(REAL(NNX1),REAL(NNY1),XX0,YY0)
      CALL COORDINIJ(REAL(NNX2),REAL(NNY1),XX1,YY1)
      CALL GWIOLINE(XX0,YY0,XX1,YY1,0)
      CALL COORDINIJ(REAL(NNX2),REAL(NNY2),XX2,YY2)
      CALL GWIOLINE(XX1,YY1,XX2,YY2,0)
      CALL COORDINIJ(REAL(NNX1),REAL(NNY2),XX1,YY1)
      CALL GWIOLINE(XX2,YY2,XX1,YY1,0)
      CALL GWIOLINE(XX1,YY1,XX0,YY0,0)

 1000 CALL GWIOBDFLUSH(1)

      RETURN
      END

      SUBROUTINE TRIANGCONT3D(IN0,IN1,J0,J1)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL   XP(5),YP(5)

      XI0 = CFX(IN0)
      YI0 = CFY(IN0)
      XI1 = CFX(IN1)
      YI1 = CFY(IN1)
      XJ0 = CFX(J0)
      YJ0 = CFY(J0)
      XJ1 = CFX(J1)
      YJ1 = CFY(J1)

      RNF  = (F0(IN0) - FMIN)/DF
      NF  = RNF - 1
   11 FD  = NF*DF + FMIN
      IF (IFIND.EQ.-2) THEN
         NPG   = 1
         XP(1) = XI0
         YP(1) = YI0
      ENDIF
      IF (FD.LT.F0(IN0)) THEN
          NF = NF + 1
          GO TO 11
        ENDIF

      JN0 = J0
      JN1 = J1

   10   CONTINUE
          FD = NF*DF + FMIN
          IF (FD.GT.FMAX.OR.FD.GT.F0(IN1)) THEN
             IF (IFIND.EQ.-2) THEN
                IF (JN0.EQ.J0) THEN
                   NPG     = NPG + 1
                   XP(NPG) = XJ1
                   YP(NPG) = YJ1
                ENDIF
             ENDIF
             GO TO 20
          ENDIF
          IF (FD.GT.F0(JN1)) THEN
             JN0 = JN1
             JN1 = IN1
             XJ0 = XJ1
             YJ0 = YJ1
             XJ1 = XI1
             YJ1 = YI1
             IF (IFIND.EQ.-2) THEN
                NPG     = NPG + 1
                XP(NPG) = XJ0
                YP(NPG) = YJ0
             ENDIF
          ENDIF
          IF (F0(IN1).EQ.F0(IN0)) GO TO 18
          IF (F0(JN1).EQ.F0(JN0)) GO TO 18
          DI = (FD - F0(IN0))/(F0(IN1) - F0(IN0))
          DJ = (FD - F0(JN0))/(F0(JN1) - F0(JN0))
          XX0 = XI0 + (XI1 - XI0)*DI
          YY0 = YI0 + (YI1 - YI0)*DI
          XX1 = XJ0 + (XJ1 - XJ0)*DJ
          YY1 = YJ0 + (YJ1 - YJ0)*DJ
          IF (IFIND.EQ.-2) THEN
             NPG       = NPG + 2
             XP(NPG-1) = XX1
             YP(NPG-1) = YY1
             XP(NPG)   = XX0
             YP(NPG)   = YY0
             CALL FGWIOPOLYS(XP,YP,NPG)
           ELSE
             CALL FGWIOLINE(XX0,YY0,XX1,YY1)
          ENDIF
   18     NF = NF + 1
          GO TO 10

   20   CONTINUE
      IF (IFIND.EQ.-2) THEN
         NPG     = NPG + 1
         XP(NPG) = XI1
         YP(NPG) = YI1
         CALL FGWIOPOLYS(XP,YP,NPG)
      ENDIF
      RETURN
      END

      SUBROUTINE COORDINIJ(X,Y,XP,YP)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2

      XP1 = DXPU*X + DXPV*Y + DXP0
      YP1 = DYPU*X + DYPV*Y + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*X + DZPV*Y + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END

      SUBROUTINE COORDINIJK(X,Y,Z,XP,YP)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CONTORPARM3D/ FM1,FM2,DXPU,DXPV,DXPW,DXP0
     ,                     ,DYPU,DYPV,DYPW,DYP0,DZPU,DZPV,DZPW,DZP0
     ,                     ,NNX1,NNX2,NNY1,NNY2,IMNX,IMNY,IMNZ,ICMOD
      REAL*8 FM1,FM2
      INTEGER X,Y,Z

      XP1 = DXPU*X + DXPV*Y + DXPW*Z + DXP0
      YP1 = DYPU*X + DYPV*Y + DYPW*Z + DYP0
      IF (MDPROJ.NE.0) THEN
         ZP  = DZPU*X + DZPV*Y + DZPW*Z + DZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END
