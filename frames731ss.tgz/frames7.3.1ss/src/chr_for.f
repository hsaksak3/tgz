******************************************
*          F  R  A  M  E  S  V.7         *
*          FOR FORTRAN CHARACTERS        *
******************************************

      SUBROUTINE REMOVEEXTENTION(NAME,NAME1)
      CHARACTER NAME*(*),NAME1*(*)
      CHARACTER C*1

      N  = 1
      IC = 0
      ID = 0
      NC = 0
      ND = 0
      DO 10 I = 1, LEN(NAME)
         C = NAME(I:I)
         IF (C.EQ.' ') GO TO 10
*         IF (C.EQ.'\\') C  = '/'
         IF (C.EQ.'.')  THEN
            IC = 1
            NC = I
          ELSE IF (C.EQ.'/') THEN
            ID = 1
            ND = I+1
         ENDIF
         NAME1(N:N) = C
         N = N + 1
   10   CONTINUE

      IF (IC.EQ.1.AND.ND.LE.NC) N = NC

      NAME1(N:N) = CHAR(0)

      RETURN
      END

      INTEGER FUNCTION CHRLENGTH(CH)
      CHARACTER CH*(*)

      N0 = LEN(CH)
      N  = N0
      DO 10 I = N0, 1, -1
         IF (CH(I:I).NE.' ') GO TO 110
         N = N - 1
   10   CONTINUE

  110 CHRLENGTH = N
      RETURN
      END
