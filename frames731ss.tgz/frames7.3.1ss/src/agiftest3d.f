*******************************************
*          F  R  A  M  E  S  V.7          *
*    TESTS OF REAL 3D FRAME SUBROUTINES   *
*         PROGRAMMED BY T.TAGUCHI         *
*******************************************
      
      IMPLICIT REAL*8 (A-H,O-Z)

      CALL FR_GINIT
      CALL FR_GIFFILE('agiftest3d',3,0)

      CALL LORENTZ(30.D0,40.D0,0)
        CALL NEXT

*      do i = 0, 8
*        theta = i*45
*         CALL LORENTZ(-30.D0,theta,0)
*         call next
*      enddo
*      go to 1000

*      call fr_fpline(0.d0,0.d0,640.d0,480.d0,7,1)
*       CALL NEXT
      CALL LORENTZ(0.D0,40.D0,1)
        CALL NEXT
      CALL LORENTZ(90.D0,40.D0,1)
        CALL NEXT
      CALL SPLINE3D
        CALL NEXT
      CALL WAVE3D(-30.D0,60.D0,0)
        CALL NEXT
      CALL WAVE3D(-30.D0,120.D0,1)
        CALL NEXT
      CALL WAVE3D2(50.D0,150.D0,0)
        CALL NEXT
      CALL FIELD
        CALL NEXT
      CALL CYLIND
        CALL NEXT
      CALL TORUS2
        CALL NEXT
      CALL CATAST
        CALL NEXT
      CALL TCONT3D
        CALL NEXT
      CALL TCONT3D2
        CALL NEXT
*      CALL TCONT3D3
*        CALL NEXT
*1000  continue
      CALL TCONTVOL
        CALL NEXT
*      CALL TCONTVOL2
*        CALL NEXT
      CALL SURFACE2

 999  CALL FR_GEND

      STOP
      END

      SUBROUTINE NEXT
      CALL FR_GPAUSE
      CALL FR_GCLEAR
      RETURN
      END

*---------------------------------------------*
*    LORENTZ ATTRACTER  BY  3D  GRAPHICS      *
*---------------------------------------------*
      SUBROUTINE LORENTZ(TH,PH,ID)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (N=5000)
      REAL*8 XS(0:N),YS(0:N),ZS(0:N)
      REAL*8 F(3)
      COMMON /PARM/ SIG,R,B

      XMIN = -20.D0
      XMAX = 20.D0
      YMIN = -20.D0
      YMAX = 20.D0
      ZMIN = 0.0D0
      ZMAX = 40.0D0

      DT  = 0.01D0
      SIG = 10.D0
      R   = 28.D0
      B   = 8.D0/3.D0

      T     = 0.D0
      XS(0) = 0.1D0
      YS(0) = 0.1D0
      ZS(0) = 0.1D0
      
      F(1)  = XS(0)
      F(2)  = YS(0)
      F(3)  = ZS(0)

      DO I = 1, N
         CALL RKH4(3,T,DT,F)
         XS(I) = F(1)
         YS(I) = F(2)
         ZS(I) = F(3)
      ENDDO

      IF (ID.EQ.0) THEN
         CALL FR_ANGLE3D(TH,PH)
         CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
         CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
       ELSE
         CALL FR_ROTATE(TH,PH,3)
      ENDIF
      CALL FR_XYZNAME('XXX','YYY','ZZZ')
      CALL FR_GRAPH3D(XS,YS,ZS,N+1,2,1)
*      CALL ARROW3D(0.D0,0.D0,0.D0,4,0)

      RETURN
      END

      SUBROUTINE RKH4(N,X,H,Y)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NM=3)
      PARAMETER (C16=.16666666666666667D0)
      REAL*8 Y(N),Z(NM),K1(NM),K2(NM),K3(NM),K4(NM)

      CALL EQUAT(X,Y,K1)
      DO I = 1, N
         Z(I) = Y(I) + 0.5D0*H*K1(I)
      ENDDO

      CALL EQUAT(X+0.5D0*H,Z,K2)    
      DO I = 1, N
         Z(I) = Y(I) + 0.5D0*H*K2(I)
      ENDDO

      CALL EQUAT(X+0.5D0*H,Z,K3)    
      DO I = 1, N
         Z(I) = Y(I) + H*K3(I)
      ENDDO

      X = X + H
      CALL EQUAT(X,Z,K4)
      DO I = 1, N
         Y(I) = Y(I) + C16*H*(K1(I) + 2.D0*(K2(I) + K3(I)) + K4(I))
      ENDDO
      
      RETURN
      END

      SUBROUTINE EQUAT(X,F,DF)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NM=3)
      REAL*8 F(NM),DF(NM)
      COMMON /PARM/ SIG,R,B
      
      DF(1) = SIG*(F(2) - F(1))
      DF(2) = (R - F(3))*F(1) - F(2)
      DF(3) = F(1)*F(2) - B*F(3)
      
      RETURN
      END

      SUBROUTINE ARROW3D(X,Y,Z,IC,MODE)
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 XX(7),YY(7),ZZ(7)

      DO I = 1, 7
         YY(I) = 0.D0
      ENDDO
      XX(1) = 0.D0
      ZZ(1) = 0.D0
      XX(2) = 0.1D0
      ZZ(2) = 0.1D0
      XX(3) = XX(2)
      ZZ(3) = 0.05D0
      XX(4) = 0.2D0
      ZZ(4) = ZZ(3)
      XX(5) = XX(4)
      ZZ(5) = -ZZ(4)
      XX(6) = XX(3)
      ZZ(6) = -ZZ(3)
      XX(7) = XX(6)
      ZZ(7) = -ZZ(2)
      CALL FR_3DMOVE(X,Y,Z,MODE)
      CALL FR_3DPOLYGON(XX,YY,ZZ,7,IC,72)
      RETURN
      END

*-----------------------*
*     3D SPLINE TEST    *
*-----------------------*
      SUBROUTINE SPLINE3D
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NW=20,N=4*NW)
      PARAMETER (PI=3.141592653589793D0,PI2=PI*2)
      REAL*8 X(0:N*10),Y(0:N*10),Z(0:N*10)
      REAL*8 XS(2,0:N),YS(2,0:N),ZS(2,0:N)

      XMIN = -1.D0
      XMAX = 1.D0
      YMIN = -1.D0
      YMAX = 1.D0
      ZMIN = -1.0D0
      ZMAX = 1.0D0
      TH   = 50.D0
      PH   = 30.D0
      RL   = 1

      CALL FR_PROJECT(5.D0,1)
      CALL FR_ANGLE3D(TH,PH)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)

      CALL FR_XYZNAME('XXX','YYY','ZZZ')

      RS   = 0.D0
      N20   = N*10
      DPH   = NW*PI2/(N20)
      DTH   = PI2/(N20)
      DO I = 0, N20
         X(I) = (RL+RS*COS(DPH*I))*COS(DTH*I)
         Y(I) = (RL+RS*COS(DPH*I))*SIN(DTH*I)
         Z(I) = RS*SIN(DPH*I)
      ENDDO

      CALL FR_GRAPH3D(X,Y,Z,N20+1,1,1)

      RS   = 0.25D0

      N20   = N
      DPH   = NW*PI2/(N20)
      DTH   = PI2/(N20)
      DO I = 0, N20
         X(I) = (RL+RS*COS(DPH*I))*COS(DTH*I)
         Y(I) = (RL+RS*COS(DPH*I))*SIN(DTH*I)
         Z(I) = RS*SIN(DPH*I)
      ENDDO
      CALL FR_GRAPH3D(X,Y,Z,N20+1,2,1)

      R = 1.06D0

      N20   = N
      DPH   = NW*PI2/(N20)
      DTH   = PI2/(N20)
      DO I = 0, N20
         XS(1,I) = (RL+RS*COS(DPH*I))*COS(DTH*I)
         YS(1,I) = (RL+RS*COS(DPH*I))*SIN(DTH*I)
         ZS(1,I) = RS*SIN(DPH*I)
         XS(2,I) = -RS*SIN(DPH*I)*DPH*COS(DTH*I)*R
     +            -(RL+RS*COS(DPH*I))*SIN(DTH*I)*DTH
         YS(2,I) = -RS*SIN(DPH*I)*DPH*SIN(DTH*I)*R
     +            +(RL+RS*COS(DPH*I))*COS(DTH*I)*DTH
         ZS(2,I) = RS*COS(DPH*I)*DPH*R
      ENDDO
      CALL FR_GRAPH3D(XS,YS,ZS,2*(N20+1),4,6)

      N20   = N*10
      DPH   = NW*PI2/(N20)
      DTH   = PI2/(N20)
      DO I = 0, N20
         X(I) = (RL+RS*COS(DPH*I))*COS(DTH*I)
         Y(I) = (RL+RS*COS(DPH*I))*SIN(DTH*I)
         Z(I) = RS*SIN(DPH*I)
      ENDDO
      CALL FR_GRAPH3D(X,Y,Z,N20+1,6,1)
      RETURN
      END

*-----------------------------------------*
*    TEST  PROGRAM  OF  3D  GRAPHICS      *
*-----------------------------------------*
      SUBROUTINE WAVE3D(TH,PH,ID)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=50)

      REAL*8 T2(0:IMAX,0:JMAX)

      XMIN = -15.D0
      XMAX = 15.D0
      YMIN = -10.D0
      YMAX = 10.D0
      ZMIN = -15.0D0
      ZMAX = 15.0D0

      DX = (XMAX-XMIN)/IMAX
      DY = (YMAX-YMIN)/JMAX

      IF (ID.EQ.0) THEN
         CALL FR_PROJECT(5.D0,0)
         CALL FR_ANGLE3D(TH,PH)
         CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
         CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
       ELSE
         CALL FR_ROTATE(TH,PH,3)
      ENDIF

      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')

      DO J = 0, JMAX
         Y = DY*J + YMIN
         DO I = 0, IMAX
            X = DX*I + XMIN
            T2(I,J) = FUNC(X,Y)
         ENDDO
      ENDDO

      CALL FR_SET2DRGN(1,11,0,25)
      CALL FR_PROFILE(T2,IMAX+1,JMAX+1,4,1)

      RETURN
      END

      REAL*8 FUNCTION FUNC(X,Y)
      IMPLICIT REAL*8 (A-H,O-Z)

      XX = X*X + 3*Y*Y
      FUNC = 15.D0*COS(SQRT(XX))*EXP(-0.01D0*XX)

      RETURN
      END

      SUBROUTINE WAVE3D2(TH,PH,ID)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=50,JMAX=50)

      REAL*8 X(3),Y(3),T2(0:IMAX,0:JMAX)

      XMIN = -15.D0
      XMAX = 15.D0
      YMIN = -15.D0
      YMAX = 15.D0
      ZMIN = -15.0D0
      ZMAX = 15.0D0

      DX = (XMAX-XMIN)/IMAX
      DY = (YMAX-YMIN)/JMAX

      IF (ID.EQ.0) THEN
         CALL FR_PROJECT(5.D0,1)
         CALL FR_ANGLE3D(TH,PH)
         CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
         CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
       ELSE
         CALL FR_ROTATE(TH,PH,3)
      ENDIF

      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')

      DO J = 0, JMAX
         YY = DY*J + YMIN
         DO I = 0, IMAX
            XX = DX*I + XMIN
            T2(I,J) = FUNC(XX,0.5D0*YY)
         ENDDO
      ENDDO

      X(1) = XMIN
      X(2) = XMAX
      X(3) = XMIN
      Y(1) = YMIN
      Y(2) = YMIN
      Y(3) = YMAX
      CALL FR_SURFACE(X,Y,T2,IMAX+1,JMAX+1,6,304)

      RETURN
      END

********************************
*        3D DIPOLE FIELD       *
********************************
      SUBROUTINE FIELD
      IMPLICIT REAL*8(A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0)
      PARAMETER (IFMAX=31,ITMAX=40,IMAX=30,JMAX=40)
      REAL*8 XX(500),YY(500),ZZ(500)
      REAL*8 BX(-IMAX:IMAX,0:JMAX),BY(-IMAX:IMAX,0:JMAX)
     ,      ,BZ(-IMAX:IMAX,0:JMAX)
      REAL*8 F(IFMAX),TH(ITMAX)

      XMIN = -0.25D0*IMAX
      XMAX = 0.25D0*IMAX
      YMIN = 0.0D0
      YMAX = 0.25D0*JMAX
      ZMIN = 0.D0
      ZMAX = 5.D0
      CALL FR_PROJECT(5.D0,1)
      CALL FR_ANGLE3D(30.D0,-60.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')
      DO J = 0, JMAX
         DO I = -IMAX, IMAX
            X  = 0.25D0*I
            Y  = 0.25D0*J
            CALL DIPOLE(X,Y,BX(I,J),BY(I,J))
            BZ(I,J) = 1.D-3*(SIN(PI*2*Y/YMAX)+1)
         ENDDO
      ENDDO

      R = 1.0D0
      DO I = 1, IFMAX
         TH1 = PI*(I-1)/DBLE(IFMAX-1)
         CALL DIPOLE(R*COS(TH1),R*SIN(TH1),X,Y)
         F(I) = X*COS(TH1)+Y*SIN(TH1)
      ENDDO
      
      TH(1)     = 0.D0
      TH(ITMAX) = PI
      CALL FR_FLOWSPACE(F,IFMAX,TH,ITMAX,AREA,I0)

*      DO I = 1, ITMAX
*         TH(I) = PI*(I-1)/DBLE(ITMAX-1)
*      ENDDO

*      CALL FR_FLOW3DRGN(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX)
      CALL FR_FLOW3DRGN(0.D0,XMAX,0.D0,YMAX,ZMIN,ZMAX)
      DO I = 1, ITMAX/2
         XX(1) = R*COS(TH(I))
         YY(1) = R*SIN(TH(I))
         ZZ(1) = ZMIN
         NMAX  = 500
         CALL FR_FLOW3DLINE(XX,YY,ZZ,NMAX,BX,BY,BZ,2*IMAX+1,JMAX+1
     ,                                   ,1,4,1.D-7,5)
      ENDDO
      CALL FR_FLOW3DRGN(XMIN,0.D0,0.D0,YMAX,ZMIN,ZMAX)
      DO I = ITMAX/2+1, ITMAX
         XX(1) = R*COS(TH(I))
         YY(1) = R*SIN(TH(I))
         ZZ(1) = ZMAX
         NMAX  = 500
        CALL FR_FLOW3DLINE(XX,YY,ZZ,NMAX,BX,BY,BZ,2*IMAX+1,JMAX+1
     ,                                   ,1,6,1.D-7,-5)
      ENDDO

      RETURN
      END

      SUBROUTINE DIPOLE(X,Y,BX,BY)
      REAL*8 X,Y,R2,R5,BX,BY

      R2 = X*X+Y*Y
      IF (R2.EQ.0) THEN
         BX = 0.D0
         BY = 0.D0
       ELSE
         R5 = R2**2.5D0
         BX = (3.D0*X*X-R2)/R5
         BY = 3.D0*X*Y/R5
      ENDIF
      RETURN
      END

*-------------------------*
*      TORUS DISPLAY      *
*-------------------------*
      SUBROUTINE TORUS1
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=51,JMAX=51,PI=3.141592653589793D0)
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)

      DU = 2*PI/(IMAX-1)
      DV = 2*PI/(JMAX-1)

      DO J = 1, JMAX
         V = DV*J
         DO I = 1, IMAX
            U      = DU*(I-1)
            X(I,J) = (1+0.25*COS(V))*COS(U)
            Y(I,J) = (1+0.25*COS(V))*SIN(U)
            Z(I,J) = 0.25*SIN(V)
         ENDDO
      ENDDO

      CALL FR_ANGLE3D(30.D0,-60.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(-1.3D0,1.3D0,0.0D0,1.3D0,-0.5D0,0.5D0,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')

      CALL FR_SET2DRGN(1,26,0,35)
      CALL FR_SURFACE(X,Y,Z,IMAX,JMAX,3,4)

      RETURN
      END

*--------------------------------*
*      DOUBLE TORUS DISPLAY      *
*--------------------------------*
      SUBROUTINE TORUS2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=51,JMAX=51,PI=3.141592653589793D0)
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)

      DU = 2*PI/(IMAX-1)
      DV = 2*PI/(JMAX-1)

      DO J = 1, JMAX
         V = DV*J
         DO I = 1, IMAX
            U      = DU*(I-1)
            X(I,J) = (1+0.25*COS(V))*COS(U)
            Y(I,J) = (1+0.25*COS(V))*SIN(U)
            Z(I,J) = 0.25*SIN(V)
         ENDDO
      ENDDO

      CALL FR_ANGLE3D(30.D0,-60.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(-1.3D0,2.3D0,-1.3D0,1.3D0,-0.5D0,0.5D0,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')

*      CALL FR_SET2DRGN(1,26,0,35)
      CALL FR_SURFACE(X,Y,Z,IMAX,JMAX,3,10)

      DO J = 1, JMAX
         V = DV*J
         DO I = 1, IMAX
            U      = DU*(I-1)
            Z(I,J) = (1+0.25*COS(V))*COS(U)
            X(I,J) = 1+(1+0.25*COS(V))*SIN(U)
            Y(I,J) = 0.25*SIN(V)
         ENDDO
      ENDDO
      CALL FR_SURFACE(X,Y,Z,IMAX,JMAX,4,3)

      RETURN
      END

**************************************
*       TEST OF 3D TRINGLE MESH      *
**************************************
      SUBROUTINE CATAST
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=20,NPMAX=(IMAX+1)*(JMAX+1))
      REAL*8 X(NPMAX),Y(NPMAX),Z(NPMAX)
      INTEGER NODE(3,NPMAX*2)
      
      NP = 0
      DO J = 0, JMAX
         DO I = 0, IMAX
            NP = NP + 1
            X(NP) = (I-IMAX/2)*0.9D0
            Z(NP) = (J-JMAX/2)*0.47D0
            Y(NP) = 0.2D0*(Z(NP)**3-1.5*X(NP)*Z(NP))*IMAX/(4*IMAX-3*I)
         ENDDO
      ENDDO
      
      NS  = 0
      NP0 = 0
      DO J = 0, JMAX-1
         DO I = 0, IMAX-1
            NS  = NS + 1
            NP0 = NP0 + 1
            NODE(1,NS) = NP0
            NODE(2,NS) = NP0 + IMAX + 1
            NODE(3,NS) = NP0 + IMAX + 2
            NS  = NS + 1
            NODE(1,NS) = NP0
            NODE(2,NS) = NP0 + 1
            NODE(3,NS) = NP0 + IMAX + 2
         ENDDO
         NP0 = NP0 + 1
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(30.D0,10.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_TRISURFACE(X,Y,Z,NP,NODE,NS,-2,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')
      RETURN
      END

**********************************
*       TEST OF 3D CONTOURS      *
**********************************
      SUBROUTINE TCONT3D
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (JMAX=40,KMAX=50)
      REAL*8 F(0:JMAX,0:KMAX)
      COMPLEX*16 C

      XMIN = -2.D0
      XMAX =  2.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DY   = (YMAX - YMIN)/JMAX
      DZ   = (ZMAX - ZMIN)/KMAX
      DO K = 0, KMAX
         Z=DZ*K+YMIN
         DO J = 0, JMAX
            Y=DY*J+YMIN
*            C = DCMPLX(DY*J+YMIN,DZ*K+ZMIN-0.5D0)
*            F(I,J) = ABS(SIN(C))
            F(J,K)=EXP(-0.5*((Y-1)**2+(Z-.5)**2))
     +            +EXP(-1.2*((Y+1.5)**2+(Z+.5)**2))
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(30.D0,40.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
*      CALL FR_SETCONTOUR(0.D0,0.05D0,1)
*      CALL FR_SET3DRGN(0,1,20,40,30,50)
      CALL FR_CONTOUR3D(F,1,JMAX+1,KMAX+1,0.D0,20,5,0)

      RETURN
      END

***************************************
*       TEST OF 3D FILL CONTOURS      *
***************************************
      SUBROUTINE TCONT3D2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,KMAX=30)
      REAL*8 F(0:IMAX,0:KMAX)
      COMPLEX*16 C

      XMIN = -2.D0
      XMAX =  2.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DZ   = (ZMAX - ZMIN)/KMAX
      DO K = 0, KMAX
         Z=DZ*K+ZMIN
         DO I = 0, IMAX
            X=DX*I+XMIN
*            C = DCMPLX(DX*I+XMIN,DZ*K+ZMIN-0.5D0)
*            F(I,K) = ABS(SIN(C))
            F(I,K)=EXP(-0.5*((X-1)**2+(Z-0.5)**2))
     +            +EXP(-1.2*((X+1.5)**2+(Z+.5)**2))
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(30.D0,40.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
*      CALL FR_STCONTOUR(0.D0,0.05D0,1)
*      CALL FR_SET3DRGN(10,20,0,1,10,20)
      CALL FR_CONTOUR3D(F,IMAX+1,1,KMAX+1,.5D0,20,-2,0)
      CALL FR_COLORBAR(100,230,15,100,12)

      RETURN
      END

***************************************
*       TEST OF 3D FILL CONTOURS      *
***************************************
      SUBROUTINE TCONT3D3
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=30)
      REAL*8 F(0:IMAX,0:JMAX)
      COMPLEX*16 C

      XMIN = -2.D0
      XMAX =  2.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      DO J = 0, JMAX
         Y=DY*J+YMIN
         DO I = 0, IMAX
            X=DX*I+XMIN
*            C = DCMPLX(DX*I+XMIN,DY*J+YMIN-0.5D0)
*            F(I,J) = ABS(SIN(C))
            F(I,J)=EXP(-0.5*((X-1)**2+(Y-.5)**2))
     +            +EXP(-1.2*((X+1.5)**2+(Y+.5)**2))
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(30.D0,40.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
*      CALL FR_SETCONTOUR(0.D0,0.05D0,1)
*      CALL FR_SET3DRGN(10,20,10,20,0,1)
      CALL FR_CONTOUR3D(F,IMAX+1,JMAX+1,1,.5D0,20,-2,0)
      CALL FR_COLORBAR(100,230,15,100,12)

      RETURN
      END

***************************************
*        CYLINDRICAL FIELD LINES      *
***************************************
      SUBROUTINE CYLIND
      IMPLICIT REAL*8(A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0)
      PARAMETER (IFMAX=31,ITMAX=10,IMAX=20,JMAX=50)
      PARAMETER (NMAX0=5000)
      REAL*8 XX(NMAX0),YY(NMAX0),ZZ(NMAX0)
      REAL*8 BR(0:IMAX,0:JMAX),BT(0:IMAX,0:JMAX)
     ,      ,BZ(0:IMAX,0:JMAX)
      REAL*8 F(0:IMAX,0:JMAX)

      RMAX = 0.25D0*IMAX
      RMIN = -RMAX
      YMAX = RMAX
      YMIN = -YMAX
      ZMIN = 0.D0
      ZMAX = 10.D0
      OM   = -5

      CALL FR_PROJECT(5.D0,1)
      CALL FR_ANGLE3D(30.D0,-60.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(RMIN,RMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')

      DR   = RMAX/IMAX
      DZ   = (ZMAX-ZMIN)/JMAX
      DO J = 0, JMAX
         Z = DZ*J+ZMIN
         DO I = 0, IMAX
            R = DR*I
            F(I,J)  = EXP(-0.3*((R-2)**2+(Z-ZMAX/2)**2))
            BR(I,J) = 0
            BT(I,J) = R*OM*F(I,J)
            BZ(I,J) = 1
         ENDDO
      ENDDO

      CALL FR_SETGEOMETRY(2)
      DR = RMAX/(ITMAX+1)
      DO I = 1, ITMAX
         R     = DR*I
         XX(1) = R
         YY(1) = 0
         ZZ(1) = ZMIN+0.1
         NMAX  = NMAX0
         CALL FR_FLOW3DLINE(XX,YY,ZZ,NMAX,BR,BT,BZ,IMAX+1,1,JMAX+1
     ,                                   ,5,1.D-7,3)
      ENDDO

      CALL FR_SET3DBOX(0.D0,RMAX,YMIN,YMAX,ZMIN,ZMAX,0)
      CALL FR_CONTOUR3D(F,IMAX+1,1,JMAX+1,0D0,20,-2,0)
      CALL FR_SET3DBOX(0.D0,-RMAX,YMIN,YMAX,ZMIN,ZMAX,0)
      CALL FR_CONTOUR3D(F,IMAX+1,1,JMAX+1,0D0,20,-2,0)

      CALL FR_CLIP3D(RMIN,RMAX,0.D0,YMAX,ZMIN,ZMAX,-2)
      DO I = 1, ITMAX
         R     = DR*I
         XX(1) = R
         YY(1) = 0
         ZZ(1) = ZMIN+0.1
         NMAX  = NMAX0
         CALL FR_FLOW3DLINE(XX,YY,ZZ,NMAX,BR,BT,BZ,IMAX+1,1,JMAX+1
     ,                                   ,5,1.D-7,3)
      ENDDO

      RETURN
      END

************************************
*       TEST OF 3D FILL SLICE      *
************************************
      SUBROUTINE TCONTVOL
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=15,KMAX=10)
      REAL*8 F(0:IMAX,0:JMAX,0:KMAX)
      COMPLEX*16 C

      XMIN = -2.D0
      XMAX =  2.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      DZ   = (ZMAX - ZMIN)/KMAX
      DO K = 0, KMAX
         Z=DZ*K+ZMIN
         DO J = 0, JMAX
            Y=DY*J+YMIN
            DO I = 0, IMAX
               X=DX*I+XMIN
               F(I,J,K)=EXP(-0.5*((X-.5)**2+(Y-.5)**2+(Z-.5)**2))
     +                 +EXP(-1.2*((X+1.5)**2+(Y+1.5)**2)
     +                            -0.1*(Z+1.5)**2)
            ENDDO
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(20.D0,130.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
*      CALL FR_SETCONTOUR(0.D0,0.05D0,1)
*      CALL FR_SET3DRGN(10,20,5,8,1,5)
      CALL FR_CONTOUR3D(F,IMAX+1,JMAX+1,KMAX+1,-.5D0,20,-2,403)
      CALL FR_COLORBAR(100,230,15,100,12)

      RETURN
      END

      SUBROUTINE TCONTVOL2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=20,JMAX=15,KMAX=10)
      REAL*8 F(0:IMAX,0:JMAX,0:KMAX)
      COMPLEX*16 C

      XMIN = -2.D0
      XMAX =  2.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      DZ   = (ZMAX - ZMIN)/KMAX
      DO K = 0, KMAX
         Z=DZ*K+ZMIN
         DO J = 0, JMAX
            Y=DY*J+YMIN
            DO I = 0, IMAX
               X=DX*I+XMIN
               F(I,J,K)=EXP(-0.5*((X-.5)**2+(Y-.5)**2+(Z-.5)**2))
     +                 +EXP(-1.2*((X+1.5)**2+(Y+1.5)**2)
     +                            -0.1*(Z+1.5)**2)
            ENDDO
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_VIEW3D(10,20,630,400)
      CALL FR_ANGLE3D(20.D0,130.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,1)
      CALL FR_FRAME3D(XMIN*2,XMAX*2,YMIN*2,YMAX*2,ZMIN*2,ZMAX*2,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
*      CALL FR_SETCONTOUR(0.D0,0.05D0,1)
*      CALL FR_SET3DRGN(10,20,5,8,1,5)
      CALL FR_SET3DBOX(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_CONTOUR3D(F,IMAX+1,JMAX+1,KMAX+1,-.5D0,20,-2,403)
      CALL FR_COLORBAR(100,230,15,100,12)

      RETURN
      END

*-------------------------*
*      ISOSURFACE         *
*-------------------------*
      SUBROUTINE SURFACE2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=10,JMAX=10,KMAX=50,PI2=2*3.141592653589793D0)
      REAL*8 F(-IMAX:IMAX,-JMAX:JMAX,0:KMAX)

      R0 = 5.5D0
      F0 = 0.75D0
      DO K = 0, KMAX
         RC = R0*COS(PI2*K/KMAX)
         RS = R0*SIN(PI2*K/KMAX)
         DO J = -JMAX, JMAX
            DO I = -IMAX, IMAX
               F(I,J,K) =  EXP(-((I-RC)*(I-RC)+(J-RS)*(J-RS))/20.D0)
     +                    +EXP(-((I+RC)*(I+RC)+(J+RS)*(J+RS))/40.D0)
            ENDDO
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,21)
      CALL FR_ANGLE3D(30.D0,-30.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(-DBLE(IMAX),DBLE(IMAX),-DBLE(JMAX),DBLE(JMAX)
     ,                           ,0.D0,DBLE(KMAX),4)
*      CALL FR_SET3DBOX(-3.D0,3.D0,-3.D0,3.D0,0.D0,10.D0,3)
      CALL FR_XYZNAME('X-AX','Y-AX','Z-AX')
      CALL FR_ISOSURFACE(F,2*IMAX+1,2*JMAX+1,KMAX+1,F0,3,5)

      RETURN
      END
