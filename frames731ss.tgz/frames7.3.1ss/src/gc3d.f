*******************************************
*          F  R  A  M  E  S  V.7          *
*    TESTS OF REAL 3D FRAME SUBROUTINES   *
*         PROGRAMMED BY T.TAGUCHI         *
*******************************************
      IMPLICIT REAL*8 (A-H,O-Z)

      CALL FR_GINIT
*      call fr_gwsize(580,450,0,0)
*      CALL FR_GFILEgif('gtest3d',0,0)
      CALL FR_GFILE('gc3d',0)
      CALL TCONTVOL2
 999  CALL FR_GEND

      STOP
      END

      SUBROUTINE NEXT
      CALL FR_GPAUSE
      CALL FR_GCLEAR
      RETURN
      END

      SUBROUTINE TCONTVOL2
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX=30,JMAX=20,KMAX=20)
      REAL*8 F(0:IMAX,0:JMAX,0:KMAX),TD(3)
      INTEGER NU(3)

      TD(1) = 0
      TD(2) = 0
      TD(3) = -1.8
      NU(1) = 3
      NU(2) = 1
      NU(3) = 2

      XMIN = -3.D0
      XMAX =  3.D0
      YMIN = -2.D0
      YMAX =  2.D0
      ZMIN = -2.D0
      ZMAX =  2.D0
      DX   = (XMAX - XMIN)/IMAX
      DY   = (YMAX - YMIN)/JMAX
      DZ   = (ZMAX - ZMIN)/KMAX
      DO K = 0, KMAX
         Z=DZ*K+ZMIN
         DO J = 0, JMAX
            Y=DY*J+YMIN
            DO I = 0, IMAX
               X=DX*I+XMIN
               F(I,J,K)=EXP(-0.5*((X-.5)**2+(Y-.5)**2+(Z-.5)**2))
     +              +EXP(-1.2*((X+1.5)**2+(Y+1.5)**2)-0.1*(Z+1.5)**2)
               if (F(I,J,K)<0.02) F(I,J,K)=0
            ENDDO
         ENDDO
      ENDDO

      CALL FR_PROJECT(5.D0,1)
      CALL FR_MARGIN3D(10,20,10,80)
      CALL FR_ANGLE3D(20.D0,70.D0)
      CALL FR_ASPECT3D(1.D0,1.D0,1.D0,0)
      CALL FR_FRAME3D(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_XYZNAME('X-AXIS','Y-AXIS','Z-AXIS')
!      CALL FR_SETCONTOUR(0.D0,0.005D0,1)
      CALL FR_SETCONTOUR(0.D0,1D0,2)
*      CALL FR_SET3DRGN(10,20,5,8,1,5)
*      CALL FR_SET3DBOX(XMIN,XMAX,YMIN,YMAX,ZMIN,ZMAX,3)
      CALL FR_SLICES(F,IMAX+1,JMAX+1,KMAX+1,TD,NU,20,-12,0)
      CALL FR_COLORBAR(50,180,15,100,12)

      RETURN
      END
