***********************************************
*     FILING  SKIP  SUBROUTINES  FOR  TPLOT   *
***********************************************
      SUBROUTINE CANVASALLCLOSE

      RETURN
      END

      SUBROUTINE GFILEFLUSHCLS

      RETURN
      END

      SUBROUTINE GFILEFRAME(X1,X2,Y1,Y2,IND)
      REAL*8 X1,X2,Y1,Y2

      RETURN
      END

      SUBROUTINE GFILE3FRAME(X1,X2,Y1,Y2,Z1,Z2,IND)
      REAL*8 X1,X2,Y1,Y2,Z1,Z2

      RETURN
      END

      SUBROUTINE GSENDBYTE(B,N)
      INTEGER B(N)

      RETURN
      END

      SUBROUTINE GSENDCHAR(B,N)
      INTEGER B(N)

      RETURN
      END

      SUBROUTINE GSEND8BYTE(X,Y,N,MODE)
      REAL*8 X(N),Y(N)

      RETURN
      END

      SUBROUTINE GSEND38BYTE(X,Y,Z,N,MODE)
      REAL*8 X(N),Y(N),Z(1)

      RETURN
      END

      SUBROUTINE GSENDHLSDATA(SH,SL,SS,NDIV,MODE)
      REAL*8 SH(*),SL(*),SS(*)

      RETURN
      END

      INTEGER FUNCTION CHRLENGTH(CH)
      PARAMETER (MAXCHR=1024)
      CHARACTER CH*(*)
      CHARACTER C0*1

      C0 = CHAR(0)
      N  = 0
      DO 10 I = 1, MAXCHR
         IF (CH(I:I).EQ.C0) GO TO 110
         N = N + 1
   10   CONTINUE

  110 CHRLENGTH = N
      RETURN
      END
