/*********************************************************
 *                 F r a m e s  V.7.2                    *
 *               Sphere Graph Core Routine               *
 *               Programed by T. Taguchi                 *
 *                   October  1, 2006                    *
 *********************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "frames.h"

#ifndef CompaqVisual
extern void spheregraphmain(double *,double *,double *,int *,int *,int *,int *,float *,int *);
#endif

void mallocsphgraphcore(double *x,double *y,double *z,int *nm,int *ns,int *ic,int *ind,int *ier)
{
	float *ws;
	int *hs,n;

	*ier=0;
	n=((*nm)-1)/(*ns)+1;
	ws=(float *)malloc(sizeof(float)*n);
	hs=(int *)malloc(sizeof(int)*n);
	if (ws==NULL || hs==NULL) {
		*ier=2;
		return;
	}
	spheregraphmain(x,y,z,nm,ns,ic,ind,ws,hs);
	free(ws);	free(hs);
}
