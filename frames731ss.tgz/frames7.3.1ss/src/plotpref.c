/*********************************************************
 *                 F r a m e s  V.7.2                    *
 *       tplot  preference file analize routines         *
 *                   for X-Frames                        *
 *               Programed by T. Taguchi                 *
 *                   December 27, 2010                   *
 *********************************************************
*/

#include <stdio.h>
#ifdef SOLARIS
#include <unistd.h>
#endif
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>

#include "frames_canvas.h"

#define nothing
#define MAXNCHAR		128
#define MAXPSLINE		8
#define MAXPSROW		8
#define MAXWORD			12
#define MAXEXT			2
#define RATEMAG			1024
#define MINRATE			5

char 		*wordlist[MAXWORD]={"xmin","xmax","ymin","ymax"
								,"zmin","zmax","theta","phi"
								,"fmin","fmax","fdelta","ncontour"};
char 		*extlist[MAXEXT]={"2d","3d"};

extern int		CLRSTOP,PSWRITE,PSPIPE,PREFFILE,PSFILE,PSSIZEMODE,PSFMODE;
extern int 		PSMODE,WINMODE,TGMODE,DISPMODE,HARDMODE,VECTORMODE,CHARMODE,DISPINFO;
extern int		PSCOLMODE,D3MODE,C256MODE,CONTCOLOR,USE0COL,GRAPHSTEP,GRAPHEACH;
extern int		STARTPAGE,NOFPAGE,PAPERSIZE,PAPERDIR,PLOTLMAX,PLOTRMAX;
extern int		LMARG,BMARG,BWREVMODE,GWIDTH,GHEIGHT,GXOFF,GYOFF,GWINFIX;
extern int		GWRNUM,GWRDEN;
extern char		psname[],filtername[],prefname[];
extern char		line_style[],gray_style[],color_name[9][8],line_name[9][14];

extern int 		SCALE2STEP,CONTOR2STEP;
extern int		SCALE2DMODE[],SCALE3DMODE[],CONTOR2DMODE[],CONTOR3DMODE[];
extern double	SC2DX1[],SC2DX2[],SC2DY1[],SC2DY2[];
extern double 	SC3DX1[],SC3DX2[],SC3DY1[],SC3DY2[],SC3DZ1[],SC3DZ2[];
extern double	SC3DPH[],SC3DTH[];
extern double  	CTRDF1[],CTRDF2[],CTRDDF[],CTRDT0[];
extern int     	CTRDND[],CTRDDIM[],CTRDNUM[];
extern int		scheck2[4],scheck3[6];

#ifdef GIF
extern int		GIFMODE,GIFANIME,GIFWRITE,GIFCOLMODE,GIFFILE,GIFSTEPNO,GIFAAMODE,GIFAARESOLVE;
extern int		GIFSETT,GIFSETB,GIFSETI,GIFBWREVMODE,GIFBASEW,GIFBASEH,GIFADELAY,GIFCOLTABLE,GIFGRAYMODE;
extern int		gif_h, gif_w;
extern double	gif_n;
extern char		gifname[];
#endif

void	option_set(char *,int);

void make_lower(char *str)
{
	while (*str) {
		if (*str>='A' && *str<='Z') (*str)+='a'-'A';
		if (*str=='\n' || *str=='\r') {
			*str='\0';
			break;
		}
		str++;
	}
}

char *skip_space(char *str)
{
	while (*str==' ' || *str=='\t') str++;
	return str;
}

char *skip_sep(char *str)
{
	while (*str==' ' || *str=='\t' || *str=='=' || *str==':') str++;
	return str;
}

char *get_argument(char *str,int *n)
{
	char str0[15];
	int i;

	for (i=0;i<15-1;i++,str++) {
		if (*str==']' || *str==')') {
			str0[i]='\0';
			*n=atoi(str0);
			return (str+1);
		}
		str0[i]=*str;
	}
	*n=-1;
	return str;
}

char *get_var(char *str,char *word,char **ext)
{
	int ne=0;
	while (1) {
		if ((*str<'a' || *str>'z') && (*str<'0' || *str>'9')) {
			if (*str=='.' || *str=='_') {
				ne++;
				if (ne>1) return NULL;
				*str='\0';		*ext=word+1;
			  }
			  else break;
		}
		*word++=*str++;
	}
	*word='\0';
	if (ne==0) *ext=word;
	return str;
}

int search_word(char *word,char *wlist[],int nl)
{
	int i;

	for (i=0;i<nl;i++) {
		if (strcmp(word,wlist[i])==0) return i+1;
	}
	return -1;
}

void syll_analyze(char *str)
{
	char word[80],*ext;
	int nw,ne,now;
	double dat;

	make_lower(str);
	str=skip_space(str);
	if (*str=='\0') return;
	str=get_var(str,word,&ext);
	if (str==NULL) return;
	nw=search_word(word,wordlist,MAXWORD);
	if (nw<0) return;
	if (*ext=='\0') ne=3;
	  else {
		ne=search_word(ext,extlist,MAXEXT);
		if (ne<0) return;
	}
	str=skip_sep(str);
	if (*str=='[' || *str=='(') {
		str=get_argument(str+1,&now);
		if ((--now)<0 || now>=SCALE2STEP) return;
		str=skip_sep(str);
	  }
	  else now=0;
	dat=atof(str);
	
	switch (nw) {
		case 1:
			if (ne&1) {		SCALE2DMODE[now]|=1;		SC2DX1[now]=dat;	scheck2[0] = !0;		}
			if (ne&2) {		SCALE3DMODE[now]|=1;		SC3DX1[now]=dat;	scheck3[0] = !0;		}
			break;
		case 2:
			if (ne&1) {		SCALE2DMODE[now]|=1;		SC2DX2[now]=dat;	scheck2[0] = !0;		}
			if (ne&2) {		SCALE3DMODE[now]|=1;		SC3DX2[now]=dat;	scheck3[0] = !0;		}
			break;
		case 3:
			if (ne&1) {		SCALE2DMODE[now]|=2;		SC2DY1[now]=dat;	scheck2[1] = !0;		}
			if (ne&2) {		SCALE3DMODE[now]|=2;		SC3DY1[now]=dat;	scheck3[1] = !0;		}
			break;
		case 4:
			if (ne&1) {		SCALE2DMODE[now]|=2;		SC2DY2[now]=dat;	scheck2[1] = !0;		}
			if (ne&2) {		SCALE3DMODE[now]|=2;		SC3DY2[now]=dat;	scheck3[1] = !0;		}
			break;
		case 5:
			if (ne&2) {		SCALE3DMODE[now]|=4;		SC3DZ1[now]=dat;	scheck3[2] = !0;		}
			break;
		case 6:
			if (ne&2) {		SCALE3DMODE[now]|=4;		SC3DZ2[now]=dat;	scheck3[2] = !0;		}
			break;
		case 7:
			if (ne&2) {		SCALE3DMODE[now]|=8;		SC3DTH[now]=dat;	scheck3[3] = !0;		}
			break;
		case 8:
			if (ne&2) {		SCALE3DMODE[now]|=8;		SC3DPH[now]=dat;	scheck3[3] = !0;		}
			break;
		case 9:
			if (ne&1) {		CONTOR2DMODE[now]|=2;		CTRDF1[now]=dat;	scheck2[2] = !0;		}
			if (ne&2) {		CONTOR3DMODE[now]|=2;		CTRDF1[now]=dat;	scheck3[4] = !0;		}
			break;
		case 10:
			if (ne&1) {		CONTOR2DMODE[now]|=2;		CTRDF2[now]=dat;	scheck2[2] = !0;		}
			if (ne&2) {		CONTOR3DMODE[now]|=2;		CTRDF2[now]=dat;	scheck3[4] = !0;		}
			break;
		case 11:
			if (ne&1) {		CONTOR2DMODE[now]|=4;		CTRDDF[now]=dat;	scheck2[3] = !0;		}
			if (ne&2) {		CONTOR3DMODE[now]|=4;		CTRDDF[now]=dat;	scheck3[5] = !0;		}
			break;
		case 12:
			if (ne&1) {		CONTOR2DMODE[now]|=1;		CTRDND[now]=dat;	scheck2[2] = !0;		}
			if (ne&2) {		CONTOR3DMODE[now]|=1;		CTRDND[now]=dat;	scheck3[4] = !0;		}
			break;
	}
}

int get_pref(char *name)
{
	char   	str[MAXNCHAR];
	FILE	*fp;

	if ((fp=fopen(name,"r"))==NULL) return 0;

	while (fscanf(fp,"%s",str)!=EOF) {
		switch (str[0]) {
			case '-': 	option_set(str,0);
						break;
			case '%': 	case '#': 	case '$': 	case '!': 
						break;
			default:	 syll_analyze(str);
		}
	}
	fclose(fp);
	return 1;
}

void style_help()
{
	int i;

	puts("\n  *********************************************************");
	puts("  *         B/W PS Printer Color Assignments              *");
	puts("  *    No.  Color     Gray Scale    Line Style            *");
	puts("  *-------------------------------------------------------*");
	for (i=1;i<8;i++) 
		printf("  *     %1d   %s      (%1d)        (%1d) %s     *\n"
				,i,color_name[i],gray_style[i],line_style[i],line_name[line_style[i]]);
	if (USE0COL) {
		printf("  *     %1d   %s      (%1d)        (%1d) %s     *\n"
				,0,color_name[0],gray_style[0],line_style[0],line_name[line_style[0]]);
	}
	printf("  *********************************************************\n");
}

void line_style_help()
{
	int i;

	printf("  ************************************************************************\n");
	printf("  *                B/W PS Printer Line Style Assignments                 *\n");
	printf("  *  No.  Color    Line Style         |  No.  Color   Line Style         *\n");
	printf("  *-----------------------------------+----------------------------------*\n");
	for (i=1;i<4;i++) 
		printf("  *   %1d   %s  (%1d) %s  |   %1d   %s  (%1d) %s  *\n"
				,i,color_name[i],line_style[i],line_name[line_style[i]]
					,i+4,color_name[i+4],line_style[i+4],line_name[line_style[i+4]]);
	if (USE0COL) {
		printf("  *   %1d   %s  (%1d) %s  |   %1d   %s  (%1d) %s   *\n"
				,4,color_name[4],line_style[4],line_name[line_style[4]]
					,0,color_name[0],line_style[0],line_name[line_style[0]]);
	   }
	  else {
		printf("  *   %1d   %s  (%1d) %s  |                                  *\n"
				,4,color_name[4],line_style[4],line_name[line_style[4]]);
	}
	printf("  ************************************************************************\n");
}

void gray_style_help()
{
	int i;

	printf("  ************************************************************\n");
	printf("  *           B/W PS Printer Gray Scale Assignments          *\n");
	printf("  *  No.  Color    Gray Scale   |  No.  Color   Gray Scale   *\n");
	printf("  *-----------------------------+----------------------------*\n");
	for (i=1;i<4;i++) 
		printf("  *   %1d   %s     (%1d)       |   %1d   %s     (%1d)       *\n"
				,i,color_name[i],gray_style[i],i+4,color_name[i+4],gray_style[i+4]);
	if (USE0COL) {
		printf("  *   %1d   %s     (%1d)       |   %1d   %s     (%1d)       *\n"
				,4,color_name[4],gray_style[4],0,color_name[0],gray_style[0]);
	   }
	  else {
		printf("  *   %1d   %s     (%1d)       |                            *\n"
				,4,color_name[4],gray_style[4]);
	}
	printf("  ************************************************************\n");
}

void help_display(int n)
{
	if (n) puts("\nUsage :  tplot [options] filename");
	puts("\n  <Display Options for tplot>");
	puts("   -?        Help");
	puts("   -on:name  Get Options & Preferences from File 'name'");
	puts("   -n        Normal Mode");
	puts("   -d        Direct Display Mode (Animation Mode)");
	puts("   -a        Forced Animation Mode");
	puts("   -h        Consecutive Hardcopy Mode");
	puts("   -f        Consecutive Filter   Mode");
	puts("   -i        Print Current Page in non-Display Modes (-gif etc)");
	puts("   -rv       Exchange black & White color");
	puts("   -k        Change Contour to 256 Colors Mode");
	puts("   -kn1(,n2,n3) Change Contour to Normal Mode ( n1 lines, n2 color, n3 border color)");
	puts("   -z        Precision PROF3D Mode");
	puts("   -f:name   Set Filter Name to 'name'");
	puts("   -gnn      Start From Page No. nn");
	puts("   -onn      Output nn Page");
	puts("   -snn      Set Page  Step Number to nn (Default=1)");
	puts("   -enn      Output First nn Pages in Each Step (Default=1)");
	printf("   -ssnn     Set Scale Step Number to nn (nn=1-%d Default=1)\n",MAXSCALENO);
	printf("   -csnn     Set Contour Step Number to nn (nn=1-%d Default=1)\n",MAXSCALENO);
	puts("   -rxx      Set Window Ratio to xx/2 (xx>=2, Default=2)");
	puts("   -wnn      Rescale to Fit Window Width to nn");
	puts("   -wn1xn2   Rescale Window Size to n1 x n2 (Keep width)");
	puts("   -hnn      Rescale to Fit Window Height to nn");
	puts("   -hn1xn2   Rescale Window Size to n2 x n1 (Keep height)");
	puts("   -vwn1xn2+(-)x0+(-)y0");
	puts("             Trim Window Size of n1 x n2 from Origin ( +(-)x0 , +(-)y0 )");
	puts("   -rwnn     After Trimming by -vw Option, Scale Window Width to nn");
	puts("   -rhnn     After Trimming by -vw Option, Scale Window Height to nn");
}

void help_postscript(int n)
{
	if (n) puts("\nUsage :  tplot [options] filename");
	puts("\n  <PostScript Options for tplot>");
	puts("   -ps       PS Output into File or Pipe without Display");
	puts("   -p:name   Specify Pipe 'name' for PS code output (or -p:\"lpr -Plp1\")");
	puts("   -pn:name  Change Output File name to 'name.ps and name.gif'");
	puts("   -l        Output One   Frame  in Landscape Style (Yoko)");
	puts("   -ln1xn2   Output n1xn2 Frames in Landscape Style (Yoko)");
	puts("   -m        Output Two   Frames in Portrait  Style (Tate)  (default)");
	puts("   -mn1xn2   Output n1xn2 Frames in Portrait  Style (Tate)");
	puts("   -s        Same as -l2x2");
	puts("   -a4       Output on Portrait  A4 Paper (default)");
	puts("   -a4l      Output on Landscape A4 Paper");
	puts("   -us       Output on Portrait  US Letter Paper");
	puts("   -mz       Set Left & Bottom Margin to Zero");
	puts("   -c0       Black/White");
	puts("   -c1       Gray Scale (default)");
	puts("   -c2       Gray Scale & Dashed Line");
	puts("   -c3       256 Colors");
/*	puts("   -c4       Pseudo 256 Colors (Require special filter)");
	puts("   -u0       Use 0 Number Color");  */
	puts("   -v0       Black Vectors");
	puts("   -v        Gray Scale Vectors (default)");
	puts("   -t0       Black Texts");
	puts("   -t        Gray Scale Texts (default)");
	puts("   -xn1n2..  Exchange Gray Scale (Use * as default)");
	puts("   -yn1n2..  Exchange Line Style (Use * as default)");
	style_help();
}

void help_gif(int n)
{
	if (n) puts("\nUsage :  tplot [options] filename");
	puts("\n  <GIF Options for tplot>");
	puts("   -gif      GIF Output without Display");
	puts("   -gifa     GIF Animation Output without Display");
	puts("   -gn:name  Change Output File name to 'name.gif and name.ps'");
	puts("   -gc1      GIF Gray scale color");
	puts("   -ga(nn)   GIF Anti-aliasing mode (if add nn=0-7)");
	puts("   -gan      GIF Switch off anti-aliasing");
	puts("   -gi       GIF Interlace");
	puts("   -gt       GIF Transparent for background color");
	puts("   -gtnn     GIF Transparent nn (nn=0-7)");
	puts("   -gdnn     GIF Animation Dlelay Time nn (unit in 1/100 sec. Default=10)");
	puts("   -ggc      Use Global Colormaps for GIF Animation");
	puts("   -glc      Use Local  Colormaps for GIF Animation (Default)");
	puts("   -grv      GIF Exchange black & White color");
	puts("   -grxx     GIF Window Ratio  to xx (Default=1)");
	puts("   -gwxx     GIF Window Width  to xx");
	puts("   -ghxx     GIF Window Height to xx");
}

void help_script(int n)
{
	if (n) puts("\nUsage :  Keyword=Number   (For example, xmax=5, ymin_2d(1)=10)");
	puts("\n  <Script Keywords for tplot>");
	puts("   xmin, xmax     X Domains (2D or 3D)");
	puts("   ymin, ymax     Y Domains (2D or 3D)");
	puts("   zmin, zmax     Z Domains (3D only)");
	puts("   theta, phi     Latitude and Longitude (3D only)");
	puts("   fmin, fmax     Data Value Domains for Contour Plot (2D or 3D)");
	puts("   fdelta         Data Value Spacing for Contour Plot (2D or 3D)");
	puts("   ncontour       Number of Contours (2D or 3D)");
	puts("   _2d, _3d       Designate 2D or 3D (For example, xmin_2d, etc.)");
	puts("   (nn)           Specify Page Step (For example, xmin_2d(1), etc.)");
	puts("                  This spectification must be used with -snn option.");
}

void help_all()
{
	help_display(1);
	help_postscript(0);
	help_gif(0);
	help_script(0);
}

void help_mode()
{
	puts("\nUsage :  tplot [options] filename");
	puts("\n  <Try One of the Followings>");
	puts("     tplot -helpd   :  Print  Display Options");
	puts("     tplot -helpp   :  Print  PostScript Options");
	puts("     tplot -helpg   :  Print  GIF Options");
	puts("     tplot -helps   :  Print  Notation of Scripts");
	puts("     tplot -helpa   :  Print  All Options");
/*
	puts("     tplot -?d   :  Print  Display Options");
	puts("     tplot -?p   :  Print  PostScript Options");
	puts("     tplot -?g   :  Print  GIF Options");
	puts("     tplot -?s   :  Print  Notation of Scripts");
	puts("     tplot -?a   :  Print  All Options");
	puts("   -ns       Do not send showpage code if not necessary");
	puts("   -m(n)     Plot in Medium Size (position 1-2)");
	puts("   -s(n)     Plot in Small  Size (position 1-3)");
	puts("   -c(?)     Full Color Mode (? gives you help)");
	puts("   -c[n]     Color Number Settings");
	puts("   -xmn      Correspond Color:m to Pen:n");
	puts("   -b        Printer Buffer Switch Mode");
*/
}

void option_set(char *opt,int ind)
{
	int		i,c1,nx,ny;
	double  x;
	char    name[128],*endptr;

	do {
		switch (*(++opt)) {

			case 'p':	case 'P':
				if (ind==0) {
					PSWRITE=1;
					if (*(++opt)=='s' || *opt=='S') {
						PSMODE=1;		CLRSTOP=0;		WINMODE=0;		TGMODE=0;
						PSFMODE=0;
						opt++;
					  }
					  else if (*opt==':') {
						strcpy(name,++opt);
						if (strlen(name)>0) {
							strcpy(psname,name);
							PSPIPE=1;		PSFMODE=0;
						}
					  }
					  else if (*opt=='n' || *opt=='N') {
						if (*(++opt)==':') {
							strcpy(name,++opt);
							if (strlen(name)>0) {
								strcpy(psname,name);
								/*	strcat(psname,".ps");	*/
								PSFILE=1;
#ifdef GIF
								if (GIFFILE==0) {
					 		   		strcpy(gifname,name);
									GIFFILE=1;
								}
#endif
							}
						}
					  }
					  else {
						PSMODE=0;		CLRSTOP=1;		WINMODE=1;
					}
					DISPMODE=0;		HARDMODE=0;
				}
				break;

			case 'a':	case 'A':
				if (ind==0) {
					if (*(++opt)=='4') {
						if (*(++opt)=='l') PAPERSIZE=1;
							else PAPERSIZE=0;
					  }
					  else {
						CLRSTOP=0;		WINMODE=1;
						DISPMODE=2;		HARDMODE=0;		TGMODE=0;
					}
				}
				break;

			case 'd':	case 'D':
				if (ind==0) {
					CLRSTOP=0;		WINMODE=1;
					DISPMODE=1;		HARDMODE=0;		TGMODE=0;
				}
				break;

			case 'n':	case 'N':
				if (ind==0) {
					CLRSTOP=1;		WINMODE=1;
					DISPMODE=0;		HARDMODE=0;		TGMODE=1;
				}
				break;

			case 'f':	case 'F':
				if (ind==0) {
					if (*(++opt)==':') {
						strcpy(name,++opt);
						if (strlen(name)>0) strcpy(filtername,name);
					  }
					  else {
					    CLRSTOP=1;		WINMODE=1;
					    DISPMODE=4;		HARDMODE=2;		TGMODE=0;
					}
				}
				break;

			case 'g':	case 'G':
				if (ind==0) {
#ifdef GIF
					if (*(++opt)=='i' || *opt=='I') {
						if (*(++opt) == 'f' || *opt == 'F') {
							GIFWRITE=1;
							CLRSTOP=0;		WINMODE=0;		TGMODE=0;
							if (*(++opt) == 'a' || *opt == 'A'){
								GIFMODE=1;		GIFANIME=1;
							  }
							  else {
								GIFMODE=1;		GIFANIME=0;
							}
						  }
						  else{
							GIFSETI=1;
						}
					  }
					  else if (*opt=='n' || *opt=='N') {
						if (*(++opt)==':') {
							strcpy(name,++opt);
							if (strlen(name)>0) {
								strcpy(gifname,name);
								GIFFILE=1;
								if (PSFILE==0) {
									strcpy(psname,name);
									/*	strcat(psname,".ps");	*/
									PSFILE=1;
								}
							}
	 					}
					  }
					  else if (*opt=='t' || *opt=='T') {
						if (*(++opt) >= '0' && *opt <= '9') {
							GIFSETT=atoi(opt);
							if( GIFSETT < 0 || GIFSETT >7) GIFSETT=0;
						  }
						  else GIFSETB=1;
					  }
					  else if (*opt=='d' || *opt=='D') {
						GIFADELAY=atoi(++opt);
						if(GIFADELAY<=0) GIFADELAY=10;
					  }
					  else if (*opt=='a' || *opt=='A') {
//						if (*(++opt) == 'a' || *opt=='A') {
							GIFAAMODE=1;
							if (*(++opt) >= '0' && *opt <= '9') {
								GIFAARESOLVE=atoi(opt);
								if( GIFAARESOLVE < 0 || GIFAARESOLVE >GIFMAXRESOL) GIFAARESOLVE=GIFBASERESOL;
						  	}
						    else if (*opt=='n' || *opt=='N') GIFAAMODE=0;
//						  }
//						  else GIFAAMODE=0;
					  }
					  else if (*opt=='c' || *opt=='C') {
						if (*(++opt) == '1') {
							GIFGRAYMODE=1;
						  }
						  else GIFGRAYMODE=0;
					  }
					  else if (*opt=='r' || *opt=='R') {
						if (*(++opt) == 'v' || *opt == 'V') {
							GIFBWREVMODE=1;
						  }
						  else gif_n = atof(opt);
					  }
					  else if (*opt=='w' || *opt=='W') {
						gif_n = atof(++opt)/GIFBASEW;
						gif_h = GIFBASEH;		
						gif_w = GIFBASEW;		
					  }
					  else if (*opt=='h' || *opt=='H') {
						gif_n = atof(++opt)/GIFBASEH;
						gif_h = GIFBASEH;		
						gif_w = GIFBASEW;		
					  }
					  else if (*opt=='l' || *opt=='L') {
						if (*(++opt) == 'c' || *opt == 'C') {
							GIFCOLTABLE=1;		
						}
					  }
					  else if (*opt=='g' || *opt=='G') {
						if (*(++opt) == 'c' || *opt == 'C') {
							GIFCOLTABLE=0;		
						}
					  }
					  else if (*opt=='s' || *opt=='S') {
						GIFSTEPNO=atoi(++opt);
						if (GIFSTEPNO<=0) GIFSTEPNO=1;
					  }
					  else {
#endif
						STARTPAGE=atoi(opt)-1;
						if (STARTPAGE<0) STARTPAGE=0;
#ifdef GIF
				  	}
#endif
				}
				break;

			case 'o':	case 'O':
				if (ind==0) {
					if (*(++opt)=='n' || *opt=='N') {
						if (PREFFILE==0 && *(++opt)==':') {
							strcpy(name,++opt);
							if (strlen(name)>0) {
								strcpy(prefname,name);
								PREFFILE=1;
							}
						}
					  }
					  else {
						NOFPAGE=atoi(opt);
						if (NOFPAGE<1) NOFPAGE=1;
					}
				}
				break;

			case 'e':	case 'E':
				if (ind==0) {
					GRAPHEACH=atoi(++opt);
					if (GRAPHEACH<1) GRAPHEACH=1;
	 			}
				break;

			case 'i':	case 'I':
				if (ind==0) {
					DISPINFO=1;
				}
				break;

			case 'l':	case 'L':
				if (ind==0) {
					PAPERDIR=1;		PLOTLMAX=1;		PLOTRMAX=1;		PSSIZEMODE=2;
					goto sz;
				}
				break;

			case 'm':	case 'M':
				if (*(++opt)=='Z' || *opt=='z') {
					LMARG=BMARG=0;
				  }
				  else if (ind==0) {
					opt--;
					PAPERDIR=0;		PLOTLMAX=2;		PLOTRMAX=1;		PSSIZEMODE=1;
					goto sz;
				}
				break;

			case 's':	case 'S':
				if (ind==0) {
	 				if (*(++opt)>='0' && *opt<='9') {
						GRAPHSTEP=atoi(opt);
						if (GRAPHSTEP<1) GRAPHSTEP=1;
		 			  }
					  else if (*opt=='s' || *opt=='S') {
						SCALE2STEP=atoi(++opt);
						if (SCALE2STEP>MAXSCALENO) SCALE2STEP=MAXSCALENO;
					  }
		 			  else {
						PAPERDIR=1;		PLOTLMAX=2;		PLOTRMAX=2;		PSSIZEMODE=0;
						goto sz;
					}
				}
				break;

		sz:		c1=*(++opt);
 				if (c1>='0' && c1<='9') {
 					PSSIZEMODE=3;
	 				PLOTLMAX=(int)strtol(opt,&endptr,0);
	 				if (PLOTLMAX<1) PLOTLMAX=1;
	 				  else if (PLOTLMAX>MAXPSLINE) PLOTLMAX=MAXPSLINE;
					if (*endptr=='x') {
		 				PLOTRMAX=(int)strtol(endptr+1,&endptr,0);
	 					if (PLOTRMAX<1) PLOTRMAX=1;
	 						else if (PLOTRMAX>MAXPSROW) PLOTRMAX=MAXPSROW;
	 				}
	 			}
				break;

			case 'r':	case 'R':
				if (ind==0) {
					if (*(++opt)=='v') {
						BWREVMODE=1-BWREVMODE;
					  }
					  else {
						c1=*opt;
						if (GWINFIX==1 && (c1=='w' || c1=='W')) {
							GWRNUM=atoi(++opt);		GWRDEN=GWIDTH;
						  }
						  else if (GWINFIX==1 && (c1=='h' || c1=='H')) {
							GWRNUM=atoi(++opt);		GWRDEN=GHEIGHT;
						  }
						  else if (GWINFIX==0 || GWINFIX==1) {
						  	x=strtod(opt,&endptr);
						  	if (*endptr=='/') {
						  		GWRNUM=x;	GWRDEN=atoi(++endptr);
							  }
							  else {
								GWRNUM=x*RATEMAG;		GWRDEN=RATEMAG;
							}
						}
					}
				}
				break;

			case 'w':	case 'W':
				if (ind==0) {
					nx=(int)strtol(++opt,&endptr,0);
					if (nx<WINWIDTH/2) nx=WINWIDTH/2;
					GWRNUM=nx;			GWRDEN=0;		GWINFIX=3;
					if (*endptr=='x') {
						ny=atoi(++endptr);
						if (ny<WINHEIGHT/MINRATE) {
							GWRNUM=GWRNUM*WINHEIGHT/(MINRATE*ny);
							ny=WINHEIGHT/MINRATE;
						}
						GWRDEN=ny;
					}
				}
				break;

			case 'h':	case 'H':
				if (*(++opt)=='e' || *opt=='E') {
					if (*(++opt) == 'l' || *opt == 'L'){
						if (*(++opt) == 'p' || *opt == 'P') goto help;
					}
					break;
				}
				if (ind==0) {
					if (*opt>='0' && *opt<='9') {
						ny=(int)strtol(opt,&endptr,0);
						if (ny<WINHEIGHT/2) ny=WINHEIGHT/2;
						GWRNUM=ny;			GWRDEN=0;		GWINFIX=-3;
						if (*endptr=='x') {
							nx=atoi(++endptr);
							if (nx<WINWIDTH/MINRATE) {
								GWRNUM=GWRNUM*WINWIDTH/(MINRATE*nx);
								nx=WINWIDTH/MINRATE;
							}
							GWRDEN=nx;
						}
					  }
					  else {
						CLRSTOP=1;		WINMODE=1;
						DISPMODE=3;		HARDMODE=1;		TGMODE=0;
					}
				}
				break;

			case 'z':	case 'Z':
				D3MODE=1;
				break;

			case 'k':	case 'K':
				c1=*(++opt);
 				if (c1>='0' && c1<='9') {
	 				C256MODE=(int)strtol(opt,&endptr,0);
					if (*endptr==',') {
	 					nx=(int)strtol(endptr+1,&endptr,0);
						if (*endptr==',') ny=atoi(++endptr);
					  		else ny=7;
					  }
					  else nx=5;
					if (nx>0) CONTCOLOR= ny*256+nx;
						else  CONTCOLOR=-ny*256+nx;
				  }
				  else C256MODE=-2;
				break;

			case 'c':	case 'C':
				c1=*(++opt);
				if (ind==0) {
					if (*opt=='s' || *opt=='S') {
						CONTOR2STEP=atoi(++opt);
						if (CONTOR2STEP>MAXSCALENO) CONTOR2STEP=MAXSCALENO;
					  	break;
					}
				}
 				if (c1>='0' && c1<='3') PSCOLMODE=c1-'0';
 					else	 PSCOLMODE=1;
				break;

			case 'u':	case 'U':
				c1=*(++opt);
 				if (c1=='0') USE0COL=1;
 				if (c1=='S' || c1=='s') PAPERSIZE=2;
				break;

			case 'v':	case 'V':
				if (*(++opt)=='W' || *opt=='w') {
					if (ind==0) {
						c1=*(++opt);
					 	if (c1!='+' && c1!='-') {
							GWIDTH=WINWIDTH;	GHEIGHT=WINHEIGHT;
							GWIDTH=(int)strtol(opt,&endptr,0);
#ifdef GIF
							gif_w=GWIDTH;
#endif
							if (*endptr=='x') {
								GHEIGHT=(int)strtol(++endptr,&endptr,0);
#ifdef GIF
								gif_h=GHEIGHT;
#endif
						 	}
					 		c1=*endptr;
							GWINFIX=1;
							opt=endptr;
						 }
						 if (c1=='+' || c1=='-') {
							GXOFF=0;			GYOFF=0;
							GXOFF=(int)strtol(++opt,&endptr,0);
							if (c1=='-') GXOFF=-GXOFF;
						 	c1=*endptr;
							if (c1=='+' || c1=='-') {
								GYOFF=(int)strtol(++endptr,&endptr,0);
								if (c1=='-') GYOFF=-GYOFF;
							}
						}
					}
				  }
				  else {
					c1=*opt;
 					if (c1=='0') VECTORMODE=0;
 						else	 VECTORMODE=1;
 				}
				break;

			case 't':	case 'T':
				c1=*(++opt);
 				if (c1=='0') CHARMODE=0;
 					else	 CHARMODE=1;
				break;

			case 'x':	case 'X':
				for (i=0;i<8;i++) {
					c1=*(++opt);
					if (c1=='*' || c1<'0' || c1>'7') continue;
						else if (c1=='\0') break;
					nx=c1-'0';
					gray_style[i+1]=nx;
					if (i==7) gray_style[0]=nx;
				}
				break;

			case 'y':	case 'Y':
				for (i=0;i<8;i++) {
					c1=*(++opt);
					if (c1=='*' || c1<'0' || c1>'7') continue;
						else if (c1=='\0') break;
					nx=c1-'0';
					line_style[i+1]=nx;
					if (i==7) line_style[0]=nx;
				}
				break;
/*
	retry:		if (c1=='/' || c1=='-') continue;
				if (c1<=' ') break;

	def:		nothing;
*/
			default:
				fprintf(stderr,"Invalid Option <%02x> !!!\n",*opt);

			case '?':
		help:	c1=*(++opt);
				if (*opt=='d' || *opt=='D') help_display(1);
				  else if (*opt=='p' || *opt=='P') help_postscript(1);
				  else if (*opt=='g' || *opt=='G') help_gif(1);
				  else if (*opt=='s' || *opt=='S') help_script(1);
				  else if (*opt=='a' || *opt=='A') help_all();
				  else help_mode();
				exit(1);
		  }
		  while (*(++opt)==' ') nothing;

	  } while (*opt=='-');
}
