*******************************************************
*                F r a m e s  V.7                     *
*      Miscellaneous Routines for Frames Libraries    *
*******************************************************

*      SUBROUTINE GWIOMODECHECK(MODE)

*      MODE = 0

*      RETURN
*      END

*      SUBROUTINE GWIOSETWSTEP(STEP,GWM)
*      IMPLICIT INTEGER (A-Z)
*      save gpstep,gsmode
*      data gpstep/1/,gsmode/0/

*      if (gwm.eq.1) then
*         gsmode = step
*       else if (gwm.lt.0) then
*         step   = gpstep
*         gsmode = 1
*       else if (gsmode.eq.0) then
*         gpstep = step
*      endif

*      RETURN
*      END

      SUBROUTINE FRAMESERROR(CH)
      CHARACTER CH*(*)

      WRITE(*,*) CH

      RETURN
      END

      SUBROUTINE INTEGER2TEXT(NUM,N,CNUMB)
      IMPLICIT NONE
      INTEGER NUM,N,K
      CHARACTER :: FORM*10,CNUMB*(*)

      FORM = '(I4)'
      FORM(3:3) = CHAR(ICHAR('0')+N)
      WRITE(CNUMB,FORM) NUM
      DO K = 1, 9
         IF (CNUMB(K:K) == ' ') THEN
            CNUMB(K:K) = '0'
          ELSE
            RETURN
         ENDIF
      ENDDO

      RETURN
      END
