/*****************************************
 *      F r a m e s  V.7                 *
 *      Header for Canvas Settings       *
 *****************************************
*/

#ifndef CANVAS_DEFINITION

#define WINWIDTH			640
#define WINHEIGHT			480
#define WINRATE				2
#define MAXSCALENO			50
#define MAXFP				100
#define SPHERECOLNUM		35
#define GIFBASEDELAY		10
#define GIFBASELOOP			0
#define GIFBASERESOL		3
#define GIFMAXRESOL			7
#define MAXSYSCOLMAP		50
#define MAXDEFCUMAPP		100
#define MINSPHERECOL		(MAXDEFCUMAPP+9)
#define MAXSPHERECOL		(MINSPHERECOL+7)
#define BASECOLVAL			256

#define FRAME_MASK			0xf00
#define FRAME_2D			0x100
#define FRAME_3D			0x200
#define GRAPH_2D			(FRAME_2D|1)
#define CONTOR_2D			(FRAME_2D|3)
#define CONTOR_3D			(FRAME_3D|2)
#define ISOSURF				(FRAME_3D|4)
#define VRENDER				(FRAME_3D|8)
#define LIGHTINGS			(FRAME_3D|16)

typedef struct {
	FILE *fp;
	char *fname;
	int  width, height, xoff, yoff, csize;
	int colset, outlet, page, window, status, gifoption;
	int r, g, b;
	char windowmode[3];
	char agifopion[3];
} frames_canvas;

#define GIFANIMSTATUS		1
#define STATUSON			1
#define STATUSOFF			0

frames_canvas *get_gcanvasp(void);
void	get_canvas_hlstable(int,int *,double ***,int ***);
int		get_current_hlstable(double **,int **);
int		get_current_tphlstable(void);
void	plt_fileclose(FILE *);
void	getcanvas_windowsize(int *,int *,int *,int *);
void	set_canvas_status(int,int);
void	get_canvas_rgb(int *);
void	get_canvas_charsize(int *);

#define CANVAS_DEFINITION

#endif
