/********************************************************
 *                 F r a m e s  V.7.3.0                 *
 *              tplot  main routine  V.7.3              *
 *             Redraw, Dump & PS Conversion             *
 *                Programed by T. Taguchi               *
 *                   September 17, 2012                 *
 *    Modification for Alpha was done by H. Sakagami    *
 ********************************************************
*/
/*#define TOOLKIT*/
/*#define TT_SPECIAL*/
/*#define HARDCOPY_MENU*/

#include <stdio.h>

#ifdef SOLARIS
#include <unistd.h>
#endif

#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>

#define NOT_USED_TPLOT
#include "frames.h"

#define PLT_NOFUNCTIONS
#include "frames_canvas.h"

#ifdef TOOLKIT
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/Toggle.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Scrollbar.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Text.h>

void 	text_out(Widget, char *);
void 	create_file_dialog(Widget, XtAppContext);
void 	file_frame(Widget,int);
void 	clear_settings(void);
void 	clear_step(int);
int 	goto_filep(int,int,int,int *);
int		next_frame_main(int);
int		sequence_frame_main(int);
void 	color_exchange(int);
void 	get_mouse_position(double *, double *);
void 	screengraph2d(double *,double *,double *,double *);
int		hard_copy(int);
int		ps_output(void);
int		scale_output(void);
int		analyze_output(void);
void 	quit_main(void);
void 	set_frames_initialize(int);
void 	start_file(void);
void 	set_app_initialize(int,char **);
void 	error_end(char *,int);
void 	clear_scales(void);
void 	get_next_file(void);
void 	settings_input(void);
void 	ps_setting_proc(int,int,int);
void 	clear_colormap(void);
void 	set_title_name(int);
int 	get_colormode(void);

void	fix_window(Widget, Position, Position);
void	clear_frames_window(void);
void 	exchange_window(int, int, int, int);
void 	wpicdraweventchk(int *, int *);
void 	wpicdrawcolormode(int *);
void	wpicdrawbufwaitflush(void);
void 	wpicdrawcharacters(int *,int *,char *,int *,int *,int *,int *,int *,int *);
void	gwiomodes(int *,int *,int *,float *);
void 	gwiocolor(int *,int *);

#ifdef GIF
int		gif_output(void);
void 	gif_setting_proc(int,int,int,int,int,int);
void 	gif_setaamode(int,int);
#endif

#define check_width 	16
#define check_height 	16
static unsigned char check_bits[] = {
   0x00, 0x00, 0x00, 0x60, 0x00, 0x30, 0x00, 0x18, 0x00, 0x08, 0x00, 0x0c,
   0x00, 0x06, 0x00, 0x03, 0x00, 0x03, 0x80, 0x01, 0xc6, 0x01, 0xdc, 0x00,
   0xf8, 0x00, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00};
static unsigned char blank_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
#endif

#define BEEP()			fputc(0x07,stderr)
#define Nothing
#define MAXPAGE			9999999
#define DISPPREC		7
#define MAXMCHAR		64
#define MAX1MEMO		16
#define INPUTLONG		120
#define INPUTSHORT		70
#define INPUTLESS		50
#define INPUTTINY		40
#define INPUTONE		20
#define TEXTLINE		600

extern void gwioclearpage(void);
extern int rotate_frame_main(int);

extern int				GRAPHNO,GWIDTH,GHEIGHT,WINMODE,PSWRITE,PSCOLMODE,PSSIZEMODE,PSFMODE;
extern int				GWRNUM,GWRDEN;
extern int				WWIDTH,WHEIGHT,WRMODE,BWREVMODE;
extern int				PSMODE,HARDMODE,DISPMODE,ENDPAGE,GRAPHSPEC,SURFACEMODE;

#ifdef GIF
extern int				GIFMODE,GIFWRITE,GIFGRAYMODE,GIFSETB,GIFSETI,GIFADELAY,GIFALOOP,GIFAAMODE,GIFAARESOLVE;
#endif

extern int 				seq_no;
extern int				step_no, step_each, step_off, start_page, end_page;
extern int				log2d_mode, threed_mode;
extern int 				SCALE2STEP,CONTOR2STEP,NOWS,NOWC;
extern int				SCALE2DMODE[],SCALE3DMODE[],CONTOR2DMODE[],CONTOR3DMODE[],LOG2DMODE[];
extern double			SC2DX1[],SC2DX2[],SC2DY1[],SC2DY2[];
extern double 			SC3DX1[],SC3DX2[],SC3DY1[],SC3DY2[],SC3DZ1[],SC3DZ2[];
extern double			SC3DPH[],SC3DTH[];
extern double  			CTRDF1[],CTRDF2[],CTRDDF[],CTRDT0[];
extern int				CTRDND[],CTRDDIM[],CTRDNUM[];
extern int				ANALYZEMODE,ANACOL,ANAORDER,NANA_DATA;
extern double			ANA2DX1,ANA2DX2,ANA_DATA[];
extern double			ARROWLEN,CIRCRAD,LINELIMIT,DOTRESOLVE,MOVIESPEED;
extern double			LIGHTALT,LIGHTAZIM,LIGHTAMB,LIGHTDIFF;
extern int				DOTSKIP,REANGLE3D,LIGHTNSPEC,SURFACECOLOR,LIGHTINGMODE;
extern int				SETTINGMODE,COLORSEL,COLORNOW,CLIP2DMODE,CLIP3DMODE,PROJ3DMODE,D3XYZMODE;
extern char				filename[];
extern int				flistno;

static int	scale2d_mask=-1, scale3d_mask=-1, cont2d_mask=-1, cont3d_mask=-1;
extern int	page_switching, step_angle;

#ifdef TOOLKIT
int			TGMODE=1;
#else
int			TGMODE=0;
#endif

#ifdef TOOLKIT
XtAppContext 	app_con;
Widget			toplevel, xframes, number_label, goto_popup, mode_button;
Widget			next_button, prev_button, start_button;
/*Widget			goto_button, goto_dialog;	*/
Widget			seq_button, step_popup, step_button, step_dialog;
Widget			scale_button, scale2_popup, scale2_dialog, scale3_popup, scale3_dialog;
Widget			analyze_popup, analyze_button, analyze_dialog;
Widget			result_popup, result_dialog;
Widget			setting_popup, setting_button, setting_dialog, checks_button;
Widget			file_button, xy_text;
Widget			memo_button, memo_popup, memo_list;
Widget 			first_button, last_button, next1_button, prev1_button, quit_button;
Widget			filter_button, ps_button, rotate_button;
#ifdef HARDCOPY_MENU
Widget			hardcopy_button;
#endif

#ifdef GIF
Widget			gif_button;
#endif

static int 	frame_no, seq_mode, set_no=0, button_on, rotate_on=0;
static int 	label_cont, label_cont3d, anal_mode, scale_on=0, goto_sw=0;
static char	comstring[MAXMCHAR+1];
static String *memolist=NULL;
static int	nmemo=0, maxmemo=-1, hardcopyon=1, filteron=0;

static String color_modes[]={
	"Normal","Reverse","B/W","B/W Rev",
};
static char color_type[]={0,1,10,11};
static String sequences[]={
#ifdef HARDCOPY_MENU
#ifdef GIF
		"Display","Hardcopy","Filter","PS output","GIF image","GIF anime"
#else
		"Display","Hardcopy","Filter","PS output",
#endif

#else
#ifdef GIF
		"Display","Filter","PS output","GIF image","GIF anime"
#else
		"Display","Filter","PS output",
#endif
#endif
	};

static void noop() {}

static int check_wildcard(char *str)
{
	int n=0;
	while (*str) {
		if (*str=='*' || *str=='?' || *str=='[') n++;
		str++;
	}
	return n;
}

#ifdef OSX
static void set_button_frame(Widget w)
{
	XtSetSensitive(w,False);
	XtSetSensitive(w,True);
}
#endif

static void clear_modes()
{
#ifdef OSX
	static int nc=0;
#endif

	ANALYZEMODE=ANACOL=0;		anal_mode=0;
/*	
	if ((SCALE2DMODE[NOWS]&16)==0) SCALE2DMODE[NOWS]=0;
 	if ((CONTOR2DMODE[NOWC]&16)==0)  CONTOR2DMODE[NOWC]=0;
	if ((SCALE3DMODE[NOWS]&16)==0) SCALE3DMODE[NOWS]=0;
	if ((CONTOR3DMODE[NOWC]&128)==0)  CONTOR3DMODE[NOWC]=0;
*/
	if (scale2d_mask>=0) {
		SCALE2DMODE[NOWS]&=scale2d_mask;
		scale2d_mask=-1;
	}
	if (cont2d_mask>=0) {
		CONTOR2DMODE[NOWC]&=cont2d_mask;
		cont2d_mask=-1;
	}
	if (scale3d_mask>=0) {
		SCALE3DMODE[NOWS]&=scale3d_mask;
		scale3d_mask=-1;
	}
	if (cont3d_mask>=0) {
		CONTOR3DMODE[NOWC]&=cont3d_mask;
		cont3d_mask=-1;
	}
	if ((SETTINGMODE&65536)==0)  clear_settings();
	COLORNOW=0;			LIGHTINGMODE=0;
#ifdef OSX
	if (nc==0) {
		set_button_frame(step_button);
		set_button_frame(next_button);
		set_button_frame(prev_button);
		set_button_frame(first_button);
		set_button_frame(last_button);
		set_button_frame(prev1_button);
		set_button_frame(next1_button);
		set_button_frame(file_button);
		set_button_frame(quit_button);
		set_button_frame(seq_button);
		set_button_frame(start_button);
		set_button_frame(mode_button);
//		set_button_frame(scale_button);
//		set_button_frame(analyze_button);
		set_button_frame(ps_button);
		set_button_frame(gif_button);
		set_button_frame(setting_button);
		set_button_frame(memo_button);
		set_button_frame(xy_text);
		nc=1;
	}
#endif
	XtSetSensitive(scale_button,False);
	XtSetSensitive(analyze_button,False);
	XtVaSetValues(xy_text,XtNlabel,comstring,NULL);
	XtSetSensitive(rotate_button,False);
	if (filteron) XtSetSensitive(filter_button,True);
		else	  XtSetSensitive(filter_button,False);
	if (rotate_on) {
		XtSetSensitive(next1_button,False);
		XtSetSensitive(prev1_button,False);
	}
}

static void set_special_buttons()
{
	if (GRAPHNO>1 && button_on==1) {
		XtSetSensitive(prev_button,True);
		button_on=0;
	  }
	  else if (GRAPHNO<=1 && button_on==0) {
		XtSetSensitive(prev_button,False);
		button_on=1;
	}
	if (GRAPHSPEC&FRAME_MASK) XtSetSensitive(scale_button,True);
	if (GRAPHSPEC==GRAPH_2D) XtSetSensitive(analyze_button,True);
/*	XtVaSetValues(analyze_button,XtNmappedWhenManaged,False,NULL);	*/
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_3D && threed_mode) {
		XtSetSensitive(rotate_button,True);
		if (rotate_on) {
			XtSetSensitive(next1_button,True);
			XtSetSensitive(prev1_button,True);
		}
	}
}

static void goto_nth_frame(int n,int mg)
{
	char str[20];
	int err;

	if (n<=0) {
		BEEP();
		return;
	}

	if (GRAPHNO!=n) {
	/*	wait_events(PropertyNotify,0);	*/
		switch (goto_filep(0,n-1,mg,&err)) {
			case 0:	BEEP();
			case 0xff:
					return;
		}
		clear_modes();
		err=next_frame_main(1);
		if (err<=0) {
			sprintf(str,"Last");
			XtVaSetValues(number_label,XtNlabel,str,NULL);
			BEEP();
		}
		set_special_buttons();
	}
}

static void next_frame()
{
	int ns=step_no,nd;

	if (seq_no>0) return;

	if (step_each>1) {
		nd=(GRAPHNO+step_off-1)%step_no+1;
		if (nd<step_each) ns=1;
			else ns=step_no-nd+1;
	}

	goto_nth_frame(GRAPHNO+ns,0);
}

static void prev_frame()
{
	int ns=step_no,nd;

	if (seq_no>0) return;

	if (step_each>1) {
		nd=(GRAPHNO+step_off-1)%step_no+1;
		if (nd>1 && nd<=step_each) ns=1;
			else if (nd==1) ns=step_no-step_each+1;
			else ns=nd-step_each;
	}

	goto_nth_frame(GRAPHNO-ns,0);
}

static void next_frame_sc()
{
	int ns=step_no,nd;
	static int mx=0;

	if (seq_no>0) return;

	if (step_each>1) {
		nd=(GRAPHNO+step_off-1)%step_no+1;
		if (nd<step_each) ns=1;
			else ns=step_no-nd+1;
	}

	if (GRAPHNO < ENDPAGE) {
		goto_nth_frame(GRAPHNO+ns,0);		mx=0;
	  }
	  else if (mx==0) {
		goto_nth_frame(GRAPHNO+ns,0);		mx++;
	}
}

static void prev_frame_sc()
{
	int ns=step_no,nd;
	static int mx=0;

	if (seq_no>0) return;

	if (step_each>1) {
		nd=(GRAPHNO+step_off-1)%step_no+1;
		if (nd>1 && nd<=step_each) ns=1;
			else if (nd==1) ns=step_no-step_each+1;
			else ns=nd-step_each;
	}

	if (GRAPHNO-ns > 0) {
		goto_nth_frame(GRAPHNO-ns,0);		mx=0;
	  }
	  else if (mx==0) {
		goto_nth_frame(GRAPHNO-ns,0);		mx++;
	}
}

static void put_angle()
{
	char str[128];
#ifdef TOOLKIT
	sprintf(str,"Azimumth = %.1f",SC3DPH[NOWS]);
	XtVaSetValues(xy_text,XtNlabel,str,NULL);
#endif
}

static void angle_one_step(int dangle)
{
	SCALE3DMODE[NOWS]|=8;		REANGLE3D=0;
	SC3DPH[NOWS]+=dangle*step_angle;
	if (SC3DPH[NOWS]> 180) SC3DPH[NOWS]-=360;
	if (SC3DPH[NOWS]<-180) SC3DPH[NOWS]+=360;
	next_frame_main(-1);
	wpicdrawbufwaitflush();
	put_angle();
}

static void next1_frame()
{
	if (rotate_on) angle_one_step(1);
		else goto_nth_frame(GRAPHNO+1,0);
}

static void prev1_frame()
{
	if (rotate_on) angle_one_step(-1);
		else goto_nth_frame(GRAPHNO-1,0);
}

static void first_frame()
{
	int n;

	if (seq_no>0) return;

/*	n=((start_page-1)%step_no)+1;	*/
	n=((GRAPHNO-1)%step_no)+1;
	if (GRAPHNO<=n) BEEP();
	  else {
	  	goto_nth_frame(n,0);
	}
}

static void last_frame()
{    
	if (seq_no>0) return;

	goto_nth_frame(ENDPAGE,1);
}


/*static void goto_frame(Widget w, XtPointer client_data,  XtPointer call_data)*/
/*
static void goto_frame(Widget w, XtPointer client_data,  XtPointer call_data)
{
	Position x,y;
	Dimension width, height;

	if (seq_no>0) return;

	XtVaGetValues(goto_button,XtNwidth,&width,XtNheight,&height,NULL);	
	XtTranslateCoords(goto_button,(Position)0,(Position)(-3*height),&x,&y);

	XtSetSensitive(goto_button,FALSE);
	XtVaSetValues(goto_dialog,XtNvalue,"",NULL);
	XtVaSetValues(goto_popup,XtNx,x,XtNy,y,NULL);
	XtPopup(goto_popup,XtGrabNonexclusive);
	goto_sw=0;
}

static void goto_proc(Widget w,Widget text)
{

	if (seq_no>0) return;

	XtPopdown(goto_popup);
	XtSetSensitive(goto_button,TRUE);
	frame_no=atoi(XawDialogGetValueString(goto_dialog));
	goto_sw=1;
}

static void goto_window()
{
	if (goto_sw) goto_nth_frame(frame_no,1);
}

static void goto_cancel(Widget w,Widget shell)
{
	XtPopdown(shell);
	XtSetSensitive(goto_button,TRUE);
}
*/

static void seq_proc(Widget w, int mode)
{

	if (seq_no>0) return;
	seq_mode=mode;

#ifndef HARDCOPY_MENU
	if (seq_mode > 1) seq_mode++;
#endif

	XtVaSetValues(seq_button,XtNlabel,sequences[mode],NULL);
}

static void set_general_buttons(Boolean n, int ind)
{
/*	if (XtIsSensitive(mode_button)==True) printf("on\n");	*/
	XtSetSensitive(mode_button,n);
	XtSetSensitive(next_button,n);
	XtSetSensitive(prev_button,n);
/*	XtSetSensitive(start_button,n);	*/
	XtSetSensitive(step_button,n);
	XtSetSensitive(seq_button,n);
/*	XtSetSensitive(goto_button,n);		*/
	XtSetSensitive(scale_button,n);
/*	XtSetSensitive(analyze_button,n);	*/
	XtSetSensitive(setting_button,n);
	XtSetSensitive(checks_button,n);
	XtSetSensitive(file_button,n);
	XtSetSensitive(first_button,n);
	XtSetSensitive(last_button,n);
	XtSetSensitive(quit_button,n);
	if (n==False) {
		if (ind==0) XtSetSensitive(rotate_button,n);
			else {
				XtSetSensitive(start_button,n);
				XtSetSensitive(rotate_button,True);
		}
		XtSetSensitive(next1_button,n);
		XtSetSensitive(prev1_button,n);
	  }
	  else if (rotate_on==0) {
		XtSetSensitive(next1_button,n);
		XtSetSensitive(prev1_button,n);
	  }
	  else {
		XtSetSensitive(start_button,n);
	}
#ifdef HARDCOPY_MENU
	if (hardcopyon) XtSetSensitive(hardcopy_button,n);
#endif
	if (filteron) XtSetSensitive(filter_button,n);
	if (nmemo>0) XtSetSensitive(memo_button,n);
	if (PSWRITE) XtSetSensitive(ps_button,n);
#ifdef GIF
	if (GIFWRITE) XtSetSensitive(gif_button,n);
#endif
}

static void rotate_frame()
{
	int n;

	set_no=1;
/*	clear_modes();		*/
	set_general_buttons(False,1);
	XtVaSetValues(rotate_button,XtNlabel,"Stop",NULL);

	n=rotate_frame_main(seq_mode);
	put_angle();
	if (n<0) return;
	set_no=0;
	set_special_buttons();
	XtVaSetValues(rotate_button,XtNlabel,"Rotate",NULL);
	set_general_buttons(True,1);
	scale3d_mask=0;
}

static void start_proc()
{
	char str[20];
	int n;

	set_no=1;
	clear_modes();
	set_general_buttons(False,0);
	XtVaSetValues(start_button,XtNlabel,"Stop",NULL);

/*	if (start_page!=GRAPHNO) goto_nth_frame(start_page,1);	*/

	n=sequence_frame_main(seq_mode);
	if (n<0) return;
	if (n) BEEP();
	  else {
		sprintf(str,"%5d",GRAPHNO);
		XtVaSetValues(number_label,XtNlabel,str,NULL);
	}
	set_no=0;
	set_special_buttons();
	XtVaSetValues(start_button,XtNlabel,"Start",NULL);
	set_general_buttons(True,0);
}
/*
static void mode_proc(Widget w, int mode)
{
	if (seq_no>0) return;

	color_exchange((int)color_type[mode]);

	XtVaSetValues(mode_button,XtNlabel,color_modes[mode],NULL);
}
*/
static void color_proc(Widget w, int mode)
{
	int cmd=1-BWREVMODE;
	if (seq_no>0) return;

	if( cmd ) {
		XtVaSetValues(mode_button, XtNforeground, 0x000000, XtNbackground, 0xffffffff, NULL );
	  }
	  else {
		XtVaSetValues(mode_button, XtNforeground, 0xffffff, XtNbackground, 0x00000000, NULL );
	}
	color_exchange(cmd);
}

static void bw_color()
{
	int cmd=2;

	if (seq_no>0) return;

	switch (BWREVMODE) {
		case 10:	cmd=0;		break;
		case 1:		cmd=3;		break;
		case 11:	cmd=1;		break;
	}
	color_exchange((int)color_type[cmd]);
	XtVaSetValues(mode_button,XtNlabel,color_modes[cmd],NULL);
}

static void check_mouse()
{
/*	XtWidgetGeometry geom,geom2;
	int width;						*/
	double x0,y0,sx,sy;
	char str[128];

	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
		get_mouse_position(&sx,&sy);
		screengraph2d(&sx,&sy,&x0,&y0);
		if (LOG2DMODE[NOWS]&1) x0 = pow(10.0,x0);
		if (LOG2DMODE[NOWS]&2) y0 = pow(10.0,y0);
		sprintf(str,"(%g , %g)",x0,y0);
		XtVaSetValues(xy_text,XtNlabel,str,NULL);
/*
		XtQueryGeometry(xy_text,NULL,&geom);
	XtVaGetValues(xy_text,XtNwidth,&width,NULL);	
		printf("%d %d %d\n",geom.width,geom.height,width);
		XtVaSetValues(xy_text,XtNwidth,180,NULL);
	XtVaGetValues(xy_text,XtNwidth,&width,NULL);	
		printf("%d %d %d\n",geom.width,geom.height,width);
		XtMakeGeometryRequest(xy_text,&geom,&geom2);
	XtVaGetValues(xy_text,XtNwidth,&width,NULL);	
		printf("%d %d %d\n",geom.width,geom.height,width);
*/
	}
}

#ifdef HARDCOPY_MENU
static void hardcopy_proc()
{

	if (seq_no>0) return;

	if (hard_copy(1)) {
		XtSetSensitive(hardcopy_button,FALSE);
		hardcopyon=0;
		BEEP();
	}
}
#endif

static void filter_proc()
{

	if (seq_no>0) return;

	if (hard_copy(2)) {
		XtSetSensitive(filter_button,FALSE);
		filteron=0;
		BEEP();
	}
}

static void psout_proc()
{

	if (seq_no>0) return;

	if (ps_output()) BEEP();
	BEEP();
}

#ifdef GIF
static void gifout_proc()
{

	if (seq_no>0) return;

	if (gif_output()) BEEP();
	BEEP();
}
#endif

static void quit_proc() 
{

	if (seq_no>0) return;

	quit_main();
}

void redraw_window(Widget, XEvent *);
void initialize_tplot_frames(void);
#endif

static void write_menu()
{
	char str[80];
	int x=0,y,n,cmd;

	if (WRMODE) y=2*(WHEIGHT-5)*WINHEIGHT/WHEIGHT;
		else	y=2*(WHEIGHT-5)*WINWIDTH/WWIDTH;
	if (PSWRITE)
		sprintf(str," No.%d: RB:Next MB:B/W F5:Rev F6:Hd F7:Flt F8:PS Esc:Bk",GRAPHNO);
	  else
		sprintf(str," No.%d: RB:Next MB:B/W F5:Rev F6:Hd F7:Flt Esc:Bk",GRAPHNO);
	n=strlen(str);		cmd=1;
	wpicdrawcharacters(&x,&y,str,&n,&x,&x,&x,&x,&cmd);
	wpicdrawbufwaitflush();
}

void set_counter()
{
#ifdef TOOLKIT
	char str[20];
/*	if (set_no) {*/
		sprintf(str,"%5d",GRAPHNO);
		XtVaSetValues(number_label,XtNlabel,str,NULL);
/*	}*/
#endif
}

void put_comment(char *str)
{
#ifdef TOOLKIT
	int i;
	String *ml;
	if (*str=='#') {
		str++;
		XtVaSetValues(xy_text,XtNlabel,str,NULL);
		str[MAXMCHAR]='\0';
		strcpy(comstring,str);
	}
	if (nmemo==0) XtSetSensitive(memo_button,TRUE);
	if (memolist==NULL) {
		maxmemo=MAX1MEMO;
		memolist = (String *) XtCalloc(sizeof(String *), MAX1MEMO);
	  }
	  else if (nmemo>=maxmemo) {
	  	maxmemo+=MAX1MEMO;
		ml = (String *) XtCalloc(sizeof(String *), maxmemo);
		for (i=0;i<nmemo;i++) ml[i]=memolist[i];
		XtFree((XtPointer) memolist);
		memolist=ml;
	}
	  	
	memolist[nmemo++]=XtNewString(str);
#endif
}

int clr_stop(int n)
{
	int c,n0,n1,icmod,idmod,cmd,ich;
	float x;

	if (PSWRITE==2) {
		PSMODE=0;
		c=10;		n0=n1=0;
		gwiomodes(&n0,&c,&n1,&x);
	}
#ifdef GIF
	if (GIFWRITE==2) {
		GIFMODE=0;
		c=10;		n0=n1=0;
		gwiomodes(&n0,&c,&n1,&x);
	}
#endif

	if (HARDMODE) {
		wpicdrawbufwaitflush();
		hard_copy(HARDMODE);
		goto cls;
	}

#ifdef TOOLKIT
	if (DISPMODE>0) goto cls;
#endif

/*	BEEP();		*/
	n0=1;	c=6;	gwiocolor(&n0,&c);
	n0=0;	    icmod=0;
	write_menu();
	cmd=BWREVMODE;	icmod=(BWREVMODE)/10*10;	idmod=BWREVMODE%10;		n0=99999;

	n1=1;	ich=0;
	while (1) {
		wpicdraweventchk(&n0,&n1);
		switch (n0) {
			case 2: 	if (ich==0) icmod=10-icmod;
							else	idmod=1-idmod;
						ich=1-ich;
						cmd=icmod+idmod;
						wpicdrawcolormode(&cmd);
						break;
			case 14: 	icmod=10-icmod;
						cmd=icmod+idmod;
						wpicdrawcolormode(&cmd);
						break;
			case 15:	idmod=1-idmod;
						cmd=icmod+idmod;
						wpicdrawcolormode(&cmd);
						break;
			case 3:
			case 13:	goto cls;
			case 16:
			case 17:	write_menu();
						hard_copy(n0-15);
						write_menu();
						break;
			case 18:	ps_output();
						break;
			case 27:	return 1;
		}
	}
cls:
	gwioclearpage();
   	if (cmd!=BWREVMODE) wpicdrawcolormode(&BWREVMODE);
	return 0;
}

#ifdef TOOLKIT

Pixmap 	check_bmp, blank_bmp;
#ifdef NOGCVT
char *gcvt(double val, int dec, char *buf)
{
	char str[]="%.9g";
	if (dec<9) str[2]='0'+dec;
	sprintf(buf,str,val);
	return buf;
}
#endif

void delete_chara(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	static XawTextBlock nullblock={0,0,"",0};

	XawTextPosition x1,x2;
	XawTextGetSelectionPos(w, &x1, &x2);
	if (x1<x2) {
		XawTextReplace(w, x1, x2, &nullblock);
		XawTextSetSelection(w, x1, x1);
	}
}

/*		Step Dialog		*/

#define MAX_STEP_TEXT		6
Widget	text_p[MAX_STEP_TEXT], focus_p;

static void step_frame(Widget w, XtPointer client_data,  XtPointer call_data)
{
	Position x,y;
	Dimension width, height;
	char str[15];

	if (seq_no>0) return;

	XtVaGetValues(step_button,XtNwidth,&width,XtNheight,&height,NULL);
	XtTranslateCoords(step_button,(Position)0,(Position)(-3*height),&x,&y);

	XtSetSensitive(step_button,FALSE);
/*	XtVaSetValues(step_popup,XtNx,x,XtNy,y,NULL);*/

	XtVaSetValues(text_p[0],XtNstring,gcvt((double)step_no,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[0],strlen(str));
	frame_no=GRAPHNO;
	XtVaSetValues(text_p[1],XtNstring,gcvt((double)frame_no,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[1],strlen(str));
	XtVaSetValues(text_p[2],XtNstring,gcvt((double)step_each,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[2],strlen(str));
	if (end_page>ENDPAGE) end_page=ENDPAGE;
	XtVaSetValues(text_p[3],XtNstring,gcvt((double)end_page,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[3],strlen(str));
	XtVaSetValues(text_p[4],XtNstring,gcvt((double)SCALE2STEP,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[4],strlen(str));
	XtVaSetValues(text_p[5],XtNstring,gcvt((double)CONTOR2STEP,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_p[5],strlen(str));

	XtPopup(step_popup,XtGrabNonexclusive);
	fix_window(step_popup,x,y);

	goto_sw=0;
}

static void step_proc(Widget w, XtPointer pnt)
{
	int no=(int)pnt,n;
	String num;
	char str[20];

	if (seq_no>0) return;

	XtPopdown(step_popup);
	XtSetSensitive(step_button,TRUE);

	XtVaGetValues(text_p[0], XtNstring, &num, NULL);
	step_no=atoi(num);
	if (step_no<=0) step_no=1;

	XtVaGetValues(text_p[1], XtNstring, &num, NULL);
	start_page=atoi(num);
	if (start_page<=0) start_page=1;

	XtVaGetValues(text_p[2], XtNstring, &num, NULL);
	step_each=atof(num);
	if (step_each<=0) step_each=1;

	XtVaGetValues(text_p[3], XtNstring, &num, NULL);
	end_page=atof(num);
	if (end_page<=0 || end_page>ENDPAGE) end_page=ENDPAGE;

	XtVaGetValues(text_p[4], XtNstring, &num, NULL);
	n=atof(num);
	if (SCALE2STEP>0 && SCALE2STEP<=MAXSCALENO) SCALE2STEP=n;

	XtVaGetValues(text_p[5], XtNstring, &num, NULL);
	n=atof(num);
	if (CONTOR2STEP>0 && CONTOR2STEP<=MAXSCALENO) CONTOR2STEP=n;

	step_off=step_no-(start_page-1)%step_no;

	if (no && frame_no!=start_page) {
		frame_no=start_page;
		goto_sw=1;
	}

	sprintf(str,"Step %3d",step_no);
	XtVaSetValues(step_button,XtNlabel,str,NULL);
	XtSetSensitive(step_button,TRUE);
}

static void step_proc1(Widget w, XtPointer pnt)
{
	step_proc(w, (XtPointer)1);
}

static void step_window()
{
	if (goto_sw==0) return;
	if (goto_sw) goto_nth_frame(frame_no,1);
	goto_sw=0;
}

static void step_cancel(Widget w,Widget shell)
{
	XtPopdown(shell);
	XtSetSensitive(step_button,TRUE);
}

static void step_reset(Widget w, Widget shell)
{
	char str[20];

	if (seq_no>0) return;

	XtPopdown(shell);
	XtSetSensitive(step_button,TRUE);

	clear_step(0);

	sprintf(str,"Step %3d",step_no);
	XtVaSetValues(step_button,XtNlabel,str,NULL);
	XtSetSensitive(step_button,TRUE);
}

void step_delete(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	XtPopdown(step_popup);
	XtSetSensitive(step_button,TRUE);
}

void updown_pkey_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	char *s=XtName(w);
	int n;
	n=s[5]-'0';
	XtVaSetValues(w, XtNdisplayCaret, False, NULL);
	if (*(vector[0])=='0') n+=MAX_STEP_TEXT-1;
		else			   n+=1;
	n%=MAX_STEP_TEXT;
	focus_p=text_p[n];
	XtSetKeyboardFocus(step_dialog, focus_p);
	XtVaSetValues(focus_p, XtNdisplayCaret, True, NULL);
}

void mouse_step_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	XtVaSetValues(focus_p, XtNdisplayCaret, False, NULL);
	XtSetKeyboardFocus(step_dialog, w);
	XtVaSetValues(w, XtNdisplayCaret, True, NULL);
	focus_p=w;
}

void create_step_dialog(Widget form)
{
	static XtActionsRec actions[]={
		{ "stepwindow" , (XtActionProc)step_window},
		{ "stepproc"   , (XtActionProc)step_proc1},
		{ "updown_pkey"  , (XtActionProc)updown_pkey_cb},
		{ "mouse_step"    , (XtActionProc)mouse_step_cb},
		{ "delete_step"    , (XtActionProc)step_delete},
	};
	static XtTranslations trans,trans1;
	Widget label1,label2,button1,button2,button3,button4;
	static Atom wm_delete_window;

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Unmap>: stepwindow()\n\
						<Message>WM_PROTOCOLS: delete_step()");

	step_popup=XtVaCreatePopupShell("step_popup",
						transientShellWidgetClass,form,XtNtitle,"Paging Dialog",
                        XtNtranslations, trans1,
						NULL);

	trans = XtParseTranslationTable("#override\n\
						<Key>KP_Enter: stepproc()\n\
						<Key>Return: stepproc()\n\
						Ctrl<Key>M: stepproc()\n\
						Ctrl<Key>J: stepproc()\n\
						<Key>Up:   updown_pkey(0)\n\
						<Key>Down: updown_pkey(1)\n\
						<Key>Tab: updown_pkey(1)\n\
						<Btn1Down>,<Btn1Up>: mouse_step()\n\
						Ctrl<Key>D: delete_chara() delete-next-character()\n\
						Ctrl<Key>H: delete_chara() delete-previous-character()\n\
						<Key>BackSpace: delete_chara() delete-previous-character()\n\
						<Key>Delete: delete_chara() delete-next-character()\n\
						<Key>Left: backward-character()\n\
						<Key>Right: forward-character()\n\
						<Key>: delete_chara() insert-char()\n\
						");

	step_dialog = XtVaCreateManagedWidget("pform0", formWidgetClass, step_popup,
		                            XtNborderWidth, 0,
									NULL);

	label1 = XtVaCreateManagedWidget("plabel0", labelWidgetClass, step_dialog,
							XtNlabel, "  Page  Step",
							XtNborderWidth, 0,
  							NULL);

	text_p[0] = XtVaCreateManagedWidget("ptext0", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						NULL);

	label2 = XtVaCreateManagedWidget("plabel1", labelWidgetClass, step_dialog,
						XtNlabel, " Start  Page",
						XtNfromVert, label1,
						XtNborderWidth, 0,
						NULL);

	text_p[1] = XtVaCreateManagedWidget("ptext1", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label1,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label1 = XtVaCreateManagedWidget("plabel2", labelWidgetClass, step_dialog,
							XtNlabel, "  Show  Each",
						XtNfromVert, label2,
							XtNborderWidth, 0,
						NULL);

	text_p[2] = XtVaCreateManagedWidget("ptext2", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label2,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label2 = XtVaCreateManagedWidget("plabel3", labelWidgetClass, step_dialog,
						XtNlabel, "  End   Page",
						XtNfromVert, label1,
						XtNborderWidth, 0,
						NULL);

	text_p[3] = XtVaCreateManagedWidget("ptext3", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label1,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label1 = XtVaCreateManagedWidget("plabel4", labelWidgetClass, step_dialog,
						XtNlabel, " Scale  Step",
						XtNfromVert, label2,
						XtNborderWidth, 0,
						NULL);

	text_p[4] = XtVaCreateManagedWidget("ptext4", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label2,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label2 = XtVaCreateManagedWidget("plabel5", labelWidgetClass, step_dialog,
						XtNlabel, "Contour Step",
						XtNfromVert, label1,
						XtNborderWidth, 0,
						NULL);

	text_p[5] = XtVaCreateManagedWidget("ptext5", asciiTextWidgetClass, step_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label1,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label1=label2;
	button1=XtVaCreateManagedWidget("pgo", commandWidgetClass, step_dialog,
						XtNlabel, " Go ",
						XtNfromVert, label1,
         /*					XtNfromHoriz, text2,*/
						XtNvertDistance, 15,
						XtNhorizDistance, 10,
						XtNborderWidth, 1, NULL);

	button2=XtVaCreateManagedWidget("pset", commandWidgetClass, step_dialog,
						XtNlabel, " Set ",
						XtNfromVert, label1,
						XtNfromHoriz, button1,
						XtNvertDistance, 15,
						XtNhorizDistance, 15,
						XtNborderWidth, 1, NULL);

	button3=XtVaCreateManagedWidget("pcan", commandWidgetClass, step_dialog,
						XtNlabel, "Cancel",
						XtNfromVert, label1,
						XtNfromHoriz, button2,
						XtNvertDistance, 15,
						XtNhorizDistance, 15,
						XtNborderWidth, 1, NULL);

	button4=XtVaCreateManagedWidget("pres", commandWidgetClass, step_dialog,
						XtNlabel, "Reset",
						XtNfromVert, label1,
						XtNfromHoriz, button3,
						XtNvertDistance, 15,
						XtNhorizDistance, 15,
						XtNborderWidth, 1, NULL);

	XtSetKeyboardFocus(step_dialog, text_p[0]);
	focus_p=text_p[0];
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)step_proc, (XtPointer)1);
	XtAddCallback(button2, XtNcallback, (XtCallbackProc)step_proc, (XtPointer)0);
	XtAddCallback(button3, XtNcallback, (XtCallbackProc)step_cancel, step_popup);
	XtAddCallback(button4, XtNcallback, (XtCallbackProc)step_reset, step_popup);

	XtRealizeWidget(step_popup);
	wm_delete_window = XInternAtom(XtDisplay(step_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(step_popup), XtWindow(step_popup), &wm_delete_window, 1);
}

/*		Scale Dialog		*/

#define XYZPOS				14
#define XYZPOSM1			(XYZPOS-1)
#define CHECKNUM2D			4
#define CHECKNUM3D			7
Widget 	text2_w[8], focus2_w, text3_w[XYZPOS], focus3_w, text3_xyz[3], text_lit[5];
Widget	log2d_x, log2d_y, lradio[7];
Widget	check2_button[CHECKNUM2D], check3_button[CHECKNUM3D];
int 	scheck2[CHECKNUM2D]={0,0,0,0},scheck3[CHECKNUM3D]={0,0,0,0,0,0,0};
int		logcheck2[2]={0,0},light_num=0;
char 	on_lcolor[7];
static int xyz_num;
static XtTranslations trans,trans1,trans2,trans3;

void false_text3d(int n)
{
	int i;

	for (i=8;i<XYZPOS;i++) XtSetSensitive(text3_w[i],False);
#ifdef OSX
	XtVaSetValues(text3_xyz[xyz_num], XtNstate, False, NULL);
	for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
	XtVaSetValues(text3_xyz[xyz_num], XtNstate, True, NULL);
#else
	for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
#endif
	for (i=4;i<CHECKNUM3D;i++) XtSetSensitive(check3_button[i],False);
	for (i=8;i<XYZPOSM1;i++) {
		if (focus3_w==text3_w[i]) break;
	}
	if (i<XYZPOSM1 && i!=n) {
		XtVaSetValues(focus3_w, XtNdisplayCaret, False, NULL);
		focus3_w=text3_w[0];
		XtSetKeyboardFocus(scale3_dialog, focus3_w);
		XtVaSetValues(focus3_w, XtNdisplayCaret, True, NULL);
	}
}

void false_textlight(void)
{
	int i;

	for (i=0;i<5;i++) XtSetSensitive(text_lit[i],False);
#ifdef OSX
	if (light_num>0) XtVaSetValues(lradio[light_num-1], XtNstate, False, NULL);
	for (i=0;i<7;i++) XtSetSensitive(lradio[i],False);
	if (light_num>0) XtVaSetValues(lradio[light_num-1], XtNstate, True, NULL);
#else
	for (i=0;i<7;i++) XtSetSensitive(lradio[i],False);
#endif
}

static void scale_frame(Widget w, XtPointer client_data, XtPointer call_data)
{
	Position x,y;
	Dimension width, height;
	char str[15];
	int i, n;

	if (seq_no>0 || (GRAPHSPEC&FRAME_MASK)==0) {  BEEP();		return;  }

	XtVaGetValues(scale_button,XtNwidth,&width,XtNheight,&height,NULL);
	XtTranslateCoords(scale_button,(Position)0,(Position)(-3*height),&x,&y);
	/*printf("%d %d\n",x,y);*/

	XtSetSensitive(scale_button,FALSE);
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
/*		XtVaSetValues(scale2_popup,XtNx,x,XtNy,y,NULL);	*/
		XtVaSetValues(text2_w[0],XtNstring,gcvt(SC2DX1[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[0],strlen(str));
		XtVaSetValues(text2_w[1],XtNstring,gcvt(SC2DX2[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[1],strlen(str));
		XtVaSetValues(text2_w[2],XtNstring,gcvt(SC2DY1[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[2],strlen(str));
		XtVaSetValues(text2_w[3],XtNstring,gcvt(SC2DY2[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[3],strlen(str));
		logcheck2[0]=logcheck2[1]=0;

		n=LOG2DMODE[NOWS];
		if (n&1) logcheck2[0]=!logcheck2[0];
		if (n&2) logcheck2[1]=!logcheck2[1];
		if (logcheck2[0]) XtVaSetValues(log2d_x, XtNlabel, "Log", NULL);
			else 		  XtVaSetValues(log2d_x, XtNlabel, "Linear", NULL);
		if (logcheck2[1]) XtVaSetValues(log2d_y, XtNlabel, "Log", NULL);
			else 		  XtVaSetValues(log2d_y, XtNlabel, "Linear", NULL);
		XtSetSensitive(log2d_x,TRUE);
		XtSetSensitive(log2d_y,TRUE);
/*
		if (log2d_mode&8) {
			n=LOG2DMODE[NOWS];
			if (n&1) logcheck2[0]=!logcheck2[0];
			if (n&2) logcheck2[1]=!logcheck2[1];
			if (logcheck2[0]) XtVaSetValues(log2d_x, XtNlabel, "Log", NULL);
				else 		  XtVaSetValues(log2d_x, XtNlabel, "Linear", NULL);
			if (logcheck2[1]) XtVaSetValues(log2d_y, XtNlabel, "Log", NULL);
				else 		  XtVaSetValues(log2d_y, XtNlabel, "Linear", NULL);
			XtSetSensitive(log2d_x,TRUE);
			XtSetSensitive(log2d_y,TRUE);
		  }
		  else {
			XtSetSensitive(log2d_x,FALSE);
			XtSetSensitive(log2d_y,FALSE);
			XtVaSetValues(log2d_x, XtNlabel, "Linear", NULL);
			XtVaSetValues(log2d_y, XtNlabel, "Linear", NULL);
		}
*/			
		if (GRAPHSPEC==CONTOR_2D) {
			XtVaSetValues(text2_w[4],XtNstring,gcvt(CTRDF1[NOWC],DISPPREC,str),NULL);
			CTRDF1[NOWC]=atof(str);
			XawTextSetInsertionPoint(text2_w[4],strlen(str));
			XtVaSetValues(text2_w[5],XtNstring,gcvt(CTRDF2[NOWC],DISPPREC,str),NULL);
			CTRDF2[NOWC]=atof(str);
			XawTextSetInsertionPoint(text2_w[5],strlen(str));
			XtVaSetValues(text2_w[6],XtNstring,gcvt(CTRDDF[NOWC],DISPPREC,str),NULL);
			CTRDDF[NOWC]=atof(str);
			XawTextSetInsertionPoint(text2_w[6],strlen(str));
			XtVaSetValues(text2_w[7],XtNstring,gcvt((double)CTRDND[NOWC],10,str),NULL);
			XawTextSetInsertionPoint(text2_w[7],strlen(str));
			if (label_cont==0) {
				label_cont=1;
				for (i=4;i<8;i++) XtSetSensitive(text2_w[i],True);
				XtSetSensitive(check2_button[2],True);
				XtSetSensitive(check2_button[3],True);
			}
		  }	
		  else if (label_cont) {
			label_cont=0;
			for (i=4;i<8;i++) XtSetSensitive(text2_w[i],False);
			XtSetSensitive(check2_button[2],False);
			XtSetSensitive(check2_button[3],False);
			for (i=4;i<8;i++) {
				if (focus2_w==text2_w[i]) break;
			}
			if (i<8) {
				XtVaSetValues(focus2_w, XtNdisplayCaret, False, NULL);
				focus2_w=text2_w[0];
				XtSetKeyboardFocus(scale2_dialog, focus2_w);
				XtVaSetValues(focus2_w, XtNdisplayCaret, True, NULL);
			}
		}
		XtPopup(scale2_popup,XtGrabNonexclusive);
		fix_window(scale2_popup,x,y);
	  }
	  else {
/*		XtVaSetValues(scale3_popup,XtNx,x,XtNy,y,NULL);	*/
		XtVaSetValues(text3_w[0],XtNstring,gcvt(SC3DX1[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[0],strlen(str));
		XtVaSetValues(text3_w[1],XtNstring,gcvt(SC3DX2[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[1],strlen(str));
		XtVaSetValues(text3_w[2],XtNstring,gcvt(SC3DY1[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[2],strlen(str));
		XtVaSetValues(text3_w[3],XtNstring,gcvt(SC3DY2[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[3],strlen(str));
		XtVaSetValues(text3_w[4],XtNstring,gcvt(SC3DZ1[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[4],strlen(str));
		XtVaSetValues(text3_w[5],XtNstring,gcvt(SC3DZ2[NOWS],DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text3_w[5],strlen(str));
		if (threed_mode) {
			XtVaSetValues(text3_w[6],XtNstring,gcvt(SC3DTH[NOWS],DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text3_w[6],strlen(str));
			XtVaSetValues(text3_w[7],XtNstring,gcvt(SC3DPH[NOWS],DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text3_w[7],strlen(str));
			XtSetSensitive(text3_w[6],True);
			XtSetSensitive(text3_w[7],True);
			XtSetSensitive(check3_button[3],True);
		  }
		  else {
			XtSetSensitive(text3_w[6],False);
			XtSetSensitive(text3_w[7],False);
			XtSetSensitive(check3_button[3],False);
		}
		if (GRAPHSPEC==CONTOR_3D) {
			XtVaSetValues(text3_w[8],XtNstring,gcvt(CTRDF1[NOWC],DISPPREC,str),NULL);
			CTRDF1[NOWC]=atof(str);
			XawTextSetInsertionPoint(text3_w[8],strlen(str));
			XtVaSetValues(text3_w[9],XtNstring,gcvt(CTRDF2[NOWC],DISPPREC,str),NULL);
			CTRDF2[NOWC]=atof(str);
			XawTextSetInsertionPoint(text3_w[9],strlen(str));
			XtVaSetValues(text3_w[10],XtNstring,gcvt(CTRDDF[NOWC],DISPPREC,str),NULL);
			CTRDDF[NOWC]=atof(str);
			XawTextSetInsertionPoint(text3_w[10],strlen(str));
			XtVaSetValues(text3_w[11],XtNstring,gcvt((double)CTRDND[NOWC],10,str),NULL);
			XawTextSetInsertionPoint(text3_w[11],strlen(str));
			XtVaSetValues(text3_w[12],XtNstring,gcvt(CTRDT0[NOWC],DISPPREC,str),NULL);
			CTRDT0[NOWC]=atof(str);
			XawTextSetInsertionPoint(text3_w[12],strlen(str));
			XtVaSetValues(text3_w[13],XtNstring,gcvt((double)CTRDNUM[NOWC],10,str),NULL);
			XawTextSetInsertionPoint(text3_w[13],strlen(str));
//		printf("aaa %d %d %d %d\n",GRAPHSPEC,SURFACEMODE,label_cont3d,CTRDDIM[NOWC]);
			if (SURFACEMODE==0) {
				if (label_cont3d==0 || label_cont3d==3 || label_cont3d==4) {
					if (CTRDDIM[NOWC]%10) {
						label_cont3d=1;
						for (i=8;i<XYZPOS;i++) XtSetSensitive(text3_w[i],True);
						for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],True);
					  }
					  else {
						label_cont3d=2;
						for (i=8;i<XYZPOSM1;i++) XtSetSensitive(text3_w[i],True);
					}
						for (i=4;i<CHECKNUM3D;i++) XtSetSensitive(check3_button[i],True);
				  }
				  else if (label_cont3d==1 && CTRDDIM[NOWC]%10==0) {
					label_cont3d=2;
					XtSetSensitive(text3_w[XYZPOSM1],False);
#ifdef OSX
					XtVaSetValues(text3_xyz[xyz_num], XtNstate, False, NULL);
					for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
					XtVaSetValues(text3_xyz[xyz_num], XtNstate, True, NULL);
#else
					for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
#endif
				  }
				  else if (label_cont3d==2 && CTRDDIM[NOWC]%10) {
					label_cont3d=1;
					XtSetSensitive(text3_w[XYZPOSM1],True);
					for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],True);
				}
				if (CTRDDIM[NOWC]%10) 	i=CTRDDIM[NOWC]-1;
					else	 			i=CTRDDIM[NOWC]/10-1;
/*				if (xyz_num!=i) {*/
					xyz_num=i;		/*  Radio Button change call former button  */ 
					XtVaSetValues(text3_xyz[xyz_num], XtNstate, True, NULL);
/*				}*/
			  }
			  else if (SURFACEMODE<0) {
				if (label_cont3d<=3) {
					label_cont3d=4;
					for (i=8;i<XYZPOSM1-1;i++) XtSetSensitive(text3_w[i],True);
					for (i=XYZPOSM1-1;i<XYZPOSM1+1;i++) XtSetSensitive(text3_w[i],False);
					for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
					for (i=4;i<6;i++) XtSetSensitive(check3_button[i],True);
					for (i=6;i<CHECKNUM3D;i++) XtSetSensitive(check3_button[i],False);
				}
			}
		  }	
		  else if (GRAPHSPEC==ISOSURF) {
			label_cont3d=3;
			false_text3d(12);
			XtVaSetValues(text3_w[12],XtNstring,gcvt(CTRDT0[NOWC],DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text3_w[12],strlen(str));
			CTRDT0[NOWC]=atof(str);
			XtVaSetValues(text3_w[8],XtNstring,NULL,NULL);
			XtVaSetValues(text3_w[9],XtNstring,NULL,NULL);
			XtVaSetValues(text3_w[10],XtNstring,NULL,NULL);
			XtVaSetValues(text3_w[11],XtNstring,NULL,NULL);
			XtVaSetValues(text3_w[13],XtNstring,NULL,NULL);
			XtSetSensitive(text3_w[12],True);
			XtSetSensitive(check3_button[6],True);
		  }
		  else if (label_cont3d) {
			label_cont3d=0;
			false_text3d(-1);
		}
		if (SURFACEMODE>0 && SURFACECOLOR>0) {
			for (i=0;i<5;i++) XtSetSensitive(text_lit[i],True);
			for (i=0;i<7;i++) XtSetSensitive(lradio[i],True);
			if (light_num!=SURFACECOLOR) XtVaSetValues(lradio[SURFACECOLOR-1], XtNstate, True, NULL);
			light_num=SURFACECOLOR;		/*  Radio Button change call former button  */ 
			XtVaSetValues(text_lit[0],XtNstring,gcvt(LIGHTALT,DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text_lit[0],strlen(str));
			XtVaSetValues(text_lit[1],XtNstring,gcvt(LIGHTAZIM,DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text_lit[1],strlen(str));
			XtVaSetValues(text_lit[2],XtNstring,gcvt(LIGHTAMB,DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text_lit[2],strlen(str));
			XtVaSetValues(text_lit[3],XtNstring,gcvt(LIGHTDIFF,DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text_lit[3],strlen(str));
			XtVaSetValues(text_lit[4],XtNstring,gcvt(LIGHTNSPEC,DISPPREC,str),NULL);
			XawTextSetInsertionPoint(text_lit[4],strlen(str));
		  }
		  else {
			false_textlight();
		}
		XtPopup(scale3_popup,XtGrabNonexclusive);
		fix_window(scale3_popup,x,y);
	}
	scale_on=1;
}

static void scale_reset(Widget w,Widget shell)
{
	int i;

	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
		XtPopdown(scale2_popup);
		SCALE2DMODE[NOWS]=0;		scale2d_mask=-1;
		if (GRAPHSPEC==CONTOR_2D) {
			CONTOR2DMODE[NOWC]=0;	cont2d_mask=-1;
		}
		for (i=0;i<CHECKNUM2D;i++) {
			if (scheck2[i]) XtVaSetValues(check2_button[i], XtNbitmap, blank_bmp, NULL);
			scheck2[i]=0;
		}
	  }
	  else {
		XtPopdown(scale3_popup);
		SCALE3DMODE[NOWS]=0;		scale3d_mask=-1;
		if (GRAPHSPEC==CONTOR_3D || GRAPHSPEC==ISOSURF) {
			CONTOR3DMODE[NOWC]=0;	cont3d_mask=-1;
		}
		for (i=0;i<CHECKNUM3D;i++) {
			if (scheck3[i]) XtVaSetValues(check3_button[i], XtNbitmap, blank_bmp, NULL);
			scheck3[i]=0;
		}
	}
	XtSetSensitive(scale_button,TRUE);
}

static void scale_window()
{
	if (scale_on==0) return;
	if (scale_output()) BEEP();
	scale_on=0;
}

static void scale_cancel(Widget w,Widget shell)
{
	XtPopdown(shell);
	XtSetSensitive(scale_button,TRUE);
	scale_on=0;
}

static void scale_proc(Widget w,Widget text)
{
	double x1,x2,y1,y2,z1,z2,ph,th,df;
	int nd,nn;
	String num;

	scale_on=0;
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
/*		x1=SC2DX1;	x2=SC2DX2;	y1=SC2DY1;	y2=SC2DY2;		*/
		scale2d_mask=0;
		if (scheck2[0]) scale2d_mask|=1;
		if (scheck2[1]) scale2d_mask|=2;
		XtPopdown(scale2_popup);
		XtVaGetValues(text2_w[0], XtNstring, &num, NULL);
		x1=atof(num);
		if (x1!=SC2DX1[NOWS] || scheck2[0]) {
			if (x1!=SC2DX1[NOWS]) scale_on=1;
			SC2DX1[NOWS]=x1;
			SCALE2DMODE[NOWS]|=1;
		}
		XtVaGetValues(text2_w[1], XtNstring, &num, NULL);
		x2=atof(num);
		if (x2!=SC2DX2[NOWS] || scheck2[0]) {
			if (x2!=SC2DX2[NOWS]) scale_on=1;
			SC2DX2[NOWS]=x2;
			SCALE2DMODE[NOWS]|=1;
		}
		XtVaGetValues(text2_w[2], XtNstring, &num, NULL);
		y1=atof(num);
		if (y1!=SC2DY1[NOWS] || scheck2[1]) {
			if (y1!=SC2DY1[NOWS]) scale_on=1;
			SC2DY1[NOWS]=y1;
			SCALE2DMODE[NOWS]|=2;
		}
		XtVaGetValues(text2_w[3], XtNstring, &num, NULL);
		y2=atof(num);
		if (y2!=SC2DY2[NOWS] || scheck2[1]) {
			if (y2!=SC2DY2[NOWS]) scale_on=1;
			SC2DY2[NOWS]=y2;
			SCALE2DMODE[NOWS]|=2;
		}

		nn=0;
		if (logcheck2[0]) nn=1;
		if ((LOG2DMODE[NOWS]&1)!=nn || scheck2[0]) {
			if ((LOG2DMODE[NOWS]&1)!=nn) scale_on=1;
			LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfe)|(nn&1);
			SCALE2DMODE[NOWS]|=1;
		}
		nn=0;
		if (logcheck2[1]) nn=2;
		if ((LOG2DMODE[NOWS]&2)!=nn || scheck2[1]) {
			if ((LOG2DMODE[NOWS]&2)!=nn) scale_on=1;
			LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfd)|(nn&2);
			SCALE2DMODE[NOWS]|=2;
		}
/*
		if (log2d_mode&8) {
			nn=0;
			if (logcheck2[0]) nn=1;
			if ((LOG2DMODE[NOWS]&1)!=nn || scheck2[0]) {
				LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfe)|(nn&1);
				SCALE2DMODE[NOWS]|=1;
			}
			nn=0;
			if (logcheck2[1]) nn=2;
			if ((LOG2DMODE[NOWS]&2)!=nn || scheck2[1]) {
				LOG2DMODE[NOWS]=(LOG2DMODE[NOWS]&0xfd)|(nn&2);
				SCALE2DMODE[NOWS]|=2;
			}
		  }
		  else {
			logcheck2[0]=logcheck2[1]=0;
			if ((LOG2DMODE[NOWS]&1)!=0 || scheck2[0]) {
				LOG2DMODE[NOWS]&=0xfe;
				SCALE2DMODE[NOWS]|=1;
			}
			if ((LOG2DMODE[NOWS]&2)!=0 || scheck2[1]) {
				LOG2DMODE[NOWS]&=0xfd;
				SCALE2DMODE[NOWS]|=2;
			}
		}
*/
		if (GRAPHSPEC==CONTOR_2D) {
/*			z1=CTRDF1;	z2=CTRDF2;	df=CTRDDF;	nd=CTRDND;		*/
			cont2d_mask=0;
			if (scheck2[2]) cont2d_mask|=7;
			XtVaGetValues(text2_w[4], XtNstring, &num, NULL);
			z1=atof(num);
			if (z1!=CTRDF1[NOWC] || scheck2[2]) {
				if (z1!=CTRDF1[NOWC]) scale_on=1;
				CTRDF1[NOWC]=z1;
				CONTOR2DMODE[NOWC]|=2;
			}
			XtVaGetValues(text2_w[5], XtNstring, &num, NULL);
			z2=atof(num);
			if (z2!=CTRDF2[NOWC] || scheck2[2]) {
				if (z2!=CTRDF2[NOWC]) scale_on=1;
				CTRDF2[NOWC]=z2;
				CONTOR2DMODE[NOWC]|=2;
			}
			XtVaGetValues(text2_w[7], XtNstring, &num, NULL);
			nd=atoi(num);
			XtVaGetValues(text2_w[6], XtNstring, &num, NULL);
			df=atof(num);
			if ((nd!=CTRDND[NOWC] && df==CTRDDF[NOWC]) || (scheck2[2] && nd>0)) {
				if (nd!=CTRDND[NOWC]) scale_on=1;
				CTRDND[NOWC]=nd;
				CONTOR2DMODE[NOWC]|=4;
			  }
			  else if (nd!=CTRDND[NOWC] || df!=CTRDDF[NOWC] || scheck2[3]) {
				if (nd!=CTRDND[NOWC] || df!=CTRDDF[NOWC]) scale_on=1;
				CTRDDF[NOWC]=df;
				CONTOR2DMODE[NOWC]|=1;		CONTOR2DMODE[NOWC]&=0xfd;
			}
		}
	  }
	  else {
/*		x1=SC3DX1;	x2=SC3DX2;	y1=SC3DY1;	y2=SC3DY2;
		z1=SC3DZ1;	z2=SC3DZ2;	ph=SC3DPH;	th=SC3DTH;		*/
		scale3d_mask=0;
		if (scheck3[0]) scale3d_mask|=1;
		if (scheck3[1]) scale3d_mask|=2;
		if (scheck3[2]) scale3d_mask|=4;
		if (scheck3[3]) scale3d_mask|=8;
		XtPopdown(scale3_popup);
		XtVaGetValues(text3_w[0], XtNstring, &num, NULL);
		x1=atof(num);
		if (x1!=SC3DX1[NOWS] || scheck3[0]) {
			if (x1!=SC3DX1[NOWS]) scale_on=1;
			SC3DX1[NOWS]=x1;
			SCALE3DMODE[NOWS]|=1;
		}
		XtVaGetValues(text3_w[1], XtNstring, &num, NULL);
		x2=atof(num);
		if (x2!=SC3DX2[NOWS] || scheck3[0]) {
			if (x2!=SC3DX2[NOWS]) scale_on=1;
			SC3DX2[NOWS]=x2;
			SCALE3DMODE[NOWS]|=1;
		}
		XtVaGetValues(text3_w[2], XtNstring, &num, NULL);
		y1=atof(num);
		if (y1!=SC3DY1[NOWS] || scheck3[1]) {
			if (y1!=SC3DY1[NOWS]) scale_on=1;
			SC3DY1[NOWS]=y1;
			SCALE3DMODE[NOWS]|=2;
		}
		XtVaGetValues(text3_w[3], XtNstring, &num, NULL);
		y2=atof(num);
		if (y2!=SC3DY2[NOWS] || scheck3[1]) {
			if (y2!=SC3DY2[NOWS]) scale_on=1;
			SC3DY2[NOWS]=y2;
			SCALE3DMODE[NOWS]|=2;
		}
		XtVaGetValues(text3_w[4], XtNstring, &num, NULL);
		z1=atof(num);
		if (z1!=SC3DZ1[NOWS] || scheck3[2]) {
			if (z1!=SC3DZ1[NOWS]) scale_on=1;
			SC3DZ1[NOWS]=z1;
			SCALE3DMODE[NOWS]|=4;
		}
		XtVaGetValues(text3_w[5], XtNstring, &num, NULL);
		z2=atof(num);
		if (z2!=SC3DZ2[NOWS] || scheck3[2]) {
			if (z2!=SC3DZ2[NOWS]) scale_on=1;
			SC3DZ2[NOWS]=z2;
			SCALE3DMODE[NOWS]|=4;
		}
		XtVaGetValues(text3_w[6], XtNstring, &num, NULL);
		th=atof(num);
		if (th!=SC3DTH[NOWS] || scheck3[3]) {
			if (th!=SC3DTH[NOWS]) scale_on=1;
			SC3DTH[NOWS]=th;
			SCALE3DMODE[NOWS]|=8;
		}
		XtVaGetValues(text3_w[7], XtNstring, &num, NULL);
		ph=atof(num);
		if (ph!=SC3DPH[NOWS] || scheck3[3]) {
			if (ph!=SC3DPH[NOWS]) scale_on=1;
			SC3DPH[NOWS]=ph;
			SCALE3DMODE[NOWS]|=8;
			put_angle();
		}
		if (GRAPHSPEC==CONTOR_3D) {
/*			z1=CTRDF1;	z2=CTRDF2;	df=CTRDDF;	nd=CTRDND;		*/
			cont3d_mask=0;
			if (scheck3[4]) cont3d_mask|=7;
			if (scheck3[5]) cont3d_mask|=15;
			if (scheck3[6]) cont3d_mask|=31;
			XtVaGetValues(text3_w[8], XtNstring, &num, NULL);
			z1=atof(num);
			if (z1!=CTRDF1[NOWC] || scheck3[4]) {
				if (z1!=CTRDF1[NOWC]) scale_on=1;
				CTRDF1[NOWC]=z1;
				CONTOR3DMODE[NOWC]|=2;
			}
			XtVaGetValues(text3_w[9], XtNstring, &num, NULL);
			z2=atof(num);
			if (z2!=CTRDF2[NOWC] || scheck3[4]) {
				if (z2!=CTRDF2[NOWC]) scale_on=1;
				CTRDF2[NOWC]=z2;
				CONTOR3DMODE[NOWC]|=2;
			}
			XtVaGetValues(text3_w[11], XtNstring, &num, NULL);
			nd=atoi(num);
			XtVaGetValues(text3_w[10], XtNstring, &num, NULL);
			df=atof(num);
			if ((nd!=CTRDND[NOWC] && df==CTRDDF[NOWC]) || (scheck3[4] && nd>0)) {
				if (nd!=CTRDND[NOWC]) scale_on=1;
				CTRDND[NOWC]=nd;
				CONTOR3DMODE[NOWC]|=4;
			  }
			  else if (nd!=CTRDND[NOWC] || df!=CTRDDF[NOWC] || scheck3[5]) {
				if (nd!=CTRDND[NOWC] || df!=CTRDDF[NOWC]) scale_on=1;
				CTRDDF[NOWC]=df;
				CONTOR3DMODE[NOWC]|=1;		CONTOR3DMODE[NOWC]&=0xfd;
			}
			XtVaGetValues(text3_w[12], XtNstring, &num, NULL);
			x1=atof(num);
			if (x1!=CTRDT0[NOWC] || scheck3[6]) {
				if (x1!=CTRDT0[NOWC]) scale_on=1;
				CTRDT0[NOWC]=x1;
				CONTOR3DMODE[NOWC]|=8;
			}
			XtVaGetValues(text3_w[13], XtNstring, &num, NULL);
			nn=atof(num);
			if (nn!=CTRDNUM[NOWC] || scheck3[6]) {
				if (nn!=CTRDNUM[NOWC]) scale_on=1;
				CTRDNUM[NOWC]=nn;
				CONTOR3DMODE[NOWC]|=16;
			}
			if (CTRDDIM[NOWC]<10 && CTRDDIM[NOWC]!=(xyz_num+1) || scheck3[6]) {
				if (CTRDDIM[NOWC]<10) scale_on=1;
				CTRDDIM[NOWC]=xyz_num+1;
				CONTOR3DMODE[NOWC]|=8;
			}
		  }
		  else if (GRAPHSPEC==ISOSURF) {
			cont3d_mask=0;
			if (scheck3[6]) cont3d_mask|=63;
			XtVaGetValues(text3_w[12], XtNstring, &num, NULL);
			x1=atof(num);
			if (x1!=CTRDT0[NOWC] || scheck3[6]) {
				if (x1!=CTRDT0[NOWC]) scale_on=1;
				CTRDT0[NOWC]=x1;
				CONTOR3DMODE[NOWC]=32;
			}
		}
		if (SURFACEMODE>0 && SURFACECOLOR>0) {
			if (light_num!=SURFACECOLOR) {
				scale_on=1;
				SURFACECOLOR=light_num;
				LIGHTINGMODE|=4;
			}
			XtVaGetValues(text_lit[0], XtNstring, &num, NULL);
			x1=atof(num);
			if (x1!=LIGHTALT) {
				scale_on=1;
				LIGHTALT=x1;
				LIGHTINGMODE|=1;
			}
			XtVaGetValues(text_lit[1], XtNstring, &num, NULL);
			x2=atof(num);
			if (x2!=LIGHTAZIM) {
				scale_on=1;
				LIGHTAZIM=x2;
				LIGHTINGMODE|=1;
			}
			XtVaGetValues(text_lit[2], XtNstring, &num, NULL);
			x1=atof(num);
			if (x1!=LIGHTAMB) {
				scale_on=1;
				LIGHTAMB=x1;
				LIGHTINGMODE|=2;
			}
			XtVaGetValues(text_lit[3], XtNstring, &num, NULL);
			x2=atof(num);
			if (x2!=LIGHTDIFF) {
				scale_on=1;
				LIGHTDIFF=x2;
				LIGHTINGMODE|=2;
			}
			XtVaGetValues(text_lit[4], XtNstring, &num, NULL);
			x2=atof(num);
			if (x2!=LIGHTNSPEC) {
				scale_on=1;
				LIGHTNSPEC=x2;
				LIGHTINGMODE|=2;
			}
		}
	}
	XtSetSensitive(scale_button,TRUE);
}

void updown_key_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	char *s=XtName(w),c=*(vector[0]);
	int n,nmax,nmax1,nmax2,nm1,nm2,nb;

	n=s[5]-'0';
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) { 
		if (GRAPHSPEC==CONTOR_2D) nmax=8;
			else 				  nmax=4;
	  }
	  else {
		if (GRAPHSPEC==CONTOR_3D || GRAPHSPEC==ISOSURF) {
			nmax=14;
			if (n>9) n-='a'-'9'-1;
			if (label_cont3d==2 || GRAPHSPEC==ISOSURF) nmax=13;
		  		else if (label_cont3d==4) nmax=12;
		  }
		  else 				  nmax=8;
	}
	nmax1=nmax-1;	nmax2=nmax-2;
	nm1=nmax-1;		nm2=nmax-2;	
 	if ((GRAPHSPEC==CONTOR_3D  && label_cont3d==2) || GRAPHSPEC==ISOSURF) {
		nm1=nmax-2;		nm2=nmax-1;
	}
	XtVaSetValues(w, XtNdisplayCaret, False, NULL);
	if (c=='2') n+=1;
		else if (c=='3') n+=nmax-1;
		else if (c=='1') {
			if (n<nm2) n+=2;	
				else if (n==nm2) n=1;
				else n=0;
		}
		else {
			if (n>=2) n+=nmax2;	
				else if (n==1) n=nm2;
				else n=nm1;
	}
	n%=nmax;
	if (GRAPHSPEC==ISOSURF) {
		if (n==8) n=12;
		  else if (n==11) n=7;
		  else if (n==10) n=6;
		  else if (n==9) n=0;
	}
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
		focus2_w=text2_w[n];
		XtSetKeyboardFocus(scale2_dialog, focus2_w);
		XtVaSetValues(focus2_w, XtNdisplayCaret, True, NULL);
	  }
	  else {
		focus3_w=text3_w[n];
		XtSetKeyboardFocus(scale3_dialog, focus3_w);
		XtVaSetValues(focus3_w, XtNdisplayCaret, True, NULL);
	}
}

void mouse_on_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
		XtVaSetValues(focus2_w, XtNdisplayCaret, False, NULL);
/*			XawTextUnsetSelection(focus2_w);	*/
		XtSetKeyboardFocus(scale2_dialog, w);
		XtVaSetValues(w, XtNdisplayCaret, True, NULL);
		focus2_w=w;
	  }
	  else {
		XtVaSetValues(focus3_w, XtNdisplayCaret, False, NULL);
/*		XawTextUnsetSelection(focus3_w);	*/
		XtSetKeyboardFocus(scale3_dialog, w);
		XtVaSetValues(w, XtNdisplayCaret, True, NULL);
		focus3_w=w;
	}
}

void check_cb(Widget w, XtPointer pnt, XtPointer dmy)
{
	int no=(int)pnt,nn;

	nn=no>>4;	no&=0xf;
	XtVaSetValues(w, XtNbitmap, blank_bmp, NULL);
	if (no==0) {
		scheck2[nn] = !scheck2[nn];
		if (scheck2[nn]) XtVaSetValues(w, XtNbitmap, check_bmp, NULL);
		if (scheck2[2] && scheck2[3]) {
			nn=5-nn;
			scheck2[nn] = !scheck2[nn];
			XtVaSetValues(check2_button[nn], XtNbitmap, blank_bmp, NULL);
		}
	  }
	  else {
		scheck3[nn] = !scheck3[nn];
		if (scheck3[nn]) XtVaSetValues(w, XtNbitmap, check_bmp, NULL);
		if (scheck3[4] && scheck3[5]) {
			nn=9-nn;
			scheck3[nn] = !scheck3[nn];
			XtVaSetValues(check3_button[nn], XtNbitmap, blank_bmp, NULL);
		}
	}
}

void check_all(Widget w, XtPointer pnt, XtPointer dmy)
{
	int no=(int)pnt,nn,i;

	nn=no>>4;	no&=0xf;
	if (no==0) {
		for (i=0;i<2;i++) {
			scheck2[i] = !0;
			XtVaSetValues(check2_button[i], XtNbitmap, check_bmp, NULL);
		}
		if (label_cont) {
			if (scheck2[2]==0 && scheck2[3]==0) {
				scheck2[3] = !0;
				XtVaSetValues(check2_button[3], XtNbitmap, check_bmp, NULL);
			}
		}
	  }
	  else {
		for (i=0;i<4;i++) {
			scheck3[i] = !0;
			XtVaSetValues(check3_button[i], XtNbitmap, check_bmp, NULL);
		}
		if (label_cont3d) {
			if (scheck3[4]==0 && scheck3[5]==0 && label_cont3d!=3) {
				scheck3[5] = !0;
				XtVaSetValues(check3_button[5], XtNbitmap, check_bmp, NULL);
			}
			scheck3[6] = !0;
			XtVaSetValues(check3_button[6], XtNbitmap, check_bmp, NULL);
		}
	}
}

void log2d_cb(Widget w, XtPointer pnt, XtPointer dmy)
{
	double a1,a2;
	int no=(int)pnt;
	String num;
	char str[15];

	logcheck2[no] = !logcheck2[no];
	if (logcheck2[no]) 	{
		XtVaGetValues(text2_w[2*no]  , XtNstring, &num, NULL);
		a1=atof(num);
		if (a1<=0) a1=-30;
			else   a1=log10(a1);
		XtVaGetValues(text2_w[2*no+1], XtNstring, &num, NULL);
		a2=atof(num);
		if (a2<=0) a2=-29;
			else   a2=log10(a2);
		XtVaSetValues(text2_w[2*no],XtNstring,gcvt(a1,DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[2*no],strlen(str));
		XtVaSetValues(text2_w[2*no+1],XtNstring,gcvt(a2,DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[2*no+1],strlen(str));
		XtVaSetValues(w, XtNlabel, "Log", NULL);
	  }
	  else {
		XtVaGetValues(text2_w[2*no]  , XtNstring, &num, NULL);
		a1=pow(10.0,atof(num));
		XtVaGetValues(text2_w[2*no+1], XtNstring, &num, NULL);
		a2=pow(10.0,atof(num));
/*		if (a1/a2<0.0001) a1 = 0;	*/
		XtVaSetValues(text2_w[2*no],XtNstring,gcvt(a1,DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[2*no],strlen(str));
		XtVaSetValues(text2_w[2*no+1],XtNstring,gcvt(a2,DISPPREC,str),NULL);
		XawTextSetInsertionPoint(text2_w[2*no+1],strlen(str));
		XtVaSetValues(w, XtNlabel, "Linear", NULL);
	}
}

void delete_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	if ((GRAPHSPEC&FRAME_MASK)==FRAME_2D) {
		XtPopdown(scale2_popup);
	  }
	  else {
	    XtPopdown(scale3_popup);
	}
	XtSetSensitive(scale_button,TRUE);
}
/*
void lbtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	int n;
	Boolean stat;

	n=s[4]-'1';
	if (s[2]=='x') {
		XtVaGetValues(log2x[n],XtNstate,&stat,NULL);
		if (stat==True) log2_num=(log2_num&2)|n;
	  }
	  else if (s[2]=='y') {
		XtVaGetValues(log2y[n],XtNstate,&stat,NULL);
		if (stat==True) log2_num=(log2_num&1)|(n<<1);
	}
}
*/
void set_scale_translations(void)
{
	static XtActionsRec actions[]={
		{ "scalewindow" , (XtActionProc)scale_window},
		{ "scaleproc"   , (XtActionProc)scale_proc},
		{ "updown_key"  , (XtActionProc)updown_key_cb},
		{ "mouse_on"    , (XtActionProc)mouse_on_cb},
		{ "delete_win"	, (XtActionProc)delete_cb},
	};

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Unmap>: scalewindow()\n\
						<Message>WM_PROTOCOLS: delete_win()");

	trans = XtParseTranslationTable("#override\n\
						<Key>KP_Enter: scaleproc()\n\
						<Key>Return: scaleproc()\n\
						Ctrl<Key>M: scaleproc()\n\
						Ctrl<Key>J: scaleproc()\n\
						<Key>Up:   updown_key(0)\n\
						<Key>Down: updown_key(1)\n\
						Shift<Key>Tab: updown_key(3)\n\
						<Key>Tab: updown_key(2)\n\
						<Btn1Down>,<Btn1Up>: mouse_on()\n\
						Ctrl<Key>D: delete_chara() delete-next-character()\n\
						Ctrl<Key>H: delete_chara() delete-previous-character()\n\
						<Key>BackSpace: delete_chara() delete-previous-character()\n\
						<Key>Delete: delete_chara() delete-next-character()\n\
						<Key>Left: backward-character()\n\
						<Key>Right: forward-character()\n\
						<Key>: delete_chara() insert-char()\n\
						");

	trans2 = XtParseTranslationTable("#override\n\
						<EnterWindow>: highlight(Always)\n\
						<LeaveWindow>: unhighlight()\n\
						<Btn1Down>,<Btn1Up>: set() notify()\n\
						");

	trans3 = XtParseTranslationTable("#override\n\
						<Btn1Down>,<Btn1Up>: set() notify()\n\
						");
}

static void create_scale2_dialog(Widget form)
{
	Widget label1,label2,label3,label4,button1,button2,button3;
	Widget label5,label6,label7,label8;
	static Atom wm_delete_window;
	static char *onofflab[2]={"On","Off"};
	Dimension wd;
	int i;

	scale2_popup=XtVaCreatePopupShell("scale2_popup",
						transientShellWidgetClass,form,XtNtitle,"2D Scaling Dialog",
						XtNtranslations, trans1,
						NULL);

	scale2_dialog = XtVaCreateManagedWidget("form20", formWidgetClass, scale2_popup,
						XtNborderWidth, 0,
						NULL);

	label1 = XtVaCreateManagedWidget("label20", labelWidgetClass, scale2_dialog,
						XtNlabel, "Xmin",
						XtNborderWidth, 0,
  						NULL);
	text2_w[0] = XtVaCreateManagedWidget("text20", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						NULL);

	label2 = XtVaCreateManagedWidget("label21", labelWidgetClass, scale2_dialog,
						XtNlabel, "Xmax",
						XtNborderWidth, 0,
						XtNfromHoriz, text2_w[0],
						NULL);

	text2_w[1] = XtVaCreateManagedWidget("text21", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	log2d_x = XtVaCreateManagedWidget("log2x", commandWidgetClass, scale2_dialog,
						XtNlabel, "Linear",
						XtNfromHoriz, text2_w[1],
						NULL);
	XtAddCallback(log2d_x, XtNcallback, log2d_cb, (XtPointer)0);

	check2_button[0] = XtVaCreateManagedWidget("check21", commandWidgetClass, scale2_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromHoriz, log2d_x,
						XtNhorizDistance, 10,
						XtNborderWidth, 1, 
						NULL);
	XtAddCallback(check2_button[0], XtNcallback, check_cb, (XtPointer)0x00);

	label3 = XtVaCreateManagedWidget("label22", labelWidgetClass, scale2_dialog,
						XtNlabel, "Ymin",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						NULL);

	text2_w[2] = XtVaCreateManagedWidget("text22", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label3,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label4 = XtVaCreateManagedWidget("label23", labelWidgetClass, scale2_dialog,
						XtNlabel, "Ymax",
						XtNborderWidth, 0,
						XtNfromHoriz, text2_w[2],
						XtNfromVert, label1,
						NULL);

	text2_w[3] = XtVaCreateManagedWidget("text23", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label4,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
                        NULL);

	log2d_y = XtVaCreateManagedWidget("log2y", commandWidgetClass, scale2_dialog,
						XtNlabel, "Linear",
						XtNfromVert, label1,
						XtNfromHoriz, text2_w[3],
						NULL);
	XtAddCallback(log2d_y, XtNcallback, log2d_cb, (XtPointer)1);
	XtVaGetValues(log2d_y,XtNwidth,&wd,NULL);

	check2_button[1] = XtVaCreateManagedWidget("check22", commandWidgetClass, scale2_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label1,
						XtNfromHoriz, log2d_y,
						XtNhorizDistance, 10,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check2_button[1], XtNcallback, check_cb, (XtPointer)0x10);

	label5 = XtVaCreateManagedWidget("label24", labelWidgetClass, scale2_dialog,
						XtNlabel, "Fmin",
						XtNborderWidth, 0,
						XtNfromVert, label3,
						NULL);

	text2_w[4] = XtVaCreateManagedWidget("text24", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label5,
						XtNfromVert, label3,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label6 = XtVaCreateManagedWidget("label25", labelWidgetClass, scale2_dialog,
						XtNlabel, "Fmax",
						XtNborderWidth, 0,
						XtNfromHoriz, text2_w[4],
						XtNfromVert, label3,
						NULL);

	text2_w[5] = XtVaCreateManagedWidget("text25", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label6,
						XtNfromVert, label3,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check2_button[2] = XtVaCreateManagedWidget("check23", commandWidgetClass, scale2_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label3,
						XtNfromHoriz, text2_w[5],
						XtNhorizDistance, wd+16,
						XtNborderWidth, 1, 
						NULL);
	XtAddCallback(check2_button[2], XtNcallback, check_cb, (XtPointer)0x20);

	label7 = XtVaCreateManagedWidget("label26", labelWidgetClass, scale2_dialog,
						XtNlabel, "Fdiv",
						XtNborderWidth, 0,
						XtNfromVert, label6,
						NULL);

	text2_w[6] = XtVaCreateManagedWidget("text26", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label7,
						XtNfromVert, label6,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label8 = XtVaCreateManagedWidget("label27", labelWidgetClass, scale2_dialog,
						XtNlabel, "Ncon",
						XtNborderWidth, 0,
						XtNfromHoriz, text2_w[6],
						XtNfromVert, label5,
						NULL);

	text2_w[7] = XtVaCreateManagedWidget("text27", asciiTextWidgetClass, scale2_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label8,
						XtNfromVert, label5,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check2_button[3] = XtVaCreateManagedWidget("check24", commandWidgetClass, scale2_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label5,
						XtNfromHoriz, text2_w[7],
						XtNhorizDistance, wd+16+(INPUTLONG-INPUTSHORT),
						XtNborderWidth, 1, 
						NULL);
	XtAddCallback(check2_button[3], XtNcallback, check_cb, (XtPointer)0x30);

	label4=label7;
/*
	label4 = XtVaCreateManagedWidget("llog2x", labelWidgetClass, scale2_dialog,
						XtNlabel, "Log X",
						XtNborderWidth, 0,
						XtNfromVert, label7,
						XtNvertDistance, 10,
						NULL);

	log2x[0]=XtVaCreateManagedWidget("l2x01", toggleWidgetClass, scale2_dialog, 
						XtNfromHoriz, label4, 
						XtNfromVert, label7,
						XtNvertDistance, 10,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(log2x[0], XtNcallback, lbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(log2x[0], XtNstate, True, NULL);

	log2x[1]=XtVaCreateManagedWidget("l2x02", toggleWidgetClass, scale2_dialog, 
						XtNfromHoriz, log2x[0], 
						XtNfromVert, label7,
						XtNvertDistance, 10,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(log2x[1], XtNcallback, lbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(log2x[1], XtNradioGroup, log2x[0], NULL);

	label5 = XtVaCreateManagedWidget("llog2y", labelWidgetClass, scale2_dialog,
						XtNlabel, "Log Y",
						XtNborderWidth, 0,
						XtNfromHoriz, log2x[1], 
						XtNhorizDistance, 30,
						XtNfromVert, label7,
						XtNvertDistance, 10,
						NULL);

	log2y[0]=XtVaCreateManagedWidget("l2y01", toggleWidgetClass, scale2_dialog, 
						XtNfromHoriz, label5, 
						XtNfromVert, label7,
						XtNvertDistance, 10,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(log2y[0], XtNcallback, lbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(log2y[0], XtNstate, True, NULL);

	log2y[1]=XtVaCreateManagedWidget("l2y02", toggleWidgetClass, scale2_dialog, 
						XtNfromHoriz, log2y[0], 
						XtNfromVert, label7,
						XtNvertDistance, 10,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(log2y[1], XtNcallback, lbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(log2y[1], XtNradioGroup, log2y[0], NULL);
*/
	button1=XtVaCreateManagedWidget("ok2", commandWidgetClass, scale2_dialog,
						XtNlabel, " OK ",
						XtNfromVert, label4,
						XtNfromHoriz, label4,
						XtNvertDistance, 8,
						XtNborderWidth, 1, 
						NULL);

	button2=XtVaCreateManagedWidget("cancel2", commandWidgetClass, scale2_dialog,
						XtNlabel, "Cancel",
						XtNfromVert, label4,
						XtNfromHoriz, button1,
						XtNhorizDistance, 30,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);

	button3=XtVaCreateManagedWidget("reset2", commandWidgetClass, scale2_dialog,
						XtNlabel, "Reset",
						XtNfromVert, label4,
						XtNfromHoriz, button2,
						XtNhorizDistance, 30,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);

	XtSetKeyboardFocus(scale2_dialog, text2_w[0]);
	focus2_w=text2_w[0];
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)scale_proc, (XtPointer)text2_w);
	XtAddCallback(button2, XtNcallback, (XtCallbackProc)scale_cancel, scale2_popup);
	XtAddCallback(button3, XtNcallback, (XtCallbackProc)scale_reset, scale2_popup);

	button1=XtVaCreateManagedWidget("label30", commandWidgetClass, scale2_dialog,
						XtNlabel, "Keep All",
						XtNfromVert, label4,
						XtNfromHoriz, button3,
						XtNhorizDistance, 100,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)check_all, (XtPointer)0x00);

	XtRealizeWidget(scale2_popup);
	for (i=0;i<CHECKNUM2D;i++) {
		if (scheck2[i]) XtVaSetValues(check2_button[i], XtNbitmap, check_bmp, NULL);
			else 		XtVaSetValues(check2_button[i], XtNbitmap, blank_bmp, NULL);
	}
	wm_delete_window = XInternAtom(XtDisplay(scale2_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(scale2_popup), XtWindow(scale2_popup), &wm_delete_window, 1);
	label_cont=0;
/*
 	XtVaSetValues(log2x[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(log2y[1], XtNlabel, onofflab[0], NULL);
*/
	for (i=4;i<8;i++) XtSetSensitive(text2_w[i],False);
	XtSetSensitive(check2_button[2],False);
	XtSetSensitive(check2_button[3],False);
#ifdef OSX
	set_button_frame(button1);
	set_button_frame(button2);
	set_button_frame(button3);
#endif

}

void xyzbtn_cb(Widget btn, XtPointer pnt, XtPointer dmy)
{ 
	Boolean stat;
	int n=(int)pnt;
	XtVaGetValues(text3_xyz[n],XtNstate,&stat,NULL);
	if (stat==True) xyz_num=n;
}

static void lbtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	light_num=s[4]-'0';
}

static void create_scale3_dialog(Widget form)
{
	Widget label1,label2,label3,label4;
	Widget label5,label6,label7,label8,label9,label10,label11,label12,label13,label14;
	Widget button1,button2,button3;
	static Atom wm_delete_window;
	char   bname[10];
	static char *blabel[3]={"X","Y","Z"};
	static char *clabel[7]={"bl","re","ma","gr","cy","ye","wh"};
	Dimension wd;
	int i;

	wd=check_width*3-(INPUTLONG-INPUTSHORT);

	scale3_popup=XtVaCreatePopupShell("scale3_popup",
						transientShellWidgetClass,form,XtNtitle,"Scaling Dialog",
						XtNtranslations, trans1,
						NULL);

	scale3_dialog = XtVaCreateManagedWidget("form30", formWidgetClass, scale3_popup,
						XtNborderWidth, 0,
						NULL);

	label1 = XtVaCreateManagedWidget("label30", labelWidgetClass, scale3_dialog,
						XtNlabel, "Xmin",
						XtNborderWidth, 0,
						NULL);
	text3_w[0] = XtVaCreateManagedWidget("text30", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						NULL);

	label2 = XtVaCreateManagedWidget("label31", labelWidgetClass, scale3_dialog,
						XtNlabel, "Xmax",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[0],
						NULL);

	text3_w[1] = XtVaCreateManagedWidget("text31", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[0] = XtVaCreateManagedWidget("check31", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromHoriz, text3_w[1],
						XtNhorizDistance, wd+38,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[0], XtNcallback, check_cb, (XtPointer)0x01);

	label3 = XtVaCreateManagedWidget("label32", labelWidgetClass, scale3_dialog,
						XtNlabel, "Ymin",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						NULL);

	text3_w[2] = XtVaCreateManagedWidget("text32", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label3,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label4 = XtVaCreateManagedWidget("label33", labelWidgetClass, scale3_dialog,
						XtNlabel, "Ymax",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[2],
						XtNfromVert, label1,
						NULL);

	text3_w[3] = XtVaCreateManagedWidget("text33", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label4,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[1] = XtVaCreateManagedWidget("check32", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label1,
						XtNfromHoriz, text3_w[3],
						XtNhorizDistance, wd+38,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[1], XtNcallback, check_cb, (XtPointer)0x11);

	label5 = XtVaCreateManagedWidget("label34", labelWidgetClass, scale3_dialog,
						XtNlabel, "Zmin",
						XtNborderWidth, 0,
						XtNfromVert, label3,
						NULL);

	text3_w[4] = XtVaCreateManagedWidget("text34", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label5,
						XtNfromVert, label3,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label6 = XtVaCreateManagedWidget("label35", labelWidgetClass, scale3_dialog,
						XtNlabel, "Zmax",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[4],
						XtNfromVert, label3,
						NULL);

	text3_w[5] = XtVaCreateManagedWidget("text35", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label6,
						XtNfromVert, label3,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[2] = XtVaCreateManagedWidget("check33", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label3,
						XtNfromHoriz, text3_w[5],
						XtNhorizDistance, wd+38,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[2], XtNcallback, check_cb, (XtPointer)0x21);

	label7 = XtVaCreateManagedWidget("label36", labelWidgetClass, scale3_dialog,
						XtNlabel, "Alt ",
						XtNborderWidth, 0,
						XtNfromVert, label5,
						NULL);

	text3_w[6] = XtVaCreateManagedWidget("text36", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label7,
						XtNfromVert, label5,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label8 = XtVaCreateManagedWidget("label37", labelWidgetClass, scale3_dialog,
						XtNlabel, "Azim",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[6],
						XtNfromVert, label5,
						NULL);

	text3_w[7] = XtVaCreateManagedWidget("text37", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label8,
						XtNfromVert, label5,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[3] = XtVaCreateManagedWidget("check34", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label5,
						XtNfromHoriz, text3_w[7],
						XtNhorizDistance, wd+38,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[3], XtNcallback, check_cb, (XtPointer)0x31);

	label9 = XtVaCreateManagedWidget("label38", labelWidgetClass, scale3_dialog,
						XtNlabel, "Fmin",
						XtNborderWidth, 0,
						XtNfromVert, label7,
						NULL);

	text3_w[8] = XtVaCreateManagedWidget("text38", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label9,
						XtNfromVert, label7,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label10 = XtVaCreateManagedWidget("label39", labelWidgetClass, scale3_dialog,
						XtNlabel, "Fmax",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[8],
						XtNfromVert, label7,
						NULL);

	text3_w[9] = XtVaCreateManagedWidget("text39", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label10,
						XtNfromVert, label7,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[4] = XtVaCreateManagedWidget("check35", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label7,
						XtNfromHoriz, text3_w[9],
						XtNhorizDistance, wd+38,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[4], XtNcallback, check_cb, (XtPointer)0x41);

	label11 = XtVaCreateManagedWidget("label3a", labelWidgetClass, scale3_dialog,
						XtNlabel, "Fdiv",
						XtNborderWidth, 0,
						XtNfromVert, label9,
						NULL);

	text3_w[10] = XtVaCreateManagedWidget("text3a", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label11,
						XtNfromVert, label9,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label12 = XtVaCreateManagedWidget("label3b", labelWidgetClass, scale3_dialog,
						XtNlabel, "Ncon",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[10],
						XtNfromVert, label9,
						NULL);

	text3_w[11] = XtVaCreateManagedWidget("text3b", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label12,
						XtNfromVert, label9,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	check3_button[5] = XtVaCreateManagedWidget("check36", commandWidgetClass, scale3_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label9,
						XtNfromHoriz, text3_w[11],
						XtNhorizDistance, wd+38+(INPUTLONG-INPUTSHORT),
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[5], XtNcallback, check_cb, (XtPointer)0x51);

	label13 = XtVaCreateManagedWidget("label3c", labelWidgetClass, scale3_dialog,
						XtNlabel, "Val ",
						XtNborderWidth, 0,
						XtNfromVert, label11,
						NULL);

	text3_w[12] = XtVaCreateManagedWidget("text3c", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label13,
						XtNfromVert, label11,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label14 = XtVaCreateManagedWidget("label3d", labelWidgetClass, scale3_dialog,
						XtNlabel, "Nsuf",
						XtNborderWidth, 0,
						XtNfromHoriz, text3_w[12],
						XtNfromVert, label11,
						NULL);

	text3_w[13] = XtVaCreateManagedWidget("text3d", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label14,
						XtNfromVert, label11,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	text3_xyz[0]=XtVaCreateManagedWidget("xyz01", toggleWidgetClass, scale3_dialog, 
						XtNfromHoriz, text3_w[13],
						XtNfromVert, label11,
						XtNhorizDistance, 8,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNtranslations, trans2,
						XtNlabel, blabel[0], NULL);
	XtAddCallback(text3_xyz[0], XtNcallback, xyzbtn_cb, (XtPointer)0);
	for (i=1; i<3; i++){
		sprintf(bname, "xyz%02d", i+1);
		text3_xyz[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, scale3_dialog,
						XtNfromHoriz, text3_xyz[i-1],
						XtNfromVert, label11,
						XtNhorizDistance, 7,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNtranslations, trans2,
						XtNlabel, blabel[i], NULL);
		XtAddCallback(text3_xyz[i], XtNcallback, xyzbtn_cb, (XtPointer)i);
		XtVaSetValues(text3_xyz[i], XtNradioGroup, text3_xyz[i-1], NULL);
	}

	check3_button[6] = XtVaCreateManagedWidget("check37", commandWidgetClass, scale3_dialog,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromVert, label11,
						XtNfromHoriz, text3_xyz[2],
						XtNhorizDistance, 10,
						XtNborderWidth, 1, NULL);
	XtAddCallback(check3_button[6], XtNcallback, check_cb, (XtPointer)0x61);

/*	Lighting Lines	*/

	label1 = XtVaCreateManagedWidget("cllabel1", labelWidgetClass, scale3_dialog,
						XtNlabel, "Surf Color",
						XtNborderWidth, 0,
						XtNfromVert, label13,
						XtNvertDistance, 10,
						NULL);

	lradio[0]=XtVaCreateManagedWidget("lit01", toggleWidgetClass, scale3_dialog, 
						XtNfromHoriz, label1, 
						XtNfromVert, label13,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, clabel[0], NULL);
	XtAddCallback(lradio[0], XtNcallback, lbtn_cb, (XtPointer)clabel[0]);

	for (i=1; i<7; i++){
		sprintf(bname, "lit%02d", i+1);
		lradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, scale3_dialog, 
						XtNfromHoriz, lradio[i-1], 
						XtNfromVert, label13,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, clabel[i], NULL);
		XtAddCallback(lradio[i], XtNcallback, lbtn_cb, (XtPointer)clabel[i]);
		XtVaSetValues(lradio[i], XtNradioGroup, lradio[i-1], NULL);
	}

	label4 = XtVaCreateManagedWidget("llabel1", labelWidgetClass, scale3_dialog,
						XtNlabel, "Light Alt ",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						NULL);

	text_lit[0] = XtVaCreateManagedWidget("light1", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label4,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label2 = XtVaCreateManagedWidget("llabel2", labelWidgetClass, scale3_dialog,
						XtNlabel, "Azim",
						XtNborderWidth, 0,
						XtNfromHoriz, text_lit[0],
						XtNfromVert, label1,
						XtNhorizDistance, 15,
						NULL);

	text_lit[1] = XtVaCreateManagedWidget("light2", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label2,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label3 = XtVaCreateManagedWidget("llabel3", labelWidgetClass, scale3_dialog,
						XtNlabel, "Light Amb ",
						XtNborderWidth, 0,
						XtNfromVert, label4,
						NULL);

	text_lit[2] = XtVaCreateManagedWidget("light3", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label3,
						XtNfromVert, label4,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label2 = XtVaCreateManagedWidget("llabel4", labelWidgetClass, scale3_dialog,
						XtNlabel, "Diff",
						XtNborderWidth, 0,
						XtNfromHoriz, text_lit[2],
						XtNfromVert, label4,
						XtNhorizDistance, 15,
						NULL);

	text_lit[3] = XtVaCreateManagedWidget("light4", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label2,
						XtNfromVert, label4,
						XtNborderWidth, 1,
						XtNwidth, INPUTSHORT,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label2 = XtVaCreateManagedWidget("glabel2", labelWidgetClass, scale3_dialog,
						XtNlabel, "Nspec",
						XtNborderWidth, 0,
						XtNfromVert, label4,
						XtNfromHoriz,text_lit[3], 
						XtNhorizDistance, 15,
						NULL);

	text_lit[4] = XtVaCreateManagedWidget("light5", asciiTextWidgetClass, scale3_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label4,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTTINY,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

/*	Bottom Line	*/
	label13=label3;
	button1=XtVaCreateManagedWidget("ok3", commandWidgetClass, scale3_dialog,
						XtNlabel, " OK ",
						XtNfromVert, label13,
						XtNfromHoriz, label13,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);

	button2=XtVaCreateManagedWidget("cancel3", commandWidgetClass, scale3_dialog,
						XtNlabel, "Cancel",
						XtNfromVert, label13,
						XtNfromHoriz, button1,
						XtNhorizDistance, 30,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);

	button3=XtVaCreateManagedWidget("reset3", commandWidgetClass, scale3_dialog,
						XtNlabel, "Reset",
						XtNfromVert, label13,
						XtNfromHoriz, button2,
						XtNhorizDistance, 30,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);

	XtSetKeyboardFocus(scale3_dialog, text3_w[0]);
	focus3_w=text3_w[0];
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)scale_proc, (XtPointer)text3_w);
	XtAddCallback(button2, XtNcallback, (XtCallbackProc)scale_cancel, scale3_popup);
	XtAddCallback(button3, XtNcallback, (XtCallbackProc)scale_reset, scale3_popup);

	button1=XtVaCreateManagedWidget("label37", commandWidgetClass, scale3_dialog,
						XtNlabel, "Keep All",
						XtNfromVert, label13,
						XtNfromHoriz, button3,
						XtNhorizDistance, 100,
						XtNvertDistance, 8,
						XtNborderWidth, 1, NULL);
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)check_all, (XtPointer)0x01);

	XtRealizeWidget(scale3_popup);
	for (i=0;i<CHECKNUM3D;i++) {
		if (scheck3[i]) XtVaSetValues(check3_button[i], XtNbitmap, check_bmp, NULL);
			else		XtVaSetValues(check3_button[i], XtNbitmap, blank_bmp, NULL);
	}
	wm_delete_window = XInternAtom(XtDisplay(scale3_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(scale3_popup), XtWindow(scale3_popup), &wm_delete_window, 1);
	label_cont3d=0;
	for (i=8;i<XYZPOS;i++) XtSetSensitive(text3_w[i],False);
	for (i=0;i<3;i++) XtSetSensitive(text3_xyz[i],False);
	xyz_num=0;
	XtVaSetValues(text3_xyz[0], XtNstate, True, NULL);
	for (i=3;i<CHECKNUM3D;i++) XtSetSensitive(check3_button[i],False);
}

/*		Analysis Dialog		*/

#define MAX_ANA_TEXT		2
Widget	text_a[MAX_ANA_TEXT], focus_a, result_text ,cradio[7],oradio[2];
int		anal_num,order_num;

static void analyze_frame(Widget w, XtPointer client_data,  XtPointer call_data)
{
	Position x,y;
	Dimension width, height;
	char str[15];

	if (seq_no>0 || GRAPHSPEC!=GRAPH_2D) {  BEEP();		return;  }

	XtVaGetValues(analyze_button,XtNwidth,&width,XtNheight,&height,NULL);
	XtTranslateCoords(analyze_button,(Position)0,(Position)(-3*height),&x,&y);

	XtSetSensitive(analyze_button,FALSE);
/*	XtVaSetValues(analyze_dialog,XtNvalue,"",NULL);		*/
	XtVaSetValues(analyze_popup,XtNx,x,XtNy,y,NULL);
/*
	sprintf(str,"%d",4);
	XtVaSetValues(text_a[0],XtNstring,str,NULL);
*/
	if (anal_mode==0) {
		ANA2DX1=SC2DX1[NOWS];		ANA2DX2=SC2DX2[NOWS];
	}
		
	XtVaSetValues(text_a[0],XtNstring,gcvt(ANA2DX1,10,str),NULL);
	XawTextSetInsertionPoint(text_a[0],strlen(str));
	XtVaSetValues(text_a[1],XtNstring,gcvt(ANA2DX2,10,str),NULL);
	XawTextSetInsertionPoint(text_a[0],strlen(str));
	if (ANACOL) {
		XtVaSetValues(cradio[ANACOL-1], XtNstate, True, NULL);
		anal_num=ANACOL;
	}
	XtPopup(analyze_popup,XtGrabNonexclusive);
	fix_window(analyze_popup,x,y);
}

static void analyze_window()
{
/*
      line fit to ax+by=c
        res[0] ... x av
        res[1] ... y av
        res[2] ... x std
        res[3] ... y std
        res[4] ... xy std
        res[5] ... a
        res[6] ... b
        res[7] ... c
        res[8] ... d
        res[9] ... r
*/

	int c,rrr;
	double *res=ANA_DATA;
	char str[1024];

	if (ANALYZEMODE==0) return;
	if ((rrr=analyze_output()) || NANA_DATA<=0) BEEP();
	  else if (order_num==1) {
		c =sprintf(str,    "X  range        %lg-%lg\n",ANA2DX1,ANA2DX2);
		c+=sprintf(&str[c],"No. of Data     %d\n",NANA_DATA);
		c+=sprintf(&str[c],"X  average      %lg\n",res[0]);
		c+=sprintf(&str[c],"Y  average      %lg\n",res[1]);
		c+=sprintf(&str[c],"X  standard     %lg\n",res[2]);
		c+=sprintf(&str[c],"Y  standard     %lg\n",res[3]);
		c+=sprintf(&str[c],"XY average      %lg\n\n",res[4]);
		if (res[5]==1) {
			if (res[7]>=0) c+=sprintf(&str[c],"Line ...     X = %lg Y + %lg\n",-res[6], res[7]);
				else	   c+=sprintf(&str[c],"Line ...     X = %lg Y - %lg\n",-res[6],-res[7]);
		  }
		  else {
			if (res[7]>=0) c+=sprintf(&str[c],"Line ...     Y = %lg X + %lg\n",-res[5], res[7]);
				else	   c+=sprintf(&str[c],"Line ...     Y = %lg X - %lg\n",-res[5],-res[7]);
		}
		c+=sprintf(&str[c],"             r = %lg",res[9]);
		XtVaSetValues(result_text,XtNstring,str,NULL);
		XtPopup(result_popup,XtGrabNonexclusive);
	  }
	  else {
		c =sprintf(str,    "X  range        %lg-%lg\n",ANA2DX1,ANA2DX2);
		c+=sprintf(&str[c],"No. of Data     %d\n",NANA_DATA);
		c+=sprintf(&str[c],"X  average      %lg\n",res[0]);
		c+=sprintf(&str[c],"Y  average      %lg\n",res[1]);
		c+=sprintf(&str[c],"X  standard     %lg\n",res[2]);
		c+=sprintf(&str[c],"Y  standard     %lg\n",res[3]);
		c+=sprintf(&str[c],"X  basepoint    %lg\n\n",res[4]);
		c+=sprintf(&str[c],"  Y = %lg + %lg*Xd + %lg*Xd^2\n",res[5], res[6], res[7]);
		c+=sprintf(&str[c],"          + %lg*Xd^3 + %lg*Xd^4\n",res[8], res[9]);
		c+=sprintf(&str[c],"    (Xd = X-Xbase)");
#ifdef TT_SPECIAL
		c+=sprintf(&str[c],"\n\n  omega    %lg\n",sqrt(-12*res[9]/res[7]));
		c+=sprintf(&str[c],"  gamma    %lg\n",-1.5*res[8]/res[7]);
		c+=sprintf(&str[c],"  b        %lg\n",res[7]*res[7]/(6*res[9]));
		c+=sprintf(&str[c],"  a        %lg",res[5]-res[7]*res[7]/(6*res[9]));
#endif
		XtVaSetValues(result_text,XtNstring,str,NULL);
		XtPopup(result_popup,XtGrabNonexclusive);
	}
	ANALYZEMODE=0;
}

static void analyze_cancel(Widget w,Widget shell)
{
	XtPopdown(shell);
	XtSetSensitive(analyze_button,TRUE);
	ANALYZEMODE=0;
}

static void analyze_delete(Widget w,Widget shell)
{
	XtPopdown(analyze_popup);
	XtSetSensitive(analyze_button,TRUE);
	ANALYZEMODE=0;
}

static void result_ok(Widget w,Widget shell)
{
	XtPopdown(result_popup);
	XtSetSensitive(analyze_button,TRUE);
	ANALYZEMODE=0;
}

static void analyze_proc(Widget w,Widget text)
{
	String num;

	XtPopdown(analyze_popup);
	XtSetSensitive(analyze_button,TRUE);
/*
	XtVaGetValues(text_a[0], XtNstring, &num, NULL);
	ANACOL=atoi(num);
*/
	XtVaGetValues(text_a[0], XtNstring, &num, NULL);
	ANA2DX1=atof(num);
	XtVaGetValues(text_a[1], XtNstring, &num, NULL);
	ANA2DX2=atof(num);
	ANACOL=anal_num;
	ANAORDER=order_num;
	ANALYZEMODE=1;
	anal_mode=1;
}

static void updown_akey_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	char *s=XtName(w);
	int n;
	n=s[5]-'0';
	XtVaSetValues(w, XtNdisplayCaret, False, NULL);
	if (*(vector[0])=='0') n+=MAX_ANA_TEXT-1;
		else			   n+=1;
	n%=MAX_ANA_TEXT;
	focus_a=text_a[n];
	XtSetKeyboardFocus(analyze_dialog, focus_a);
	XtVaSetValues(focus_a, XtNdisplayCaret, True, NULL);
}

static void mouse_ana_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	XtVaSetValues(focus_a, XtNdisplayCaret, False, NULL);
	XtSetKeyboardFocus(analyze_dialog, w);
	XtVaSetValues(w, XtNdisplayCaret, True, NULL);
	focus_a=w;
}

static void btn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	anal_num=s[4]-'0';
}

static void obtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	order_num=s[4]-'0';
}

static void create_analyze_dialog(Widget form)
{
	static XtActionsRec actions[]={
		{ "analyzewindow" , (XtActionProc)analyze_window},
		{ "analyzeproc"   , (XtActionProc)analyze_proc},
		{ "updown_akey"  , (XtActionProc)updown_akey_cb},
		{ "mouse_ana"    , (XtActionProc)mouse_ana_cb},
		{ "delete_ana"    , (XtActionProc)analyze_delete},
	};
	static XtTranslations trans,trans1;
	Widget label1,label2,button1,button2;
	static Atom wm_delete_window;
	int    i;
	char   bname[10];
	static char *blabel[7]={"bl","re","ma","gr","cy","ye","wh"};
	static char *orderlab[2]={"linear","4thorder"};

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Unmap>: analyzewindow()\n\
						<Message>WM_PROTOCOLS: delete_ana()");

	analyze_popup=XtVaCreatePopupShell("analyze_popup",
						transientShellWidgetClass,form,XtNtitle,"Analyze Dialog",
                         XtNtranslations, trans1,
						NULL);

	trans = XtParseTranslationTable("#override\n\
						<Key>KP_Enter: analyzeproc()\n\
						<Key>Return: analyzeproc()\n\
						Ctrl<Key>M: analyzeproc()\n\
						Ctrl<Key>J: analyzeproc()\n\
						<Key>Up:   updown_akey(0)\n\
						<Key>Down: updown_akey(1)\n\
						<Key>Tab: updown_akey(1)\n\
						<Btn1Down>,<Btn1Up>: mouse_ana()\n\
						Ctrl<Key>D: delete_chara() delete-next-character()\n\
						Ctrl<Key>H: delete_chara() delete-previous-character()\n\
						<Key>BackSpace: delete_chara() delete-previous-character()\n\
						<Key>Delete: delete_chara() delete-next-character()\n\
						<Key>Left: backward-character()\n\
						<Key>Right: forward-character()\n\
						<Key>: delete_chara() insert-char()\n\
						");

	analyze_dialog = XtVaCreateManagedWidget("aform0", formWidgetClass, analyze_popup,
		                            XtNborderWidth, 0,
									NULL);

/*
	label1 = XtVaCreateManagedWidget("alabel0", labelWidgetClass, analyze_dialog,
							XtNlabel, "Color",
							XtNborderWidth, 0,
  							NULL);

	text_a[0] = XtVaCreateManagedWidget("atext0", asciiTextWidgetClass, analyze_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						NULL);
*/

	label1 = XtVaCreateManagedWidget("alabel0", labelWidgetClass, analyze_dialog,
						XtNlabel, "Xmin",
						XtNborderWidth, 0,
						NULL);

	text_a[0] = XtVaCreateManagedWidget("atext0", asciiTextWidgetClass, analyze_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						NULL);

	label2 = XtVaCreateManagedWidget("alabel1", labelWidgetClass, analyze_dialog,
						XtNlabel, "Xmax",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						NULL);

	text_a[1] = XtVaCreateManagedWidget("atext1", asciiTextWidgetClass, analyze_dialog,
						XtNeditType, XawtextEdit,
						XtNfromHoriz, label2,
						XtNfromVert, label1,
						XtNborderWidth, 1,
						XtNwidth, INPUTLONG,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	cradio[0]=XtVaCreateManagedWidget("rad01", toggleWidgetClass, analyze_dialog, 
						XtNfromVert, label2,
						XtNtranslations, trans2,
						XtNlabel, blabel[0], NULL);
	XtAddCallback(cradio[0], XtNcallback, btn_cb, (XtPointer)blabel[0]);
	XtVaSetValues(cradio[0], XtNstate, True, NULL);
	anal_num=1;

	for (i=1; i<7; i++){
		sprintf(bname, "rad%02d", i+1);
		cradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, analyze_dialog, 
						XtNfromHoriz, cradio[i-1], 
						XtNfromVert, label2,
						XtNtranslations, trans2,
						XtNlabel, blabel[i], NULL);
		XtAddCallback(cradio[i], XtNcallback, btn_cb, (XtPointer)blabel[i]);
		XtVaSetValues(cradio[i], XtNradioGroup, cradio[i-1], NULL);
	}

	oradio[0]=XtVaCreateManagedWidget("ord01", toggleWidgetClass, analyze_dialog, 
						XtNfromVert, cradio[0],
						XtNhorizDistance, 15,
						XtNtranslations, trans2,
						XtNlabel, orderlab[0], NULL);
	XtAddCallback(oradio[0], XtNcallback, obtn_cb, (XtPointer)orderlab[0]);
	XtVaSetValues(oradio[0], XtNstate, True, NULL);
	order_num=1;

	for (i=1; i<2; i++){
		sprintf(bname, "ord%02d", i+1);
		oradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, analyze_dialog, 
						XtNfromHoriz, oradio[i-1], 
						XtNfromVert, cradio[0],
						XtNhorizDistance, 15,
						XtNtranslations, trans2,
						XtNlabel, orderlab[i], NULL);
		XtAddCallback(oradio[i], XtNcallback, obtn_cb, (XtPointer)orderlab[i]);
		XtVaSetValues(oradio[i], XtNradioGroup, oradio[i-1], NULL);
	}
  
	button1=XtVaCreateManagedWidget("aok", commandWidgetClass, analyze_dialog,
						XtNlabel, " OK ",
						XtNfromVert, oradio[0],
         /*						XtNfromHoriz, text2,*/
						XtNhorizDistance, 15,
						XtNborderWidth, 1, NULL);

	button2=XtVaCreateManagedWidget("acancel", commandWidgetClass, analyze_dialog,
						XtNlabel, "Cancel",
						XtNfromVert, oradio[0],
						XtNfromHoriz, button1,
						XtNhorizDistance, 30,
						XtNborderWidth, 1, NULL);

	XtSetKeyboardFocus(analyze_dialog, text_a[0]);
	focus_a=text_a[0];
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)analyze_proc, (XtPointer)text_a);
	XtAddCallback(button2, XtNcallback, (XtCallbackProc)analyze_cancel, analyze_popup);
	XtRealizeWidget(analyze_popup);
	wm_delete_window = XInternAtom(XtDisplay(analyze_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(analyze_popup), XtWindow(analyze_popup), &wm_delete_window, 1);

	anal_mode=0;
}

#ifdef TT_SPECIAL
#define MAXRESLINE		200
#else
#define MAXRESLINE		140
#endif

static void result_cancel(Widget w,Widget shell)
{
	XtPopdown(result_popup);
}

static void create_result_dialog(Widget form)
{
	static XtActionsRec actions[]={
		{"res_cb", (XtActionProc)result_cancel},
	};
	static XtTranslations trans;
	static Atom wm_delete_window;
	Widget button;

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans = XtParseTranslationTable("#override\n\
						<Key>Return: res_cb()\n\
						<Key>KP_Enter: res_cb()\n\
						<Message>WM_PROTOCOLS: res_cb()");

	result_popup=XtVaCreatePopupShell("result_popup",
						transientShellWidgetClass,form,XtNtitle,"Results",
						XtNtranslations, trans,
						NULL);

	result_dialog = XtVaCreateManagedWidget("res_dialog", formWidgetClass, result_popup,
						XtNborderWidth, 0,
						NULL);

	result_text = XtVaCreateManagedWidget("result_text", asciiTextWidgetClass, result_dialog,
						/*XtNlabel, "Result",*/
						XtNwidth, 360,
						XtNheight, MAXRESLINE,
						XtNborderWidth, 0,
						XtNdisplayCaret, False,
						NULL);
  
	button=XtVaCreateManagedWidget("rok", commandWidgetClass, result_dialog,
						XtNlabel, " OK ",
						XtNfromVert, result_text,
         /*						XtNfromHoriz, text2,*/
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNborderWidth, 1, NULL);

	XtAddCallback(button, XtNcallback, (XtCallbackProc)analyze_cancel, result_popup);
	XtRealizeWidget(result_popup);
	wm_delete_window = XInternAtom(XtDisplay(result_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(result_popup), XtWindow(result_popup), &wm_delete_window, 1);
}

/*		Setting Dialog		*/

#define MAX_SET_TEXT		6
#define MAX_SET_TEXT2		4
Widget	text_s[MAX_SET_TEXT], focus_s ,ctoggle[7], c2radio[3], c3radio[2], p3radio[2];
Widget	psizeradio[4],poutradio[3],pcolradio[4],sxyz[3], angradio[2], text_an;
char 	on_color[7];
static int schecks=0, clip2_num=0, clip3_num=0, proj3_num=0, angle_num=0;
static int ps_set1=0, ps_set2=0, ps_set3=0, sxyz_num;

#ifdef GIF
Widget	gifbw[2],gifaa[2],giftr[2],gifit[2],text_loop,text_delay,text_aares;
static int gifgray_num=0,gifaa_num=0,giftr_num=0,gifit_num=0;
static int gifde_num=GIFBASEDELAY,giflo_num=GIFBASELOOP,gifres_num=GIFBASERESOL;
#endif

static void setting_frame(Widget w, XtPointer client_data,  XtPointer call_data)
{
	Position x,y;
	Dimension width, height;
	char str[15];
	int i,cols;

	if (seq_no>0) {  BEEP();		return;  }

	XtVaGetValues(setting_button,XtNwidth,&width,XtNheight,&height,NULL);
	XtTranslateCoords(setting_button,(Position)(-3*width),(Position)(-3*height),&x,&y);

	XtSetSensitive(setting_button,FALSE);
/*	XtVaSetValues(setting_dialog,XtNvalue,"",NULL);
	XtVaSetValues(setting_popup,XtNx,x,XtNy,y,NULL);		*/

	XtVaSetValues(text_s[0],XtNstring,gcvt(ARROWLEN,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_s[0],strlen(str));
	XtVaSetValues(text_s[1],XtNstring,gcvt(CIRCRAD,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_s[1],strlen(str));
	XtVaSetValues(text_s[2],XtNstring,gcvt(LINELIMIT,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_s[2],strlen(str));
	XtVaSetValues(text_s[3],XtNstring,gcvt(DOTRESOLVE,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_s[3],strlen(str));
	XtVaSetValues(text_an,XtNstring,gcvt(MOVIESPEED,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_an,strlen(str));
#ifdef GIF
	XtVaSetValues(text_delay,XtNstring,gcvt(GIFADELAY,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_delay,strlen(str));
	XtVaSetValues(text_loop,XtNstring,gcvt(GIFALOOP,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_loop,strlen(str));
	XtVaSetValues(text_aares,XtNstring,gcvt(GIFAARESOLVE,DISPPREC,str),NULL);
	XawTextSetInsertionPoint(text_aares,strlen(str));
#endif
	XtPopup(setting_popup,XtGrabNonexclusive);
	fix_window(setting_popup,x,y);

	if (CLIP2DMODE!=clip2_num) {
		clip2_num=CLIP2DMODE;
		XtVaSetValues(c2radio[clip2_num], XtNstate, True, NULL);
	}
	if (CLIP3DMODE!=clip3_num) {
		clip3_num=CLIP3DMODE;
		XtVaSetValues(c3radio[clip3_num], XtNstate, True, NULL);
	}
	if (PROJ3DMODE!=proj3_num) {
		proj3_num=PROJ3DMODE;
		XtVaSetValues(p3radio[proj3_num], XtNstate, True, NULL);
	}
	if (D3XYZMODE!=sxyz_num) {
		sxyz_num=D3XYZMODE;
		XtVaSetValues(sxyz[sxyz_num], XtNstate, True, NULL);
	}
	if (REANGLE3D!=angle_num) {
		angle_num=REANGLE3D;
		XtVaSetValues(angradio[angle_num], XtNstate, True, NULL);
	}

/*	cols=COLORNOW&COLORSEL;		*/
	cols=COLORSEL;
	for (i=0;i<7;i++) {
		if (cols&1) {
			on_color[i]=1;
			XtVaSetValues(ctoggle[i], XtNstate, True, NULL);
		  }
		  else {
		  	on_color[i]=0;
			XtVaSetValues(ctoggle[i], XtNstate, False, NULL);
		}
		cols>>=1;
	}

	scale_on=1;

	if (PSSIZEMODE!=ps_set1) {
		ps_set1=PSSIZEMODE;
		XtVaSetValues(psizeradio[ps_set1], XtNstate, True, NULL);
	}
	if (PSFMODE!=ps_set2) {
		ps_set2=PSFMODE;
		XtVaSetValues(poutradio[ps_set2], XtNstate, True, NULL);
	}
	if (PSCOLMODE!=ps_set3) {
		ps_set3=PSCOLMODE;
		XtVaSetValues(pcolradio[ps_set3], XtNstate, True, NULL);
	}

#ifdef GIF
	if (GIFGRAYMODE!=gifgray_num) {
		gifgray_num=GIFGRAYMODE;
		XtVaSetValues(gifbw[gifgray_num], XtNstate, True, NULL);
	}
	if (GIFSETB!=giftr_num) {
		giftr_num=GIFSETB;
		XtVaSetValues(giftr[giftr_num], XtNstate, True, NULL);
	}
	if (GIFSETI!=gifit_num) {
		gifit_num=GIFSETI;
		XtVaSetValues(gifit[gifit_num], XtNstate, True, NULL);
	}
	if (GIFAAMODE!=gifaa_num) {
		gifaa_num=GIFAAMODE;
		XtVaSetValues(gifaa[gifaa_num], XtNstate, True, NULL);
		if (gifaa_num==0) XtSetSensitive(text_aares,FALSE);
			else 		  XtSetSensitive(text_aares,True);
	}
#endif
}

static void setting_window()
{
	if (scale_on==0) return;
	settings_input();
	if (scale_output()) BEEP();
	scale_on=0;
}

static void setting_reset(Widget w,Widget shell)
{
	clear_settings();
	XtPopdown(shell);
	XtSetSensitive(setting_button,TRUE);
}

static void setting_cancel(Widget w,Widget shell)
{
	XtPopdown(shell);
	XtSetSensitive(setting_button,TRUE);
	scale_on=0;
}

static void setting_proc(Widget w,Widget text)
{
	int i,cols;
	double x1,x2,x3,x4;
	int nd;
	String num;

	scale_on=0;

	XtPopdown(setting_popup);
	XtSetSensitive(setting_button,TRUE);

	x1=ARROWLEN;		x2=CIRCRAD;
	XtVaGetValues(text_s[0], XtNstring, &num, NULL);
	x1=atof(num);
	if (x1!=ARROWLEN) {
		scale_on=1;
		ARROWLEN=x1;
		SETTINGMODE|=1;
	}
	XtVaGetValues(text_s[1], XtNstring, &num, NULL);
	x2=atof(num);
	if (x2!=CIRCRAD) {
		scale_on=1;
		CIRCRAD=x2;
		SETTINGMODE|=2;
	}
	XtVaGetValues(text_s[2], XtNstring, &num, NULL);
	x3=atof(num);
	if (x3!=LINELIMIT) {
		scale_on=1;
		LINELIMIT=x3;
		SETTINGMODE|=4;
	}
	XtVaGetValues(text_s[3], XtNstring, &num, NULL);
	x4=atof(num);
	if (x4!=DOTRESOLVE) {
		scale_on=1;
		DOTRESOLVE=x4;
		SETTINGMODE|=128;
	}
	XtVaGetValues(text_an, XtNstring, &num, NULL);
	x4=atof(num);
	if (x4!=MOVIESPEED) {
		MOVIESPEED=x4;
	}

	cols=0;
	for (i=6;i>=0;i--) {
		cols=(cols<<1)|on_color[i];
	}
	if (cols!=COLORSEL) {
		if (cols!=COLORSEL) scale_on=1;
		COLORSEL=cols;
		SETTINGMODE|=8;
	}

	if (CLIP2DMODE!=clip2_num) {
		if (CLIP2DMODE!=clip2_num) scale_on=1;
		CLIP2DMODE=clip2_num;
		SETTINGMODE|=16;
	}

	if (CLIP3DMODE!=clip3_num) {
		if (CLIP3DMODE!=clip3_num) scale_on=1;
		CLIP3DMODE=clip3_num;
		SETTINGMODE|=32;
	}

	if (PROJ3DMODE!=proj3_num) {
		if (PROJ3DMODE!=proj3_num) scale_on=1;
		PROJ3DMODE=proj3_num;
		SETTINGMODE|=64;
	}
	if (D3XYZMODE!=sxyz_num) {
		if (D3XYZMODE!=sxyz_num) scale_on=1;
		D3XYZMODE=sxyz_num;
		SETTINGMODE|=64;
	}
	if (REANGLE3D!=angle_num) {
		if (REANGLE3D!=angle_num) scale_on=1;
		REANGLE3D=angle_num;
		SETTINGMODE|=256;
	}

	if (schecks) SETTINGMODE|=65536;
		else	 SETTINGMODE&=65535;

	ps_setting_proc(ps_set1,ps_set2,ps_set3);
#ifdef GIF
	XtVaGetValues(text_delay, XtNstring, &num, NULL);
	gifde_num=atof(num);
	XtVaGetValues(text_loop, XtNstring, &num, NULL);
	giflo_num=atof(num);
	XtVaGetValues(text_aares, XtNstring, &num, NULL);
	gifres_num=atof(num);
	if (gifres_num<0 || gifres_num>GIFMAXRESOL) gifres_num=GIFAARESOLVE;
	nd=(gifres_num<<1) | gifaa_num;
	gif_setting_proc(gifgray_num,giftr_num,gifit_num,gifde_num,giflo_num,nd);
#endif
}

static void updown_skey_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	char *s=XtName(w);
	int n;
	n=s[5]-'0';
	XtVaSetValues(w, XtNdisplayCaret, False, NULL);
	if (*(vector[0])=='0') n+=MAX_SET_TEXT2-1;
		else			   n+=1;
	n%=MAX_SET_TEXT2;
	focus_s=text_s[n];
	XtSetKeyboardFocus(setting_dialog, focus_s);
	XtVaSetValues(focus_s, XtNdisplayCaret, True, NULL);
}

static void mouse_set_cb(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	XtVaSetValues(focus_s, XtNdisplayCaret, False, NULL);
	XtSetKeyboardFocus(setting_dialog, w);
	XtVaSetValues(w, XtNdisplayCaret, True, NULL);
	focus_s=w;
}

static void sbtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	int n;
	Boolean stat;

	n=s[4]-'1';
	if (s[2]=='g') on_color[n]=1-on_color[n];
	  else if (s[2]=='2') {
		XtVaGetValues(c2radio[n],XtNstate,&stat,NULL);
		if (stat==True) clip2_num=n;
	  }
	  else if (s[2]=='3') {
		XtVaGetValues(c3radio[n],XtNstate,&stat,NULL);
		if (stat==True) clip3_num=n;
	  }
	  else if (s[2]=='j') {
		XtVaGetValues(p3radio[n],XtNstate,&stat,NULL);
		if (stat==True) proj3_num=n;
	  }
	  else if (s[2]=='l') {
		XtVaGetValues(angradio[n],XtNstate,&stat,NULL);
		if (stat==True) angle_num=n;
	}
}

static void psbtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	int n;
	Boolean stat;

	n=s[3]-'1';
	if (s[2]=='1') {
		XtVaGetValues(psizeradio[n],XtNstate,&stat,NULL);
		if (stat==True) ps_set1=n;
	  }
	  else if (s[2]=='2') {
		XtVaGetValues(poutradio[n],XtNstate,&stat,NULL);
		if (stat==True) ps_set2=n;
	  }
	  else if (s[2]=='3') {
		XtVaGetValues(pcolradio[n],XtNstate,&stat,NULL);
		if (stat==True) ps_set3=n;
	}
}

#ifdef GIF
static void gifbtn_cb(Widget btn, XtPointer msg, XtPointer dt)
{ 
	char *s=XtName(btn);
	int n;
	Boolean stat;

	n=s[4]-'1';
	if (s[2]=='b') {
		XtVaGetValues(gifbw[n],XtNstate,&stat,NULL);
		if (stat==True) {
			gifgray_num=n;
		}
	  }
	  else if (s[2]=='t') {
		XtVaGetValues(giftr[n],XtNstate,&stat,NULL);
		if (stat==True) giftr_num=n;
	}
	  else if (s[2]=='i') {
		XtVaGetValues(gifit[n],XtNstate,&stat,NULL);
		if (stat==True) gifit_num=n;
	}
	  else if (s[2]=='a') {
		XtVaGetValues(gifaa[n],XtNstate,&stat,NULL);
		if (stat==True) gifaa_num=n;
		if (gifaa_num==0) XtSetSensitive(text_aares,FALSE);
			else 		  XtSetSensitive(text_aares,True);
	}
}
#endif

static void checks_cb(Widget w, XtPointer pnt, XtPointer dmy)
{
	int no=(int)pnt;

	XtVaSetValues(w, XtNbitmap, blank_bmp, NULL);
	schecks = !schecks;
	if (schecks) XtVaSetValues(w, XtNbitmap, check_bmp, NULL);
}

static void sxyzbtn_cb(Widget btn, XtPointer pnt, XtPointer dmy)
{ 
	Boolean stat;
	int n=(int)pnt;
	XtVaGetValues(sxyz[n],XtNstate,&stat,NULL);
	if (stat==True) sxyz_num=n;
}

static void setting_delete(Widget w, XEvent *e, String *vector, Cardinal *count)
{
	XtPopdown(setting_popup);
	XtSetSensitive(setting_button,TRUE);
}

static Widget make_label_widget(char *name,Widget dialog,char *label,Widget upperitem,int vdist,int wborder)
{
	if (vdist<0) {
		return XtVaCreateManagedWidget(name, labelWidgetClass, dialog,
						XtNlabel, label,
						XtNborderWidth, wborder,
						NULL);
	}
		return XtVaCreateManagedWidget(name, labelWidgetClass, dialog,
						XtNlabel, label,
						XtNfromVert, upperitem,
						XtNvertDistance, vdist,
						XtNborderWidth, wborder,
						NULL);
}

static Widget make_edit_text(char *name,Widget dialog,char *label,Widget upperitem,int length,int state
											,char *str,XtTranslations trans,Widget *text)
{
/*		XtTranslations trans		*/
	Widget item;
	item = XtVaCreateManagedWidget(name, labelWidgetClass, dialog,
						XtNlabel, label,
						XtNfromVert, upperitem,
//						XtNvertDistance, vdist,
						XtNborderWidth, 0,
						NULL);

	*text = XtVaCreateManagedWidget(str, asciiTextWidgetClass, dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, upperitem,
//						XtNvertDistance, vdist,
						XtNfromHoriz, item,
						XtNborderWidth, 1,
						XtNwidth, length,
						XtNtranslations, trans,
						XtNdisplayCaret, state,
						NULL);
	return item;
}

static Widget make_onoff_button(char *name,Widget dialog,char *label,Widget upperitem,int vdist,int wborder,char *str,Widget *onoff)
{
/*		XtTranslations trans2		*/
	Widget item;
	char   bname[10];

	item = XtVaCreateManagedWidget(name, labelWidgetClass, dialog,
						XtNlabel, label,
						XtNfromVert, upperitem,
						XtNvertDistance, vdist,
						XtNborderWidth, wborder,
						NULL);

	sprintf(bname, "%s%02d", str, 1);
	onoff[0]=XtVaCreateManagedWidget(bname, toggleWidgetClass, dialog, 
						XtNfromHoriz,item, 
						XtNfromVert, upperitem,
						XtNvertDistance, vdist,
						XtNtranslations, trans2,
						XtNlabel, "Off", NULL);

	sprintf(bname, "%s%02d", str, 2);
	onoff[1]=XtVaCreateManagedWidget(bname, toggleWidgetClass, dialog, 
						XtNfromHoriz,onoff[0], 
						XtNfromVert, upperitem,
						XtNvertDistance, vdist,
						XtNtranslations, trans2,
						XtNlabel, "Off", NULL);

	return item;
}

static void create_setting_dialog(Widget form)
{
	static XtActionsRec actions[]={
		{ "settingwindow" , (XtActionProc)setting_window},
		{ "settingproc"   , (XtActionProc)setting_proc},
		{ "updown_skey"  , (XtActionProc)updown_skey_cb},
		{ "mouse_set"    , (XtActionProc)mouse_set_cb},
		{ "delete_set"    , (XtActionProc)setting_delete},
	};
	static XtTranslations trans,trans1;
	Widget label0,label1,label2,label3,label4,label41,button1,button2,button3;
	int    i;
	char   bname[10];
	static char *blabel[7]={"bl","re","ma","gr","cy","ye","wh"};
	static char *onofflab[2]={"On","Off"};
	static char *pssize[4]={"Small","Medium","Large","Custom"};
	static char *psmode[3]={"All","Page","Single"};
	static char *pscol[4]={"B/W","Gray","G/D","Color"};
	static unsigned int colpix[8];
	static Atom wm_delete_window;

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Unmap>: settingwindow()\n\
						<Message>WM_PROTOCOLS: delete_set()");

	setting_popup=XtVaCreatePopupShell("setting_popup",
						transientShellWidgetClass,form,XtNtitle,"Setting Dialog",
                        XtNtranslations, trans1,
						NULL);

	trans = XtParseTranslationTable("#override\n\
						<Key>KP_Enter: settingproc()\n\
						<Key>Return: settingproc()\n\
						Ctrl<Key>M: settingproc()\n\
						Ctrl<Key>J: settingproc()\n\
						<Key>Up:   updown_skey(0)\n\
						<Key>Down: updown_skey(1)\n\
						<Key>Tab: updown_skey(1)\n\
						<Btn1Down>,<Btn1Up>: mouse_set()\n\
						Ctrl<Key>D: delete_chara() delete-next-character()\n\
						Ctrl<Key>H: delete_chara() delete-previous-character()\n\
						<Key>BackSpace: delete_chara() delete-previous-character()\n\
						<Key>Delete: delete_chara() delete-next-character()\n\
						<Key>Left: backward-character()\n\
						<Key>Right: forward-character()\n\
						<Key>: delete_chara() insert-char()\n\
						");

	setting_dialog = XtVaCreateManagedWidget("sform0", formWidgetClass, setting_popup,
						XtNborderWidth, 0,
						NULL);

/*	Display	Settings	*/
	label0 = make_label_widget("stitle0",setting_dialog,"      <<< Display Settings >>> ",label0,-1,0);
	label2 = XtVaCreateManagedWidget("stitle01", labelWidgetClass, setting_dialog,
						XtNlabel, "Keep ?",
						XtNborderWidth, 0,
						XtNhorizDistance, 50,
						XtNfromHoriz, label0,
						NULL);

	checks_button = XtVaCreateManagedWidget("checks", commandWidgetClass, setting_dialog, 
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNinternalWidth, 0,
						XtNfromHoriz, label2,
						XtNborderWidth, 1, NULL);
	XtAddCallback(checks_button, XtNcallback, checks_cb, (XtPointer)1);

	label1 = make_edit_text("slabel0", setting_dialog,"Arrow   Mag",label0,INPUTLONG, True,"stext0",trans,&text_s[0]);
	label2 = make_edit_text("slabel1", setting_dialog,"Radius  Mag",label1,INPUTLONG,False,"stext1",trans,&text_s[1]);
	label1 = make_edit_text("slabel2", setting_dialog,"Line  Limit",label2,INPUTLONG,False,"stext2",trans,&text_s[2]);
	label2 = make_edit_text("slabel3", setting_dialog,"Dot Resolve",label1,INPUTLONG,False,"stext3",trans,&text_s[3]);

	label1 = XtVaCreateManagedWidget("ctlabel1", labelWidgetClass, setting_dialog,
						XtNlabel, "Draw color",
						XtNborderWidth, 0,
						XtNfromVert, label2,
						XtNvertDistance, 10,
						NULL);

	ctoggle[0]=XtVaCreateManagedWidget("tog01", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label1, 
						XtNfromVert, label2,
						XtNlabel, blabel[0], 
						XtNvertDistance, 10,
						NULL);
	XtAddCallback(ctoggle[0], XtNcallback, sbtn_cb, (XtPointer)blabel[0]);
//	XtVaSetValues(ctoggle[0], XtNstate, True, NULL);
	on_color[0]=1;

	for (i=1; i<7; i++){
		sprintf(bname, "tog%02d", i+1);
		ctoggle[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, ctoggle[i-1], 
						XtNfromVert, label2,
						XtNlabel, blabel[i],
						XtNvertDistance, 10,
						NULL);
		XtAddCallback(ctoggle[i], XtNcallback, sbtn_cb, (XtPointer)blabel[i]);
//		XtVaSetValues(ctoggle[i], XtNstate, True, NULL);
		on_color[i]=1;
	}

	label3 = XtVaCreateManagedWidget("c2label1", labelWidgetClass, setting_dialog,
						XtNlabel, " 2D   Clip",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						XtNvertDistance, 10,
						NULL);

	c2radio[0]=XtVaCreateManagedWidget("cl201", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label3, 
						XtNfromVert, label1,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(c2radio[0], XtNcallback, sbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(c2radio[0], XtNstate, True, NULL);
	clip2_num=0;

	for (i=1; i<3; i++){
		sprintf(bname, "cl2%02d", i+1);
		c2radio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, c2radio[i-1], 
						XtNfromVert, label1,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, onofflab[1], NULL);
		XtAddCallback(c2radio[i], XtNcallback, sbtn_cb, (XtPointer)onofflab[i]);
		XtVaSetValues(c2radio[i], XtNradioGroup, c2radio[i-1], NULL);
	}

	label4 = make_onoff_button("c3label1", setting_dialog," 3D   Clip",label3,10,0,"cl3",c3radio);
	XtAddCallback(c3radio[0], XtNcallback, sbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(c3radio[0], XtNstate, True, NULL);
	clip3_num=0;
	XtAddCallback(c3radio[1], XtNcallback, sbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(c3radio[1], XtNradioGroup, c3radio[0], NULL);

	label41 = XtVaCreateManagedWidget("c3label2", labelWidgetClass, setting_dialog,
						XtNlabel, "Perspect",
						XtNborderWidth, 0,
						XtNfromVert, label3,
						XtNfromHoriz, c3radio[1], 
						XtNvertDistance, 10,
						XtNhorizDistance, 15,
						NULL);

	p3radio[0]=XtVaCreateManagedWidget("prj01", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label41, 
						XtNfromVert, label3,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, onofflab[1], NULL);
	XtAddCallback(p3radio[0], XtNcallback, sbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(p3radio[0], XtNstate, True, NULL);
	proj3_num=0;

	for (i=1; i<2; i++){
		sprintf(bname, "prj%02d", i+1);
		p3radio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz,p3radio[i-1], 
						XtNfromVert, label3,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, onofflab[1], NULL);
		XtAddCallback(p3radio[i], XtNcallback, sbtn_cb, (XtPointer)onofflab[i]);
		XtVaSetValues(p3radio[i], XtNradioGroup, p3radio[i-1], NULL);
	}

	sxyz[1]=XtVaCreateManagedWidget("sxyz01", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, p3radio[1],
						XtNfromVert, label3,
						XtNhorizDistance, 15,
						XtNvertDistance, 10,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNlabel, "X",
						XtNtranslations, trans2,
						NULL);
	XtAddCallback(sxyz[1], XtNcallback, sxyzbtn_cb, (XtPointer)1);
	XtVaSetValues(sxyz[1], XtNstate, True, NULL);
	sxyz_num=1;
	sxyz[2]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, sxyz[1],
						XtNfromVert, label3,
						XtNhorizDistance, 7,
						XtNvertDistance, 10,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNlabel, "Y",
						XtNtranslations, trans2,
						NULL);
	XtAddCallback(sxyz[2], XtNcallback, sxyzbtn_cb, (XtPointer)2);
	XtVaSetValues(sxyz[2], XtNradioGroup, sxyz[1], NULL);
	sxyz[0]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, sxyz[2],
						XtNfromVert, label3,
						XtNhorizDistance, 7,
						XtNvertDistance, 10,
						XtNheight, check_height,
						XtNwidth, check_width,
						XtNlabel, "Z",
						XtNtranslations, trans2,
						NULL);
	XtAddCallback(sxyz[0], XtNcallback, sxyzbtn_cb, (XtPointer)0);
	XtVaSetValues(sxyz[0], XtNradioGroup, sxyz[2], NULL);

	label3 = make_onoff_button("c3label1", setting_dialog,"   ReAngle",label4,10,0,"anl",angradio);
	XtAddCallback(angradio[0], XtNcallback, sbtn_cb, (XtPointer)onofflab[0]);
	XtVaSetValues(angradio[0], XtNstate, True, NULL);
	angle_num=0;
	XtAddCallback(angradio[1], XtNcallback, sbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(angradio[1], XtNradioGroup, angradio[0], NULL);

/*	Animation Setting	*/

	label2 = XtVaCreateManagedWidget("anilab", labelWidgetClass, setting_dialog,
						XtNlabel, "Movie Speed (1-30)",
						XtNfromVert, label3,
						XtNborderWidth, 0,
						XtNvertDistance, 10,
						NULL);

	text_an = XtVaCreateManagedWidget("antext", asciiTextWidgetClass, setting_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label3,
						XtNfromHoriz, label2,
						XtNborderWidth, 1,
						XtNwidth, INPUTTINY,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						XtNvertDistance, 10,
						NULL);

/*	PostScript Settings	*/

	label4 = label2;
	label0 = make_label_widget("stitle1",setting_dialog,"      <<< PostScript Settings >>>",label4,16,0);

	label1 = XtVaCreateManagedWidget("psize", labelWidgetClass, setting_dialog,
						XtNlabel, "Print  Size",
						XtNborderWidth, 0,
						XtNfromVert, label0,
						XtNvertDistance, 10,
						NULL);
	psizeradio[0]=XtVaCreateManagedWidget("ps11", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label1, 
						XtNfromVert, label0,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
	XtAddCallback(psizeradio[0], XtNcallback, psbtn_cb, (XtPointer)pssize[0]);

	for (i=1; i<4; i++){
		sprintf(bname, "ps1%d", i+1);
		psizeradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, psizeradio[i-1], 
						XtNfromVert, label0,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
		XtAddCallback(psizeradio[i], XtNcallback, psbtn_cb, (XtPointer)pssize[i]);
		XtVaSetValues(psizeradio[i], XtNradioGroup, psizeradio[i-1], NULL);
	}
	XtVaSetValues(psizeradio[PSSIZEMODE], XtNstate, True, NULL);
	if (PSSIZEMODE<3) XtSetSensitive(psizeradio[3],False);
	ps_set1=PSSIZEMODE;

	label2 = XtVaCreateManagedWidget("pmode", labelWidgetClass, setting_dialog,
						XtNlabel, "Output Mode",
						XtNborderWidth, 0,
						XtNfromVert, label1,
						XtNvertDistance, 10,
						NULL);

	poutradio[0]=XtVaCreateManagedWidget("ps21", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label2, 
						XtNfromVert, label1,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
	XtAddCallback(poutradio[0], XtNcallback, psbtn_cb, (XtPointer)psmode[0]);

	for (i=1; i<3; i++){
		sprintf(bname, "ps2%d", i+1);
		poutradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, poutradio[i-1], 
						XtNfromVert, label1,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
		XtAddCallback(poutradio[i], XtNcallback, psbtn_cb, (XtPointer)psmode[i]);
		XtVaSetValues(poutradio[i], XtNradioGroup, poutradio[i-1], NULL);
	}
	XtVaSetValues(poutradio[PSFMODE], XtNstate, True, NULL);
/*	XtSetSensitive(poutradio[0],False);		*/
	ps_set2=PSFMODE;

	label3 = XtVaCreateManagedWidget("pcol", labelWidgetClass, setting_dialog,
						XtNlabel, "Print Color",
						XtNborderWidth, 0,
						XtNfromVert, label2,
						XtNvertDistance, 10,
						NULL);

	pcolradio[0]=XtVaCreateManagedWidget("ps31", toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, label3, 
						XtNfromVert, label2,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
	XtAddCallback(pcolradio[0], XtNcallback, psbtn_cb, (XtPointer)pssize[0]);

	for (i=1; i<4; i++){
		sprintf(bname, "ps3%d", i+1);
		pcolradio[i]=XtVaCreateManagedWidget(bname, toggleWidgetClass, setting_dialog, 
						XtNfromHoriz, pcolradio[i-1], 
						XtNfromVert, label2,
						XtNvertDistance, 10,
						XtNtranslations, trans2,
						XtNlabel, pssize[1], NULL);
		XtAddCallback(pcolradio[i], XtNcallback, psbtn_cb, (XtPointer)pscol[i]);
		XtVaSetValues(pcolradio[i], XtNradioGroup, pcolradio[i-1], NULL);
	}
	XtVaSetValues(pcolradio[PSCOLMODE], XtNstate, True, NULL);
	ps_set3=PSCOLMODE;

#ifdef GIF
/*	GIF Settings	*/

	label0 = make_label_widget("stitle2",setting_dialog,"      <<< GIF Settings >>>",label3,16,0);

/*
	label3 = make_onoff_button("glabel1", setting_dialog,"Reverse B/W",label0,10,0,"gfb",gifbw);
	XtAddCallback(gifbw[0], XtNcallback, gifbtn_cb, (XtPointer)onofflab[0]);
	XtAddCallback(gifbw[1], XtNcallback, gifbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(gifbw[1], XtNradioGroup, gifbw[0], NULL);
	XtVaSetValues(gifbw[GIFBWREVMODE], XtNstate, True, NULL);
	gifbw_num=GIFBWREVMODE;
*/
	label3 = make_onoff_button("glabel1", setting_dialog,"Gray Color ",label0,10,0,"gfb",gifbw);
	XtAddCallback(gifbw[0], XtNcallback, gifbtn_cb, (XtPointer)onofflab[0]);
	XtAddCallback(gifbw[1], XtNcallback, gifbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(gifbw[1], XtNradioGroup, gifbw[0], NULL);
	XtVaSetValues(gifbw[GIFGRAYMODE], XtNstate, True, NULL);
	gifgray_num=GIFGRAYMODE;

	label3 = XtVaCreateManagedWidget("glabel2", labelWidgetClass, setting_dialog,
						XtNlabel, " Delay",
						XtNborderWidth, 0,
						XtNfromVert, label0,
						XtNfromHoriz,gifbw[1], 
						XtNhorizDistance, 20,
						XtNvertDistance, 10,
						NULL);

	text_delay = XtVaCreateManagedWidget("deltext", asciiTextWidgetClass, setting_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label0,
						XtNfromHoriz, label3,
						XtNvertDistance, 10,
						XtNborderWidth, 1,
						XtNwidth, INPUTLESS,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label1 = XtVaCreateManagedWidget("glabel21", labelWidgetClass, setting_dialog,
						XtNlabel, " /100 sec",
						XtNborderWidth, 0,
						XtNfromVert, label0,
						XtNfromHoriz,text_delay, 
						XtNvertDistance, 10,
						NULL);

	label0 = label3;
	label3 = make_onoff_button("glabel3", setting_dialog,"Transparent",label0,10,0,"gft",giftr);
	XtAddCallback(giftr[0], XtNcallback, gifbtn_cb, (XtPointer)onofflab[0]);
	XtAddCallback(giftr[1], XtNcallback, gifbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(giftr[1], XtNradioGroup, giftr[0], NULL);
	XtVaSetValues(giftr[GIFSETB], XtNstate, True, NULL);
	giftr_num=GIFSETB;

	label2 = XtVaCreateManagedWidget("glabel4", labelWidgetClass, setting_dialog,
						XtNlabel, "  Loop",
						XtNborderWidth, 0,
						XtNfromVert, label0,
						XtNfromHoriz,giftr[1], 
						XtNhorizDistance, 20,
						XtNvertDistance, 10,
						NULL);

	text_loop = XtVaCreateManagedWidget("loptext", asciiTextWidgetClass, setting_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label0,
						XtNfromHoriz, label2,
						XtNvertDistance, 10,
						XtNborderWidth, 1,
						XtNwidth, INPUTLESS,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);

	label3 = make_onoff_button("glabel5", setting_dialog,"Interlace  ",label3,10,0,"gfi",gifit);
	XtAddCallback(gifit[0], XtNcallback, gifbtn_cb, (XtPointer)onofflab[0]);
	XtAddCallback(gifit[1], XtNcallback, gifbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(gifit[1], XtNradioGroup, gifit[0], NULL);
	XtVaSetValues(gifit[GIFSETI], XtNstate, True, NULL);
	gifit_num=GIFSETI;

	label0 = label3;
	label3 = make_onoff_button("glabel6", setting_dialog,"Antialias  ",label3,10,0,"gfa",gifaa);
	XtAddCallback(gifaa[0], XtNcallback, gifbtn_cb, (XtPointer)onofflab[0]);
	XtAddCallback(gifaa[1], XtNcallback, gifbtn_cb, (XtPointer)onofflab[1]);
	XtVaSetValues(gifaa[1], XtNradioGroup, gifaa[0], NULL);
	XtVaSetValues(gifaa[GIFAAMODE], XtNstate, True, NULL);
	gifaa_num=GIFAAMODE;
	gifres_num=GIFAARESOLVE;
	if (GIFAAMODE) gif_setaamode(GIFAAMODE,GIFAARESOLVE);
	text_aares = XtVaCreateManagedWidget("restext", asciiTextWidgetClass, setting_dialog,
						XtNeditType, XawtextEdit,
						XtNfromVert, label0,
						XtNfromHoriz, gifaa[1],
						XtNvertDistance, 10,
						XtNborderWidth, 1,
						XtNwidth, INPUTONE,
						XtNtranslations, trans,
						XtNdisplayCaret, False,
						NULL);
	if (gifaa_num==0) XtSetSensitive(text_aares,FALSE);
		else 		  XtSetSensitive(text_aares,True);

#endif

/*	Final line	*/
	label0=label3;
	button1=XtVaCreateManagedWidget("sok", commandWidgetClass, setting_dialog,
						XtNlabel, " OK ",
						XtNfromVert, label0,
         /*						XtNfromHoriz, text2,*/
						XtNvertDistance, 18,
						XtNborderWidth, 1, NULL);

	button2=XtVaCreateManagedWidget("scancel", commandWidgetClass, setting_dialog,
						XtNlabel, "Cancel",
						XtNfromVert, label0,
						XtNfromHoriz, button1,
						XtNvertDistance, 18,
						XtNhorizDistance, 20,
						XtNborderWidth, 1, NULL);

	button3=XtVaCreateManagedWidget("sreset", commandWidgetClass, setting_dialog,
						XtNlabel, "Reset",
						XtNfromVert, label0,
						XtNfromHoriz, button2,
						XtNhorizDistance, 20,
						XtNvertDistance, 18,
						XtNborderWidth, 1, NULL);

	XtSetKeyboardFocus(setting_dialog, text_s[0]);
	focus_s=text_s[0];
	XtAddCallback(button1, XtNcallback, (XtCallbackProc)setting_proc, (XtPointer)text_s);
	XtAddCallback(button2, XtNcallback, (XtCallbackProc)setting_cancel, setting_popup);
	XtAddCallback(button3, XtNcallback, (XtCallbackProc)setting_reset, setting_popup);
	XtRealizeWidget(setting_popup);
	if (schecks) XtVaSetValues(checks_button, XtNbitmap, check_bmp, NULL);
		else 	 XtVaSetValues(checks_button, XtNbitmap, blank_bmp, NULL);
	wm_delete_window = XInternAtom(XtDisplay(setting_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(setting_popup), XtWindow(setting_popup), &wm_delete_window, 1);
	XtVaSetValues(c2radio[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(c2radio[2], XtNlabel, "X", NULL);
	XtVaSetValues(c3radio[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(p3radio[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(angradio[1], XtNlabel, onofflab[0], NULL);
	for (i=0;i<4;i++) XtVaSetValues(psizeradio[i], XtNlabel, pssize[i], NULL);
	for (i=0;i<3;i++) XtVaSetValues(poutradio[i], XtNlabel, psmode[i], NULL);
	for (i=0;i<4;i++) XtVaSetValues(pcolradio[i], XtNlabel, pscol[i], NULL);
	XtVaSetValues(gifbw[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(giftr[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(gifit[1], XtNlabel, onofflab[0], NULL);
	XtVaSetValues(gifaa[1], XtNlabel, onofflab[0], NULL);
/*
	for (i=MAX_SET_TEXT2;i<MAX_SET_TEXT;i++) XtSetSensitive(text_s[i],False);
*/
}

static void memo_frame(Widget w, XtPointer client_data,  XtPointer call_data)
{
	if (nmemo){
		XawListChange(memo_list, memolist, nmemo, 0, True);

		XtSetSensitive(memo_button,FALSE);
		XtPopup(memo_popup,XtGrabNonexclusive);
/*		XtPopup(memo_popup,XtGrabExclusive);	*/
	}
}

static void memo_cancel(Widget w,Widget shell)
{
	XtPopdown(memo_popup);
	XtSetSensitive(memo_button,TRUE);
}

static void create_memo_dialog(Widget form)
{
	static XtActionsRec actions[]={
		{"mok_cb", (XtActionProc)memo_cancel},
	};
	static XtTranslations trans,trans1;
	static Atom wm_delete_window;

	Widget button, text, dialog, vport, form1;

	XtAppAddActions(app_con, actions, XtNumber(actions));

	trans1 = XtParseTranslationTable("#override\n\
						<Message>WM_PROTOCOLS: mok_cb()");

	trans = XtParseTranslationTable("#override\n\
						<Key>Return: mok_cb()\n\
						<Key>KP_Enter: mok_cb()\n\
						Ctrl<Key>M: mok_cb()\n\
						Ctrl<Key>J: mok_cb()");

	memo_popup=XtVaCreatePopupShell("memo_popup",
						transientShellWidgetClass,form,XtNtitle,"Data Notes",
						XtNtranslations, trans1,
						NULL);

	dialog = XtVaCreateManagedWidget("memo_dialog", formWidgetClass, memo_popup,
						XtNborderWidth, 0,
						NULL);

	form1 = XtVaCreateManagedWidget("mform1", panedWidgetClass, dialog,
						XtNborderWidth, 1,
						XtNwidth, 400,
						XtNheight, 200,
						XtNtranslations, trans,
						NULL);

	vport = XtVaCreateManagedWidget("mvport", viewportWidgetClass, form1,
						XtNallowVert, True,
						XtNallowHoriz, True,
						XtNuseRight, True,
						XtNuseBottom, True,
						NULL);
	memo_list = XtVaCreateManagedWidget("mlist", listWidgetClass, vport,
						XtNverticalList, True,
						XtNcolumnSpacing, 5,
						XtNdefaultColumns, 1,
						XtNforceColumns, True,
						NULL);
  
	button=XtVaCreateManagedWidget("mok", commandWidgetClass, dialog,
						XtNlabel, " OK ",
						XtNfromVert, form1,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						XtNborderWidth, 1, NULL);

	XtAddCallback(button, XtNcallback, (XtCallbackProc)memo_cancel, memo_popup);
	XtSetSensitive(memo_button,FALSE);

	XtRealizeWidget(memo_popup);
	wm_delete_window = XInternAtom(XtDisplay(memo_popup), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(memo_popup), XtWindow(memo_popup), &wm_delete_window, 1);
}

void frames_first_page(int ind)
{
	char str[20];
	int md;

	clear_modes();
	set_frames_initialize(ind);
	set_special_buttons();
	set_title_name(0);
	XtVaSetValues(number_label,XtNlabel,"    1",NULL);
	if (start_page<=step_no) XtSetSensitive(prev_button,False);
	sprintf(str,"Step %3d",step_no);
	XtVaSetValues(step_button,XtNlabel,str,NULL);
	button_on=1;
	md=BWREVMODE;
	BWREVMODE=get_colormode();
	color_exchange(md);
	if( BWREVMODE ) {
		XtVaSetValues(mode_button, XtNforeground, 0x000000, XtNbackground, 0xffffffff, NULL );
	  }
	  else {
		XtVaSetValues(mode_button, XtNforeground, 0xffffff, XtNbackground, 0x00000000, NULL );
	}
}

static void all_clear()
{
	int i;
	ANALYZEMODE=ANACOL=0;		anal_mode=0;
	clear_scales();
	clear_settings();
	COLORNOW=0;
	scale2d_mask=-1;		cont2d_mask=-1;
	for (i=0;i<CHECKNUM2D;i++) {
		if (scheck2[i]) XtVaSetValues(check2_button[i], XtNbitmap, blank_bmp, NULL);
		scheck2[i]=0;
	}
	scale3d_mask=-1;		cont3d_mask=-1;
	for (i=0;i<CHECKNUM3D;i++) {
		if (scheck3[i]) XtVaSetValues(check3_button[i], XtNbitmap, blank_bmp, NULL);
		scheck3[i]=0;
	}
}

void file_process(int sc)
{
	String str;
	int i;

	if (seq_no>0) return;

	XtSetSensitive(file_button,TRUE);

	if (sc==0) all_clear();
	clear_colormap();

	for (i=0;i<nmemo;i++) XtFree((XtPointer)memolist[i]);
	nmemo=0;
	XtSetSensitive(memo_button,False);
	comstring[0]='\0';

	get_next_file();
	frames_first_page(1);
}

static void create_tplot_window(int num, int den)
{
	int argc0=0, n, i, wid, hei;
/*	Position x, y;		*/
	char **argv0=NULL;

	static XtActionsRec actions[]={
		{ "redrawwindow" , (XtActionProc)redraw_window},
		{ "nextframe" , (XtActionProc)next_frame},
		{ "prevframe" , (XtActionProc)prev_frame},
		{ "nextframesc" , (XtActionProc)next_frame_sc},
		{ "prevframesc" , (XtActionProc)prev_frame_sc},
		{ "firstframe" , (XtActionProc)first_frame},
		{ "lastframe" , (XtActionProc)last_frame},
		{ "bwcolor" , (XtActionProc)bw_color},
		{ "checkmouse" , (XtActionProc)check_mouse},
/*		{ "gotoproc" , (XtActionProc)goto_proc},
		{ "stepproc" , (XtActionProc)step_proc},
		{ "seqwindow" , (XtActionProc)seq_window},
		{ "gotowindow" , (XtActionProc)goto_window},	*/
		{ "resultok" , (XtActionProc)result_ok},
		{ "quitproc" ,(XtActionProc)quit_proc},
		{ "delete_chara" , (XtActionProc)delete_chara},
	};
	static XrmOptionDescRec options[]={
		{"-size",".Size",XrmoptionSepArg,NULL},
	};
/*	static Arg top_args[]={XtNallowShellResize, TRUE};	*/
	static String fallback_resources[]={
		"*XFrames.translations: #override\\n\
			<Message>WM_PROTOCOLS: quitproc()",
		"*form.translations: #override\\n\
			Meta<Key>Q: quitproc()",
/*		"*xframes.fromVert: seq_button",	*/
		"*xframes.translations: #override\\n\
			<Expose>: redrawwindow()\\n\
			<Btn5Up>: nextframesc()\\n\
			<Btn4Up>: prevframesc()\\n\
			<Btn3Up>: nextframe()\\n\
			<Btn2Up>: bwcolor()\\n\
			<Btn1Up>: checkmouse()\\n\
			<Configure>: redrawwindow()\\n\
			<Key>Up: prevframe()\\n\
			<Key>Down: nextframe()\\n\
			<Key>Home: firstframe()\\n\
			<Key>End: lastframe()\\n\
			Meta<Key>Q: quitproc()",
/*		"*seq_button.menuName: seq_menu",
		"*mode_button.menuName: mode_menu",
*/

#ifdef GIF
		"*setting_button.fromHoriz: gif_button",
#else
		"*setting_button.fromHoriz: ps_button",
#endif
		"*result_text.translations: #override \\n\
			<Key>KP_Enter: resultok() \\n\
			<Key>Return: resultok()",
		"*res_dialog.translations: #override \\n\
			<Key>KP_Enter: resultok() \\n\
			<Key>Return: resultok()",
		NULL ,
	};
	Widget form, entry, seq_menu, mode_menu, form1, no_label;
	static Atom wm_delete_window;

/*	XtSetLanguageProc(NULL,NULL,NULL);	*/

	toplevel=XtVaAppInitialize(&app_con,"XFrames",
	             options,XtNumber(options),&argc0,argv0,fallback_resources,NULL);
/*	XtSetValues(toplevel,top_args,1);	*/

	XtAppAddActions(app_con, actions, XtNumber(actions));
	
	form=XtVaCreateManagedWidget("form", formWidgetClass,toplevel,NULL);

	check_bmp = XCreateBitmapFromData(XtDisplay(toplevel), DefaultRootWindow(XtDisplay(toplevel)),
											(char *) check_bits, check_width, check_height);
	blank_bmp = XCreateBitmapFromData(XtDisplay(toplevel), DefaultRootWindow(XtDisplay(toplevel)),
											(char *) blank_bits, check_width, check_height);

/* Upper row */
	no_label = XtVaCreateManagedWidget("no_label", labelWidgetClass, form,
						XtNlabel, "No.",
						XtNborderWidth, 0,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	number_label = XtVaCreateManagedWidget("number_label", labelWidgetClass, form,
						XtNlabel, "    1",
						XtNfromHoriz, no_label,
						XtNborderWidth, 0,
						XtNhorizDistance, 0,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);

	step_button=XtVaCreateManagedWidget("step_button" , commandWidgetClass ,form, 
						XtNlabel,"Step   1",
						XtNfromHoriz, number_label,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(step_button, XtNcallback, (XtCallbackProc)step_frame, NULL);
	create_step_dialog(form);

	next_button=XtVaCreateManagedWidget("next_button" , commandWidgetClass , form, 
						XtNlabel, "Next",
						XtNfromHoriz, step_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(next_button, XtNcallback, (XtCallbackProc)next_frame, NULL);
	prev_button=XtVaCreateManagedWidget("prev_button" , commandWidgetClass , form, 
						XtNlabel,"Prev",
						XtNfromHoriz, next_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(prev_button, XtNcallback, (XtCallbackProc)prev_frame, NULL);

	first_button=XtVaCreateManagedWidget("first_button", commandWidgetClass ,form, 
						XtNlabel, "First",
						XtNfromHoriz, prev_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(first_button, XtNcallback, (XtCallbackProc)first_frame, NULL);
	last_button=XtVaCreateManagedWidget("last_button", commandWidgetClass ,form, 
						XtNlabel, "Last",
						XtNfromHoriz, first_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(last_button, XtNcallback, (XtCallbackProc)last_frame, NULL);
	rotate_button=XtVaCreateManagedWidget("rotate_button", commandWidgetClass ,form, 
						XtNlabel, "Rotate",
						XtNfromHoriz, last_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(rotate_button, XtNcallback, (XtCallbackProc)rotate_frame, NULL);
	next1_button=XtVaCreateManagedWidget("next1_button", commandWidgetClass ,form, 
						XtNlabel, "+1",
						XtNfromHoriz, rotate_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(next1_button, XtNcallback, (XtCallbackProc)next1_frame, NULL);
	prev1_button=XtVaCreateManagedWidget("prev1_button", commandWidgetClass ,form, 
						XtNlabel, "-1",
						XtNfromHoriz, next1_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(prev1_button, XtNcallback, (XtCallbackProc)prev1_frame, NULL);

	file_button=XtVaCreateManagedWidget("file_button" , commandWidgetClass ,form, 
						XtNlabel, "File",
						XtNfromHoriz, prev1_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(file_button, XtNcallback, (XtCallbackProc)file_frame, (XtPointer)1);
	create_file_dialog(form, app_con);

	quit_button=XtVaCreateManagedWidget("quit_button", commandWidgetClass ,form, 
						XtNlabel, "Quit",
						XtNfromHoriz, file_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(quit_button, XtNcallback, (XtCallbackProc)quit_proc , NULL);
/*
	xy_text = XtVaCreateManagedWidget("xy_text", labelWidgetClass, form, 
						XtNlabel, "",
						XtNborderWidth, 0,
						XtNjustify, XtJustifyLeft,
						XtNresize, False,
						XtNfromHoriz, quit_button,
						XtNwidth, 180,
						XtNhorizDistance, 15,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	comstring[0]='\0';
*/
/* Lower row */
	seq_button=XtVaCreateManagedWidget("seq_button", menuButtonWidgetClass,form,
						XtNlabel, "Sequence ",
						XtNfromVert, number_label,
						XtNmenuName, "seq_menu",
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	seq_menu=XtVaCreatePopupShell("seq_menu", simpleMenuWidgetClass,seq_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
#ifdef GIF
	n=(int)XtNumber(sequences)-3;
	if (PSWRITE) n++;
	if (GIFWRITE) n+=2;
#else
	n=(int)XtNumber(sequences)-1;
	if (PSWRITE) n++;
#endif
	for (i=0;i<n;i++) {
		entry=XtVaCreateManagedWidget(sequences[i],smeBSBObjectClass,seq_menu,NULL);
		XtAddCallback(entry,XtNcallback,(XtCallbackProc)seq_proc,(XtPointer)i);
	}
	
	start_button=XtVaCreateManagedWidget("start_button" , commandWidgetClass , form, 
						XtNlabel, "Start",
						XtNfromHoriz, seq_button,
						XtNfromVert, number_label,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL),
	XtAddCallback(start_button, XtNcallback, (XtCallbackProc)start_proc, NULL);
/*  color menu
	mode_button=XtVaCreateManagedWidget("mode_button", menuButtonWidgetClass, form,
						XtNlabel, " Color ",
						XtNfromVert, number_label,
						XtNfromHoriz, start_button,
						XtNhorizDistance, 10,
						XtNmenuName, "mode_menu",
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);

	mode_menu=XtVaCreatePopupShell("mode_menu",	simpleMenuWidgetClass,mode_button,NULL);
	for (i=0;i<(int)XtNumber(color_modes);i++) {
		entry=XtVaCreateManagedWidget(color_modes[i],
					smeBSBObjectClass,mode_menu,NULL);
		XtAddCallback(entry,XtNcallback,(XtCallbackProc)mode_proc,(XtPointer)i);
	}
*/
	set_scale_translations();
	mode_button=XtVaCreateManagedWidget("mode_button", commandWidgetClass, form,
						XtNlabel, " Color ",
						XtNfromVert, number_label,
						XtNfromHoriz, start_button,
						XtNhorizDistance, 10,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);

	XtAddCallback(mode_button, XtNcallback, (XtCallbackProc)color_proc, NULL);

	scale_button=XtVaCreateManagedWidget("scale_button" , commandWidgetClass ,form, 
						XtNlabel, "Scale",
						XtNfromVert, number_label,
						XtNfromHoriz, mode_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(scale_button, XtNcallback, (XtCallbackProc)scale_frame, NULL);

	create_scale2_dialog(form);
	create_scale3_dialog(form);

	analyze_button=XtVaCreateManagedWidget("analyze_button" , commandWidgetClass ,form, 
						XtNlabel, "Analyze",
						XtNfromVert, number_label,
						XtNfromHoriz, scale_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(analyze_button, XtNcallback, (XtCallbackProc)analyze_frame, NULL);
	create_analyze_dialog(form);
	create_result_dialog(form);

#ifdef HARDCOPY_MENU
	hardcopy_button=XtVaCreateManagedWidget("hardcopy_button", commandWidgetClass ,form, 
						XtNlabel, "Hardcopy",
						XtNfromVert, number_label,
						XtNfromHoriz, analyze_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(hardcopy_button, XtNcallback, (XtCallbackProc)hardcopy_proc, NULL);
#endif
	filter_button=XtVaCreateManagedWidget("filter_button", commandWidgetClass ,form, 
						XtNlabel, "Filter",
						XtNfromVert, number_label,
#ifdef HARDCOPY_MENU
						XtNfromHoriz, hardcopy_button,
#else
						XtNfromHoriz, analyze_button,
#endif
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(filter_button, XtNcallback, (XtCallbackProc)filter_proc, NULL);

	ps_button=XtVaCreateManagedWidget("ps_button" , commandWidgetClass ,form, 
						XtNlabel, "PSOO",
						XtNfromVert, number_label,
						XtNfromHoriz, filter_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(ps_button, XtNcallback, (XtCallbackProc)psout_proc, NULL);
	if (PSWRITE==0) XtSetSensitive(ps_button,FALSE);

#ifdef GIF
	gif_button=XtVaCreateManagedWidget("gif_button" , commandWidgetClass ,form, 
						XtNlabel, "GIFO",
						XtNfromVert, number_label,
						XtNfromHoriz, ps_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(gif_button, XtNcallback, (XtCallbackProc)gifout_proc, NULL);
	if (GIFWRITE==0) XtSetSensitive(gif_button,FALSE);
#endif

	setting_button=XtVaCreateManagedWidget("setting_button" , commandWidgetClass ,form, 
						XtNlabel, "Setting",
						XtNfromVert, number_label,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(setting_button, XtNcallback, (XtCallbackProc)setting_frame, NULL);
	create_setting_dialog(form);

	memo_button=XtVaCreateManagedWidget("memo_button" , commandWidgetClass ,form, 
						XtNlabel, "Notes",
						XtNfromVert, number_label,
						XtNfromHoriz, setting_button,
						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
						NULL);
	XtAddCallback(memo_button, XtNcallback, (XtCallbackProc)memo_frame, NULL);
	create_memo_dialog(form);

/*	if (*filename=='\0' || check_wildcard(filename)) {		*/
	if (*filename=='\0' || flistno>1) {
		file_frame(file_button,0);
		while (1) {
			XEvent ev;
			XtAppNextEvent(app_con,&ev);
			XtDispatchEvent(&ev);
			if (ev.type==UnmapNotify) break;
		}
	}

	start_file();
/*
	if (GWIDTH>WINWIDTH) 	wid=GWIDTH*GWRNUM/GWRDEN;
		else			 	wid=WINWIDTH*GWRNUM/GWRDEN;
	if (GHEIGHT>WINHEIGHT)  hei=GHEIGHT*GWRNUM/GWRDEN;
		else				hei=WINHEIGHT*GWRNUM/GWRDEN;
*/
	wid=GWIDTH*num/den;
	hei=GHEIGHT*num/den;

	form1=XtVaCreateManagedWidget("form1", formWidgetClass, form,
						XtNwidth, wid, XtNheight, hei,
						XtNfromVert, seq_button,
/*						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
*/						NULL);
	xy_text = XtVaCreateManagedWidget("xy_text", labelWidgetClass, form, 
						XtNlabel, "",
						XtNborderWidth, 1,
						XtNjustify, XtJustifyLeft,
						XtNresize, False,
						XtNfromVert, form1,
						XtNwidth, TEXTLINE,
/*						XtNleft, XtChainLeft,
						XtNright, XtChainLeft,
						XtNtop, XtChainTop,
						XtNbottom, XtChainTop,
*/						NULL);

	XtRealizeWidget(toplevel);
	wm_delete_window = XInternAtom(XtDisplay(toplevel), "WM_DELETE_WINDOW", False);
	XSetWMProtocols (XtDisplay(toplevel), XtWindow(toplevel), &wm_delete_window, 1);
	XtVaSetValues(seq_button, XtNlabel, "Sequence", NULL);
	XtVaSetValues(ps_button, XtNlabel, "PS", NULL);
#ifdef GIF
	XtVaSetValues(gif_button, XtNlabel, "GIF", NULL);
#endif

/*
	n=(wid-GWIDTH*GWRNUM/GWRDEN)/2;
	if (n<0) n=0;
	wid=GWIDTH*GWRNUM/GWRDEN;
	hei=GHEIGHT*GWRNUM/GWRDEN;
*/
	xframes = XtVaCreateManagedWidget("xframes",
						coreWidgetClass, form1,
						XtNwidth, wid, XtNheight, hei,
						XtNbackground, BlackPixel(XtDisplay(toplevel), 0),
						XtNhorizDistance, n, XtNvertDistance, 0,
/*						XtNleft, XtChainLeft,
						XtNtop, XtChainTop,
*/						NULL);
}

void recreate_window(int num, int den)
{
	clear_frames_window();
	create_tplot_window(num, den);
	clear_modes();
	exchange_window(GWIDTH, GHEIGHT, num, den);
}

static void tk_plot(void)
{
	while (1) {
		XEvent ev;

		XtAppNextEvent(app_con,&ev);
/*
		if (ev.type==ConfigureNotify) printf("conf\n");
		  else if (ev.type==Expose) printf("expose\n");
		  else if (ev.type==MapNotify) printf("map\n");
		  else if (ev.type==UnmapNotify) printf("unmap\n");
		  else if (ev.type==DestroyNotify) printf("destroy\n");
		  else if (ev.type==CirculateNotify) printf("circ\n");
		  else if (ev.type==GravityNotify) printf("grav\n");
		  else if (ev.type==ReparentNotify) printf("parent\n");
		  else if (ev.type==ButtonPress) printf("m-ButtonPress\n");
		  else if (ev.type==ButtonRelease) printf("m-release %d\n",ev.xbutton.button);
		  else printf("%d \n",ev.type);
*/
		XtDispatchEvent(&ev);
	}

/*
	XtAppMainLoop(app_con);
*/
}
#endif

void xl_plot(void)
{
	int err;

	start_file();
	set_frames_initialize(0);
	while (1) {
		while (1) {
			if (clr_stop(1)) break;
			err=next_frame_main(1);
			if (err==0) break;
			if (err<0) error_end("Reached to End Of File",1);
		}
		quit_main();
	}
}

void main(int argc,char **argv)
{
	int n=0;

/* added by Sakagami,H. 95/06/02 to supress unalign error msg */
#ifdef ALPHA
	suppressunaligned();
#endif

	set_app_initialize(argc,argv);
	if (WINMODE==0) {
		while (1) {
			start_file();
			set_frames_initialize(n++);
			quit_main();
		}
	}

#ifdef TOOLKIT	
	if (TGMODE) {
		create_tplot_window(GWRNUM, GWRDEN);
		initialize_tplot_frames();
		tk_plot();
	  }
	  else	xl_plot();
#else
	xl_plot();
#endif
}
