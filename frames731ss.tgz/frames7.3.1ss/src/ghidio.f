***********************************************
*            F  R  A  M  E  S  V.7            *
*        3D HIDDEN LINE PROCESS ROUTINES      *
*            PROGRAMMED BY T.TAGUCHI          *
*              NOVEMBER 27/2000               *
***********************************************
      SUBROUTINE FR_HCLEAR(N)
      PARAMETER (IDOTMAX=1600,DATAMAX=1.E5)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      COMMON /HIDDEN3D/ HMAX(0:IDOTMAX),HMIN(0:IDOTMAX),DH(0:IDOTMAX)
*      REAL*8 HMAX,HMIN,DH,B0
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      SAVE /HIDDEN3D/

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0.AND.N.LT.10000) THEN
         CALL GSENDBYTE(42,1)
         CALL GSENDBYTE(N,1)
      ENDIF

      IHIND = N
      IF (IHIND.GE.10000) IHIND = IHIND - 10000
      IF (IHIND.EQ.0) RETURN

      IF (IHIND.NE.2) THEN
*         B0 = by1-1
         B0 = -DATAMAX
       ELSE 
*         B0 = by2+1
         B0 = DATAMAX
      ENDIF

      DO 10 I = 0, IDOTMAX
         HMAX(I) = B0
*         HMIN(I) = by2+1
         HMIN(I) = DATAMAX
         DH(I)   = 0
  10  CONTINUE

      RETURN
      END

      SUBROUTINE SETHIDDEN(G1,G2)
      PARAMETER (IDOTMAX=1600)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      COMMON /HIDDEN3D/ HMAX(0:IDOTMAX),HMIN(0:IDOTMAX),DH(0:IDOTMAX)
*      REAL*8 HMAX,HMIN,DH

      K1 = G1+ixoff
      K2 = G2+ixoff+1
      IF (K1.LT.0)       K1 = 0
      IF (K2.GT.IDOTMAX) K2 = IDOTMAX
      DO 10 I = K1, K2
         IF (DH(I).GT.0) THEN
            HMAX(I) = HMAX(I) + DH(I)
            IF (HMIN(I).GT.HMAX(I)) HMIN(I) = HMAX(I)
          ELSE IF (DH(I).LT.0) THEN
            HMIN(I) = HMIN(I) + DH(I)
            IF (HMIN(I).GT.HMAX(I)) HMAX(I) = HMIN(I)
         ENDIF
         DH(I) = 0
   10  CONTINUE

      RETURN
      END

      SUBROUTINE HGWIOPSET(XX,YY)
      PARAMETER (IDOTMAX=1600)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      COMMON /HIDDEN3D/ HMAX(0:IDOTMAX),HMIN(0:IDOTMAX),DH(0:IDOTMAX)
*      REAL*8 HMAX,HMIN,DH
      COMMON /HIDDENPARM/ X1,Y1,DX1,DT,YV3,HMAX0,HMIN0,KX1,IV1,X0,Y0

      XK1 = XX + ixoff
      KX  = XK1
      DX  = XK1 - KX
      IF (KX.GE.0.AND.KX.LE.IDOTMAX) THEN
         IF (YY.LT.HMIN(KX)) THEN
            IF (DX.EQ.0) HMIN(KX) = YY
            CALL GWIOPSET(XX,YY)
         ENDIF
         IF (YY.GT.HMAX(KX)) THEN
            IF (DX.EQ.0) HMAX(KX) = YY
            CALL GWIOPSET(XX,YY)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE HGWIOLINE(XX1,YY1,XX2,YY2)
      PARAMETER (IDOTMAX=1600)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      COMMON /HIDDEN3D/ HMAX(0:IDOTMAX),HMIN(0:IDOTMAX),DH(0:IDOTMAX)
*      REAL*8 HMAX,HMIN,DH
      COMMON /HIDDENPARM/ X1,Y1,DX1,DT,YV3,HMAX0,HMIN0,KX1,IV1,X0,Y0

      X1  = XX1
      Y1  = YY1
      X2  = XX2
      Y2  = YY2
      XK1 = XX1 + ixoff
      XK2 = XX2 + ixoff
      IF (MIN(XK1,XK2).LT.0.OR.MAX(XK1,XK2).GT.IDOTMAX) RETURN

      KX1 = XK1
      DX1 = XK1 - KX1

      IF (X1.EQ.X2) THEN
         IF (Y1.LT.Y2) THEN
            Y3 = Y1
            Y1 = Y2
            Y2 = Y3
         ENDIF
         IF (DX1.EQ.0) THEN
            IF (Y1.GE.HMAX(KX1)) THEN
               Y3 = MAX(Y2,HMAX(KX1))
               CALL GWIOLINE(X1,Y1,X1,Y3,0)
               DH(KX1) = Y1 - HMAX(KX1)
            ENDIF
            IF (Y2.LE.HMIN(KX1)) THEN
               Y3 = MIN(Y1,HMIN(KX1))
               CALL GWIOLINE(X1,Y3,X1,Y2,0)
               DH(KX1) = Y2 - HMIN(KX1)
            ENDIF
          ELSE
            YV3 = HMAX(KX1) + (HMAX(KX1+1) - HMAX(KX1))*DX1 
            IF (Y1.GE.YV3) THEN
               Y3 = MAX(Y2,YV3)
               CALL GWIOLINE(X1,Y1,X1,Y3,0)
            ENDIF
            YV3 = HMIN(KX1) + (HMIN(KX1+1) - HMIN(KX1))*DX1 
            IF (Y2.LE.YV3) THEN
               Y3 = MIN(Y1,YV3)
               CALL GWIOLINE(X1,Y3,X1,Y2,0)
            ENDIF
         ENDIF
         RETURN
      ENDIF

      DT  = (Y2 - Y1)/(X2 - X1)
      IF (XK1.LT.0) THEN
         Y1  = Y1 - DT*XK1
         X1  = -ixoff
         XK1 = 0
       ELSE IF (XK2.LT.0) THEN
         Y2  = Y1 - DT*XK1
         X2  = -ixoff
         XK2 = 0
       ELSE IF (XK1.GT.IDOTMAX) THEN
         Y1  = Y1 + DT*(IDOTMAX - XK1)
         X1  = IDOTMAX-ixoff
         XK1 = IDOTMAX
       ELSE IF (XK2.GT.IDOTMAX) THEN
         Y2  = Y1 + DT*(IDOTMAX - XK1)
         X2  = IDOTMAX-ixoff
         XK2 = IDOTMAX
      ENDIF
 
      YV3 = HMAX(KX1) + (HMAX(KX1+1) - HMAX(KX1))*DX1
      IF (Y1.GE.YV3) THEN
         IV1 = 1
       ELSE
         YV3 = HMIN(KX1) + (HMIN(KX1+1) - HMIN(KX1))*DX1
         IF (Y1.LE.YV3) THEN
            IV1 = -1
          ELSE
            IV1 = 0
         ENDIF
      ENDIF
 
      X0 = X1
      Y0 = Y1

      KX2   = XK2
      HMAX0 = HMAX(KX1)
      HMIN0 = HMIN(KX1)

      IF (X1.LT.X2) THEN
         IN  = 1
         DTI = DT
       ELSE
         IN  = -1
         DTI = -DT
      ENDIF

      IF (DX1.NE.0) THEN
         IF (KX1.EQ.KX2) THEN
            CALL HIDDENLINE(XK2,Y2)
            IF (IV1.NE.0) CALL GWIOLINE(X0,Y0,X1,Y1,0)
            RETURN
         ENDIF

         IF (X1.LT.X2) THEN
            CALL HIDDENLINE(REAL(KX1+1),DT*(KX1+1-XK1)+Y1)
            KX1   = KX1 + 1
            HMAX0 = HMAX(KX1)
            HMIN0 = HMIN(KX1)
          ELSE
            CALL HIDDENLINE(REAL(KX1),DT*(KX1-XK1)+Y1)
         ENDIF
      ENDIF

      IF (Y1.GT.HMAX0) DH(KX1) = Y1 - HMAX0
      IF (Y1.LT.HMIN0) DH(KX1) = Y1 - HMIN0

      IF (X1.GT.X2.AND.KX2.NE.XK2) KX2 = KX2 + 1

  100 IF (KX1.NE.KX2) THEN
         XK1 = KX1
         X1  = KX1 - ixoff
         KX1 = KX1 + IN
         Y4  = Y1  + DTI
         YV4 = HMAX(KX1)
         IF (Y4.GE.YV4) THEN
            IV2 = 1
          ELSE 
            YV4 = HMIN(KX1)
            IF (Y4.LE.YV4) THEN
               IV2 = -1
             ELSE
               IV2 = 0
            ENDIF
         ENDIF

         IF (IV1.EQ.IV2) THEN

          ELSE IF (IV1.EQ.0) THEN
            IF (IV2.GT.0) YV3 = HMAX(KX1-IN)
            DDY = YV4-YV3-DTI
            IF (DDY.NE.0) THEN
               DX = (Y1-YV3)/DDY*IN
             ELSE
               DX = 0
            ENDIF
            X0 = X1 + DX
            Y0 = Y1 + DT*DX
          ELSE IF (IV2.EQ.0) THEN
            IF (IV1.GT.0) THEN
               YV5 = HMAX(KX1)
             ELSE
               YV5 = YV4
            ENDIF
            DDY = YV5-YV3-DTI
            IF (DDY.NE.0) THEN
               DX  = (Y1-YV3)/DDY*IN
               CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
            ENDIF
          ELSE IF (IV1.GT.0) THEN
            YV5 = HMAX(KX1)
            DDY = YV5-YV3-DTI
            IF (DDY.NE.0) THEN
               DX  = (Y1-YV3)/DDY*IN
               CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
            ENDIF
            YV5 = HMIN0
            DDY = YV4-YV5-DTI
            IF (DDY.NE.0) THEN
               DX  = (Y1-YV5)/DDY*IN
             ELSE
               DX  = 0
            ENDIF
            X0  = X1 + DX
            Y0  = Y1 + DT*DX
          ELSE
            YV5 = HMIN(KX1)
            DDY = YV5-YV3-DTI
            IF (DDY.NE.0) THEN
               DX  = (Y1-YV3)/DDY*IN
               CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
            ENDIF
            YV5 = HMAX0
            DDY = YV4-YV5-DTI
            IF (DDY.NE.0) THEN
               DX  = (Y1-YV5)/DDY*IN
             ELSE
               DX  = 0
            ENDIF
            X0  = X1 + DX
            Y0  = Y1 + DT*DX
         ENDIF
 
         IV1   = IV2
         YV3   = YV4
         Y1    = Y4
         HMAX0 = HMAX(KX1)
         HMIN0 = HMIN(KX1)
         IF (Y1.GT.HMAX0) DH(KX1) = Y1 - HMAX0
         IF (Y1.LT.HMIN0) DH(KX1) = Y1 - HMIN0
         GO TO 100
      ENDIF

      IF (XK2.NE.KX1) THEN
         XK1  = KX1
         X1   = KX1-ixoff
         IF (XK2.LT.XK1) THEN
            KX1   = KX1 - 1
            HMAX0 = HMAX(KX1)
            HMIN0 = HMIN(KX1)
         ENDIF
         DX1 = XK1 - KX1
         CALL HIDDENLINE(XK2,Y2)
      ENDIF
      IF (IV1.NE.0) CALL GWIOLINE(X0,Y0,X2,Y2,0)

      RETURN
      END

      SUBROUTINE HIDDENLINE(XK2,Y2)
      PARAMETER (IDOTMAX=1600)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      COMMON /HIDDEN3D/ HMAX(0:IDOTMAX),HMIN(0:IDOTMAX),DH(0:IDOTMAX)
*      REAL*8 HMAX,HMIN,DH
      COMMON /HIDDENPARM/ X1,Y1,DX1,DT,YV3,HMAX0,HMIN0,KX1,IV1,X0,Y0

      X2  = XK2 - ixoff
      DX2 = XK2 - KX1

      YV4 = HMAX0 + (HMAX(KX1+1) - HMAX0)*DX2
      IF (Y2.GE.YV4) THEN
         IV2 = 1
       ELSE 
         YV4 = HMIN0 + (HMIN(KX1+1) - HMIN0)*DX2 
         IF (Y2.LE.YV4) THEN
            IV2 = -1
          ELSE
            IV2 = 0
         ENDIF
      ENDIF

      DX21 = X2 - X1
      IF (IV1.EQ.IV2) THEN

       ELSE IF (IV1.EQ.0) THEN
         IF (IV2.GT.0) YV3 = HMAX0 + (HMAX(KX1+1) - HMAX0)*DX1
         DDY = YV4-YV3-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV3)/DDY
          ELSE
            DX  = 0
         ENDIF
         X0  = X1 + DX
         Y0  = Y1 + DT*DX
       ELSE IF (IV2.EQ.0) THEN
         IF (IV1.GT.0) THEN
            YV5 = HMAX0 + (HMAX(KX1+1) - HMAX0)*DX2
          ELSE
            YV5 = YV4
         ENDIF
         DDY = YV5-YV3-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV3)/DDY
            CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
         ENDIF
       ELSE IF (IV1.GT.0) THEN
         YV5 = HMAX0 + (HMAX(KX1+1) - HMAX0)*DX2
         DDY = YV5-YV3-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV3)/DDY
            CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
         ENDIF
         YV5 = HMIN0 + (HMIN(KX1+1) - HMIN0)*DX1
         DDY = YV4-YV5-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV5)/DDY
          ELSE
            DX  = 0
         ENDIF
         X0  = X1 + DX
         Y0  = Y1 + DT*DX
       ELSE
         YV5 = HMIN0 + (HMIN(KX1+1) - HMIN0)*DX2
         DDY = YV5-YV3-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV3)/DDY
            CALL GWIOLINE(X0,Y0,X1+DX,Y1+DT*DX,0)
         ENDIF
         YV5 = HMAX0 + (HMAX(KX1+1) - HMAX0)*DX1
         DDY = YV4-YV5-Y2+Y1
         IF (DDY.NE.0) THEN
            DX  = DX21*(Y1-YV5)/DDY
          ELSE
            DX  = 0
         ENDIF
         X0  = X1 + DX
         Y0  = Y1 + DT*DX
      ENDIF

      IV1 = IV2
      YV3 = YV4
      X1  = X2
      Y1  = Y2
 
      RETURN
      END

      SUBROUTINE HGWIOMINMAX(XH,YH,NH,XXXMIN,YYYMIN,XXXMAX,YYYMAX)
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,iclip
      real bx0,by0,bx1,by1,bx2,by2
      REAL XH(*),YH(*)

      IF (NH.GE.0) THEN
         XXXMIN = bx2 + 1
         YYYMIN = by2 + 1
         XXXMAX = bx1 - 1
         YYYMAX = by1 - 1
         NH0    = NH
       ELSE
         NH0 = -NH
      ENDIF

      DO 10 I = 1, NH0
         IF (XXXMIN.GT.XH(I)) XXXMIN = XH(I)
         IF (XXXMAX.LT.XH(I)) XXXMAX = XH(I)
         IF (YYYMIN.GT.YH(I)) YYYMIN = YH(I)
         IF (YYYMAX.LT.YH(I)) YYYMAX = YH(I)
  10   CONTINUE

      XXXMAX = XXXMAX + 1
      YYYMAX = YYYMAX + 1
      IF (XXXMIN.LT.bx1)   XXXMIN = bx1
      IF (XXXMAX.GT.bx2)   XXXMAX = bx2
      IF (YYYMIN.LT.by1)   YYYMIN = by1
      IF (YYYMAX.GT.by2)   YYYMAX = by2

      RETURN
      END
