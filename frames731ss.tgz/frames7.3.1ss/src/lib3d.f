***********************************
*     F  R  A  M  E  S  V.7       *
*    3D   FRAME  SUBROUTINES      *
*    PROGRAMMED BY T.TAGUCHI      *
***********************************
      SUBROUTINE FR_PMVIEW(IXXMIN,IYYMIN,IXXMAX,IYYMAX,IXX,IYY)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(31,1)
         CALL GSENDBYTE(IXXMIN,2)
         CALL GSENDBYTE(IYYMIN,2)
         CALL GSENDBYTE(IXXMAX,2)
         CALL GSENDBYTE(IYYMAX,2)
         CALL GSENDBYTE(IXX,2)
         CALL GSENDBYTE(IYY,2)
      ENDIF

      IXMIN  = IXXMIN
      IXMAX  = IXXMAX
      IYMIN  = IYYMIN
      IYMAX  = IYYMAX
      IZXMAX = IXX
      IZYMAX = IYY
      IFRAM  = 0
      IVIEW  = 1
      IPRREG = 0
      MODE3D = 0

      RETURN
      END

      SUBROUTINE FR_PMFRAME(XXMIN0,XXMAX0,YYMIN0,YYMAX0,ZZMIN0,ZZMAX0
     ,                                      ,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      REAL*8 XXMIN0,XXMAX0,YYMIN0,YYMAX0,ZZMIN0,ZZMAX0
      REAL*8 XXMIN,XXMAX,YYMIN,YYMAX,ZZMIN,ZZMAX
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /AXISNAMECOM3D/ XNAME,YNAME,ZNAME,IXYZNAME,LXNM,LYNM,LZNM
      CHARACTER XNAME*128,YNAME*128,ZNAME*128
      CHARACTER CH*20,FORM*20
      REAL LOGPOS(2:9)
      INTEGER INDS(2)
      DATA LOGPOS/0.3010300, 0.4771213,
     +            0.6020600, 0.6989700,
     +            0.7781513, 0.8450980,
     +            0.9030900, 0.9542425/

      IF (IGCANVAS.LT.0) RETURN

      MODE3D = 0

      CALL REGULATEGREGION(XXMIN0,XXMAX0,XXMIN,XXMAX)
      CALL REGULATEGREGION(YYMIN0,YYMAX0,YYMIN,YYMAX)
      CALL REGULATEGREGION(ZZMIN0,ZZMAX0,ZZMIN,ZZMAX)

      XMIN  = XXMIN
      XMAX  = XXMAX
      YMIN  = YYMIN
      YMAX  = YYMAX
      ZMIN  = ZZMIN
      ZMAX  = ZZMAX
      XTAN  = (IXMAX - IXMIN)/(XMAX - XMIN)
      YTAN  = (IYMIN - IYMAX)/(YMAX - YMIN)
      X0    = IXMIN - XTAN*XMIN
      Y0    = IYMAX - YTAN*YMIN

      ZXTAN = (IZXMAX - IXMAX)/(ZMAX - ZMIN)
      ZYTAN = (IZYMAX - IYMAX)/(ZMAX - ZMIN)
      ZX1   = IXMAX - ZXTAN*ZMIN
      ZY1   = IYMAX - ZYTAN*ZMIN
      ZX0   = ZX1 + X0 - IXMAX
      ZY0   = ZY1 + Y0 - IYMAX

      IF (IGPLT.GT.0) THEN
         IF (IVIEW.EQ.0) THEN
            CALL FR_PMVIEW(IXMIN,IYMIN,IXMAX,IYMAX,IZXMAX,IZYMAX)
         ENDIF
         IFRAM  = 1
         IF (IFRAM.NE.999) THEN
            CALL GSENDBYTE(32,1)
            CALL GFILE3FRAME(XXMIN,XXMAX,YYMIN,YYMAX,ZZMIN,ZZMAX,IND)
*            IF (IFSW.EQ.2) RETURN
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) THEN
         LABELAX = 0
         RETURN
      ENDIF

      IFRAM  = 1
      ICLP   = 0
      CALL GWIONOCLIP

      IF (IND.EQ.1) GO TO 997

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(0,-7)

      RXMIN = IXMIN
      RXMAX = IXMAX
      RYMIN = IYMIN
      RYMAX = IYMAX

      INDS(1) = MOD(LOGFORM,2)
      INDS(2) = MOD(LOGFORM/2,2)
      IF (INDS(1).NE.0.AND.XMAX-XMIN.LT.1.0) INDS(1) = 0
      IF (INDS(2).NE.0.AND.YMAX-YMIN.LT.1.0) INDS(2) = 0
      LOGFORM = 0

      IF (MOD(LABELAX,2).EQ.1) THEN
         IXNUM = 0
       ELSE
         IXNUM = 1
      ENDIF

      IF (MOD(LABELAX/2,2).EQ.1) THEN
         IYNUM = 0
       ELSE
         IYNUM = 1
      ENDIF

      IF (LABELAX/4.EQ.1) THEN
         IZNUM = 0
       ELSE
         IZNUM = 1
      ENDIF
      LABELAX = 0

      IF (IND.GE.2) THEN
         CALL GWIOLINE(RXMIN,RYMIN,RXMAX,RYMAX,1)
         IDX = IZXMAX - IXMAX
         IDY = IZYMAX - IYMAX
         CALL GWIOLINE(RXMAX,RYMAX,RXMAX+IDX,RYMAX+IDY,0)
         CALL GWIOLINE(RXMAX,RYMIN,RXMAX+IDX,RYMIN+IDY,0)
         CALL GWIOLINE(RXMIN,RYMIN,RXMIN+IDX,RYMIN+IDY,0)
         CALL GWIOLINE(RXMIN+IDX,RYMIN+IDY,RXMAX+IDX,RYMIN+IDY,0)
         CALL GWIOLINE(RXMAX+IDX,RYMIN+IDY,RXMAX+IDX,RYMAX+IDY,0)
         IF (IND.EQ.2) GO TO 999
      ENDIF

      DO 10 I = 1, 2
         IF (I.EQ.1) THEN
            AMIN = XMIN
            AMAX = XMAX
            PTAN = XTAN
            A0   = X0
            CALL GWIOLINE(RXMIN,RYMAX,RXMAX,RYMAX,0)
          ELSE
            AMIN = YMIN
            AMAX = YMAX
            PTAN = YTAN
            A0   = Y0
            CALL GWIOLINE(RXMIN,RYMIN,RXMIN,RYMAX,0)
         ENDIF

         IF (AMIN.GT.AMAX) THEN
            DA   = AMAX
            AMAX = AMIN
            AMIN = DA
         ENDIF

         IF (INDS(I).EQ.0) THEN
            CALL AXISDELFORM(AMIN,AMAX,DA,FORM,NS,NSC,NS1,NMZ,1)
            IF (NMZ.NE.0) THEN
               AMIN = AMIN*10.D0**(-NMZ)
               AMAX = AMAX*10.D0**(-NMZ)
               PTAN = PTAN*10.D0**(NMZ)
            ENDIF
          ELSE
            CALL LOGARLABEL(AMIN,AMAX,DA,NS,NS2,NMZ)
            NSC = 1
         ENDIF

         AMIN = AMIN - 0.001*DA
         AMAX = AMAX + 0.001*DA
         NM   = INT(AMIN/DA) - 1
         AAT  = NM*DA

1000     IF (AAT.LT.AMIN) THEN
            NM  = NM + 1
            AAT = DA*NM
            GO TO 1000
         ENDIF
         IF (I.EQ.1) THEN
            PA = RYMAX
1010        IF (AAT.LT.AMAX) THEN
               PAT = PTAN*AAT + X0
               NT  = 4
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT*2
                  IF (MOD(NM,NSC).EQ.0) THEN
                     IF (IXNUM.EQ.1) THEN
                        IF (INDS(1).EQ.0) THEN
                           WRITE(CH,FORM) AAT
                           CALL FWNUMBER(PAT,PA,CH,NMZ,1,2,-1,2)
                         ELSE
                           CALL LGNUMBER(PAT,PA,AAT,NMZ,1,2,-1)
                        ENDIF
                     ENDIF
                   ELSE IF (NS1.EQ.1) THEN
                     NT = NT*3/4
                  ENDIF
               ENDIF
               CALL GWIOLINE(PAT,RYMAX,PAT,RYMAX-NT,0)
               IF (INDS(1).NE.0.AND.NS2.NE.0) THEN
                  A2  = AAT
                  LA  = 2
                  NT  = 4
                  IF (NS2.EQ.5) LA = 5
1015              AAT = A2 - 1.0 + LOGPOS(LA)
                  PAT = PTAN*AAT + A0
                  IF (AAT.GT.A1) THEN
                    CALL GWIOLINE(PAT,RYMAX,PAT,RYMAX-NT,0)
                  ENDIF
                  LA = LA + NS2
                  IF (LA.LT.10) GO TO 1015
                  A1 = A2
               ENDIF
               NM  = NM + 1
               AAT = NM*DA
               GO TO 1010
            ENDIF
          ELSE
            PA = RXMIN
1020        IF (AAT.LT.AMAX) THEN
               PAT = PTAN*AAT + Y0
               NT  = 4
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT*2
                  IF (MOD(NM,NSC).EQ.0) THEN
                     IF (IYNUM.EQ.1) THEN
                        IF (INDS(2).EQ.0) THEN
                           WRITE(CH,FORM) AAT
                           CALL FWNUMBER(PA,PAT,CH,NMZ,-1,0,-1,0)
                         ELSE
                           CALL LGNUMBER(PA,PAT,AAT,NMZ,-1,0,-1)
                        ENDIF
                     ENDIF
                   ELSE IF (NS1.EQ.1) THEN
                     NT = NT*3/4
                  ENDIF
               ENDIF
               CALL GWIOLINE(RXMIN,PAT,RXMIN+NT,PAT,0)
               IF (INDS(2).NE.0.AND.NS2.NE.0) THEN
                  A2  = AAT
                  LA  = 2
                  NT  = 4
                  IF (NS2.EQ.5) LA = 5
1025              AAT = A2 - 1.0 + LOGPOS(LA)
                  PAT = PTAN*AAT + A0
                  IF (AAT.GT.A1) THEN
                    CALL GWIOLINE(RXMIN,PAT,RXMIN+NT,PAT,0)
                  ENDIF
                  LA = LA + NS2
                  IF (LA.LT.10) GO TO 1025
                  A1 = A2
               ENDIF
               NM  = NM + 1
               AAT = NM*DA
               GO TO 1020
            ENDIF
        ENDIF
   10  CONTINUE

      AMIN  = ZMIN
      AMAX  = ZMAX
      PTAN  = ZXTAN
      PTAN1 = ZYTAN
      CALL GWIOLINE(RXMAX,RYMAX,REAL(IZXMAX),REAL(IZYMAX),0)

      IF (AMIN.GT.AMAX) THEN
         DA   = AMAX
         AMAX = AMIN
         AMIN = DA
      ENDIF

      CALL AXISDELFORM(AMIN,AMAX,DA,FORM,NS,NSC,NS1,NMZ,1)
      IF (NMZ.NE.0) THEN
         AMIN = AMIN*10.D0**(-NMZ)
         AMAX = AMAX*10.D0**(-NMZ)
         PTAN = PTAN*10.D0**(NMZ)
         PTAN1 = PTAN1*10.D0**(NMZ)
      ENDIF

      AMIN = AMIN - 0.001*DA
      AMAX = AMAX + 0.001*DA
      NM   = INT(AMIN/DA) - 1
      AAT  = NM*DA

1031  IF (AAT.LT.AMIN) THEN
         NM  = NM + 1
         AAT = DA*NM
         GO TO 1031
      ENDIF
1030  IF (AAT.LT.AMAX) THEN
         PAT  = PTAN*AAT + ZX1
         PAT1 = PTAN1*AAT + ZY1
         NT   = 4
         IF (MOD(NM,NS).EQ.0) THEN
            NT = NT*2
            IF (MOD(NM,NSC).EQ.0) THEN
               IF (IZNUM.EQ.1) THEN
                  WRITE(CH,FORM) AAT
                  CALL FWNUMBER(PAT+NT,PAT1,CH,NMZ,1,0,2,1)
               ENDIF
             ELSE IF (NS1.EQ.1) THEN
               NT = NT*3/4
            ENDIF
         ENDIF
         CALL GWIOLINE(PAT+NT,PAT1,PAT,PAT1,0)
         NM  = NM + 1
         AAT = NM*DA
         GO TO 1030
      ENDIF

 999  CALL GWIOBDFLUSH(1)
 998  IF (IXYZNAME.NE.0) CALL FR_XYZNAME(' ',' ',' ')
 997  CONTINUE

      RETURN
      END

      SUBROUTINE FR_PMGRAPH(X,Y,Z,N,IC,MODE)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /HISTGRAMCOM/ HIST0,MODHIST
      REAL*8 X(*),Y(*),Z(*),DX,DY

      IF (IGCANVAS.LT.0) RETURN

      IF (MODE3D.NE.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR PMGRAPH')
         RETURN
      ENDIF

      IF (IFRAM.EQ.0) THEN
         CALL FRAMESERROR('CALL PMFRAM BEFORE CALLING PMGRAPH')
         RETURN
      ENDIF

      IND = MOD(MODE,100)
      M1  = ABS(MODE/100)
      IF (IND/10.LE.5) THEN
         MD = 0
         ID = IND
       ELSE
         MD = 1
         ID = MOD(IND,10)
      ENDIF

      IF (IC.LT.0) THEN
         ICM = 256
         IC0 = -IC - 1
         IC1 = MOD(IC0,1000)
         IC2 = IC0/1000
         IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
       ELSE
         ICM = 2
         IC1 = MOD(IC,100)
         IC2 = IC/100
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(34,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(N,4)
         IF (MD.EQ.0) THEN
            CALL GSEND38BYTE(Z,Z,Z,1,0)
            IF (M1.EQ.0) THEN
               CALL GSEND8BYTE(X,Y,N,1)
             ELSE IF (M1.EQ.2) THEN
               CALL GSEND8BYTE(Y(1),Y(2),1,0)
               CALL GSEND8BYTE(X,Y,N,5)
             ELSE
               CALL GSEND8BYTE(X(1),X(2),1,0)
               CALL GSEND8BYTE(X,Y,N,6)
            ENDIF
          ELSE
            IF (M1.EQ.0) THEN
               CALL GSEND38BYTE(X,Y,Z,N,1)
             ELSE IF (M1.EQ.2) THEN
               CALL GSEND8BYTE(Y(1),Y(2),1,0)
               CALL GSEND38BYTE(X,Y,Z,N,6)
             ELSE
               CALL GSEND8BYTE(X(1),X(2),1,0)
               CALL GSEND38BYTE(X,Y,Z,N,5)
            ENDIF
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (NSTEP.GT.0) THEN
         NS = NSTEP
         NM = N
       ELSE IF (NSTEP.EQ.0) THEN
         NS = 1
         NM = N
       ELSE
         NS = -NSTEP
         NM = N*NS
      ENDIF

      X0  = ZXTAN*Z(1) + ZX0
      Y0  = ZYTAN*Z(1) + ZY0
      X01 = X0
      Y01 = Y0

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(ICM,IC1)

      IF (M1.EQ.0) THEN
         IF (ID.LT.0.AND.IHIND.NE.0) THEN
            PX    = XTAN*X(1) + X0
            PY    = YTAN*Y(1) + Y0
            PXMIN = PX
            PXMAX = PX
            DO 10 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              PX1 = XTAN*X(I) + X0
              PY1 = YTAN*Y(I) + Y0
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
   10       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (ID.EQ.2) THEN
            DO 20 I = 1, NM, NS
               IF (MD.NE.0) THEN
                  X0 = ZXTAN*Z(I) + ZX0
                  Y0 = ZYTAN*Z(I) + ZY0
               ENDIF
               XX = XTAN*X(I) + X0
               YY = YTAN*Y(I) + Y0
               CALL GWIOPSET(XX,YY)
   20       CONTINUE
          ELSE IF (ID.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
   31       DO 30 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX = XTAN*X(I) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOMARKING(XX,YY,IM)
   30       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 31
            ENDIF
          ELSE IF (ID.EQ.4.OR.ID.EQ.5) THEN
            IF (ID.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            DO 40 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0  = ZXTAN*Z(I) + ZX0
                 Y0  = ZYTAN*Z(I) + ZY0
                 X01 = ZXTAN*Z(I+1) + ZX0
                 Y01 = ZYTAN*Z(I+1) + ZY0
              ENDIF
              XX  = XTAN*X(I) + X0
              YY  = YTAN*Y(I) + Y0
              XX1 = XTAN*X(I+1) + X01
              YY1 = YTAN*Y(I+1) + Y01
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
   40       CONTINUE
          ELSE IF (ID.EQ.6) THEN
            NS = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*X(2)
            DY1 = YTAN*Y(2)
            I2  = 1
            DO 60 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 I2  = I2 + NS/2
                 X0 = ZXTAN*Z(I2) + ZX0
                 Y0 = ZYTAN*Z(I2) + ZY0
              ENDIF
              XX2 = XTAN*X(I) + X0
              YY2 = YTAN*Y(I) + Y0
              DX2 = XTAN*X(I+1)
              DY2 = YTAN*Y(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX2,YY2,DY2)
              XX1  = XX2
              YY1  = YY2
              DX1  = DX2
              DY1  = DY2
   60       CONTINUE
          ELSE IF (ID.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(2,IC2)
            ENDIF
            IF (MODHIST.LE.0) THEN
   71          XX  = XTAN*X(1) + X0
               YY  = YTAN*Y(1) + Y0
               YY1 = YTAN*HIST0 + Y0
               DO 70 I = NS+1, NM, NS
                 XX1 = XTAN*X(I) + X0
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                 XX  = XX1
                 YY  = YTAN*Y(I) + Y0
   70          CONTINUE
               IF (IM.EQ.2.AND.IC2.GT.0) THEN
                  IM = 1
                  CALL GWIOCOLOR(2,IC2)
                  GO TO 71
               ENDIF
             ELSE
   73          XX  = XTAN*X(1) + X0
               YY  = YTAN*Y(1) + Y0
               XX1 = XTAN*HIST0 + X0
               DO 72 I = NS+1, NM, NS
                 YY1 = YTAN*Y(I) + Y0
                 CALL GWIOLINE(XX,YY,XX1,YY1,IM)
                 XX  = XTAN*X(I) + X0
                 YY  = YY1
   72          CONTINUE
               IF (IM.EQ.2.AND.IC2.GT.0) THEN
                  IM = 1
                  CALL GWIOCOLOR(2,IC2)
                  GO TO 73
               ENDIF
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 50 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX1 = XTAN*X(I) + X0
              YY1 = YTAN*Y(I) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
   50       CONTINUE
         ENDIF

       ELSE IF (M1.EQ.2) THEN
         IF (NM.LE.1) THEN
            DY = 1
          ELSE
            DY = (Y(2)-Y(1))/(NM-1)
         ENDIF
         IF (ID.LT.0.AND.IHIND.NE.0) THEN
            PX    = XTAN*X(1) + X0
            PY    = YTAN*Y(1) + Y0
            PXMIN = PX
            PXMAX = PX
            DO 210 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              PX1 = XTAN*X(I) + X0
              PY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  210       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (ID.EQ.2) THEN
            DO 220 I = 1, NM, NS
               IF (MD.NE.0) THEN
                  X0 = ZXTAN*Z(I) + ZX0
                  Y0 = ZYTAN*Z(I) + ZY0
               ENDIF
               XX = XTAN*X(I) + X0
               YY = YTAN*(DY*(I-1)+Y(1)) + Y0
               CALL GWIOPSET(XX,YY)
  220       CONTINUE
          ELSE IF (ID.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  231       DO 230 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX = XTAN*X(I) + X0
              YY = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOMARKING(XX,YY,IM)
  230       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 231
            ENDIF
          ELSE IF (ID.EQ.4.OR.ID.EQ.5) THEN
            IF (ID.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            DO 240 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0  = ZXTAN*Z(I) + ZX0
                 Y0  = ZYTAN*Z(I) + ZY0
                 X01 = ZXTAN*Z(I+1) + ZX0
                 Y01 = ZYTAN*Z(I+1) + ZY0
              ENDIF
              XX  = XTAN*X(I) + X0
              YY  = YTAN*(DY*(I-1)+Y(1)) + Y0
              XX1 = XTAN*X(I+1) + X01
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y01
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  240       CONTINUE
          ELSE IF (ID.EQ.6) THEN
            NS  = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*X(2)
            DY1 = YTAN*DY*2
            I2  = 1
            DO 260 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 I2  = I2 + NS/2
                 X0 = ZXTAN*Z(I2) + ZX0
                 Y0 = ZYTAN*Z(I2) + ZY0
              ENDIF
              XX2 = XTAN*X(I) + X0
              YY2 = YTAN*(DY*(I-1)+Y(1)) + Y0
              DX2 = XTAN*X(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX2,YY2,DY1)
              XX1  = XX2
              YY1  = YY2
              DX1  = DX2
  260       CONTINUE
          ELSE IF (ID.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  271       XX  = XTAN*X(1) + X0
            YY  = YTAN*Y(1) + Y0
            XX1 = XTAN*HIST0 + X0
            DO 270 I = NS+1, NM, NS
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
              XX  = XTAN*X(I) + X0
              YY  = YY1
  270       CONTINUE
            IF (IM.EQ.2.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(2,IC2)
               GO TO 271
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 250 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX1 = XTAN*X(I) + X0
              YY1 = YTAN*(DY*(I-1)+Y(1)) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
  250       CONTINUE
         ENDIF

       ELSE
         IF (NM.LE.1) THEN
            DX = 1
          ELSE
            DX = (X(2)-X(1))/(NM-1)
         ENDIF
         IF (ID.LT.0.AND.IHIND.NE.0) THEN
            PX    = XTAN*X(1) + X0
            PY    = YTAN*Y(1) + Y0
            PXMIN = PX
            PXMAX = PX
            DO 110 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              PX1 = XTAN*(DX*(I-1)+X(1)) + X0
              PY1 = YTAN*Y(I) + Y0
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              PX  = PX1
              PY  = PY1
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
  110       CONTINUE
            CALL SETHIDDEN(PXMIN,PXMAX)
            GO TO 999
         ENDIF

         IF (ID.EQ.2) THEN
            DO 120 I = 1, NM, NS
               IF (MD.NE.0) THEN
                  X0 = ZXTAN*Z(I) + ZX0
                  Y0 = ZYTAN*Z(I) + ZY0
               ENDIF
               XX = XTAN*(DX*(I-1)+X(1)) + X0
               YY = YTAN*Y(I) + Y0
               CALL GWIOPSET(XX,YY)
  120       CONTINUE
          ELSE IF (ID.EQ.3) THEN
            IM = 1
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  131       DO 130 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX = XTAN*(DX*(I-1)+X(1)) + X0
              YY = YTAN*Y(I) + Y0
              CALL GWIOMARKING(XX,YY,IM)
  130       CONTINUE
            IF (IM.EQ.1.AND.IC2.GT.0) THEN
               IM = 0
               CALL GWIOCOLOR(2,IC2)
               GO TO 131
            ENDIF
          ELSE IF (ID.EQ.4.OR.ID.EQ.5) THEN
            IF (ID.EQ.4) THEN
               IM = 0
             ELSE
               IM = 3
            ENDIF
            NS = NS + NS
            DO 140 I = 1, NM, NS
              IF (MD.NE.0) THEN
                 X0  = ZXTAN*Z(I) + ZX0
                 Y0  = ZYTAN*Z(I) + ZY0
                 X01 = ZXTAN*Z(I+1) + ZX0
                 Y01 = ZYTAN*Z(I+1) + ZY0
              ENDIF
              XX  = XTAN*(DX*(I-1)+X(1)) + X0
              YY  = YTAN*Y(I) + Y0
              XX1 = XTAN*(DX*(I-1)+X(1)) + X01
              YY1 = YTAN*Y(I+1) + Y01
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
  140       CONTINUE
          ELSE IF (ID.EQ.6) THEN
            NS  = NS + NS
            XX1 = XTAN*X(1) + X0
            YY1 = YTAN*Y(1) + Y0
            DX1 = XTAN*DX*2
            DY1 = YTAN*Y(2)
            I2  = 1
            DO 160 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 I2  = I2 + NS/2
                 X0 = ZXTAN*Z(I2) + ZX0
                 Y0 = ZYTAN*Z(I2) + ZY0
              ENDIF
              XX2 = XTAN*(DX*(I-1)+X(1)) + X0
              YY2 = YTAN*Y(I) + Y0
              DY2 = YTAN*Y(I+1)
              CALL GWIOSPLINE(XX1,DX1,YY1,DY1,XX2,DX1,YY2,DY2)
              XX1  = XX2
              YY1  = YY2
              DY1  = DY2
  160       CONTINUE
          ELSE IF (ID.EQ.7) THEN
            IM = 2
            CALL BARSECONDCOLOR(IC1,IC2)
            IF (IC1.EQ.0.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(2,IC2)
            ENDIF
  171       XX  = XTAN*X(1) + X0
            YY  = YTAN*Y(1) + Y0
            YY1 = YTAN*HIST0 + Y0
            DO 170 I = NS+1, NM, NS
              XX1 = XTAN*(DX*(I-1)+X(1)) + X0
              CALL GWIOLINE(XX,YY,XX1,YY1,IM)
              XX  = XX1
              YY  = YTAN*Y(I) + Y0
  170       CONTINUE
            IF (IM.EQ.2.AND.IC2.GT.0) THEN
               IM = 1
               CALL GWIOCOLOR(2,IC2)
               GO TO 171
            ENDIF
          ELSE
            XX = XTAN*X(1) + X0
            YY = YTAN*Y(1) + Y0
            DO 150 I = NS+1, NM, NS
              IF (MD.NE.0) THEN
                 X0 = ZXTAN*Z(I) + ZX0
                 Y0 = ZYTAN*Z(I) + ZY0
              ENDIF
              XX1 = XTAN*(DX*(I-1)+X(1)) + X0
              YY1 = YTAN*Y(I) + Y0
              CALL GWIOLINE(XX,YY,XX1,YY1,0)
              XX  = XX1
              YY  = YY1
  150       CONTINUE
         ENDIF
      ENDIF

  999 CALL GWIOBDFLUSH(1)
      RETURN
      END

      SUBROUTINE FR_PMDRAW(X,Y,IC,IND)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 X,Y

      IF (IGCANVAS.LT.0) RETURN

      IF (MODE3D.NE.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR PMDRAW')
         RETURN
      ENDIF

      ICM = 2
      IC1 = IC
      IF (IC.LT.0) THEN
         ICM = 256
         IC1 = -IC - 1
         IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(35,1)
         CALL GSENDBYTE(IND,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X,Y,1,1)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOCOLOR(ICM,IC1)

      IF (IND.LT.0.AND.IHIND.NE.0) THEN
         IF (IND.EQ.-2) THEN
            GX = XTAN*X + X0
            GY = YTAN*Y + Y0
            CALL HGWIOPSET(GX,GY)
          ELSE
            GX1 = XTAN*X + X0
            GY1 = YTAN*Y + Y0
            CALL HGWIOLINE(GX,GY,GX1,GY1)
            IF (GX1.LT.GX) THEN
               GG1 = GX1
               GG2 = GX
             ELSE
               GG1 = GX
               GG2 = GX1
            ENDIF
            CALL SETHIDDEN(GG1,GG2)
            GX = GX1
            GY = GY1
         ENDIF
       ELSE IF (IND.EQ.0) THEN
         GX = XTAN*X + X0
         GY = YTAN*Y + Y0
       ELSE IF (IND.EQ.2.OR.IND.EQ.-2) THEN
         GX = XTAN*X + X0
         GY = YTAN*Y + Y0
         CALL GWIOPSET(GX,GY)
       ELSE IF (IND.EQ.3.OR.IND.EQ.-3) THEN
         GX = XTAN*X + X0
         GY = YTAN*Y + Y0
         CALL GWIOMARKING(GX,GY,1)
       ELSE IF (IND.EQ.5.OR.IND.EQ.-5) THEN
         GX1 = XTAN*X + X0
         GY1 = YTAN*Y + Y0
         CALL GWIOLINE(GX,GY,GX1,GY1,3)
         GX  = GX1
         GY  = GY1
       ELSE
         GX1 = XTAN*X + X0
         GY1 = YTAN*Y + Y0
         CALL GWIOLINE(GX,GY,GX1,GY1,0)
         GX  = GX1
         GY  = GY1
      ENDIF

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_PMSET(Z)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 Z

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(41,1)
         CALL GSEND38BYTE(Z,Z,Z,1,0)
      ENDIF

      X0 = ZXTAN*Z + ZX0
      Y0 = ZYTAN*Z + ZY0

      RETURN
      END
