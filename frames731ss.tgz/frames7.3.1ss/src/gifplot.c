/******************************************************
 *              F  r  a  m  e  s   V.7.2.2            *
 *           GIF file I/O Routine for Frames          *
 *             Programmed by Y. Fujii, HIT            *
 *               Modified by T. Taguchi               *
 *                   July, 16, 2007                   *
 ******************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define NOT_USED_TPLOT
#include "frames.h"
#include "frames_canvas.h"

#ifdef GIF

#include <signal.h>

#include "gdfr.h"
/*
#include "gd.h"
#include "gdfontg.h"
#include "gdfonts.h"
#include "gdfontmb.h"
#include "gdfontl.h"
#include "gdfontt.h"
*/

#define FONTGIANT			0
#define FONTLARGE			1
#define FONTMEDIUMBOLD		2
#define FONTSMALL			3
#define FONTTINY			4

/*#define GIFREVBW					*/
#define Nothing
/*#define MAXGRAYNO			65536	*/
#define MAXGRAYNO			255
#define MAXRGBNO			(256-8)
#define	GRAY256(X)			(MAXGRAYNO*(maxcolnum-(X))/maxcolnum)
#define	COLOR256(X)			(X)
#define MAX256COL			256
#define POLYnodmax			1000
#define MAXNCHAR			128
#define DEFAULTCOLOR		128
#define COLORNUM(X)			((X)<1?2:(X))
#define MAXCOLMAPS			(MAXDEFCUMAPP+MAXSYSCOLMAP)
#define BASE_NPIXEL			MAX256COL

#ifdef GIFLIB
static char		*gifname;
static int		GWIDTH,GHEIGHT,IGXOFF,IGYOFF;
static int		GIFMODE=0,GIFANIME=0,GIFSETT=-1,GIFSETB=0,GIFSETI=0,GIFSTEP=1;
static int		GIFBWREVMODE=0,GIFGRAYMODE=0,GIFADELAY=GIFBASEDELAY,GIFCOLTABLE=0,GIFALOOP=GIFBASELOOP;
static int		GIFBASEW=640, GIFBASEH=480, PPMMODE=0,GIFAAMODE=0,GIFAARESOLVE=GIFBASERESOL;
static int		gif_w=0, gif_h=0, gifpage=0, gif_int=0;
static double	gif_n=1;
#else
extern char		gifname[];
extern int		GWIDTH,GHEIGHT,IGXOFF,IGYOFF;
extern int		GIFMODE,GIFANIME,GIFSETT,GIFSETB,GIFSETI,GIFSTEP,PPMMODE;
extern int		GIFBWREVMODE,GIFGRAYMODE,GIFADELAY,GIFCOLTABLE,GIFALOOP,GIFAAMODE,GIFAARESOLVE;
int				GIFBASEW=640, GIFBASEH=480;
int				gif_w=0, gif_h=0;
double			gif_n=1;
#endif

static int		gifbackrgb[3]={  255,  255,  255};
static int		gifchrw[5]={  9,  8,  7,  6,  5};
/*int			gifchrh[5]={ 12, 13, 11, 10,  7};*/
static int		gifchrh[5]={ 13, 12, 11, 10,  7};
static int		gifsetchr=0, gifaacol=-1, gifaaresol=-1, gifaacolmax=0;
static int		GIFAALMODE=-1, GIFAAPMODE=-1, GIFAACMODE=-1;

#ifdef GIFAALINE
static int		USEAALINE=1;
#else
static int		USEAALINE=0;
#endif

#ifdef PPM
static int		SWPPM=1;		/* if SWPPM=1,  create PPM image when the colortable overflows					*/
								/* if SWPPM=-1, replace the overflowed color by a nearest color (animation)		*/
#else
static int		SWPPM=0;		/* PPM mode is switch off														*/
#endif

/*
int			giflineset0[1] ={0};
int			giflineset1[2] ={7,0};
int			giflineset2[4] ={7,7,0,0};
int			giflineset3[8] ={7,7,7,7,0,0,0,0};
int			giflineset4[16] ={7,7,7,7,7,7,7,7,0,0,0,0,0,0,0,0};
int			giflineset5[14] ={7,7,0,0,7,7,7,7,7,7,7,7,0,0};
int			giflineset6[18] ={7,7,0,0,7,7,0,0,7,7,7,7,7,7,7,7,0,0};
int			giflineset7[1] ={7};
*/
/*int			*giflineset[8],*/
static int			giflinebody[]={ 0,7, 7,7,0,0, 7,7,0,0, 7,7,7,7, 7,7,7,7,0,0,0,0,0,0,0,0 },
					giflinesnum[]={ 1,2,4,8,16,14,18,1 };
static int			*giflineset[]={	&giflinebody[0],  &giflinebody[3],
									&giflinebody[0],  &giflinebody[3],
									&giflinebody[2],  &giflinebody[14],
									&giflinebody[10], &giflinebody[6],
									&giflinebody[2],  &giflinebody[1]};

static int			ani_open=0,mess_out=0;
static int			gifout_chk=0, gif_basecolset=-1, gif_hlscolset=-1;
static int			wxoff,wyoff,gifno=0,animeno=0,nc_base;
static char			str[256];
static int			lcolmode,vcolmode,ccolmode;
static int			tcolor=7,lcolor=0,mcolor=-1,rgbcol[MAX256COL][3];

static int			maxcolnum,gifanicolset=0,gifcolchk=0;

static FILE			*imout;
static char			outgiffilename[128];
static int			gifbasecolor[10],gifwcol,gifbcol,gifbackcol,gifback=0,gifccolb,gifycolb,gifccolw,gifycolw;
static int			*gpixels=NULL,gifcolorn=0,*gifrgbp=NULL,gifcolmax=-1,gifrgbinit=0;
static int			max_gpixels=-1;

static unsigned int	gpixpt[MAXCOLMAPS];			/* Global Pointer to the pixel array		  */
static int			gcmapnum[MAXCOLMAPS];		/* Assign to the Frames color table number	  */
static int			*gsphept[7];
static int			current_hlstable=0, defgifcolmap=0;

static void gif_clearall_color(void)
{
	int i;
	for(i=0;i<gifcolmax;i++) gdframes_color_deallocate(gpixels[i]);
	gifcolmax=0;		defgifcolmap=0;
}

static void set_color_table(int ncmax, int mode)
{
	int i,rr,gg,bb;

	if (mode) {
		for(i=0;i<ncmax;i++) {
			gdframes_color_deallocate(gifrgbp[i]);
		}
	}

	if (GIFGRAYMODE==0 && lcolmode!=1 && lcolmode!=2) {
		for(i=0;i<ncmax;i++) {
			rr = rgbcol[i][0]/256;
			gg = rgbcol[i][1]/256;
			bb = rgbcol[i][2]/256;
			gifrgbp[i]=gdframes_color_allocate(rr, gg, bb);
/*				printf("  %d r:%d g:%d b:%d->%d \n",i,rr,gg,bb,gifrgbp[i]);		*/
			
		}
	  }
	  else {
		if(GIFBWREVMODE) {
			for(i=0;i<ncmax;i++) {
				rr = GRAY256(i);
				gg = GRAY256(i);
				bb = GRAY256(i);
				gifrgbp[i]=gdframes_color_allocate(rr, gg, bb);
			}
		  }
		  else {
			for(i=0;i<ncmax;i++) {
				rr = 255-GRAY256(i);
				gg = 255-GRAY256(i);
				bb = 255-GRAY256(i);
				gifrgbp[i]=gdframes_color_allocate(rr, gg, bb);
			}
		}
	}
}

static void gif_setcol()
{
	int i;

/*	printf("gif current_hlstable = %d\n",current_hlstable);		*/
	for (i=0;i<defgifcolmap;i++) {
		if (gcmapnum[i]==current_hlstable) {
			gifrgbp=&gpixels[gpixpt[i]];
			gif_hlscolset=1;		/*	Setting complete	*/
			return;
		}
	}

/*	printf("gifrgbinit %d %d %d %d %d\n",gifrgbinit,gifcolmax,maxcolnum,gifcolorn,gifaacolmax);		*/
	if (gifrgbinit==0 && gifcolmax>0) gif_clearall_color();

	if (gifcolmax<0) {
		if (gpixels != NULL) free(gpixels);
		gifcolmax=0;
		max_gpixels=BASE_NPIXEL;
		gpixels = (int *)malloc(sizeof(int)*max_gpixels);
	  }
	  else if (GIFANIME && gifcolmax+maxcolnum+gifaacolmax >= MAXRGBNO) {
		if (maxcolnum < gifcolorn) {
			for(i=(gifcolorn-1);i>=0;i--) gdframes_color_deallocate(gifrgbp[i]);
			gifcolmax-=maxcolnum;
		  }
		  else gif_clearall_color();
	  }
	  else if (gifcolmax+maxcolnum>max_gpixels) {
		max_gpixels+=BASE_NPIXEL;
		gpixels = (int *)realloc(gpixels, sizeof(int)*max_gpixels);
		for (i=0;i<defgifcolmap;i++) {
			if (gcmapnum[i]>=MINSPHERECOL && gcmapnum[i]<MAXSPHERECOL) {
				gsphept[gcmapnum[i]-MINSPHERECOL]=&gpixels[gpixpt[i]];
			}
		}
/*		gdframes_colormap_size(max_gpixels+gifaacolmax);			*/
/*		printf("Increase GIF Colormap --> Switch to PPM\n");		*/
/*		PPMMODE=1;		*/
	}
#ifdef PPM
	if (gifcolmax+maxcolnum+gifaacolmax >= MAXRGBNO) {
		gdframes_colormap_size(max_gpixels+gifaacolmax);
		PPMMODE=1;
	}
#else
	  else if (gifcolmax+maxcolnum+gifaacolmax >= MAXRGBNO) {
		if (maxcolnum < gifcolorn) {
			for(i=(gifcolorn-1);i>=0;i--) gdframes_color_deallocate(gifrgbp[i]);
			gifcolmax-=maxcolnum;
		  }
		  else gif_clearall_color();
	  }
#endif
	gifrgbp=&gpixels[gifcolmax];
	gcmapnum[defgifcolmap]=current_hlstable;
	gpixpt[defgifcolmap++]=gifcolmax;
	if (current_hlstable>=MINSPHERECOL 
			&& current_hlstable<MAXSPHERECOL) gsphept[current_hlstable-MINSPHERECOL]=gifrgbp;
	set_color_table(maxcolnum,0);
	gif_hlscolset=1;		/*	Setting complete	*/
	gifcolorn = maxcolnum;
	gifcolmax += gifcolorn;
	gifrgbinit = 1;
}

static int setgifcolor()
{
	int sc;
/*	gif_hlscolset means
		= -1		No information in imgif
		=  0		Ready to store colormap in imgif ( not necessary already stored )
		=  1		Complete storage (unable to change)								
	int rr,gg,bb,gifcolor;	*/

	if(lcolmode==2) sc=7;
	  else if(mcolor < 0) {
		if (lcolor > 0) sc=gifbasecolor[lcolor-1];
		  else			sc=gifbasecolor[7];
	  }
	  else {
		if (gif_hlscolset==0) gif_setcol();		/*	If not set (0), setcolor 	*/
		sc=gifrgbp[mcolor];
	}
	return sc;
}

static void setaaflush(int sc,int mode)
{
	if (gifaacol>=0) {
		if (mode==0 || GIFAALMODE<0 || sc!=gifaacol) {
			gifaacolmax+=gdframes_aaspaceflush(gifaacol,gifbackcol,gifaaresol,SWPPM);
			gifaacol=-1;
#ifdef PPM
			if ((gifcolmax<0?0:gifcolmax)+gifaacolmax >= MAXRGBNO) PPMMODE=1;
#endif
		}
	}
}

static void setaagradflush(int xc, int yc, int dr, int cn1, int cn2, int *gifrgbp)
{
	int mode=0, sc=0;
/*	if (gifaacol>=0) {	*/
		if (mode==0 || GIFAALMODE<0 || sc!=gifaacol) {
			gifaacolmax+=gdframes_aagradspaceflush(xc,yc,dr,cn1,cn2,gifrgbp,gifaaresol,SWPPM);
			gifaacol=-1;
#ifdef PPM
			if ((gifcolmax<0?0:gifcolmax)+gifaacolmax >= MAXRGBNO) PPMMODE=1;
#endif
		}
/*	}	*/
}

static void setgiflinestyle()
{
	if (mcolor<0) {
		if(lcolor < 8) gdframes_set_style(giflineset[lcolor-1],giflinesnum[lcolor-1]);
			else	   gdframes_set_style(giflineset[7],giflinesnum[7]);
/*	  }
	  else {
	  	gray1=GRAY256(mcolor);
		if (gray1!=gray) {
			gray=gray1;
		}
*/
	}
}

/*  Real number version  0<=fh<=360   0<=fl,fs<=1	*/
#define weps 		1.0e-3
#define rgbmax 		65536
#define rgbmax1		(rgbmax-1)
#define rgbmax6 	(6*rgbmax)
static void hls2rgb(double dh,double dl,double ds,int *ir,int *ig,int *ib)
{
	unsigned int w1,w2,fl,fs,fh;
	int wh;

	if (dh < 0) dh+=360;
	fh=rgbmax*dh/60;		fl=rgbmax1*dl;		fs=rgbmax1*ds;
	if (fl>rgbmax1) fl=rgbmax1;
	if (fs>rgbmax1) fs=rgbmax1;

//	if ( fl < rgbmax/2 ) w2 = fl*(rgbmax+fs)/rgbmax;
//				else     w2 = rgbmax1-(rgbmax-fs)*(rgbmax-fl)/rgbmax;
	if ( fl < rgbmax/2 ) w2 = fl + fs*fl/rgbmax1;
				else     w2 = fl + fs*(rgbmax1-fl)/rgbmax1;
	w1 = 2*fl-w2;

	if ( fs < rgbmax/1024 ) *ir = *ig = *ib = fl;
	  else {
		wh = fh+2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ir = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
				( wh < 3*rgbmax? w2:
				( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));

		*ig = (  fh <   rgbmax? w1+(w2-w1)*fh/rgbmax:
				( fh < 3*rgbmax? w2:
				( fh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-fh)/rgbmax: w1 )));

		wh = fh-2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		*ib = (  wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
				( wh < 3*rgbmax? w2:
				( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));
	}
}

static void giffile_defaultrgb(void)
{
	int i,cnm,kkk,k,ii,jj,kk;
	double sh0,sh1,sl0,sl1,ss0,ss1,hue,lig,sat;

	if (gif_hlscolset>=0) return;
/*	if (gifcolchk && GIFCOLTABLE==0) return;		*/
	if (GIFANIME && gifanicolset>1) return;

	sh0=300;				sh1=0;
	sl0=sl1=0.5;			ss0=ss1=1;
	maxcolnum=DEFAULTCOLOR;

	if (maxcolnum>MAX256COL) cnm=MAX256COL;
		else cnm=maxcolnum;

	for (i=0,kkk=-1;i<maxcolnum;i++) {
		k = i*cnm/maxcolnum;
		if (k!=kkk) {
			hue = sh0+i*(sh1-sh0)/maxcolnum;
			lig = sl0+i*(sl1-sl0)/maxcolnum;
			sat = ss0+i*(ss1-ss0)/maxcolnum;
			hls2rgb(hue,lig,sat,&ii,&jj,&kk);
			kkk=k;
		}
		rgbcol[i][0]=ii;		rgbcol[i][1]=jj;		rgbcol[i][2]=kk;
	}
	gif_hlscolset=0;
}

void gifframeclear(void)
{
	gdframes_frame_clear(gifbackcol);
	gifrgbinit=0;
	/*	gif_hlscolset=0;	*/
}

void giffilestyle(int colormode,char *line_style,char *gray_style,int vectormode,int charmode)
{
	int i;

	if (gifanicolset>1) return;

	lcolmode=colormode;
	vcolmode=vectormode;
	ccolmode=charmode;

/*
	printf("giffilestyle %d\n",gif_basecolset);

	if (lcolmode==0) {
		for (i=0;i<9;i++) grayno[i]=0;
	  }
	 else {
		grayno[0]=0;
		for (i=0;i<8;i++) grayno[i+1]=(7-gray_style[i])*MAXGRAYNO/7;
	}
*/

/*		if (lcolmode==3 && setrgb==0) {	*/

	if(gif_n < 0.6) 		 gifsetchr=FONTTINY;
		else if(gif_n < 0.7) gifsetchr=FONTSMALL;
		else if(gif_n < 0.8) gifsetchr=FONTMEDIUMBOLD;
		else if(gif_n < 0.9) gifsetchr=FONTLARGE;
		else 				 gifsetchr=FONTGIANT;

	if (gif_basecolset<=0) {					/*	If not set, set default	*/
		if(lcolmode!=1 && lcolmode!=2) {
#ifdef GIFREVBW
			gifwcol=gdframes_color_allocate(0, 0, 0);
			gifbcol=gdframes_color_allocate(255, 255, 255);
#else
			gifbcol=gdframes_color_allocate(0, 0, 0);
			gifwcol=gdframes_color_allocate(255, 255, 255);
#endif
			gifccolb=gdframes_color_allocate(110, 110, 255);
			gifycolb=gdframes_color_allocate(255, 255,   0);
			gifccolw=gdframes_color_allocate(  0,   0, 255);
			gifycolw=gdframes_color_allocate(255, 127,   0);
			if(GIFBWREVMODE == 0) {
				gifbasecolor[0] = gifbcol;
				gifbasecolor[7] = gifwcol;
				gifbasecolor[1] = gifccolb;
				gifbasecolor[6] = gifycolb;
			  }
			  else {
				gifbasecolor[0] = gifwcol;
				gifbasecolor[7] = gifbcol;
				gifbasecolor[1] = gifccolw;
				gifbasecolor[6] = gifycolw;
			}
			gifbasecolor[2] = gdframes_color_allocate(255,   0,   0);
			gifbasecolor[3] = gdframes_color_allocate(255,   0, 255);
			gifbasecolor[4] = gdframes_color_allocate(  0, 255,   0);
			gifbasecolor[5] = gdframes_color_allocate(  0, 255, 255);
			gifbasecolor[8] = gifbcol;
			gifbasecolor[9] = gifwcol;
/*			printf("%d %d %d %d\n",gifback,gifbackrgb[0], gifbackrgb[1], gifbackrgb[2]);	*/
			if (gifback) {
				gifbackcol = gdframes_color_allocate(gifbackrgb[0], gifbackrgb[1], gifbackrgb[2]);
				gifbasecolor[0] = gifbackcol;
			  }
			  else	 gifbackcol = gifbasecolor[0];
		  }
		  else {
			/*
			printf("set gray \n");
			*/
			if(GIFBWREVMODE == 0){
				for(i=0;i<8;i++){
					gifbasecolor[i] = gdframes_color_allocate(32*i, 32*i, 32*i);
				}
				gifbasecolor[8] = gifbasecolor[0];
				gifbasecolor[9] = gifbasecolor[7];
			  }
			  else{
				for(i=0;i<8;i++){
					gifbasecolor[i] = gdframes_color_allocate(255-32*i, 255-32*i, 255-32*i);
				}
				gifbasecolor[8] = gifbasecolor[7];
				gifbasecolor[9] = gifbasecolor[0];
			}
			gifbackcol = gifbasecolor[0];
		}

		giffile_defaultrgb();
		gifanicolset=gifcolchk=0;
		gif_basecolset=1;

		if(GIFSETT != -1) gdframes_color_transparent(GIFSETT);
		if(GIFSETB) gdframes_color_transparent(gifbackcol);
		if(GIFSETI) gdframes_interlace(1);
	}

	gifframeclear();
}

void giffile_init(int mode)
{
	int i;
#ifdef GIFLIB
	frames_canvas *gcanvas=get_gcanvasp();
	int opt;

	if (gifanicolset>1) return;
#endif
	tcolor=7;		lcolor=0;		mcolor=-1;
	animeno=gifanicolset=ani_open=gifcolchk=0;

#ifdef GIFLIB
	gifname=gcanvas->fname;
	getcanvas_windowsize(&GWIDTH,&GHEIGHT,&IGXOFF,&IGYOFF);
	GIFSTEP   = gcanvas->windowmode[0];
	GIFALOOP  = gcanvas->agifopion[0];
	GIFADELAY = gcanvas->agifopion[2];
	GIFADELAY =((unsigned char)gcanvas->agifopion[1]) | (GIFADELAY<<8);

/*	printf("giffile_init  %d %d %d %d\n",GWIDTH,GHEIGHT,IGXOFF,IGYOFF);	*/

	opt=gcanvas->gifoption;
	GIFANIME     =opt&0x20;
	GIFCOLTABLE  =opt&0x10;
	GIFSETB      =opt&0x08;
	GIFSETI      =opt&0x04;
	GIFGRAYMODE  =(opt&0x02)>>1;
	GIFBWREVMODE =opt&0x01;

	gifpage=gcanvas->page+1;
	ani_open=(gcanvas->status)&GIFANIMSTATUS;
/*	if (GIFANIME && gifpage>1) ani_chk=1;	*/
	if (SWPPM) {
		if (GIFANIME) SWPPM=-1;
		  else		  SWPPM=1;
	}

	get_canvas_rgb(gifbackrgb);
	if (gifbackrgb[0] < 0)	gifback=0;
	  else {
		for (i=0;i<3;i++) gifbackrgb[i]>>=8;
		gifback=1;
	}

	gif_w = GWIDTH*gif_n;
	gif_h = GHEIGHT*gif_n;
	gif_basecolset=-1;
	if (gif_hlscolset > 0) gif_hlscolset=0;
	gifno=0;
#else
	if (mode==0) gifno=0;
	if(gif_w == 0)  gif_w = GWIDTH*gif_n;
	  else			gif_w *= gif_n;
	if(gif_h == 0)  gif_h = GHEIGHT*gif_n;
	  else			gif_h *= gif_n;
#endif

	wxoff=IGXOFF;	wyoff=IGYOFF;

	gdframes_image_create(gif_w, gif_h);
/*		gif_colset=-1;	*/						/*	Unset color	*/
	gifcolmax=-1;		defgifcolmap=0;
	gifaacol=-1;		gifaacolmax=0;

	
/*	printf("gif_h:%d gif_w:%d gif_n:%f \n",gif_h,gif_w,gif_n);	*/
	
#ifdef GIFLIB
	if (mode) gif_int=1;
	giffilestyle(3,NULL,NULL,1,1);
#endif
}
/*
void gif_aamode_init(void)
{
	gifaacol=-1;
	gifaacolmax=0;
}
*/
void giffilesetrgb(double *sh,double *sl,double *ss,int *div,int *mode,int *cdef,int *csys)
{
	int i,j,dpm,cnm,nc,mc,kkk,k,ii,jj,kk;
	double sh0[2],sl0[2],ss0[2],hue,lig,sat;

	/*
	printf(" giffilesetrgb %d %d %d %d\n",gifcolchk,GIFCOLTABLE,GIFANIME,gifanicolset);
	if (sh==NULL) printf("giffile name %s.gif \n",gifname);
		else	  printf("giffile name %s.gif %f \n",gifname,sh[0]);*/
	
/*	if (gifcolchk && GIFCOLTABLE==2) return;		???		*/

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(0);
	nc=get_current_hlstable(&sh,&mode);
	if (nc>0) {
		div=mode+1;
		if (*mode>0) {
			sl=sh+*mode+1;		ss=sl+*mode+1;
		}
		current_hlstable=nc;
	  }
	  else if (nc<0) {
		current_hlstable=-nc;
	  }
	  else current_hlstable=0;
#else
	current_hlstable=get_current_tphlstable();
	if (current_hlstable>-2 && *csys>0) {
		current_hlstable=*csys+MAXDEFCUMAPP;
	}
#endif
	if (GIFANIME && gifanicolset>1) {
		gif_hlscolset=0;
		return;
	}

	if (*mode<=0 || *div<=0) {
		dpm=1;
		if (*mode<0 || *div<=0) i=*cdef;
		  else					i=*div;
		sh0[0]=300;       sh0[1]=0;
		sl0[0]=sl0[1]=0.5;
		ss0[0]=ss0[1]=1;
		sh=sh0;		ss=ss0;		sl=sl0;
		maxcolnum=i;	div=&maxcolnum;
	  }
	  else {
		dpm=*mode;
		if (dpm==1) maxcolnum=*div;
		  else {
/*	color setting point		*/
			for (i=maxcolnum=0;i<dpm;i++) {
				mc=div[i]-1;
				if (mc<0) mc=1;
				maxcolnum+=mc;
			}
			maxcolnum++;
		}
	}

	if (maxcolnum>MAX256COL) cnm=MAX256COL;
		else cnm=maxcolnum;

	mc=div[0]-1;
	if (mc<1) mc=1;
	for (i=j=nc=0,kkk=-1;i<maxcolnum;i++,j++) {
		k = i*cnm/maxcolnum;
		while (j>=COLORNUM(div[nc])) {
			nc++;	j=1;
			mc=div[nc]-1;
			if (mc<0) mc=1;
		}
		if (k!=kkk) {
			hue = sh[nc]+j*(sh[nc+1]-sh[nc])/mc;
			lig = sl[nc]+j*(sl[nc+1]-sl[nc])/mc;
			sat = ss[nc]+j*(ss[nc+1]-ss[nc])/mc;
			hls2rgb(hue,lig,sat,&ii,&jj,&kk);
			kkk=k;
		}
		rgbcol[i][0]=ii;		rgbcol[i][1]=jj;		rgbcol[i][2]=kk;
	}

	gif_hlscolset=0;		/*	Ready to store colorset (changable)		*/
	gifcolchk=1;
	if (current_hlstable>=MINSPHERECOL && current_hlstable<MAXSPHERECOL) gif_setcol();

	if (GIFANIME && GIFCOLTABLE==0) gifanicolset=1;
}

void gifcolormode(int bw)
{
	int bsw=0;
/*	if(lcolmode==1 || lcolmode==2) return;	*/
	if(lcolmode==2) return;

	bw%=10;
/*	printf("cc %d %d\n",bw,GIFBWREVMODE);		*/
	if (bw==1 && GIFBWREVMODE==0) {
		gifbasecolor[0]=gifwcol;
		gifbasecolor[7]=gifbcol;
		gifbasecolor[1]=gifccolw;
		gifbasecolor[6]=gifycolw;
		GIFBWREVMODE=1;		bsw=1;
	  }
	  else if (bw==0 && GIFBWREVMODE) {
		gifbasecolor[0]=gifbcol;
		gifbasecolor[7]=gifwcol;
		gifbasecolor[1]=gifccolb;
		gifbasecolor[6]=gifycolb;
		GIFBWREVMODE=0;		bsw=1;
	}
	gifbackcol = gifbasecolor[0];

	if (bsw==1 && GIFGRAYMODE==1) set_color_table(maxcolnum,1);
/*	if (GIFGRAYMODE>0) lcolmode=2;	*/

}

void gifgraycolormode(int gray)
{
/*	printf("kk %d %d\n",gray,GIFGRAYMODE);		*/
	if (gray==1 && GIFGRAYMODE==0) {
		GIFGRAYMODE=1;
		set_color_table(maxcolnum,1);
	  }
	  else if (gray==0 && GIFGRAYMODE) {
		GIFGRAYMODE=0;
		set_color_table(maxcolnum,1);
	}
/*	if (GIFGRAYMODE>0) lcolmode=2;	*/

}

void gifdelaytiming(int delay)
{
	GIFADELAY=delay;
}

void gifloopcount(int loop)
{
	GIFALOOP=loop;
}

void gifinterlacemode(int mode)
{
	GIFSETI=mode;
	if (mode) gdframes_interlace(1);
		else  gdframes_interlace(0);
}

void giftransparentmode(int mode)
{
	GIFSETB=mode;
	if (mode) gdframes_color_transparent(gifbackcol);
		else  gdframes_color_transparent(-1);
}

void gif_setaamode(int aamode,int aares)
{
	GIFAAMODE=aamode;
	GIFAARESOLVE=aares;
/*	giffilesetantialias(aamode,aares);		*/
	USEAALINE=aamode;
	if (aamode) {
		gifaaresol=aares;
		GIFAALMODE=1;
	  }
	  else GIFAALMODE=-1;
}

static void giffile_store(int page)
{
	setaaflush(0,0);

#ifdef PPM
	if (PPMMODE) {
		if (page>0 && GIFMODE<3) {
			sprintf(outgiffilename,"%s%.4d.ppm",gifname,page);
			imout = fopen(outgiffilename, "wb");
			gdframes_image_ppm(imout);
			fclose(imout);
			PPMMODE=0;
		  }
		  else {
			sprintf(outgiffilename,"%s_%.4d.ppm",gifname,++gifno);
			imout = fopen(outgiffilename, "wb");
			gdframes_image_ppm(imout);
			fclose(imout);
/*			gifaacol=-1;		gifaacolmax=0;		*/
		}
/*		PPMMODE=0;		*/
	  }
	  else if (GIFANIME) {
#else
	if (GIFANIME) {
#endif
		if (animeno==0) {
			sprintf(outgiffilename,"%s.gif",gifname);
		  }
		  else {
			sprintf(outgiffilename,"%s_%d.gif",gifname,animeno);
		}
		if(ani_open==0) {
			imout=fopen(outgiffilename ,"wb");
			ani_open=1;
#ifdef GIFLIB
			set_canvas_status(GIFANIMSTATUS,STATUSON);
#endif
		  }
		  else {
			imout=fopen(outgiffilename ,"r+b");
		}

		gdframes_animation(imout,GIFALOOP,GIFADELAY,GIFCOLTABLE,GIFSTEP);

		if (GIFCOLTABLE==0 && gifanicolset==1) {
			gdframes_colset(imout);
			gifanicolset++;
		}
		fclose(imout);
		if (GIFMODE==1 && mess_out > 0 && (page%mess_out)==0) {
			fprintf(stderr,"GIF Image %06d has been processed.\n",page);
		}
	  }
	  else if (page>0 && GIFMODE<3) {
		sprintf(outgiffilename,"%s%.4d.gif",gifname,page);
		imout = fopen(outgiffilename, "wb");
		gdframes_image_gif(imout);
		fclose(imout);
	  }
	  else {
		sprintf(outgiffilename,"%s_%.4d.gif",gifname,++gifno);
		imout = fopen(outgiffilename, "wb");
		gdframes_image_gif(imout);
		fclose(imout);
	}
#ifdef GIFLIB
	gif_int=0;
#endif
}

void giffileend(int page)
{
	if(page>=0 && gifout_chk) giffile_store(page);
	if (page<0) {
		gifout_chk=0;		gif_basecolset=-1;		gif_hlscolset=-1;
	}
}

void giffilenext(int page)
{
	if(gifout_chk) giffile_store(page);
	gifframeclear();
	gifout_chk=0;
	gifcolchk=0;
}

#ifdef GIFLIB
void gifoutputend(void)
{
	if(gifout_chk) giffile_store(gifpage++);
	gdframes_image_destroy();

	GIFMODE=0;		GIFANIME=0;		GIFSETT=-1;	GIFSETB=0;		GIFSETI=0;		GIFSTEP=1;
	GIFBWREVMODE=0;	GIFADELAY=GIFBASEDELAY;		GIFCOLTABLE=0;	GIFALOOP=GIFBASELOOP;
	gif_w=0;			gif_h=0;				gifpage=0;				gif_int=0;
	gifout_chk=0;		gif_basecolset=-1;		gif_hlscolset=-1;
	gifno=0;			animeno=0;
	gifanicolset=0;		gifcolchk=0;			GIFGRAYMODE=0;
	gifcolorn=0;		gifback=0;
	PPMMODE=0;
}

void gifoutputnext(void)
{
	if(gifout_chk) giffile_store(gifpage++);
	gifout_chk=0;
	gifcolchk=0;
/*	tcolor=7;		lcolor=0;		mcolor=-1;	*/
/*	gif_colset=0;	*/						/*	Unset color	*/
}
#endif

void giffilecolor(int *n,int *pal)
{

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

/*		n=0... both,  n=1... text,  n=2... lines,  n=256... 256 color	*/
	if (*n!=256) {
/*
		if ((*n)!=2 && (*pal)!=tcolor) {
			tcolor=*pal;
		}
		if ((*n)!=1) {
*/
			if (*pal>=0) {
			    lcolor=(*pal)+1;
				if (lcolor>10) lcolor=8;
			  }
		      else {
			    lcolor=0;
			}
/*
		}
*/
		mcolor=-1;
	  }
	 else {
#ifndef GIFLIB
/*		if (gif_colset==0) gif_setcol();					If not set, setcolor	*/
#endif
		mcolor=*pal;
		if (mcolor>=maxcolnum) mcolor=maxcolnum-1;
	}
}

void giffiledot(float *x,float *y)
{
	int sc,gx1,gy1;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	gx1=(*x-wxoff)*gif_n+0.5;
	gy1=(*y-wyoff)*gif_n+0.5;

	sc=setgifcolor();
/*	setaaflush(0,0);	*/
	setaaflush(sc,1);

	gdframes_set_pixel(gx1,gy1,sc);
	gifout_chk = 1;

}

void giffileline(float *x1,float *y1,float *x2,float *y2,int *dc)
{
	static float 	xx=-99999.9,yy=-99999.9;
	int n,sc,gx1,gx2,gy1,gy2;
	float fx1,fx2,fy1,fy2;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	sc=setgifcolor();
	setaaflush(sc,1);

	if (lcolmode==2 && *dc<2) setgiflinestyle();
	  else {
		giflineset[7][0]=sc;
		gdframes_set_style(giflineset[7], 1);
	}

	if (*dc==0) {
		xx=*x2;		yy=*y2;
	  }
	  else {
		xx=-99999.9;	yy=-99999.9;
	}

	fx1=(*x1-wxoff)*gif_n;
	fx2=(*x2-wxoff)*gif_n;
	fy1=(*y1-wyoff)*gif_n;
	fy2=(*y2-wyoff)*gif_n;
	gx1=fx1+0.5;	gx2=fx2+0.5;
	gy1=fy1+0.5;	gy2=fy2+0.5;

	if(*dc == 1) {
		gdframes_rectangle(gx1,gy1,gx2,gy2,sc);
	  }
	  else if (*dc == 2) {
		if (gx1>gx2) { n=gx1;  gx1=gx2;  gx2=n;  }
		if (gy1>gy2) { n=gy1;  gy1=gy2;  gy2=n;  }
		gdframes_fill_rectangle(gx1,gy1,gx2,gy2,sc);
	  }
	  else if (GIFAALMODE>=0 && GIFAACMODE<2) {
		n=gdframes_aaline(fx1,fy1,fx2,fy2,GIFAALMODE);
		if (n==0) return;
		gifaacol=sc;
	  }
	  else {
		/*
		gdImageLine(imgif,gx1,gy1,gx2,gy2,sc);
		*/
		gdframes_line(gx1,gy1,gx2,gy2);
	}

	gifout_chk = 1;

}

void giffileaaspaceflush(int *mode, int *poly, int *chr)
{
/*	printf("flush %d %d %d %d\n",*mode, *poly, *chr,gifaacol);		*/
	if (USEAALINE>0 && *mode>=0) {
		GIFAALMODE=*mode;		GIFAAPMODE=*poly;		GIFAACMODE=*chr;
	  }
	  else {
		if (gifaacol>=0) {
			gifaacolmax+=gdframes_aaspaceflush(gifaacol,gifbackcol,gifaaresol,SWPPM);
			gifaacol=-1;
#ifdef PPM
			if ((gifcolmax<0?0:gifcolmax)+gifaacolmax >= MAXRGBNO) PPMMODE=1;
#endif
		}
		GIFAALMODE=-1;
	}
}

void giffilesetantialias(int *mode, int *reduc)
{
	USEAALINE=*mode;
	if (*mode>0) {
		gifaaresol=*reduc;
		if (gifaaresol>=8) gifaaresol=-1;
	}
}

void giffilegradrectangle(float *x1,float *y1,float *x2,float *y2,float *cnc)
{
	int gx1,gy1,gx2,gy2;
	int cn,icn[4],ff,i;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	setaaflush(0,0);

	if (gif_hlscolset==0) gif_setcol();		/*	If not set (0), setcolor 	*/

	gx1=(*x1-wxoff)*gif_n+0.5;
	gx2=(*x2-wxoff)*gif_n+0.5;
	gy1=(*y1-wyoff)*gif_n+0.5;
	gy2=(*y2-wyoff)*gif_n+0.5;

	for (i=0;i<4;i++) icn[i]=cnc[i]*65536;
	if (gx1>gx2) {
		ff=gx2;		gx2=gx1;		gx1=ff;
		ff=icn[0];	icn[0]=icn[2];	icn[2]=ff;
		ff=icn[1];	icn[1]=icn[3];	icn[3]=ff;
	}
	if (gy1>gy2) {
		ff=gy2;		gy2=gy1;		gy1=ff;
		ff=icn[0];	icn[0]=icn[1];	icn[1]=ff;
		ff=icn[2];	icn[2]=icn[3];	icn[3]=ff;
	}

	gdframes_gradrectangle(gx1,gy1,gx2,gy2,icn,gifrgbp,maxcolnum);

	gifout_chk = 1;

}

void giffilepolygon(float *px,float *py,int *nn,int *md)
{
	int i,n,sc,gx1,gy1,gx2,gy2;
	float xx[POLYnodmax],yy[POLYnodmax];
	float fx1,fx2,fy1,fy2;
/*	gdPoint xy[POLYnodmax];	*/

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	sc=setgifcolor();
	setaaflush(sc,1);
	if (*md<=1 && lcolmode==2) setgiflinestyle();

	if (lcolmode==2) setgiflinestyle();
	  else {
		giflineset[7][0]=sc;
		gdframes_set_style(giflineset[7], 1);
	}

	for(i=0;i<*nn;i++) {
		xx[i]=(px[i]-wxoff)*gif_n;
		yy[i]=(py[i]-wyoff)*gif_n;

	}
	if (GIFAALMODE>=0 && (*md<2 || GIFAAPMODE>0)) {
		n=0;
		if (*md < 2) {
			fx1 = xx[0]+0.5;
			fy1 = yy[0]+0.5;
			for(i=1;i<*nn;i++){
				fx2 = xx[i]+0.5;
				fy2 = yy[i]+0.5;
				n+=gdframes_aaline(fx1,fy1,fx2,fy2,GIFAALMODE);
				fx1 = fx2;
				fy1 = fy2;
			}
			if (*md == 1) {
				fx2 = xx[0]+0.5;
				fy2 = yy[0]+0.5;
				n+=gdframes_aaline(fx1,fy1,fx2,fy2,GIFAALMODE);
			}
		  }
		  else {
			n=gdframes_aafillpolygon(xx, yy, *nn);
		}
		if (n==0) return;
		gifaacol=sc;
	  }
	  else {
		if (*md < 2) {
			gx1 = xx[0]+0.5;
			gy1 = yy[0]+0.5;
			for(i=1;i<*nn;i++){
				gx2 = xx[i]+0.5;
				gy2 = yy[i]+0.5;
				gdframes_line(gx1,gy1,gx2,gy2);
				gx1 = gx2;
				gy1 = gy2;
			}
			if (*md == 1) {
				gx2 = xx[0]+0.5;
				gy2 = yy[0]+0.5;
				gdframes_line(gx1,gy1,gx2,gy2);
			}
		  }
		  else {
			gdframes_fillf_polygon(xx, yy, *nn, sc);
/*			gdframes_fill_polygon(xy, *nn, sc);		*/
		}
	}

	gifout_chk = 1;

}

void giffilearrow(float *x1,float *y1,float *x2,float *y2
					,float *vx,float *vy,float *cs,float *sn,int *icv)
{
	int sc,gx1,gy1,gx2,gy2,n;
	float xx,yy;
	float px[3],py[3];
	float fx1,fx2,fy1,fy2;
	gdPoint gxy[3];

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	sc=setgifcolor();
	setaaflush(sc,1);
	if (lcolmode==2) setgiflinestyle();
	  else {
		giflineset[7][0]=sc;
		gdframes_set_style(giflineset[7], 1);
	}

	if (GIFAALMODE>=0) {
		fx1=(*x1-wxoff)*gif_n;
		fy1=(*y1-wyoff)*gif_n;
		fx2=(*x2-wxoff)*gif_n;
		fy2=(*y2-wyoff)*gif_n;
		px[0]=fx2;
		py[0]=fy2;

		n=gdframes_aaline(fx1,fy1,fx2,fy2,GIFAALMODE);

		if (*vx!=0 && *icv==0) {
			xx=-(*vx)*(*cs)+(*vy)*(*sn);
			yy= (*vy)*(*cs)+(*vx)*(*sn);

			px[1]=fx2+xx*gif_n;
			py[1]=fy2-yy*gif_n;

			xx=-2*(*vy)*(*sn);
			yy=-2*(*vy)*(*cs);
			px[2]=px[1]+xx*gif_n;
			py[2]=py[1]-yy*gif_n;

			n+=gdframes_aafillpolygon(px, py, 3);
		}
		if (n==0) return;
		gifaacol=sc;
	  }
	  else {
		gx1=(*x1-wxoff)*gif_n+0.5;
		gy1=(*y1-wyoff)*gif_n+0.5;
		gx2=(*x2-wxoff)*gif_n+0.5;
		gy2=(*y2-wyoff)*gif_n+0.5;
		gxy[0].x=gx2;
		gxy[0].y=gy2;

		gdframes_line(gx1,gy1,gx2,gy2);

		if (*vx!=0 && *icv==0) {
			xx=-(*vx)*(*cs)+(*vy)*(*sn);
			yy= (*vy)*(*cs)+(*vx)*(*sn);

			gxy[1].x=gx2+xx*gif_n+0.5;
			gxy[1].y=gy2-yy*gif_n+0.5;

			xx=-2*(*vy)*(*sn);
			yy=-2*(*vy)*(*cs);
			gxy[2].x=gxy[1].x+xx*gif_n+0.5;
			gxy[2].y=gxy[1].y-yy*gif_n+0.5;

			gdframes_fill_polygon(gxy, 3, sc);
		}
	}

	gifout_chk = 1;

}

void giffilecirc(float *x,float *y,float *dx,float *dy,int *md)
{
	int sc,gx1,gy1,gdx,gdy,n;
	float rx=*dx/2,ry=*dy/2;
	float fx1,fy1,fdx,fdy;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	sc=setgifcolor();
	setaaflush(sc,1);
	if (*md==0 && lcolmode==2) setgiflinestyle();

	if (GIFAALMODE>=0) {
		fx1=(*x-wxoff)*gif_n;
		fy1=(*y-wyoff)*gif_n;
		fdx=(*dx)*gif_n;
		fdy=(*dy)*gif_n;
		n=gdframes_aacircle(fx1,fy1,fdx,fdy,*md);
		if (n==0) return;
		gifaacol=sc;
	  }
	  else {
		gx1 = (*x-wxoff)*gif_n+0.5;
		gy1 = (*y-wyoff)*gif_n+0.5;
		gdx = (*dx)*gif_n+0.5;
		gdy = (*dy)*gif_n+0.5;
		gdframes_circle(gx1,gy1,gdx,gdy,sc,*md);
	}

	gifout_chk = 1;
}

void giffilegradcirc(float *x,float *y,float *dd,int *md)
{
	int gx1,gy1,gdx,cn1,cn2,n;
	float fx1,fy1,fdd;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	setaaflush(0,0);

	if (gif_hlscolset==0) gif_setcol();		/*	If not set (0), setcolor 	*/

	if (*md<=0) {
		cn1=maxcolnum*0.05;			cn2=maxcolnum*0.95;
	  }
	  else {
		gifrgbp=gsphept[(*md)-1];
		cn1=0;						cn2=SPHERECOLNUM-1;
	}

	if (GIFAALMODE>=0) {
		fx1=(*x-wxoff)*gif_n;
		fy1=(*y-wyoff)*gif_n;
		fdd=(*dd)*gif_n;
		n=gdframes_aagradcircle(fx1,fy1,fdd);
		if (n==0) return;
		setaagradflush((int)(fx1+0.5),(int)(fy1+0.5),(int)(fdd+0.5),cn1,cn2,gifrgbp);
	  }
	  else {
		gx1 = (*x-wxoff)*gif_n+0.5;
		gy1 = (*y-wyoff)*gif_n+0.5;
		gdx = (*dd)*gif_n+0.5;
/*		gdy = (*dy)*gif_n+0.5;	*/
		gdframes_gradcircle(gx1,gy1,gdx,cn1,cn2,gifrgbp);
	}
	gifout_chk = 1;
}

/*
#define AACWIDTH		8
#define AACHEIGHT		14
*/
#define FONTOFFSET			3
static int AACWIDTH, AACHEIGHT;

#ifdef CompaqVisual
void giffilechr(float *x,float *y,char *chr,int length,int *nc
							,int *icx,int *icy,int *icdx,int *idx,int *idy)	/* Compaq demands character length	*/
#else
void giffilechr(float *x,float *y,char *chr,int *nc
							,int *icx,int *icy,int *icdx,int *idx,int *idy)
#endif
/*
 *   icx       : 1/1024 word width
 *   icdx, icy : 1/1024 font width and height
 *   idx,  idy : 1/1024 font adjustment in width or height
 *   Base Point is Top Left
 */
{
	static int aachk=-1;
	int i,n,nl,sc,gx1,gy1,ddx,ddy,cdx,ibx;
	float fx1,fy1;

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

/*	if (ccolmode && lcolmode) setgifcolor();	*/

	n=*nc;		nl=0;
	for (i=0;i<n;i++) str[nl++]=chr[i];
	str[nl]='\0';							/*	nl--;		why?	*/

/*	setaaflush(0,0);	*/
	sc=setgifcolor();
	setaaflush(sc,1);

again:
	if (gifsetchr==0 && (aachk && GIFAALMODE>=0 && GIFAACMODE>0)) {
		if (aachk<0) {
			n=gdframes_aastring(fx1, fy1, str, 1);
			if (n<0) {
				aachk=0;	goto again;
			}
			aachk=1;	AACHEIGHT=n&0xffff;		AACWIDTH=n>>16;
		}
/*		fx1=(*x-wxoff)*gif_n+gifchrw[gifsetchr]*(nl*((*icx)-1)+(*idx))/2.0;
		fy1=(*y-wyoff)*gif_n+gifchrh[gifsetchr]*((*icy)-1)/2.0;
		fx1=(*x-wxoff)*gif_n;
		fy1=(*y-wyoff)*gif_n;			*/
		ddx=gdframes_aastring(fx1, fy1, str, 2);
		ddy=(*icy)>>9;
		if (ddy&1) ddy=-128;
			else ddy=0;
		cdx=ddx*(*icdx)/(nl*8);
		fx1=(*x-wxoff)*gif_n+((((*icx)*ddx/8)+cdx+AACHEIGHT*(*idx))>>10);
		fy1=(*y-wyoff)*gif_n+((AACHEIGHT*((*icy)+ddy)+AACWIDTH*(*idy))>>10)-AACHEIGHT;
		n=gdframes_aastring(fx1, fy1, str, 0);
		if (n==0) return;
		gifaacol=sc;
	  }
	  else {
		ibx=(*icx)*nl+(*icdx);
		gx1=(*x-wxoff)*gif_n+((gifchrw[gifsetchr]*ibx+gifchrh[gifsetchr]*(*idx))>>10)+0.5;
		gy1=(*y-wyoff)*gif_n+((gifchrh[gifsetchr]*(*icy)+gifchrw[gifsetchr]*(*idy))>>10)
									-gifchrh[gifsetchr]+0.5;
		gdframes_string(gifsetchr, gx1, gy1, str, sc);
	}

	gifout_chk = 1;

}

#ifdef CompaqVisual
void giffilechr10(float *x,float *y,char *chr,int length,int *nc,char *chr10,int length10,int *nc10
										,int *ix,int *iy,int *idx)	/* Compaq demands character length	*/
#else
void giffilechr10(float *x,float *y,char *chr,int *nc,char *chr10,int *nc10
										,int *ix,int *iy,int *idx)
#endif
{
	int i,n,n10,sc,nchr10;
	int gx1,gy1,gx10,gy10,gxex,gyex;
	char strexp[30];

#ifdef GIFLIB
	if (gif_int<=0) giffile_init(1);
#endif

	setaaflush(0,0);

/*	if (ccolmode && lcolmode) setgifcolor();	*/

	n=*nc;		n10=*nc10;
	if (n>0) {
		for (i=0;i<n;i++) str[i]=chr[i];
		str[n++]=' ';		str[n]='\0';
	}
	for (i=0;i<n10;i++) strexp[i]=chr10[i];
	strexp[n10]='\0';

	nchr10=gifsetchr-1;
	if (nchr10<0) nchr10=0;
	gx1=(*x-wxoff)*gif_n+(gifchrw[gifsetchr]*((n+2)*((*ix)-1)+(*idx))
								+gifchrw[nchr10]*n10*((*ix)-1))/2.0+0.5;
	gy1=(*y-wyoff)*gif_n+gifchrh[gifsetchr]*((*iy)-1)/2.0+0.5;
	gx10=gx1+gifchrw[gifsetchr]*n;
	gy10=gy1;
	gxex=gx10+gifchrw[gifsetchr]*2;
	gyex=gy10-gifchrh[gifsetchr]*0.7;

	sc=setgifcolor();
	if (n>0) gdframes_string(gifsetchr, gx1, gy1, str, sc);
	gdframes_string(gifsetchr, gx10, gy10, "10", sc);
	if (gifsetchr < FONTTINY) {
		gdframes_string(gifsetchr+1, gxex, gyex, strexp, sc);
	  }
	  else {
		gdframes_string(gifsetchr, gxex, gyex, strexp, sc);
	}

	gifout_chk = 1;

}

#else

void giffileoption(int *amode){}
void giffilecolor(int *n,int *pal){}
void giffiledot(float *x,float *y){}
void giffileline(float *x1,float *y1,float *x2,float *y2,int *dc){}
void giffileaaspaceflush(int *mode, int *poly, int *chr){}
void giffilesetantialias(int *mode){}
void giffilegradfillbox(float *x1,float *y1,float *x2,float *y2,int *cnc){}
void giffilepolygon(float *px,float *py,int *nn,int *md){}
void giffilecirc(float *x,float *y,float *dx,float *dy,int *md){}
void giffilegradcirc(float *x,float *y,float *dd,int *md){}
void giffilearrow(float *x1,float *y1,float *x2,float *y2
					,float *vx,float *vy,float *cs,float *sn,int *icv){}
void giffilechr(float *x,float *y,char *chr,int *nc
							,int *icx,int *icy,int *idx,int *idy){}
void giffilechr10(float *x,float *y,char *chr,int *nc,char *chr10,int *nc10
								,int *ix,int *iy,int *idx){}
void giffilesetrgb(double *sh,double *sl,double *ss,int *div,int *mode,int *cdef,int *csys){}

void gifoutputend(void){}
void gifoutputnext(void){}
#endif
