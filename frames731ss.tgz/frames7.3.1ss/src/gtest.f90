!*************************************
!        F  r  a  m  e  s  V.7       *
!   Tests of 2D Graphic Subroutines  *
!      Programmed by T. Taguchi      *
!*************************************
program frames_2dtest
   implicit none

   call fr_ginit
!      call fr_gwsize(600,300,0,0)
!      call fr_gfile('gtest',0)
   call fr_opencanvas(1,'gtest',111)

   call fr_gnotes('#2d graphic test')
   call fr_gnotes('xmin=10   xmax=100')

   call basic
     call next
   call sincos
     call next
   call drawsin
     call next
   call lissajous
     call next
   call logsin
     call next
   call polygn
     call next
   call histgram
     call next
   call bruss
     call next
   call field
     call next
   call tcont
     call next
   call tcont2
     call next
   call tconsq
     call next
   call tcontr
   call fr_gend

end program frames_2dtest

subroutine next
   call fr_gpause
   call fr_gclear
end subroutine next

!****************************
!   Character Output Test   *
!****************************
subroutine basic
   implicit none
   integer i

   call fr_fpline(200.0,100.0,400.0,100.0,7,0)
   call fr_fpline(200.0,80.0,200.0,120.0,7,0)
   call fr_fpchars(200.0,100.0,'100',4,0,0,0,0)
   call fr_fpline(240.0,80.0,240.0,120.0,7,0)
   call fr_fpchars(240.0,100.0,'100',6,1,1,0,0)
   call fr_fpline(280.0,80.0,280.0,120.0,7,0)
   call fr_fpchars(280.0,100.0,'100',3,1,-1,0,0)
   call fr_fpline(360.0,80.0,360.0,120.0,7,0)
   call fr_fpchars(360.0,100.0,'100',1,-1,0,0,0)

   call fr_fpline(200.0,200.0,400.0,200.0,7,0)
   call fr_fpline(200.0,180.0,200.0,220.0,7,0)
   call fr_fpchars(200.0,200.0,'100',1,-1,0,1,0)
   call fr_fpline(240.0,180.0,240.0,220.0,7,0)
   call fr_fpchars(240.0,200.0,'100',2,1,0,-1,0)
   call fr_fpline(320.0,180.0,320.0,220.0,7,0)
   call fr_fpchars(320.0,200.0,'100',3,-1,0,1,0)
   call fr_fpline(360.0,180.0,360.0,220.0,7,0)
   call fr_fpchars(360.0,200.0,'100',4,1,0,-1,0)

   call fr_fpline(200.0,240.0,400.0,240.0,7,0)
   call fr_fpline(200.0,220.0,200.0,260.0,7,0)
   call fr_fpchars(350.0,240.0,'   |',1,1,-1,0,0)
   call fr_fpchars(1.0,-2.0,'abcdefghijklmnopqr',-5,1,1,0,1)
   do i = 1, 12
     call fr_fpchars(0.0,1.0,'abcdefghijklmnopqr',-10*i-5,1,1,0,1)
   enddo

   call fr_fpchars(0.0,-2.0,'abcdefghijklmnopqr',1,-1,1,0,1)
   do i = 1, 6
     call fr_fpchars(0.0,-1.0,'abcdefghijklmnopqr',i+1,-1,1,0,1)
   enddo

   call fr_fpchars(-1.0,0.0,'abcdefghijklmnopqr',1,-1,1,0,1)
   do i = 1, 3
     call fr_fpchars(0.0,2.0,'abcdefghijklmnopqr',i+1,-1,1,0,1)
   enddo

end subroutine basic

!**********************
!   2D Graphic Test   *
!**********************
subroutine sincos
   implicit none
   integer, parameter :: nmax=5
   real, parameter :: pi=3.141592653589793
   real  x(2),y(0:nmax),y1(0:nmax),xmin,xmax,ymax,a,b,dx,yy,dy
   integer i,j,nn
   character text*10

   xmin = 0.0
   xmax = 5.0
   ymax = 1.2

   call fr_xyname('x-axis','y-datas')
   call fr_frame2d(xmin,xmax,-ymax,ymax,10)

   dx = (xmax-xmin)/nmax
   do i = 0, nmax
      y(i) = 0.1*sin(10*(dx*i+xmin))
   enddo

   nn = 7
   dy = 2.0/nn
   x(1) = xmin
   x(2) = xmax
   a    = 20
   b    = a*sin(pi/10)/cos(pi/5)
   do i = 1, nn
      yy = dy*i-1.2
!      call fr_setcircle(20*dy*i)
      call fr_setmark(a*dy*i,b*dy*i,10)
      do j = 0, nmax
         y1(j) = yy + y(j)
      enddo
      write(text,'(f5.2)') dy*i
      call fr_graph2d(x,y1,nmax+1,-i*18,101)
      call fr_graph2d(x,y1,nmax+1,-i*18,103)
      call fr_2dmove(1.0,y1(nmax),1)
      call fr_fpchars(15.0,0.0,text,-i*18,1,0,0,30)
   enddo

end subroutine sincos

!**********************
!     2D Draw Test    *
!**********************
subroutine drawsin
   implicit none
   real  xmin,xmax,ymax,x,dx
   integer i,n

   n    = 100
   xmin = 0.0
   xmax = 1.e-6
   ymax = 1.5e-7

   call fr_xyname('x-axis','y-datas')
   call fr_frame2d(xmin,xmax,-ymax,ymax,10)
   dx   = xmax/n

   call fr_draw2d(0.0,0.0,4,0)
   do i = 1, n
      x = dx*i
      call fr_draw2d(x,1e-6*exp(-0.7e7*x)*sin(1e8*x),4,1)
   enddo

end subroutine drawsin

!************************
!     2D Spline Test    *
!************************
subroutine lissajous
   implicit none
   integer, parameter :: nmax=12
   real, parameter :: pi=3.141592653589793, pi2=pi*2
   real  x(0:nmax*20),y(0:nmax*20)
   real  xmax,ymax,r,th,dth
   real  xs(2,0:nmax),ys(2,0:nmax)
   integer i,nx,ny

   xmax = 1.0
   ymax = 1.0
   nx   = 2
   ny   = 3
   r    = 1.03

   call fr_aspect2d(1.0,1.0,0)
   call fr_xyname('x','y')
   call fr_frame2d(-xmax,xmax,-ymax,ymax,10)

   dth   = pi2/nmax
   do i = 0, nmax
      th = dth*i
      x(i) = sin(nx*th)
      y(i) = sin(ny*th)
   enddo      

   call fr_graph2d(x,y,nmax+1,2,1)

   do i = 0, nmax
      th = dth*i
      xs(1,i) = sin(nx*th)
      ys(1,i) = sin(ny*th)
      xs(2,i) = nx*cos(nx*th)*dth*r
      ys(2,i) = ny*cos(ny*th)*dth*r
   enddo      

   call fr_graph2d(xs,ys,2*(nmax+1),4,6)

   dth   = pi2/(nmax*20)
   do i = 0, nmax*20
      th = dth*i
      x(i) = sin(nx*th)
      y(i) = sin(ny*th)
   enddo      

   call fr_graph2d(x,y,nmax*20+1,6,1)

end subroutine lissajous

!*******************************
!   2D Log Axis Graphic Test   *
!*******************************
subroutine logsin
   implicit none
   integer, parameter :: nmax=1000
   real  x(0:nmax),y(0:nmax),dx,xmax,ymax
   integer i

   xmax = 5.0
   ymax = 2.0

   dx   = 2*xmax/nmax
   do i = 0, nmax
       x(i) = dx*i-xmax
       y(i) = sin(10*x(i))
   enddo
   call fr_aspect2d(1.0,1.0,-1)
   call fr_setaxis(3)
   call fr_frame2d(-xmax,xmax,-ymax,ymax,10)
   call fr_xyname('x-axis','y-datas')
   call fr_graph2d(x,y,nmax+1,6,2)
!   call fr_graph2d(x,y,nmax+1,2,3)

   call fr_2dmove(1.0,y(nmax),1)
   call fr_fpchars(-5.0,0.0,'test for fpchrs',3,-1,0,0,30)

end subroutine logsin

!*****************************
!     Polygons and Circles   *
!*****************************
subroutine polygn
   implicit none
   real  xmin,xmax,ymax,dx,dl,dd,xxx,yyy
   integer i,nn

   xmin = 0.0
   xmax = 2.0
   ymax = 3.0
   nn   = 20
   
   dl    = 14.0
   dd    = 32.0

   call fr_frame2d(xmin,xmax,-ymax,ymax,10)
   call fr_xyname('x-axis','y-datas')

   dx = xmax/nn
   do i = 1, nn
      xxx=dx*i
      yyy=2.0*sin(5*xxx)
      call fr_2dmove(xxx,yyy,0)
      call fr_fpcircle(0.0,0.0,dd,dd,-i*6,31)
      call fr_fpmark(0.0,0.0,dl,dl,6,-i*6,32)
   enddo

end subroutine polygn

!*****************************
!     histgram               *
!*****************************
subroutine histgram
   implicit none
   real  xx(21),yy(21),xmax,ymax,x
   integer i,nn

   nn   = 21
   xmax = nn-1
   ymax = 1.0

   call fr_frame2d(0.0,xmax,0.0,ymax,10)
   call fr_xyname('number','frequency')

   do i = 1, nn
      xx(i) = i-1
      x     = xx(i)/2.0
      yy(i) = 1.5*x**2*exp(-x)
   enddo
   call fr_setbar(0.4,0)
   call fr_graph2d(xx,yy,nn,5,7)

end subroutine histgram

!******************************
!         brusselator         *
!       test of vectors       *
!******************************
subroutine bruss
   implicit none
   real  x,r,y(2),f(2)
   real  xx(500),yy(500),xf(0:20,0:20),yf(0:20,0:20)
   integer i,j

   call fr_view2d(100,70,550,390)
   call fr_aspect2d(1.0,1.0,0)
   call fr_frame2d(0.0,5.0,0.0,5.0,10)
   call fr_xyname('x','y')
!   call fr_setarrow(20.0,20.0)
   x = 0.0
   r = 0.05
   do j = 0, 20
      do i = 0, 20
         y(1) = 0.25*i
         y(2) = 0.25*j
         call hannou(y,f)
         call fr_vector2d(y(1),y(2),r*f(1),r*f(2),2,0)
         xf(i,j) = f(1)
         yf(i,j) = f(2)
      enddo
   enddo

   do i = 1, 10
      xx(1) = 0.4*i
      yy(1) = 0.2*i
!      yy(1) = 0.2
      call fr_flow2dline(xx,yy,500,xf,yf,21,21,4,1e-5,5)
   enddo

end subroutine bruss

subroutine hannou(f,df)
   implicit none
   real  f(2),df(2)

   df(1) = 0.5 + f(1)*(f(1)*f(2) - 3.0)
   df(2) = f(1)*(2.0 - f(1)*f(2))

end subroutine hannou

!*******************************
!        Dipole Field          *
!       Test of Flow Line      *
!*******************************
subroutine field
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: ifmax=31, itmax=40, imax=30, jmax=40
   real  xx(500),yy(500)
   real  bx(-imax:imax,0:jmax),by(-imax:imax,0:jmax)
   real  f(ifmax),th(itmax),x,y,r,th1,area
   integer i,j

!   call fr_view2d(100,70,550,390)
   call fr_aspect2d(1.0,1.0,0)
   call fr_frame2d(-0.25*imax,0.25*imax,0.0,0.25*jmax,0)
   call fr_xyname('x','y')
   do j = 0, jmax
      do i = -imax, imax
         x  = 0.25*i
         y  = 0.25*j
         call dipole(x,y,bx(i,j),by(i,j))
      enddo
   enddo

   r = 1.0
   do i = 1, ifmax
      th1 = pi*(i-1)/real(ifmax-1)
      call dipole(r*cos(th1),r*sin(th1),x,y)
      f(i) = x*cos(th1)+y*sin(th1)
   enddo
   
   th(1)     = 0.0
   th(itmax) = pi
   call fr_flowspace(f,ifmax,th,itmax,area,0)

   call fr_flow2drgn(0.0,0.25*imax,0.0,0.25*jmax)
   do i = 1, itmax/2
      xx(1) = r*cos(th(i))
      yy(1) = r*sin(th(i))
      call fr_flow2dline(xx,yy,500,bx,by,2*imax+1,jmax+1,4,1e-7,5)
   enddo
   call fr_flow2drgn(-0.25*imax,0.0,0.0,0.25*jmax)
   do i = itmax/2+1, itmax
      xx(1) = r*cos(th(i))
      yy(1) = r*sin(th(i))
      call fr_flow2dline(xx,yy,500,bx,by,2*imax+1,jmax+1,6,1e-7,-5)
   enddo

end subroutine field

subroutine dipole(x,y,bx,by)
   real  x,y,r2,r5,bx,by

   r2 = x*x+y*y
   if (r2 == 0) then
      bx = 0.0
      by = 0.0
    else
      r5 = r2**2.5
      bx = (3.0*x*x-r2)/r5
      by = 3.0*x*y/r5
   endif
end subroutine dipole

!******************************
!       Test of Contours      *
!******************************
subroutine tcont
   implicit none
   integer, parameter :: imax=50, jmax=50
   real  f(0:imax,0:jmax)
   real  xmin,xmax,ymin,ymax,x,y,dx,dy
   integer i,j

   xmin = -3.0
   xmax =  3.0
   ymin = -2.0
   ymax =  2.0
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax
   do j = 0, jmax
      do i = 0, imax
         x=dx*i+xmin
         y=dy*j+ymin
         f(i,j)=exp(-0.5*((x-1)**2+(y-0.5)**2))+exp(-1.2*((x+1.5)**2+(y+0.5)**2))
      enddo
   enddo

!      call fr_view2d(150,40,500,390)
   call fr_aspect2d(1.0,1.0,1)
   call fr_xyname('re','im')
   call fr_frame2d(xmin,xmax,ymin,ymax,0)

   call fr_setcontour(0.0,2.0,2)
   call fr_setcontour(0.5,0.0,3)
!      call fr_set2rgn(50,100,50,100)
!      call fr_set2dbox(-2.0,2.0,-3.0,3.0,0)
   call fr_contour(f,imax+1,jmax+1,31,205)
   call fr_setcontour(0.5,2.0,4)
   call fr_contour(f,imax+1,jmax+1,30,6)

end subroutine tcont

!***********************************
!       Test of Fill Contours      *
!***********************************
subroutine tcont2
   implicit none
   integer, parameter :: imax=20, jmax=20
   real  f(0:imax,0:jmax)
   real  xmin,xmax,ymin,ymax,x,y,dx,dy,x0,y0
   integer i,j

   xmin = -3.0
   xmax =  3.0
   ymin = -2.0
   ymax =  2.0
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax

   x0 = 1.0
   y0 = 0.0

   do j = 0, jmax
      do i = 0, imax
         x=dx*i+xmin
         y=dy*j+ymin
         f(i,j)=exp(-0.5*((x-x0)**2+(y-y0)**2))-exp(-1.2*((x-1.5)**2+(y-0.5)**2))
      enddo
   enddo

!   call fr_view2d(150,40,500,390)
   call fr_aspect2d(1.0,1.0,0)
   call fr_frame2d(xmin,xmax,ymin,ymax,0)
   call fr_xyname('re','im')
   call fr_contour(f,imax+1,jmax+1,20,-2)
   call fr_2dmove(0.5,1.0,3)
   call fr_colorbar(0,10,100,15,132)
   call fr_2dmove(1.0,0.5,3)
   call fr_colorbar(10,0,15,100,132)

end subroutine tcont2

!*******************************************************
!       Test of Fill Contours for Arbitrary Mesh       *
!*******************************************************
subroutine tconsq
   implicit none
   integer, parameter :: imax=15, jmax=30
   real  f(0:imax,0:jmax),x(0:imax,0:jmax),y(0:imax,0:jmax)
   real  sh(5),sl(5),ss(5),rmin,rmax,tmin,tmax,dr,dt,r,t
   integer ndiv(4),i,j

   rmin =  0.5
   rmax =  3.0
   tmin =  0.0
   tmax =  8.0*atan(1.0)
   dr   = (rmax - rmin)/imax
   dt   = (tmax - tmin)/jmax
   do j = 0, jmax
      do i = 0, imax
         r=dr*i+rmin
         t=dt*j+tmin
         x(i,j) = r*cos(t)
         y(i,j) = r*sin(t)
         f(i,j)=exp(-0.5*((x(i,j)-1.0)**2+(y(i,j)-0.5)**2)) &
               -exp(-1.2*((x(i,j)+1.5)**2+(y(i,j)+0.5)**2))
      enddo
   enddo
   sh(1) = 240.0
   sh(2) = 240.0
   sh(3) = 0.0
   sh(4) = 0.0
   sl(1) = 0.2
   sl(2) = 0.95
   sl(3) = 0.95
   sl(4) = 0.2
   ss(1) = 1.0
   ss(2) = 1.0
   ss(3) = 1.0
   ss(4) = 1.0
   ndiv(1) = 64
   ndiv(2) = 0
   ndiv(3) = 64
   call fr_hlsset(sh,sl,ss,ndiv,3)

!   call fr_view2d(150,40,500,390)
   call fr_aspect2d(1.0,1.0,0)
!   call fr_frame2d(-3.0,3.0,-3.0,3.0,2)
!   call fr_xyname('re','im')
   call fr_setcontour(-1.0,1.0,2)
!   call fr_set2rgn(50,100,50,100)

   call fr_sqrcontour(x,y,f,imax+1,jmax+1,30,-2,7)
   call fr_colorbar(500,220,20,200,102)

end subroutine tconsq

!*******************************************************
!       Test of Fill Contours for Triangle Mesh        *
!*******************************************************
subroutine tcontr
   implicit none
   integer, parameter :: npd=300, nsd=500
   real  x(npd),y(npd),f(npd)
   integer ndx(3,nsd)
   real  sh(3),sl(3),ss(3),dy,xmin,xmax,ymin,ymax
   integer ndiv(2),i,np,ns,ni,nj

   xmin = -3.0
   xmax =  3.0
   ymin = -2.0
   ymax =  2.0
   ni   = 10
   nj   = 10
   dy = (ymax-ymin)/nj

   np = 0
   ns = 0
   call genmesh(xmin,0.0,ymin,ymax,ni,nj,x,y,ndx,np,ns)
   call genmesh(0.0,xmax,ymin,-dy,ni,nj/2-1,x,y,ndx,np,ns)
   call genmesh(0.6,xmax,0.0,ymax,ni,nj,x,y,ndx,np,ns)

   do i = 1, np
      f(i)=-exp(-5.0*((x(i)-1.8)**2+(y(i)-1.1)**2)) &
           +exp(-0.7*((x(i)+1.3)**2+(y(i)+0.5)**2))
   enddo

   sh(1) = 130.0
   sh(2) = 340.0
   sh(3) = 340.0
   sl(1) = 0.5
   sl(2) = 0.5
   sl(3) = 0.0
   ss(1) = 1.0
   ss(2) = 1.0
   ss(3) = 1.0
   ndiv(1) = 64
   ndiv(2) = 64
   call fr_hlsset(sh,sl,ss,ndiv,2)

   call fr_view2d(80,50,560,430)
   call fr_aspect2d(1.0,1.0,0)
   call fr_frame2d(xmin,xmax,ymin,ymax,1)
!   call fr_setcontour(-1.0,1.0,2)

   call fr_tricontour(x,y,f,np,ndx,ns,20,-2,7)
   call fr_colorbar(200,60,200,20,2)

end subroutine tcontr

subroutine genmesh(x1,x2,y1,y2,ni,nj,x,y,node,ip,is)
   implicit none
   real  x1,x2,y1,y2,x(*),y(*)
   integer node(3,*),ni,nj,ip,is
   real  dx,dy
   integer i,j,np,np0,ns

   dx = (x2-x1)/ni
   dy = (y2-y1)/nj
   
   np = ip
   do j = 0, nj
      do i = 0, ni
         np = np + 1
         x(np) = x1 + i*dx
         y(np) = y1 + j*dy
      enddo
   enddo

   ns  = is
   np0 = ip
   do j = 0, nj-1
      do i = 0, ni-1
         ns  = ns + 1
         np0 = np0 + 1
         node(1,ns) = np0
         node(2,ns) = np0 + ni + 1
         node(3,ns) = np0 + ni + 2
         ns  = ns + 1
         node(1,ns) = np0
         node(2,ns) = np0 + 1
         node(3,ns) = np0 + ni + 2
      enddo
      np0 = np0 + 1
   enddo

   ip = np
   is = ns

end subroutine genmesh
