**************************************************
*             F  R  A  M  E  S  V.7              *
*         REAL COORDINATE GRAPHIC LIBRARIES      *
*            PROGRAMMED BY T.TAGUCHI             *
**************************************************
      SUBROUTINE FR_GINIT
      PARAMETER (IYOFFSET=30,LTCOLMAX0=118,ICMAPMIN=16)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /GRAPHCOM3D/ XMIN3,XMAX3,YMIN3,YMAX3,XTAN3,YTAN3,X03,Y03
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN3,IXMAX3,IYMIN3,IYMAX3,IZXMAX,IZYMAX,IFRAM3,IVIEW3
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /ASPECTXYCOM/ RXY,IASPEC,IXBMIN,IXBMAX,IYBMIN,IYBMAX
      COMMON /HGLINECOM3D/ IHG,IHIND
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /GPAGECOM/ IACPAGE,IDSPAGE
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /HISTGRAMCOM/ HIST0,MODHIST
*      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
*     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /CONTLIMITCOM/ FCMIN,FCMAX,MODDRAW
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      COMMON /CONTREG3DCOM/ CNXMIN3,CNXMAX3,CNYMIN3,CNYMAX3
     ,                     ,CNZMIN,CNZMAX,ICNREG3
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /REGIONSCOM3D/ NXDMIN3,NXDMAX3,NYDMIN3,NYDMAX3
     ,                     ,NZDMIN,NZDMAX
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /FLRREGIONCOM3D/ RNXM13,RNXM23,RNYM13,RNYM23
     ,                       ,RNZM13,RNZM23,NFCHK3
      COMMON /AXISNAMECOM/ XNAME,YNAME,IXYNAME,LXNM,LYNM
      CHARACTER XNAME*128,YNAME*128
      COMMON /AXISNAMECOM3D/ XNAM3,YNAM3,ZNAME,IXYZNAME,LXNM3,LYNM3,LZNM
      CHARACTER XNAM3*128,YNAM3*128,ZNAME*128
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      COMMON /VOLUMERENDCOM/ FVRMIN,FVRMAX,ALPHA,BETA,BRMAX,INDBR
      SAVE /GRAPHCOM/,/GRAPHCOM3D/,/HGLINECOM3D/,/DEFFRAMCOM/
      SAVE /GPAGECOM/,/GCANVASCOM/,/CLIPPINGCOM/,/ASPECTXYCOM/
      SAVE /PROJECTCOM/,/GRAPH3DMOD/,/NFCONTCOM/,/CONTREGIONCOM/
      SAVE /REGIONSCOM/,/REGIONSCOM3D/,/FLRREGIONCOM/,/FLRREGIONCOM3D/
      SAVE /COLORMODCOM/,/PERSPECTCOM/,/PROFREGIONCOM/,/CONTREG3DCOM/
      SAVE /HISTGRAMCOM/,/CONTLIMITCOM/,/GFILESELECT/
      SAVE /AXISNAMECOM/,/AXISNAMECOM3D/,/LIGHTINGCOM/,/VOLUMERENDCOM/

*     IGCANVAS = WIN(2)-1 : CHECK GFILE.F
      IGCANVAS = 1
      IGPLT    = 0
      NFPCOUNT = 0
      NFP      = 0

*      IF ICOL256 BECOMES -1 AFTER THE FOLLOWING CALL, IT IS TPLOT.
      CALL FRAMESINITIAL(NCL256,ICOL256,NFP)
      ICOLMODE = 0
      N256MAP  = 0
      ICUMAP   = 0
      ICSYSMAP = 0
      DO 10 I = 1, 50
         ICMAP(I) = -1
   10 CONTINUE
*      ICMAPMIN SHOULD BE DETERMINED BY SPHERE COLORS.
      ICMAPMAX = ICMAPMIN
      LTCOLMAX  = LTCOLMAX0
      LTCOLBASE = ICMAPMIN
      LCSBASE   = 0
*      CALL GWIOMODECHECK(IGMODE)

      IXMIN   = 80
      IYMIN   = 20  + IYOFFSET
      IXMAX   = 560
      IYMAX   = 340 + IYOFFSET

      XMIN    = 0
      YMIN    = 0
      XMAX    = IXMAX - IXMIN
      YMAX    = IYMAX - IYMIN
      XTAN    = 1
      YTAN    = -1
      X0      = 0.0
      Y0      = IYMAX

      PX      = 0.0
      PY      = 0.0
      IFRAM   = 0
      IVIEW   = 0
      IXYNAME = 0

      HIST0   = 0
      MODHIST = 0

      RXY     = 1.0
      IASPEC  = -1
      IXBMIN  = IXMIN
      IYBMIN  = IYMIN
      IXBMAX  = IXMAX
      IYBMAX  = IYMAX

      IXMIN3  = 70
      IXMAX3  = 440
      IYMIN3  = 120 + IYOFFSET
      IYMAX3  = 340 + IYOFFSET
      IZXMAX  = 560
      IZYMAX  = 220 + IYOFFSET

      XTAN3   = 1.0
      YTAN3   = -1.0
      X03     = 0.0
      Y03     = IYMAX3 + IYMIN3
      ZXTAN   = 1.0
      ZYTAN   = 1.0
      ZX0     = X03
      ZY0     = Y03
      ZMIN    = 0.0
      ZMAX    = X03 - ZX0

      IHIND   = 0
      IHG     = 0

      GX      = 0
      GY      = 0
      IFRAM3  = 0
      IVIEW3  = 0
      IXYZNAME= 0

      IXPMIN  = 30
      IXPMAX  = 610
      IYPMIN  = 10  + IYOFFSET
      IYPMAX  = 390 + IYOFFSET
      XPMID   = 0.5*(IXPMIN + IXPMAX)
      YPMID   = 0.5*(IYPMIN + IYPMAX)
      XPX     = 1.0/SQRT(2.0)
      XPY     = XPX
      YPX     = 0
      YPY     = 0
      YPZ     = XPY

      XPMIN   = 0.0
      XPMAX   = XPX + XPY
      YPMIN   = YPX
      YPMAX   = YPY + YPZ
      RX      = (IXPMAX - IXPMIN)/(XPMAX - XPMIN)
      RY      = (IYPMIN - IYPMAX)/(YPMAX - YPMIN)
      IF (ABS(RX).GE.ABS(RY)) THEN
         RATE = ABS(RY)
       ELSE
         RATE = ABS(RX)
      ENDIF
      XPX     = RATE*XPX
      XPY     = XPX
      XPZ     = 0
      YPX     = -RATE*YPX
      YPY     = YPX
      YPZ     = -XPY
      XP0     = -0.5*RATE*(XPMAX - XPMIN)
      YP0     =  0.5*RATE*(YPMAX - YPMIN) + RATE*YPMIN
      ZSCALE  = 1

      THETA   =  45.0
      PHI     = -45.0
      RATIO   = RATE
      RATIOXY = 1.0
      RATIOXZ = 1.0
      IPROJ   = 0
      MOD3DIR = 0
      MDPROJ  = 0
      IACPAGE = 0
      IDSPAGE = 0

      CALL DEFAULTLIGHTING(-1)

      IDFFR2  = -999
      IDFFR3  = -999
      LOGFORM = 0
      LABELAX = 0
      ICLP    = 0
      ICLP3D  = 0

      NCL6    = 16
      MODCONT = 0
      IFCONT  = 0
      ICMAX   = -1
*      FBASE   = 0
      IFBASE  = 0
      IRNF    = 0
      ICNREG  = 0
      ICNREG3 = 0
      FCMIN   = 0
      FCMAX   = 1
      MODDRAW = 0

      MODE3D  = 1
      MODEGEOM = 1
      IPRREG  = 0

      NXDMIN  = 0
      NYDMIN  = 0
      NSTEP   = 0

      NXDMIN3 = 0
      NYDMIN3 = 0
      NZDMIN  = 0

      NFCHK   = 0
      NFCHK3  = 0

      ALPHA   = 1
      BETA    = 1
      FVRMIN  = 0
      FVRMAX  = 0
      BRMAX   = 0
      INDBR   = 0

      RETURN
      END

      SUBROUTINE FR_GEND
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      CALL CANVASALLCLOSE

      IF (IGCANVAS.GT.0) CALL GWIOTERMINATE
      IGCANVAS = -1
         IGPLT = -1

      RETURN
      END

      SUBROUTINE CLEARGSETTINGS
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /GRAPHCOM3D/ XMIN3,XMAX3,YMIN3,YMAX3,XTAN3,YTAN3,X03,Y03
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN3,IXMAX3,IYMIN3,IYMAX3,IZXMAX,IZYMAX,IFRAM3,IVIEW3
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /REGIONSCOM3D/ NXDMIN3,NXDMAX3,NYDMIN3,NYDMAX3
     ,                     ,NZDMIN,NZDMAX
      COMMON /FLRREGIONCOM3D/ RNXM13,RNXM23,RNYM13,RNYM23
     ,                       ,RNZM13,RNZM23,NFCHK3
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      COMMON /CONTREG3DCOM/ CNXMIN3,CNXMAX3,CNYMIN3,CNYMAX3
     ,                     ,CNZMIN,CNZMAX,ICNREG3
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /AXISNAMECOM/ XNAME,YNAME,IXYNAME,LXNM,LYNM
      COMMON /VOLUMERENDCOM/ FVRMIN,FVRMAX,ALPHA,BETA,BRMAX,INDBR
      CHARACTER XNAME*128,YNAME*128
      COMMON /AXISNAMECOM3D/ XNAM3,YNAM3,ZNAME,IXYZNAME,LXNM3,LYNM3,LZNM
      CHARACTER XNAM3*128,YNAM3*128,ZNAME*128

      IFRAM   = 0
      IVIEW   = 0
      IXYNAME = 0
      IFRAM3  = 0
      IVIEW3  = 0
      IXYZNAME= 0
      NFCHK   = 0
      NXDMIN  = 0
      NYDMIN  = 0
      NFCHK3  = 0
      NXDMIN3 = 0
      NYDMIN3 = 0
      NZDMIN  = 0
      NSTEP   = 0
      MODCONT = 0
      IFCONT  = 0
      ICNREG  = 0
      ICNREG3 = 0
      ICMAX   = -1
      IFBASE  = 0
      IRNF    = 0
      IF (ICOL256.GT.0) ICOL256 = 0
      ICLP    = 0
      ICLP3D  = 0
      IPRREG  = 0
      LOGFORM = 0
      LABELAX = 0
      INDBR   = 0
      IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)

*      IF (IGCANVAS.GT.0.AND.ICLP.NE.0) THEN
         CALL GWIONOCLIP
*      ENDIF
      CALL DEFAULTLIGHTING(1)

      RETURN
      END

      SUBROUTINE FR_SETCIRCLE(DD)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      real*8 DD

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(101,1)
*         CALL GSENDBYTE(IR,2)
         CALL GSEND8BYTE(DD,DD,1,-1)
      ENDIF

      IF (DD.LT.0) THEN
         CALL GWIODEFAULTSIZES(1,0)
       ELSE
         DIAMX  = DD
         DIAMY  = DD
      ENDIF
      MKSPEC = 0

      RETURN
      END

      SUBROUTINE FR_SETMARK(DD1,DD2,ISPEC)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      real*8 DD1,DD2

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(107,1)
         CALL GSENDBYTE(ISPEC,2)
         CALL GSEND8BYTE(DD1,DD2,1,0)
      ENDIF

      IF (ISPEC.EQ.0) THEN
         DIAMX = DD1*2
         DIAMY = DD2*2
       ELSE
         DIAM1 = DD1
         DIAM2 = DD2
      ENDIF

      MKSPEC = ISPEC
      IF (MKSPEC.LT.3)  MKSPEC = 0
      IF (MKSPEC.GT.20) MKSPEC = 20

      IF (MKSPEC.GT.0) CALL GWIOMARKING(CX,CY,-1)

      RETURN
      END

      SUBROUTINE FR_SETBAR(BASE,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /HISTGRAMCOM/ HIST0,MODHIST
      REAL*8 BASE

      IF (IGCANVAS.LT.0) RETURN

      MODE1 = MODE
      IF (MODE1.LT.0) MODE1 = 0
      IF (MODE1.GT.1) MODE1 = 1
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(108,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSEND8BYTE(BASE,BASE,1,-1)
      ENDIF

      HIST0    = BASE
      MODHIST  = MODE1

      RETURN
      END

      SUBROUTINE FR_SETARROW(LL,HH)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      common /comarrows/ arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real arrowl,arrowh,arrowr,arrowmin,arrowmag,arhead
      real*8 LL,HH

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(102,1)
*         CALL GSENDBYTE(IL,2)
*         CALL GSENDBYTE(IH,2)
         CALL GSEND8BYTE(LL,HH,1,0)
      ENDIF

      IF (LL.GT.0) THEN
         ARROWL  = LL
        ELSE IF (LL.LT.0) THEN
         ARROWMAG = -LL
        ELSE IF (HH.EQ.0) THEN
         ARROWMIN = 0
        ELSE IF (HH.LT.0) THEN
         CALL GWIODEFAULTSIZES(0,1)
      ENDIF
      IF (HH.GT.0) THEN
         ARROWH  = HH/2
       ELSE IF (HH.LT.0.AND.LL.NE.0) THEN
         ARROWMIN = -HH
      ENDIF
      ARROWR  = ARROWH/ARROWL

      RETURN
      END

      SUBROUTINE FR_SETSTEP(NS)
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      NSTEP = NS
      IF (NSTEP.EQ.1.OR.NSTEP.EQ.-1) NSTEP = 0

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(104,1)
         NS0 = NSTEP
         IF (NS0.LT.0) NS0 = 0
         CALL GSENDBYTE(NS0,4)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_SETFRAME(IDEF,IDIM)
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(105,1)
         NS = IDEF
         IF (NS.GE.0.AND.IDIM.GT.1) NS = NS + 100
         CALL GSENDBYTE(NS,4)
      ENDIF

      IF (IDIM.LE.1) THEN
         IDFFR2 = IDEF
       ELSE 
         IDFFR3 = IDEF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_SETFRAME2D(IDEF)
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(105,1)
         CALL GSENDBYTE(IDEF,4)
      ENDIF

      IDFFR2 = IDEF

      RETURN
      END

      SUBROUTINE FR_SETFRAME3D(IDEF)
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(105,1)
         NS = IDEF + 100
         CALL GSENDBYTE(NS,4)
      ENDIF

      IDFFR3 = IDEF

      RETURN
      END

      SUBROUTINE FR_SETAXIS(IND)
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
*      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IGPLT.GT.0) THEN
*         CALL GSENDBYTE(13,1)
*         CALL GSENDBYTE(10+IND,1)
*      ENDIF

      LOGFORM = MOD(IND,10)
      LABELAX = IND/10

      RETURN
      END

      SUBROUTINE FR_SETCONTOUR(F10,F20,IND)
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CONTLIMITCOM/ FCMIN,FCMAX,MODDRAW
      REAL*8 F10,F20,F1,F2
      SAVE F1,F2

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         IF (IND.LT.0) THEN
            CALL GSENDBYTE(12,1)
            CALL GSENDBYTE(MODCONT,2)
            IF (MODCONT.GT.0) CALL GSEND8BYTE(F1,F2,1,0)
            IFCONT = 1
            RETURN
          ELSE
            CALL GSENDBYTE(12,1)
            CALL GSENDBYTE(IND,2)
            IF (IND.GT.0.AND.IND.LT.5) CALL GSEND8BYTE(F10,F20,1,0)
         ENDIF
      ENDIF

*6      IF (IND.LT.5) THEN
         IF (IND.EQ.3) THEN
            FBASE  = F10
            IFBASE = 1
            RETURN
          ELSE IF (IND.EQ.4) THEN
            FBASE  = F10
            FBASE1 = F10 + F20
*            IF (FBASE.GT.FBASE1) THEN
*               FBASE  = F10 + F20
*               FBASE1 = F10
*            ENDIF
            IFBASE = 2
            RETURN
         ENDIF

         IFCONT = 1

         MODCONT = IND
         IF (MODCONT.EQ.0) RETURN
         IF (MODCONT.EQ.1) THEN
            FMIN = F10
            DF   = F20
            IF (DF.EQ.0.D0) DF = 1.0
            F1   = F10
            F2   = F20
*          ELSE IF (MODCONT.EQ.4) THEN
*            FMIN = F10
          ELSE
            CALL REGULATEGREGION(F10,F20,F1,F2)
            IF (F1.LE.F2) THEN
               FMIN = F1
               FMAX = F2
             ELSE
               FMIN = F2
               FMAX = F1
            ENDIF
         ENDIF
         FCMIN = FMIN
         FCMAX = FMAX
*6       ELSE
*6         IF (IND.LT.NCL256) THEN
*6            NCL6 = IND
*6           ELSE
*6            NCL6 = NCL256
*6         ENDIF
*6      ENDIF

      RETURN
      END

      SUBROUTINE FR_SET2DRGN(NX1,NX2,NY1,NY2)
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /FLRREGIONCOM/ RNXM1,RNXM2,RNYM1,RNYM2,NFCHK
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF ((NX1.GT.0.AND.NX2.LE.NX1)
     *              .OR.(NY1.GT.0.AND.NY2.LE.NY1)) THEN
         CALL FRAMESERROR('ILLEGAL SETTINGS FOR SET2DRGN')
         RETURN
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(103,1)
         CALL GSENDBYTE(NX1,4)
         IF (NX1.GT.0) CALL GSENDBYTE(NX2,4)
         CALL GSENDBYTE(NY1,4)
         IF (NY1.GT.0) CALL GSENDBYTE(NY2,4)
      ENDIF

      NXDMIN = NX1
      NXDMAX = NX2
      NYDMIN = NY1
      NYDMAX = NY2

      NFCHK  = 0

      RETURN
      END

      SUBROUTINE FR_SETGEOMETRY(IND)
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM

      MODEGEOM = IND

      RETURN
      END

      SUBROUTINE FR_SET3DRGN(NX1,NX2,NY1,NY2,NZ1,NZ2)
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /FLRREGIONCOM3D/ RNXM1,RNXM2,RNYM1,RNYM2,RNZM1,RNZM2,NFCHK
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      IF ((NX1.GT.0.AND.NX2.LE.NX1)
     *              .OR.(NY1.GT.0.AND.NY2.LE.NY1)
     *              .OR.(NZ1.GT.0.AND.NZ2.LE.NZ1)) THEN
         CALL FRAMESERROR('ILLEGAL SETTINGS FOR SET3DRGN')
         RETURN
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(106,1)
         CALL GSENDBYTE(NX1,4)
         IF (NX1.GT.0) CALL GSENDBYTE(NX2,4)
         CALL GSENDBYTE(NY1,4)
         IF (NY1.GT.0) CALL GSENDBYTE(NY2,4)
         CALL GSENDBYTE(NZ1,4)
         IF (NZ1.GT.0) CALL GSENDBYTE(NZ2,4)
      ENDIF

      NXDMIN = NX1
      NXDMAX = NX2
      NYDMIN = NY1
      NYDMAX = NY2
      NZDMIN = NZ1
      NZDMAX = NZ2

      NFCHK  = 0

      RETURN
      END

      SUBROUTINE FR_SET2DBOX(DX1,DX2,DY1,DY2,MASK)
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      COMMON /PROFREGIONCOM/ PRXMIN,PRXMAX,PRYMIN,PRYMAX,IPRREG
      REAL*8 DX1,DX2,DY1,DY2

      CNXMIN = DX1
      CNXMAX = DX2
      CNYMIN = DY1
      CNYMAX = DY2

      ICNREG = 2+MASK

      PRXMIN = DX1
      PRXMAX = DX2
      PRYMIN = DY1
      PRYMAX = DY2

      IPRREG = 2+MASK

      RETURN
      END

      SUBROUTINE FR_SET3DBOX(DX1,DX2,DY1,DY2,DZ1,DZ2,MASK)
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      REAL*8 DX1,DX2,DY1,DY2,DZ1,DZ2

      CNXMIN = DX1
      CNXMAX = DX2
      CNYMIN = DY1
      CNYMAX = DY2
      CNZMIN = DZ1
      CNZMAX = DZ2

      ICNREG = 2+MASK

      RETURN
      END

      SUBROUTINE FR_2DCONTOURBOX(DX1,DX2,DY1,DY2,MASK)
      COMMON /CONTREGIONCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX,ICNREG
      REAL*8 DX1,DX2,DY1,DY2

      CNXMIN = DX1
      CNXMAX = DX2
      CNYMIN = DY1
      CNYMAX = DY2

      ICNREG = 2+MASK

      RETURN
      END

      SUBROUTINE FR_3DCONTOURBOX(DX1,DX2,DY1,DY2,DZ1,DZ2,MASK)
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      REAL*8 DX1,DX2,DY1,DY2,DZ1,DZ2

      CNXMIN = DX1
      CNXMAX = DX2
      CNYMIN = DY1
      CNYMAX = DY2
      CNZMIN = DZ1
      CNZMAX = DZ2

      ICNREG = 2+MASK

      RETURN
      END

      SUBROUTINE FR_SETCOLOR(F1,F2)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 F1,F2

      IF (IGCANVAS.LT.0) RETURN

      FMIN  = F1
      FMAX  = F2
      IFIND = -2
      ND1   = NCL256-1
      DF    = (F2 - F1)/(ND1+1)

      RETURN
      END

      SUBROUTINE FR_SETLIGHT(DTH,DPH,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      REAL*8 DTH,DPH

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         IF (MODE.EQ.-1000) THEN
            CALL GSENDBYTE(109,1)
            CALL GSENDBYTE(0,1)
            CALL GSEND8BYTE(DBLE(LTH),DBLE(LPH),1,0)
            ILIGHT = 1
            RETURN
          ELSE
            CALL GSENDBYTE(109,1)
            CALL GSENDBYTE(MODE,1)
            CALL GSEND8BYTE(DTH,DPH,1,0)
         ENDIF
      ENDIF

      IF (MODE.EQ.1) THEN
         LTH  = DMOD(DTH,180.0D0)
         IF (LTH.GT.90.0)  LTH =  180.0 - LTH
         IF (LTH.LT.-90.0) LTH = -180.0 - LTH
         LPH  = DMOD(DPH+PHI,360.0D0)
         IF (LPH.GT.180.0)  LPH = LPH - 360.0
         IF (LPH.LE.-180.0) LPH = LPH + 360.0
       ELSE
         LTH  = DMOD(DTH,180.0D0)
         IF (LTH.GT.90.0)  LTH =  180.0 - LTH
         IF (LTH.LT.-90.0) LTH = -180.0 - LTH
         LPH  = DMOD(DPH,360.0D0)
         IF (LPH.GT.180.0)  LPH = LPH - 360.0
         IF (LPH.LE.-180.0) LPH = LPH + 360.0
      ENDIF

      ILIGHT   = 1

      RETURN
      END

      SUBROUTINE SET3DVIEWDIRECTION(EEX,EEY,EEZ,CLGX,CLGY,CLGZ)
      REAL*8 PI,TH,PH
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH

      XX1 = XPY*YPZ-YPY*XPZ
      YY1 = XPZ*YPX-YPZ*XPX
      ZZ1 = XPX*YPY-YPX*XPY
      IF (MDPROJ.EQ.0) THEN
         EEX = -XX1
         EEY = -YY1
         EEZ = -ZZ1
         RR  = SQRT(EEX**2+EEY**2+EEZ**2)
         EEX = EEX/RR
         EEY = EEY/RR
         EEZ = EEZ/RR
       ELSE
         XD0 = (XMAX+XMIN)/2
         YD0 = (YMAX+YMIN)/2
         ZD0 = (ZMAX+ZMIN)/2
*         0 = XPX*(X-XD0) + XPY*(Y-YD0) + XPZ*(Z-ZD0)
*         0 = YPX*(X-XD0) + YPY*(Y-YD0) + YPZ*(Z-ZD0)
*         1 = ZPX*(X-XD0) + ZPY*(Y-YD0) + ZPZ*(Z-ZD0)
         DET = ZPX*XX1+ZPY*YY1+ZPZ*ZZ1
         EEX = XD0 + XX1/DET
         EEY = YD0 + YY1/DET
         EEZ = ZD0 + ZZ1/DET
      ENDIF
      TH  = PI*LTH/180.D0
      PH  = PI*LPH/180.D0
      IF (MOD3DIR.EQ.1) THEN
         CLGY    =  COS(TH)*COS(PH)
         CLGZ    =  COS(TH)*SIN(PH)
         CLGX    =  SIN(TH)
       ELSE IF (MOD3DIR.EQ.2) THEN
         CLGZ    =  COS(TH)*COS(PH)
         CLGX    =  COS(TH)*SIN(PH)
         CLGY    =  SIN(TH)
       ELSE
         CLGX    =  COS(TH)*COS(PH)
         CLGY    =  COS(TH)*SIN(PH)
         CLGZ    =  SIN(TH)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_SETSURFACE(AMB,DIF,NSPO)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      REAL*8 AMB,DIF

      IF (IGCANVAS.LT.0) RETURN

      IF (NSPO.LT.0.AND.NSPO.NE.-1000) CALL DEFAULTLIGHTING(0)

      IF (IGPLT.GT.0) THEN
         IF (NSPO.LT.0) THEN
            CALL GSENDBYTE(110,1)
            CALL GSENDBYTE(NSPORDER,1)
            CALL GSEND8BYTE(DBLE(CAMB),DBLE(CDIF),1,0)
            ISURF = 1
            RETURN
          ELSE
            CALL GSENDBYTE(110,1)
            CALL GSENDBYTE(NSPO,1)
            CALL GSEND8BYTE(AMB,DIF,1,0)
         ENDIF
      ENDIF

      IF (AMB.GE.0.AND.DIF.GE.0) THEN
         CAMB  = AMB
         CDIF  = DIF
         CSPC  = 1-CAMB-CDIF
         IF (CSPC.LT.0) CSPC = 0
         NSPORDER  = NSPO
      ENDIF

      ISURF   = 1

      RETURN
      END

      SUBROUTINE DEFAULTLIGHTING(MODE)
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH

      CAMB     = 0.12
      CDIF     = 0.62
      CSPC     = 1-CAMB-CDIF
      IF (MODE.LT.0) THEN
         LTH      = 90.0
         LPH      = 0
         ISURF    = 0
       ELSE IF (MODE.GT.0) THEN
         ISURF    = 0
      ENDIF
      NSPORDER = 20
      ILIGHT   = 0

      RETURN
      END

      SUBROUTINE FR_SETVOLUME(FMIN,FMAX,ALPHA0,BETA0)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /VOLUMERENDCOM/ FVRMIN,FVRMAX,ALPHA,BETA,BRMAX,INDBR
      REAL*8 FMIN,FMAX,ALPHA0,BETA0

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(111,1)
         CALL GSEND8BYTE(FMIN,FMAX,1,0)
         IF (ALPHA0.EQ.-9999.D0) THEN
            CALL GSEND8BYTE(DBLE(ALPHA),DBLE(BETA),1,0)
          ELSE
            CALL GSEND8BYTE(ALPHA0,BETA0,1,0)
         ENDIF
      ENDIF

      IF (FMIN.LT.FMAX.AND.ALPHA0.NE.-9999.D0) THEN
         FVRMIN = FMIN
         FVRMAX = FMAX
      ENDIF
      IF (ALPHA0.GT.0) ALPHA = ALPHA0
      IF (BETA0.GT.0)  BETA  = BETA0

      RETURN
      END

      SUBROUTINE FR_COLORBAR(IXX,IYY,IDX,IDY,IND)
      PARAMETER (LOLDSET=0)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL XX(4),YY(4)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      CHARACTER CH*20,FORM*20
      REAL PP(2),FF(2)
      INTEGER IP

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(14,1)
         CALL GSENDBYTE(IND,2)
         CALL GSENDBYTE(IXX,2)
         CALL GSENDBYTE(IYY,2)
         CALL GSENDBYTE(IDX,2)
         CALL GSENDBYTE(IDY,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

*      IF (IND/10000.NE.0) GO TO 1
      IF (IND.GE.0.AND.IFIND.GT.-2) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN

      IND1 = ABS(IND)
      M5   = 0
      IF (IND/10000.NE.0) THEN
         M5 = IND/10000
         IND1 = MOD(IND1,10000)
      ENDIF
      IF (LOLDSET.EQ.1) THEN
*     OLD SETTINGS
         MD   = MOD(IND1/10,10)
         M3   = IND1/100
         IND1 = MOD(IND1,10)
         M4   = M3/10
         M3   = MOD(M3,10)
         MMM  = 0
         IF (IND1.GE.3) THEN
            IND1 = IND1 - 3
            MMM  = 1
          ELSE IF (M4.GT.0) THEN
            MMM = M4
         ENDIF
         IF (IND1.EQ.0) THEN
            IF (IDX.GT.IDY) THEN
               IND1 = 1
             ELSE
               IND1 = 2
            ENDIF
         ENDIF
       ELSE
*     NEW SETTINGS
         MD   = MOD(IND1,10)
         M3   = IND1/10
         M4   = M3/10
         M3   = MOD(M3,10)
         MMM  = 0
         IF (M4.GT.0) THEN
            MMM  = 1
         ENDIF
         IF (IDX.GT.IDY) THEN
            IND1 = 1
          ELSE
            IND1 = 2
         ENDIF
      ENDIF

      IF (IVIEW3.EQ.0) THEN
         IXML = IXMIN
         IXMU = IXMAX
         IYML = IYMIN
         IYMU = IYMAX
       ELSE
         IXML = IXPMIN
         IXMU = IXPMAX
         IYML = IYPMIN
         IYMU = IYPMAX
      ENDIF

      CALL AXISDELFORM(FMIN,FMAX,DF,FORM,NS,NSC,NS1,NMZ,1)
      IF (NMZ.NE.0) THEN
         FMIN = FMIN*10.D0**(-NMZ)
         FMAX = FMAX*10.D0**(-NMZ)
      ENDIF

      ND1  = NCL256
      NM   = INT(FMIN/DF) - 1
      FT   = NM*DF
      ZMIN = FMIN - 0.001*DF
      ZMAX = FMAX + 0.001*DF
      CALL GWIOCOLOR(0,-7)
      CALL GWIONOCLIP

1000  IF (FT.LT.ZMIN) THEN
         NM  = NM + 1
         FT  = DF*NM
         GO TO 1000
      ENDIF

      IF (M3.EQ.1.OR.M3.EQ.3) THEN
         PXX = IXX + CURPX
       ELSE
         PXX = IXX
      ENDIF
      IF (IND1.EQ.1.AND.MMM.EQ.1) PXX = PXX - IDX/2
      IF (M3.GE.2) THEN
         PYY = CURPY - IYY
       ELSE
         PYY = IYY
      ENDIF
      IF (IND1.EQ.2.AND.MMM.EQ.1) PYY = PYY - IDY/2

      IF (IND1.EQ.1) THEN
         IF (MD.NE.0) THEN
            FTAN = IDX/(FMAX-FMIN)
            FF0  = PXX - FTAN*FMIN

            IF (MD.EQ.2) THEN
               PYY = PYY - IDY
               PX  = PXX
               PY  = PYY
               NT0 = -4
               NK  = -1
             ELSE
               PX  = PXX
               PY  = PYY+IDY
               NT0 = 4
               NK  = 1
            ENDIF

            NT2 = 2*NT0
            NT3 = 3*NT0
            IP  = 0
1010        IF (FT.LT.ZMAX) THEN
               PFT = FTAN*FT + FF0
               NT  = NT0
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT2
                  IF (IP.EQ.0) THEN
                     IP = IP + 1
                     FF(1) = FT
                     PP(1) = PFT
                   ELSE
                     IP    = IP + 1
                     FF(2) = FT
                     PP(2) = PFT
                  ENDIF
               ENDIF
               CALL GWIOLINE(PFT,PY,PFT,PY+NT,0)
               NM  = NM + 1
               FT  = NM*DF
               GO TO 1010
            ENDIF
            IF (IP.LT.2) THEN
               WRITE(CH,FORM) FMIN
               CALL FWNUMBER(PX,PY+NT3,CH,NMZ,1,NK,-1,1)
               PX = PXX+IDX
               WRITE(CH,FORM) FMAX
               CALL FWNUMBER(PX,PY+NT3,CH,NMZ,1,NK,-1,1)
             ELSE
               WRITE(CH,FORM) FF(1)
               CALL FWNUMBER(PP(1),PY+NT3,CH,NMZ,1,NK,-1,1)
               WRITE(CH,FORM) FF(2)
               CALL FWNUMBER(PP(2),PY+NT3,CH,NMZ,1,NK,-1,1)
            ENDIF
         ENDIF

         DX     = REAL(IDX)/ND1
         PXX1   = PXX
         PYY1   = PYY
         DO 10 I = 0, ND1-1
            CALL GWIOCOLOR(256,I)
            XX(1) = PXX1 + DX*I
            YY(1) = PYY1
            XX(2) = PXX1 + DX*(I+1)
            YY(2) = PYY1
            XX(3) = PXX1 + DX*(I+1)
            YY(3) = PYY1 + IDY
            XX(4) = PXX1 + DX*I
            YY(4) = PYY1 + IDY
            CALL GWIOPOLYGON(XX,YY,4,2)
  10     CONTINUE
  
       ELSE

         IF (MD.NE.0) THEN
            FTAN = IDY/(FMIN-FMAX)
            FF0  = PYY - FTAN*FMAX

            IF (MD.EQ.2) THEN
               PX  = PXX+IDX
               PY  = PYY+IDY
               NT0 = 4
               NK  = -1
               NX  = 1
             ELSE
               PXX = PXX-IDX
               PX  = PXX
               PY  = PYY+IDY
               NT0 = -4
               NK  = -1
               NX  = -1
            ENDIF

            FT0 = FT
            NM0 = NM
1021        IF (FT0.LT.ZMAX) THEN
               IF (MOD(NM0,NS).EQ.0) THEN
                  IF (MOD(NM0,NSC).EQ.0) GO TO 1022
               ENDIF
               NM0  = NM0 + 1
               FT0  = NM0*DF
               GO TO 1021
            ENDIF

1022        NT2 = 2*NT0
            IF (MD.EQ.2) THEN
               IF (FT0.LT.0.0) THEN
                  NT3 = 2.5*NT0
                ELSE
                  NT3 = NT0
               ENDIF
             ELSE
               NT3 = 1.5*NT0
            ENDIF
            IP  = 0
1020        IF (FT.LT.ZMAX) THEN
               PFT = FTAN*FT + FF0
               NT  = NT0
               IF (MOD(NM,NS).EQ.0) THEN
                  NT = NT2
                  IF (IP.EQ.0) THEN
                     IP = IP + 1
                     FF(1) = FT
                     PP(1) = PFT
                   ELSE
                     IP    = IP + 1
                     FF(2) = FT
                     PP(2) = PFT
                  ENDIF
                  IF (MOD(NM,NSC).EQ.0) THEN
                     WRITE(CH,FORM) FT
                     CALL FWNUMBER(PX+NT3,PFT,CH,NMZ,NX,0,NK,0)
                  ENDIF
               ENDIF
               CALL GWIOLINE(PX,PFT,PX+NT,PFT,0)
               NM  = NM + 1
               FT  = NM*DF
               GO TO 1020
            ENDIF
*            IF (IP.LT.2) THEN
*               WRITE(CH,FORM) FMIN
*               CALL FWNUMBER(PX+NT3,PY,CH,NMZ,NX,0,NK,0)
*               PY = PYY
*               WRITE(CH,FORM) FMAX
*               CALL FWNUMBER(PX+NT3,PY,CH,NMZ,NX,0,NK,0)
*             ELSE
*               WRITE(CH,FORM) FF(1)
*               CALL FWNUMBER(PX+NT3,PP(1),CH,NMZ,NX,0,NK,0)
*               WRITE(CH,FORM) FF(2)
*               CALL FWNUMBER(PX+NT3,PP(2),CH,NMZ,NX,0,NK,0)
*            ENDIF
         ENDIF

         DY     = REAL(IDY)/ND1
         PXX1   = PXX
         PYY1   = PYY + IDY
         DO 20 I = 0, ND1-1
            CALL GWIOCOLOR(256,I)
            XX(1) = PXX1
            YY(1) = PYY1 - DY*I
            XX(2) = PXX1
            YY(2) = PYY1 - DY*(I+1)
            XX(3) = PXX1 + IDX
            YY(3) = PYY1 - DY*(I+1)
            XX(4) = PXX1 + IDX
            YY(4) = PYY1 - DY*I
            CALL GWIOPOLYGON(XX,YY,4,2)
  20     CONTINUE
      ENDIF

      CALL GWIOCOLOR(0,-7)
      CALL GWIOLINE(PXX,PYY,PXX+REAL(IDX),PYY+REAL(IDY),1)
       IF (M5.NE.0) THEN
         CALL GWIOCOLOR(0,2)
         CALL GWIOLINE(REAL(IXML),REAL(IYML),REAL(IXMU),REAL(IYMU),1)
      ENDIF

      CALL GWIOBDFLUSH(1)
      IF (ICLP.NE.0) CALL GWIOADDCLIP(REAL(IXMIN),REAL(IYMIN)
     ,                                   ,REAL(IXMAX),REAL(IYMAX))

      RETURN
      END

      SUBROUTINE FR_MAXMIN(A,N,AMIN,AMAX)
      REAL*8 A(*),AMIN,AMAX,A1,A2

      IF (N.LT.0) THEN
         IF (AMAX.LT.AMIN) THEN
            A1 = AMAX
            A2 = AMIN
          ELSE
            A1 = AMIN
            A2 = AMAX
         ENDIF
         N0 = -N
       ELSE
         A1 = A(1)
         A2 = A1
         N0 = N
      ENDIF

      DO 10 I = 1, N0
         IF (A(I).LT.A1) A1 = A(I)
         IF (A(I).GT.A2) A2 = A(I)
   10  CONTINUE

      AMIN = A1
      AMAX = A2

      RETURN
      END

*      SUBROUTINE GRID1D(A,N,AMIN,AMAX)
*      REAL*8 A(*),AMIN,AMAX,DA

*      A(1) = AMIN
*      IF (N.LE.1) RETURN
*      DA = (AMAX - AMIN)/(N-1)
*      DO 10 I = 1, N-1
*         A(I+1) = DA*I + AMIN
*   10  CONTINUE

*      RETURN
*      END

      SUBROUTINE REGULATEGREGION(FMIN0,FMAX0,FMIN,FMAX)
      REAL*8 FMIN0,FMAX0,FMIN,FMAX
      REAL*4 FM1,FM2

      FM1 = FMIN0
      FM2 = FMAX0
      IF (FM1.EQ.FM2) THEN
         IF (FM1.EQ.0.0) THEN
            FMIN = -1.D0
            FMAX = 1.D0
          ELSE IF (FM1.LT.0.0) THEN
            FMIN = FMIN0
            FMAX = 0.D0
          ELSE
            FMIN = 0.D0
            FMAX = FMAX0
         ENDIF
       ELSE
         FMIN = FMIN0
         FMAX = FMAX0
      ENDIF

      RETURN
      END

      SUBROUTINE BARSECONDCOLOR(IC1,IC2)
      INTEGER ICM(7)
      DATA ICM/5,3,2,6,1,4,1/

      IF (IC2.NE.0) RETURN
      IF (IC1.LE.0.OR.IC1.GT.7) RETURN
      IC2 = ICM(IC1)

      RETURN
      END

      SUBROUTINE FGWIOLINESTART
      COMMON /CONTLIMITCOM/ FCMIN,FCMAX,MODDRAW

      MODDRAW = 1

      RETURN
      END

      SUBROUTINE FGWIOLINEEND
      COMMON /CONTLIMITCOM/ FCMIN,FCMAX,MODDRAW

      IF (MODDRAW.EQ.1) THEN
         CALL GWIOLINE(0.0,0.0,0.0,0.0,-100)
         MODDRAW = 0
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOCOLORSET(ICOL,ND,FM1,FM2)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF
      REAL DF1
      REAL*8 FM1,FM2

      IF (ICOL.GT.-2.AND.ND.EQ.0) RETURN

      IF (ICOL.LT.0) THEN
         IFIND = MOD(ICOL,10)
*         IRNF  = ICOL/10
*         IRNF  = 0
*         IF (IFIND.LT.-5) IFIND = -5
*         IF (IFIND .LT. -1) IRNF = 1
       ELSE IF (ICOL.GE.100) THEN
         IFIND = 1
       ELSE
         IFIND = 0
      ENDIF

      IF (ICOL.GE.100) THEN
         IC    = MOD(ICOL,100)
         IC2   = ICOL/100
       ELSE IF (ICOL.GE.0) THEN
         IC    = ICOL
         CALL GWIOCOLOR(2,IC)
      ENDIF

      ND1 = ND
      IF (ND1.LT.0) ND1 = -ND1
      IF (IFIND.EQ.-1) THEN
*6         DNF   = REAL(NCL6)/ND1
         DNF   = REAL(NCL256-1)/ND1
       ELSE IF (IFIND.LE.-2) THEN
         DNF   = 1.0
         ND1   = NCL256-1
         IF (IRNF.EQ.0) THEN
            ICMAX = -1
          ELSE
            ICMAX = 0
         ENDIF
      ENDIF

      IF (MODCONT.EQ.0) THEN
         CALL REGULATEGREGION(FM1,FM2,FM1,FM2)
         DF1  = (FM2 - FM1)/ND1
         IF (IFIND.GE.-1) THEN
*         IF (IRNF.EQ.0) THEN
            DF   = (FM2 - FM1 + DF1*0.01D0)/(ND1 + 1)
            FMIN = FM1 - DF1*0.005D0 + DF
          ELSE
            DF   = (FM2 - FM1)/(ND1 + 1)
            FMIN = FM1
         ENDIF
*         DF  = (FM2 - FM1)/ND1
*         FMIN = FM1
         FMAX = FM2
       ELSE IF (MODCONT.EQ.1) THEN
         FMAX = FM2
         IF (IFIND.LE.-2) FMAX = FMIN + DF*NCL256
       ELSE IF (MODCONT.EQ.4) THEN
         DF   = MAX(ABS(FMIN-FM1),ABS(FMIN-FM2))*2.D0
         IF (DF.EQ.0.D0) DF = 1.D0
         FMAX = FMIN + DF*0.5D0
       ELSE
         DF   = (FMAX - FMIN)/(ND1+1)
      ENDIF

      NDV = ND1

      IF (IFIND.LE.-2.AND.IFBASE.EQ.2) THEN
*         IF (FBASE.GE.FMIN.AND.FBASE.LE.FMAX) THEN
*            RNF = (FBASE - FMIN)/DF
*            NF  = RNF
*            ICMAX = NF*DNF
*         ENDIF
         IFBASE = -1
         IF (FBASE.GT.FBASE1) THEN
             DF1    = FBASE
             FBASE  = FBASE1
             FBASE1 = DF1
         ENDIF

       ELSE IF (IFIND.EQ.0.AND.IFBASE.EQ.2) THEN
         DF   = MAX(ABS(FBASE-FM1),ABS(FBASE-FM2))*2.D0
         IF (DF.EQ.0.D0) DF = 1.D0
         FMIN = FBASE
         FMAX = FMIN + DF*0.5D0
         IFBASE = 0
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOLINE(X0,Y0,X1,Y1)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CONTLIMITCOM/ FCMIN,FCMAX,MODDRAW
      REAL X0,Y0,X1,Y1,F0,FMIN,FMAX,FBASE,FBASE1
      REAL DF,CFX,CFY,DNF,RNF,FCMIN,FCMAX
*      INTEGER IC0(6)
*      DATA IC0/1,5,4,6,3,2/

      IF (IFIND.NE.0) THEN
         INC = 2
         IF (IFIND.EQ.1) THEN
            IF (IFBASE.EQ.1) THEN
               IF (DF*NF+FMIN.LT.FBASE) THEN
                  IC1 = IC2
                ELSE
                  IC1 = IC
               ENDIF
             ELSE
               IF (MOD(NF,5).EQ.0) THEN
                  IC1 = IC2
                ELSE
                  IC1 = IC
               ENDIF
            ENDIF
          ELSE IF (IFIND.EQ.-1) THEN
            INC = 256
*6            IC1  = INT(NF*DNF + 1.01)*NCL256/NCL6
            IC1  = NF*DNF
*            IF (IC1.LT.0)      IC1 = 0
*            IF (IC1.GE.NCL256) IC1 = NCL256-1

*            N0  = NF*DNF + 1.01
*            IF (N0.LE.0) N0 = 1
*            IF (N0.GT.NCL6) N0 = NCL6
*            IC1 = IC0(N0)
          ELSE
            IC1 = IC
         ENDIF
         CALL GWIOCOLOR(INC,IC1)          
      ENDIF

      IF (MODDRAW.EQ.1) THEN
         CALL GWIOLINE(X0,Y0,X1,Y1,100)
       ELSE
         CALL GWIOLINE(X0,Y0,X1,Y1,0)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOBASECOL(F,IMAX,JMAX,X1,Y1,X2,Y2)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF,X1,Y1,X2,Y2
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL XX1,YY1,XX2,YY2
      REAL*8 F(IMAX,JMAX)
      INTEGER NCL(256)

      IF (IFBASE.LT.0.OR.IRNF.NE.0) RETURN
*      IF (IFBASE.LT.0.OR.IRNF.NE.0) THEN
**         ICMAX = 0
*         IFBASE = 0
*         RETURN
*      ENDIF

      DO 5 I = 1, 256
         NCL(I) = 0
    5 CONTINUE

      DO 10 J = 1, JMAX
         DO 11 I = 1, IMAX 
            NF  = (F(I,J) - FMIN)/DF
            IC1 = NF*DNF
            IF (IC1.LT.0)      IC1 = 0
            IF (IC1.GE.NCL256) IC1 = NCL256-1
            NCL(IC1+1) = NCL(IC1+1) + 1
   11 CONTINUE
   10 CONTINUE

      NCMAX = 0
      ICMAX = 0
      DO 15 I = 1, 256
         IF (NCMAX.LT.NCL(I)) THEN
            NCMAX = NCL(I)
            ICMAX = I-1
         ENDIF
  15  CONTINUE

      XX1 = X1
      YY1 = Y1
      XX2 = X2
      YY2 = Y2
      IF (XX1.GT.XX2) THEN
         XX1 = X2
         XX2 = X1
      ENDIF
      IF (YY1.GT.YY2) THEN
         YY1 = Y2
         YY2 = Y1
      ENDIF

      CALL GWIOCOLOR(256,ICMAX)
      CALL GWIOLINE(XX1,YY1,XX2,YY2,2)

      RETURN
      END

      SUBROUTINE FGWIOPOLY(XP,YP,N,FP)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP(*),YP(*),FP,F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF

      IF (IFBASE.LT.0) THEN
         IF (FP.GE.FBASE.AND.FP.LE.FBASE1) GO TO 1
      ENDIF

      RNF = (FP - FMIN)/DF
      NF  = RNF + 0.5
      IC1 = NF*DNF
      IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPOLYGON(XP,YP,N,3)
       ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPOLYGON(XP,YP,N,3)
      ENDIF

   1  XP(1) = XP(N)
      YP(1) = YP(N)
      XP(2) = XP(N-1)
      YP(2) = YP(N-1)
      N     = 2

      RETURN
      END

      SUBROUTINE FGWIOPOLYS(XP,YP,N)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP(*),YP(*),F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF

*      IF (IFBASE.LT.0) THEN
*         IF (FP.GE.FBASE.AND.FP.LE.FBASE1) GO TO 1
*      ENDIF

      IC1 = NF*DNF
      IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPOLYGON(XP,YP,N,3)
       ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPOLYGON(XP,YP,N,3)
      ENDIF

   1  XP(1) = XP(N)
      YP(1) = YP(N)
      XP(2) = XP(N-1)
      YP(2) = YP(N-1)
      N     = 2

      RETURN
      END

      SUBROUTINE FGWIOCOLORBOX(XP,YP,FP)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP(*),YP(*),FP,F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF

      IF (IFBASE.LT.0) THEN
         IF (FP.GE.FBASE.AND.FP.LE.FBASE1) RETURN
      ENDIF

      RNF = (FP - FMIN)/DF
      NF  = RNF + 0.5
      IC1 = NF*DNF
      IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
         CALL GWIOCOLOR(256,IC1)
       ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
         CALL GWIOCOLOR(256,IC1)
      ENDIF
      IF (IC1.NE.0) THEN
         CALL GWIOLINE(XP(1),YP(1),XP(2),YP(2),2)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOLITPOLY(XP,YP,N,CS)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP(*),YP(*),F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF,CS

      IC1 = NF*DNF
      IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
         CALL GWIOGRADCOLOR(256,IC1,CS)
         CALL GWIOPOLYGON(XP,YP,N,3)
       ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
         CALL GWIOGRADCOLOR(256,IC1,CS)
         CALL GWIOPOLYGON(XP,YP,N,3)
      ENDIF

      XP(1) = XP(N)
      YP(1) = YP(N)
      XP(2) = XP(N-1)
      YP(2) = YP(N-1)
      N     = 2

      RETURN
      END

      SUBROUTINE FGWIOGRADFILLBOX(XP,YP,CNC)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP(*),YP(*),CNC(*),F0,FMIN,FMAX,FBASE,FBASE1
      REAL DF,CFX,CFY,DNF,RNF,FPMIN,FPMAX

      IC1 = 0
      IF (IFBASE.LT.0) THEN
         FPMIN = CNC(1)
         FPMAX = CNC(1)
         DO I = 1, 4
            IF (CNC(I).LT.FPMIN) FPMIN = CNC(I)
            IF (CNC(I).GT.FPMAX) FPMAX = CNC(I)
            RNF    = (CNC(I) - FMIN)/DF
            CNC(I) = RNF*DNF
            IF (INT(CNC(I)).NE.ICMAX) IC1 = 1
         ENDDO
         IF (FPMIN.GE.FBASE.AND.FPMAX.LE.FBASE1) RETURN
       ELSE
         DO I = 1, 4
            RNF    = (CNC(I) - FMIN)/DF
            CNC(I) = RNF*DNF
            IF (INT(CNC(I)).NE.ICMAX) IC1 = 1
         ENDDO
      ENDIF
      IF (ICMAX.LT.0.OR.IC1.NE.0) THEN
         CALL GWIOGRADFILLBOX(XP(1),YP(1),XP(2),YP(2),CNC)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOFSQUARE(SQX,SQY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL SQX(4),SQY(4),FP(4)

      CALL GWIOCOLOR(2,0)
      CALL GWIOPOLYGON(SQX,SQY,4,3)

      IF (MODE.EQ.1) THEN
*         F00 = FP(1)+FP(2)+FP(3)+FP(4)
*         RNF = (F00/4 - FMIN)/DF
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,1)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,1)
         ENDIF
       ELSE IF (MODE.EQ.2) THEN
         XX12 = (SQX(1) + SQX(2))/2
         YY12 = (SQY(1) + SQY(2))/2
         XX23 = (SQX(2) + SQX(3))/2
         YY23 = (SQY(2) + SQY(3))/2
         XX34 = (SQX(3) + SQX(4))/2
         YY34 = (SQY(3) + SQY(4))/2
         XX41 = (SQX(4) + SQX(1))/2
         YY41 = (SQY(4) + SQY(1))/2
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),XX41,YY41,0)
            CALL GWIOLINE(SQX(1),SQY(1),XX12,YY12,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),XX41,YY41,0)
            CALL GWIOLINE(SQX(1),SQY(1),XX12,YY12,0)
         ENDIF
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),XX12,YY12,0)
            CALL GWIOLINE(SQX(2),SQY(2),XX23,YY23,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),XX12,YY12,0)
            CALL GWIOLINE(SQX(2),SQY(2),XX23,YY23,0)
         ENDIF
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),XX23,YY23,0)
            CALL GWIOLINE(SQX(3),SQY(3),XX34,YY34,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),XX23,YY23,0)
            CALL GWIOLINE(SQX(3),SQY(3),XX34,YY34,0)
         ENDIF
         RNF = (FP(4) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),XX34,YY34,0)
            CALL GWIOLINE(SQX(4),SQY(4),XX41,YY41,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),XX34,YY34,0)
            CALL GWIOLINE(SQX(4),SQY(4),XX41,YY41,0)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),SQX(2),SQY(2),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),SQX(2),SQY(2),0)
         ENDIF
         F00 = FP(2)+FP(3)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),SQX(3),SQY(3),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),SQX(3),SQY(3),0)
         ENDIF
         F00 = FP(3)+FP(4)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),SQX(4),SQY(4),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),SQX(4),SQY(4),0)
         ENDIF
         F00 = FP(4)+FP(1)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),SQX(1),SQY(1),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),SQX(1),SQY(1),0)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOFPSQUARE(SQX,SQY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL SQX(4),SQY(4),FP(4),SX1(4),SY1(4)

      MC = MCOL

      IF (MODE.EQ.1.OR.MODE.EQ.2) THEN
         MC = -1
         IF (MODE.EQ.1) THEN
            CALL GWIOCOLOR(2,0)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
         XX12 = (SQX(1) + SQX(2))/2
         YY12 = (SQY(1) + SQY(2))/2
         XX23 = (SQX(2) + SQX(3))/2
         YY23 = (SQY(2) + SQY(3))/2
         XX34 = (SQX(3) + SQX(4))/2
         YY34 = (SQY(3) + SQY(4))/2
         XX41 = (SQX(4) + SQX(1))/2
         YY41 = (SQY(4) + SQY(1))/2
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),XX41,YY41,0)
            CALL GWIOLINE(SQX(1),SQY(1),XX12,YY12,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),XX41,YY41,0)
            CALL GWIOLINE(SQX(1),SQY(1),XX12,YY12,0)
         ENDIF
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),XX12,YY12,0)
            CALL GWIOLINE(SQX(2),SQY(2),XX23,YY23,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),XX12,YY12,0)
            CALL GWIOLINE(SQX(2),SQY(2),XX23,YY23,0)
         ENDIF
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),XX23,YY23,0)
            CALL GWIOLINE(SQX(3),SQY(3),XX34,YY34,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),XX23,YY23,0)
            CALL GWIOLINE(SQX(3),SQY(3),XX34,YY34,0)
         ENDIF
         RNF = (FP(4) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),XX34,YY34,0)
            CALL GWIOLINE(SQX(4),SQY(4),XX41,YY41,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),XX34,YY34,0)
            CALL GWIOLINE(SQX(4),SQY(4),XX41,YY41,0)
         ENDIF
       ELSE IF (MODE.EQ.3) THEN
         XX41 = (SQX(4) + SQX(1))/2
         YY41 = (SQY(4) + SQY(1))/2
         SX1(1) = SQX(1)
         SY1(1) = SQY(1)
         SX1(2) = (SQX(1) + SQX(2))/2
         SY1(2) = (SQY(1) + SQY(2))/2
         SX1(3) = (SQX(1) + SQX(2) + SQX(3) + SQX(4))/4
         SY1(3) = (SQY(1) + SQY(2) + SQY(3) + SQY(4))/4
         SX1(4) = XX41
         SY1(4) = YY41
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(2)
         SY1(1) = SQY(2)
         SX1(4) = (SQX(2) + SQX(3))/2
         SY1(4) = (SQY(2) + SQY(3))/2
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(3)
         SY1(1) = SQY(3)
         SX1(2) = (SQX(3) + SQX(4))/2
         SY1(2) = (SQY(3) + SQY(4))/2
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(4)
         SY1(1) = SQY(4)
         SX1(4) = XX41
         SY1(4) = YY41
         RNF = (FP(4) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
       ELSE
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
      ENDIF

      IF (MC.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOFTRIANGLE(TRIX,TRIY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3)

      CALL GWIOCOLOR(2,0)
      CALL GWIOPOLYGON(TRIX,TRIY,3,3)

      IF (MODE.EQ.1) THEN
*         F00 = FP(1)+FP(2)+FP(3)+FP(4)
*         RNF = (F00/4 - FMIN)/DF
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,1)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,1)
         ENDIF
       ELSE IF (MODE.EQ.2) THEN
         XX12 = (TRIX(1) + TRIX(2))/2
         YY12 = (TRIY(1) + TRIY(2))/2
         XX23 = (TRIX(2) + TRIX(3))/2
         YY23 = (TRIY(2) + TRIY(3))/2
         XX31 = (TRIX(3) + TRIX(1))/2
         YY31 = (TRIY(3) + TRIY(1))/2
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX31,YY31,0)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX12,YY12,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX31,YY31,0)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX12,YY12,0)
         ENDIF
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX12,YY12,0)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX23,YY23,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX12,YY12,0)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX23,YY23,0)
         ENDIF
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX23,YY23,0)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX31,YY31,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX23,YY23,0)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX31,YY31,0)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),TRIX(2),TRIY(2),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),TRIX(2),TRIY(2),0)
         ENDIF
         F00 = FP(2)+FP(3)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),TRIX(3),TRIY(3),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),TRIX(3),TRIY(3),0)
         ENDIF
         F00 = FP(3)+FP(1)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),TRIX(1),TRIY(1),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),TRIX(1),TRIY(1),0)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOFPTRIANGLE(TRIX,TRIY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3),SX1(4),SY1(4)

      MC = MCOL

      IF (MODE.EQ.1.OR.MODE.EQ.2) THEN
         MC = -1
         IF (MODE.EQ.1) THEN
            CALL GWIOCOLOR(2,0)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
         XX12 = (TRIX(1) + TRIX(2))/2
         YY12 = (TRIY(1) + TRIY(2))/2
         XX23 = (TRIX(2) + TRIX(3))/2
         YY23 = (TRIY(2) + TRIY(3))/2
         XX31 = (TRIX(3) + TRIX(1))/2
         YY31 = (TRIY(3) + TRIY(1))/2
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX31,YY31,0)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX12,YY12,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX31,YY31,0)
            CALL GWIOLINE(TRIX(1),TRIY(1),XX12,YY12,0)
         ENDIF
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX12,YY12,0)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX23,YY23,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX12,YY12,0)
            CALL GWIOLINE(TRIX(2),TRIY(2),XX23,YY23,0)
         ENDIF
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX23,YY23,0)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX31,YY31,0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX23,YY23,0)
            CALL GWIOLINE(TRIX(3),TRIY(3),XX31,YY31,0)
         ENDIF
       ELSE IF (MODE.EQ.3) THEN
         XX31 = (TRIX(3) + TRIX(1))/2
         YY31 = (TRIY(3) + TRIY(1))/2
         SX1(1) = TRIX(1)
         SY1(1) = TRIY(1)
         SX1(2) = (TRIX(1) + TRIX(2))/2
         SY1(2) = (TRIY(1) + TRIY(2))/2
         SX1(3) = (TRIX(1) + TRIX(2) + TRIX(3))/3
         SY1(3) = (TRIY(1) + TRIY(2) + TRIY(3))/3
         SX1(4) = XX31
         SY1(4) = YY31
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = TRIX(2)
         SY1(1) = TRIY(2)
         SX1(4) = (TRIX(2) + TRIX(3))/2
         SY1(4) = (TRIY(2) + TRIY(3))/2
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = TRIX(3)
         SY1(1) = TRIY(3)
         SX1(2) = XX31
         SY1(2) = YY31
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
       ELSE
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
      ENDIF

      IF (MC.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOSSQUARE(SQX,SQY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL SQX(4),SQY(4),FP(4),SX1(4),SY1(4)

      IF (MODE.EQ.1) THEN
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
       ELSE IF (MODE.EQ.2) THEN
         XX41 = (SQX(4) + SQX(1))/2
         YY41 = (SQY(4) + SQY(1))/2
         SX1(1) = SQX(1)
         SY1(1) = SQY(1)
         SX1(2) = (SQX(1) + SQX(2))/2
         SY1(2) = (SQY(1) + SQY(2))/2
         SX1(3) = (SQX(1) + SQX(2) + SQX(3) + SQX(4))/4
         SY1(3) = (SQY(1) + SQY(2) + SQY(3) + SQY(4))/4
         SX1(4) = XX41
         SY1(4) = YY41
         RNF = (FP(1) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(2)
         SY1(1) = SQY(2)
         SX1(4) = (SQX(2) + SQX(3))/2
         SY1(4) = (SQY(2) + SQY(3))/2
         RNF = (FP(2) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(3)
         SY1(1) = SQY(3)
         SX1(2) = (SQX(3) + SQX(4))/2
         SY1(2) = (SQY(3) + SQY(4))/2
         RNF = (FP(3) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
         SX1(1) = SQX(4)
         SY1(1) = SQY(4)
         SX1(4) = XX41
         SY1(4) = YY41
         RNF = (FP(4) - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SX1,SY1,4,3)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)+FP(3)+FP(4)
         RNF = (F00/4 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
      ENDIF

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOAVSQUARE(SQX,SQY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL SQX(4),SQY(4),FP(4)

      MC = MCOL

      IF (MODE.EQ.1.OR.MODE.EQ.2) THEN
         MC = -1
         IF (MODE.EQ.1) THEN
            CALL GWIOCOLOR(2,0)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
         F00 = FP(1)+FP(2)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),SQX(2),SQY(2),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(1),SQY(1),SQX(2),SQY(2),0)
         ENDIF
         F00 = FP(2)+FP(3)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),SQX(3),SQY(3),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(2),SQY(2),SQX(3),SQY(3),0)
         ENDIF
         F00 = FP(3)+FP(4)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),SQX(4),SQY(4),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(3),SQY(3),SQX(4),SQY(4),0)
         ENDIF
         F00 = FP(4)+FP(1)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),SQX(1),SQY(1),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(SQX(4),SQY(4),SQX(1),SQY(1),0)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)+FP(3)+FP(4)
         RNF = (F00/4 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(SQX,SQY,4,3)
         ENDIF
      ENDIF

      IF (MC.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOSTRIANGLE(TRIX,TRIY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3)

      IF (MODE.EQ.1) THEN
         F00 = FP(1)
         RNF = (F00 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)+FP(3)
         RNF = (F00/3 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
      ENDIF

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOAVTRIANGLE(TRIX,TRIY,FP,MCOL,MODE)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3)

      MC = MCOL

      IF (MODE.EQ.1.OR.MODE.EQ.2) THEN
         MC = -1
         IF (MODE.EQ.1) THEN
            CALL GWIOCOLOR(2,0)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
         F00 = FP(1)+FP(2)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),TRIX(2),TRIY(2),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(1),TRIY(1),TRIX(2),TRIY(2),0)
         ENDIF
         F00 = FP(2)+FP(3)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),TRIX(3),TRIY(3),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(2),TRIY(2),TRIX(3),TRIY(3),0)
         ENDIF
         F00 = FP(3)+FP(1)
         RNF = (F00/2 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),TRIX(1),TRIY(1),0)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOLINE(TRIX(3),TRIY(3),TRIX(1),TRIY(1),0)
         ENDIF
       ELSE
         F00 = FP(1)+FP(2)+FP(3)
         RNF = (F00/3 - FMIN)/DF
         NF  = RNF
         IC1 = NF*DNF
         IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
          ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
            CALL GWIOCOLOR(256,IC1)
            CALL GWIOPOLYGON(TRIX,TRIY,3,3)
         ENDIF
      ENDIF

      IF (MC.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOSQUARE(SQX,SQY,FP0,MCOL)
      REAL SQX(4),SQY(4),FP0(4)
      REAL TRIX(3),TRIY(3),FP(3)

      TRIX(1) = SQX(1)
      TRIX(2) = SQX(2)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(1)
      TRIY(2) = SQY(2)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(1)
      FP(2)   = FP0(2)
      FP(3)   = FP0(4)
      CALL FGWIOTRIANGLE(TRIX,TRIY,FP,-1)

      TRIX(1) = SQX(2)
      TRIX(2) = SQX(3)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(2)
      TRIY(2) = SQY(3)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(2)
      FP(2)   = FP0(3)
      FP(3)   = FP0(4)
      CALL FGWIOTRIANGLE(TRIX,TRIY,FP,-1)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOTRIANGLE(TRIX,TRIY,FP,MCOL)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3),XP(5),YP(5)

         DO 220 L = 1, 2
            DO 221 L1 = L+1, 3
               IF (FP(L).GT.FP(L1)) THEN
                  TT       = TRIX(L)
                  TRIX(L)  = TRIX(L1)
                  TRIX(L1) = TT
                  TT       = TRIY(L)
                  TRIY(L)  = TRIY(L1)
                  TRIY(L1) = TT
                  FF       = FP(L)
                  FP(L)    = FP(L1)
                  FP(L1)   = FF
               ENDIF
  221      CONTINUE
  220      CONTINUE

         F01 = FP(1)
         F03 = FP(3)
         IF (IFIND.EQ.-2.AND.IFBASE.LT.0) THEN
            IF (F01.GE.FBASE.AND.F03.LE.FBASE1) GO TO 10
         ENDIF
         NF  = INT((F01 - FMIN)/DF) - 1
         NPG   = 1
         XP(1) = TRIX(1)
         YP(1) = TRIY(1)

  250    FD = NF*DF + FMIN
         IF (FD.LT.F01) THEN
            NF = NF + 1
            GO TO 250
         ENDIF
         IN0 = 1
         DX1 = TRIX(3) - TRIX(1)
         DY1 = TRIY(3) - TRIY(1)
         DX2 = TRIX(2) - TRIX(1)
         DY2 = TRIY(2) - TRIY(1)
         DFI = FP(2) - FP(1)
         IF (DFI.EQ.0.0) THEN
            NPG   = 2
            XP(2) = TRIX(2)
            YP(2) = TRIY(2)
            IN0 = 2
            DX2 = TRIX(3) - TRIX(2)
            DY2 = TRIY(3) - TRIY(2)
            DFI = FP(3) - FP(2)
            IF (DFI.EQ.0.0) GO TO 290
         ENDIF
         DFI = 1.0/DFI
         DF1 = 1.0/(F03 - F01)
  260      CONTINUE
         FD = NF*DF + FMIN
         IF (FD.LE.FMAX.AND.FD.LE.F03) THEN
            IF (IN0.EQ.1.AND.FD.GE.FP(2)) THEN
               NPG     = NPG + 1
               XP(NPG) = TRIX(2)
               YP(NPG) = TRIY(2)
               IN0 = 2
               DX2 = TRIX(3) - TRIX(2)
               DY2 = TRIY(3) - TRIY(2)
               DFI = FP(3) - FP(2)
               IF (DFI.EQ.0.0) GO TO 290
               DFI = 1.0/DFI
            ENDIF
            DI  = (FD - F01)*DF1
            DJ  = (FD - FP(IN0))*DFI
            XX0 = DX1*DI + TRIX(1)
            YY0 = DY1*DI + TRIY(1)
            XX1 = DX2*DJ + TRIX(IN0)
            YY1 = DY2*DJ + TRIY(IN0)
            NPG       = NPG + 2
            XP(NPG-1) = XX1
            YP(NPG-1) = YY1
            XP(NPG)   = XX0
            YP(NPG)   = YY0
            CALL FGWIOPOLYS(XP,YP,NPG)
            NF = NF + 1
            GO TO 260
         ENDIF
  290     CONTINUE
         IF (NPG.EQ.1.OR.IN0.EQ.1) THEN
            NPG   = NPG + 1
            XP(NPG) = TRIX(2)
            YP(NPG) = TRIY(2)
         ENDIF
         NPG   = NPG + 1
         XP(NPG) = TRIX(3)
         YP(NPG) = TRIY(3)
         CALL FGWIOPOLYS(XP,YP,NPG)

   10 IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOLITSQUARE(SQX,SQY,FP0,MCOL,XS,YS,ZS)
      REAL SQX(4),SQY(4),FP0(4),FP(3),XS(4),YS(4),ZS(4)
      REAL TRIX(3),TRIY(3)

      XV1 = XS(2)-XS(1)
      YV1 = YS(2)-YS(1)
      ZV1 = ZS(2)-ZS(1)
      XV2 = XS(4)-XS(1)
      YV2 = YS(4)-YS(1)
      ZV2 = ZS(4)-ZS(1)

      XX  = YV1*ZV2-ZV1*YV2
      YY  = ZV1*XV2-XV1*ZV2
      ZZ  = XV1*YV2-YV1*XV2
      RR  = XX*XX+YY*YY+ZZ*ZZ
      IF (RR.NE.0) THEN
         CS = ZZ/SQRT(RR)
       ELSE
         CS = 0
      ENDIF
      CS = (((1-CS)/2)**1)*0.65+0.05

      TRIX(1) = SQX(1)
      TRIX(2) = SQX(2)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(1)
      TRIY(2) = SQY(2)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(1)
      FP(2)   = FP0(2)
      FP(3)   = FP0(4)
      CALL FGWIOLITTRIANGLE(TRIX,TRIY,FP,-1,CS)

      XV1 = XS(4)-XS(3)
      YV1 = YS(4)-YS(3)
      ZV1 = ZS(4)-ZS(3)
      XV2 = XS(2)-XS(3)
      YV2 = YS(2)-YS(3)
      ZV2 = ZS(2)-ZS(3)

      XX  = YV1*ZV2-ZV1*YV2
      YY  = ZV1*XV2-XV1*ZV2
      ZZ  = XV1*YV2-YV1*XV2
      RR  = XX*XX+YY*YY+ZZ*ZZ
      IF (RR.NE.0) THEN
         CS = ZZ/SQRT(RR)
       ELSE
         CS = 0
      ENDIF
      CS = (((1-CS)/2)**1)*0.65+0.05

      TRIX(1) = SQX(2)
      TRIX(2) = SQX(3)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(2)
      TRIY(2) = SQY(3)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(2)
      FP(2)   = FP0(3)
      FP(3)   = FP0(4)
      CALL FGWIOLITTRIANGLE(TRIX,TRIY,FP,-1,CS)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOLITTRIANGLE(TRIX,TRIY,FP,MCOL,CS)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL TRIX(3),TRIY(3),FP(3),XP(5),YP(5)

         DO 220 L = 1, 2
            DO 221 L1 = L+1, 3
               IF (FP(L).GT.FP(L1)) THEN
                  TT       = TRIX(L)
                  TRIX(L)  = TRIX(L1)
                  TRIX(L1) = TT
                  TT       = TRIY(L)
                  TRIY(L)  = TRIY(L1)
                  TRIY(L1) = TT
                  FF       = FP(L)
                  FP(L)    = FP(L1)
                  FP(L1)   = FF
               ENDIF
  221      CONTINUE
  220      CONTINUE

         F01 = FP(1)
         F03 = FP(3)
         NF  = INT((F01 - FMIN)/DF) - 1
         NPG   = 1
         XP(1) = TRIX(1)
         YP(1) = TRIY(1)

  250    FD = NF*DF + FMIN
         IF (FD.LT.F01) THEN
            NF = NF + 1
            GO TO 250
         ENDIF
         IN0 = 1
         DX1 = TRIX(3) - TRIX(1)
         DY1 = TRIY(3) - TRIY(1)
         DX2 = TRIX(2) - TRIX(1)
         DY2 = TRIY(2) - TRIY(1)
         DFI = FP(2) - FP(1)
         IF (DFI.EQ.0.0) THEN
            NPG   = 2
            XP(2) = TRIX(2)
            YP(2) = TRIY(2)
            IN0 = 2
            DX2 = TRIX(3) - TRIX(2)
            DY2 = TRIY(3) - TRIY(2)
            DFI = FP(3) - FP(2)
            IF (DFI.EQ.0.0) GO TO 290
         ENDIF
         DFI = 1.0/DFI
         DF1 = 1.0/(F03 - F01)
  260      CONTINUE
         FD = NF*DF + FMIN
         IF (FD.LE.FMAX.AND.FD.LE.F03) THEN
            IF (IN0.EQ.1.AND.FD.GE.FP(2)) THEN
               NPG     = NPG + 1
               XP(NPG) = TRIX(2)
               YP(NPG) = TRIY(2)
               IN0 = 2
               DX2 = TRIX(3) - TRIX(2)
               DY2 = TRIY(3) - TRIY(2)
               DFI = FP(3) - FP(2)
               IF (DFI.EQ.0.0) GO TO 290
               DFI = 1.0/DFI
            ENDIF
            DI  = (FD - F01)*DF1
            DJ  = (FD - FP(IN0))*DFI
            XX0 = DX1*DI + TRIX(1)
            YY0 = DY1*DI + TRIY(1)
            XX1 = DX2*DJ + TRIX(IN0)
            YY1 = DY2*DJ + TRIY(IN0)
            NPG       = NPG + 2
            XP(NPG-1) = XX1
            YP(NPG-1) = YY1
            XP(NPG)   = XX0
            YP(NPG)   = YY0
            CALL FGWIOLITPOLY(XP,YP,NPG,CS)
            NF = NF + 1
            GO TO 260
         ENDIF
  290     CONTINUE
         IF (NPG.EQ.1.OR.IN0.EQ.1) THEN
            NPG   = NPG + 1
            XP(NPG) = TRIX(2)
            YP(NPG) = TRIY(2)
         ENDIF
         NPG   = NPG + 1
         XP(NPG) = TRIX(3)
         YP(NPG) = TRIY(3)
         CALL FGWIOLITPOLY(XP,YP,NPG,CS)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE FGWIOPSET(XP,YP,FP)
      IMPLICIT INTEGER (A-Z)
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      REAL XP,YP,FP,F0,FMIN,FMAX,FBASE,FBASE1,DF,CFX,CFY,DNF,RNF

      IF (IFBASE.LT.0) THEN
         IF (FP.GE.FBASE.AND.FP.LE.FBASE1) RETURN
      ENDIF

      RNF = (FP - FMIN)/DF
      NF  = RNF + 0.5
      IC1 = NF*DNF
      IF (ICMAX.LT.0.OR.IC1.NE.ICMAX) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPSET(XP,YP)
       ELSE IF (IRNF.NE.0.AND.IC1.EQ.ICMAX.AND.RNF.NE.0) THEN
         CALL GWIOCOLOR(256,IC1)
         CALL GWIOPSET(XP,YP)
      ENDIF

      RETURN
      END

      SUBROUTINE SETSURFACECOLNUM(N)
      PARAMETER (LTCOLMAX0=118,ICMAPMIN=16)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX

      IF (N.LT.0) THEN
         LTCOLMAX  = LTCOLMAX0
*         LTCOLBASE = 0
         LCSBASE   = 0
       ELSE
         LTCOLMAX  = N
*         LTCOLBASE = ICMAPMIN
         LCSBASE   = 0
      ENDIF

      RETURN
      END

      SUBROUTINE LGWIOPOLYGON(TX,TY,N,CS,RS,MCOL)
*      PARAMETER (LTCOLMAX=118)
      REAL TX(*),TY(*),CS,RS,CS1,KDIF,KSPC
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH

*      CS1 = (1+CS)/2
*      CS1 = CS1*CS1

* IF YOU LIKE A REALITY, REMOVE COMMENTS THE FOLLOWING LINES.
      KDIF = CDIF*(CS+1)/2
*      IF (CS.LT.0) KDIF = 0
      IF (RS.LT.0) THEN
         KSPC = 0
       ELSE
         KSPC = CSPC*RS**NSPORDER
      ENDIF
      CS1 = CAMB + KDIF + KSPC
* UP TO HERE.

      IF (CS1.GT.1) CS1 = 1
      ICS = CS1*LTCOLMAX + LCSBASE
      CALL GWIOCOLOR(256,ICS)
      CALL GWIOPOLYGON(TX,TY,N,2)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TX,TY,N,1)
      ENDIF

      RETURN
      END

      SUBROUTINE SGWIOPOLYGON(TX,TY,N,IC,MCOL)
      REAL TX(*),TY(*)

      CALL GWIOCOLOR(2,IC)
      CALL GWIOPOLYGON(TX,TY,N,2)
      CALL GWIOCOLOR(2,MCOL)
      CALL GWIOPOLYGON(TX,TY,N,1)

      RETURN
      END

      SUBROUTINE LGWIOTRIANGLE(TRIX,TRIY,CS,RS,MCOL)
*      PARAMETER (LTCOLMAX=118)
      REAL CS1,KDIF,KSPC
      REAL TRIX(3),TRIY(3),CS(3),RS(3),FP(3)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH

      DO 10 I = 1, 3
*         CS1 = (1+CS(I))/2
*         CS1 = CS1*CS1

* IF YOU LIKE A REALITY, REMOVE COMMENTS THE FOLLOWING LINES.
         KDIF = CDIF*(CS(I)+1)/2
*         IF (CS(I).LT.0) KDIF = 0
         IF (RS(I).LT.0) THEN
            KSPC = 0
          ELSE
            KSPC = CSPC*RS(I)**NSPORDER
         ENDIF
         CS1 = CAMB + KDIF + KSPC
* UP TO HERE.

         IF (CS1.GT.1) CS1 = 1
         FP(I) = CS1*LTCOLMAX
   10  CONTINUE

      CALL LGWIOLTRIANGLE(TRIX,TRIY,FP)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(TRIX,TRIY,3,1)
      ENDIF

      RETURN
      END

      SUBROUTINE LGWIOSQUARE(SQX,SQY,FP0,MCOL)
*      PARAMETER (LTCOLMAX=118)
      REAL SQX(4),SQY(4),FP0(4)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      REAL TRIX(3),TRIY(3),FP(3)

      DO 10 I = 1, 4
         IF (FP0(I).GT.1) FP0(I) = 1
         FP0(I) = FP0(I)*LTCOLMAX
   10  CONTINUE

      TRIX(1) = SQX(1)
      TRIX(2) = SQX(2)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(1)
      TRIY(2) = SQY(2)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(1)
      FP(2)   = FP0(2)
      FP(3)   = FP0(4)
      CALL LGWIOLTRIANGLE(TRIX,TRIY,FP)

      TRIX(1) = SQX(2)
      TRIX(2) = SQX(3)
      TRIX(3) = SQX(4)
      TRIY(1) = SQY(2)
      TRIY(2) = SQY(3)
      TRIY(3) = SQY(4)
      FP(1)   = FP0(2)
      FP(2)   = FP0(3)
      FP(3)   = FP0(4)
      CALL LGWIOLTRIANGLE(TRIX,TRIY,FP)

      IF (MCOL.GE.0) THEN
         CALL GWIOCOLOR(2,MCOL)
         CALL GWIOPOLYGON(SQX,SQY,4,1)
      ENDIF

      RETURN
      END

      SUBROUTINE LGWIOLTRIANGLE(TRIX,TRIY,FP)
      REAL TRIX(3),TRIY(3),FP(3),XP(5),YP(5)

         DO 220 L = 1, 2
            DO 221 L1 = L+1, 3
               IF (FP(L).GT.FP(L1)) THEN
                  TT       = TRIX(L)
                  TRIX(L)  = TRIX(L1)
                  TRIX(L1) = TT
                  TT       = TRIY(L)
                  TRIY(L)  = TRIY(L1)
                  TRIY(L1) = TT
                  FF       = FP(L)
                  FP(L)    = FP(L1)
                  FP(L1)   = FF
               ENDIF
  221      CONTINUE
  220      CONTINUE

         F01 = FP(1)
         F03 = FP(3)
         NF  = INT(F01) - 1
         NPG   = 1
         XP(1) = TRIX(1)
         YP(1) = TRIY(1)

  250    FD = NF
         IF (FD.LT.F01) THEN
            NF = NF + 1
            GO TO 250
         ENDIF
         IN0 = 1
         DX1 = TRIX(3) - TRIX(1)
         DY1 = TRIY(3) - TRIY(1)
         DX2 = TRIX(2) - TRIX(1)
         DY2 = TRIY(2) - TRIY(1)
         DFI = FP(2) - FP(1)
         IF (DFI.EQ.0.0) THEN
            NPG   = 2
            XP(2) = TRIX(2)
            YP(2) = TRIY(2)
            IN0 = 2
            DX2 = TRIX(3) - TRIX(2)
            DY2 = TRIY(3) - TRIY(2)
            DFI = FP(3) - FP(2)
            IF (DFI.EQ.0.0) GO TO 290
         ENDIF
         DFI = 1.0/DFI
         DF1 = 1.0/(F03 - F01)
  260      CONTINUE
         FD = NF
         IF (FD.LE.F03) THEN
            IF (IN0.EQ.1.AND.FD.GE.FP(2)) THEN
               NPG     = NPG + 1
               XP(NPG) = TRIX(2)
               YP(NPG) = TRIY(2)
               IN0 = 2
               DX2 = TRIX(3) - TRIX(2)
               DY2 = TRIY(3) - TRIY(2)
               DFI = FP(3) - FP(2)
               IF (DFI.EQ.0.0) GO TO 290
               DFI = 1.0/DFI
            ENDIF
            DI  = (FD - F01)*DF1
            DJ  = (FD - FP(IN0))*DFI
            XX0 = DX1*DI + TRIX(1)
            YY0 = DY1*DI + TRIY(1)
            XX1 = DX2*DJ + TRIX(IN0)
            YY1 = DY2*DJ + TRIY(IN0)
            NPG       = NPG + 2
            XP(NPG-1) = XX1
            YP(NPG-1) = YY1
            XP(NPG)   = XX0
            YP(NPG)   = YY0
            CALL GWIOCOLOR(256,NF)
            CALL GWIOPOLYGON(XP,YP,NPG,3)
            XP(1) = XP(NPG)
            YP(1) = YP(NPG)
            XP(2) = XP(NPG-1)
            YP(2) = YP(NPG-1)
            NPG   = 2
            NF = NF + 1
            GO TO 260
         ENDIF
  290     CONTINUE
         IF (NPG.EQ.1.OR.IN0.EQ.1) THEN
            NPG   = NPG + 1
            XP(NPG) = TRIX(2)
            YP(NPG) = TRIY(2)
         ENDIF
         NPG   = NPG + 1
         XP(NPG) = TRIX(3)
         YP(NPG) = TRIY(3)
         CALL GWIOCOLOR(256,NF)
         CALL GWIOPOLYGON(XP,YP,NPG,3)

      RETURN
      END

      SUBROUTINE ISHLSLIGHTSET(ICOL,IMP)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      SAVE IUMAP

*      CALL GWIOMODECHECK(IGMODE)
*      IF (IGMODE.NE.0) RETURN

*     IMP < 0 IS FOR TPLOT ONLY
      IF (IMP.LT.0) THEN
         IC    = ICOL
         IF (IC.LT.1) IC = 1
         IF (IC.GT.7) IC = 7
*         ICSP = LTCOLBASE+IC
         ICSYSMAP  = IC
         CALL SURFACECOLORSET(IC)
         ICSYSMAP  = 0
         RETURN
      ENDIF

      IF (IMP.EQ.0) THEN
         ICSYSMAP  = 0
         CALL FR_HLSRECALL(IUMAP)
         ICOLMODE  = 0
         RETURN
      ENDIF

      IF (ICSYSMAP.EQ.0) IUMAP = ICUMAP
      IC    = ICOL
      IF (IC.LT.1) IC = 1
      IF (IC.GT.7) IC = 7
*      ICSP = LTCOLBASE+IC
      ICSYSMAP  = IC
      IF (ICMAP(IC).GE.0) THEN
         CALL FR_HLSRECALL(ICMAP(IC))
         RETURN
      ENDIF

      CALL SURFACECOLORSET(ICOL)

      ICMAP(IC) = IC

      RETURN
      END

      SUBROUTINE SURFACECOLORSET(ICOL)
*      PARAMETER (LTCOLMAX=118)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 SH(2),SL(2),SS(2)

      IC    = ICOL
      IF (IC.LT.1) IC = 1
      IF (IC.GT.7) IC = 7

      SL(1) = 0.1D0
      SL(2) = 0.65D0
*      SL(2) = 0.55D0
      GO TO (10,20,30,40,50,60,70),IC
   70 SH(1) = 0.D0
      SH(2) = SH(1)
      SL(2) = 1
      SS(1) = 0
      SS(2) = 0

      GO TO 998
   10 SH(1) = 240.D0
      SH(2) = 210.D0
*      SL(2) = 0.65D0
      GO TO 997
*   20 SH(1) = 0.D0
   20 SH(1) = 360.D0
      SH(2) = 335.D0
      GO TO 997
   30 SH(1) = 310.D0
      SH(2) = 290.D0
      GO TO 997
   40 SH(1) = 120.D0
      SH(2) =  90.D0
      GO TO 997
   50 SH(1) = 190.D0
      SH(2) = 160.D0
      GO TO 997
   60 SH(1) = 65.D0
      SH(2) = 55.D0

*  999 SH(2) = SH(1)

  997 SS(1) = 1
      SS(2) = 1
  998 NDIV  = LTCOLMAX
      IG    = IGPLT
      IGPLT = 0
      CALL FR_HLSSET(SH,SL,SS,NDIV,1)
      IGPLT = IG

      RETURN
      END

      SUBROUTINE LSHLSLIGHTMAP(ICOL,ICN,IMP)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      INTEGER ICOL(*),IC0(7),ICMSAVE(128),LCMNUM(128)
      SAVE IUMAP,ICMSAVE,LCMNUM

      IF (IMP.EQ.0) THEN
         ICSYSMAP  = 0
         CALL FR_HLSRECALL(IUMAP)
         ICOLMODE  = 0
         RETURN
      ENDIF

*      CALL GWIOMODECHECK(IGMODE)
*      IF (IGMODE.NE.0) RETURN
      DO 10 I = 1, 7
         IC0(I) = 0
   10 CONTINUE
      DO 11 I = 1, ICN
         IC = MOD(ICOL(I),100)
         IF (IC.LT.1) IC = 1
         IF (IC.GT.7) IC = 7
         IC0(IC) = 1
   11 CONTINUE
      ICM = 0
      ID0 = 0
      DO 12 I = 1, 7
         ICM = ICM*2 + IC0(I)
         IF (IC0(I).GT.0) THEN
            LCMAP(I) = ID0
            ID0 = ID0 + 1
          ELSE
            LCMAP(I) = 0
         ENDIF
   12 CONTINUE
      ICMNOW = 0
      DO 13 I = 1, ICMAPMAX-LTCOLBASE
         IF (ICM.EQ.ICMSAVE(I)) THEN
            IF (LTCOLMAX.EQ.LCMNUM(I)) THEN
               ICMNOW   = I
               GO TO 14
            ENDIF
         ENDIF
   13 CONTINUE
   14 CONTINUE

*     IMP < 0 IS FOR TPLOT ONLY
      IF (IMP.LT.0) THEN
         IF (ICMNOW.EQ.0) THEN
            ICMAPMAX = ICMAPMAX + 1
*            NO LIMIT IN TPLOT MODE
*            IF (ICMAPMAX.GT.50) ICMAPMAX = 50
            MAXICM   = ICMAPMAX - LTCOLBASE
            ICMSAVE(MAXICM) = ICM
            LCMNUM(MAXICM)  = LTCOLMAX
            ICMNOW   = MAXICM
         ENDIF
         ICSYSMAP  = LTCOLBASE+ICMNOW
         DO 20 I = 1, 7
            IF (IC0(I).NE.0) CALL MSURFACECOLORSET(I,0)
   20    CONTINUE
         CALL MSURFACECOLORSET(IC,1)
         ICSYSMAP  = 0
         RETURN
      ENDIF

      IF (ICMNOW.GT.0) THEN
         ICSYSMAP  = LTCOLBASE+ICMNOW
         CALL FR_HLSRECALL(ICMAP(ICSYSMAP))
         RETURN
      ENDIF

      ICMAPMAX = ICMAPMAX + 1
      IF (ICMAPMAX.GT.50) ICMAPMAX = 50
      MAXICM   = ICMAPMAX - LTCOLBASE
      ICMSAVE(MAXICM) = ICM
      LCMNUM(MAXICM)  = LTCOLMAX
      IF (ICSYSMAP.EQ.0) IUMAP = ICUMAP
      ICSYSMAP  = LTCOLBASE+MAXICM
      DO 30 I = 1, 7
         IF (IC0(I).NE.0) CALL MSURFACECOLORSET(I,0)
   30 CONTINUE
      CALL MSURFACECOLORSET(IC,1)
      ICMAP(ICSYSMAP) = ICSYSMAP

      RETURN
      END

      SUBROUTINE LSHLSLIGHTSET(ICOL)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX

      IC    = MOD(ICOL,100)
      IF (IC.LT.1) IC = 1
      IF (IC.GT.7) IC = 7
*      ICSYSMAP = LTCOLBASE+IC
      LCSBASE = LCMAP(IC)*LTCOLMAX

      RETURN
      END

      SUBROUTINE MSURFACECOLORSET(ICOL,MODE)
*      PARAMETER (LTCOLMAX=118)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 SH(14),SL(14),SS(14)
      INTEGER IM,NDIV(14)
      DATA IM/0/
      SAVE SH,SL,SS,NDIV,IM

      IF (MODE.NE.0) THEN
         IF (IM.EQ.0) THEN
            CALL FRAMESERROR('NO COLOR SET STORED FOR SURFACES')
            RETURN
         ENDIF
         IG    = IGPLT
         IGPLT = 0
         CALL FR_HLSSET(SH,SL,SS,NDIV,IM-1)
         IM = 0
         IGPLT = IG
         RETURN
      ENDIF

      IBASE1  = IM + 1
      IBASE2  = IBASE1 + 1
      NDIV(IBASE1) = LTCOLMAX
      NDIV(IBASE2) = 2
*      LCMAP(ICOL) = IM/2
      IM      = IM + 2

      SL(IBASE1) = 0.1D0
      SL(IBASE2) = 0.65D0
*      SL(IBASE2) = 0.55D0
      GO TO (10,20,30,40,50,60,70),ICOL
   70 SH(IBASE1) = 0.D0
      SH(IBASE2) = SH(IBASE1)
      SL(IBASE2) = 1
      SS(IBASE1) = 0
      SS(IBASE2) = 0

      GO TO 998
   10 SH(IBASE1) = 240.D0
      SH(IBASE2) = 210.D0
*      SL(IBASE2) = 0.65D0
      GO TO 997
*   20 SH(IBASE1) = 0.D0
   20 SH(IBASE1) = 360.D0
      SH(IBASE2) = 335.D0
      GO TO 997
   30 SH(IBASE1) = 310.D0
      SH(IBASE2) = 290.D0
      GO TO 997
   40 SH(IBASE1) = 120.D0
      SH(IBASE2) =  90.D0
      GO TO 997
   50 SH(IBASE1) = 190.D0
      SH(IBASE2) = 160.D0
      GO TO 997
   60 SH(IBASE1) = 65.D0
      SH(IBASE2) = 55.D0

*  999 SH(IBASE2) = SH(IBASE1)

  997 SS(IBASE1) = 1
      SS(IBASE2) = 1
  998 RETURN
      END

      SUBROUTINE HLSSPHERECOLORSET(ICOL,IMP)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      SAVE IUMAP

      IC    = ICOL
      IF (IC.LT.1) IC = 1
      IF (IC.GT.7) IC = 7
      ICSP = 8+IC
*      CALL GWIOMODECHECK(IGMODE)
*      IF (IGMODE.NE.0) RETURN

*     IMP < 0 IS FOR TPLOT ONLY
      IF (IMP.LT.0) THEN
         ICSYSMAP  = ICSP
         CALL SPHERECOLORSET(IC)
         ICSYSMAP  = 0
         RETURN
      ENDIF

      IF (IMP.EQ.0) THEN
         ICSYSMAP  = 0
         CALL FR_HLSRECALL(IUMAP)
         ICOLMODE  = 0
         RETURN
      ENDIF

      IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
      IF (ICSYSMAP.EQ.0) IUMAP = ICUMAP
      ICSYSMAP  = ICSP
      IF (ICMAP(ICSP).GE.0) THEN
         CALL FR_HLSRECALL(ICMAP(ICSP))
         RETURN
      ENDIF

      CALL SPHERECOLORSET(IC)

      ICMAP(ICSP) = ICSP

      RETURN
      END

      SUBROUTINE SPHERECOLORSET(IC)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 SH(2),SL(2),SS(2)

*      SL(1) = 0.1D0
*      SL(2) = 0.65D0
      SL(1) = 0.2D0
      SL(2) = 0.8D0
*      SL(2) = 0.55D0
      GO TO (10,20,30,40,50,60,70),IC
   70 SH(1) = 0.D0
      SH(2) = SH(1)
      SL(2) = 1
      SS(1) = 0
      SS(2) = 0

      GO TO 998
   10 SH(1) = 240.D0
      SH(2) = 210.D0
*      SL(2) = 0.65D0
      GO TO 997
*   20 SH(1) = 0.D0
   20 SH(1) = 360.D0
      SH(2) = 335.D0
      GO TO 997
   30 SH(1) = 310.D0
      SH(2) = 290.D0
      GO TO 997
   40 SH(1) = 120.D0
      SH(2) =  90.D0
      GO TO 997
   50 SH(1) = 190.D0
      SH(2) = 160.D0
      GO TO 997
   60 SH(1) = 65.D0
      SH(2) = 55.D0

*  999 SH(2) = SH(1)

  997 SS(1) = 1
      SS(2) = 1
  998 NDIV  = 35

      IG    = IGPLT
      IGPLT = 0
      CALL FR_HLSSET(SH,SL,SS,NDIV,1)
      IGPLT = IG

      RETURN
      END

      SUBROUTINE AXISDELFORM(ZMIN,ZMAX,DZ,FORM,NS,NSC,NS1,NMZ0,MODE)
      CHARACTER FORM*(*)
      CHARACTER CH*20

      ICH0 = ICHAR('0')

      WRITE(CH,'(1PE12.5)') MAX(ABS(ZMIN),ABS(ZMAX))
      READ(CH,'(9X,I3)') NMZ
      WRITE(CH,'(2PE8.1)') ABS(ZMAX-ZMIN)
      READ(CH,'(I3,2X,I3)') IZ,NM
      NSC = 1
      NS1 = 0
      IF (MODE.EQ.0) THEN
         IF (IZ.LT.14) THEN
            IZ  = 1
            NS  = 2
          ELSE IF (IZ.LT.35) THEN
            IZ  = 1
            NS  = 5
          ELSE IF (IZ.LT.70) THEN
            IZ  = 1
            NS  = 5
            NSC = 10
            NS1 = 1
*         ELSE IF (IZ.LT.90) THEN
*            IZ  = 5
*            NS  = 2
*            NS1 = 1
          ELSE IF (IZ.LT.90) THEN
            IZ  = 2
            NS  = 5
            NSC = 10
          ELSE
            IZ  = 10
            NS  = 2
         ENDIF
       ELSE
*         IF (IZ.LT.11) THEN
*            IZ  = 1
*            NS  = 2
*            NSC = 2
*          ELSE IF (IZ.LT.25) THEN
         IF (IZ.LT.20) THEN
            IZ  = 1
            NS  = 5
          ELSE IF (IZ.LT.40) THEN
            IZ  = 2
            NS  = 5
            NSC = 5
            NS1 = 1
          ELSE IF (IZ.LT.50) THEN
            IZ  = 5
            NS  = 2
            NSC = 2
*          ELSE IF (IZ.LT.65) THEN
*            IZ  = 5
*            NS  = 2
*            NSC = 4
          ELSE IF (IZ.LT.80) THEN
            IZ  = 5
            NS  = 2
            NSC = 4
          ELSE
            IZ  = 10
            NS  = 2
         ENDIF
      ENDIF

      IF (ABS(NMZ).GE.5) THEN
         NMZ0 = NMZ
         NM   = NM-NMZ
         NMZ  = 0
       ELSE
         NMZ0 = 0
      ENDIF

      WRITE(CH,'(I3,2H.E,I3)') IZ,NM
      READ(CH,'(E12.5)') DZ
      WRITE(CH,'(1PE12.5)') DZ*NS
      READ(CH,'(9X,I3)') NM
      IF (ABS(NMZ).GE.5) THEN
         FORM = '(1PE09.2)'
         IM = NMZ-NM
         IF (IM.GT.9) IM = 9
         IK = IM+8
         FORM(5:5) = CHAR(ICH0+IK/10)
         FORM(6:6) = CHAR(ICH0+MOD(IK,10))
         FORM(8:8) = CHAR(ICH0+IM)
       ELSE
         FORM = '(F04.0)'
         IF (NM.LE.0) THEN
            IF (NM.LT.-9) NM = -9
            IF (NMZ.LE.0) THEN
               IK = 4-NM
             ELSE
               IK = NMZ-NM+4
            ENDIF
            FORM(3:3) = CHAR(ICH0+IK/10)
            FORM(4:4) = CHAR(ICH0+MOD(IK,10))
            FORM(6:6) = CHAR(ICH0-NM)
          ELSE IF (MODE.EQ.0) THEN
            FORM(4:4) = CHAR(ICH0+NMZ+3)
          ELSE
            FORM(4:4) = CHAR(ICH0+NMZ+4)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE LOGARLABEL(ZMIN,ZMAX,DZ,NS,NS2,NMZ)
      CHARACTER CH*20

      ICH0 = ICHAR('0')

      WRITE(CH,'(1PE12.5)') MAX(ABS(ZMIN),ABS(ZMAX))
      READ(CH,'(9X,I3)') NMZ
      WRITE(CH,'(2PE8.1)') ABS(ZMAX-ZMIN)
      READ(CH,'(I3,2X,I3)') IZ,NM
      IF (NM.LT.0) THEN
         IF (IZ.LT.35) THEN
            IZ  = 10
            NS  = 1
            NS2 = 1
          ELSE IF (IZ.LT.70) THEN
            IZ  = 10
            NS  = 1
            NS2 = 2
          ELSE 
            IZ  = 10
            NS  = 1
            NS2 = 5
         ENDIF
       ELSE
         IF (IZ.LT.14) THEN
            IZ = 1
            NS = 2
          ELSE IF (IZ.LT.35) THEN
            IZ = 1
            NS = 5
          ELSE IF (IZ.LT.70) THEN
            IZ = 5
            NS = 2
          ELSE 
            IZ = 10
            NS = 2
         ENDIF
         NS2 = 0
      ENDIF
      WRITE(CH,'(I3,2H.E,I3)') IZ,NM
      READ(CH,'(E12.5)') DZ
      NMZ = NMZ + 1
      IF (ZMIN.LE.-1.0) NMZ = NMZ + 1

      RETURN
      END

      SUBROUTINE FR_HLSSET(SH,SL,SS,NDIV,MODE)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 SH(*),SL(*),SS(*)
      INTEGER NDIV(*)
*     N256MAP        NUMBER OF COLORMAP
*     ICUMAP         CURRENT VIRTUAL COLORMAP
*                    =0  MEANS DEFAULT COLORMAP
*     ICOL256        CONTROL SWITCH FOR PLT FILES (LIBRARY MODE)
*                    =0  NOT STORED IN PLT FILE
*     ICSYSMAP       SYSTEM DEFINE COLOR
*                    =0  USER DEFINED COLOR MAP

      IF (IGCANVAS.LT.0) RETURN

*     ICOL256 < 0 IS FOR TPLOT ONLY
      IF (ICOL256.LT.0) THEN
         MODE0   = MODE
         CALL GWIOCOLORSET(SH,SL,SS,NDIV,MODE0,0,ICSYSMAP)
         NCL256  = MODE0
         RETURN
      ENDIF

      IF (ICSYSMAP.EQ.0) THEN
         IF (IGPLT.GT.0) CALL GSENDBYTE(123,1)
         IF (MODE.LT.0.OR.(MODE.EQ.0.AND.NDIV(1).LE.0)) THEN
*           SET DEFAULT COLORMAP
            IF (IGPLT.GT.0) CALL GSENDBYTE(-1,1)
            ICUMAP  = 0
          ELSE
            IF (IGPLT.GT.0) CALL GSENDHLSDATA(SH,SL,SS,NDIV,MODE)
            N256MAP = N256MAP + 1
            ICUMAP  = N256MAP
         ENDIF
       ELSE
         ICUMAP = ICSYSMAP
      ENDIF

*      print *,'cmap = ',ICUMAP,ICSYSMAP

      IC0     = -ICUMAP
      MODE0   = MODE
      CALL GWIOCOLORSET(SH,SL,SS,NDIV,MODE0,IC0,-ICSYSMAP)
      NCL256  = MODE0
      ICOL256 = 0

      RETURN
      END

      SUBROUTINE STORECURRENTCOLMAP
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER ONECMAPP
      PARAMETER (ONECMAPP=100)
*     ICOL256        CONTROL SWITCH FOR PLT FILES (LIBRARY MODE)
*                    =1  TO BE STORED IN PLT FILE IF USED

*      IF (IGCANVAS.LT.0) RETURN  //Should be already checked
*      IF (ICOL256.GT.0) RETURN   //This routine only run on ICOL256==0

      ICOL256 = 1
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(123,1)
         MODE = -999
         CALL GSENDHLSDATA(SH,SL,SS,NDIV,MODE)
         IF (ICUMAP.LE.ONECMAPP) THEN
            CALL GSENDBYTE(-(ICUMAP+2),1)
          ELSE
            CALL GSENDBYTE(-(ONECMAPP+5),1)
            CALL GSENDBYTE(ICUMAP,2)
         ENDIF
         IF (IGCANVAS.EQ.0) RETURN
      ENDIF

      RETURN
      END

      SUBROUTINE FR_HLSRECALL(IMAP)
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX
      REAL*8 SS

      IF (IMAP.LE.N256MAP.OR.ICSYSMAP.GT.0) THEN
         ICOL256 = 0
         ICUMAP  = IMAP
         NDIV    = 0
         MODE    = 0
         CALL GWIOCOLORSET(SS,SS,SS,NDIV,MODE,ICUMAP,ICSYSMAP)
         NCL256 = MODE
      ENDIF

      RETURN
      END

      SUBROUTINE FR_HLSQUERY(IMAP)
      COMMON /COLORMODCOM/ N256MAP,ICUMAP,ICSYSMAP,ICMAP(50),ICMAPMAX
     ,                    ,LCMAP(7),LTCOLBASE,LCSBASE,LTCOLMAX

      IMAP = ICUMAP

      RETURN
      END

      SUBROUTINE FR_RGB2HLS(SR,SG,SB,SH,SL,SS)
*     SR,SG,SB  ->  SH,SL,SS
*     DATA ARE GIVEN BY REAL NUMBER 0-1
*     SH = 0-360, SL,SS = 0-1
      REAL*8 SR,SG,SB,SH,SL,SS
      REAL*8 CR,CG,CB,CMAX,CMIN

      CMAX = MAX(SR,SG,SB)
      CMIN = MIN(SR,SG,SB)
      SL = (CMAX+CMIN)/2
      IF (CMAX == CMIN) THEN
         SS = 0
         SH = 0
       ELSE
         IF (SL <= 0.5D0) THEN
            SS = (CMAX-CMIN)/(CMAX+CMIN)
          ELSE
            SS = (CMAX-CMIN)/(2-CMAX-CMIN)
         ENDIF
         CR = (CMAX-SR)/(CMAX-CMIN)
         CG = (CMAX-SG)/(CMAX-CMIN)
         CB = (CMAX-SB)/(CMAX-CMIN)
         IF (SR == CMAX) THEN
            SH = CB-CG
         ELSE IF (SG == CMAX) THEN
            SH = 2+CR-CB
          ELSE
            SH = 4+CG-CR
         ENDIF
         SH = 60*SH
         IF (SH < 0) SH = SH + 360
      ENDIF

      RETURN
      END

      SUBROUTINE COORDINXYZ(X,Y,Z,XP,YP)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8 X,Y,Z

      XP1 = XPX*X + XPY*Y + XPZ*Z + XP0
      YP1 = YPX*X + YPY*Y + YPZ*Z + YP0
      IF (MDPROJ.NE.0) THEN
         ZP  = ZPX*X + ZPY*Y + ZPZ*Z + ZP0
         XP1 = XP1/(1.0-ZP)
         YP1 = YP1/(1.0-ZP)
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END

      SUBROUTINE COORDINDXYZ(X,Y,Z,DX,DY,DZ,XP,YP,DXP,DYP)
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8 X,Y,Z,DX,DY,DZ

      XP1 = XPX*X + XPY*Y + XPZ*Z + XP0
      YP1 = YPX*X + YPY*Y + YPZ*Z + YP0
      DXP = XPX*DX + XPY*DY + XPZ*DZ
      DYP = YPX*DX + YPY*DY + YPZ*DZ
      IF (MDPROJ.NE.0) THEN
         ZP1 = ZPX*X + ZPY*Y + ZPZ*Z + ZP0
*         XP2 = XP1 + DXP
*         YP2 = YP1 + DYP
         XP1 = XP1/(1.0-ZP1)
         YP1 = YP1/(1.0-ZP1)
*         ZP2 = ZPX*(X+DX) + ZPY*(Y+DY) + ZPZ*(Z+DZ) + ZP0
*         DXP = XP2/(1.0-ZP2) - XP1
*         DYP = YP2/(1.0-ZP2) - YP1
         DXP =  ((XPX+XP1*ZPX)*DX + (XPY+XP1*ZPY)*DY
     +                            + (XPZ+XP1*ZPZ)*DZ)/(1.0-ZP1)
         DYP =  ((YPX+YP1*ZPX)*DX + (YPY+YP1*ZPY)*DY
     +                            + (YPZ+YP1*ZPZ)*DZ)/(1.0-ZP1)
       ELSE
         DXP = XPX*DX + XPY*DY + XPZ*DZ
         DYP = YPX*DX + YPY*DY + YPZ*DZ
      ENDIF
      XP = XP1 + XPMID
      YP = YP1 + YPMID

      RETURN
      END
