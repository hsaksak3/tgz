************************************
*       F  R  A  M  E  S  V.7.3    *
*     SURFACE RENDERING ROUTINES   *
*           FOR XYZ DATA           *
*      PROGRAMMED BY T.TAGUCHI     *
*         SEPTEMBER/17/2012        *
************************************

*      GIVEN DIMENSION IS X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)

*      BYPASS ROUTINE TO NEW VERSION
      SUBROUTINE FR_PROFILE3D(X,Y,Z,IMAX,JMAX,ICOL,MODE,WS)
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)
      INTEGER WS(*)

      CALL FR_SURFACE(X,Y,Z,IMAX,JMAX,ICOL,MODE)

      RETURN
      END

      SUBROUTINE FR_SURFACE(X,Y,Z,IMAX,JMAX,ICOL,MODE)
      PARAMETER (NDBMODE=8,NDIV=16)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      COMMON /PROF3DNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)
      REAL*8  X1,X2,Y1,Y2,Z1,Z2
      INTEGER DI,DJ
      SAVE /PROF3DCOM/,/PROF3DNIK/,/PROF3DPARM/,/PROF3DREG/,NPR
      DATA NPR/0/

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('3D SURFACE PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN
         NX2 = NXDMAX
         IF (NX1.GE.IMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - SURFACE')
            RETURN
         ENDIF
         IF (NX2.GT.IMAX) NX2 = IMAX
       ELSE
         NX1 = 1
         NX2 = IMAX
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN
         NY2 = NYDMAX
         IF (NY1.GE.JMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - SURFACE')
            RETURN
         ENDIF
         IF (NY2.GT.JMAX) NY2 = JMAX
       ELSE
         NY1 = 1
         NY2 = JMAX
      ENDIF

      IND = MOD(MODE,100)
      M1  = ABS(MODE/100)

      IF (M1.EQ.0) THEN
       ELSE IF (M1.EQ.1) THEN
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIU,DJU)
       ELSE IF (M1.EQ.2) THEN
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIU,DJU)
       ELSE IF (M1.EQ.4) THEN
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIU,DJU)
       ELSE IF (M1.EQ.5) THEN
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIU,DJU)
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIV,DJV)
       ELSE IF (M1.EQ.6) THEN
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIU,DJU)
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIV,DJV)
       ELSE
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIU,DJU)
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIV,DJV)
      ENDIF

      IF (IFRAM.EQ.0) THEN
         IF (M1.EQ.0) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.1) THEN
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.2) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.4) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.5) THEN
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.6) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
               ENDDO
            ENDDO
          ELSE
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
         ENDIF
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         IF (MODE3D.EQ.0) THEN
            CALL FR_PMFRAME(X1,X2,Z1,Z2,Y1,Y2,IDFR)
          ELSE
            CALL FR_FRAME3D(X1,X2,Y1,Y2,Z1,Z2,IDFR)
         ENDIF
      ENDIF

      ICOLMODE = 0
      NBCOL    = -1
      NSMODE   = IND/10
      IC       = MOD(ICOL,100)
      IF (ICOL.LT.0.AND.IND.NE.0) THEN
*         IF (IND.EQ.7) NBCOL  = -ICOL/100
         NBCOL  = -ICOL/100
         NSFINE = -MOD(ICOL/10,10)
         IC     = MOD(ICOL,10)
         IF (IC.EQ.-3) THEN
            NSMODE = 2000 + NSFINE
          ELSE IF (IC.EQ.-4) THEN
*            NSMODE = 2001
            NSMODE = 3000 + NSFINE
          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 4000 + NSFINE
          ELSE
            NSMODE = 1000
         ENDIF
         IF (MOD3DIR.EQ.1) THEN
            IF (MOD(M1,2).EQ.0) THEN
*               FM1 = X(NX1,NY1)
               FM1 = X(1,1)
               FM2 = FM1
*               DO J = NY1, NY2
*                  DO I = NX1, NX2
               DO J = 1, JMAX
                  DO I = 1, IMAX
                     IF (FM1.GT.X(I,J)) FM1 = X(I,J)
                     IF (FM2.LT.X(I,J)) FM2 = X(I,J)
                  ENDDO
               ENDDO
             ELSE
               FM1 = X1
               FM2 = X2
            ENDIF
          ELSE IF (MOD3DIR.EQ.2) THEN
            IF (M1.EQ.0.OR.M1.EQ.1.OR.M1.EQ.4.OR.M1.EQ.5) THEN
*               FM1 = Y(NX1,NY1)
               FM1 = Y(1,1)
               FM2 = FM1
*               DO J = NY1, NY2
*                  DO I = NX1, NX2
               DO J = 1, JMAX
                  DO I = 1, IMAX
                     IF (FM1.GT.Y(I,J)) FM1 = Y(I,J)
                     IF (FM2.LT.Y(I,J)) FM2 = Y(I,J)
                  ENDDO
               ENDDO
             ELSE
               FM1 = Y1
               FM2 = Y2
            ENDIF
          ELSE
            IF (M1.LE.3) THEN
*               FM1 = Z(NX1,NY1)
               FM1 = Z(1,1)
               FM2 = FM1
*               DO J = NY1, NY2
*                  DO I = NX1, NX2
               DO J = 1, JMAX
                  DO I = 1, IMAX
                     IF (FM1.GT.Z(I,J)) FM1 = Z(I,J)
                     IF (FM2.LT.Z(I,J)) FM2 = Z(I,J)
                  ENDDO
               ENDDO
             ELSE
               FM1 = Z1
               FM2 = Z2
            ENDIF
         ENDIF
*       ELSE IF (IND.EQ.10) THEN
       ELSE IF (IND.LT.0) THEN
            NSMODE = -1
       ELSE IF (IND.LE.4) THEN
         IF (ICOL/100.GT.0) THEN
            NBCOL  = IC
            IC     = ICOL/100
            NSMODE = 100
          ELSE
            NSMODE = -1
        ENDIF
       ELSE IF (IND.EQ.5) THEN
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.6) THEN
         NSMODE = 10
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.7) THEN
         NSMODE = 10
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.NDBMODE) THEN
         NSMODE = 30
      ENDIF
      IF (NBCOL.EQ.0) NBCOL = -1

      IF (NSMODE.LT.0) THEN
         CALL GWIOCOLOR(2,IC)
       ELSE IF (ICOL256.GE.0) THEN
         IF (IC.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 1
          ELSE IF (IND.NE.0) THEN
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (IC.GE.0) THEN
         CALL ISHLSLIGHTSET(IC,-1)
      ENDIF

      IF (IGPLT.GT.0) THEN
         IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
            CALL FR_SETCONTOUR(0.D0,0.D0,-1)
          ELSE IF (NSMODE.GE.0) THEN
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(52,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         IF (M1.EQ.0) THEN
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,1)
          ELSE IF (M1.EQ.1) THEN
            CALL GSEND8BYTE(X,Y,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,5)
          ELSE IF (M1.EQ.2) THEN
            CALL GSEND8BYTE(Y,Z,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,6)
          ELSE IF (M1.EQ.4) THEN
            CALL GSEND8BYTE(Z,X,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,7)
          ELSE IF (M1.EQ.5) THEN
            CALL GSEND8BYTE(X,Z,3,2)
            CALL GSEND8BYTE(X,Y,IMAX*JMAX,6)
          ELSE IF (M1.EQ.6) THEN
            CALL GSEND8BYTE(Y,Z,3,2)
            CALL GSEND8BYTE(X,Y,IMAX*JMAX,5)
          ELSE
            CALL GSEND8BYTE(X,Y,3,2)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,0)
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(0)

      IF (IND.GE.3.OR.IND.LT.0) GO TO 1

*     NORMAL HIDDEN LINE 

      ID   = IND
      IF (ID.NE.0) CALL FR_HCLEAR(IND+10000)

      IF (MODE3D.NE.0) GO TO 10000

      PX    = XTAN*X(NX1,NY1) + ZXTAN*Y(NX1,NY1) + ZX0
      PY    = YTAN*Z(NX1,NY1) + ZYTAN*Y(NX1,NY1) + ZY0
      PXMAX = PX
      PXMIN = PX
      DO I = NX1+1, NX2
          PX1 = XTAN*X(I,NY1) + ZXTAN*Y(I,NY1) + ZX0
          PY1 = YTAN*Z(I,NY1) + ZYTAN*Y(I,NY1) + ZY0
          IF (ID.EQ.0) THEN
              CALL GWIOLINE(PX,PY,PX1,PY1,0)
            ELSE   
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
           ENDIF
          PX  = PX1
          PY  = PY1
        ENDDO

      DO J = NY1+1, NY2
          PX1 = XTAN*X(NX2,J) + ZXTAN*Y(NX2,J) + ZX0
          PY1 = YTAN*Z(NX2,J) + ZYTAN*Y(NX2,J) + ZY0
          IF (ID.EQ.0) THEN
              CALL GWIOLINE(PX,PY,PX1,PY1,0)
            ELSE   
              CALL HGWIOLINE(PX,PY,PX1,PY1)
              IF (PX.GT.PXMAX) PXMAX = PX
              IF (PX.LT.PXMIN) PXMIN = PX
           ENDIF
          PX  = PX1
          PY  = PY1
        ENDDO

      IF (ID.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)

      DO J = NY1+1, NY2
          PX    = XTAN*X(NX2,J) + ZXTAN*Y(NX2,J) + ZX0
          PY    = YTAN*Z(NX2,J) + ZYTAN*Y(NX2,J) + ZY0
          PXMAX = PX
          PXMIN = PX
          DO I = NX2-1, NX1, -1
              PX1 = XTAN*X(I,J) + ZXTAN*Y(I,J) + ZX0
              PY1 = YTAN*Z(I,J) + ZYTAN*Y(I,J) + ZY0
              PX2 = XTAN*X(I,J-1) + ZXTAN*Y(I,J-1) + ZX0
              PY2 = YTAN*Z(I,J-1) + ZYTAN*Y(I,J-1) + ZY0
              IF (ID.EQ.0) THEN
                  CALL GWIOLINE(PX,PY,PX1,PY1,0)
                  CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
                ELSE   
                  CALL HGWIOLINE(PX,PY,PX1,PY1)
                  CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                  IF (PX.GT.PXMAX) PXMAX = PX
                  IF (PX.LT.PXMIN) PXMIN = PX
                  IF (PX2.GT.PXMAX) PXMAX = PX2
                  IF (PX2.LT.PXMIN) PXMIN = PX2
               ENDIF
              PX = PX1
              PY = PY1
            ENDDO
          IF (ID.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
        ENDDO

      GO TO 990

10000    CONTINUE

      IF (PHI.LE.-90.0) THEN
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.-135.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE IF (PHI.LT.0.0) THEN
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY1
         J2 = NY2
         DJ = 1
         IF (PHI.LT.-45.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
       ELSE IF (PHI.LT.90.0) THEN
         I1 = NX2
         I2 = NX1
         DI = -1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.45.0) THEN
            IJ = 2
          ELSE
            IJ = 1
         ENDIF
       ELSE
         I1 = NX1
         I2 = NX2
         DI = 1
         J1 = NY2
         J2 = NY1
         DJ = -1
         IF (PHI.LT.135.0) THEN
            IJ = 1
          ELSE
            IJ = 2
         ENDIF
      ENDIF

      CALL COORDINXYZ(X(I2,J1),Y(I2,J1),Z(I2,J1),PX,PY)
      PXMAX = PX
      PXMIN = PX
      DO I = I2-DI, I1, -DI
         CALL COORDINXYZ(X(I,J1),Y(I,J1),Z(I,J1),PX1,PY1)
         IF (ID.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO

      DO J = J1+DJ, J2, DJ
         CALL COORDINXYZ(X(I1,J),Y(I1,J),Z(I1,J),PX1,PY1)
         IF (ID.EQ.0) THEN
            CALL GWIOLINE(PX,PY,PX1,PY1,0)
          ELSE
            CALL HGWIOLINE(PX,PY,PX1,PY1)
            IF (PX1.GT.PXMAX) PXMAX = PX1
            IF (PX1.LT.PXMIN) PXMIN = PX1
         ENDIF
         PX  = PX1
         PY  = PY1
      ENDDO

      IF (ID.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)

      IF (IJ.EQ.1) THEN
         DO J = J1+DJ, J2, DJ
            CALL COORDINXYZ(X(I1,J),Y(I1,J),Z(I1,J),PX,PY)
            PXMIN = PX
            PXMAX = PY
            DO I = I1+DI, I2, DI
               CALL COORDINXYZ(X(I,J),Y(I,J),Z(I,J),PX1,PY1)
               CALL COORDINXYZ(X(I,J-DJ),Y(I,J-DJ),Z(I,J-DJ),PX2,PY2)
               IF (ID.EQ.0) THEN
                  CALL GWIOLINE(PX,PY,PX1,PY1,0)
                  CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
                ELSE
                  CALL HGWIOLINE(PX,PY,PX1,PY1)
                  IF (PX1.GT.PXMAX) PXMAX = PX1
                  IF (PX1.LT.PXMIN) PXMIN = PX1
                  CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                  IF (PX2.GT.PXMAX) PXMAX = PX2
                  IF (PX2.LT.PXMIN) PXMIN = PX2
               ENDIF
               PX = PX1
               PY = PY1
            ENDDO
            IF (ID.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
         ENDDO
       ELSE
         DO I = I1+DI, I2, DI
            CALL COORDINXYZ(X(I,J1),Y(I,J1),Z(I,J1),PX,PY)
            PXMIN = PX
            PXMAX = PY
            DO J = J1+DJ, J2, DJ
               CALL COORDINXYZ(X(I,J),Y(I,J),Z(I,J),PX1,PY1)
               CALL COORDINXYZ(X(I-DJ,J),Y(I-DJ,J),Z(I-DJ,J),PX2,PY2)
               IF (ID.EQ.0) THEN
                  CALL GWIOLINE(PX,PY,PX1,PY1,0)
                  CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
                ELSE
                  CALL HGWIOLINE(PX,PY,PX1,PY1)
                  IF (PX1.GT.PXMAX) PXMAX = PX1
                  IF (PX1.LT.PXMIN) PXMIN = PX1
                  CALL HGWIOLINE(PX1,PY1,PX2,PY2)
                  IF (PX2.GT.PXMAX) PXMAX = PX2
                  IF (PX2.LT.PXMIN) PXMIN = PX2
               ENDIF
               PX = PX1
               PY = PY1
            ENDDO
            IF (ID.NE.0) CALL SETHIDDEN(PXMIN,PXMAX)
         ENDDO
       ENDIF

      GO TO 990

    1    CONTINUE

*     HIGH TECHNIQUE HIDDEN LINE 

      IF (NPR.EQ.0) THEN
         NPROF = 1
       ELSE
         NPROF = NPROF+1
      ENDIF
      ICOLS(NPROF) = ICOL

      CALL MALLOCANDSURFACECORE(X,Y,Z,Z,IMAX,JMAX,NX1,NX2,NY1,NY2
     +                                             ,IC,M1,IND,NPR,IER)
      IF (IER.NE.0) THEN
         CALL FRAMESERROR('3D SURFACE PROGRAM IS SOMETHING WRONG !')
         GO TO 999
      ENDIF

  990  CONTINUE
      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      CALL GWIOBDFLUSH(1)
*  999 IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
  999 RETURN
      END

      SUBROUTINE FR_MAPSURFACE(X,Y,Z,F,IMAX,JMAX,ICOL,MODE)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX),F(IMAX,JMAX)
      REAL*8  X1,X2,Y1,Y2,Z1,Z2
      SAVE /PROF3DCOM/,/PROF3DNIK/,NPR
      DATA NPR/0/

      IF (IGCANVAS.LT.0) RETURN

      IF (IMAX.LE.1.OR.JMAX.LE.1) THEN
         CALL FRAMESERROR('3D SURFACE PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN
         NX2 = NXDMAX
         IF (NX1.GE.IMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - SURFACE')
            RETURN
         ENDIF
         IF (NX2.GT.IMAX) NX2 = IMAX
       ELSE
         NX1 = 1
         NX2 = IMAX
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN
         NY2 = NYDMAX
         IF (NY1.GE.JMAX) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - SURFACE')
            RETURN
         ENDIF
         IF (NY2.GT.JMAX) NY2 = JMAX
       ELSE
         NY1 = 1
         NY2 = JMAX
      ENDIF

      IND = MOD(MODE,100)
      M1  = ABS(MODE/100)
      M1  = 0

      IF (M1.EQ.0) THEN
       ELSE IF (M1.EQ.1) THEN
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIU,DJU)
       ELSE IF (M1.EQ.2) THEN
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIU,DJU)
       ELSE IF (M1.EQ.4) THEN
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIU,DJU)
       ELSE IF (M1.EQ.5) THEN
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIU,DJU)
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIV,DJV)
       ELSE IF (M1.EQ.6) THEN
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIU,DJU)
         CALL SETPROFDIDJ(Z,IMAX,JMAX,ZC,Z1,Z2,DIV,DJV)
       ELSE
         CALL SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DIU,DJU)
         CALL SETPROFDIDJ(Y,IMAX,JMAX,YC,Y1,Y2,DIV,DJV)
      ENDIF

      IF (IFRAM.EQ.0) THEN
         IF (M1.EQ.0) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.1) THEN
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.2) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.4) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.5) THEN
            Y1 = Y(NX1,NY1)
            Y2 = Y1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Y1.GT.Y(I,J)) Y1 = Y(I,J)
                  IF (Y2.LT.Y(I,J)) Y2 = Y(I,J)
               ENDDO
            ENDDO
          ELSE IF (M1.EQ.6) THEN
            X1 = X(NX1,NY1)
            X2 = X1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (X1.GT.X(I,J)) X1 = X(I,J)
                  IF (X2.LT.X(I,J)) X2 = X(I,J)
               ENDDO
            ENDDO
          ELSE
            Z1 = Z(NX1,NY1)
            Z2 = Z1
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IF (Z1.GT.Z(I,J)) Z1 = Z(I,J)
                  IF (Z2.LT.Z(I,J)) Z2 = Z(I,J)
               ENDDO
            ENDDO
         ENDIF
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         IF (MODE3D.EQ.0) THEN
            CALL FR_PMFRAME(X1,X2,Z1,Z2,Y1,Y2,IDFR)
          ELSE
            CALL FR_FRAME3D(X1,X2,Y1,Y2,Z1,Z2,IDFR)
         ENDIF
      ENDIF

      ICOLMODE = 0
      NBCOL    = -1
      NSMODE   = IND/10
      IC       = MOD(ICOL,100)
*      IF (ICOL.LT.0.AND.IND.NE.0) THEN
*         IF (IND.EQ.7) NBCOL  = -ICOL/100
         NBCOL  = -ICOL/100
         NSFINE = -MOD(ICOL/10,10)
         IC     = MOD(ICOL,10)
         IF (IC.EQ.-3) THEN
            NSMODE = 2000 + NSFINE
          ELSE IF (IC.EQ.-4) THEN
*            NSMODE = 2001
            NSMODE = 3000 + NSFINE
          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 4000 + NSFINE
          ELSE
            NSMODE = 1000
         ENDIF
*         FM1 = F(NX1,NY1)
         FM1 = F(1,1)
         FM2 = FM1
*         DO J = NY1, NY2
*            DO I = NX1, NX2
         DO J = 1, JMAX
            DO I = 1, IMAX
               IF (FM1.GT.F(I,J)) FM1 = F(I,J)
               IF (FM2.LT.F(I,J)) FM2 = F(I,J)
            ENDDO
         ENDDO
*      ENDIF
      IF (NBCOL.EQ.0) NBCOL = -1

      IF (NSMODE.LT.0) THEN
         CALL GWIOCOLOR(2,IC)
       ELSE IF (ICOL256.GE.0) THEN
         IF (IC.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 1
          ELSE IF (IND.NE.0) THEN
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (IC.GE.0) THEN
         CALL ISHLSLIGHTSET(IC,-1)
      ENDIF

      IF (IGPLT.GT.0) THEN
         IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
            CALL FR_SETCONTOUR(0.D0,0.D0,-1)
          ELSE IF (NSMODE.GE.0) THEN
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(52,1)
         CALL GSENDBYTE(10000+MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX,4)
         IF (M1.EQ.0) THEN
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,1)
          ELSE IF (M1.EQ.1) THEN
            CALL GSEND8BYTE(X,Y,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,5)
          ELSE IF (M1.EQ.2) THEN
            CALL GSEND8BYTE(Y,Z,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,6)
          ELSE IF (M1.EQ.4) THEN
            CALL GSEND8BYTE(Z,X,3,3)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,7)
          ELSE IF (M1.EQ.5) THEN
            CALL GSEND8BYTE(X,Z,3,2)
            CALL GSEND8BYTE(X,Y,IMAX*JMAX,6)
          ELSE IF (M1.EQ.6) THEN
            CALL GSEND8BYTE(Y,Z,3,2)
            CALL GSEND8BYTE(X,Y,IMAX*JMAX,5)
          ELSE
            CALL GSEND8BYTE(X,Y,3,2)
            CALL GSEND38BYTE(X,Y,Z,IMAX*JMAX,0)
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(0)

*     HIGH TECHNIQUE HIDDEN LINE 

      IF (NPR.EQ.0) THEN
         NPROF = 1
       ELSE
         NPROF = NPROF+1
      ENDIF
      ICOLS(NPROF) = ICOL

      M1  = 1000 + M1
      CALL MALLOCANDSURFACECORE(X,Y,Z,F,IMAX,JMAX,NX1,NX2,NY1,NY2
     +                                             ,IC,M1,IND,NPR,IER)
      IF (IER.NE.0) THEN
         CALL FRAMESERROR('3D SURFACE PROGRAM IS SOMETHING WRONG !')
         GO TO 999
      ENDIF

  990  CONTINUE
      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      CALL GWIOBDFLUSH(1)
*  999 IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
  999 NPR = 0
      RETURN
      END

      SUBROUTINE SURFACE3DMAIN(X,Y,Z,F,IMAX,JMAX,NX1,NX2,NY1,NY2
     +                                        ,IC,M1,IND,NPR,WS,TS,HS)
      PARAMETER (NDIV=16)
      REAL*8 PI
      PARAMETER (PI=3.141592653589793D0)
      REAL*8 X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX),F(IMAX,JMAX)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  X2,Y2,Z2
      REAL*4 WS(*),TS(*)
      INTEGER HS(*)

      NU(NPROF)    = NX2 - NX1 + 1
      NV(NPROF)    = NY2 - NY1 + 1
      NUNV(NPROF)  = NU(NPROF)*NV(NPROF)
      NR           = 0

      IW = NPR
      JW = IW + NUNV(NPROF)
      KW = JW + NUNV(NPROF)

      K0MAX0 = 0
      M0 = M1/1000
      M1 = MOD(M1,1000)
      IF (M1.EQ.0) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  WS(IW)  = XTAN*X(I,J) + ZXTAN*Y(I,J) + ZX0
                  WS(JW)  = YTAN*Z(I,J) + ZYTAN*Y(I,J) + ZY0
** LEFT HANDED SYSTEM **
                  WS(KW)  = Y(I,J)
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  CALL COORDINXYZ(X(I,J),Y(I,J),Z(I,J),WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X(I,J) + ZPY*Y(I,J) + ZPZ*Z(I,J))
               ENDDO
            ENDDO
         ENDIF          
       ELSE IF (M1.EQ.1) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  X2 = DIU*(I-1) + DJU*(J-1) + XC
                  WS(IW)  = XTAN*X2     + ZXTAN*Y(I,J) + ZX0
                  WS(JW)  = YTAN*Z(I,J) + ZYTAN*Y(I,J) + ZY0
                  WS(KW)  = Y(I,J)
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  X2 = DIU*(I-1) + DJU*(J-1) + XC
                  CALL COORDINXYZ(X2,Y(I,J),Z(I,J),WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X2 + ZPY*Y(I,J) + ZPZ*Z(I,J))
               ENDDO
            ENDDO
         ENDIF          
       ELSE IF (M1.EQ.2) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Y2 = DIU*(I-1) + DJU*(J-1) + YC
                  WS(IW)  = XTAN*X(I,J) + ZXTAN*Y2 + ZX0
                  WS(JW)  = YTAN*Z(I,J) + ZYTAN*Y2 + ZY0
                  WS(KW)  = Y2
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Y2 = DIU*(I-1) + DJU*(J-1) + YC
                  CALL COORDINXYZ(X(I,J),Y2,Z(I,J),WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X(I,J) + ZPY*Y2 + ZPZ*Z(I,J))
               ENDDO
            ENDDO
         ENDIF          
       ELSE IF (M1.EQ.4) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Z2 = DIU*(I-1) + DJU*(J-1) + ZC
                  WS(IW)  = XTAN*X(I,J) + ZXTAN*Y(I,J) + ZX0
                  WS(JW)  = YTAN*Z2     + ZYTAN*Y(I,J) + ZY0
                  WS(KW)  = Y(I,J)
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Z2 = DIU*(I-1) + DJU*(J-1) + ZC
                  CALL COORDINXYZ(X(I,J),Y(I,J),Z2,WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X(I,J) + ZPY*Y(I,J) + ZPZ*Z2)
               ENDDO
            ENDDO
         ENDIF          
       ELSE IF (M1.EQ.5) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Z2 = DIU*(I-1) + DJU*(J-1) + ZC
                  X2 = DIV*(I-1) + DJV*(J-1) + XC
                  WS(IW)  = XTAN*X2 + ZXTAN*Y(I,J) + ZX0
                  WS(JW)  = YTAN*Z2 + ZYTAN*Y(I,J) + ZY0
                  WS(KW)  = Y(I,J)
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Z2 = DIU*(I-1) + DJU*(J-1) + ZC
                  X2 = DIV*(I-1) + DJV*(J-1) + XC
                  CALL COORDINXYZ(X2,Y(I,J),Z2,WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X2 + ZPY*Y(I,J) + ZPZ*Z2)
               ENDDO
            ENDDO
         ENDIF          
       ELSE IF (M1.EQ.6) THEN
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Y2 = DIU*(I-1) + DJU*(J-1) + YC
                  Z2 = DIV*(I-1) + DJV*(J-1) + ZC
                  WS(IW)  = XTAN*X(I,J) + ZXTAN*Y2 + ZX0
                  WS(JW)  = YTAN*Z2     + ZYTAN*Y2 + ZY0
                  WS(KW)  = Y2
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  Y2 = DIU*(I-1) + DJU*(J-1) + YC
                  Z2 = DIV*(I-1) + DJV*(J-1) + ZC
                  CALL COORDINXYZ(X(I,J),Y2,Z2,WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X(I,J) + ZPY*Y2 + ZPZ*Z2)
               ENDDO
            ENDDO
         ENDIF          
       ELSE
         IF (MODE3D.EQ.0) THEN
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  X2 = DIU*(I-1) + DJU*(J-1) + XC
                  Y2 = DIV*(I-1) + DJV*(J-1) + YC
                  WS(IW)  = XTAN*X2     + ZXTAN*Y2 + ZX0
                  WS(JW)  = YTAN*Z(I,J) + ZYTAN*Y2 + ZY0
                  WS(KW)  = Y2
               ENDDO
            ENDDO
          ELSE
            DO J = NY1, NY2
               DO I = NX1, NX2
                  IW = IW + 1
                  JW = JW + 1
                  KW = KW + 1
                  X2 = DIU*(I-1) + DJU*(J-1) + XC
                  Y2 = DIV*(I-1) + DJV*(J-1) + YC
                  CALL COORDINXYZ(X2,Y2,Z(I,J),WS(IW),WS(JW))
                  WS(KW) = -(ZPX*X2 + ZPY*Y2 + ZPZ*Z(I,J))
               ENDDO
            ENDDO
         ENDIF
      ENDIF

      NPR = NPR+NUNV(NPROF)*3
*      IF (IND.GT.9) RETURN
      IF (IND.LT.0) RETURN

      CALL HGWIOMINMAX(WS,WS(NUNV(1)+1),NUNV(1)
     ,                          ,XXXMIN,YYYMIN,XXXMAX,YYYMAX)
      NUNVMAX  = NUNV(1)
      NUNV1(1) = 0
      NUNV3(1) = 0
      DO NP = 2, NPROF
         NUNVMAX   = NUNVMAX + NUNV(NP)
         NUNV1(NP) = NUNV1(NP-1)+NUNV(NP-1)
         NUNV3(NP) = NUNV3(NP-1)+NUNV(NP-1)*3
         NW        = NUNV3(NP)+1
         CALL HGWIOMINMAX(WS(NW),WS(NW+NUNV(NP)),-NUNV(NP)
     ,                          ,XXXMIN,YYYMIN,XXXMAX,YYYMAX)
      ENDDO
      DRX    = (XXXMAX - XXXMIN)/NDIV
      DRY    = (YYYMAX - YYYMIN)/NDIV

      IF (NSMODE.LT.0) THEN
         NUV2   = NUNVMAX/2
*         IND1   = IND-3
*         IF (NPROF.GT.1) IND1 = 0
*         IF (IND1.GE.0) THEN
*            IF (NUNVMAX.LT.NDIV*NDIV) IND1 = 0
*         ENDIF
*         IND0 = IND1
         IND1 = 1
         IND0 = IND1
         CALL ZDATASORT(WS,TS,HS,HS(NUNVMAX+1),IND0)
       CALL DRAWSURFACE3D(WS,TS,HS,HS(NUNVMAX*2+1),NUNVMAX,IND0,IND1,IC)
       ELSE
         IF (NSMODE.GE.1000) THEN
            ICC = -2
*            IF (IC/10.NE.0) ICC = -12
            CALL FGWIOCOLORSET(ICC,0,FM1,FM2)
         ENDIF
         CALL SET3DVIEWDIRECTION(EEX,EEY,EEZ,CLGX,CLGY,CLGZ)
         IND1 = -1
         CALL ZDATASORT(WS,TS,HS,HS,IND1)
         IF (NSMODE.EQ.10) THEN
            CALL PWITHNORMALVECTOR(X,Y,Z,IMAX,JMAX,NX1,NX2,NY1,NY2
     +                                          ,WS,HS,TS,NUNVMAX)
          ELSE IF (M0.NE.0) THEN
            CALL DFILL3DSQUARES(X,Y,Z,F,IMAX,JMAX,NX1,NX2,NY1
     +                                          ,WS,HS,NUNVMAX,IC)
          ELSE
            IF (MOD3DIR.EQ.1) THEN
               CALL DFILL3DSQUARES(X,Y,Z,X,IMAX,JMAX,NX1,NX2,NY1
     +                                          ,WS,HS,NUNVMAX,IC)
             ELSE IF (MOD3DIR.EQ.2) THEN
               CALL DFILL3DSQUARES(X,Y,Z,Y,IMAX,JMAX,NX1,NX2,NY1
     +                                          ,WS,HS,NUNVMAX,IC)
             ELSE
               CALL DFILL3DSQUARES(X,Y,Z,Z,IMAX,JMAX,NX1,NX2,NY1
     +                                          ,WS,HS,NUNVMAX,IC)
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE SETPROFDIDJ(X,IMAX,JMAX,XC,X1,X2,DI,DJ)
      REAL*8 X(3),XC,X1,X2,DI,DJ

      XC = X(1)
      DI = (X(2)-XC)/(IMAX-1)
      DJ = (X(3)-XC)/(JMAX-1)
      X1 = XC
      X2 = X1
      IF (X1.GT.X(2)) X1 = X(2)
      IF (X2.LT.X(2)) X2 = X(2)
      IF (X1.GT.X(3)) X1 = X(3)
      IF (X2.LT.X(3)) X2 = X(3)
      
      RETURN
      END

      SUBROUTINE DFILL3DSQUARES(X,Y,Z,F,IMAX,JMAX,NX1,NX2,NY,WS
     +                                              ,ORDER,NUV,IC)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8    X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX),F(IMAX,JMAX)
      REAL*8    X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3
      REAL*4    WS(NUV,3),CS,RS
      REAL      TRIX(3),TRIY(3),FH(4),SQX(4),SQY(4)
      INTEGER   ORDER(*)

      NU  = NX2-NX1+1
      IF (NSMODE.EQ.1000) THEN
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            I  = MOD(KN-1,NU)+NX1
            J  = (KN-1)/NU+NY
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            FH(1)  = F(I,J)
            FH(2)  = F(I+1,J)
            FH(3)  = F(I+1,J+1)
            FH(4)  = F(I,J+1)
            CALL FGWIOSQUARE(SQX,SQY,FH,NBCOL)
         ENDDO

       ELSE IF (NSMODE.GE.2000.AND.NSMODE.LE.2010) THEN
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            I  = MOD(KN-1,NU)+NX1
            J  = (KN-1)/NU+NY
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            FH(1)  = F(I,J)
            FH(2)  = F(I+1,J)
            FH(3)  = F(I+1,J+1)
            FH(4)  = F(I,J+1)
*            CALL FGWIOSSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
            CALL FGWIOAVSQUARE(SQX,SQY,FH,NBCOL,NSMODE-2000)
         ENDDO

       ELSE IF (NSMODE.GE.3000.AND.NSMODE.LE.3010) THEN
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            I  = MOD(KN-1,NU)+NX1
            J  = (KN-1)/NU+NY
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            FH(1)  = F(I,J)
            FH(2)  = F(I+1,J)
            FH(3)  = F(I+1,J+1)
            FH(4)  = F(I,J+1)
*            CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
            CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
         ENDDO

       ELSE IF (NSMODE.GE.4000.AND.NSMODE.LE.4010) THEN
         NM = NSMODE-4000
         IF (NM.EQ.2) THEN
            DO K = NORDER, 1, -1
               KN = ORDER(K)
               I  = MOD(KN-1,NU)+NX1
               J  = (KN-1)/NU+NY
               XX = WS(KN,1)
               YY = WS(KN,2)
               FF = F(I,J)
               CALL FGWIOPSET(XX,YY,FF)
            ENDDO
          ELSE IF (NM.EQ.1) THEN
            DO K = NORDER, 1, -1
               KN = ORDER(K)
               I  = MOD(KN-1,NU)+NX1
               J  = (KN-1)/NU+NY
               SQX(1) = WS(KN,1)
               SQX(2) = WS(KN+1,1)
               SQX(3) = WS(KN+NU+1,1)
               SQX(4) = WS(KN+NU,1)
               SQY(1) = WS(KN,2)
               SQY(2) = WS(KN+1,2)
               SQY(3) = WS(KN+NU+1,2)
               SQY(4) = WS(KN+NU,2)
               FH(1)  = F(I,J)
               FH(2)  = F(I+1,J)
               FH(3)  = F(I+1,J+1)
               FH(4)  = F(I,J+1)
*               CALL FGWIOFSQUARE(SQX,SQY,FH,NBCOL,NSMODE-3000)
               CALL FGWIOFPSQUARE(SQX,SQY,FH,NBCOL,3)
         ENDDO
          ELSE
            DO K = NORDER, 1, -1
               KN = ORDER(K)
               I  = MOD(KN-1,NU)+NX1
               J  = (KN-1)/NU+NY
               SQX(1) = WS(KN,1)
               SQX(2) = WS(KN+1,1)
               SQX(3) = WS(KN+NU+1,1)
               SQX(4) = WS(KN+NU,1)
               SQY(1) = WS(KN,2)
               SQY(2) = WS(KN+1,2)
               SQY(3) = WS(KN+NU+1,2)
               SQY(4) = WS(KN+NU,2)
               CALL GWIOCOLOR(2,0)
               CALL GWIOPOLYGON(SQX,SQY,4,3)
               FF = F(I,J)
               CALL FGWIOPSET(SQX(1),SQY(1),FF)
               FF = F(I+1,J)
               CALL FGWIOPSET(SQX(2),SQY(2),FF)
               FF = F(I+1,J+1)
               CALL FGWIOPSET(SQX(3),SQY(3),FF)
               FF = F(I,J+1)
               CALL FGWIOPSET(SQX(4),SQY(4),FF)
            ENDDO
         ENDIF

       ELSE IF (NSMODE.EQ.100) THEN
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            CALL SGWIOPOLYGON(SQX,SQY,4,IC,NBCOL)
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            I  = MOD(KN-1,NU)+NX1
            J  = (KN-1)/NU+NY
            X1 = X(I,J)
            Y1 = Y(I,J)
            Z1 = Z(I,J)
            X2 = X(I+1,J)
            Y2 = Y(I+1,J)
            Z2 = Z(I+1,J)
            X3 = X(I,J+1)
            Y3 = Y(I,J+1)
            Z3 = Z(I,J+1)
            CALL DNORMSQUARES(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,CS,RS,CSS)
            TRIX(1) = WS(KN,1)
            TRIX(2) = WS(KN+1,1)
            TRIX(3) = WS(KN+NU,1)
            TRIY(1) = WS(KN,2)
            TRIY(2) = WS(KN+1,2)
            TRIY(3) = WS(KN+NU,2)
            CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
            X1 = X(I+1,J)
            Y1 = Y(I+1,J)
            Z1 = Z(I+1,J)
            X2 = X(I+1,J+1)
            Y2 = Y(I+1,J+1)
            Z2 = Z(I+1,J+1)
            X3 = X(I,J+1)
            Y3 = Y(I,J+1)
            Z3 = Z(I,J+1)
            CALL DNORMSQUARES(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,CS,RS,CSS)
            TRIX(1) = WS(KN+1,1)
            TRIX(2) = WS(KN+NU+1,1)
            TRIX(3) = WS(KN+NU,1)
            TRIY(1) = WS(KN+1,2)
            TRIY(2) = WS(KN+NU+1,2)
            TRIY(3) = WS(KN+NU,2)
            CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,-1)
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            IF (NBCOL.GE.0) THEN
               CALL GWIOCOLOR(2,NBCOL)
               CALL GWIOPOLYGON(SQX,SQY,4,1)
            ENDIF
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE DNORMSQUARES(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,LITN,EYER,EYEN)
      REAL*8 X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,DX1,DY1,DZ1,DX2,DY2,DZ2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      REAL LITN
      REAL*8 XX,YY,ZZ

      IF (MDPROJ.NE.0) THEN
         XX = (X1+X2+X3)/3
         YY = (Y1+Y2+Y3)/3
         ZZ = (Z1+Z2+Z3)/3
         EEX0 = EEX-XX
         EEY0 = EEY-YY
         EEZ0 = EEZ-ZZ
         RN  = SQRT(EEX0*EEX0+EEY0*EEY0+EEZ0*EEZ0)
         EEX0 = EEX0/RN
         EEY0 = EEY0/RN
         EEZ0 = EEZ0/RN
       ELSE
         EEX0 = EEX
         EEY0 = EEY
         EEZ0 = EEZ
      ENDIF

      DX1 = X2-X1
      DY1 = Y2-Y1
      DZ1 = Z2-Z1
      DX2 = X3-X1
      DY2 = Y3-Y1
      DZ2 = Z3-Z1
      DSX = DY1*DZ2-DY2*DZ1
      DSY = DZ1*DX2-DZ2*DX1
      DSZ = DX1*DY2-DX2*DY1
      RN  = DSX*DSX+DSY*DSY+DSZ*DSZ
      EYEN = EEX0*DSX+EEY0*DSY+EEZ0*DSZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         IF (EYEN.LT.0) THEN
            DSX  = -DSX
            DSY  = -DSY
            DSZ  = -DSZ
*   DO NOT COMMENT HERE
            EYEN = -EYEN
         ENDIF
         RN = 1/SQRT(RN)
         LITN = (CLGX*DSX+CLGY*DSY+CLGZ*DSZ)*RN
         RX = 2*LITN*DSX*RN -CLGX
         RY = 2*LITN*DSY*RN -CLGY
         RZ = 2*LITN*DSZ*RN -CLGZ
         EYER = EEX0*RX+EEY0*RY+EEZ0*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE PWITHNORMALVECTOR(X,Y,Z,IMAX,JMAX,NX1,NX2,NY1,NY2,WS
     +                                              ,ORDER,NORMAL,NUV)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL LTH,LPH
      REAL*8    X(IMAX,JMAX),Y(IMAX,JMAX),Z(IMAX,JMAX)
      REAL*8    DX1,DX2,DY1,DY2,DZ1,DZ2,VX1,VY1,VZ1
      REAL*4    WS(NUV,3),CS,RS,KDIF,KSPC
      REAL      SQX(4),SQY(4),FP(4),NORMAL(NX1:NX2,NY1:NY2)
      INTEGER   ORDER(*)

*     MAIN REGION
      DO J = NY1+1, NY2-1
         DO I = NX1+1, NX2-1
            DX1 = X(I+1,J)-X(I,J)
            DY1 = Y(I+1,J)-Y(I,J)
            DZ1 = Z(I+1,J)-Z(I,J)
            DX2 = X(I,J+1)-X(I,J)
            DY2 = Y(I,J+1)-Y(I,J)
            DZ2 = Z(I,J+1)-Z(I,J)
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            DX1 = X(I-1,J)-X(I,J)
            DY1 = Y(I-1,J)-Y(I,J)
            DZ1 = Z(I-1,J)-Z(I,J)
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            DX2 = X(I,J-1)-X(I,J)
            DY2 = Y(I,J-1)-Y(I,J)
            DZ2 = Z(I,J-1)-Z(I,J)
            VX1 = VX1 + DY1*DZ2-DY2*DZ1
            VY1 = VY1 + DZ1*DX2-DZ2*DX1
            VZ1 = VZ1 + DX1*DY2-DX2*DY1
            DX1 = X(I+1,J)-X(I,J)
            DY1 = Y(I+1,J)-Y(I,J)
            DZ1 = Z(I+1,J)-Z(I,J)
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC
         ENDDO
      ENDDO

*     BOTTOM LINE
      J = NY1
         DO I = NX1+1, NX2-1
            DX1 = X(I+1,J)-X(I,J)
            DY1 = Y(I+1,J)-Y(I,J)
            DZ1 = Z(I+1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J+1)-X(I,J)
               DY1 = Y(I+1,J+1)-Y(I,J)
               DZ1 = Z(I+1,J+1)-Z(I,J)
            ENDIF
            DX2 = X(I,J+1)-X(I,J)
            DY2 = Y(I,J+1)-Y(I,J)
            DZ2 = Z(I,J+1)-Z(I,J)
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            DX1 = X(I-1,J)-X(I,J)
            DY1 = Y(I-1,J)-Y(I,J)
            DZ1 = Z(I-1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J+1)-X(I,J)
               DY1 = Y(I-1,J+1)-Y(I,J)
               DZ1 = Z(I-1,J+1)-Z(I,J)
            ENDIF
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC
         ENDDO

*     TOP LINE
      J = NY2
         DO I = NX1+1, NX2-1
            DX1 = X(I-1,J)-X(I,J)
            DY1 = Y(I-1,J)-Y(I,J)
            DZ1 = Z(I-1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J-1)-X(I,J)
               DY1 = Y(I-1,J-1)-Y(I,J)
               DZ1 = Z(I-1,J-1)-Z(I,J)
            ENDIF
            DX2 = X(I,J-1)-X(I,J)
            DY2 = Y(I,J-1)-Y(I,J)
            DZ2 = Z(I,J-1)-Z(I,J)
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            DX1 = X(I+1,J)-X(I,J)
            DY1 = Y(I+1,J)-Y(I,J)
            DZ1 = Z(I+1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J-1)-X(I,J)
               DY1 = Y(I+1,J-1)-Y(I,J)
               DZ1 = Z(I+1,J-1)-Z(I,J)
            ENDIF
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC
         ENDDO

*     LEFT LINE
         I = NX1
      DO J = NY1+1, NY2-1
            DX1 = X(I,J-1)-X(I,J)
            DY1 = Y(I,J-1)-Y(I,J)
            DZ1 = Z(I,J-1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J-1)-X(I,J)
               DY1 = Y(I+1,J-1)-Y(I,J)
               DZ1 = Z(I+1,J-1)-Z(I,J)
            ENDIF
            DX2 = X(I+1,J)-X(I,J)
            DY2 = Y(I+1,J)-Y(I,J)
            DZ2 = Z(I+1,J)-Z(I,J)
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            DX1 = X(I,J+1)-X(I,J)
            DY1 = Y(I,J+1)-Y(I,J)
            DZ1 = Z(I,J+1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J+1)-X(I,J)
               DY1 = Y(I+1,J+1)-Y(I,J)
               DZ1 = Z(I+1,J+1)-Z(I,J)
            ENDIF
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC
      ENDDO

*     RIGHT LINE
         I = NX2
      DO J = NY1+1, NY2-1
            DX1 = X(I,J+1)-X(I,J)
            DY1 = Y(I,J+1)-Y(I,J)
            DZ1 = Z(I,J+1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J+1)-X(I,J)
               DY1 = Y(I-1,J+1)-Y(I,J)
               DZ1 = Z(I-1,J+1)-Z(I,J)
            ENDIF
            DX2 = X(I-1,J)-X(I,J)
            DY2 = Y(I-1,J)-Y(I,J)
            DZ2 = Z(I-1,J)-Z(I,J)
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            DX1 = X(I,J-1)-X(I,J)
            DY1 = Y(I,J-1)-Y(I,J)
            DZ1 = Z(I,J-1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J-1)-X(I,J)
               DY1 = Y(I-1,J-1)-Y(I,J)
               DZ1 = Z(I-1,J-1)-Z(I,J)
            ENDIF
            VX1 = VX1 - (DY1*DZ2-DY2*DZ1)
            VY1 = VY1 - (DZ1*DX2-DZ2*DX1)
            VZ1 = VZ1 - (DX1*DY2-DX2*DY1)
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC
      ENDDO

*     BOTTOM LEFT
      J = NY1
         I = NX1
            DX1 = X(I+1,J)-X(I,J)
            DY1 = Y(I+1,J)-Y(I,J)
            DZ1 = Z(I+1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J+1)-X(I,J)
               DY1 = Y(I+1,J+1)-Y(I,J)
               DZ1 = Z(I+1,J+1)-Z(I,J)
            ENDIF
            DX2 = X(I,J+1)-X(I,J)
            DY2 = Y(I,J+1)-Y(I,J)
            DZ2 = Z(I,J+1)-Z(I,J)
            IF (DX2.EQ.0.AND.DY2.EQ.0.AND.DZ2.EQ.0) THEN
               DX1 = X(I+1,J+1)-X(I,J)
               DY1 = Y(I+1,J+1)-Y(I,J)
               DZ1 = Z(I+1,J+1)-Z(I,J)
            ENDIF
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC

*     BOTTOM RIGHT
      J = NY1
         I = NX2
            DX1 = X(I,J+1)-X(I,J)
            DY1 = Y(I,J+1)-Y(I,J)
            DZ1 = Z(I,J+1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J+1)-X(I,J)
               DY1 = Y(I-1,J+1)-Y(I,J)
               DZ1 = Z(I-1,J+1)-Z(I,J)
            ENDIF
            DX2 = X(I-1,J)-X(I,J)
            DY2 = Y(I-1,J)-Y(I,J)
            DZ2 = Z(I-1,J)-Z(I,J)
            IF (DX2.EQ.0.AND.DY2.EQ.0.AND.DZ2.EQ.0) THEN
               DX1 = X(I-1,J+1)-X(I,J)
               DY1 = Y(I-1,J+1)-Y(I,J)
               DZ1 = Z(I-1,J+1)-Z(I,J)
            ENDIF
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC

*     TOP LEFT
      J = NY2
         I = NX1
            DX1 = X(I,J-1)-X(I,J)
            DY1 = Y(I,J-1)-Y(I,J)
            DZ1 = Z(I,J-1)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I+1,J-1)-X(I,J)
               DY1 = Y(I+1,J-1)-Y(I,J)
               DZ1 = Z(I+1,J-1)-Z(I,J)
            ENDIF
            DX2 = X(I+1,J)-X(I,J)
            DY2 = Y(I+1,J)-Y(I,J)
            DZ2 = Z(I+1,J)-Z(I,J)
            IF (DX2.EQ.0.AND.DY2.EQ.0.AND.DZ2.EQ.0) THEN
               DX1 = X(I+1,J-1)-X(I,J)
               DY1 = Y(I+1,J-1)-Y(I,J)
               DZ1 = Z(I+1,J-1)-Z(I,J)
            ENDIF
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC

*     TOP RIGHT
      J = NY2
         I = NX2
            DX1 = X(I-1,J)-X(I,J)
            DY1 = Y(I-1,J)-Y(I,J)
            DZ1 = Z(I-1,J)-Z(I,J)
            IF (DX1.EQ.0.AND.DY1.EQ.0.AND.DZ1.EQ.0) THEN
               DX1 = X(I-1,J-1)-X(I,J)
               DY1 = Y(I-1,J-1)-Y(I,J)
               DZ1 = Z(I-1,J-1)-Z(I,J)
            ENDIF
            DX2 = X(I,J-1)-X(I,J)
            DY2 = Y(I,J-1)-Y(I,J)
            DZ2 = Z(I,J-1)-Z(I,J)
            IF (DX2.EQ.0.AND.DY2.EQ.0.AND.DZ2.EQ.0) THEN
               DX1 = X(I-1,J-1)-X(I,J)
               DY1 = Y(I-1,J-1)-Y(I,J)
               DZ1 = Z(I-1,J-1)-Z(I,J)
            ENDIF
            VX1 = DY1*DZ2-DY2*DZ1
            VY1 = DZ1*DX2-DZ2*DX1
            VZ1 = DX1*DY2-DX2*DY1
            CALL GETNORMALLIGHT(X(I,J),Y(I,J),Z(I,J),VX1,VY1,VZ1,CS,RS)
            KDIF = CDIF*(CS+1)/2
            IF (RS.LT.0) THEN
               KSPC = 0
             ELSE
               KSPC = CSPC*RS**NSPORDER
            ENDIF
            NORMAL(I,J) = CAMB + KDIF + KSPC

      NU  = NX2-NX1+1

*       ELSE
         DO K = NORDER, 1, -1
            KN = ORDER(K)
            I  = MOD(KN-1,NU)+NX1
            J  = (KN-1)/NU+NY1
            SQX(1) = WS(KN,1)
            SQX(2) = WS(KN+1,1)
            SQX(3) = WS(KN+NU+1,1)
            SQX(4) = WS(KN+NU,1)
            SQY(1) = WS(KN,2)
            SQY(2) = WS(KN+1,2)
            SQY(3) = WS(KN+NU+1,2)
            SQY(4) = WS(KN+NU,2)
            FP(1)  = NORMAL(I,J)
            FP(2)  = NORMAL(I+1,J)
            FP(3)  = NORMAL(I+1,J+1)
            FP(4)  = NORMAL(I,J+1)
            CALL LGWIOSQUARE(SQX,SQY,FP,NBCOL)
         ENDDO
*      ENDIF

      RETURN
      END

      SUBROUTINE GETNORMALLIGHT(XX,YY,ZZ,VX,VY,VZ,LITN,EYER)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8 XX,YY,ZZ,VX,VY,VZ
      REAL   LITN,EYER

      IF (MDPROJ.NE.0) THEN
         EEX0 = EEX-XX
         EEY0 = EEY-YY
         EEZ0 = EEZ-ZZ
         RN  = SQRT(EEX0*EEX0+EEY0*EEY0+EEZ0*EEZ0)
         EEX0 = EEX0/RN
         EEY0 = EEY0/RN
         EEZ0 = EEZ0/RN
         EN1  = (EEX-XX)*VX+(EEY-YY)*VY+(EEZ-ZZ)*VZ
       ELSE
         EEX0 = EEX
         EEY0 = EEY
         EEZ0 = EEZ
         EN1  = EEX*VX+EEY*VY+EEZ*VZ
      ENDIF

      RN = VX*VX+VY*VY+VZ*VZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         RN = 1/SQRT(RN)
         LITN = (CLGX*VX+CLGY*VY+CLGZ*VZ)*RN
         RX = 2*LITN*VX*RN -CLGX
         RY = 2*LITN*VY*RN -CLGY
         RZ = 2*LITN*VZ*RN -CLGZ
         EYER = EEX0*RX+EEY0*RY+EEZ0*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE ZDATASORT(WS,TS,ORDER,REGION,IND)
      PARAMETER (NDIV=16)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      REAL*4 WS(*),TS(*)
      INTEGER ORDER(*),REGION(*)
      INTEGER L,R,S,SB0(20),SB1(20)

      IF (IND.GT.0) THEN
         NREG0 = 0
         DO J = 1, NDIV
            DO I = 1, NDIV
               IREGDEX(I,J) = 0
            ENDDO
         ENDDO
      ENDIF

      K1  = 0
      DO NP = 1, NPROF
         NW = NUNV1(NP)
         IW = NUNV3(NP)
         JW = IW + NUNV(NP)
         KW = JW + NUNV(NP)
         DO 20 J = 1, NV(NP)-1
            DO 10 I = 1, NU(NP)-1
               NW = NW + 1
               IW = IW + 1
               JW = JW + 1
               KW = KW + 1 
               K1 = K1 + 1
               ORDER(K1) = NW
** LEFT HANDED SYSTEM **
              TS(K1)= MIN(WS(KW),WS(KW+1),WS(KW+NU(NP)),WS(KW+NU(NP)+1))
               IF (IND.GE.0) THEN
                  X1= MIN(WS(IW),WS(IW+1),WS(IW+NU(NP)),WS(IW+NU(NP)+1))
                  X2= MAX(WS(IW),WS(IW+1),WS(IW+NU(NP)),WS(IW+NU(NP)+1))
                  Y1= MIN(WS(JW),WS(JW+1),WS(JW+NU(NP)),WS(JW+NU(NP)+1))
                  Y2= MAX(WS(JW),WS(JW+1),WS(JW+NU(NP)),WS(JW+NU(NP)+1))

                  NX1 = (X1 - XXXMIN)/DRX
                  NX2 = (X2 - XXXMIN)/DRX
                  NY1 = (Y1 - YYYMIN)/DRY
                  NY2 = (Y2 - YYYMIN)/DRY

                  IF (NX1.GE.NDIV.OR.NX2.LT.0
     +                    .OR.NY1.GE.NDIV.OR.NY2.LT.0) THEN
                     REGION(K1) = 0
                     IF (IND.NE.0) NREG0 = NREG0 + 1
                   ELSE
                     IF (NX1.LT.0)    NX1 = 0
                     IF (NX2.GE.NDIV) NX2 = NDIV - 1
                     IF (NY1.LT.0)    NY1 = 0
                     IF (NY2.GE.NDIV) NY2 = NDIV - 1
                     IRX        = ISHFT(1,NX2-NX1+1) - 1
                     IRY        = ISHFT(1,NY2-NY1+1) - 1
                     REGION(K1) = IOR(ISHFT(IRX,NX1+16),ISHFT(IRY,NY1))
                     IF (IND.NE.0) THEN
                        IF (IRX.EQ.1.AND.IRY.EQ.1) THEN
                           IREGDEX(NX1+1,NY1+1) = IREGDEX(NX1+1,NY1+1)+1
                         ELSE 
                           NREG0 = NREG0 + 1
                        ENDIF
                     ENDIF
                  ENDIF
               ENDIF
   10       CONTINUE
            NW = NW + 1
            IW = IW + 1
            JW = JW + 1
            KW = KW + 1 
   20   CONTINUE
      ENDDO

      IF (IND.GT.0) THEN
         IND  = NREG0
         NSUM = NREG0 + 1
         DO J = 1, NDIV
            DO I = 1, NDIV
               NSUM1 = NSUM + IREGDEX(I,J)
               IREGDEX(I,J) = NSUM
               NSUM = NSUM1
            ENDDO
         ENDDO
      ENDIF

      NORDER = K1
      K      = 1
      SB0(1) = 1
      SB1(1) = K1

  100 IF (K.GT.0) THEN
         L = SB0(K)
         R = SB1(K)
         K = K - 1
  200    IF (L.LT.R) THEN
            I = L
            J = R
            W = TS((L+R)/2)
  300       IF (I.LE.J) THEN
** LEFT HANDED SYSTEM **
  400          IF (TS(I).LT.W) THEN
                  I = I + 1
                  GO TO 400
               ENDIF
  500          IF (TS(J).GT.W) THEN
                  J = J - 1
                  GO TO 500
               ENDIF
               IF (I.LE.J) THEN
                  D         = TS(I)
                  TS(I)     = TS(J)
                  TS(J)     = D
                  S         = ORDER(I)
                  ORDER(I)  = ORDER(J)
                  ORDER(J)  = S
                  IF (IND.GE.0) THEN
                     S         = REGION(I)
                     REGION(I) = REGION(J)
                     REGION(J) = S
                  ENDIF
                  I = I + 1
                  J = J - 1
               ENDIF
               GO TO 300
            ENDIF
            IF (J-L.LT.R-I) THEN
               IF (I.LT.R) THEN
                  K      = K + 1
                  SB0(K) = I
                  SB1(K) = R
                  R      = J
                ELSE
                  R = J
               ENDIF
             ELSE IF (L.LT.J) THEN
               K      = K + 1
               SB0(K) = L
               SB1(K) = J
               L      = I
             ELSE
               L = I
            ENDIF
            GO TO 200
         ENDIF
         GO TO 100
      ENDIF

      RETURN
      END

      SUBROUTINE REGIONORDER(REGION,IRS,REGDER)
      PARAMETER (NDIV=16,MASK=2**NDIV-1)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      INTEGER REGION(*),IRS(NDIV,NDIV),REGDER(*)

      DO J = 1, NDIV
         DO I = 1, NDIV
            IRS(I,J) = IREGDEX(I,J)
         ENDDO
      ENDDO

      IRS0    = 1
      NUNVM1 = (NU(1)-1)*(NV(1)-1)
      DO I = 1, NUNVM1
         IRX = ISHFT(REGION(I),-16)
         IRY = IAND(REGION(I),MASK)
         NX1 = 1
         NY1 = 1
         DO J = 1, NDIV
            IF (IAND(IRX,1).NE.0) GO TO 10
            NX1 = NX1 + 1
            IRX = ISHFT(IRX,-1)
         ENDDO
   10    DO J = 1, NDIV
            IF (IAND(IRY,1).NE.0) GO TO 20
            NY1 = NY1 + 1
            IRY = ISHFT(IRY,-1)
         ENDDO
   20    IF (IRX.EQ.1.AND.IRY.EQ.1) THEN
            REGDER(IRS(NX1,NY1)) = I
            IRS(NX1,NY1) = IRS(NX1,NY1) + 1
          ELSE
            REGDER(IRS0) = I
            IRS0 = IRS0 + 1
         ENDIF
      ENDDO

      RETURN
      END

      SUBROUTINE SEARCHIMAX(TS,REGION,REGSEL)
      PARAMETER (NDIV=16,MASK=2**16-1)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      REAL*4  TS(*)
      INTEGER REGION(*),REGSEL(*)

      IV = 1
      IF (XXX.LT.XXXMIN.OR.YYY.LT.YYYMIN) GO TO 999

      NX   = (XXX - XXXMIN)/DRX
      IF (NX.GE.NDIV) GO TO 999
      NY   = (YYY - YYYMIN)/DRY
      IF (NY.GE.NDIV) GO TO 999
      NR1  = ISHFT(1,NX+16)
      NR1  = IOR(NR1,ISHFT(1,NY))

      IF (NR.NE.NR1.OR.K0MAX0.EQ.0) THEN
         NR    = NR1
         I0    = 0
         K     = 0
         DO 10 I = 1, NORDER
** LEFT HANDED SYSTEM **
            IF (ZZZ.LT.TS(I)) GO TO 11
            IF (I0.EQ.0.AND.IAND(NR,REGION(I)).EQ.NR) THEN
               K = K + 1
               REGSEL(K) = I
               IF (K.GE.NUV2) I0 = I + 1
            ENDIF
   10    CONTINUE
   11    K0MAX  = K
         K0MAX0 = K
         I0MAX  = I - 1

       ELSE
** LEFT HANDED SYSTEM **
         IF (ZZZ.LT.TS(I0MAX)) THEN
            DO 20 K0 = K0MAX0-1, 1, -1
** LEFT HANDED SYSTEM **
               IF (ZZZ.GE.TS(REGSEL(K0))) GO TO 21
   20        CONTINUE
   21       K0MAX = K0
          ELSE IF (K0MAX0.LT.NUV2) THEN
            K = K0MAX0
            DO 30 I = I0MAX + 1, NORDER
** LEFT HANDED SYSTEM **
               IF (ZZZ.LT.TS(I)) GO TO 31
               IF (I0.EQ.0.AND.IAND(NR,REGION(I)).EQ.NR) THEN
                  K = K + 1
                  REGSEL(K) = I
                  IF (K.GE.NUV2) I0 = I + 1
               ENDIF
   30       CONTINUE
   31       K0MAX  = K
            K0MAX0 = K
            I0MAX  = I - 1
         ENDIF
      ENDIF

      RETURN

      ENTRY SEARCHIMAX2(TS)

      IV = 1
      IF (XXX.LT.XXXMIN.OR.YYY.LT.YYYMIN) GO TO 999
      NX   = (XXX - XXXMIN)/DRX
      IF (NX.GE.NDIV) GO TO 999
      NY   = (YYY - YYYMIN)/DRY
      IF (NY.GE.NDIV) GO TO 999
      NR   = ISHFT(1,NX+16)
      NR   = IOR(NR,ISHFT(1,NY))
      NX0  = NX + 1
      NY0  = NY + 1

      I1 = 1
      I2 = NORDER + 1
  100   CONTINUE
         I = (I2 + I1)/2
         IF (I.EQ.I1) GO TO 110
** LEFT HANDED SYSTEM **
         IF (TS(I).LT.ZZZ) THEN
            I1 = I
          ELSE
            I2 = I
         ENDIF
         GO TO 100
110   I0    = 1
      I0MAX = I
      K0MAX = 0

      RETURN

  999 IV = 0
      RETURN
      END

      SUBROUTINE TRIVISIBLE(WS,NUV,KK,NPP)
      COMMON /PROF3DCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +                  ,CLGX,CLGY,CLGZ,NUV2,NORDER,NK,NR,IDIR,ITY,IV
     +                  ,NPROF,NP,NSMODE,NBCOL
      COMMON /PROF3DNUV/ NU(100),NV(100),NUNV(100),NUNV1(100),NUNV3(100)
     ,                  ,ICOLS(100)
      REAL*4 WS(NUV,3)

      K  = KK - NUNV1(NPP)
      K1 = K  + NU(NPP)
      X1 = WS(K,1)
      X2 = WS(K+1,1)
      X3 = WS(K1+1,1)
      X4 = WS(K1,1)
      IF (XXX.GT.X1.AND.XXX.GT.X2.AND.XXX.GT.X3.AND.XXX.GT.X4) RETURN
      IF (XXX.LT.X1.AND.XXX.LT.X2.AND.XXX.LT.X3.AND.XXX.LT.X4) RETURN

      Y1 = WS(K,2)
      Y2 = WS(K+1,2)
      Y3 = WS(K1+1,2)
      Y4 = WS(K1,2)
      IF (YYY.GT.Y1.AND.YYY.GT.Y2.AND.YYY.GT.Y3.AND.YYY.GT.Y4) RETURN
      IF (YYY.LT.Y1.AND.YYY.LT.Y2.AND.YYY.LT.Y3.AND.YYY.LT.Y4) RETURN

      Z1 = WS(K,3)
      Z2 = WS(K+1,3)
      Z3 = WS(K1+1,3)
      Z4 = WS(K1,3)
** LEFT HANDED SYSTEM **
      IF (ZZZ.LT.Z1.AND.ZZZ.LT.Z2.AND.ZZZ.LT.Z3.AND.ZZZ.LT.Z4) RETURN

      IF (ITY.LE.4) THEN
         GO TO (100,110,120,130),ITY
  100       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X2 - XXX
            DY12 = Y2 - YYY
            DZ12 = Z2 - ZZZ
            DX13 = X3 - XXX
            DY13 = Y3 - YYY
            DZ13 = Z3 - ZZZ
            DX23 = X4 - XXX
            DY23 = Y4 - YYY
            DZ23 = Z4 - ZZZ
            GO TO 190

  110       DX11 = X2 - XXX
            DY11 = Y2 - YYY
            DZ11 = Z2 - ZZZ
            DX12 = X3 - XXX
            DY12 = Y3 - YYY
            DZ12 = Z3 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            DX23 = X1 - XXX
            DY23 = Y1 - YYY
            DZ23 = Z1 - ZZZ
            GO TO 190

  120       DX11 = X2 - XXX
            DY11 = Y2 - YYY
            DZ11 = Z2 - ZZZ
            DX12 = X1 - XXX
            DY12 = Y1 - YYY
            DZ12 = Z1 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            DX23 = X3 - XXX
            DY23 = Y3 - YYY
            DZ23 = Z3 - ZZZ
            GO TO 190

  130       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X4 - XXX
            DY12 = Y4 - YYY
            DZ12 = Z4 - ZZZ
            DX13 = X3 - XXX
            DY13 = Y3 - YYY
            DZ13 = Z3 - ZZZ
            DX23 = X2 - XXX
            DY23 = Y2 - YYY
            DZ23 = Z2 - ZZZ
  190       DX22 = DX13
            DY22 = DY13
            DZ22 = DZ13

       ELSE IF (ITY.GE.16) THEN
         GO TO (200,210,220,230,240,250,260,270),ITY-15
  200       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X2 - XXX
            DY12 = Y2 - YYY
            DZ12 = Z2 - ZZZ
            DX13 = X3 - XXX
            DY13 = Y3 - YYY
            DZ13 = Z3 - ZZZ
            GO TO 290

  210       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X2 - XXX
            DY12 = Y2 - YYY
            DZ12 = Z2 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            GO TO 290

  220       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X3 - XXX
            DY12 = Y3 - YYY
            DZ12 = Z3 - ZZZ
            DX13 = X2 - XXX
            DY13 = Y2 - YYY
            DZ13 = Z2 - ZZZ
            GO TO 290

  230       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X3 - XXX
            DY12 = Y3 - YYY
            DZ12 = Z3 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            GO TO 290

  240       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X4 - XXX
            DY12 = Y4 - YYY
            DZ12 = Z4 - ZZZ
            DX13 = X2 - XXX
            DY13 = Y2 - YYY
            DZ13 = Z2 - ZZZ
            GO TO 290

  250       DX11 = X1 - XXX
            DY11 = Y1 - YYY
            DZ11 = Z1 - ZZZ
            DX12 = X4 - XXX
            DY12 = Y4 - YYY
            DZ12 = Z4 - ZZZ
            DX13 = X3 - XXX
            DY13 = Y3 - YYY
            DZ13 = Z3 - ZZZ
            GO TO 290

  260       DX11 = X2 - XXX
            DY11 = Y2 - YYY
            DZ11 = Z2 - ZZZ
            DX12 = X3 - XXX
            DY12 = Y3 - YYY
            DZ12 = Z3 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            GO TO 290

  270       DX11 = X2 - XXX
            DY11 = Y2 - YYY
            DZ11 = Z2 - ZZZ
            DX12 = X4 - XXX
            DY12 = Y4 - YYY
            DZ12 = Z4 - ZZZ
            DX13 = X3 - XXX
            DY13 = Y3 - YYY
            DZ13 = Z3 - ZZZ

  290       ITY = 0
       ELSE
         GO TO (300,310,320,330),ITY-7
  300       DX12 = X1 - XXX
            DY12 = Y1 - YYY
            DZ12 = Z1 - ZZZ
            DX13 = X2 - XXX
            DY13 = Y2 - YYY
            DZ13 = Z2 - ZZZ
            DX22 = X4 - XXX
            DY22 = Y4 - YYY
            DZ22 = Z4 - ZZZ
            DX23 = X3 - XXX
            DY23 = Y3 - YYY
            DZ23 = Z3 - ZZZ
            GO TO 315

  310       DX12 = X2 - XXX
            DY12 = Y2 - YYY
            DZ12 = Z2 - ZZZ
            DX13 = X1 - XXX
            DY13 = Y1 - YYY
            DZ13 = Z1 - ZZZ
            DX22 = X3 - XXX
            DY22 = Y3 - YYY
            DZ22 = Z3 - ZZZ
            DX23 = X4 - XXX
            DY23 = Y4 - YYY
            DZ23 = Z4 - ZZZ
  315       DX1  = X4 - X1
            DY1  = Y4 - Y1
            DX2  = X3 - X2
            DY2  = Y3 - Y2
            DX3  = X2 - X1
            DY3  = Y2 - Y1
            DXY1 = X1*Y4 - X4*Y1
            DXY2 = X2*Y3 - X3*Y2
            D    = DX1*DY2 - DX2*DY1
            Z5   = (DX3*DY2 - DX2*DY3)/D
            DZ11 = Z5*(Z4 - Z1) + Z1
            Z5   = (DX3*DY1 - DX1*DY3)/D
            Z5   = Z5*(Z3 - Z2) + Z2
            GO TO 390

  320       DX12 = X1 - XXX
            DY12 = Y1 - YYY
            DZ12 = Z1 - ZZZ
            DX13 = X4 - XXX
            DY13 = Y4 - YYY
            DZ13 = Z4 - ZZZ
            DX22 = X2 - XXX
            DY22 = Y2 - YYY
            DZ22 = Z2 - ZZZ
            DX23 = X3 - XXX
            DY23 = Y3 - YYY
            DZ23 = Z3 - ZZZ
            GO TO 335

  330       DX12 = X4 - XXX
            DY12 = Y4 - YYY
            DZ12 = Z4 - ZZZ
            DX13 = X1 - XXX
            DY13 = Y1 - YYY
            DZ13 = Z1 - ZZZ
            DX22 = X3 - XXX
            DY22 = Y3 - YYY
            DZ22 = Z3 - ZZZ
            DX23 = X2 - XXX
            DY23 = Y2 - YYY
            DZ23 = Z2 - ZZZ
  335       DX1  = X2 - X1
            DY1  = Y2 - Y1
            DX2  = X4 - X3
            DY2  = Y4 - Y3
            DX3  = X3 - X1
            DY3  = Y3 - Y1
            DXY1 = X1*Y2 - X2*Y1
            DXY2 = X3*Y4 - X4*Y3
            D    = DX1*DY2 - DX2*DY1
            Z5   = (DX3*DY2 - DX2*DY3)/D
            DZ11 = Z5*(Z2 - Z1) + Z1
            Z5   = (DX3*DY1 - DX1*DY3)/D
            Z5   = Z5*(Z4 - Z3) + Z3

  390    DX11 = (DX1*DXY2 - DX2*DXY1)/D - XXX
         DY11 = (DY1*DXY2 - DY2*DXY1)/D - YYY
         IF (Z5.GT.DZ11) DZ11 = Z5
         DZ11 = DZ11 - ZZZ
      ENDIF

      D1 = DX12*DY13 - DX13*DY12
      IF (D1.GE.0) THEN
         D2 = DX13*DY11 - DX11*DY13
         IF (D2.GE.0) THEN
            D3 = DX11*DY12 - DX12*DY11
            IF (D3.GE.0) THEN
               D = DZ11*D1 + DZ12*D2 + DZ13*D3
** LEFT HANDED SYSTEM **
               IF (D.LT.0) THEN
                  IV = 0
                  RETURN
               ENDIF
            ENDIF
         ENDIF
      ENDIF

      IF (ITY.EQ.0) RETURN

      D1 = DX22*DY23 - DX23*DY22
      IF (D1.GE.0) THEN
         D2 = DX23*DY11 - DX11*DY23
         IF (D2.GE.0) THEN
            D3 = DX11*DY22 - DX22*DY11
            IF (D3.GE.0) THEN
               D = DZ11*D1 + DZ22*D2 + DZ23*D3
** LEFT HANDED SYSTEM **
               IF (D.LT.0) IV = 0
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END
