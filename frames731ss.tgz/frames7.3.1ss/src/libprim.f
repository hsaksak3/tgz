*********************************************************
*                  F  R  A  M  E  S  V.7                *
*    PRIMITIVE  GRAPHIC SUBROUTINES  USING  FRAMES      *
*               PROGRAMMED BY T.TAGUCHI                 *
*********************************************************
      SUBROUTINE FR_FPLINE(X1,Y1,X2,Y2,IC,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      REAL*8 X1,Y1,X2,Y2

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(81,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X1,Y1,1,2)
         CALL GSEND8BYTE(X2,Y2,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      IF (M2.EQ.0) THEN
         XX1 = X1
         XX2 = X2
         YY1 = Y1
         YY2 = Y2
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            XX1 = XX1 + CURPX
            XX2 = XX2 + CURPX
         ENDIF
         IF (M1.GE.2) THEN
            YY1 = YY1 + CURPY
            YY2 = YY2 + CURPY
         ENDIF
       ELSE
         XX1 = XTAN*X1
         XX2 = XTAN*X2
         YY1 = YTAN*Y1
         YY2 = YTAN*Y2
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            XX1 = XX1 + CURPX
            XX2 = XX2 + CURPX
          ELSE
            XX1 = XX1 + X0
            XX2 = XX2 + X0
         ENDIF
         IF (M1.GE.2) THEN
            YY1 = YY1 + CURPY
            YY2 = YY2 + CURPY
          ELSE
            YY1 = YY1 + Y0
            YY2 = YY2 + Y0
         ENDIF
      ENDIF

      ICL = CLIP
      IF ((M1.EQ.3.AND.ICLIP.GT.0).OR.(M2.NE.0.AND.ICLP2D.GT.0)) THEN
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF
      CALL GWIOLINE(XX1,YY1,XX2,YY2,MD)
      CURPX = XX2
      CURPY = YY2
      CLIP  = ICL

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_FPCIRCLE(X,Y,DX,DY,IC,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      REAL*8 X,Y,DX,DY

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(82,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND8BYTE(X,Y,1,2)
         CALL GSEND8BYTE(DX,DY,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      DX1   = DIAMX
      DY1   = DIAMY
      ID    = 0
      IF (MD.GT.1) ID = 1

      IF (M2.EQ.0) THEN
         DIAMX = DX
         DIAMY = DY
         XX    = X
         YY    = Y
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            XX = XX + CURPX
         ENDIF
         IF (M1.GE.2) THEN
            YY = YY + CURPY
         ENDIF
       ELSE
         XX    = XTAN*X
         YY    = YTAN*Y
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            XX = XX + CURPX
          ELSE
            XX = XX + X0
         ENDIF
         IF (M1.GE.2) THEN
            YY = YY + CURPY
          ELSE
            YY = YY + Y0
         ENDIF
         DIAMX = ABS(DX*XTAN)
         DIAMY = ABS(DY*YTAN)
      ENDIF

      ICL = CLIP
      IF ((M1.EQ.3.AND.ICLIP.GT.0).OR.(M2.NE.0.AND.ICLP2D.GT.0)) THEN
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF

      CALL GWIOCIRCLE(XX,YY,ID)
      CURPX = XX
      CURPY = YY
      CLIP  = ICL

      DIAMX = DX1
      DIAMY = DY1

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_FPPOLYGON(X,Y,N,IC,MODE)
*     MAXIMUM POLYGON NODE NUMBER IS NODMAX
      PARAMETER (NODMAX=500)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      REAL*8 X(*),Y(*)
      REAL   PX(NODMAX),PY(NODMAX)

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(83,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(N,4)
         CALL GSEND8BYTE(X,Y,N,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      N1 = N
      IF (N1.GT.NODMAX) N1 = NODMAX

      IF (M2.EQ.0) THEN
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            CCX = CURPX
          ELSE
            CCX = 0.0
         ENDIF
         IF (M1.GE.2) THEN
            CCY = CURPY
          ELSE
            CCY = 0.0
         ENDIF

         DO I = 1, N1
            PX(I) = X(I) + CCX
            PY(I) = Y(I) + CCY
         ENDDO
       ELSE
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            CCX = CURPX
          ELSE
            CCX = X0
         ENDIF
         IF (M1.GE.2) THEN
            CCY = CURPY
          ELSE
            CCY = Y0
         ENDIF

         DO I = 1, N1
            PX(I) = XTAN*X(I) + CCX
            PY(I) = YTAN*Y(I) + CCY
         ENDDO
      ENDIF

      ICL = CLIP
      IF ((M1.EQ.3.AND.ICLIP.GT.0).OR.(M2.NE.0.AND.ICLP2D.GT.0)) THEN
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF
      CALL GWIOPOLYGON(PX,PY,N1,MD)
      CLIP  = ICL
      CURPX = PX(1)
      CURPY = PY(1)

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_FPMARK(X,Y,DD1,DD2,ISPEC,IC,MODE)
      real*8 pi,dth
      PARAMETER (PI=3.141592653589793D0)
      PARAMETER (NODMAX=21)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /commarking/ diamx,diamy,diam1,diam2,diammag,mkspec
      real diamx,diamy,diam1,diam2,diammag
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      REAL*8 X,Y,DD1,DD2
      REAL PX(NODMAX),PY(NODMAX)
      REAL DPX(NODMAX),DPY(NODMAX)
      REAL PDIAM1,PDIAM2
      SAVE PDIAM1,PDIAM2,MPSPEC,DPX,DPY
      DATA MPSPEC/-1/

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(89,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(ISPEC,2)
         CALL GSEND8BYTE(X,Y,1,2)
         CALL GSEND8BYTE(DD1,DD2,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      D1   = DD1
      D2   = DD2
      IF (D1.NE.PDIAM1.OR.D2.NE.PDIAM2.OR.ISPEC.NE.MPSPEC) THEN
         MPSPEC = ISPEC
         PDIAM1 = D1
         PDIAM2 = D2
         IF (MPSPEC.LT.3)  MPSPEC = 0
         IF (MPSPEC.GT.20) MPSPEC = 20
         IF (MPSPEC.NE.0) THEN
            DTH = PI*2/MPSPEC
            DO I = 0, MPSPEC-1, 2
               DPX(I+1) =  PDIAM1*SIN(DTH*I)
               DPY(I+1) = -PDIAM1*COS(DTH*I)
            ENDDO
            DO I = 1, MPSPEC-1, 2
               DPX(I+1) =  PDIAM2*SIN(DTH*I)
               DPY(I+1) = -PDIAM2*COS(DTH*I)
            ENDDO
         ENDIF
      ENDIF

      ID    = 0
      IF (MD.GT.1) ID = 1

      IF (M2.EQ.0) THEN
         XX = X
         YY = Y
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            XX = XX + CURPX
         ENDIF
         IF (M1.GE.2) THEN
            YY = YY + CURPY
         ENDIF
       ELSE
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            CCX = CURPX
          ELSE
            CCX = X0
         ENDIF
         IF (M1.GE.2) THEN
            CCY = CURPY
          ELSE
            CCY = Y0
         ENDIF

         XX = XTAN*X + CCX
         YY = YTAN*Y + CCY
      ENDIF

      ICL = CLIP
      IF (M1.EQ.3.AND.ICLIP.GT.0) THEN 
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF
      IF (MPSPEC.EQ.0) THEN
         DX1   = DIAMX
         DY1   = DIAMY
         DIAMX = DD1*2
         DIAMY = DD2*2
         CALL GWIOCIRCLE(XX,YY,ID)
         DIAMX = DX1
         DIAMY = DY1
       ELSE
         DO I = 1, MPSPEC
            PX(I) = XX + DPX(I)
            PY(I) = YY + DPY(I)
         ENDDO
         CALL GWIOPOLYGON(PX,PY,MPSPEC,ID+1)
      ENDIF
      CURPX = XX
      CURPY = YY
      CLIP  = ICL

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_FPDOTS(X,Y,IC,N,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      REAL*8 X(*),Y(*)
      REAL PX,PY
      INTEGER IC(*)

      IF (IGCANVAS.LT.0) RETURN

      M1 = MODE/10
      M2 = M1/10
      M1 = MOD(M1,10)
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      ICL = CLIP
      IF (M1.EQ.3.AND.ICLIP.GT.0) THEN 
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF

      IF (ICOL256.EQ.0) THEN
         IC2 = 0
         IF (MD.EQ.0) THEN
            IF (IC(1).LT.0) IC2 = 1
          ELSE
            DO 2 I = 1, N
               IF (IC(I).LT.0) THEN
                  IC2 = 1
                  GO TO 3
               ENDIF
   2        CONTINUE
         ENDIF
   3     IF (IC2.NE.0) CALL STORECURRENTCOLMAP
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(85,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(N,4)
         CALL GSEND8BYTE(X,Y,N,2)
         IF (MD.EQ.0) THEN
            CALL GSENDBYTE(IC(1),2)
          ELSE
            DO 5 I = 1, N
               CALL GSENDBYTE(IC(I),2)
    5       CONTINUE           
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN

      IF (M2.EQ.0) THEN
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            CCX = CURPX
          ELSE
            CCX = 0.0
         ENDIF
         IF (M1.GE.2) THEN
            CCY = CURPY
          ELSE
            CCY = 0.0
         ENDIF

         IF (MD.EQ.0) THEN
            IC1 = IC(1)
            IF (IC1.LT.0) THEN
               ICM = 256
               IC0 = -IC1 - 1
             ELSE
               ICM = 2
               IC0 = IC1
            ENDIF
            CALL GWIOCOLOR(ICM,IC0)
            DO 10 I = 1, N
               PX = X(I) + CCX
               PY = Y(I) + CCY
               CALL GWIOPSET(PX,PY)
   10       CONTINUE
          ELSE
            DO 20 I = 1, N
               IC1 = IC(I)
               IF (IC1.LT.0) THEN
                  ICM = 256
                  IC0 = -IC1 - 1
                ELSE
                  ICM = 2
                  IC0 = IC1
               ENDIF
               CALL GWIOCOLOR(ICM,IC0)
               PX = X(I) + CCX
               PY = Y(I) + CCY
               CALL GWIOPSET(PX,PY)
   20       CONTINUE
         ENDIF
         CLIP  = ICL
         CURPX = X(1) + CCX
         CURPY = Y(1) + CCY
       ELSE
         IF (M1.EQ.1.OR.M1.EQ.3) THEN
            CCX = CURPX
          ELSE
            CCX = X0
         ENDIF
         IF (M1.GE.2) THEN
            CCY = CURPY
          ELSE
            CCY = Y0
         ENDIF

         IF (MD.EQ.0) THEN
            IC1 = IC(1)
            IF (IC1.LT.0) THEN
               ICM = 256
               IC0 = -IC1 - 1
             ELSE
               ICM = 2
               IC0 = IC1
            ENDIF
            CALL GWIOCOLOR(ICM,IC0)
            DO 30 I = 1, N
               PX = XTAN*X(I) + CCX
               PY = YTAN*Y(I) + CCY
               CALL GWIOPSET(PX,PY)
   30       CONTINUE
          ELSE
            DO 40 I = 1, N
               IC1 = IC(I)
               IF (IC1.LT.0) THEN
                  ICM = 256
                  IC0 = -IC1 - 1
                ELSE
                  ICM = 2
                  IC0 = IC1
               ENDIF
               CALL GWIOCOLOR(ICM,IC0)
               PX = XTAN*X(I) + CCX
               PY = YTAN*Y(I) + CCY
               CALL GWIOPSET(PX,PY)
   40       CONTINUE
         ENDIF
         CLIP  = ICL
         CURPX = PX
         CURPY = PY
      ENDIF

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_IDOTS(ICOL,IMIN,IMAX,JMIN,JMAX,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      common /comgpborder/ bx0,by0,bx1,by1,bx2,by2,ixoff,iyoff,clip
      real bx0,by0,bx1,by1,bx2,by2
      integer ixoff,iyoff,clip
      INTEGER ICOL(IMIN:IMAX,JMIN:JMAX)

      IF (IGCANVAS.LT.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      ICL = CLIP
      IF (M1.EQ.3.AND.ICLIP.GT.0) THEN 
         CLIP = 1
       ELSE
         CLIP = 0
      ENDIF

      IF (ICOL256.EQ.0) THEN
         IC2 = 0
         IF (MD.EQ.0) THEN
            IF (ICOL(IMIN,JMIN).LT.0) IC2 = 1
          ELSE
            DO J = JMIN, JMAX
               DO I = IMIN,IMAX
                  IF (ICOL(I,J).LT.0) THEN
                     IC2 = 1
                     GO TO 3
                  ENDIF
               ENDDO
            ENDDO
         ENDIF
   3     IF (IC2.NE.0) CALL STORECURRENTCOLMAP
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(90,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(N,4)
         IF (MD.EQ.0) THEN
            CALL GSENDBYTE(ICOL(IMIN,JMIN),2)
          ELSE
            DO J = JMIN, JMAX
               DO I = IMIN,IMAX
                  CALL GSENDBYTE(ICOL(I,J),2)
               ENDDO
            ENDDO
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN

      DO J = JMIN, JMAX
         DO I = IMIN,IMAX
            IC1 = ICOL(I,J)
            IF (IC1.LT.0) THEN
              ICM = 256
              IC0 = -IC1 - 1
             ELSE
              ICM = 2
              IC0 = IC1
            ENDIF
            CALL GWIOCOLOR(ICM,IC0)
            CALL GWIOIPSET(I,J)
         ENDDO
      ENDDO

      CALL GWIOBDFLUSH(0)

      RETURN
      END

      SUBROUTINE FR_2DTOFP(X,Y,SX,SY)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      REAL*8 X,Y,SX,SY

      SX = XTAN*X + X0
      SY = YTAN*Y + Y0

      RETURN
      END

      SUBROUTINE FR_3DTOFP(X,Y,Z,SX,SY)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      REAL*8 X,Y,Z,SX,SY

      IF (MODE3D.EQ.0) THEN
         SX    = XTAN*X + ZXTAN*Z + ZX0
         SY    = YTAN*Y + ZYTAN*Z + ZY0
       ELSE
         CALL COORDINXYZ(X,Y,Z,PX,PY)
         SX    = PX
         SY    = PY
      ENDIF

      RETURN
      END

      SUBROUTINE FR_2DMOVE(X,Y,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      REAL*8 X,Y,X1,Y1

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(86,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSEND8BYTE(X,Y,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (IFRAM.EQ.0) RETURN

      IF (MODE.EQ.1.OR.MODE.EQ.3) THEN
         X1 = (XMAX-XMIN)*X + XMIN
         CURPX = XTAN*X1 + X0
       ELSE
         CURPX = XTAN*X + X0
      ENDIF
      IF (MODE.GE.2) THEN
         Y1 = (YMAX-YMIN)*Y + YMIN
         CURPY = YTAN*Y1 + Y0
       ELSE
         CURPY = YTAN*Y + Y0
      ENDIF
      IF (MODE.EQ.0.AND.ICLP2D.NE.0) THEN
         ICLIP = 1
       ELSE 
         ICLIP = 0
      ENDIF

      RETURN
      END

      SUBROUTINE FR_3DMOVE(X,Y,Z,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CURRE3DPOSCOM/ CUR3X,CUR3Y,CUR3Z
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X,Y,Z,X1,Y1,Z1

      IF (IGCANVAS.LT.0) RETURN

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(87,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSEND38BYTE(X,Y,Z,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IF (IFRAM.EQ.0) RETURN

      IF (MOD(MODE,2).EQ.1) THEN
         X1 = (XMAX-XMIN)*X + XMIN
       ELSE
         X1 = X
      ENDIF
      IF (MOD(MODE/2,2).EQ.1) THEN
         Y1 = (YMAX-YMIN)*Y + YMIN
       ELSE
         Y1 = Y
      ENDIF
      IF (MODE.GE.4) THEN
         Z1 = (ZMAX-ZMIN)*Z + ZMIN
       ELSE
         Z1 = Z
      ENDIF

      CUR3X = X1
      CUR3Y = Y1
      CUR3Z = Z1

      IF (MODE3D.EQ.0) THEN
         CURPX = XTAN*X1 + ZXTAN*Z1 + ZX0
         CURPY = YTAN*Y1 + ZYTAN*Z1 + ZY0
         ICLIP = 0
       ELSE
         CALL COORDINXYZ(X1,Y1,Z1,CURPX,CURPY)
         IF (MODE.EQ.0.AND.ICLP3D.NE.0) THEN
            IF (X1.LT.tdx1.OR.X1.GT.tdx2.OR.
     +                 Y1.LT.tdy1.OR.Y1.GT.tdy2.OR.
     +                       Z1.LT.tdz1.OR.Z1.GT.tdz2) THEN
               ICLIP = -1
             ELSE
               ICLIP = 0
            ENDIF
          ELSE 
            ICLIP = 0
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_3DPOLYGON(X,Y,Z,N,IC,MODE)
*     MAXIMUM POLYGON NODE NUMBER IS NODMAX
      PARAMETER (NODMAX=500)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CURRE3DPOSCOM/ CUR3X,CUR3Y,CUR3Z
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 X(*),Y(*),Z(*)
      REAL*8 XX(NODMAX),YY(NODMAX),ZZ(NODMAX)
      REAL   PX(NODMAX),PY(NODMAX)

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(88,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(N,4)
         CALL GSEND38BYTE(X,Y,Z,N,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      IF (IFRAM.EQ.0) RETURN

      N1 = N
      IF (N1.GT.NODMAX) N1 = NODMAX

      IF (MOD(M1,2).EQ.1) THEN
         DO I = 1, N1
            XX(I) = CUR3X + (XMAX-XMIN)*X(I)
         ENDDO
       ELSE
         DO I = 1, N1
            XX(I) = CUR3X + X(I)
         ENDDO
      ENDIF
      IF (MOD(M1/2,2).EQ.1) THEN
         DO I = 1, N1
            YY(I) = CUR3Y + (YMAX-YMIN)*Y(I)
         ENDDO
       ELSE
         DO I = 1, N1
            YY(I) = CUR3Y + Y(I)
         ENDDO
      ENDIF
      IF (M1.GE.4) THEN
         DO I = 1, N1
            ZZ(I) = CUR3Z + (ZMAX-ZMIN)*Z(I)
         ENDDO
       ELSE
         DO I = 1, N1
            ZZ(I) = CUR3Z + Z(I)
         ENDDO
      ENDIF
      IF (MODE3D.EQ.0) THEN
         DO I = 1, N1
            PX(I) = XTAN*XX(I) + ZXTAN*ZZ(I) + ZX0
            PY(I) = YTAN*YY(I) + ZYTAN*ZZ(I) + ZY0
         ENDDO
       ELSE
         DO I = 1, N1
            CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I),PY(I))
         ENDDO
      ENDIF

      CALL GWIOPOLYGON(PX,PY,N1,MD)
*      CLIP  = ICL
      CURPX = PX(1)
      CURPY = PY(1)

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_3DLINE(X1,Y1,Z1,X2,Y2,Z2,IC,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CURRE3DPOSCOM/ CUR3X,CUR3Y,CUR3Z
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 X1,Y1,Z1,X2,Y2,Z2,XX1,YY1,ZZ1,XX2,YY2,ZZ2

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(90,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND38BYTE(X1,Y1,Z1,1,2)
         CALL GSEND38BYTE(X2,Y2,Z2,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      IF (IFRAM.EQ.0) RETURN

      IF (MOD(M1,2).EQ.1) THEN
         XX1 = (XMAX-XMIN)*X1
         XX2 = (XMAX-XMIN)*X2
       ELSE
         XX1 = X1
         XX2 = X2
      ENDIF
      IF (MOD(M1/2,2).EQ.1) THEN
         YY1 = (YMAX-YMIN)*Y1
         YY2 = (YMAX-YMIN)*Y2
       ELSE
         YY1 = Y1
         YY2 = Y2
      ENDIF
      IF (M1.GE.4) THEN
         ZZ1 = (ZMAX-ZMIN)*Z1
         ZZ2 = (ZMAX-ZMIN)*Z2
       ELSE
         ZZ1 = Z1
         ZZ2 = Z2
      ENDIF

      IF (ICLP3D.EQ.0) THEN
         IF (MODE3D.EQ.0) THEN
            PX1 = XTAN*XX1 + ZXTAN*ZZ1 + ZX0
            PY1 = YTAN*YY1 + ZYTAN*ZZ1 + ZY0
            PX2 = XTAN*XX2 + ZXTAN*ZZ2 + ZX0
            PY2 = YTAN*YY2 + ZYTAN*ZZ2 + ZY0
          ELSE
            CALL COORDINXYZ(XX1,YY1,ZZ1,PX1,PY1)
            CALL COORDINXYZ(XX2,YY2,ZZ2,PX2,PY2)
            CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
         ENDIF
       ELSE
         CALL GWIOCLIP3D(XX1,YY1,ZZ1,XX2,YY2,ZZ2,ICL)
         IF (ICL.NE.0) THEN
            CALL COORDINXYZ(XX1,YY1,ZZ1,PX1,PY1)
            CALL COORDINXYZ(XX2,YY2,ZZ2,PX2,PY2)
            CALL GWIOLINE(PX1,PY1,PX2,PY2,0)
         ENDIF
      ENDIF

*      CLIP  = ICL
      CURPX = PX2
      CURPY = PY2

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_3DCIRCLE(X,Y,Z,RX,RY,RZ,RX1,RY1,RZ1,IC,MODE)
*     MAXIMUM POLYGON NODE NUMBER IS NODMAX
      PARAMETER (NODMAX=512)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CURRE3DPOSCOM/ CUR3X,CUR3Y,CUR3Z
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 X,Y,Z,RX,RY,RZ,RX1,RY1,RZ1
      REAL*8 XS,YS,ZS,SX,SY,SZ,SX1,SY1,SZ1,NX,NY,NZ,NN,VX,VY,VZ,VV,RR,PI
      REAL*8 XX(NODMAX),YY(NODMAX),ZZ(NODMAX),DT,OM2
      REAL   PX(NODMAX),PY(NODMAX)
      INTEGER IV(NODMAX)

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(91,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSEND38BYTE(X,Y,Z,1,2)
         CALL GSEND38BYTE(RX,RY,RZ,1,2)
         CALL GSEND38BYTE(RX1,RY1,RZ1,1,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      IF (IFRAM.EQ.0) RETURN

      IF (MOD(M1,2).EQ.1) THEN
         XS  = (XMAX-XMIN)*X
         SX  = (XMAX-XMIN)*RX
         SX1 = (XMAX-XMIN)*RX1
       ELSE
         XS  = X
         SX  = RX
         SX1 = RX1
      ENDIF
      IF (MOD(M1/2,2).EQ.1) THEN
         YS  = (YMAX-YMIN)*Y
         SY  = (YMAX-YMIN)*RY
         SY1 = (YMAX-YMIN)*RY1
       ELSE
         YS  = Y
         SY  = RY
         SY1 = RY1
      ENDIF
      IF (M1.GE.4) THEN
         ZS  = (ZMAX-ZMIN)*Z
         SZ  = (ZMAX-ZMIN)*RZ
         SZ1 = (ZMAX-ZMIN)*RZ1
       ELSE
         ZS  = Z
         SZ  = RZ
         SZ1 = RZ1
      ENDIF
      SRX = SX
      SRY = SY
      SRZ = SZ

      N1 = NODMAX
      IF (MD/2.EQ.0) THEN
         NX = SY*SZ1-SZ*SY1
         NY = SZ*SX1-SX*SZ1
         NZ = SX*SY1-SY*SX1
         NN = NX*NX+NY*NY+NZ*NZ
         IF (NN.EQ.0) RETURN
         NN = SQRT(NN)
         NX = NX/NN
         NY = NY/NN
         NZ = NZ/NN
         VX = NY*SZ-NZ*SY
         VY = NZ*SX-NX*SZ
         VZ = NX*SY-NY*SX
         VV = VX*VX+VY*VY+VZ*VZ
         RR = SX*SX+SY*SY+SZ*SZ
         PI = 3.141592653589793D0
         OM2 = SQRT(VV/RR)
         VX = VX/OM2
         VY = VY/OM2
         VZ = VZ/OM2
         DT = PI*2/(NODMAX)
       ELSE
         NN = SX1*SX1+SY1*SY1+SZ1*SZ1
         IF (NN.EQ.0.OR.SX.EQ.0) RETURN
         NN = SQRT(NN)
         NX = SX1/NN
         NY = SY1/NN
         NZ = SZ1/NN
         SX1 =  0
         SY1 =  NZ
         SZ1 = -NY
         NN = NY*NY+NZ*NZ
         IF (NN.EQ.0) THEN
            SX1 = -NZ
            SY1 =  0
            SZ1 =  NX
            NN = NX*NX+NZ*NZ
         ENDIF
         NN = SX/SQRT(NN)
         SX = SX1*NN
         SY = SY1*NN
         SZ = SZ1*NN
         VX = NY*SZ-NZ*SY
         VY = NZ*SX-NX*SZ
         VZ = NX*SY-NY*SX
         VV = VX*VX+VY*VY+VZ*VZ
         RR = SX*SX+SY*SY+SZ*SZ
         PI = 3.141592653589793D0
         OM2 = SQRT(VV/RR)
         VX = VX/OM2
         VY = VY/OM2
         VZ = VZ/OM2
         DT = PI*2/(NODMAX)
      ENDIF

      XX(1) = XS + SX
      YY(1) = YS + SY
      ZZ(1) = ZS + SZ
      DO I = 2, N1
         SX = SX + VX*DT
         SY = SY + VY*DT
         SZ = SZ + VZ*DT
         VX    = VX - SX*DT
         VY    = VY - SY*DT
         VZ    = VZ - SZ*DT
         XX(I) = XS + SX
         YY(I) = YS + SY
         ZZ(I) = ZS + SZ
      ENDDO

      NG   = 1
      IF (MODE3D.EQ.0) THEN
         DO I = 1, N1
            PX(I) = XTAN*XX(I) + ZXTAN*ZZ(I) + ZX0
            PY(I) = YTAN*YY(I) + ZYTAN*ZZ(I) + ZY0
         ENDDO
       ELSE
         IF (MOD(MD,2).NE.0) THEN
            IF (MDPROJ.EQ.0) THEN
               ZO  = ZPX*X + ZPY*Y + ZPZ*Z
               DO I = 1, N1
                  ZP  = ZPX*XX(I) + ZPY*YY(I) + ZPZ*ZZ(I)
                  IF (ZP.GE.ZO) THEN
                     IV(I) = 1
                   ELSE
                     IV(I) = 0
                  ENDIF
               ENDDO
             ELSE
               XO  = XPX*X + XPY*Y + XPZ*Z + XP0
               YO  = YPX*X + YPY*Y + YPZ*Z + YP0
               ZO1 = ZPX*X + ZPY*Y + ZPZ*Z + ZP0
               ZO  = ZSCALE*(1 - ZO1)
               RO2 = XO*XO+YO*YO+ZO*ZO
               XS  = XPX*SRX + XPY*SRY + XPZ*SRZ
               YS  = YPX*SRX + YPY*SRY + YPZ*SRZ
               ZS  = ZPX*SRX + ZPY*SRY + ZPZ*SRZ + ZO1
               ZS  = ZSCALE*(1 - ZS)
               RS  = XS*XS+YS*YS+(ZS-ZO)*(ZS-ZO)
               RO  = SQRT(RO2)
               RR0 = RO*(1-RS/RO2)
               XO  = XO/RO
               YO  = YO/RO
               ZO  = ZO/RO
               DO I = 1, N1
                  XP  = XPX*XX(I) + XPY*YY(I) + XPZ*ZZ(I) + XP0
                  YP  = YPX*XX(I) + YPY*YY(I) + YPZ*ZZ(I) + YP0
                  ZP  = ZPX*XX(I) + ZPY*YY(I) + ZPZ*ZZ(I) + ZP0
                  ZP  = ZSCALE*(1 - ZP)
                  RC  = XP*XO+YP*YO+ZP*ZO
                  IF (RC.LE.RR0) THEN
                     IV(I) = 1
                   ELSE
                     IV(I) = 0
                  ENDIF
               ENDDO
            ENDIF
            IF (IV(1).EQ.0.OR.IV(N1).EQ.0) THEN
               I1 = 0
               DO I = 1, N1
                  IF (IV(I).NE.0) THEN
                     I1 = I1 + 1
                     CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I1),PY(I1))
                  ENDIF
               ENDDO
             ELSE
               DO I = 2, N1-1
                  IF (IV(I).EQ.0) GO TO 100
               ENDDO
  100          IF (I.LT.N1) THEN
                  I0 = I
                  I1 = 0
                  DO I = I0+1, N1
                     IF (IV(I).NE.0) THEN
                        I1 = I1 + 1
                        CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I1),PY(I1))
                     ENDIF
                  ENDDO
                  DO I = 1, I0-1
                     IF (IV(I).NE.0) THEN
                        I1 = I1 + 1
                        CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I1),PY(I1))
                     ENDIF
                  ENDDO
                ELSE
                  DO I = 1, N1
                     CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I),PY(I))
                  ENDDO
               ENDIF
            ENDIF
            IF (I1.LT.N1) NG = 0
            N1 = I1
          ELSE
            DO I = 1, N1
               CALL COORDINXYZ(XX(I),YY(I),ZZ(I),PX(I),PY(I))
            ENDDO
         ENDIF
      ENDIF

      CALL GWIOPOLYGON(PX,PY,N1,NG)
*      CLIP  = ICL
      CURPX = PX(1)
      CURPY = PY(1)

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_2DPOLYGON(X,Y,N,IC,MODE)
*     MAXIMUM POLYGON NODE NUMBER IS NODMAX
      PARAMETER (NODMAX=50)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,GX,GY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      REAL*8 X(*),Y(*)
      REAL*8 XX(NODMAX),YY(NODMAX)
      REAL   PX(NODMAX),PY(NODMAX)

      IF (IGCANVAS.LT.0) RETURN

      IF (IC.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP
      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(8,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(IC,2)
         CALL GSENDBYTE(N,4)
         CALL GSEND8BYTE(X,Y,N,2)
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(1)

      IF (IC.LT.0) THEN
        ICM = 256
        IC0 = -IC - 1
       ELSE
        ICM = 2
        IC0 = IC
      ENDIF
      CALL GWIOCOLOR(ICM,IC0)

      IF (IFRAM.EQ.0) RETURN

      N1 = N
      IF (N1.GT.NODMAX) N1 = NODMAX

      IF (MOD(M1,2).EQ.1) THEN
         DO I = 1, N1
            XX(I) = (XMAX-XMIN)*X(I)
         ENDDO
       ELSE
         DO I = 1, N1
            XX(I) = X(I)
         ENDDO
      ENDIF
      IF (MOD(M1/2,2).EQ.1) THEN
         DO I = 1, N1
            YY(I) = (YMAX-YMIN)*Y(I)
         ENDDO
       ELSE
         DO I = 1, N1
            YY(I) = Y(I)
         ENDDO
      ENDIF

      DO I = 1, N1
         PX(I) = XTAN*XX(I) + X0
         PY(I) = YTAN*YY(I) + Y0
      ENDDO

      CALL GWIOPOLYGON(PX,PY,N1,MD)
*      CLIP  = ICL
      CURPX = PX(1)
      CURPY = PY(1)

      CALL GWIOBDFLUSH(0)
      RETURN
      END

      SUBROUTINE FR_3DDOTS(X,Y,Z,IC,N,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /CLIPPINGCOM/ ICLP2D,ICLP3D
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /CURREPOSCOM/ CURPX,CURPY,ICLIP
      COMMON /CURRE3DPOSCOM/ CUR3X,CUR3Y,CUR3Z
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8 X(*),Y(*),Z(*)
      REAL PX,PY
      INTEGER IC(*)

      IF (IGCANVAS.LT.0) RETURN

      M1 = MODE/10
      MD = MOD(MODE,10)
      IF (M1.EQ.3.AND.ICLIP.LT.0) RETURN 

      IF (ICOL256.EQ.0) THEN
         IC2 = 0
         IF (MD.EQ.0) THEN
            IF (IC(1).LT.0) IC2 = 1
          ELSE
            DO 2 I = 1, N
               IF (IC(I).LT.0) THEN
                  IC2 = 1
                  GO TO 3
               ENDIF
   2        CONTINUE
         ENDIF
   3     IF (IC2.NE.0) CALL STORECURRENTCOLMAP
      ENDIF

      IF (IGPLT.GT.0) THEN
         CALL GSENDBYTE(92,1)
         CALL GSENDBYTE(MODE,1)
         CALL GSENDBYTE(N,4)
         CALL GSEND38BYTE(X,Y,Z,N,2)
         IF (MD.EQ.0) THEN
            CALL GSENDBYTE(IC(1),2)
          ELSE
            DO 5 I = 1, N
               CALL GSENDBYTE(IC(I),2)
    5       CONTINUE           
         ENDIF
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      IXBIT = MOD(M1,2)
      IYBIT = MOD(M1/2,2)
      IZBIT = MOD(M1/4,2)

      IF (MD.EQ.0) THEN
         IC1 = IC(1)
         IF (IC1.LT.0) THEN
            ICM = 256
            IC0 = -IC1 - 1
          ELSE
            ICM = 2
            IC0 = IC1
         ENDIF
         CALL GWIOCOLOR(ICM,IC0)

         IF (ICLP3D.EQ.0) THEN
            IF (IXBIT.EQ.0) THEN
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 100 I = 1, N
                           PX = XTAN*X(I) + ZXTAN*Z(I) + ZX0
                           PY = YTAN*Y(I) + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
  100                   CONTINUE
                      ELSE
                        DO 101 I = 1, N
                           CALL COORDINXYZ(X(I),Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
  101                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 102 I = 1, N
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*X(I) + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*Y(I) + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
  102                   CONTINUE
                      ELSE
                        DO 103 I = 1, N
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(X(I),Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
  103                   CONTINUE
                     ENDIF
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 110 I = 1, N
                           YY1 = (YMAX-YMIN)*Y(I)
                           PX = XTAN*X(I) + ZXTAN*Z(I) + ZX0
                           PY = YTAN*YY1  + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
  110                   CONTINUE
                      ELSE
                        DO 111 I = 1, N
                           YY1 = (YMAX-YMIN)*Y(I)
                           CALL COORDINXYZ(X(I),YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
  111                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 112 I = 1, N
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*X(I) + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*YY1  + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
  112                   CONTINUE
                      ELSE
                        DO 113 I = 1, N
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(X(I),YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
  113                   CONTINUE
                     ENDIF
                  ENDIF
               ENDIF
             ELSE
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 200 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           PX = XTAN*XX1  + ZXTAN*Z(I) + ZX0
                           PY = YTAN*Y(I) + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
  200                   CONTINUE
                      ELSE
                        DO 201 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           CALL COORDINXYZ(XX1,Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
  201                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 202 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*XX1  + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*Y(I) + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
  202                   CONTINUE
                      ELSE
                        DO 203 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(XX1,Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
  203                   CONTINUE
                     ENDIF
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 210 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           PX = XTAN*XX1  + ZXTAN*Z(I) + ZX0
                           PY = YTAN*YY1  + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
  210                   CONTINUE
                      ELSE
                        DO 211 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           CALL COORDINXYZ(XX1,YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
  211                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 212 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*XX1  + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*YY1  + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
  212                   CONTINUE
                      ELSE
                        DO 213 I = 1, N
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(XX1,YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
  213                   CONTINUE
                     ENDIF
                  ENDIF
               ENDIF
            ENDIF
*           ICLP3D = 1, CLIPPPING CASE ONLY REAL 3D MODE
          ELSE
            IF (IXBIT.EQ.0) THEN
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     DO 301 I = 1, N
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           CALL COORDINXYZ(X(I),Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  301                CONTINUE
                   ELSE
                     DO 303 I = 1, N
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1.LE.tdz2) THEN
                           CALL COORDINXYZ(X(I),Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  303                CONTINUE
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     DO 311 I = 1, N
                        YY1 = (YMAX-YMIN)*Y(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           CALL COORDINXYZ(X(I),YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  311                CONTINUE
                   ELSE
                     DO 313 I = 1, N
                        YY1 = (YMAX-YMIN)*Y(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           CALL COORDINXYZ(X(I),YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  313                CONTINUE
                  ENDIF
               ENDIF
             ELSE
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     DO 401 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           CALL COORDINXYZ(XX1,Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  401                CONTINUE
                   ELSE
                     DO 403 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           CALL COORDINXYZ(XX1,Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  403                CONTINUE
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     DO 411 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        YY1 = (YMAX-YMIN)*Y(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           CALL COORDINXYZ(XX1,YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  411                CONTINUE
                   ELSE
                     DO 413 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        YY1 = (YMAX-YMIN)*Y(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           CALL COORDINXYZ(XX1,YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
  413                CONTINUE
                  ENDIF
               ENDIF
            ENDIF
         ENDIF

       ELSE
*        MULTIPLE COLOR MODE
         IF (ICLP3D.EQ.0) THEN
            IF (IXBIT.EQ.0) THEN
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 1100 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           PX = XTAN*X(I) + ZXTAN*Z(I) + ZX0
                           PY = YTAN*Y(I) + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
 1100                   CONTINUE
                      ELSE
                        DO 1101 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(X(I),Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
 1101                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 1102 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*X(I) + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*Y(I) + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
 1102                   CONTINUE
                      ELSE
                        DO 1103 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(X(I),Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
 1103                   CONTINUE
                     ENDIF
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 1110 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           YY1 = (YMAX-YMIN)*Y(I)
                           PX = XTAN*X(I) + ZXTAN*Z(I) + ZX0
                           PY = YTAN*YY1  + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
 1110                   CONTINUE
                      ELSE
                        DO 1111 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           YY1 = (YMAX-YMIN)*Y(I)
                           CALL COORDINXYZ(X(I),YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
 1111                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 1112 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*X(I) + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*YY1  + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
 1112                   CONTINUE
                      ELSE
                        DO 1113 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(X(I),YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
 1113                   CONTINUE
                     ENDIF
                  ENDIF
               ENDIF
             ELSE
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 1200 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           PX = XTAN*XX1  + ZXTAN*Z(I) + ZX0
                           PY = YTAN*Y(I) + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
 1200                   CONTINUE
                      ELSE
                        DO 1201 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           CALL COORDINXYZ(XX1,Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
 1201                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 1202 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*XX1  + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*Y(I) + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
 1202                   CONTINUE
                      ELSE
                        DO 1203 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(XX1,Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
 1203                   CONTINUE
                     ENDIF
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     IF (MODE3D.EQ.0) THEN
                        DO 1210 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           PX = XTAN*XX1  + ZXTAN*Z(I) + ZX0
                           PY = YTAN*YY1  + ZYTAN*Z(I) + ZY0
                           CALL GWIOPSET(PX,PY)
 1210                   CONTINUE
                      ELSE
                        DO 1211 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           CALL COORDINXYZ(XX1,YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
 1211                   CONTINUE
                     ENDIF
                   ELSE
                     IF (MODE3D.EQ.0) THEN
                        DO 1212 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           PX = XTAN*XX1  + ZXTAN*ZZ1 + ZX0
                           PY = YTAN*YY1  + ZYTAN*ZZ1 + ZY0
                           CALL GWIOPSET(PX,PY)
 1212                   CONTINUE
                      ELSE
                        DO 1213 I = 1, N
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           XX1 = (XMAX-XMIN)*X(I)
                           YY1 = (YMAX-YMIN)*Y(I)
                           ZZ1 = (ZMAX-ZMIN)*Z(I)
                           CALL COORDINXYZ(XX1,YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
 1213                   CONTINUE
                     ENDIF
                  ENDIF
               ENDIF
            ENDIF
*           ICLP3D = 1, CLIPPPING CASE ONLY REAL 3D MODE
          ELSE
            IF (IXBIT.EQ.0) THEN
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     DO 1301 I = 1, N
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(X(I),Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1301                CONTINUE
                   ELSE
                     DO 1303 I = 1, N
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1.LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(X(I),Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1303                CONTINUE
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     DO 1311 I = 1, N
                        YY1 = (YMAX-YMIN)*Y(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(X(I),YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1311                CONTINUE
                   ELSE
                     DO 1313 I = 1, N
                        YY1 = (YMAX-YMIN)*Y(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (X(I).GE.tdx1.AND.X(I).LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(X(I),YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1313                CONTINUE
                  ENDIF
               ENDIF
             ELSE
               IF (IYBIT.EQ.0) THEN
                  IF(IZBIT.EQ.0) THEN
                     DO 1401 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(XX1,Y(I),Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1401                CONTINUE
                   ELSE
                     DO 1403 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      Y(I).GE.tdy1.AND.Y(I).LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(XX1,Y(I),ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1403                CONTINUE
                  ENDIF
                ELSE
                  IF(IZBIT.EQ.0) THEN
                     DO 1411 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        YY1 = (YMAX-YMIN)*Y(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      Z(I).GE.tdz1.AND.Z(I).LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(XX1,YY1,Z(I),PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1411                CONTINUE
                   ELSE
                     DO 1413 I = 1, N
                        XX1 = (XMAX-XMIN)*X(I)
                        YY1 = (YMAX-YMIN)*Y(I)
                        ZZ1 = (ZMAX-ZMIN)*Z(I)
                        IF (XX1 .GE.tdx1.AND.XX1 .LE.tdx2.AND.
     +                      YY1 .GE.tdy1.AND.YY1 .LE.tdy2.AND.
     +                      ZZ1 .GE.tdz1.AND.ZZ1 .LE.tdz2) THEN
                           IC1 = IC(I)
                           IF (IC1.LT.0) THEN
                              ICM = 256
                              IC0 = -IC1 - 1
                            ELSE
                              ICM = 2
                              IC0 = IC1
                           ENDIF
                           CALL GWIOCOLOR(ICM,IC0)
                           CALL COORDINXYZ(XX1,YY1,ZZ1,PX,PY)
                           CALL GWIOPSET(PX,PY)
                        ENDIF
 1413                CONTINUE
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
      ENDIF

      CURPX = PX
      CURPY = PY

      CALL GWIOBDFLUSH(0)
      RETURN
      END
