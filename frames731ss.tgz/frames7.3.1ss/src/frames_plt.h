/***************************************************************
 *      F r a m e s  V.7.3                                     *
 *      Header for Data Restoring Routines from PLT File       *
 ***************************************************************
*/

#ifndef PLT_DEFINITION

#ifndef PLT_NOFUNCTIONS

typedef struct {
	int com;		
	int n;			int c;			int md;
	int nx;			int ny;			int nz;
	int size;		int wsize;
	double x1;		double y1;		double z1;
	double x2;		double y2;		double z2;
	double *X;		double *Y;		double *Z;		double *F;		int *W;
} frames_data;

typedef struct {
	int com;		
	int n;			int c;			int md;
	int nx;			int ny;			int nz;
	int size;		int wsize;
	double x1;		double y1;		double z1;
	double x2;		double y2;		double z2;
	char *chx;		char *chy;		char *chz;		int *W;
} frames_str;

#define DATA_LEVEL			10
#define INLAY_LEVEL			20
#define LABEL_LEVEL			30
#define PRIM_LEVEL			40
#define FRAME_LEVEL			50
#define VIEW_LEVEL			60
#define SET_LEVEL			70
#define CNTL_LEVEL			90
#define END_LEVEL			100
#define NONCOM_LEVEL		200

#define DEFAULT_LEVEL	INLAY_LEVEL

int 	open_plt_file(char *);
int 	get_frames_command(int);
int		get_frames_data(frames_data *);
void	unget_frames_command(void);
void	free_frames_data(frames_data *);
void	change_frames_level(int);

#endif

#define FRAMES_VIEW2D		1
#define FRAMES_FRAME2D		2
#define FRAMES_XYNAME		3
#define FRAMES_GRAPH2D		4
#define FRAMES_DRAW2D		5
#define FRAMES_VECTOR2D		6
#define FRAMES_ASPECT2D		7
#define FRAMES_2DPOLYGON	8
#define FRAMES_CONTOUR		11
#define FRAMES_SETCONTOUR	12
#define FRAMES_LOGAXIS		13
#define FRAMES_COLORBAR		14
#define FRAMES_TRICONTOUR	15
#define FRAMES_SQRCONTOUR	16
#define FRAMES_PMVIEW		31
#define FRAMES_PMFRAME		32
#define FRAMES_XYZNAME		33
#define FRAMES_PMGRAPH		34
#define FRAMES_PMDRAW		35
#define FRAMES_PMSET		41
#define FRAMES_HCLEAR		42
#define FRAMES_PROFILE		51
#define FRAMES_PROFILE3D	52
#define FRAMES_SURFACE		52
#define FRAMES_VIEW3D		61
#define FRAMES_ANGLE3D		62
#define FRAMES_ASPECT3D		63
#define FRAMES_ROTATE		64
#define FRAMES_FRAME3D		65
#define FRAMES_GRAPH3D		66
#define FRAMES_DRAW3D		67
#define FRAMES_VECTOR3D		68
#define FRAMES_PROJECT		69
#define FRAMES_CONTOUR3D	70
#define FRAMES_SLICES		70
#define FRAMES_TRIPROFILE	71
#define FRAMES_TRISURFACE	71
#define FRAMES_ISOSURFACE	72
#define FRAMES_CLIP3D		73
#define FRAMES_VOLRENDER	74
#define FRAMES_FPLINE		81
#define FRAMES_FPCIRCLE		82
#define FRAMES_FPPOLYGON	83
#define FRAMES_FPCHARS		84
#define FRAMES_FPDOTS		85
#define FRAMES_2DMOVE		86
#define FRAMES_3DMOVE		87
#define FRAMES_3DPOLYGON	88
#define FRAMES_FPMARK		89
#define FRAMES_3DLINE		90
#define FRAMES_3DCIRCLE		91
#define FRAMES_3DDOTS		92
#define FRAMES_SETCIRCLE	101
#define FRAMES_SETARROW		102
#define FRAMES_SET2DRGN		103
#define FRAMES_SETSTEP		104
#define FRAMES_SETFRAME		105
#define FRAMES_SET3DRGN		106
#define FRAMES_SETMARK		107
#define FRAMES_SETBAR		108
#define FRAMES_SETLIGHT		109
#define FRAMES_SETSURFACE	110
#define FRAMES_SETVOLUME	111
#define FRAMES_GNOTES		116
#define FRAMES_FILECHAR		117
#define FRAMES_FILEINT		118
#define FRAMES_FILEDBLE		119
#define FRAMES_HLSSET		123
#define FRAMES_GPAGEC		124
#define FRAMES_GPAGE		125
#define FRAMES_GCLEAR		126
#define FRAMES_GEND			127

#define PLT_DEFINITION

#endif
