/*****************************************
 *      F r a m e s  V.7.2               *
 *      Header for Frames Routines       *
 *****************************************
*/

#ifndef FRAMES_HEADERS

/*#define CompaqVisual*/
#ifdef CompaqVisual
#define isosurfacecore			__stdcall ISOSURFACECORE
#define malloctrisurfacecore	__stdcall MALLOCTRISURFACECORE
#define mallocandsurfacecore	__stdcall MALLOCANDSURFACECORE
#define mallocsphgraphcore		__stdcall MALLOCSPHGRAPHCORE
#define withnormalvector		__stdcall WITHNORMALVECTOR
#define setgfilemaxpage			__stdcall SETGFILEMAXPAGE
#define gsendhlsdataproc		__stdcall GSENDHLSDATAPROC
#define gsendsrealproc			__stdcall GSENDSREALPROC
#define gsend1bytechars			__stdcall GSEND1BYTECHARS
#define gsend1bytebytes			__stdcall GSEND1BYTEBYTES
#define flushbufferpages		__stdcall FLUSHBUFFERPAGES
#define gcanvasbackgroundhls	__stdcall GCANVASBACKGROUNDHLS
#define gcanvaswindowsize		__stdcall GCANVASWINDOWSIZE
#define getcanvaswindowsize		__stdcall GETCANVASWINDOWSIZE
#define gcanvasgraphstep		__stdcall GCANVASGRAPHSTEP
#define gcanvascharsize			__stdcall GCANVASCHARSIZE
#define getcanvaswindowstatus	__stdcall GETCANVASWINDOWSTATUS
#define setcanvaswindownumber	__stdcall SETCANVASWINDOWNUMBER
#define exchangefandbcolor		__stdcall EXCHANGEFANDBCOLOR
#define cleargcanvasall			__stdcall CLEARGCANVASALL
#define gcanvascreate			__stdcall GCANVASCREATE
#define gcanvasclose			__stdcall GCANVASCLOSE
#define gcanvasallclose			__stdcall GCANVASALLCLOSE
#define gcanvascheck			__stdcall GCANVASCHECK
#define getcanvasname			__stdcall GETCANVASNAME
#define setcanvasbackground		__stdcall SETCANVASBACKGROUND
#define gcanvasgifoption		__stdcall GCANVASGIFOPTION
#define gcanvasagifoption		__stdcall GCANVASAGIFOPTION
#define setcanvaspointer		__stdcall SETCANVASPOINTER
#define setcanvasoutlet			__stdcall SETCANVASOUTLET
#define getcanvasoutlet			__stdcall GETCANVASOUTLET
#define advancecanvaspage		__stdcall ADVANCECANVASPAGE
#define initializecanvas		__stdcall INITIALIZECANVAS
#define storehlstables			__stdcall STOREHLSTABLES

#define giffilecolor			__stdcall GIFFILECOLOR
#define giffiledot				__stdcall GIFFILEDOT
#define giffileline				__stdcall GIFFILELINE
#define giffilearrow			__stdcall GIFFILEARROW
#define giffilepolygon			__stdcall GIFFILEPOLYGON
#define giffilegradrectangle	__stdcall GIFFILEGRADRECTANGLE
#define giffilecirc				__stdcall GIFFILECIRC
#define giffilegradcirc			__stdcall GIFFILEGRADCIRC
#define giffilesetrgb			__stdcall GIFFILESETRGB
#define giffilechr				__stdcall GIFFILECHR
#define giffilechr10			__stdcall GIFFILECHR10
#define gifoutputend			__stdcall GIFOUTPUTEND
#define gifoutputnext			__stdcall GIFOUTPUTNEXT

#define isotriangles			ISOTRIANGLES
#define trisurfacemain			TRISURFACEMAIN
#define dsfill3dtriangs			DSFILL3DTRIANGS
#define dsfill3dwithvect		DSFILL3DWITHVECT
#define rdnormpoints			RDNORMPOINTS
#define surface3dmain			SURFACE3DMAIN
#define spheregraphmain			SPHEREGRAPHMAIN
void __stdcall SURFACE3DMAIN(double*,double*,double*,double*,int*,int*,int*,int*,int*,int*,int*,int*
													,int*,int*,float*,float*,int*);
void __stdcall SPHEREGRAPHMAIN(double *,double *,double *,int *,int *,int *,int *,float *,int *);
void __stdcall ISOTRIANGLES(float*,float*,float*,float*,float*,float*,int*,int*,int*,int*,int*,int*);
void __stdcall DSFILL3DTRIANGS(double*,double*,double*,float*,float*,float*,float*,int*,int*,int*,int*);
void __stdcall DSFILL3DWITHVECT(double*,double*,double*,float*,float*,float*,float*,int*,int*,int*,int*);
void __stdcall RDNORMPOINTS(double *,double *,double *,double *,double *,double *,double *,double *,double *);
void __stdcall TRISURFACEMAIN(double*,double*,double*,int*,int*,int*,int*,int*,float*,int*);
#endif

#ifdef UPPERCASE
#define isosurfacecore			ISOSURFACECORE
#define isotriangles			ISOTRIANGLES
#define malloctrisurfacecore	MALLOCTRISURFACECORE
#define trisurfacemain			TRISURFACEMAIN
#define withnormalvector		WITHNORMALVECTOR
#define dsfill3dtriangs			DSFILL3DTRIANGS
#define dsfill3dwithvect		DSFILL3DWITHVECT
#define rdnormpoints			RDNORMPOINTS
#define mallocandsurfacecore	MALLOCANDSURFACECORE
#define surface3dmain			SURFACE3DMAIN
#define mallocsphgraphcore		MALLOCSPHGRAPHCORE
#define spheregraphmain			SPHEREGRAPHMAIN
#define advancecanvaspage		ADVANCECANVASPAGE
#define cleargcanvasall			CLEARGCANVASALL
#define storehlstables			STOREHLSTABLES
#define giffileoption			GIFFILEOPTION
#define giffilecolor			GIFFILECOLOR
#define giffiledot				GIFFILEDOT
#define giffileline				GIFFILELINE
#define giffileaaspaceflush		GIFFILEAASPACEFLUSH
#define giffilesetantialias		GIFFILESETANTIALIAS
#define giffilepolygon			GIFFILEPOLYGON
#define giffilegradrectangle	GIFFILEGRADRECTANGLE
#define giffilegradcirc			GIFFILEGRADCIRC
#define giffilecirc				GIFFILECIRC
#define giffilearrow			GIFFILEARROW
#define giffilechr				GIFFILECHR
#define giffilechr10			GIFFILECHR10
#define giffilesetrgb			GIFFILESETRGB
#define gifoutputend			GIFOUTPUTEND
#define gifoutputnext			GIFOUTPUTNEXT
#define gcanvascreate			GCANVASCREATE
#define setcanvaspointer		SETCANVASPOINTER
#define gcanvasclose			GCANVASCLOSE
#define initializecanvas		INITIALIZECANVAS
#define gcanvasgifoption		GCANVASGIFOPTION
#define gcanvasgraphstep		GCANVASGRAPHSTEP
#define gcanvascharsize			GCANVASCHARSIZE
#define pauseallgcanvas			PAUSEALLGCANVAS
#define gcanvascheck			GCANVASCHECK
#define gcanvasallclose			GCANVASALLCLOSE
#define gcanvasagifoption		GCANVASAGIFOPTION
#define setcanvasbackground		SETCANVASBACKGROUND
#define gcanvasbackgroundhls	GCANVASBACKGROUNDHLS
#define exchangefandbcolor		EXCHANGEFANDBCOLOR
#define gcanvaswindowsize		GCANVASWINDOWSIZE
#define getcanvaswindowsize		GETCANVASWINDOWSIZE
#define setcanvasoutlet			SETCANVASOUTLET
#define getcanvasoutlet			GETCANVASOUTLET
#define gwiodisplaymode			GWIODISPLAYMODE
#define setgfilemaxpage			SETGFILEMAXPAGE
#define flushbufferpages		FLUSHBUFFERPAGES
#define gsend1bytechars			GSEND1BYTECHARS
#define gsendsrealproc			GSENDSREALPROC
#define gsendhlsdataproc		GSENDHLSDATAPROC
#endif

#include	"name.h"

extern void fr_ginit(void);
extern void fr_gend(void);
extern void fr_gpause(void);
extern void fr_grequest(int *);
extern void fr_gclear(void);
extern void fr_pagesw(int *);
extern void fr_gpage(int *,int *);
/*	extern void	fr_setcircle(int *);
	extern void fr_setarrow(int *,int *);	*/
extern void	fr_setcircle(double *);
extern void	fr_setmark(double *,double *,int *);
extern void	fr_setbar(double *,int *);
extern void fr_setarrow(double *,double *);
extern void fr_setstep(int *);
extern void fr_setframe(int *,int *);
extern void fr_set2drgn(int *,int *,int *,int *);
extern void fr_set3drgn(int *,int *,int *,int *,int *,int *);
extern void fr_setcontour(double *,double *,int *);
extern void fr_setaxis(int *);
extern void fr_hlsset(double *,double *,double *,int *,int *);
extern void fr_clip3d(double *,double *,double *,double *,double *,double *,int *);
extern void fr_setlight(double *,double *,int *);
extern void fr_setsurface(double *,double *,int *);
extern void fr_setvolume(double *,double *,double *,double *);

extern void	fr_view2d(int *,int *,int *,int *);
extern void fr_aspect2d(double *,double *,int *);
extern void	fr_frame2d(double *,double *,double *,double *,int *);
extern void	fr_xyname(char *,char *);
extern void fr_graph2d(double *,double *,int *,int *,int *);
extern void	fr_draw2d(double *,double *,int *,int *);
extern void	fr_vector2d(double *,double *,double *,double *,int *,int *);
extern void fr_contour(double *,int *,int *,int *,int *);
extern void fr_tricontour(double *,double *,double *,int *,int *,int *,int *,int *,int *);
extern void fr_sqrcontour(double *,double *,double *,int *,int *,int *,int *,int *);
extern void fr_logaxis(int *);
extern void	fr_colorbar(int *,int *,int *,int *,int *);

extern void fr_pmview(int *,int *,int *,int *,int *,int *);
extern void	fr_pmframe(double *,double *,double *,double *,double *,double *,int *);
extern void	fr_xyzname(char *,char *,char *);
extern void fr_pmgraph(double *,double *,double *,int *,int *,int *);
extern void	fr_pmdraw(double *,double *,int *,int *);
extern void	fr_pmset(double *);
extern void	fr_hclear(int *);
extern void	fr_profile(double *,int *,int *,int *,int *);
extern void	fr_mapprofile(double *,double *,int *,int *,int *,int *);
extern void fr_profile3d(double *,double *,double *,int *,int *,int *,int *,int *);
extern void fr_surface(double *,double *,double *,int *,int *,int *,int *);
extern void fr_mapsurface(double *,double *,double *,double *,int *,int *,int *,int *);

extern void fr_view3d(int *,int *,int *,int *);
extern void fr_angle3d(double *,double *);
extern void fr_aspect3d(double *,double *,double *,int *);
extern void fr_rotate(double *,double *,int *);
extern void fr_project(double *,int *);
extern void fr_frame3d(double *,double *,double *,double *,double *,double *,int *);
extern void fr_graph3d(double *,double *,double *,int *,int *,int *);
extern void fr_draw3d(double *,double *,double *,int *,int *);
extern void fr_vector3d(double *,double *,double *,double *,double *,double *,int *,int *);
extern void fr_contour3d(double *,int *,int *,int *,double *,int *,int *,int *);
extern void fr_slices(double *,int *,int *,int *,double *,int *,int *,int *,int *);
extern void fr_triprofile(double *,double *,double *,int *,int *,int *,int *,int *,int *);
extern void fr_trisurface(double *,double *,double *,int *,int *,int *,int *,int *);
extern void fr_maptrisurface(double *,double *,double *,double *,int *,int *,int *,int *,int *);
extern void fr_isosurface(double *,int *,int *,int *,double *,int *,int *);
extern void fr_volrender(double *,int *,int *,int *,int *,int *);

extern void fr_fpline(double *,double *,double *,double *,int *,int *);
extern void fr_fpcircle(double *,double *,double *,double *,int *,int *);
extern void fr_fppolygon(double *,double *,int *,int *,int *);
extern void fr_fpchars(double *,double *,char *,int *,int *,int *,int *,int *);
extern void fr_fpdots(double *,double *,int *,int *,int *);
extern void fr_fpmark(double *,double *,double *,double *,int *,int *,int *);
extern void fr_2dmove(double *,double *,int *);
extern void fr_3dmove(double *,double *,double *,int *);
extern void fr_2dpolygon(double *,double *,int *,int *,int *);
extern void fr_3dpolygon(double *,double *,double *,int *,int *,int *);
extern void fr_3dline(double *,double *,double *,double *,double *,double *,int *,int *);
extern void fr_3dcircle(double *,double *,double *,double *,double *,double *,double *,double *,double *,int *,int *);

#ifndef NOT_USED_TPLOT
extern void fr_gfile(char *,int *);
extern void fr_giffile(char *,int *,int *);
extern void fr_filesw(int *);
extern void fr_filemax(int *);
extern void fr_gwsize(int *,int *,int *,int *);
extern void fr_gwstep(int *);
extern void fr_opencanvas(int *,char *,int *);
extern void fr_closecanvas(int *);
extern void fr_pltfile(int *,char *,int *);
extern void fr_gifimage(int *,char *,int *);
extern void fr_gifanimation(int *,char *,int *,int *,int *);
extern void fr_canvas(int *);
extern void fr_gifoption(int *,int *,int *);
extern void fr_outlet(int *);
extern void	fr_flow2dline(double *,double *,int *,double *,double *,int *,int *,int *,double *,int *);
extern void	fr_flow2drgn(double *,double *,double *,double *);
extern void	fr_flowspace(double *,int *,double *,int *,int *);
extern void	fr_flow3dline(double *,double *,double *,int *,double *,double *,double *,int *,int *,int *,int *,double *,int *);
extern void	fr_flow3drgn(double *,double *,double *,double *,double *,double *);
extern void fr_gnotes(char *);
extern void fr_filechar(char *);
extern void fr_fileint(int *,int *);
extern void fr_filedble(double *,int *);
extern void fr_2dtofp(double *,double *,double *,double *);
extern void fr_3dtofp(double *,double *,double *,double *,double *);
extern void fr_hlsrecall(int *);
extern void fr_hlsinquiry(int *);
#endif

#define FRAMES_HEADERS

#endif
