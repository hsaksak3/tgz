********************************************************
*                 F  R  A  M  E  S  V.7                *
*        FRAMES FORTRAN CANVAS HANDLING ROUTINES       *
*                PROGRAMMED BY T.TAGUCHI               *
********************************************************
      SUBROUTINE FR_OPENCANVAS(NCANVAS,NAME,IOUTLET)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT
      COMMON /OPENCANVASCOM/ ERRORCANVAS
      CHARACTER NAME*(*),NAME1*100,CH*20
      SAVE /OPENCANVASCOM/

*      IF (IGCANVAS.LT.0) RETURN
*      IF (IOUTLET.EQ.0) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

*     NCANVAS = CANVAS NUMBER ( 1 - 100, 1 IS RESERVED )
*             !! CAUTION !!  NFP == NCANVAS-1 (internal number)
*     NAME    = CANVAS NAME WITHOUT EXTENSIONS
*     IOUTLET = OUTLET OPENING SWITCH ( OR OF THE FOLLOWINGS )
*             =     0 ( NULL OUTPUT )
*             =     1 ( COMMON WINDOW FOR THE SAME SIZE)
*             =     2 ( INDIVIDUAL WINDOW)
*             =     7 ( WITHOUT WINDOW WITH WHITE BACKGROUND FOR SYSTEM)
*             =     8 ( COMMON WINDOW WITH WHITE BACKGROUND FOR SYSTEM)
*             =     9 ( INDIVIDUAL WINDOW WITH WHITE BACKGROUND FOR SYSTEM)
*             =    10 ( PLT FILE )
*             =   100 ( GIF IMAGE )
*             =   200 ( GIF ANIMATION WITH INDIVIDUAL COLORMAPS)
*             =   300 ( GIF ANIMATION WITH COMMON COLORMAP)
*             =  1000 ( POSTSCRIPT DATA, NOT SUPPORTED YET)
*     IF IOUTLET<0    ( EXCHANGE BLACK AND WHITE COLOR)

      IOUT   = IOUTLET
      IOWIN  = MOD(IOUT,10)
      IBW    = 0
      IF (IOUTLET.LT.0) THEN
         IOUT   = -IOUTLET
         IOWIN  = MOD(IOUT,10)
         IBW    = 1
       ELSE IF (IOWIN.GE.7) THEN
         IOWIN  = IOWIN-7
         IBW    = 1
      ENDIF
      IOUT   = IOUT/10
      IOPLT  = MOD(IOUT,10)
      IOUT   = IOUT/10
      IOGIF  = MOD(IOUT,10)
*       IOUT   = IOUT/10
*       IOPSF  = MOD(IOUT,10)
      IOPSF  = -1

      MFP  = NCANVAS-1

      CALL REMOVEEXTENTION(NAME,NAME1)

      call gcanvascreate(NAME1,MFP,1,ID)
      IF (ID.EQ.-2) THEN
         WRITE(CH,*) NCANVAS
         CALL FRAMESERROR(
     +          'THE CANVAS NUMBER IS ALREADY USED ! :'//CH)
         ERRORCANVAS = 1
         RETURN
       ELSE IF (ID.LT.0) THEN
         WRITE(CH,*) NCANVAS
         CALL FRAMESERROR(
     +          'THE CANVAS NUMBER IS OUT OF RANGE ! :'//CH)
         ERRORCANVAS = 1
         RETURN
      ENDIF

*//      IF (NFPCOUNT.EQ.0) THEN
**//        IF THIS IS THE FIRST CALL, IT WILL BE OPENED.
*//         NFP = MFP

*     IGCANVAS+1 = IOWIN .OR. IOPLT .OR. IOGIF .OR. IOPSF
      IF (NFP.EQ.MFP) THEN
         call setcanvaspointer(NFP,IOUT)
         CALL GWIOCANVASSET(IOWIN,IOPLT,IOGIF,IOPSF)
         MODE = IGCANVAS+1
         call initializecanvas(MFP,MODE)
         CALL GWIOOPENWINDOW(0)
       ELSE
         MODE = -1
         CALL GWIOCANVASBIT(IOWIN,IOPLT,IOGIF,IOPSF,MODE)
         call initializecanvas(MFP,MODE)
      ENDIF
      NFPCOUNT = NFPCOUNT + 1

      call setcanvasbackground(MFP,IBW,IOWIN)

      IF (IOGIF.EQ.2) THEN
         call gcanvasgifoption(MFP,IBW,0,0,1,1)
       ELSE IF (IOGIF.EQ.3) THEN
         call gcanvasgifoption(MFP,IBW,0,0,0,1)
       ELSE
         call gcanvasgifoption(MFP,IBW,0,0,1,0)
      ENDIF
      ERRORCANVAS = 0

      RETURN
      END

      SUBROUTINE FR_CLOSECANVAS(NCANVAS)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

      MFP  = NCANVAS-1
      IF (IGCANVAS.LT.0) THEN
         IF (MFP.NE.NFP) call gcanvasclose(MFP)
         RETURN
      ENDIF

      IF (MFP.EQ.NFP .AND. IGPLT.GT.0) CALL FLUSHBUFFER(IND,-3)
      call gcanvasclose(MFP)
      IF (MFP.EQ.NFP) CALL PAUSEALLGCANVAS

      RETURN
      END

      SUBROUTINE FR_GFILE(NAME,IND)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      CHARACTER NAME*(*)

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      MFP  = IND/10
      IF (MFP.LT.0) THEN
         MFP  = -MFP
         IND1 = -1
       ELSE
         IND1 = MOD(IND,10)
      ENDIF

      IF (IND.EQ.-2) THEN
         IOWIN    = 0
         IOPLT    = 0
       ELSE IF (IND1.LT.0) THEN
         IOWIN    = 1
         IOPLT    = 0
       ELSE IF (IND1.EQ.1) THEN
         IOWIN    = 0
         IOPLT    = 10
       ELSE
         IOWIN    = 1
         IOPLT    = 10
      ENDIF
*      IOGIF = 0
*      IOPSF = 0

      CALL FR_OPENCANVAS(MFP+1,NAME,IOWIN+IOPLT)

      RETURN
      END

      SUBROUTINE FR_GIFFILE(NAME,IND,MODE)
      CHARACTER NAME*(*)

      CALL FR_GFILEGIF(NAME,IND,MODE)

      RETURN
      END

      SUBROUTINE FR_GFILEGIF(NAME,IND,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /OPENCANVASCOM/ ERRORCANVAS
      CHARACTER NAME*(*)

*     MODE = ICBWREV + ITRANSP*10 + INTERLACE*100
*     ICBWREV   = 1, BLACK AND WHITE ARE EXCHANGED
*     ITRANSP   = 1, TRANSPARENT FOR BACKGROUND COLOR
*     INTERLACE = 1, INTERLACED

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      MFP  = IND/10
      IF (MFP.LT.0) THEN
         MFP  = -MFP
         IND1 = -1
       ELSE
         IND1 = MOD(IND,10)
      ENDIF

      IF (IND.EQ.-2) THEN
         IOWIN    = 0
         IOGIF    = 0
       ELSE IF (IND1.LT.0) THEN
         IOWIN    = 1
         IOGIF    = 0
       ELSE IF (IND1.EQ.1) THEN
         IOWIN    = 0
         IOGIF    = 100
         ICTB     = 1
         IANI     = 0
       ELSE IF (IND1.EQ.2) THEN
         IOWIN    = 1
         IOGIF    = 200
         ICTB     = 1
         IANI     = 1
       ELSE IF (IND1.EQ.3) THEN
         IOWIN    = 0
         IOGIF    = 200
         ICTB     = 1
         IANI     = 1
       ELSE
         IOWIN    = 1
         IOGIF    = 100
         ICTB     = 1
         IANI     = 0
      ENDIF
      ICBWREV    = MOD(MODE,10)
      IF (ICBWREV.GT.3) ICBWREV = 0
      IF (IOWIN.EQ.0.AND.ICBWREV.EQ.1) IOWIN = 7
      IF (IOWIN.EQ.1.AND.ICBWREV.EQ.1) IOWIN = 8
*      IOPLT = 0
*      IOPSF = 0
      CALL FR_OPENCANVAS(MFP+1,NAME,IOWIN+IOGIF)
      IF (ERRORCANVAS.NE.0) RETURN

      IF (IOGIF.GT.0) THEN
         ITRANSP   = MOD(MODE/10,10)
         IF (ITRANSP.NE.0) ITRANSP = 1
         INTERLACE = MOD(MODE/100,10)
         IF (INTERLACE.NE.0) INTERLACE = 1
         call gcanvasgifoption(MFP,ICBWREV,INTERLACE,ITRANSP,ICTB,IANI)
      ENDIF

      RETURN
      END

      SUBROUTINE FR_WINDOW(NCANVAS,NAME,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      CHARACTER NAME*(*)

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      IF (NCANVAS.LT.0) THEN
         MFP1     = -NCANVAS
         IOWIN    = 0
         IF (MODE.EQ.1) IOWIN = 7
       ELSE
         MFP1     = NCANVAS
         IOWIN    = 2
         IF (MODE.EQ.1) IOWIN = 9
      ENDIF
*      IOPLT = 0
*      IOGIF = 0
*      IOPSF = 0

      CALL FR_OPENCANVAS(MFP1,NAME,IOWIN)

      RETURN
      END

      SUBROUTINE FR_PLTFILE(NCANVAS,NAME,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      CHARACTER NAME*(*)

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      IF (NCANVAS.LT.0) THEN
         MFP1     = -NCANVAS
         IOWIN    = 0
         IF (MODE.EQ.1) IOWIN = 7
       ELSE
         MFP1     = NCANVAS
         IOWIN    = 1
         IF (MODE.EQ.1) IOWIN = 8
      ENDIF
      IOPLT    = 10
*      IOGIF = 0
*      IOPSF = 0

      CALL FR_OPENCANVAS(MFP1,NAME,IOWIN+IOPLT)

      RETURN
      END

      SUBROUTINE FR_GIFIMAGE(NCANVAS,NAME,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /OPENCANVASCOM/ ERRORCANVAS
      CHARACTER NAME*(*)

*     MODE = ICBWREV + ITRANSP*10 + INTERLACE*100
*     ICBWREV   = 1, BLACK AND WHITE ARE EXCHANGED
*     ITRANSP   = 1, TRANSPARENT FOR BACKGROUND COLOR
*     INTERLACE = 1, INTERLACED

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      ICBWREV   = MOD(MODE,10)
      IF (ICBWREV.GT.3) ICBWREV = 0
      IF (NCANVAS.LT.0) THEN
         MFP1     = -NCANVAS
         IOWIN    = 0
         IF (ICBWREV.EQ.1) IOWIN = 7
       ELSE
         MFP1     = NCANVAS
         IOWIN    = 1
         IF (ICBWREV.EQ.1) IOWIN = 8
      ENDIF
      IOGIF    = 100
*      IOPLT = 0
*      IOPSF = 0
      CALL FR_OPENCANVAS(MFP1,NAME,IOWIN+IOGIF)
      IF (ERRORCANVAS.NE.0) RETURN

      ITRANSP   = MOD(MODE/10,10)
      IF (ITRANSP.NE.0) ITRANSP = 1
      INTERLACE = MOD(MODE/100,10)
      IF (INTERLACE.NE.0) INTERLACE = 1
      call gcanvasgifoption(MFP1-1,ICBWREV,INTERLACE,ITRANSP,1,0)

      RETURN
      END

      SUBROUTINE FR_GIFANIMATION(NCANVAS,NAME,MODE,IDELAY,LOOP)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /OPENCANVASCOM/ ERRORCANVAS
      CHARACTER NAME*(*)

*     MODE = ICBWREV + ITRANSP*10 + INTERLACE*100 + ICTABLE*1000
*     ICBWREV   = 1, BLACK AND WHITE ARE EXCHANGED
*     ITRANSP   = 1, TRANSPARENT FOR BACKGROUND COLOR
*     INTERLACE = 1, INTERLACED
*     ICTABLE   = 1, USE COMMON COLOR TABLE (NEGLECT 2ND COLOR TABLE)

*      IF (IGCANVAS.LT.0) RETURN

*      IF (IND.EQ.-2) THEN
*         IGCANVAS = -1
*         RETURN
*      ENDIF

      ICBWREV    = MOD(MODE,10)
      IF (ICBWREV.GT.3) ICBWREV = 0
      IF (NCANVAS.LT.0) THEN
         MFP1     = -NCANVAS
         IOWIN    = 0
         IF (ICBWREV.EQ.1) IOWIN = 7
       ELSE
         MFP1     = NCANVAS
         IOWIN    = 1
         IF (ICBWREV.EQ.1) IOWIN = 8
      ENDIF
      IOGIF    = 200
*      IOPLT = 0
*      IOPSF = 0
      CALL FR_OPENCANVAS(MFP1,NAME,IOWIN+IOGIF)
      IF (ERRORCANVAS.NE.0) RETURN

      ITRANSP   = MOD(MODE/10,10)
      IF (ITRANSP.NE.0) ITRANSP = 1
      INTERLACE = MOD(MODE/100,10)
      IF (INTERLACE.NE.0) INTERLACE = 1
      ICTABLE = MODE/1000
      IF (ICTABLE.NE.0) ICTABLE = 1
      MFP = MFP1 - 1
      call gcanvasgifoption(MFP,ICBWREV,INTERLACE,ITRANSP,1-ICTABLE,1)
      call gcanvasagifoption(MFP,IDELAY,LOOP)

      RETURN
      END

      SUBROUTINE FR_GIFOPTION(MODE,IDELAY,LOOP)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

*     MODE = ICBWREV + ITRANSP*10 + INTERLACE*100 + ICTABLE*1000
*     ICBWREV   = 1, BLACK AND WHITE ARE EXCHANGED
*     ITRANSP   = 1, TRANSPARENT FOR BACKGROUND COLOR
*     INTERLACE = 1, INTERLACED
*     ICTABLE   = 1, USE COMMON COLOR TABLE (NEGLECT 2ND COLOR TABLE)

      IF (IGCANVAS.LT.0) RETURN
      IF (NFP.LT.0) RETURN

      IF (MODE.GE.0) THEN
         ICBWREV    = MOD(MODE,10)
         IF (ICBWREV.GT.3) ICBWREV = 0
         ITRANSP   = MOD(MODE/10,10)
         IF (ITRANSP.NE.0) ITRANSP = 1
         INTERLACE = MOD(MODE/100,10)
         IF (INTERLACE.NE.0) INTERLACE = 1
         ICTABLE = MOD(MODE/1000,10)
         IF (ICTABLE.NE.0) ICTABLE = 1

         call gcanvasgifoption(NFP,ICBWREV,INTERLACE
     +                         ,ITRANSP,1-ICTABLE,IANIME)
      ENDIF

      call gcanvasagifoption(NFP,IDELAY,LOOP)

      RETURN
      END

      SUBROUTINE FR_GIFANTIALIAS(MODE,REDUC)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT
      INTEGER REDUC

*      IF (IGCANVAS.LT.0) RETURN
*      IF (NFP.LT.0) RETURN

      call giffilesetantialias(mode,reduc)

      RETURN
      END

      SUBROUTINE FR_GWSIZE(BX,BY,OX,OY)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER BX,BY,OX,OY

*      IF (IGCANVAS.LT.0) RETURN

*      IGW = 0
*      IBX = BX
*      IBY = BY
*      IOX = OX
*      IOY = OY
*      CALL GWIOSETWSIZE(IBX,IBY,IOX,IOY,IGW)
      call gcanvaswindowsize(BX,BY,OX,OY)

      RETURN
      END

      SUBROUTINE FR_GWCHARSIZE(SIZE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8 SIZE

*      IF (IGCANVAS.LT.0) RETURN

*      IGW = 0
*      S1  = STEP
*      CALL GWIOSETWSTEP(S1,IGW)
      call gcanvascharsize(SIZE)

      RETURN
      END

      SUBROUTINE FR_GWSTEP(STEP)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      INTEGER STEP,S1

*      IF (IGCANVAS.LT.0) RETURN

*      IGW = 0
*      S1  = STEP
*      CALL GWIOSETWSTEP(S1,IGW)
      call gcanvasgraphstep(STEP)

      RETURN
      END

      SUBROUTINE FR_GWBCOLOR(IH,IL,IS)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
*      REAL*8 H,L,S
*      common /comgifmode/ mdgif

*      IF (IGCANVAS.LT.0) RETURN

      call gcanvasbackgroundhls(DBLE(IH),0.01D0*IL,0.01D0*IS)

      RETURN
      END

      SUBROUTINE FR_GWFBEXCHANGE(MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
*      REAL*8 H,L,S
*      common /comgifmode/ mdgif

*      IF (IGCANVAS.LT.0) RETURN

      call exchangefandbcolor(MODE)

      RETURN
      END

*!!!  IOWIN IS INCOMPLETE THE FOLLOWING OUTLET CHANGING ROUTINES !!!
      SUBROUTINE FR_FILESW(IND)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT
*      CHARACTER CH*20
      IF (IGCANVAS.LT.0) RETURN

*     FIRST, CLEAR SCREEN AND FLUSH BUFFER
      CALL FR_GCLEAR

      MFP  = IND/10
      IF (MFP.LT.0) THEN
         MFP  = -MFP
         IND1 = -1
       ELSE
         IND1 = MOD(IND,10)
      ENDIF

*      IF (NFP.NE.MFP) THEN
*         call gcanvascheck(MFP,ID)
*         IF (MFP.GT.0 .AND. ID.NE.0) THEN
*            WRITE(CH,*) MFP+1
*            CALL FRAMESERROR(
*     +           'UNDEFINED CANVAS NUMBER ASSIGNMENT - FILESW :'//CH)
*            RETURN
*         ENDIF
*         NFP = MFP
*         call setcanvaspointer(NFP,IOUT)
*         CALL GWIOCLEARCANVAS
*      ENDIF

      IF (IND1.LT.0) THEN
         IOANY    = 0
         IOWIN    = 1
       ELSE IF (IND1.EQ.1) THEN
         IOANY    = 1
         IOWIN    = 0
       ELSE
         IOANY    = 1
         IOWIN    = 1
      ENDIF

      IOPSF  = -1
      call setcanvaspointer(NFP,IOUT)
      CALL GWIOCANVASSET(IOUT,IOWIN,IOANY,IOPSF)
      CALL GWIOOPENWINDOW(0)

      RETURN
      END

      SUBROUTINE FR_CANVAS(NCANVAS)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT
*      CHARACTER CH*20

*      IF (IGCANVAS.LT.0) RETURN

*     FIRST, CLEAR SCREEN AND FLUSH BUFFER
*      CALL FR_GCLEAR

      IF (IGCANVAS.GE.0) THEN
         CALL GWIOSTOREPAGE
         CALL CLEARGSETTINGS
      ENDIF
*      KEY = -2000
*      CALL GWIOPAUSE(KEY)

      MFP  = NCANVAS-1
      IF (NFP.NE.MFP .AND. MFP.GE.0) THEN
         call gcanvascheck(MFP,ID)
         IF (MFP.GT.0 .AND. ID.NE.0) THEN
*            WRITE(CH,*) NCANVAS
*            CALL FRAMESERROR(
*     +             'UNDEFINED FILE NUMBER ASSIGNMENT - CANVAS :'//CH)
            CALL PAUSEALLGCANVAS
          ELSE
            IF (NFP.LT.0) IGCANVAS = -1
            NFP = MFP
            call setcanvaspointer(NFP,IOUT)
            CALL GWIOCANVASCLONE(IOUT)
            CALL GWIOOPENWINDOW(0)
         ENDIF
      ENDIF
      IF (IGCANVAS.LE.0) RETURN

      IF (MFP.GE.0) CALL GWIOCLEARPAGE

      RETURN
      END

*     GRAPHIC CLEAR SHOULD BE EQUIVALENT TO NEXT PAGE COMMAND
      SUBROUTINE FR_GCLEAR
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      CALL GWIOSTOREPAGE
      CALL CLEARGSETTINGS
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOCLEARPAGE

      RETURN
      END

      SUBROUTINE FR_GPAUSE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LE.0) RETURN

      KEY = 1
      CALL GWIOPAUSE(KEY)

      RETURN
      END

      SUBROUTINE FR_GREQUEST(KEY,MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LE.0) RETURN

      IF (MODE.GT.0) THEN
         KEY1 = -1000
         CALL GWIOPAUSE(KEY1)
         KEY  = KEY1
       ELSE IF (MODE.LT.0) THEN
         KEY1 = 1
         CALL GWIOPAUSE(KEY1)
       ELSE
         KEY1 = -1010
         CALL GWIOPAUSE(KEY1)
         KEY  = KEY1
      ENDIF

      RETURN
      END

      SUBROUTINE PAUSEALLGCANVAS
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

*      IF (IGCANVAS.LT.0) RETURN

*     CLOSE ALL OUTLETS, BUT STILL WAIT FOR RESUME (SKEWED ASSIGNMENT)
      CALL GWIOCANVASSET(0,0,0,0)
*      IGCANVAS = 0
      NFP      = -1

      RETURN
      END

      SUBROUTINE FR_SETOUTLET(NCANVAS,IOUTLET)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

      MFP  = NCANVAS-1
      IF (MFP.EQ.NFP) THEN
         CALL FR_OUTLET(IOUTLET)
         RETURN
      ENDIF

      IF (MFP.GE.0) THEN
         call gcanvascheck(MFP,ID)
         IF (ID.NE.0) RETURN
         IOUT   = IOUTLET
         IBW    = 0
         IF (IOUTLET.LT.0) THEN
            IOUT = -IOUTLET
            IBW  = 1
         ENDIF
         IOWIN  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOPLT  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOGIF  = MOD(IOUT,10)
*         IOUT   = IOUT/10
*         IOPSF  = MODE(IOUT,10)
         IOPSF  = -1
         MODE   = -1
         CALL GWIOCANVASBIT(IOWIN,IOPLT,IOGIF,IOPSF,MODE)
         call setcanvasoutlet(MFP,MODE)
*         call setcanvasbackground(MFP,IBW,IOWIN)
         IF (IOGIF.EQ.2) THEN
            call gcanvasgifoption(MFP,-1,0,0,1,1)
          ELSE IF (IOGIF.EQ.3) THEN
            call gcanvasgifoption(MFP,-1,0,0,0,1)
          ELSE
            call gcanvasgifoption(MFP,-1,0,0,1,0)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_ADDOUTLET(NCANVAS,IOUTLET)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

      MFP  = NCANVAS-1
      IF (MFP.GE.0) THEN
         call gcanvascheck(MFP,ID)
         IF (ID.NE.0) RETURN
         IOUT   = IOUTLET
         IBW    = 0
         IF (IOUTLET.LT.0) THEN
            IOUT = -IOUTLET
            IBW  = 1
         ENDIF
         call getcanvasoutlet(MFP,MODE)
         CALL GWIOCANVASBIT(IOWIN1,IOPLT1,IOGIF1,IOPSF1,MODE)
         IOWIN  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOPLT  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOGIF  = MOD(IOUT,10)
*         IOUT   = IOUT/10
*         IOPSF  = MODE(IOUT,10)
         IOPSF  = -1
         MODE   = -1
         CALL GWIOCANVASBIT(IOWIN+IOWIN1,IOPLT+IOPLT1,IOGIF+IOGIF1
     ,                                           ,IOPSF+IOPSF1,MODE)
         call setcanvasoutlet(MFP,MODE)
*         call setcanvasbackground(MFP,IBW,IOWIN)
         IF (IOGIF1.EQ.0) THEN
            IF (IOGIF.EQ.2) THEN
               call gcanvasgifoption(MFP,-1,0,0,1,1)
             ELSE IF (IOGIF.EQ.3) THEN
               call gcanvasgifoption(MFP,-1,0,0,0,1)
             ELSE
               call gcanvasgifoption(MFP,-1,0,0,1,0)
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_OUTLET(IOUTLET)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /GFILESELECT/ NFP,NFPCOUNT

*      IF (IGCANVAS.LT.0) RETURN

      IF (NFP.GE.0) THEN
         call gcanvascheck(NFP,ID)
         IF (ID.NE.0) RETURN
         CALL FR_GCLEAR
         IOUT   = IOUTLET
         IBW    = 0
         IF (IOUTLET.LT.0) THEN
            IOUT = -IOUTLET
            IBW  = 1
         ENDIF
         IOWIN  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOPLT  = MOD(IOUT,10)
         IOUT   = IOUT/10
         IOGIF  = MOD(IOUT,10)
*         IOUT   = IOUT/10
*         IOPSF  = MOD(IOUT,10)
         IOPSF  = -1
         CALL GWIOCANVASSET(IOWIN,IOPLT,IOGIF,IOPSF)
         call setcanvasoutlet(NFP,IGCANVAS+1)
*         call setcanvasbackground(MFP,IBW,IOWIN)
         IF (IOGIF.EQ.2) THEN
            call gcanvasgifoption(NFP,-1,0,0,1,1)
          ELSE IF (IOGIF.EQ.3) THEN
            call gcanvasgifoption(NFP,-1,0,0,0,1)
          ELSE
            call gcanvasgifoption(NFP,-1,0,0,1,0)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE CANVASALLCLOSE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGPLT.GT.0) CALL FLUSHBUFFER(IND,-3)
      call gcanvasallclose

      RETURN
      END

      SUBROUTINE FR_DELAYUPDATE(MODE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LE.0) RETURN

      CALL GWIODISPLAYMODE(MODE)

      RETURN
      END
