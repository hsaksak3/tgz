****************************************************
*              F  R  A  M  E  S  V.7               *
*    TRIANGLE MESH CONTOUR  DRAWING  SUBROUTINE    *
*             PROGRAMMED BY T.TAGUCHI              *
****************************************************

*      GIVEN DIMENSION IS X(NP),Y(NP),F(NP),NODE(3,NS)

      SUBROUTINE FR_TRICONTOUR(X,Y,F,NP,NODE,NS,ND0,ICOL,MCOL)
      COMMON /GRAPHCOM/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0,PX,PY
     +            ,IXMIN,IXMAX,IYMIN,IYMAX,IFRAM,IVIEW
      COMMON /CONTOURCOM/ F0(0:4),FMIN,FMAX,FBASE,FBASE1,DF
     ,            ,CFX(0:4),CFY(0:4),I0(0:4),IC,IC2,IFIND,NDV
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8  X(NP),Y(NP),F(NP),FM1,FM2
      INTEGER NODE(3,NS)
      REAL    TRIX(3),TRIY(3),XP(5),YP(5)

      IF (IGCANVAS.LT.0) RETURN

      IF (NP.LT.3.OR.NS.LT.1) THEN
         CALL FRAMESERROR(
     +         'TRIANGLE CONTOUR PROGRAM NEEDS MORE THAN 3 POINTS')
         RETURN
      ENDIF

      XM1 = X(1)
      XM2 = XM1

      DO 10 I = 2, NP
         IF (X(I).LT.XM1) XM1 = X(I)
         IF (X(I).GT.XM2) XM2 = X(I)
   10   CONTINUE

      IF (XM2.EQ.XM1) RETURN

      YM1 = Y(1)
      YM2 = YM1

      DO 11 I = 2, NP
         IF (Y(I).LT.YM1) YM1 = Y(I)
         IF (Y(I).GT.YM2) YM2 = Y(I)
   11   CONTINUE

      IF (YM2.EQ.YM1) RETURN

      IF (IFRAM.EQ.0) THEN
*         IFRAM = 999
         IF (IDFFR2.LT.0) THEN
            IDFR = 1
          ELSE
            IDFR = IDFFR2
         ENDIF
         CALL FR_FRAME2D(DBLE(XM1),DBLE(XM2),DBLE(YM1),DBLE(YM2),IDFR)
      ENDIF

      IF (ICOL.LT.0.AND.ICOL256.EQ.0) CALL STORECURRENTCOLMAP

      FM1 = F(1)
      FM2 = FM1
      DO 12 I = 2, NP
         IF (F(I).LT.FM1) FM1 = F(I)
         IF (F(I).GT.FM2) FM2 = F(I)
   12   CONTINUE

      ND = ND0
      IF (IGPLT.GT.0) THEN
         IF (IFCONT.EQ.0) CALL FR_SETCONTOUR(0.D0,0.D0,-1)
         CALL GSENDBYTE(15,1)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(MCOL,2)
         CALL GSENDBYTE(ND,2)
         CALL GSENDBYTE(NP,4)
         CALL GSENDBYTE(NS,4)
         CALL GSEND8BYTE(X,Y,NP,1)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,NP,4)
         IF (NP.LT.256) THEN
            NB = 1
          ELSE IF (NP.LT.65536) THEN
            NB = 2
          ELSE IF (NP.LT.16777216) THEN
            NB = 3
          ELSE
            NB = 4
         ENDIF
         DO 5 I = 1, NS
            DO 6 K = 1, 3
               CALL GSENDBYTE(NODE(K,I),NB)
    6     CONTINUE           
    5     CONTINUE           
      ENDIF
      IF (IGCANVAS.EQ.0) RETURN

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) RETURN
      CALL GWIOSETAASPACE(0)

      IF (MCOL.NE.0.AND.(ICOL.GT.-2.OR.ICOL.EQ.-4)) THEN
         CALL GWIOCOLOR(2,MCOL)
         DO 13 K = 1, NS
            DO 130 J = 1, 3
               TRIX(J) = XTAN*X(NODE(J,K)) + X0
               TRIY(J) = YTAN*Y(NODE(J,K)) + Y0
  130         CONTINUE
            CALL GWIOPOLYGON(TRIX,TRIY,3,1)
   13     CONTINUE
      ENDIF

      IF (ICOL.EQ.0) GO TO 1000

      CALL FGWIOCOLORSET(ICOL,ND,FM1,FM2)
      NSFINE = -MOD(ICOL/10,10)

      IF (FM2.EQ.FM1.AND.IFIND.NE.-2) GO TO 1000
      IF (ND.LE.0.AND.IFIND.NE.-2) GO TO 1000

      IF (IFIND.EQ.-4.OR.(IFIND.EQ.-3.AND.NSFINE.EQ.1)) THEN
         DO K = 1, NS
            F00   = F(NODE(1,K))
            XP(1) = XTAN*X(NODE(1,K)) + X0
            YP(1) = YTAN*Y(NODE(1,K)) + Y0
            XP(2) = XTAN*X(NODE(2,K)) + X0
            YP(2) = YTAN*Y(NODE(2,K)) + Y0
            XP(3) = XTAN*X(NODE(3,K)) + X0
            YP(3) = YTAN*Y(NODE(3,K)) + Y0
*            RNF = (F00 - FMIN)/DF
*            NF  = RNF + 0.5
            NPG = 3
            CALL FGWIOPOLY(XP,YP,NPG,F00)
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-3) THEN
         DO K = 1, NS
            F00 = F(NODE(1,K))+F(NODE(2,K))+F(NODE(3,K))
            XP(1) = XTAN*X(NODE(1,K)) + X0
            YP(1) = YTAN*Y(NODE(1,K)) + Y0
            XP(2) = XTAN*X(NODE(2,K)) + X0
            YP(2) = YTAN*Y(NODE(2,K)) + Y0
            XP(3) = XTAN*X(NODE(3,K)) + X0
            YP(3) = YTAN*Y(NODE(3,K)) + Y0
*            RNF = (F00/3 - FMIN)/DF
*            NF  = RNF + 0.5
            NPG = 3
            CALL FGWIOPOLY(XP,YP,NPG,F00/3)
         ENDDO
         GO TO 999
       ELSE IF (IFIND.EQ.-5) THEN
         DO I = 1, NP
            F00 = F(I)
            XP1 = XTAN*X(I) + X0
            YP1 = YTAN*Y(I) + Y0
*            RNF = (F(I) - FMIN)/DF
*            NF  = RNF + 0.5
            CALL FGWIOPSET(XP1,YP1,F00)
         ENDDO
         GO TO 999
      ENDIF

      DO 20 K = 1, NS
         DO 210 L = 1, 3
            TRIX(L) = XTAN*X(NODE(L,K)) + X0
            TRIY(L) = YTAN*Y(NODE(L,K)) + Y0
            F0(L)   = F(NODE(L,K))
  210      CONTINUE

         DO 220 L = 1, 2
            DO 221 L1 = L+1, 3
               IF (F0(L).GT.F0(L1)) THEN
                  TT       = TRIX(L)
                  TRIX(L)  = TRIX(L1)
                  TRIX(L1) = TT
                  TT       = TRIY(L)
                  TRIY(L)  = TRIY(L1)
                  TRIY(L1) = TT
                  FF       = F0(L)
                  F0(L)    = F0(L1)
                  F0(L1)   = FF
               ENDIF
  221      CONTINUE
  220      CONTINUE

         F01 = F0(1)
         F03 = F0(3)
         IF (IFIND.EQ.-2.AND.IFBASE.LT.0) THEN
            IF (F01.GE.FBASE.AND.F03.LE.FBASE1) GO TO 20
         ENDIF
         NF  = INT((F01 - FMIN)/DF) - 1
         IF (IFIND.EQ.-2) THEN
            NPG   = 1
            XP(1) = TRIX(1)
            YP(1) = TRIY(1)
         ENDIF

  250    FD = NF*DF + FMIN
         IF (FD.LT.F01) THEN
            NF = NF + 1
            GO TO 250
         ENDIF
         IN0 = 1
         DX1 = TRIX(3) - TRIX(1)
         DY1 = TRIY(3) - TRIY(1)
         DX2 = TRIX(2) - TRIX(1)
         DY2 = TRIY(2) - TRIY(1)
         DFI = F0(2) - F0(1)
         IF (DFI.EQ.0.0) THEN
            IF (IFIND.EQ.-2) THEN
               NPG   = 2
               XP(2) = TRIX(2)
               YP(2) = TRIY(2)
            ENDIF
            IN0 = 2
            DX2 = TRIX(3) - TRIX(2)
            DY2 = TRIY(3) - TRIY(2)
            DFI = F0(3) - F0(2)
            IF (DFI.EQ.0.0) GO TO 290
         ENDIF
         DFI = 1.0/DFI
         DF1 = 1.0/(F03 - F01)
  260      CONTINUE
         FD = NF*DF + FMIN
         IF (FD.LE.FMAX.AND.FD.LE.F03) THEN
            IF (IN0.EQ.1.AND.FD.GE.F0(2)) THEN
               IF (IFIND.EQ.-2) THEN
                  NPG     = NPG + 1
                  XP(NPG) = TRIX(2)
                  YP(NPG) = TRIY(2)
               ENDIF
               IN0 = 2
               DX2 = TRIX(3) - TRIX(2)
               DY2 = TRIY(3) - TRIY(2)
               DFI = F0(3) - F0(2)
               IF (DFI.EQ.0.0) GO TO 290
               DFI = 1.0/DFI
            ENDIF
            DI  = (FD - F01)*DF1
            DJ  = (FD - F0(IN0))*DFI
            XX0 = DX1*DI + TRIX(1)
            YY0 = DY1*DI + TRIY(1)
            XX1 = DX2*DJ + TRIX(IN0)
            YY1 = DY2*DJ + TRIY(IN0)
            IF (IFIND.EQ.-2) THEN
               NPG       = NPG + 2
               XP(NPG-1) = XX1
               YP(NPG-1) = YY1
               XP(NPG)   = XX0
               YP(NPG)   = YY0
               CALL FGWIOPOLYS(XP,YP,NPG)
             ELSE
               CALL FGWIOLINE(XX0,YY0,XX1,YY1)
            ENDIF
            NF = NF + 1
            GO TO 260
         ENDIF
  290     CONTINUE
         IF (IFIND.EQ.-2) THEN
            IF (NPG.EQ.1.OR.IN0.EQ.1) THEN
               NPG   = NPG + 1
               XP(NPG) = TRIX(2)
               YP(NPG) = TRIY(2)
           ENDIF
            NPG   = NPG + 1
            XP(NPG) = TRIX(3)
            YP(NPG) = TRIY(3)
            CALL FGWIOPOLYS(XP,YP,NPG)
         ENDIF
   20   CONTINUE

  999 IF (MCOL.NE.0.AND.ICOL.LE.-2.AND.ICOL.NE.-5) THEN
         CALL GWIOCOLOR(2,MCOL)
         DO 30 K = 1, NS
            DO 310 J = 1, 3
               TRIX(J) = XTAN*X(NODE(J,K)) + X0
               TRIY(J) = YTAN*Y(NODE(J,K)) + Y0
  310        CONTINUE
            CALL GWIOPOLYGON(TRIX,TRIY,3,1)
   30     CONTINUE
      ENDIF

 1000 CALL GWIOBDFLUSH(1)
      RETURN
      END
