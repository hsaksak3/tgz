*******************************************
*        F  R  A  M  E  S  V.7.3          *
*       SURFACE RENDERING ROUTINES        *
*             AND ISOSURFACE              *
*       FOR XYZ TRIANGLE MESH DATA        *
*       PROGRAMMED BY T.TAGUCHI           *
*            SEPTEMBER/17/2012            *
*******************************************

*      GIVEN DIMENSION IS X(NP),Y(NP),Z(NP),NODE(3,NS)

      SUBROUTINE FR_TRIPROFILE(X,Y,Z,NP,NODE,NS,ICOL,MODE,WS)
      REAL*8 X(NP),Y(NP),Z(NP)
      INTEGER NODE(3,NS),WS(*)

      CALL FR_TRISURFACE(X,Y,Z,NP,NODE,NS,ICOL,MODE)

      RETURN
      END

      SUBROUTINE FR_TRISURFACE(X,Y,Z,NP,NODE,NS,ICOL,MODE)
      PARAMETER (NDBMODE=8)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8 X(NP),Y(NP),Z(NP)
      INTEGER NODE(3,NS)
      REAL*8  X1,X2,Y1,Y2,Z1,Z2
      REAL    TRIX(3),TRIY(3)
      SAVE /PROFTRCOM/,/PROFTRNIK/

      IF (IGCANVAS.LT.0) RETURN

      IF (NP.LE.2.OR.NS.LE.0) THEN
         CALL FRAMESERROR(
     +             'TRI SURFACE PROGRAM NEEDS MORE THAN 1 TRIANGLE')
         RETURN
      ENDIF
      
      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR TRISURFACE')
         RETURN
      ENDIF

      IND    = MOD(MODE,10)

      IF (IFRAM.EQ.0) THEN
         IF (IND.EQ.NDBMODE) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO I = 1, NP, 2
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
            ENDDO
          ELSE
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO I = 1, NP
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
            ENDDO
         ENDIF
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         CALL FR_FRAME3D(X1,X2,Y1,Y2,Z1,Z2,IDFR)
      ENDIF

      ICOLMODE = 0
      NBCOL    = -1
      ISVEC    = 0
      NSMODE   = IND/10
      IC       = MOD(ICOL,100)
      IF (ICOL.LT.0.AND.IND.NE.0) THEN
         IF (IND.EQ.7) NBCOL  = -ICOL/100
         NSFINE = -MOD(ICOL/10,10)
         IC     = MOD(ICOL,10)
         IF (IC.EQ.-3) THEN
            NSMODE = 2000 + NSFINE
          ELSE IF (IC.EQ.-4) THEN
*            NSMODE = 2001
*          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 3000 + NSFINE
          ELSE
            NSMODE = 1000
         ENDIF
         IF (MOD3DIR.EQ.1) THEN
            FM1 = X(1)
            FM2 = FM1
            DO 11 I = 2, NP
               IF (X(I).LT.FM1) FM1 = X(I)
               IF (X(I).GT.FM2) FM2 = X(I)
   11       CONTINUE
          ELSE IF (MOD3DIR.EQ.2) THEN
            FM1 = Y(1)
            FM2 = FM1
            DO 12 I = 2, NP
               IF (Y(I).LT.FM1) FM1 = Y(I)
               IF (Y(I).GT.FM2) FM2 = Y(I)
   12       CONTINUE
          ELSE
            FM1 = Z(1)
            FM2 = FM1
            DO 13 I = 2, NP
               IF (Z(I).LT.FM1) FM1 = Z(I)
               IF (Z(I).GT.FM2) FM2 = Z(I)
   13       CONTINUE
         ENDIF
       ELSE IF (IND.LE.4) THEN
         IF (ICOL/100.GT.0) THEN
            NBCOL  = IC
            IC     = ICOL/100
            NSMODE = 100
          ELSE
            NSMODE = -1
        ENDIF
       ELSE IF (IND.EQ.5) THEN
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.6) THEN
         NSMODE = 10
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.7) THEN
         NSMODE = 10
         NBCOL  = ICOL/100
       ELSE IF (IND.EQ.NDBMODE) THEN
         NSMODE = 30
      ENDIF
      IF (NBCOL.EQ.0) NBCOL = -1

      IF (NSMODE.LT.0) THEN
         CALL GWIOCOLOR(2,IC)
       ELSE IF (ICOL256.GE.0) THEN
         IF (IC.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 1
          ELSE IF (IND.NE.0) THEN
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (IC.GE.0) THEN
*        FOR TPLOT ONLY
         CALL ISHLSLIGHTSET(IC,-1)
      ENDIF

      IF (IGPLT.GT.0) THEN
         IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
            CALL FR_SETCONTOUR(0.D0,0.D0,-1)
          ELSE IF (NSMODE.GE.0) THEN
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(71,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(NP,4)
         CALL GSENDBYTE(NS,4)
         CALL GSEND38BYTE(X,Y,Z,NP,1)
         IF (NP.LT.256) THEN
            NB = 1
          ELSE IF (NP.LT.65536) THEN
            NB = 2
          ELSE IF (NP.LT.16777216) THEN
            NB = 3
          ELSE
            NB = 4
         ENDIF
         DO 5 I = 1, NS
            DO 6 K = 1, 3
               CALL GSENDBYTE(NODE(K,I),NB)
    6     CONTINUE
    5     CONTINUE
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(0)

      IF (IND.EQ.0) THEN
         IC0 = ABS(ICOL)
         CALL GWIOCOLOR(2,IC0)
         IF (ICLP3D.EQ.0) THEN
            DO 10 K = 1, NS
               DO 110 J = 1, 3
                  CALL COORDINXYZ(X(NODE(J,K)),Y(NODE(J,K)),Z(NODE(J,K))
     ,                                        ,TRIX(J),TRIY(J))
  110             CONTINUE
               CALL GWIOPOLYGON(TRIX,TRIY,3,1)
   10       CONTINUE
          ELSE
            DO 20 K = 1, NS
               N1    = NODE(1,K)
               N2    = NODE(2,K)
               N3    = NODE(3,K)
               XX    = (X(N1)+X(N2)+X(N3))/3
               YY    = (Y(N1)+Y(N2)+Y(N3))/3
               ZZ    = (Z(N1)+Z(N2)+Z(N3))/3
               IF (XX.GE.tdx1.AND.XX.LE.tdx2.AND.
     +               YY.GE.tdy1.AND.YY.LE.tdy2.AND.
     +                     ZZ.GE.tdz1.AND.ZZ.LE.tdz2) THEN
                  DO 120 J = 1, 3
                     CALL COORDINXYZ(X(NODE(J,K)),Y(NODE(J,K))
     ,                                  ,Z(NODE(J,K)),TRIX(J),TRIY(J))
  120                CONTINUE
                  CALL GWIOPOLYGON(TRIX,TRIY,3,1)
               ENDIF
   20       CONTINUE
         ENDIF
         GO TO 990
      ENDIF

*     HIGH TECHNIQUE HIDDEN LINE 

      IF (NSMODE.EQ.30) THEN
         M2 = 1
       ELSE
         M2 = 0
      ENDIF

      M1 = 0
      CALL MALLOCTRISURFACECORE(X,Y,Z,Z,NP,NODE,NS,IC,M1,M2,IND,IER)
      IF (IER.NE.0) THEN
         CALL FRAMESERROR('TRI SURFACE PROGRAM IS SOMETHING WRONG !')
         GO TO 999
      ENDIF

  990  CONTINUE
      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      CALL GWIOBDFLUSH(1)
*  999 IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
  999 RETURN
      END

      SUBROUTINE FR_MAPTRISURFACE(X,Y,Z,F,NP,NODE,NS,ICOL,MODE)
      PARAMETER (NDBMODE=8)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /NFCONTCOM/DNF,RNF,NCL6,NF,MODCONT,IFCONT,ICMAX,IFBASE,IRNF
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8 X(NP),Y(NP),Z(NP),F(NP)
      INTEGER NODE(3,NS)
      REAL*8  X1,X2,Y1,Y2,Z1,Z2
      SAVE /PROFTRCOM/,/PROFTRNIK/

      IF (IGCANVAS.LT.0) RETURN

      IF (NP.LE.2.OR.NS.LE.0) THEN
         CALL FRAMESERROR(
     +             'TRI SURFACE PROGRAM NEEDS MORE THAN 1 TRIANGLE')
         RETURN
      ENDIF
      
      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR TRISURFACE')
         RETURN
      ENDIF

      IND    = MOD(MODE,10)

      IF (IFRAM.EQ.0) THEN
         IF (IND.EQ.NDBMODE) THEN
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO I = 1, NP, 2
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
            ENDDO
          ELSE
            X1 = X(1)
            X2 = X1
            Y1 = Y(1)
            Y2 = Y1
            Z1 = Z(1)
            Z2 = Z1
            DO I = 1, NP
               IF (X1.GT.X(I)) X1 = X(I)
               IF (X2.LT.X(I)) X2 = X(I)
               IF (Y1.GT.Y(I)) Y1 = Y(I)
               IF (Y2.LT.Y(I)) Y2 = Y(I)
               IF (Z1.GT.Z(I)) Z1 = Z(I)
               IF (Z2.LT.Z(I)) Z2 = Z(I)
            ENDDO
         ENDIF
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         CALL FR_FRAME3D(X1,X2,Y1,Y2,Z1,Z2,IDFR)
      ENDIF

      ICOLMODE = 0
      NBCOL    = -1
      ISVEC    = 0
      NSMODE   = IND/10
      IC       = MOD(ICOL,100)
*      IF (ICOL.LT.0.AND.IND.NE.0) THEN
*         IF (IND.EQ.7) NBCOL  = -ICOL/100
         NSFINE = -MOD(ICOL/10,10)
         IC     = MOD(ICOL,10)
         IF (IC.EQ.-3) THEN
            NSMODE = 2000 + NSFINE
          ELSE IF (IC.EQ.-4) THEN
*            NSMODE = 2001
*          ELSE IF (IC.EQ.-5) THEN
            NSMODE = 3000 + NSFINE
          ELSE
            NSMODE = 1000
         ENDIF
         FM1 = F(1)
         FM2 = FM1
         DO 11 I = 2, NP
            IF (F(I).LT.FM1) FM1 = F(I)
            IF (F(I).GT.FM2) FM2 = F(I)
   11    CONTINUE
*      ENDIF
      IF (NBCOL.EQ.0) NBCOL = -1

      IF (NSMODE.LT.0) THEN
         CALL GWIOCOLOR(2,IC)
       ELSE IF (ICOL256.GE.0) THEN
         IF (IC.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 1
          ELSE IF (IND.NE.0) THEN
            IF (ICOL256.EQ.0) CALL STORECURRENTCOLMAP
         ENDIF
       ELSE IF (IC.GE.0) THEN
*        FOR TPLOT ONLY
         CALL ISHLSLIGHTSET(IC,-1)
      ENDIF

      IF (IGPLT.GT.0) THEN
         IF (NSMODE.GE.1000.AND.IFCONT.EQ.0) THEN
            CALL FR_SETCONTOUR(0.D0,0.D0,-1)
          ELSE IF (NSMODE.GE.0) THEN
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(71,1)
         CALL GSENDBYTE(10000+MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(NP,4)
         CALL GSENDBYTE(NS,4)
         CALL GSEND38BYTE(X,Y,Z,NP,1)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,NP,4)
         IF (NP.LT.256) THEN
            NB = 1
          ELSE IF (NP.LT.65536) THEN
            NB = 2
          ELSE IF (NP.LT.16777216) THEN
            NB = 3
          ELSE
            NB = 4
         ENDIF
         DO 5 I = 1, NS
            DO 6 K = 1, 3
               CALL GSENDBYTE(NODE(K,I),NB)
    6     CONTINUE
    5     CONTINUE
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(0)

*     HIGH TECHNIQUE HIDDEN LINE 

      IF (NSMODE.EQ.30) THEN
         M2 = 1
       ELSE
         M2 = 0
      ENDIF

      M1 = 1000
      CALL MALLOCTRISURFACECORE(X,Y,Z,F,NP,NODE,NS,IC,M1,M2,IND,IER)
      IF (IER.NE.0) THEN
         CALL FRAMESERROR('TRI SURFACE PROGRAM IS SOMETHING WRONG !')
         GO TO 999
      ENDIF

  990  CONTINUE
      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      CALL GWIOBDFLUSH(1)
*  999 IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
  999 RETURN
      END

      SUBROUTINE TRISURFACEMAIN(X,Y,Z,F,NP,NODE,NS,IC,M0,MODE,WS,HS)
      PARAMETER (NDIV=16)
      REAL*8 PI,TH,PH
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /PROF3DPARM/  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      REAL*8  XC,YC,ZC,DIU,DJU,DIV,DJV,FM1,FM2
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL*8 X(NP),Y(NP),Z(NP),F(NP)
      INTEGER NODE(3,NS)
      REAL*4  WS(*)
      INTEGER HS(*)

      IF (NSMODE.EQ.30) THEN
         NU     = NP/2
         NU2    = NP/4
       ELSE
         NU     = NP
         NU2    = NP/2
      ENDIF
      NT     = NS
      NR     = 0

      IW = 0
      JW = NU
      KW = NU + JW

      K0MAX0 = 0
      NNN1   = -1
      NNN2   = -1

      IF (NSMODE.EQ.30) THEN
         DO I = 1, NP, 2
            IW = IW + 1
            JW = JW + 1
            KW = KW + 1
            CALL COORDINXYZ(X(I),Y(I),Z(I),WS(IW),WS(JW))
            WS(KW) = -(ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
         ENDDO
       ELSE
         DO I = 1, NP
            IW = IW + 1
            JW = JW + 1
            KW = KW + 1
            CALL COORDINXYZ(X(I),Y(I),Z(I),WS(IW),WS(JW))
            WS(KW) = -(ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
         ENDDO
      ENDIF

      CALL HGWIOMINMAX(WS(1),WS(NU+1),IW,XXXMIN,YYYMIN,XXXMAX,YYYMAX)
      DRX    = (XXXMAX - XXXMIN)/NDIV
      DRY    = (YYYMAX - YYYMIN)/NDIV

      IF (NSMODE.LT.0) THEN
*         IF (IND.LT.3) IND = 3
         IND = 4
         CALL DRAWTRISURFACE(X,Y,Z,WS,HS,WS(NU*3+1),NU,NT,NODE,IND-3)
       ELSE
         IF (NSMODE.GE.1000) THEN
            ICC = -2
*            IF (IC/10.NE.0) ICC = -12
            CALL FGWIOCOLORSET(ICC,0,FM1,FM2)
         ENDIF
         XX1 = XPY*YPZ-YPY*XPZ
         YY1 = XPZ*YPX-YPZ*XPX
         ZZ1 = XPX*YPY-YPX*XPY
         IF (MDPROJ.EQ.0) THEN
            EEX = -XX1
            EEY = -YY1
            EEZ = -ZZ1
            RR  = SQRT(EEX**2+EEY**2+EEZ**2)
            EEX = EEX/RR
            EEY = EEY/RR
            EEZ = EEZ/RR
          ELSE
            XD0 = (XMAX+XMIN)/2
            YD0 = (YMAX+YMIN)/2
            ZD0 = (ZMAX+ZMIN)/2
*         0 = XPX*(X-XD0) + XPY*(Y-YD0) + XPZ*(Z-ZD0)
*         0 = YPX*(X-XD0) + YPY*(Y-YD0) + YPZ*(Z-ZD0)
*         1 = ZPX*(X-XD0) + ZPY*(Y-YD0) + ZPZ*(Z-ZD0)
            DET = ZPX*XX1+ZPY*YY1+ZPZ*ZZ1
            EEX = XD0 + XX1/DET
            EEY = YD0 + YY1/DET
            EEZ = ZD0 + ZZ1/DET
         ENDIF
         TH  = PI*LTH/180.D0
         PH  = PI*LPH/180.D0
         IF (MOD3DIR.EQ.1) THEN
            CLGY    =  COS(TH)*COS(PH)
            CLGZ    =  COS(TH)*SIN(PH)
            CLGX    =  SIN(TH)
          ELSE IF (MOD3DIR.EQ.2) THEN
            CLGZ    =  COS(TH)*COS(PH)
            CLGX    =  COS(TH)*SIN(PH)
            CLGY    =  SIN(TH)
          ELSE
            CLGX    =  COS(TH)*COS(PH)
            CLGY    =  COS(TH)*SIN(PH)
            CLGZ    =  SIN(TH)
         ENDIF
         CALL DRAWTRISURFACE(X,Y,Z,WS,HS,WS,NU,NT,NODE,-1)
         IF (NSMODE.EQ.10) THEN
            CALL WITHNORMALVECTOR(X,Y,Z,WS,HS,NU,NT,NODE,ISVEC)
          ELSE IF (M0.EQ.1000) THEN
            CALL DFILL3DTRIANGS(X,Y,Z,F,WS,HS,NU,NT,NODE,IC)
          ELSE
*            CALL DFILL3DTRIANGS(X,Y,Z,WS,HS,NU,NT,NODE,IC)
            IF (MOD3DIR.EQ.1) THEN
               CALL DFILL3DTRIANGS(X,Y,Z,X,WS,HS,NU,NT,NODE,IC)
             ELSE IF (MOD3DIR.EQ.2) THEN
               CALL DFILL3DTRIANGS(X,Y,Z,Y,WS,HS,NU,NT,NODE,IC)
             ELSE
               CALL DFILL3DTRIANGS(X,Y,Z,Z,WS,HS,NU,NT,NODE,IC)
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE FR_ISOSURFACE(F,IMAX,JMAX,KMAX,F0,ICOL,MODE)
      REAL*8 F(0:IMAX-1,0:JMAX-1,0:KMAX-1),F0
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /GRAPH3DMOD/ MODE3D,MODEGEOM
      COMMON /COLOR256COM/ NCL256,ICOL256,ICOLMODE
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      COMMON /CONTREG3DCOM/ CNXMIN,CNXMAX,CNYMIN,CNYMAX
     ,                     ,CNZMIN,CNZMAX,ICNREG
      COMMON /REGIONSCOM3D/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NZDMIN,NZDMAX
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      REAL*8  BOUND(6),FM1,FM2
      INTEGER IBOUND(6)

      IF (IGCANVAS.LT.0) RETURN

      IF (NXDMIN.GT.0) THEN
         NX1 = NXDMIN - 1
         NX2 = NXDMAX - 1
         IF (NX1.GE.IMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF I REGION - ISOSURFACE')
            RETURN
         ENDIF
         IF (NX2.GE.IMAX) NX2 = IMAX - 1
       ELSE
         NX1 = 0
         NX2 = IMAX - 1
      ENDIF

      IF (NYDMIN.GT.0) THEN
         NY1 = NYDMIN - 1
         NY2 = NYDMAX - 1
         IF (NY1.GE.JMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF J REGION - ISOSURFACE')
            RETURN
         ENDIF
         IF (NY2.GE.JMAX) NY2 = JMAX - 1
       ELSE
         NY1 = 0
         NY2 = JMAX - 1
      ENDIF

      IF (NZDMIN.GT.0) THEN
         NZ1 = NZDMIN - 1
         NZ2 = NZDMAX - 1
         IF (NZ1.GE.KMAX - 1) THEN
            CALL FRAMESERROR('SETTINGS OUT OF K REGION - ISOSURFACE')
            RETURN
         ENDIF
         IF (NZ2.GE.KMAX) NZ2 = KMAX - 1
       ELSE
         NZ1 = 0
         NZ2 = KMAX - 1
      ENDIF

      IF (NX2.LE.NX1.OR.NY2.LE.NY1.OR.NZ2.LE.NZ1) THEN
         CALL FRAMESERROR('ISOSURFACE PROGRAM NEEDS MORE THAN 1 DATA')
         RETURN
      ENDIF

      IF (ICNREG.EQ.0) THEN
         CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
         CNZMAX = ((KMAX-1)*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
       ELSE IF (ICNREG.GT.2) THEN
         ICN = ICNREG-2
         IF (IAND(ICN,1).NE.0) THEN
            CNXMIN = (XMIN*NX2-XMAX*NX1)/(NX2-NX1)
            CNXMAX = ((IMAX-1)*(XMAX-XMIN)+XMIN*NX2-XMAX*NX1)/(NX2-NX1)
         ENDIF
         IF (IAND(ICN,2).NE.0) THEN
            CNYMIN = (YMIN*NY2-YMAX*NY1)/(NY2-NY1)
            CNYMAX = ((JMAX-1)*(YMAX-YMIN)+YMIN*NY2-YMAX*NY1)/(NY2-NY1)
         ENDIF
         IF (IAND(ICN,4).NE.0) THEN
            CNZMIN = (ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
            CNZMAX = ((KMAX-1)*(ZMAX-ZMIN)+ZMIN*NZ2-ZMAX*NZ1)/(NZ2-NZ1)
         ENDIF
      ENDIF

      ICOLMODE = 0
      IND      = MOD(MODE,10)
      NSMODE   = MODE/10
      NBCOL    = -1
      IC       = MOD(ICOL,100)
      IF ((ICOL.LT.0.AND.IND.LE.4).OR.IND.GT.4) THEN
         IF (IC.LT.0) IC = -IC
         IF (IND.GE.5) THEN
            NBCOL = ABS(ICOL)/100
            IF (NBCOL.EQ.0) NBCOL = -1
         ENDIF
         IF (ICOL256.GE.0) THEN
            CALL ISHLSLIGHTSET(IC,1)
*            CALL STORECURRENTCOLMAP
            ICOLMODE = 4
          ELSE
            CALL ISHLSLIGHTSET(IC,-1)
         ENDIF
         IF (IND.GT.5) THEN
            NDMODE = 3
          ELSE
            NDMODE = 2
         ENDIF
       ELSE
         IF (ICOL/100.GT.0) THEN
            NBCOL  = IC
            IC     = ICOL/100
            NSMODE = 100
          ELSE
            NSMODE = -1
        ENDIF
         IF (IND.EQ.0) THEN
            NDMODE = 0
          ELSE
            NDMODE = 1
         ENDIF
      ENDIF

      IF (IGPLT.GT.0) THEN
         FM1 = F(0,0,0)
         FM2 = FM1
         DO 10 K = 0, KMAX-1
           DO 11 J = 0, JMAX-1
             DO 12 I = 0, IMAX-1
               IF (F(I,J,K).LT.FM1) FM1 = F(I,J,K)
               IF (F(I,J,K).GT.FM2) FM2 = F(I,J,K)
   12        CONTINUE
   11        CONTINUE
   10        CONTINUE
         IF (NSMODE.GE.0) THEN
            IF (ILIGHT.EQ.0) CALL FR_SETLIGHT(0.D0,0.D0,-1000)
            IF (ISURF.EQ.0)  CALL FR_SETSURFACE(0.D0,0.D0,-1000)
         ENDIF
         CALL GSENDBYTE(72,1)
         CALL GSENDBYTE(MODE,2)
         CALL GSENDBYTE(ICOL,2)
         CALL GSENDBYTE(IMAX,4)
         CALL GSENDBYTE(JMAX,4)
         CALL GSENDBYTE(KMAX,4)
         CALL GSEND8BYTE(DBLE(CNXMIN),DBLE(CNXMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNYMIN),DBLE(CNYMAX),1,0)
         CALL GSEND8BYTE(DBLE(CNZMIN),DBLE(CNZMAX),1,0)
         CALL GSEND8BYTE(F0,F0,1,-1)
         CALL GSEND8BYTE(F,(FM1+FM2)/2,IMAX*JMAX*KMAX,4)
      ENDIF
      IF (IGCANVAS.EQ.0) GO TO 999

      IF (IC.EQ.0) RETURN
      
      IF (MODE3D.EQ.0) THEN
         CALL FRAMESERROR('3D MODE IS DIFFERERNT FOR ISOSURFACE')
         RETURN
      ENDIF

      IF (IFRAM.EQ.0) THEN
*         IFRAM = 999
         IF (IDFFR3.LT.0) THEN
            IDFR = 3
          ELSE
            IDFR = IDFFR3
         ENDIF
         CALL FR_FRAME3D(DBLE(NX1),DBLE(NX2),DBLE(NY1),DBLE(NY2)
     ,                                  ,DBLE(NZ1),DBLE(NZ2),IDFR)
      ENDIF

      CALL GWIOBDFREEZ(IER)
      IF (IER.NE.0) GO TO 999
      CALL GWIOSETAASPACE(0)

      IF (NSMODE.LT.0.OR.MODE.EQ.0) THEN
         CALL GWIOCOLOR(2,IC)
      ENDIF

      IBOUND(1) = NX1
      IBOUND(2) = NX2
      IBOUND(3) = NY1
      IBOUND(4) = NY2
      IBOUND(5) = NZ1
      IBOUND(6) = NZ2
      BOUND(1)  = CNXMIN
      BOUND(2)  = CNXMAX
      BOUND(3)  = CNYMIN
      BOUND(4)  = CNYMAX
      BOUND(5)  = CNZMIN
      BOUND(6)  = CNZMAX
      CALL ISOSURFACECORE(F,IMAX,JMAX,KMAX,IBOUND,BOUND,F0,IC,NDMODE)
      IF (NDMODE.NE.0) THEN
         CALL FRAMESERROR('MEMORY ALLOCATION FAILED FOR ISOSURFACE')
      ENDIF

      IF (IFRAM.NE.2) THEN
         CALL FR_FRAME3D(0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,99999)
      ENDIF

      CALL GWIOBDFLUSH(1)
  999 IF (ICOLMODE.NE.0) CALL ISHLSLIGHTSET(IC,0)
      RETURN
      END

*      SUBROUTINE ONLY CALLED BY ISOSURFACE

      SUBROUTINE ISOTRIANGLES(X,Y,Z,NDX,NDY,NDZ,NP,NODE,NS,IC,NDMODE,WS)
      PARAMETER (NDIV=16)
      REAL*8 PI,TH,PH
      PARAMETER (PI=3.141592653589793D0)
      COMMON /GRAPHCOM3D/ XMIN,XMAX,YMIN,YMAX,XTAN,YTAN,X0,Y0
     +        ,ZMIN,ZMAX,ZXTAN,ZX0,ZYTAN,ZY0,GX,GY
     +        ,IXMIN,IXMAX,IYMIN,IYMAX,IZXMAX,IZYMAX,IFRAM,IVIEW
      COMMON /PROJECTCOM/ XPX,XPY,XPZ,YPX,YPY,YPZ,XP0,YP0,THETA,PHI
     +        ,RATIO,RATIOXY,RATIOXZ,XPMID,YPMID
     +        ,IXPMIN,IXPMAX,IYPMIN,IYPMAX,IPROJ
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /LIGHTINGCOM/ CAMB,CDIF,CSPC,LTH,LPH,NSPORDER,ILIGHT,ISURF
      REAL*4 X(NP),Y(NP),Z(NP),NDX(*),NDY(*),NDZ(*),WS(*)
      INTEGER NODE(3,NS)
      REAL    TRIX(3),TRIY(3)

      IF (NDMODE.EQ.0) THEN
         DO 10 K = 1, NS
            DO 110 J = 1, 3
               CALL COORDINXYZ(DBLE(X(NODE(J,K))),DBLE(Y(NODE(J,K)))
     ,                           ,DBLE(Z(NODE(J,K))),TRIX(J),TRIY(J))
  110          CONTINUE
            CALL GWIOPOLYGON(TRIX,TRIY,3,1)
   10     CONTINUE
         RETURN
      ENDIF

*     HIGH TECHNIQUE HIDDEN LINE 

      NU     = NP
      NU2    = NP/2
      NT     = NS
      NR     = 0

      IW = 0
      JW = NU
      KW = NU + JW

      K0MAX0 = 0
      NNN1   = -1
      NNN2   = -1

      DO I = 1, NP
         IW = IW + 1
         JW = JW + 1
         KW = KW + 1
         CALL COORDINXYZ(DBLE(X(I)),DBLE(Y(I)),DBLE(Z(I)),WS(IW),WS(JW))
         WS(KW) = -(ZPX*X(I) + ZPY*Y(I) + ZPZ*Z(I))
      ENDDO

      CALL HGWIOMINMAX(WS(1),WS(NU+1),IW,XXXMIN,YYYMIN,XXXMAX,YYYMAX)
      DRX    = (XXXMAX - XXXMIN)/NDIV
      DRY    = (YYYMAX - YYYMIN)/NDIV

      IF (NSMODE.LT.0) THEN
         CALL DRAWTRISURFACE(X,Y,Z,WS,WS(NU*4+1),WS(NU*3+1)
     ,                                        ,NU,NT,NODE,-1000)
       ELSE
         XX1 = XPY*YPZ-YPY*XPZ
         YY1 = XPZ*YPX-YPZ*XPX
         ZZ1 = XPX*YPY-YPX*XPY
         IF (MDPROJ.EQ.0) THEN
            EEX = -XX1
            EEY = -YY1
            EEZ = -ZZ1
*            EEX = ZPX
*            EEY = ZPY
*            EEZ = ZPZ
            RR  = SQRT(EEX*EEX+EEY*EEY+EEZ*EEZ)
            EEX = EEX/RR
            EEY = EEY/RR
            EEZ = EEZ/RR
          ELSE
            XD0 = (XMAX+XMIN)/2
            YD0 = (YMAX+YMIN)/2
            ZD0 = (ZMAX+ZMIN)/2
*         0 = XPX*(X-XD0) + XPY*(Y-YD0) + XPZ*(Z-ZD0)
*         0 = YPX*(X-XD0) + YPY*(Y-YD0) + YPZ*(Z-ZD0)
*         1 = ZPX*(X-XD0) + ZPY*(Y-YD0) + ZPZ*(Z-ZD0)
            DET = ZPX*XX1+ZPY*YY1+ZPZ*ZZ1
            EEX = XD0 + XX1/DET
            EEY = YD0 + YY1/DET
            EEZ = ZD0 + ZZ1/DET
         ENDIF
         TH  = PI*LTH/180.D0
         PH  = PI*LPH/180.D0
         IF (MOD3DIR.EQ.1) THEN
            CLGY    =  COS(TH)*COS(PH)
            CLGZ    =  COS(TH)*SIN(PH)
            CLGX    =  SIN(TH)
          ELSE IF (MOD3DIR.EQ.2) THEN
            CLGZ    =  COS(TH)*COS(PH)
            CLGX    =  COS(TH)*SIN(PH)
            CLGY    =  SIN(TH)
          ELSE
            CLGX    =  COS(TH)*COS(PH)
            CLGY    =  COS(TH)*SIN(PH)
            CLGZ    =  SIN(TH)
         ENDIF
         CALL DRAWTRISURFACE(X,Y,Z,WS,WS(NU*3+1),WS,NU,NT,NODE,-1000)
         IF (NDMODE.EQ.3) THEN
            CALL RSFILL3DTRIANGS(X,Y,Z,NDX,NDY,NDZ
     ,                            ,WS,WS(NU*3+1),NU,NT,NODE)
          ELSE
            CALL RFILL3DTRIANGS(X,Y,Z,WS,WS(NU*3+1),NU,NT,NODE,IC)
         ENDIF
      ENDIF

      RETURN
      END

      SUBROUTINE DRAWTRISURFACE(X,Y,Z,WS,HS,BS,NP,NS,NODE,IND)
      PARAMETER (NDIV=16)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /CLIPPINGCOM/ ICLP,ICLP3D
      common /com3dborder/ tdx1,tdy1,tdz1,tdx2,tdy2,tdz2
      REAL*8    X(*),Y(*),Z(*)
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,4)
      BYTE      BS(NP,3)
      INTEGER   NODE(3,*)
      REAL      TRIX(3),TRIY(3)

      IF (IND.EQ.-1000) THEN
         IND1 = 0
         IPRE = 0
         IF (NSMODE.GE.0) IND1 = -1
       ELSE
         IND1 = IND
         IPRE = 1
         IF (IND1.GT.0.AND.NP.LT.NDIV*NDIV) IND1 = 0
      ENDIF

      IF (ICLP3D.EQ.0.OR.IPRE.EQ.0) THEN
         DO 10 N = 1, NT
            HS(N,2) = N
   10    CONTINUE
         NORDER = NT

       ELSE IF (NSMODE.EQ.30) THEN
         NORDER = 0
         DO 11 N = 1, NT
            N1    = 2*NODE(1,N)-1
            N2    = 2*NODE(2,N)-1
            N3    = 2*NODE(3,N)-1
            XX    = (X(N1)+X(N2)+X(N3))/3
            YY    = (Y(N1)+Y(N2)+Y(N3))/3
            ZZ    = (Z(N1)+Z(N2)+Z(N3))/3
            IF (XX.GE.tdx1.AND.XX.LE.tdx2.AND.
     +               YY.GE.tdy1.AND.YY.LE.tdy2.AND.
     +                     ZZ.GE.tdz1.AND.ZZ.LE.tdz2) THEN
               NORDER = NORDER + 1
               HS(NORDER,2) = N
            ENDIF
   11    CONTINUE
       ELSE
         NORDER = 0
         DO 12 N = 1, NT
            N1    = NODE(1,N)
            N2    = NODE(2,N)
            N3    = NODE(3,N)
            XX    = (X(N1)+X(N2)+X(N3))/3
            YY    = (Y(N1)+Y(N2)+Y(N3))/3
            ZZ    = (Z(N1)+Z(N2)+Z(N3))/3
            IF (XX.GE.tdx1.AND.XX.LE.tdx2.AND.
     +               YY.GE.tdy1.AND.YY.LE.tdy2.AND.
     +                     ZZ.GE.tdz1.AND.ZZ.LE.tdz2) THEN
               NORDER = NORDER + 1
               HS(NORDER,2) = N
            ENDIF
   12    CONTINUE
      ENDIF

      IND0 = IND1
      CALL TRZDATASORT(WS(1,1),WS(1,2),WS(1,3),HS(1,1),HS(1,2),HS(1,3)
     ,                  ,NODE,IND0)
      IF (NSMODE.GE.0) RETURN

      IF (IND1.NE.0) THEN
         IF (IND0.GT.NORDER*2/3) THEN
            IND0 = 0
           ELSE
            IND0 = 1
            CALL TRREGIONORDER(HS(1,3),BS,HS(1,4))
         ENDIF
      ENDIF

      DO N = 1, NU
         XXX = WS(N,1)
         YYY = WS(N,2)
         ZZZ = WS(N,3)
         CALL TRSEARCHIMAX2(HS)
         IF (IV.NE.0) CALL TRVISIBLEDOT(WS,HS(1,2),BS
     ,                         ,HS(1,3),HS(1,4),NODE,IND0)
         BS(N,3) = IV
      ENDDO

      CALL TRREMOVEHIDDEN(HS,HS(1,2),HS(1,3),BS(1,3),NODE)

      NR   = 0

      DO K = 1, NORDER
         KN = HS(K,2)
         N1 = NODE(1,KN)
         N2 = NODE(2,KN)
         N3 = NODE(3,KN)

         IF (BS(N1,3).NE.0.AND.BS(N2,3).NE.0.AND.BS(N3,3).NE.0) THEN
            TRIX(1)  = WS(N1,1)
            TRIX(2)  = WS(N2,1)
            TRIX(3)  = WS(N3,1)
            TRIY(1)  = WS(N1,2)
            TRIY(2)  = WS(N2,2)
            TRIY(3)  = WS(N3,2)
            ZZ1      = WS(N1,3)
            ZZ2      = WS(N2,3)
            ZZ3      = WS(N3,3)
            XXX = (TRIX(1) + TRIX(2) + TRIX(3))/3
            YYY = (TRIY(1) + TRIY(2) + TRIY(3))/3
            ZZZ = (ZZ1 + ZZ2 + ZZ3)/3
            CALL TRSEARCHIMAX(HS,HS(1,3),BS)
            IF (IV.NE.0) THEN
               CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
            ENDIF
*            write(*,*) kn,iv
            IF (IV.NE.0) THEN
               CALL GWIOPOLYGON(TRIX,TRIY,3,1)
            ENDIF
          ELSE
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N1,N2)
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N2,N3)
            CALL TRHIDBRANCH(WS,HS,BS,NU,NT,NODE,N3,N1)
         ENDIF
      ENDDO

      RETURN
      END

      SUBROUTINE DFILL3DTRIANGS(X,Y,Z,F,WS,HS,NP,NS,NODE,IC)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8    X(*),Y(*),Z(*),F(*)
      REAL*4    WS(NP,3),CS,RS
      INTEGER   HS(NS,4),NODE(3,*)
      REAL      TRIX(3),TRIY(3),FH(3),FK(3)

      IF (NSMODE.EQ.1000) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            FH(1)   = F(N1)
            FH(2)   = F(N2)
            FH(3)   = F(N3)
            CALL FGWIOTRIANGLE(TRIX,TRIY,FH,NBCOL)
         ENDDO

       ELSE IF (NSMODE.GE.2000.AND.NSMODE.LE.2010) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            FH(1)   = F(N1)
            FH(2)   = F(N2)
            FH(3)   = F(N3)
            CALL FGWIOSTRIANGLE(TRIX,TRIY,FH,NBCOL,NSMODE-2000)
         ENDDO

       ELSE IF (NSMODE.GE.3000.AND.NSMODE.LE.3010) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            FH(1)   = F(N1)
            FH(2)   = F(N2)
            FH(3)   = F(N3)
            CALL FGWIOFTRIANGLE(TRIX,TRIY,FH,NBCOL,NSMODE-3000)
         ENDDO

       ELSE IF (NSMODE.EQ.30) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL DNORMPOINTS(X,Y,Z,N1,N2,N3,FH,FK)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
*            FK(1)   = 2*FH(1)*FK(1)-EEZ
*            FK(2)   = 2*FH(2)*FK(2)-EEZ
*            FK(3)   = 2*FH(3)*FK(3)-EEZ
            CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
         ENDDO

       ELSE IF (NSMODE.EQ.1) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL DNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            IF (CSS.GT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.2) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL DNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            IF (CSS.LT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.100) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL SGWIOPOLYGON(TRIX,TRIY,3,IC,NBCOL)
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL DNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE RFILL3DTRIANGS(X,Y,Z,WS,HS,NP,NS,NODE,IC)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*4    X(*),Y(*),Z(*)
      REAL*4    WS(NP,3),CS,RS
      INTEGER   HS(NS,4),NODE(3,*)
      REAL      TRIX(3),TRIY(3)

      IF (NSMODE.EQ.1) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            IF (CSS.GT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.2) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            IF (CSS.LT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.100) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL SGWIOPOLYGON(TRIX,TRIY,3,IC,NBCOL)
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMTRIANGLE(X,Y,Z,N1,N2,N3,CS,RS,CSS)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL LGWIOPOLYGON(TRIX,TRIY,3,CS,RS,NBCOL)
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE DSFILL3DTRIANGS(X,Y,Z,LITN,EYER,EYEN,WS,HS,NP,NS,NODE)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8    X(*),Y(*),Z(*)
      REAL*4    LITN(*),EYER(*),EYEN(*)
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,4),NODE(3,*)
      REAL      TRIX(3),TRIY(3),FH(3),FK(3)

      IF (NSMODE.EQ.1) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            FH(1) = LITN(N1)
            FH(2) = LITN(N2)
            FH(3) = LITN(N3)
            FK(1) = EYER(N1)
            FK(2) = EYER(N2)
            FK(3) = EYER(N3)
            CSS   = EYEN(N1)+EYEN(N2)+EYEN(N3)
            IF (CSS.GT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.2) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            FH(1) = LITN(N1)
            FH(2) = LITN(N2)
            FH(3) = LITN(N3)
            FK(1) = EYER(N1)
            FK(2) = EYER(N2)
            FK(3) = EYER(N3)
            CSS   = EYEN(N1)+EYEN(N2)+EYEN(N3)
            IF (CSS.LT.0) THEN
               FH(1) = -FH(1)
               FH(2) = -FH(2)
               FH(3) = -FH(3)
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
            ENDIF
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            FH(1) = LITN(N1)
            FH(2) = LITN(N2)
            FH(3) = LITN(N3)
            FK(1) = EYER(N1)
            FK(2) = EYER(N2)
            FK(3) = EYER(N3)
            CSS   = EYEN(N1)+EYEN(N2)+EYEN(N3)
            IF (CSS.LT.0) THEN
               FH(1) = -FH(1)
               FH(2) = -FH(2)
               FH(3) = -FH(3)
            ENDIF
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE DSFILL3DWITHVECT(X,Y,Z,NDX,NDY,NDZ,WS,HS,NP,NS,NODE)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*8    X(*),Y(*),Z(*)
      REAL*4    NDX(*),NDY(*),NDZ(*)
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,4),NODE(3,*)
      REAL      TRIX(3),TRIY(3),FH(3),FK(3)

      IF (NSMODE.EQ.1) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RDNORMVPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            IF (CSS.GT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
               CALL DNORMALVECTORS(X(N1),Y(N1),Z(N1)
     +                             ,NDX(N1),NDY(N1),NDZ(N1),7)
               CALL DNORMALVECTORS(X(N2),Y(N2),Z(N2)
     +                             ,NDX(N2),NDY(N2),NDZ(N2),7)
               CALL DNORMALVECTORS(X(N3),Y(N3),Z(N3)
     +                             ,NDX(N3),NDY(N3),NDZ(N3),7)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.2) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RDNORMVPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            IF (CSS.LT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
               CALL DNORMALVECTORS(X(N1),Y(N1),Z(N1)
     +                             ,NDX(N1),NDY(N1),NDZ(N1),7)
               CALL DNORMALVECTORS(X(N2),Y(N2),Z(N2)
     +                             ,NDX(N2),NDY(N2),NDZ(N2),7)
               CALL DNORMALVECTORS(X(N3),Y(N3),Z(N3)
     +                             ,NDX(N3),NDY(N3),NDZ(N3),7)
            ENDIF
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RDNORMVPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
            CALL DNORMALVECTORS(X(N1),Y(N1),Z(N1)
     +                             ,NDX(N1),NDY(N1),NDZ(N1),7)
            CALL DNORMALVECTORS(X(N2),Y(N2),Z(N2)
     +                             ,NDX(N2),NDY(N2),NDZ(N2),7)
            CALL DNORMALVECTORS(X(N3),Y(N3),Z(N3)
     +                             ,NDX(N3),NDY(N3),NDZ(N3),7)
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE RSFILL3DTRIANGS(X,Y,Z,NDX,NDY,NDZ,WS,HS,NP,NS,NODE)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      REAL*4    X(*),Y(*),Z(*),NDX(*),NDY(*),NDZ(*)
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,4),NODE(3,*)
      REAL      TRIX(3),TRIY(3),FH(3),FK(3)

      IF (NSMODE.EQ.1) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            IF (CSS.GT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
*               CALL RNORMALVECTORS(X(N1),Y(N1),Z(N1),NDX(N1),NDY(N1),NDZ(N1),7)
*               CALL RNORMALVECTORS(X(N2),Y(N2),Z(N2),NDX(N2),NDY(N2),NDZ(N2),7)
*               CALL RNORMALVECTORS(X(N3),Y(N3),Z(N3),NDX(N3),NDY(N3),NDZ(N3),7)
            ENDIF
         ENDDO

       ELSE IF (NSMODE.EQ.2) THEN
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            IF (CSS.LT.0) THEN
               TRIX(1) = WS(N1,1)
               TRIX(2) = WS(N2,1)
               TRIX(3) = WS(N3,1)
               TRIY(1) = WS(N1,2)
               TRIY(2) = WS(N2,2)
               TRIY(3) = WS(N3,2)
               CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
*               CALL RNORMALVECTORS(X(N1),Y(N1),Z(N1),NDX(N1),NDY(N1),NDZ(N1),7)
*               CALL RNORMALVECTORS(X(N2),Y(N2),Z(N2),NDX(N2),NDY(N2),NDZ(N2),7)
*               CALL RNORMALVECTORS(X(N3),Y(N3),Z(N3),NDX(N3),NDY(N3),NDZ(N3),7)
            ENDIF
         ENDDO

       ELSE
         DO K = NORDER, 1, -1
            KN = HS(K,2)
            N1 = NODE(1,KN)
            N2 = NODE(2,KN)
            N3 = NODE(3,KN)
            CALL RNORMPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,FH,FK,CSS)
            TRIX(1) = WS(N1,1)
            TRIX(2) = WS(N2,1)
            TRIX(3) = WS(N3,1)
            TRIY(1) = WS(N1,2)
            TRIY(2) = WS(N2,2)
            TRIY(3) = WS(N3,2)
            CALL LGWIOTRIANGLE(TRIX,TRIY,FH,FK,NBCOL)
*            CALL RNORMALVECTORS(X(N1),Y(N1),Z(N1),NDX(N1),NDY(N1),NDZ(N1),7)
*            CALL RNORMALVECTORS(X(N2),Y(N2),Z(N2),NDX(N2),NDY(N2),NDZ(N2),7)
*            CALL RNORMALVECTORS(X(N3),Y(N3),Z(N3),NDX(N3),NDY(N3),NDZ(N3),7)
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE RNORMALVECTORS(X,Y,Z,DX,DY,DZ,IC)
      REAL*4    X,Y,Z,DX,DY,DZ
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IGG   = IGPLT
      IGPLT = 0
      CALL FR_VECTOR3D(DBLE(X),DBLE(Y),DBLE(Z)
     ,                ,DBLE(DX),DBLE(DY),DBLE(DZ),IC,0)
      IGPLT = IGG

      RETURN
      END

      SUBROUTINE DNORMALVECTORS(X,Y,Z,DX,DY,DZ,IC)
      REAL*8    X,Y,Z
      REAL*4    DX,DY,DZ
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IGG   = IGPLT
      IGPLT = 0
      R     = 0.03
      CALL FR_VECTOR3D(X,Y,Z,DBLE(R*DX),DBLE(R*DY),DBLE(R*DZ),IC,0)
      IGPLT = IGG

      RETURN
      END

*     LITN....    NORM.LIGHT
*     EYER....    EYE.REFLECT
      SUBROUTINE DNORMPOINTS(X,Y,Z,N1,N2,N3,LITN,EYER)
      REAL*8 X(*),Y(*),Z(*)
      REAL  LITN(3),EYER(3),DSX(3),DSY(3),DSZ(3),EEX0(3),EEY0(3),EEZ0(3)
      REAL  XX(3),YY(3),ZZ(3)
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC

      M1 = 2*N1
      M2 = 2*N2
      M3 = 2*N3
      XX(1) = X(M1-1)
      XX(2) = X(M2-1)
      XX(3) = X(M3-1)
      YY(1) = Y(M1-1)
      YY(2) = Y(M2-1)
      YY(3) = Y(M3-1)
      ZZ(1) = Z(M1-1)
      ZZ(2) = Z(M2-1)
      ZZ(3) = Z(M3-1)

      DSX(1) = X(M1)
      DSX(2) = X(M2)
      DSX(3) = X(M3)
      DSY(1) = Y(M1)
      DSY(2) = Y(M2)
      DSY(3) = Y(M3)
      DSZ(1) = Z(M1)
      DSZ(2) = Z(M2)
      DSZ(3) = Z(M3)

      IF (MDPROJ.NE.0) THEN
         DO 11 I = 1, 3
            EEX0(I) = EEX-XX(I)
            EEY0(I) = EEY-YY(I)
            EEZ0(I) = EEZ-ZZ(I)
            RN  = SQRT(EEX0(I)*EEX0(I)+EEY0(I)*EEY0(I)+EEZ0(I)*EEZ0(I))
            EEX0(I) = EEX0(I)/RN
            EEY0(I) = EEY0(I)/RN
            EEZ0(I) = EEZ0(I)/RN
   11    CONTINUE
         EN1  = (EEX-XX(1))*DSX(1)+(EEY-YY(1))*DSY(1)+(EEZ-ZZ(1))*DSZ(1)
         EN2  = (EEX-XX(2))*DSX(2)+(EEY-YY(2))*DSY(2)+(EEZ-ZZ(2))*DSZ(2)
         EN3  = (EEX-XX(3))*DSX(3)+(EEY-YY(3))*DSY(3)+(EEZ-ZZ(3))*DSZ(3)
       ELSE
         DO 12 I = 1, 3
            EEX0(I) = EEX
            EEY0(I) = EEY
            EEZ0(I) = EEZ
   12    CONTINUE
         EN1  = EEX*DSX(1)+EEY*DSY(1)+EEZ*DSZ(1)
         EN2  = EEX*DSX(2)+EEY*DSY(2)+EEZ*DSZ(2)
         EN3  = EEX*DSX(3)+EEY*DSY(3)+EEZ*DSZ(3)
      ENDIF

      IF (EN1+EN2+EN3.LT.0) THEN
         DO 22 I = 1, 3
            DSX(I) = -DSX(I)
            DSY(I) = -DSY(I)
            DSZ(I) = -DSZ(I)
   22    CONTINUE
      ENDIF

      DO 10 I = 1, 3
         RN = DSX(I)*DSX(I)+DSY(I)*DSY(I)+DSZ(I)*DSZ(I)
         IF (RN.EQ.0) THEN
            EYER(I) = 0
            LITN(I) = 0
          ELSE
            RN = 1/SQRT(RN)
            LITN(I) = (CLGX*DSX(I)+CLGY*DSY(I)+CLGZ*DSZ(I))*RN
            RX = 2*LITN(I)*DSX(I)*RN -CLGX
            RY = 2*LITN(I)*DSY(I)*RN -CLGY
            RZ = 2*LITN(I)*DSZ(I)*RN -CLGZ
            EYER(I) = EEX0(I)*RX+EEY0(I)*RY+EEZ0(I)*RZ
         ENDIF
   10 CONTINUE
      RETURN
      END

      SUBROUTINE RDNORMPOINTS(XX,YY,ZZ,NDX,NDY,NDZ,LITN,EYER,EYEN)
      REAL*8 XX,YY,ZZ,NDX,NDY,NDZ,LITN,EYER,EYEN,EEX0,EEY0,EEZ0
      REAL*8 RN
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC

      IF (MDPROJ.NE.0) THEN
         EEX0 = EEX-XX
         EEY0 = EEY-YY
         EEZ0 = EEZ-ZZ
         RN  = SQRT(EEX0*EEX0+EEY0*EEY0+EEZ0*EEZ0)
         EEX0 = EEX0/RN
         EEY0 = EEY0/RN
         EEZ0 = EEZ0/RN
         EYEN = (EEX-XX)*NDX+(EEY-YY)*NDY+(EEZ-ZZ)*NDZ
       ELSE
         EEX0 = EEX
         EEY0 = EEY
         EEZ0 = EEZ
         EYEN = EEX*NDX+EEY*NDY+EEZ*NDZ
      ENDIF

      RN = NDX*NDX+NDY*NDY+NDZ*NDZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         RN = 1/SQRT(RN)
         LITN = (CLGX*NDX+CLGY*NDY+CLGZ*NDZ)*RN
         RX = 2*LITN*NDX*RN -CLGX
         RY = 2*LITN*NDY*RN -CLGY
         RZ = 2*LITN*NDZ*RN -CLGZ
         EYER = EEX0*RX+EEY0*RY+EEZ0*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE RDNORMVPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3
     +                                          ,LITN,EYER,EYEN)
      REAL*8 X(*),Y(*),Z(*)
      REAL*4 NDX(*),NDY(*),NDZ(*)
      REAL  LITN(3),EYER(3),DSX(3),DSY(3),DSZ(3),EEX0(3),EEY0(3),EEZ0(3)
      REAL  XX(3),YY(3),ZZ(3)
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC

      XX(1) = X(N1)
      XX(2) = X(N2)
      XX(3) = X(N3)
      YY(1) = Y(N1)
      YY(2) = Y(N2)
      YY(3) = Y(N3)
      ZZ(1) = Z(N1)
      ZZ(2) = Z(N2)
      ZZ(3) = Z(N3)

      DSX(1) = NDX(N1)
      DSX(2) = NDX(N2)
      DSX(3) = NDX(N3)
      DSY(1) = NDY(N1)
      DSY(2) = NDY(N2)
      DSY(3) = NDY(N3)
      DSZ(1) = NDZ(N1)
      DSZ(2) = NDZ(N2)
      DSZ(3) = NDZ(N3)

      IF (MDPROJ.NE.0) THEN
         DO 11 I = 1, 3
            EEX0(I) = EEX-XX(I)
            EEY0(I) = EEY-YY(I)
            EEZ0(I) = EEZ-ZZ(I)
            RN  = SQRT(EEX0(I)*EEX0(I)+EEY0(I)*EEY0(I)+EEZ0(I)*EEZ0(I))
            EEX0(I) = EEX0(I)/RN
            EEY0(I) = EEY0(I)/RN
            EEZ0(I) = EEZ0(I)/RN
   11    CONTINUE
         EN1  = (EEX-XX(1))*DSX(1)+(EEY-YY(1))*DSY(1)+(EEZ-ZZ(1))*DSZ(1)
         EN2  = (EEX-XX(2))*DSX(2)+(EEY-YY(2))*DSY(2)+(EEZ-ZZ(2))*DSZ(2)
         EN3  = (EEX-XX(3))*DSX(3)+(EEY-YY(3))*DSY(3)+(EEZ-ZZ(3))*DSZ(3)
       ELSE
         DO 12 I = 1, 3
            EEX0(I) = EEX
            EEY0(I) = EEY
            EEZ0(I) = EEZ
   12    CONTINUE
         EN1  = EEX*DSX(1)+EEY*DSY(1)+EEZ*DSZ(1)
         EN2  = EEX*DSX(2)+EEY*DSY(2)+EEZ*DSZ(2)
         EN3  = EEX*DSX(3)+EEY*DSY(3)+EEZ*DSZ(3)
      ENDIF

      EYEN = EN1+EN2+EN3
      IF (EYEN.LT.0) THEN
         DO 22 I = 1, 3
            DSX(I) = -DSX(I)
            DSY(I) = -DSY(I)
            DSZ(I) = -DSZ(I)
   22    CONTINUE
      ENDIF

      DO 10 I = 1, 3
         RN = DSX(I)*DSX(I)+DSY(I)*DSY(I)+DSZ(I)*DSZ(I)
         IF (RN.EQ.0) THEN
            EYER(I) = 0
            LITN(I) = 0
          ELSE
            RN = 1/SQRT(RN)
            LITN(I) = (CLGX*DSX(I)+CLGY*DSY(I)+CLGZ*DSZ(I))*RN
            RX = 2*LITN(I)*DSX(I)*RN -CLGX
            RY = 2*LITN(I)*DSY(I)*RN -CLGY
            RZ = 2*LITN(I)*DSZ(I)*RN -CLGZ
            EYER(I) = EEX0(I)*RX+EEY0(I)*RY+EEZ0(I)*RZ
         ENDIF
   10 CONTINUE
      RETURN
      END

      SUBROUTINE RNORMPOINTS(X,Y,Z,NDX,NDY,NDZ,N1,N2,N3,LITN,EYER,EYEN)
      REAL*4 X(*),Y(*),Z(*),NDX(*),NDY(*),NDZ(*)
      REAL  LITN(3),EYER(3),DSX(3),DSY(3),DSZ(3),EEX0(3),EEY0(3),EEZ0(3)
      REAL  XX(3),YY(3),ZZ(3)
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC

      XX(1) = X(N1)
      XX(2) = X(N2)
      XX(3) = X(N3)
      YY(1) = Y(N1)
      YY(2) = Y(N2)
      YY(3) = Y(N3)
      ZZ(1) = Z(N1)
      ZZ(2) = Z(N2)
      ZZ(3) = Z(N3)

      DSX(1) = NDX(N1)
      DSX(2) = NDX(N2)
      DSX(3) = NDX(N3)
      DSY(1) = NDY(N1)
      DSY(2) = NDY(N2)
      DSY(3) = NDY(N3)
      DSZ(1) = NDZ(N1)
      DSZ(2) = NDZ(N2)
      DSZ(3) = NDZ(N3)

      IF (MDPROJ.NE.0) THEN
         DO 11 I = 1, 3
            EEX0(I) = EEX-XX(I)
            EEY0(I) = EEY-YY(I)
            EEZ0(I) = EEZ-ZZ(I)
            RN  = SQRT(EEX0(I)*EEX0(I)+EEY0(I)*EEY0(I)+EEZ0(I)*EEZ0(I))
            EEX0(I) = EEX0(I)/RN
            EEY0(I) = EEY0(I)/RN
            EEZ0(I) = EEZ0(I)/RN
   11    CONTINUE
         EN1  = (EEX-XX(1))*DSX(1)+(EEY-YY(1))*DSY(1)+(EEZ-ZZ(1))*DSZ(1)
         EN2  = (EEX-XX(2))*DSX(2)+(EEY-YY(2))*DSY(2)+(EEZ-ZZ(2))*DSZ(2)
         EN3  = (EEX-XX(3))*DSX(3)+(EEY-YY(3))*DSY(3)+(EEZ-ZZ(3))*DSZ(3)
       ELSE
         DO 12 I = 1, 3
            EEX0(I) = EEX
            EEY0(I) = EEY
            EEZ0(I) = EEZ
   12    CONTINUE
         EN1  = EEX*DSX(1)+EEY*DSY(1)+EEZ*DSZ(1)
         EN2  = EEX*DSX(2)+EEY*DSY(2)+EEZ*DSZ(2)
         EN3  = EEX*DSX(3)+EEY*DSY(3)+EEZ*DSZ(3)
      ENDIF

      EYEN = EN1+EN2+EN3
      IF (EYEN.LT.0) THEN
         DO 22 I = 1, 3
            DSX(I) = -DSX(I)
            DSY(I) = -DSY(I)
            DSZ(I) = -DSZ(I)
   22    CONTINUE
      ENDIF

      DO 10 I = 1, 3
         RN = DSX(I)*DSX(I)+DSY(I)*DSY(I)+DSZ(I)*DSZ(I)
         IF (RN.EQ.0) THEN
            EYER(I) = 0
            LITN(I) = 0
          ELSE
            RN = 1/SQRT(RN)
            LITN(I) = (CLGX*DSX(I)+CLGY*DSY(I)+CLGZ*DSZ(I))*RN
            RX = 2*LITN(I)*DSX(I)*RN -CLGX
            RY = 2*LITN(I)*DSY(I)*RN -CLGY
            RZ = 2*LITN(I)*DSZ(I)*RN -CLGZ
            EYER(I) = EEX0(I)*RX+EEY0(I)*RY+EEZ0(I)*RZ
         ENDIF
   10 CONTINUE
      RETURN
      END

      SUBROUTINE DNORMTRIANGLE(X,Y,Z,N1,N2,N3,LITN,EYER,EYEN)
      REAL*8 X(*),Y(*),Z(*),DX1,DY1,DZ1,DX2,DY2,DZ2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL LITN
      REAL*8 XX,YY,ZZ

      IF (MDPROJ.NE.0) THEN
         XX = (X(N1)+X(N2)+X(N3))/3
         YY = (Y(N1)+Y(N2)+Y(N3))/3
         ZZ = (Z(N1)+Z(N2)+Z(N3))/3
         EEX0 = EEX-XX
         EEY0 = EEY-YY
         EEZ0 = EEZ-ZZ
         RN  = SQRT(EEX0*EEX0+EEY0*EEY0+EEZ0*EEZ0)
         EEX0 = EEX0/RN
         EEY0 = EEY0/RN
         EEZ0 = EEZ0/RN
       ELSE
         EEX0 = EEX
         EEY0 = EEY
         EEZ0 = EEZ
      ENDIF

      DX1 = X(N2)-X(N1)
      DY1 = Y(N2)-Y(N1)
      DZ1 = Z(N2)-Z(N1)
      DX2 = X(N3)-X(N1)
      DY2 = Y(N3)-Y(N1)
      DZ2 = Z(N3)-Z(N1)
      DSX = DY1*DZ2-DY2*DZ1
      DSY = DZ1*DX2-DZ2*DX1
      DSZ = DX1*DY2-DX2*DY1
      RN  = DSX*DSX+DSY*DSY+DSZ*DSZ
      EYEN = EEX0*DSX+EEY0*DSY+EEZ0*DSZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         IF (EYEN.LT.0) THEN
            DSX  = -DSX
            DSY  = -DSY
            DSZ  = -DSZ
*   DO NOT COMMENT HERE
            EYEN = -EYEN
         ENDIF
         RN = 1/SQRT(RN)
         LITN = (CLGX*DSX+CLGY*DSY+CLGZ*DSZ)*RN
         RX = 2*LITN*DSX*RN -CLGX
         RY = 2*LITN*DSY*RN -CLGY
         RZ = 2*LITN*DSZ*RN -CLGZ
         EYER = EEX0*RX+EEY0*RY+EEZ0*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE RNORMTRIANGLE(X,Y,Z,N1,N2,N3,LITN,EYER,EYEN)
      REAL*4 X(*),Y(*),Z(*),DX1,DY1,DZ1,DX2,DY2,DZ2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL LITN

      IF (MDPROJ.NE.0) THEN
         XX = (X(N1)+X(N2)+X(N3))/3
         YY = (Y(N1)+Y(N2)+Y(N3))/3
         ZZ = (Z(N1)+Z(N2)+Z(N3))/3
         EEX0 = EEX-XX
         EEY0 = EEY-YY
         EEZ0 = EEZ-ZZ
         RN  = SQRT(EEX0*EEX0+EEY0*EEY0+EEZ0*EEZ0)
         EEX0 = EEX0/RN
         EEY0 = EEY0/RN
         EEZ0 = EEZ0/RN
       ELSE
         EEX0 = EEX
         EEY0 = EEY
         EEZ0 = EEZ
      ENDIF

      DX1 = X(N2)-X(N1)
      DY1 = Y(N2)-Y(N1)
      DZ1 = Z(N2)-Z(N1)
      DX2 = X(N3)-X(N1)
      DY2 = Y(N3)-Y(N1)
      DZ2 = Z(N3)-Z(N1)
      DSX = DY1*DZ2-DY2*DZ1
      DSY = DZ1*DX2-DZ2*DX1
      DSZ = DX1*DY2-DX2*DY1
      RN  = DSX*DSX+DSY*DSY+DSZ*DSZ
      EYEN = EEX0*DSX+EEY0*DSY+EEZ0*DSZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         IF (EYEN.LT.0) THEN
            DSX  = -DSX
            DSY  = -DSY
            DSZ  = -DSZ
*            EYEN = -EYEN
         ENDIF
         RN = 1/SQRT(RN)
         LITN = (CLGX*DSX+CLGY*DSY+CLGZ*DSZ)*RN
         RX = 2*LITN*DSX*RN -CLGX
         RY = 2*LITN*DSY*RN -CLGY
         RZ = 2*LITN*DSZ*RN -CLGZ
         EYER = EEX0*RX+EEY0*RY+EEZ0*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE D3NORMTRIANGLE(X,Y,Z,N1,N2,N3,LITN,EYER,EYEN)
      REAL*8 X(*),Y(*),Z(*),DX1,DY1,DZ1,DX2,DY2,DZ2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL LITN

      DX1 = X(N2)-X(N1)
      DY1 = Y(N2)-Y(N1)
      DZ1 = Z(N2)-Z(N1)
      DX2 = X(N3)-X(N1)
      DY2 = Y(N3)-Y(N1)
      DZ2 = Z(N3)-Z(N1)
      DSX = DY1*DZ2-DY2*DZ1
      DSY = DZ1*DX2-DZ2*DX1
      DSZ = DX1*DY2-DX2*DY1
      RN  = DSX*DSX+DSY*DSY+DSZ*DSZ
      IF (RN.EQ.0) THEN
         EYER = 0
         LITN = 0
       ELSE
         EYEN = EEX*DSX+EEY*DSY+EEZ*DSZ
         IF (EYEN.LT.0) THEN
            DSX  = -DSX
            DSY  = -DSY
            DSZ  = -DSZ
*   DO NOT COMMENT HERE
            EYEN = -EYEN
         ENDIF
         RN = SQRT(RN)
         IF (MOD3DIR.EQ.1) THEN
            LITN = DSX/RN
            RX = 2*LITN*LITN-1
            RY = 2*LITN*DSY/RN
            RZ = 2*LITN*DSZ/RN
          ELSE IF (MOD3DIR.EQ.2) THEN
            LITN = DSY/RN
            RX = 2*LITN*DSX/RN
            RY = 2*LITN*LITN-1
            RZ = 2*LITN*DSZ/RN
          ELSE
            LITN = DSZ/RN
            RX = 2*LITN*DSX/RN
            RY = 2*LITN*DSY/RN
            RZ = 2*LITN*LITN-1
         ENDIF
         EYER = EEX*RX+EEY*RY+EEZ*RZ
      ENDIF

      RETURN
      END

      SUBROUTINE D2NORMTRIANGLE(X,Y,Z,N1,N2,N3,LITN,EYER)
      REAL*8 X(*),Y(*),Z(*),DX1,DY1,DZ1,DX2,DY2,DZ2
      COMMON /PERSPECTCOM/ ZPX,ZPY,ZPZ,ZP0,DISTAN,ZSCALE,MDPROJ,MOD3DIR
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL LITN

      DX1 = X(N2)-X(N1)
      DY1 = Y(N2)-Y(N1)
      DZ1 = Z(N2)-Z(N1)
      DX2 = X(N3)-X(N1)
      DY2 = Y(N3)-Y(N1)
      DZ2 = Z(N3)-Z(N1)
      DSX = DY1*DZ2-DY2*DZ1
      DSY = DZ1*DX2-DZ2*DX1
      DSZ = DX1*DY2-DX2*DY1
      EYER = EEX*DSX+EEY*DSY+EEZ*DSZ
      LITN = SQRT(DSX*DSX+DSY*DSY+DSZ*DSZ)
      IF (LITN.EQ.0) THEN
         EYER = 0
         RETURN
      ENDIF
      EYER = EYER/LITN
      IF (MOD3DIR.EQ.1) THEN
         LITN = DSX/LITN
       ELSE IF (MOD3DIR.EQ.2) THEN
         LITN = DSY/LITN
       ELSE
         LITN = DSZ/LITN
      ENDIF

      RETURN
      END

      SUBROUTINE TRZDATASORT(X,Y,Z,TS,ORDER,REGION,NODE,IND)
      PARAMETER (NDIV=16)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      REAL*4  X(*),Y(*),Z(*),TS(*)
      INTEGER ORDER(*),REGION(*),NODE(3,*)
      INTEGER L,R,S,SB0(20),SB1(20)

      IF (IND.GT.0) THEN
         NREG0 = 0
         DO J = 1, NDIV
            DO I = 1, NDIV
               IREGDEX(I,J) = 0
            ENDDO
         ENDDO
      ENDIF

      DO 10 K = 1, NORDER
         N     = ORDER(K)
         N1    = NODE(1,N)
         N2    = NODE(2,N)
         N3    = NODE(3,N)
*         TS(K)  = MIN(Z(N1),Z(N2),Z(N3))
         TS(K)  = Z(N1)+Z(N2)+Z(N3)
   10  CONTINUE

      IF (IND.GE.0) THEN
         DO 20 K = 1, NORDER
            N     = ORDER(K)
            N1    = NODE(1,N)
            N2    = NODE(2,N)
            N3    = NODE(3,N)
            X1    = MIN(X(N1),X(N2),X(N3))
            X2    = MAX(X(N1),X(N2),X(N3))
            Y1    = MIN(Y(N1),Y(N2),Y(N3))
            Y2    = MAX(Y(N1),Y(N2),Y(N3))

            NX1 = (X1 - XXXMIN)/DRX
            NX2 = (X2 - XXXMIN)/DRX
            NY1 = (Y1 - YYYMIN)/DRY
            NY2 = (Y2 - YYYMIN)/DRY

            IF (NX1.GE.NDIV.OR.NX2.LT.0
     +                  .OR.NY1.GE.NDIV.OR.NY2.LT.0) THEN
               REGION(K) = 0
               IF (IND.NE.0) NREG0 = NREG0 + 1
             ELSE
               IF (NX1.LT.0)    NX1 = 0
               IF (NX2.GE.NDIV) NX2 = NDIV - 1
               IF (NY1.LT.0)    NY1 = 0
               IF (NY2.GE.NDIV) NY2 = NDIV - 1
               IRX       = ISHFT(1,NX2-NX1+1) - 1
               IRY       = ISHFT(1,NY2-NY1+1) - 1
               REGION(K) = IOR(ISHFT(IRX,NX1+16),ISHFT(IRY,NY1))
               IF (IND.NE.0) THEN
                  IF (IRX.EQ.1.AND.IRY.EQ.1) THEN
                     IREGDEX(NX1+1,NY1+1) = IREGDEX(NX1+1,NY1+1)+1
                   ELSE 
                     NREG0 = NREG0 + 1
                  ENDIF
               ENDIF
            ENDIF
   20      CONTINUE
   
         IF (IND.GT.0) THEN
            IND  = NREG0
            NSUM = NREG0 + 1
            DO J = 1, NDIV
               DO I = 1, NDIV
                  NSUM1 = NSUM + IREGDEX(I,J)
                  IREGDEX(I,J) = NSUM
                  NSUM = NSUM1
               ENDDO
            ENDDO
         ENDIF
      ENDIF

      K      = 1
      SB0(1) = 1
      SB1(1) = NORDER

  100 IF (K.GT.0) THEN
         L = SB0(K)
         R = SB1(K)
         K = K - 1
  200    IF (L.LT.R) THEN
            I = L
            J = R
            W = TS((L+R)/2)
  300       IF (I.LE.J) THEN
** LEFT HANDED SYSTEM **
  400          IF (TS(I).LT.W) THEN
                  I = I + 1
                  GO TO 400
               ENDIF
  500          IF (TS(J).GT.W) THEN
                  J = J - 1
                  GO TO 500
               ENDIF
               IF (I.LE.J) THEN
                  D         = TS(I)
                  TS(I)     = TS(J)
                  TS(J)     = D
                  S         = ORDER(I)
                  ORDER(I)  = ORDER(J)
                  ORDER(J)  = S
                  IF (IND.GE.0) THEN
                     S         = REGION(I)
                     REGION(I) = REGION(J)
                     REGION(J) = S
                  ENDIF
                  I = I + 1
                  J = J - 1
               ENDIF
               GO TO 300
            ENDIF
            IF (J-L.LT.R-I) THEN
               IF (I.LT.R) THEN
                  K      = K + 1
                  SB0(K) = I
                  SB1(K) = R
                  R      = J
                ELSE
                  R = J
               ENDIF
             ELSE IF (L.LT.J) THEN
               K      = K + 1
               SB0(K) = L
               SB1(K) = J
               L      = I
             ELSE
               L = I
           ENDIF
           GO TO 200
        ENDIF
        GO TO 100
      ENDIF

      RETURN
      END

      SUBROUTINE TRREGIONORDER(REGION,IS,REGDER)
      PARAMETER (NDIV=16,MASK=2**NDIV-1)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      INTEGER REGION(*),IS(NDIV,NDIV),REGDER(*)
      
      DO J = 1, NDIV
         DO I = 1, NDIV
            IS(I,J) = IREGDEX(I,J)
         ENDDO
      ENDDO

      IS0   = 1
      DO N = 1, NORDER
         IRX = ISHFT(REGION(N),-16)
         IRY = IAND(REGION(N),MASK)
         NX1 = 1
         NY1 = 1
         DO J = 1, NDIV
            IF (IAND(IRX,1).NE.0) GO TO 10
            NX1 = NX1 + 1
            IRX = ISHFT(IRX,-1)
         ENDDO
   10    DO J = 1, NDIV
            IF (IAND(IRY,1).NE.0) GO TO 20
            NY1 = NY1 + 1
            IRY = ISHFT(IRY,-1)
         ENDDO
   20    IF (IRX.EQ.1.AND.IRY.EQ.1) THEN
            REGDER(IS(NX1,NY1)) = N
            IS(NX1,NY1) = IS(NX1,NY1) + 1
          ELSE
            REGDER(IS0) = N
            IS0 = IS0 + 1
         ENDIF
      ENDDO
      
      RETURN
      END

      SUBROUTINE TRREMOVEHIDDEN(TS,ORDER,REGION,VPOS,NODE)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL*4    TS(*)
      INTEGER   ORDER(*),REGION(*),NODE(3,*)
      BYTE      VPOS(*)

      K1 = 0
      DO 10 N = 1, NORDER
         K  = ORDER(N)
         IF (VPOS(NODE(1,K)).NE.0.OR.VPOS(NODE(2,K)).NE.0.OR.
     +                          VPOS(NODE(3,K)).NE.0) THEN
            K1         = K1 + 1
            TS(K1)     = TS(N)
            ORDER(K1)  = ORDER(N)
            REGION(K1) = REGION(N)
         ENDIF
   10  CONTINUE

      NORDER = K1

      RETURN
      END

      SUBROUTINE TRHIDBRANCH(WS,HS,BS,NP,NS,NODE,N1,N2)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      INTEGER   V1,V2
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,3),NODE(3,*)
      BYTE      BS(NP,3)

      XX1  = WS(N1,1)
      XX2  = WS(N2,1)
      YY1  = WS(N1,2)
      YY2  = WS(N2,2)
      ZZ1  = WS(N1,3)
      ZZ2  = WS(N2,3)
      V1   = BS(N1,3)
      V2   = BS(N2,3)
      NNN1 = N1
      NNN2 = N2

      IF (V1.NE.0) THEN
         IF (V2.NE.0) THEN
           XXX = (XX1 + XX2)/2
           YYY = (YY1 + YY2)/2
           ZZZ = (ZZ1 + ZZ2)/2
           CALL TRSEARCHIMAX(HS,HS(1,3),BS)
           IF (IV.NE.0) THEN
              CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
           ENDIF
            if (IV.NE.0) CALL GWIOLINE(XX1,YY1,XX2,YY2,0)
          ELSE
            CALL TRHIDBRANCH1(XX1,YY1,ZZ1,XX2,YY2,ZZ2
     ,                                      ,WS,HS,BS,NP,NS,NODE)
         ENDIF
       ELSE IF (V2.NE.0) THEN
         CALL TRHIDBRANCH1(XX2,YY2,ZZ2,XX1,YY1,ZZ1,WS,HS,BS,NP,NS,NODE)
      ENDIF

      RETURN
      END

      SUBROUTINE TRHIDBRANCH1(XX0,YY0,ZZ0,XX3,YY3,ZZ3
     ,                                   ,WS,HS,BS,NP,NS,NODE)
      PARAMETER (DMIN=0.2)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL*4    WS(NP,3)
      INTEGER   HS(NS,3),NODE(3,*)
      BYTE      BS(NP,4)

      XX1 = XX0
      YY1 = YY0
      ZZ1 = ZZ0
      XX2 = XX3
      YY2 = YY3
      ZZ2 = ZZ3
  100    CONTINUE
        XXX = (XX1 + XX2)/2
        YYY = (YY1 + YY2)/2
        ZZZ = (ZZ1 + ZZ2)/2
        CALL TRSEARCHIMAX(HS,HS(1,3),BS)
        IF (IV.NE.0) THEN
           CALL TRVISIBLELINE(WS,HS(1,2),BS,HS(1,3),NODE)
        ENDIF
        IF (IV.EQ.0) THEN
           XX2 = XXX
           YY2 = YYY
           ZZ2 = ZZZ
         ELSE
           XX1 = XXX
           YY1 = YYY
           ZZ1 = ZZZ
        ENDIF
        IF (ABS(XX1-XX2)+ABS(YY1-YY2).GE.DMIN) GO TO 100

      IF (XX0.NE.XX1.OR.YY0.NE.YY1) THEN
         CALL GWIOLINE(XX0,YY0,XX1,YY1,0)
      ENDIF

      RETURN
      END

      SUBROUTINE TRSEARCHIMAX(TS,REGION,REGSEL)
      PARAMETER (NDIV=16,MASK=2**16-1)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      REAL*4  TS(*)
      INTEGER REGION(*),REGSEL(*)

      IV = 1
      IF (XXX.LT.XXXMIN.OR.YYY.LT.YYYMIN) GO TO 999

      NX   = (XXX - XXXMIN)/DRX
      IF (NX.GE.NDIV) GO TO 999
      NY   = (YYY - YYYMIN)/DRY
      IF (NY.GE.NDIV) GO TO 999
      NR1  = ISHFT(1,NX+16)
      NR1  = IOR(NR1,ISHFT(1,NY))

      IF (NR.NE.NR1.OR.K0MAX0.EQ.0) THEN
          NR    = NR1
          I0    = 0
          K     = 0
          DO 10 I = 1, NORDER
** LEFT HANDED SYSTEM **
              IF (ZZZ.LT.TS(I)) GO TO 11
              IF (I0.EQ.0.AND.IAND(NR,REGION(I)).EQ.NR) THEN
                  K = K + 1
                  REGSEL(K) = I
                  IF (K.GE.NU2) I0 = I + 1
                ENDIF
   10       CONTINUE
   11     K0MAX  = K
          K0MAX0 = K
          I0MAX  = I - 1
        ELSE
** LEFT HANDED SYSTEM **
          IF (ZZZ.LT.TS(I0MAX)) THEN
              DO 20 K0 = K0MAX0-1, 1, -1
** LEFT HANDED SYSTEM **
                  IF (ZZZ.GE.TS(REGSEL(K0))) GO TO 21
   20           CONTINUE
   21         K0MAX = K0
            ELSE IF (K0MAX0.LT.NU2) THEN
              K = K0MAX0
              DO 30 I = I0MAX + 1, NORDER
** LEFT HANDED SYSTEM **
                  IF (ZZZ.LT.TS(I)) GO TO 31
                  IF (I0.EQ.0.AND.IAND(NR,REGION(I)).EQ.NR) THEN
                      K = K + 1
                      REGSEL(K) = I
                      IF (K.GE.NU2) I0 = I + 1
                    ENDIF
   30          CONTINUE
   31         K0MAX  = K
              K0MAX0 = K
              I0MAX  = I - 1
           ENDIF
        ENDIF

      RETURN

      ENTRY TRSEARCHIMAX2(TS)

      IV = 1
      IF (XXX.LT.XXXMIN.OR.YYY.LT.YYYMIN) GO TO 999
      NX   = (XXX - XXXMIN)/DRX
      IF (NX.GE.NDIV) GO TO 999
      NY   = (YYY - YYYMIN)/DRY
      IF (NY.GE.NDIV) GO TO 999
      NR   = ISHFT(1,NX+16)
      NR   = IOR(NR,ISHFT(1,NY))
      NX0  = NX + 1
      NY0  = NY + 1

      I1 = 1
      I2 = NORDER + 1
  100   CONTINUE
          I = (I2 + I1)/2
          IF (I.EQ.I1) GO TO 110
** LEFT HANDED SYSTEM **
          IF (TS(I).LT.ZZZ) THEN
              I1 = I
            ELSE
              I2 = I
           ENDIF
          GO TO 100
110   I0    = 1
      I0MAX = I
      K0MAX = 0

      RETURN

  999 IV = 0
      RETURN
      END

      SUBROUTINE TRVISIBLEDOT(WS,ORDER,REGSEL,REGION,REGDER,NODE,IND)
      PARAMETER (NDIV=16,MASK=2**16-1)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      COMMON /PROFTRNIK/ NX0,NY0,I0MAX,I0,K0MAX,K0MAX0
      COMMON /PROF3DREG/ IREGDEX(NDIV,NDIV)
      REAL*4    WS(*)
      INTEGER   ORDER(*),REGION(*),REGSEL(*),REGDER(*)
      INTEGER   NODE(3,*)

      ID  = IND
      KN  = 0
      GO TO 1

      ENTRY TRVISIBLELINE(WS,ORDER,REGSEL,REGION,NODE)

      ID = 0
    1    CONTINUE

      DO 10 K0 = 1, K0MAX
          I   = REGSEL(K0)
          K   = ORDER(I)
          IF (K.NE.KN) THEN
             CALL TRTRIVISIBLE(WS,NU,NODE,K)
             IF (IV.EQ.0) GO TO 100
          ENDIF
   10   CONTINUE

      IF (ID.EQ.0) THEN
         IF (I0.NE.0) THEN
            DO I = I0, I0MAX
              IF (IAND(NR,REGION(I)).EQ.NR) THEN
                 K   = ORDER(I)
                 IF (K.NE.KN) THEN
                    CALL TRTRIVISIBLE(WS,NU,NODE,K)
*                    WRITE(*,*) I,K,IV
                    IF (IV.EQ.0) GO TO 100
                 ENDIF
              ENDIF
            ENDDO
         ENDIF
         
       ELSE        
         IK1 = IREGDEX(NX0,NY0)
         IF (NX0.LT.NDIV) THEN
            IK2 = IREGDEX(NX0+1,NY0) - 1
          ELSE
            IK2 = IREGDEX(1,NY0+1) - 1
         ENDIF
         
         DO IP = IK1, IK2
            I = REGDER(IP)
            IF (I.GT.I0MAX) GO TO 101
            K   = ORDER(I)
            IF (K.NE.KN) THEN
               CALL TRTRIVISIBLE(WS,NU,NODE,K)
               IF (IV.EQ.0) GO TO 100
            ENDIF
         ENDDO
  101    DO IP = 1, IREGDEX(1,1)-1
            I = REGDER(IP)
            IF (I.GT.I0MAX) GO TO 100
            IF (IAND(NR,REGION(I)).EQ.NR) THEN
               K   = ORDER(I)
               IF (K.NE.KN) THEN
                  CALL TRTRIVISIBLE(WS,NU,NODE,K)
                  IF (IV.EQ.0) GO TO 100
               ENDIF
            ENDIF
         ENDDO
      ENDIF

  100 RETURN
      END

      SUBROUTINE TRTRIVISIBLE(WS,NP,NODE,K)
      COMMON /PROFTRCOM/ XXXMIN,YYYMIN,DRX,DRY,XXX,YYY,ZZZ,EEX,EEY,EEZ
     +        ,CLGX,CLGY,CLGZ,NU,NT,NU2,NORDER,NR,IV
     +        ,NNN1,NNN2,KN,NSMODE,NBCOL,ISVEC
      REAL*4   WS(NP,3)
      INTEGER NODE(3,*)

      N1 = NODE(1,K)
      N2 = NODE(2,K)
      N3 = NODE(3,K)
      IV = 1

      IF (NNN1.EQ.N1.OR.NNN1.EQ.N2.OR.NNN1.EQ.N3) THEN
         IF (NNN2.EQ.N1.OR.NNN2.EQ.N2.OR.NNN2.EQ.N3) RETURN
      ENDIF
      X1 = WS(N1,1)
      X2 = WS(N2,1)
      X3 = WS(N3,1)
      IF (XXX.GT.X1.AND.XXX.GT.X2.AND.XXX.GT.X3) RETURN
      IF (XXX.LT.X1.AND.XXX.LT.X2.AND.XXX.LT.X3) RETURN

      Y1 = WS(N1,2)
      Y2 = WS(N2,2)
      Y3 = WS(N3,2)
      IF (YYY.GT.Y1.AND.YYY.GT.Y2.AND.YYY.GT.Y3) RETURN
      IF (YYY.LT.Y1.AND.YYY.LT.Y2.AND.YYY.LT.Y3) RETURN

      Z1 = WS(N1,3)
      Z2 = WS(N2,3)
      Z3 = WS(N3,3)
** LEFT HANDED SYSTEM **
      IF (ZZZ.LT.Z1.AND.ZZZ.LT.Z2.AND.ZZZ.LT.Z3) RETURN


      DX1 = X1 - XXX
      DY1 = Y1 - YYY
      DZ1 = Z1 - ZZZ
      DX2 = X2 - XXX
      DY2 = Y2 - YYY
      DZ2 = Z2 - ZZZ
      DX3 = X3 - XXX
      DY3 = Y3 - YYY
      DZ3 = Z3 - ZZZ

      D1 = DX2*DY3 - DX3*DY2
      D2 = DX3*DY1 - DX1*DY3
      IF (D1.GT.0) THEN
         IF (D2.GT.0) THEN
            D3 = DX1*DY2 - DX2*DY1
            IF (D3.GT.0) THEN
               D = DZ1*D1 + DZ2*D2 + DZ3*D3
** LEFT HANDED SYSTEM **
               IF (D.LT.0) THEN
                  IV = 0
                  RETURN
               ENDIF
            ENDIF
         ENDIF
       ELSE IF (D1.LT.0) THEN
         IF (D2.LT.0) THEN
            D3 = DX1*DY2 - DX2*DY1
            IF (D3.LT.0) THEN
               D = DZ1*D1 + DZ2*D2 + DZ3*D3
** LEFT HANDED SYSTEM **
               IF (D.GT.0) THEN
                  IV = 0
                  RETURN
               ENDIF
            ENDIF
         ENDIF
      ENDIF

      RETURN
      END
