!******************************************
!          f  r  a  m  e  s  V.7          *
!     Tests of 3D Graphic Subroutines     *
!         Programmed by T. Taguchi        *
!******************************************
program frames_3dtest
   implicit none

   call fr_ginit
!      call fr_gwsize(580,450,0,0)
!      call fr_gfilegif('gtest3d',0,0)
   call fr_gfile('gtest3d',0)

   call lorentz(30.0,40.0,0,0)
     call next
   call lorentz(0.0,40.0,1,0)
     call next
   call lorentz(90.0,40.0,1,0)
     call next
   call spline3d
     call next
   call wave3d(-30.0,60.0,0)
     call next
   call wave3d(-30.0,120.0,1)
     call next
   call wave3d2(50.0,-150.0,0)
     call next
   call field
     call next
   call cylind
     call next
   call torus1
     call next
   call catast
     call next
   call torus2
     call next
   call catast2
     call next
   call tcont3d
     call next
   call tcont3d2
     call next
   call tcont3d3
     call next
   call tcontvol
     call next
   call tcontvol2
     call next
   call surface2
     call next
3   call sphere
     call next
   call sphere2
     call next
5   call spiral(40.0,-70.0)
     call next
   call tcubes(60)

 999  call fr_gend

end program frames_3dtest

subroutine next
   call fr_gpause
   call fr_gclear
end subroutine next

!**********************************************
!    Lorentz Attracter  by  3D  Graphics      *
!**********************************************
module param
   real sig,r,b
end module param

subroutine lorentz(th,ph,id,ind)
   use param
   implicit none
   integer, parameter :: nmax=5000
   real  th,ph,xs(0:nmax),ys(0:nmax),zs(0:nmax)
   real  f(3),xmin,xmax,ymin,ymax,zmin,zmax,t,dt
   integer cc(0:nmax),i,id,ind

   xmin = -20.0
   xmax = 20.0
   ymin = -20.0
   ymax = 20.0
   zmin = 0.0
   zmax = 40.0

   dt  = 0.01
   sig = 10.0
   r   = 28.0
   b   = 8.0/3.0

   t     = 0.0
   xs(0) = 0.1
   ys(0) = 0.1
   zs(0) = 0.1
   cc(0) = 1

   f(1)  = xs(0)
   f(2)  = ys(0)
   f(3)  = zs(0)

   do i = 1, nmax
      call rkh4(3,t,dt,f)
      xs(i) = f(1)
      ys(i) = f(2)
      zs(i) = f(3)
   enddo

   if (id == 0) then
!      call fr_project(5.0,21)
      call fr_margin3d(10,20,10,80)
      call fr_angle3d(th,ph)
      call fr_aspect3d(1.0,1.0,1.0,1)
      call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
    else
      call fr_rotate(th,ph,3)
   endif

   call fr_xyzname('xxx','yyy','zzz')
   if (ind == 1) then
      call fr_setcircle(12.0)
      do i = 0, nmax
         cc(i) = mod(i,7)+1
      enddo
!      call fr_setstep(2)
      call fr_graph3d(xs,ys,zs,nmax+1,cc,-13)
    else
      call fr_graph3d(xs,ys,zs,nmax+1,2,1)
   endif
   call arrow3d(0.0,0.0,0.0,4,0)

end subroutine lorentz

subroutine equat(x,f,df)
   use param
   implicit none
   real  x,f(*),df(*)
   df(1) = sig*(f(2) - f(1))
   df(2) = (r - f(3))*f(1) - f(2)
   df(3) = f(1)*f(2) - b*f(3)
end subroutine equat

subroutine arrow3d(x,y,z,ic,mode)
   implicit none
   real  xx(7),yy(7),zz(7)
   real  x,y,z
   integer i,ic,mode

   do i = 1, 7
      yy(i) = 0.0
   enddo
   xx(1) = 0.0
   zz(1) = 0.0
   xx(2) = 0.1
   zz(2) = 0.1
   xx(3) = xx(2)
   zz(3) = 0.05
   xx(4) = 0.2
   zz(4) = zz(3)
   xx(5) = xx(4)
   zz(5) = -zz(4)
   xx(6) = xx(3)
   zz(6) = -zz(3)
   xx(7) = xx(6)
   zz(7) = -zz(2)
   call fr_3dmove(x,y,z,mode)
   call fr_3dpolygon(xx,yy,zz,7,ic,72)

end subroutine arrow3d

subroutine rkh4(n,x,h,y)
   implicit none
   real, parameter :: c16=1.0/6.0
   real  x,h,y(n),z(n),k1(n),k2(n),k3(n),k4(n)
   integer n,i
   call equat(x,y,k1)
   do i = 1, n
      z(i) = y(i) + 0.5*h*k1(i)
   enddo
   call equat(x+0.5*h,z,k2)    
   do i = 1, n
      z(i) = y(i) + 0.5*h*k2(i)
   enddo
   call equat(x+0.5*h,z,k3)    
   do i = 1, n
      z(i) = y(i) + h*k3(i)
   enddo
   x = x + h
   call equat(x,z,k4)
   do i = 1, n
      y(i) = y(i) + c16*h*(k1(i) + 2.0*(k2(i) + k3(i)) + k4(i))
   enddo
end subroutine rkh4

!************************
!     3D Spline Test    *
!************************
subroutine spline3d
   implicit none
   real, parameter :: pi=3.141592653589793, pi2=pi*2
   integer, parameter :: nw=20, nmax=4*nw
   real  x(0:nmax*10),y(0:nmax*10),z(0:nmax*10)
   real  xs(2,0:nmax),ys(2,0:nmax),zs(2,0:nmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,th,ph,dth,dph,rl,rs,r
   integer i,n20

   xmin = -1.0
   xmax =  1.0
   ymin = -1.0
   ymax =  1.0
   zmin = -1.0
   zmax =  1.0
   th   = 50.0
   ph   = 30.0
   rl   = 1

   call fr_project(5.0,1)
   call fr_angle3d(th,ph)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('xxx','yyy','zzz')
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)

   rs   = 0.0
   n20   = nmax*10
   dph   = nw*pi2/(n20)
   dth   = pi2/(n20)
   do i = 0, n20
      x(i) = (rl+rs*cos(dph*i))*cos(dth*i)
      y(i) = (rl+rs*cos(dph*i))*sin(dth*i)
      z(i) = rs*sin(dph*i)
   enddo

   call fr_graph3d(x,y,z,n20+1,1,1)

   rs   = 0.25

   n20   = nmax
   dph   = nw*pi2/(n20)
   dth   = pi2/(n20)
   do i = 0, n20
      x(i) = (rl+rs*cos(dph*i))*cos(dth*i)
      y(i) = (rl+rs*cos(dph*i))*sin(dth*i)
      z(i) = rs*sin(dph*i)
   enddo
   call fr_graph3d(x,y,z,n20+1,2,1)

   r = 1.06

   n20   = nmax
   dph   = nw*pi2/(n20)
   dth   = pi2/(n20)
   do i = 0, n20
      xs(1,i) = (rl+rs*cos(dph*i))*cos(dth*i)
      ys(1,i) = (rl+rs*cos(dph*i))*sin(dth*i)
      zs(1,i) = rs*sin(dph*i)
      xs(2,i) = -rs*sin(dph*i)*dph*cos(dth*i)*r &
                -(rl+rs*cos(dph*i))*sin(dth*i)*dth
      ys(2,i) = -rs*sin(dph*i)*dph*sin(dth*i)*r &
                +(rl+rs*cos(dph*i))*cos(dth*i)*dth
      zs(2,i) = rs*cos(dph*i)*dph*r
   enddo
   call fr_graph3d(xs,ys,zs,2*(n20+1),4,6)

   n20   = nmax*10
   dph   = nw*pi2/(n20)
   dth   = pi2/(n20)
   do i = 0, n20
      x(i) = (rl+rs*cos(dph*i))*cos(dth*i)
      y(i) = (rl+rs*cos(dph*i))*sin(dth*i)
      z(i) = rs*sin(dph*i)
   enddo
   call fr_graph3d(x,y,z,n20+1,6,1)
end subroutine spline3d

!*****************************************
!    Test  Program  of  3D  Profile      *
!*****************************************
subroutine wave3d(th,ph,id)
   implicit none
   integer, parameter :: imax=20, jmax=50
   real  func,t2(0:imax,0:jmax),th,ph
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,y,dx,dy
   integer i,j,id

   xmin = -15.0
   xmax =  15.0
   ymin = -10.0
   ymax =  10.0
   zmin = -15.0
   zmax =  15.0

   dx = (xmax-xmin)/imax
   dy = (ymax-ymin)/jmax

   if (id == 0) then
      call fr_margin3d(10,30,10,80)
      call fr_project(5.0,0)
      call fr_angle3d(th,ph)
      call fr_aspect3d(1.0,1.0,1.0,0)
      call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
    else
      call fr_rotate(th,ph,3)
   endif

   call fr_xyzname('x-axis','y-axis','z-axis')

   do j = 0, jmax
      y = dy*j + ymin
      do i = 0, imax
         x = dx*i + xmin
         t2(i,j) = func(x,y)
      enddo
   enddo

   call fr_set2drgn(1,11,0,25)
   call fr_profile(t2,imax+1,jmax+1,4,1)

end subroutine wave3d

function func(x,y)
   implicit none
   real func,x,y,xx
   xx = x*x + 3*y*y
   func = 15.0*cos(sqrt(xx))*exp(-0.01*xx)
end function func

subroutine wave3d2(th,ph,id)
   implicit none
   integer, parameter :: imax=50, jmax=50
   real  func,x(3),y(3),t2(0:imax,0:jmax),th,ph
   real  xmin,xmax,ymin,ymax,zmin,zmax,xx,yy,dx,dy
   integer i,j,id

   xmin = -15.0
   xmax =  15.0
   ymin = -15.0
   ymax =  15.0
   zmin = -15.0
   zmax =  15.0

   dx = (xmax-xmin)/imax
   dy = (ymax-ymin)/jmax

   if (id == 0) then
      call fr_project(5.0,1)
      call fr_angle3d(th,ph)
      call fr_aspect3d(1.0,1.0,1.0,0)
      call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
    else
      call fr_rotate(th,ph,3)
   endif

   call fr_xyzname('x-axis','y-axis','z-axis')

   do j = 0, jmax
      yy = dy*j + ymin
      do i = 0, imax
         xx = dx*i + xmin
         t2(i,j) = func(xx,0.5*yy)
      enddo
   enddo

   x(1) = xmin
   x(2) = xmax
   x(3) = xmin
   y(1) = ymin
   y(2) = ymin
   y(3) = ymax
   call fr_surface(x,y,t2,imax+1,jmax+1,6,304)

end subroutine wave3d2

!*******************************
!        3D Dipole Field       *
!*******************************
subroutine field
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: ifmax=31, itmax=40, imax=30, jmax=40
   real  xx(500),yy(500),zz(500)
   real  bx(-imax:imax,0:jmax),by(-imax:imax,0:jmax),bz(-imax:imax,0:jmax)
   real  f(ifmax),th(itmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,area,x,y,r,th1
   integer i,j,nmax,i0

   xmin = -0.25*imax
   xmax = 0.25*imax
   ymin = 0.0
   ymax = 0.25*jmax
   zmin = 0.0
   zmax = 5.0
   call fr_project(5.0,1)
   call fr_angle3d(30.0,-60.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   do j = 0, jmax
      do i = -imax, imax
         x  = 0.25*i
         y  = 0.25*j
         call dipole(x,y,bx(i,j),by(i,j))
         bz(i,j) = 1.e-3*(sin(pi*2*y/ymax)+1)
      enddo
   enddo

   r = 1.0
   do i = 1, ifmax
      th1 = pi*(i-1)/real(ifmax-1)
      call dipole(r*cos(th1),r*sin(th1),x,y)
      f(i) = x*cos(th1)+y*sin(th1)
   enddo
   
   th(1)     = 0.0
   th(itmax) = pi
   call fr_flowspace(f,ifmax,th,itmax,area,i0)

   call fr_flow3drgn(0.0,xmax,0.0,ymax,zmin,zmax)
   do i = 1, itmax/2
      xx(1) = r*cos(th(i))
      yy(1) = r*sin(th(i))
      zz(1) = zmin
      nmax  = 500
      call fr_flow3dline(xx,yy,zz,nmax,bx,by,bz,2*imax+1,jmax+1,1,4,1.d-7,5)
   enddo
   call fr_flow3drgn(xmin,0.0,0.0,ymax,zmin,zmax)
   do i = itmax/2+1, itmax
      xx(1) = r*cos(th(i))
      yy(1) = r*sin(th(i))
      zz(1) = zmax
      nmax  = 500
     call fr_flow3dline(xx,yy,zz,nmax,bx,by,bz,2*imax+1,jmax+1,1,6,1.d-7,-5)
   enddo

end subroutine field

subroutine dipole(x,y,bx,by)
   implicit none
   real  x,y,r2,r5,bx,by

   r2 = x*x+y*y
   if (r2 == 0) then
      bx = 0.0
      by = 0.0
    else
      r5 = r2**2.5
      bx = (3.0*x*x-r2)/r5
      by = 3.0*x*y/r5
   endif

end subroutine dipole

!**************************
!      Torus Display      *
!**************************
subroutine torus1
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: imax=51, jmax=51
   real  x(imax,jmax),y(imax,jmax),z(imax,jmax)
   real  u,v,du,dv
   integer i,j

   du = 2*pi/(imax-1)
   dv = 2*pi/(jmax-1)

   do j = 1, jmax
      v = dv*j
      do i = 1, imax
         u      = du*(i-1)
         x(i,j) = (1+0.25*cos(v))*cos(u)
         y(i,j) = (1+0.25*cos(v))*sin(u)
         z(i,j) = 0.25*sin(v)
      enddo
   enddo

   call fr_margin3d(50,30,50,80)
   call fr_angle3d(30.0,-60.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
!   call fr_frame3d(-1.3,1.3,0.0,1.3,-0.5,0.5,3)

   call fr_set2drgn(1,26,0,35)
   call fr_surface(x,y,z,imax,jmax,2,6)

end subroutine torus1

!*********************************
!      Double Torus Display      *
!*********************************
subroutine torus2
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: imax=51, jmax=51
   real  x(imax,jmax),y(imax,jmax),z(imax,jmax)
   real  u,v,du,dv
   integer i,j

   du = 2*pi/(imax-1)
   dv = 2*pi/(jmax-1)

   do j = 1, jmax
      v = dv*j
      do i = 1, imax
         u      = du*(i-1)
         x(i,j) = (1+0.25*cos(v))*cos(u)
         y(i,j) = (1+0.25*cos(v))*sin(u)
         z(i,j) = 0.25*sin(v)
      enddo
   enddo

   call fr_margin3d(50,30,50,80)
   call fr_angle3d(30.0,-60.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
   call fr_frame3d(-1.3,2.3,-1.3,1.3,-0.5,0.5,3)

!   call fr_set2drgn(1,26,0,35)
   call fr_surface(x,y,z,imax,jmax,3,-1)

   do j = 1, jmax
      v = dv*j
      do i = 1, imax
         u      = du*(i-1)
         z(i,j) = (1+0.25*cos(v))*cos(u)
         x(i,j) = 1+(1+0.25*cos(v))*sin(u)
         y(i,j) = 0.25*sin(v)
      enddo
   enddo
   call fr_surface(x,y,z,imax,jmax,4,3)

end subroutine torus2

!*************************************
!       Test of 3D Tringle Mesh      *
!*************************************
subroutine catast
   implicit none
   integer, parameter :: imax=20, jmax=20, npmax=(imax+1)*(jmax+1)
   real  x(npmax),y(npmax),z(npmax)
   integer node(3,npmax*2),i,j,np,ns,np0

   np = 0
   do j = 0, jmax
      do i = 0, imax
         np = np + 1
         x(np) = (i-imax/2)*0.9
         z(np) = (j-jmax/2)*0.47
         y(np) = 0.2*(z(np)**3-1.5*x(np)*z(np))*imax/(4*imax-3*i)
      enddo
   enddo

   ns  = 0
   np0 = 0
   do j = 0, jmax-1
      do i = 0, imax-1
         ns  = ns + 1
         np0 = np0 + 1
         node(1,ns) = np0
         node(2,ns) = np0 + imax + 2
         node(3,ns) = np0 + imax + 1
         ns  = ns + 1
         node(1,ns) = np0
         node(2,ns) = np0 + 1
         node(3,ns) = np0 + imax + 2
      enddo
      np0 = np0 + 1
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,10.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
!   call fr_setcontour(-3.0,3.0,2)
   call fr_trisurface(x,y,z,np,node,ns,1,4)

end subroutine catast

!*************************************
!       Test of 3D Tringle Mesh      *
!*************************************
subroutine catast2
   implicit none
   integer, parameter :: imax=20, jmax=20, npmax=(imax+1)*(jmax+1)
   real  x(npmax),y(npmax),z(npmax)
   integer node(3,npmax*2),i,j,np,ns,np0

   np = 0
   do j = 0, jmax
      do i = 0, imax
         np = np + 1
         x(np) = (i-imax/2)*0.9
         z(np) = (j-jmax/2)*0.47
         y(np) = 0.2*(z(np)**3-1.5*x(np)*z(np))*imax/(4*imax-3*i)
      enddo
   enddo

   ns  = 0
   np0 = 0
   do j = 0, jmax-1
      do i = 0, imax-1
         ns  = ns + 1
         np0 = np0 + 1
         node(1,ns) = np0
         node(2,ns) = np0 + imax + 2
         node(3,ns) = np0 + imax + 1
         ns  = ns + 1
         node(1,ns) = np0
         node(2,ns) = np0 + 1
         node(3,ns) = np0 + imax + 2
      enddo
      np0 = np0 + 1
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,10.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
!   call fr_setcontour(-3.0,3.0,2)
   call fr_trisurface(x,y,z,np,node,ns,-2,4)
   call fr_colorbar(60,220,15,100,1)

end subroutine catast2

!*******************************************************
!       Test of 3D Tringle Mesh with Normal Vector     *
!*******************************************************
subroutine catast3
   implicit none
   integer, parameter :: imax=20, jmax=20, npmax=(imax+1)*(jmax+1)
   real  x(2,npmax),y(2,npmax),z(2,npmax)
   real  dxi,dyi,dzi,dxj,dyj,dzj
   integer node(3,npmax*2),i,j,np,ns,np0

   np = 0
   do j = 0, jmax
      do i = 0, imax
         np = np + 1
         x(1,np) = (i-imax/2)*0.9
         z(1,np) = (j-jmax/2)*0.47
         y(1,np) = 0.2*imax*(z(1,np)**3-1.5*x(1,np)*z(1,np))/(4*imax-3*i)
         dxi = 0.9
         dzi = 0
         dyi = 0.2*imax*((-1.5*dxi*z(1,np))*(4*imax-3*i) &
                +(z(1,np)**3-1.5*x(1,np)*z(1,np))*3)/(4*imax-3*i)**2
         dxj = 0
         dzj = 0.47
         dyj = 0.2*imax*(3*z(1,np)**2*dzj-1.5*x(1,np)*dzj)/(4*imax-3*i)
         x(2,np) = dyi*dzj-dyj*dzi
         y(2,np) = dzi*dxj-dzj*dxi
         z(2,np) = dxi*dyj-dxj*dyi
      enddo
   enddo

   ns  = 0
   np0 = 0
   do j = 0, jmax-1
      do i = 0, imax-1
         ns  = ns + 1
         np0 = np0 + 1
         node(1,ns) = np0
         node(2,ns) = np0 + imax + 1
         node(3,ns) = np0 + imax + 2
         ns  = ns + 1
         node(1,ns) = np0
         node(2,ns) = np0 + 1
         node(3,ns) = np0 + imax + 2
      enddo
      np0 = np0 + 1
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,10.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
!   call fr_setcontour(-3.0,3.0,2)
!   call fr_setlight(50.0,-30.0,0)
!   call fr_setsurface(0.05,0.5,10)
   call fr_trisurface(x,y,z,np*2,node,ns,3,8)

end subroutine catast3

!*********************************
!       Test of 3D Contours      *
!*********************************
subroutine tcont3d
   implicit none
   integer, parameter :: jmax=40, kmax=50
   real  f(0:jmax,0:kmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,y,z,dy,dz
   integer j,k

   xmin = -2.0
   xmax =  2.0
   ymin = -2.0
   ymax =  2.0
   zmin = -2.0
   zmax =  2.0
   dy   = (ymax - ymin)/jmax
   dz   = (zmax - zmin)/kmax
   do k = 0, kmax
      z=dz*k+ymin
      do j = 0, jmax
         y=dy*j+ymin
!         c = dcmplx(dy*j+ymin,dz*k+zmin-0.5)
!         f(i,j) = abs(sin(c))
         f(j,k)=exp(-0.5*((y-1)**2+(z-0.5)**2))+exp(-1.2*((y+1.5)**2+(z+0.5)**2))
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,40.0)
   call fr_aspect3d(1.0,1.0,1.0,1)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
!   call fr_setcontour(0.0,0.05,1)
!   call fr_set3drgn(0,1,20,40,30,50)
   call fr_contour3d(f,1,jmax+1,kmax+1,0.0,20,5,0)

end subroutine tcont3d

!**************************************
!       Test of 3D Fill Contours      *
!**************************************
subroutine tcont3d2
   implicit none
   integer, parameter :: imax=20, kmax=30
   real  f(0:imax,0:kmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,z,dx,dz
   integer i,k

   xmin = -2.0
   xmax =  2.0
   ymin = -2.0
   ymax =  2.0
   zmin = -2.0
   zmax =  2.0
   dx   = (xmax - xmin)/imax
   dz   = (zmax - zmin)/kmax
   do k = 0, kmax
      z=dz*k+zmin
      do i = 0, imax
         x=dx*i+xmin
         f(i,k)=exp(-0.5*((x-1)**2+(z-0.5)**2))+exp(-1.2*((x+1.5)**2+(z+0.5)**2))
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,40.0)
   call fr_aspect3d(1.0,1.0,1.0,1)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
!   call fr_stcontour(0.0,0.05,1)
!   call fr_set3drgn(10,20,0,1,10,20)
   call fr_contour3d(f,imax+1,1,kmax+1,.5,20,-2,0)
   call fr_colorbar(90,230,15,100,1)

end subroutine tcont3d2

!**************************************
!       Test of 3D Fill Contours      *
!**************************************
subroutine tcont3d3
   implicit none
   integer, parameter :: imax=20, jmax=30
   real  f(0:imax,0:jmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,y,dx,dy
   integer i,j

   xmin = -2.0
   xmax =  2.0
   ymin = -2.0
   ymax =  2.0
   zmin = -2.0
   zmax =  2.0
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax
   do j = 0, jmax
      y=dy*j+ymin
      do i = 0, imax
         x=dx*i+xmin
         f(i,j)=exp(-0.5*((x-1)**2+(y-.5)**2))+exp(-1.2*((x+1.5)**2+(y+.5)**2))
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(30.0,40.0)
   call fr_aspect3d(1.0,1.0,1.0,1)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
!   call fr_setcontour(0.0,0.05,1)
!   call fr_set3drgn(10,20,10,20,0,1)
   call fr_contour3d(f,imax+1,jmax+1,1,.5,20,-2,0)
   call fr_colorbar(80,200,15,100,1)

end subroutine tcont3d3

!**************************************
!        Cylindrical Field Lines      *
!**************************************
subroutine cylind
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: ifmax=31, itmax=10, imax=20, jmax=50
   integer, parameter :: nmax0=5000
   real  xx(nmax0),yy(nmax0),zz(nmax0)
   real  br(0:imax,0:jmax),bt(0:imax,0:jmax),bz(0:imax,0:jmax)
   real  f(0:imax,0:jmax)
   real  rmin,rmax,ymin,ymax,zmin,zmax,r,z,dr,dz,om
   integer i,j,nmax

   rmax = 0.25*imax
   rmin = -rmax
   ymax =  rmax
   ymin = -ymax
   zmin = 0.0
   zmax = 10.0
   om   = -5

   call fr_project(5.0,1)
   call fr_angle3d(30.0,-60.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_frame3d(rmin,rmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-ax','y-ax','z-ax')

   dr   = rmax/imax
   dz   = (zmax-zmin)/jmax
   do j = 0, jmax
      z = dz*j+zmin
      do i = 0, imax
         r = dr*i
         f(i,j)  = exp(-0.3*((r-2)**2+(z-zmax/2)**2))
         br(i,j) = 0
         bt(i,j) = r*om*f(i,j)
         bz(i,j) = 1
      enddo
   enddo

   call fr_setgeometry(2)
   dr = rmax/(itmax+1)
   do i = 1, itmax
      r     = dr*i
      xx(1) = r
      yy(1) = 0
      zz(1) = zmin+0.1
      nmax  = nmax0
      call fr_flow3dline(xx,yy,zz,nmax,br,bt,bz,imax+1,1,jmax+1,5,1.e-7,3)
   enddo

   call fr_set3dbox(0.0,rmax,ymin,ymax,zmin,zmax,0)
   call fr_contour3d(f,imax+1,1,jmax+1,0.0,20,-2,0)
   call fr_set3dbox(0.0,-rmax,ymin,ymax,zmin,zmax,0)
   call fr_contour3d(f,imax+1,1,jmax+1,0.0,20,-3,0)

   call fr_clip3d(rmin,rmax,0.0,ymax,zmin,zmax,-2)
   do i = 1, itmax
      r     = dr*i
      xx(1) = r
      yy(1) = 0
      zz(1) = zmin+0.1
      nmax  = nmax0
      call fr_flow3dline(xx,yy,zz,nmax,br,bt,bz,imax+1,1,jmax+1,5,1.e-7,3)
   enddo

end subroutine cylind

!***********************************
!       Test of 3D Fill Slice      *
!***********************************
subroutine tcontvol
   implicit none
   integer, parameter :: imax=20, jmax=15, kmax=10
   real  f(0:imax,0:jmax,0:kmax)
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,y,z,dx,dy,dz
   integer i,j,k

   xmin = -2.0
   xmax =  2.0
   ymin = -2.0
   ymax =  2.0
   zmin = -2.0
   zmax =  2.0
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax
   dz   = (zmax - zmin)/kmax
   do k = 0, kmax
      z = dz*k+zmin
      do j = 0, jmax
         y = dy*j+ymin
         do i = 0, imax
            x = dx*i+xmin
            f(i,j,k)=exp(-0.5*((x-.5)**2+(y-.5)**2+(z-.5)**2)) &
                    +exp(-1.2*((x+1.5)**2+(y+1.5)**2)-0.1*(z+1.5)**2)
         enddo
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(20.0,130.0)
   call fr_aspect3d(1.0,1.0,1.0,1)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
!   call fr_setcontour(0.0,0.05,1)
!   call fr_set3drgn(10,20,5,8,1,5)
   call fr_contour3d(f,imax+1,jmax+1,kmax+1,-.5,20,-2,403)
   call fr_colorbar(110,230,15,100,1)

end subroutine tcontvol

!***********************************
!       Test of 3D Fill Slice      *
!***********************************
subroutine tcontvol2
   implicit none
   integer, parameter :: imax=30, jmax=20, kmax=20
   real  f(0:imax,0:jmax,0:kmax),td(3)
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,y,z,dx,dy,dz
   integer nu(3),i,j,k

   td(1) = 0
   td(2) = 0
   td(3) = -1.8
   nu(1) = 3
   nu(2) = 1
   nu(3) = 2

   xmin = -3.0
   xmax =  3.0
   ymin = -2.0
   ymax =  2.0
   zmin = -2.0
   zmax =  2.0
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax
   dz   = (zmax - zmin)/kmax
   do k = 0, kmax
      z = dz*k+zmin
      do j = 0, jmax
         y = dy*j+ymin
         do i = 0, imax
            x = dx*i+xmin
            f(i,j,k)=exp(-0.5*((x-.5)**2+(y-.5)**2+(z-.5)**2)) &
                    +exp(-1.2*((x+1.5)**2+(y+1.5)**2)-0.1*(z+1.5)**2)
         enddo
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(20.0,70.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
!   call fr_setcontour(0.0,0.05,1)
!   call fr_set3drgn(10,20,5,8,1,5)
!   call fr_set3dbox(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_slices(f,imax+1,jmax+1,kmax+1,td,nu,20,-2,0)
   call fr_colorbar(70,180,15,100,1)

end subroutine tcontvol2

!**************************
!      Isosurface         *
!**************************
subroutine surface2
   implicit none
   real, parameter :: pi2=2*3.141592653589793
   integer, parameter :: imax=10,jmax=10,kmax=50
   real  f(-imax:imax,-jmax:jmax,0:kmax)
   real  r0,f0,rs,rc
   integer i,j,k

   r0 = 5.5
   f0 = 0.75
   do k = 0, kmax
      rc = r0*cos(pi2*k/kmax)
      rs = r0*sin(pi2*k/kmax)
      do j = -jmax, jmax
         do i = -imax, imax
            f(i,j,k) =  exp(-((i-rc)*(i-rc)+(j-rs)*(j-rs))/20.0) &
                       +exp(-((i+rc)*(i+rc)+(j+rs)*(j+rs))/40.0)
         enddo
      enddo
   enddo

   call fr_project(5.0,21)
   call fr_angle3d(30.0,-30.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
   call fr_frame3d(-real(imax),real(imax),-real(jmax),real(jmax),0.0,real(kmax),4)
!   call fr_set3dbox(-3.0,3.0,-3.0,3.0,0.0,10.0,3)
   call fr_isosurface(f,2*imax+1,2*jmax+1,kmax+1,f0,3,6)

end subroutine surface2

!**************************
!      Simple Sphere      *
!**************************
subroutine sphere
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: imax=31, jmax=31
   real  x(imax,jmax),y(imax,jmax),z(imax,jmax)
   real  r,ph,th,dph,dth
   integer i,j

   r   = 1
   dph = 2*pi/(jmax-1)
   dth =   pi/(imax-1)

   do j = 1, jmax
      ph = dph*(j-1)
      do i = 1, imax
         th = dth*(i-1)
         x(i,j) = r*sin(th)*cos(ph)
         y(i,j) = r*sin(th)*sin(ph)
         z(i,j) = r*cos(th)
      enddo
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(50,30,50,80)
   call fr_angle3d(20.0,150.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
   call fr_frame3d(-1.0,1.0,-1.0,1.0,-1.0,1.0,3)
   call fr_surface(x,y,z,imax,jmax,2,6)

end subroutine sphere

!**************************
!      Mapped Sphere      *
!**************************
subroutine sphere2
   implicit none
   real, parameter :: pi=3.141592653589793
   integer, parameter :: imax=31, jmax=31
   real  x(imax,jmax),y(imax,jmax),z(imax,jmax),f(imax,jmax)
   real  r,ph,th,dph,dth
   integer i,j

   r   = 1
   dph = 2*pi/(jmax-1)
   dth =   pi/(imax-1)

   do j = 1, jmax
      ph = dph*(j-1)
      do i = 1, imax
         th = dth*(i-1)
         x(i,j) = r*sin(th)*cos(ph)
         y(i,j) = r*sin(th)*sin(ph)
         z(i,j) = r*cos(th)
         f(i,j) = exp(-4*(th-pi/2)**2-0.8*(ph-pi)**2)
      enddo
   enddo

   call fr_margin3d(50,30,50,80)
   call fr_angle3d(20.0,150.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_xyzname('x-ax','y-ax','z-ax')
   call fr_frame3d(-1.0,1.0,-1.0,1.0,-1.0,1.0,3)
   call fr_mapsurface(x,y,z,f,imax,jmax,-2,1)

end subroutine sphere2

!********************************
!      Colored Mni-Spheres     *
!********************************
subroutine spiral(th,ph)
   implicit none
   real, parameter :: pi=3.141592653589793, pi2=pi*2
   integer, parameter :: nmax=100
   real  th,ph,xs(nmax),ys(nmax),zs(nmax),p,q
   real  xmin,xmax,ymin,ymax,zmin,zmax
   integer cc(nmax),n1,i

   xmin = -20.0
   xmax = 20.0
   ymin = -20.0
   ymax = 20.0
   zmin = 0.0
   zmax = 40.0

   p  = 0.1
   q  = (zmax-zmin)/nmax
   n1 = 76

   do i = 1, n1
      zs(i) = q*i
      xs(i) = 15*cos(pi2*p*zs(i))
      ys(i) = 15*sin(pi2*p*zs(i))
      zs(i) = 1.5*zs(i)
   enddo

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(th,ph)
   call fr_aspect3d(1.0,1.0,1.0,1)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('xxx','yyy','zzz')

   call fr_setcircle(20.0)
   do i = 1, n1
      cc(i) = mod(i,7)+1
   enddo
!   call fr_setstep(2)
   call fr_graph3d(xs,ys,zs,n1,cc,-13)

end subroutine spiral

subroutine tcubes(nn)
   implicit none
   integer, parameter :: imax=4, jmax=4, kmax=4
   real  f(0:imax,0:jmax,0:kmax),fmin,f0(4)
   real  xmin,xmax,ymin,ymax,zmin,zmax,x,y,z,dx,dy,dz
   integer i,j,k,nn,ic(4)

   xmin = -3.0
   xmax =  3.0
   ymin = -3.0
   ymax =  3.0
   zmin = -3.0
   zmax =  3.0
   f0(1) =  0.5
   f0(2) =  5
   f0(3) =  50
   f0(4) =  500
   ic(1) = 202
   ic(2) = 101
   ic(3) = 505
   ic(4) = 404
   dx   = (xmax - xmin)/imax
   dy   = (ymax - ymin)/jmax
   dz   = (zmax - zmin)/kmax
   do k = 0, kmax
      do j = 0, jmax
         do i = 0, imax
            f(i,j,k)=10000
         enddo
      enddo
   enddo

   f(0,0,0) = 1
   f(1,1,1) = 0
   f(2,2,2) = 0
   f(2,2,0) = 10
   f(3,3,3) = 0
   f(2,3,0) = 100
   f(4,4,4) = 100
   f(4,3,1) = 10

   call fr_project(5.0,1)
   call fr_margin3d(10,20,10,80)
   call fr_angle3d(20.0,nn+10.0)
   call fr_aspect3d(1.0,1.0,1.0,0)
   call fr_frame3d(xmin,xmax,ymin,ymax,zmin,zmax,3)
   call fr_xyzname('x-axis','y-axis','z-axis')
   call fr_isosurface(f,imax+1,jmax+1,kmax+1,f0,ic,37)

end subroutine tcubes
