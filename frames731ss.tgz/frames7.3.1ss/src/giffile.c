/*************************************************
 *        GIF Animation file Processor           *
 *          Programmed by T. Taguchi             *
 *               March 16, 2005                  *
 *************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h> 
#include <sys/types.h>
#include <sys/stat.h>

/* 
	This application partially uses GIF encoding routine of GD1.3.
	If you want to modify this program, please read the copyright notice
	of "miGIF Compression."

	If you don't want to use the GD part, comment out the following line.
	Even if you don't use the GD part, you can expand your GIF animation file 
	into separate GIF files or separate GIF animations, but AutoCrop doesn't
	work.
 */
#define GD

/*#define VERBOSE				1 	*/
/*#define DIRECT 					*/
/*#define SPEAK 					*/
#define SIZE				4096
#define MAXCOLORMAPSIZE		256
#define MAXNCHAR			128
#define CM_RED				0
#define CM_GREEN			1
#define CM_BLUE				2
#define COLORMAPBIT			0x80
#define INTERLACEBIT		0x40
#define REAGIONPOS			6L
#define Makeword(a,b)		(((b)<<8)|(a))
#define Putword(w,fp)		{ fputc((w)&0xff,fp);  fputc(((w)>>8)&0xff,fp); }

static int		nread=0,nr=1,ncount=0,nhead,nanim=0,nskip=1,nskipset=0;
static int		transparent=-1,delay=10,count=0,swanime=0,stanime=0,storecount=0;
static int		resize=0, autocrop=0, cropimage=0, croppixel=0, globalct=0;
static int		xmax=0, ymax=0;
static int		gx0,gy0,gwidth,gheight,revbw=0,addimage=0;
static unsigned char	filebuf[SIZE];
static FILE 	*fpg1;
static char		gifname[MAXNCHAR];

void error_end(char *err)
{
	fputs(err,stderr);
	exit(1);
}

get_gifbytes(unsigned char *str,int cmax)
{
	int i;

	if (cmax<0) {
		fseek(fpg1,0L,SEEK_SET);
		nread=0;	nr=1;
		cmax=-cmax;
	}

	for (i=0;i<cmax;i++) {
		if (nr>=nread) {
			nread=fread(filebuf,1,SIZE,fpg1);
			if (nread<=0) error_end("File is incomplete !!!\n");
			nr=0;
		}
		str[i]=filebuf[nr++];
	}			
	return i;
}

void help_menu()
{
	puts("\nUsage :  giffile [options] filename [filename2]");
/*	puts("      :    ( nn:>integer,  xx:>real )");		*/
	puts("      :    ( kk:>integer )");
	puts("   -a(kk)    Make an animation file from No.nn files.");
	puts("   -dkk      Set animation delay time to kk (msec).");
	puts("   -c(kk)    Auto Crop (If add kk, add kk space around the croped window.)");
	puts("   -skk      Make images in kk step");
	puts("   -nkk      Make an single GIF image of No.kk");
	puts("   -gc       Make a local coplormap to a single global colormap.");
	puts("   -rbw      Reverse Black & White.");
	puts("   -add      Add GIF data of filename2 to filename.");
	exit(0);
}

int check_words(char *str1,char *str2,int n)
{
	int i;
	for (i=0;i<n;i++) {
		if (*str1!=*str2) return -1;
	}
	return 0;
}

void write_bytes(unsigned char *str,int n)
{
	int i;
	for (i= 0;i<n;i++) printf("%02x ",str[i]);
	printf("\n");
}

void read_block_data(unsigned char *str,FILE *imout,int com)
{
	int nc;

	if (imout==NULL) {
		if (com==0xfe) {
			nc=get_gifbytes(str,1);
			if (str[0]) {
				nc=get_gifbytes(str,str[0]);
				nc=check_words(str,"*Frames*",8);
				if (nskipset==0) nskip=str[8];
				if (nanim>nskip) nanim=1;
			}
		}
		while (1) {
			nc=get_gifbytes(str,1);
			if (str[0]==0) break;
			nc=get_gifbytes(str,str[0]);
		}
	  }
	  else if (com) {
		while (1) {
			nc=get_gifbytes(str,1);
			printf("Block %d\n",str[0]);
			fwrite(str, 1, 1, imout);
			if (str[0]==0) break;
			nc=get_gifbytes(str,str[0]);
			fwrite(str, 1, nc, imout);
		}
	  }
	  else {
		while (1) {
			nc=get_gifbytes(str,1);
			fwrite(str, 1, 1, imout);
			if (str[0]==0) break;
			nc=get_gifbytes(str,str[0]);
			fwrite(str, 1, nc, imout);
		}
	}

}

void set_buffer(int n, unsigned char *header)
{
	int i;
	static int nc1,nc2;

	if (n==0) nc1=0;
	  else {
		nc2=nr;
		for (i=nc1;i<nc2;i++) header[i-nc1]=filebuf[i];
		nhead=nc2-nc1;
	}
}

write_agif(FILE *imout)
{
	if (imout == NULL) return;
	fputc( 0x21, imout );		fputc( 0xff, imout );		fputc( 0x0b, imout );
	fwrite("NETSCAPE2.0", 1, 11, imout );
	fputc( 0x03, imout );		fputc( 0x01, imout );

	if (count>65535) error_end("GIF repeat times are too large !!!\n");
	fputc( count&0xff, imout );
	fputc( count>>8  , imout );
	fputc( 0x00, imout );

	fputc( 0x21, imout );		fputc( 0xf9, imout );		fputc( 4, imout );
	if (transparent >= 0) fputc( 0x09, imout );
		else 			  fputc( 0x08, imout );

	if (delay>65535) error_end("GIF Delay time is too large !!!\n");
	fputc( delay&0xff, imout );		fputc( delay>>8  , imout );
	if (transparent >= 0) fputc( (unsigned char) transparent, imout );
		else 			  fputc( 0x00, imout);
	fputc( 0x00, imout );
}

#ifdef GD
/*	The following routines are almost copies from GD1.3 except about input method.	 	*/
#define GIFBITS 12
static int Width, Height;
static int curx, cury;
static long CountDown;
static int Pass = 0;
static int Interlace;
static int a_count;

#define gdMaxColors			256
#define MAX_LWZ_BITS		12

#define TRUE				1
#define FALSE				0
#define BitSet(byte, bit)	(((byte) & (bit)) == (bit))

int ZeroDataBlock;
int colorsTotal;
int red[gdMaxColors];
int green[gdMaxColors];
int blue[gdMaxColors]; 
int usecol[gdMaxColors];
unsigned char *pixels=NULL;
static int sx,sy;

static void init_statics(void) {
	/* Some of these are properly initialized later. What I'm doing
		here is making sure code that depends on C's initialization
		of statics doesn't break when the code gets called more
		than once. */
	Width = 0;
	Height = 0;
	curx = 0;
	cury = 0;
	CountDown = 0;
	Pass = 0;
	Interlace = 0;
	a_count = 0;
}

static int colorstobpp(int colors)
{
	int bpp = 0;

	if ( colors <= 2 ) 				bpp = 1;
		else if ( colors <= 4 )		bpp = 2;
		else if ( colors <= 8 )		bpp = 3;
		else if ( colors <= 16 )	bpp = 4;
		else if ( colors <= 32 )	bpp = 5;
		else if ( colors <= 64 )	bpp = 6;
		else if ( colors <= 128 )	bpp = 7;
		else if ( colors <= 256 )	bpp = 8;
	return bpp;
}

/*
 * Bump the 'curx' and 'cury' to point to the next pixel
 */
static void BumpPixel(void)
{
/*
* Bump the current X position
*/
	++curx;

/*
* If we are at the end of a scan line, set curx back to the beginning
* If we are interlaced, bump the cury to the appropriate spot,
* otherwise, just increment it.
*/
	if( curx == Width ) {
		curx = 0;

		if( !Interlace ) ++cury;
		  else {
			switch( Pass ) {
				case 0:
					cury += 8;
					if( cury >= Height ) {
						++Pass;
						cury = 4;
					}
					break;

				case 1:
					cury += 8;
					if( cury >= Height ) {
						++Pass;
						cury = 2;
					}
					break;

				case 2:
					cury += 4;
					if( cury >= Height ) {
						++Pass;
						cury = 1;
					}
					break;

				case 3:
					cury += 2;
					break;
			}
		}
	}
}

/*
 * Return the next pixel from the image
 */
static int GIFNextPixel(void)
{
	int r=0;

	if( CountDown == 0 ) return EOF;

	--CountDown;

	if (!(((cury < 0) || (cury >= sy)) || ((curx < 0) || (curx >= sx)))) r=pixels[cury*sx+curx];

	BumpPixel();

	return r;
}

/*-----------------------------------------------------------------------
 *
 * miGIF Compression - mouse and ivo's GIF-compatible compression
 *
 *          -run length encoding compression routines-
 *
 * Copyright (C) 1998 Hutchison Avenue Software Corporation
 *               http://www.hasc.com
 *               info@hasc.com
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation.  This software is provided "AS IS." The Hutchison Avenue 
 * Software Corporation disclaims all warranties, either express or implied, 
 * including but not limited to implied warranties of merchantability and 
 * fitness for a particular purpose, with respect to this code and accompanying
 * documentation. 
 * 
 * The miGIF compression routines do not, strictly speaking, generate files 
 * conforming to the GIF spec, since the image data is not LZW-compressed 
 * (this is the point: in order to avoid transgression of the Unisys patent 
 * on the LZW algorithm.)  However, miGIF generates data streams that any 
 * reasonably sane LZW decompresser will decompress to what we want.
 *
 * miGIF compression uses run length encoding. It compresses horizontal runs 
 * of pixels of the same color. This type of compression gives good results
 * on images with many runs, for example images with lines, text and solid 
 * shapes on a solid-colored background. It gives little or no compression 
 * on images with few runs, for example digital or scanned photos.
 *
 *                               der Mouse
 *                      mouse@rodents.montreal.qc.ca
 *            7D C8 61 52 5D E7 2D 39  4E F1 31 3E E8 B3 27 4B
 *
 *                             ivo@hasc.com
 *
 * The Graphics Interchange Format(c) is the Copyright property of
 * CompuServe Incorporated.  GIF(sm) is a Service Mark property of
 * CompuServe Incorporated.
 *
 */

static int rl_pixel;
static int rl_basecode;
static int rl_count;
static int rl_table_pixel;
static int rl_table_max;
static int just_cleared;
static int out_bits;
static int out_bits_init;
static int out_count;
static int out_bump;
static int out_bump_init;
static int out_clear;
static int out_clear_init;
static int max_ocodes;
static int code_clear;
static int code_eof;
static unsigned int obuf;
static int obits;
static FILE *ofile;
static unsigned char oblock[256];
static int oblen;

static const char *binformat(unsigned int v, int nbits)
{
	static char bufs[8][64];
	static int bhand = 0;
	unsigned int bit;
	int bno;
	char *bp;

	bhand --;
	if (bhand < 0) bhand = (sizeof(bufs)/sizeof(bufs[0]))-1;
	bp = &bufs[bhand][0];
	for (bno=nbits-1,bit=1U<<bno;bno>=0;bno--,bit>>=1) {
		*bp++ = (v & bit) ? '1' : '0';
		if (((bno&3) == 0) && (bno != 0)) *bp++ = '.';
	}
	*bp = '\0';
	return(&bufs[bhand][0]);
}

static void write_block(void)
{
	int i;

#ifdef VERBOSE
	if (VERBOSE) {
		printf("write_block %d:",oblen);
		for (i=0;i<oblen;i++) printf(" %02x",oblock[i]);
		printf("\n");
	}
#endif
	fputc(oblen,ofile);
	fwrite(&oblock[0],1,oblen,ofile);
	oblen = 0;
}

static void block_out(unsigned char c)
{
#ifdef VERBOSE
	if (VERBOSE) printf("block_out %s\n",binformat(c,8));
#endif
	oblock[oblen++] = c;
	if (oblen >= 255) write_block();
}

static void block_flush(void)
{
#ifdef VERBOSE
	if (VERBOSE) printf("block_flush\n");
#endif
	if (oblen > 0) write_block();
}

static void output(int val)
{
#ifdef VERBOSE
	if (VERBOSE) printf("output %s [%s %d %d]\n",binformat(val,out_bits),binformat(obuf,obits),obits,out_bits);
#endif
	obuf |= val << obits;
	obits += out_bits;
	while (obits >= 8) {
		block_out(obuf&0xff);
		obuf >>= 8;
		obits -= 8;
	}
#ifdef VERBOSE
	if (VERBOSE) printf("output leaving [%s %d]\n",binformat(obuf,obits),obits);
#endif
}

static void output_flush(void)
{
#ifdef VERBOSE
	if (VERBOSE) printf("output_flush\n");
#endif
	if (obits > 0) block_out(obuf);
	block_flush();
}

static void did_clear(void)
{
#ifdef VERBOSE
	if (VERBOSE) printf("did_clear\n");
#endif
	out_bits = out_bits_init;
	out_bump = out_bump_init;
	out_clear = out_clear_init;
	out_count = 0;
	rl_table_max = 0;
	just_cleared = 1;
}

static void output_plain(int c)
{
#ifdef VERBOSE
	if (VERBOSE) printf("output_plain %s\n",binformat(c,out_bits));
#endif
	just_cleared = 0;
	output(c);
	out_count ++;
	if (out_count >= out_bump) {
		out_bits ++;
		out_bump += 1 << (out_bits - 1);
	}
	if (out_count >= out_clear) {
		output(code_clear);
		did_clear();
	}
}

static unsigned int isqrt(unsigned int x)
{
	unsigned int r;
	unsigned int v;

	if (x < 2) return(x);
	for (v=x,r=1;v;v>>=2,r<<=1) ;
	while (1) {
		v = ((x / r) + r) / 2;
		if ((v == r) || (v == r+1)) return(r);
		r = v;
	}
}

static unsigned int compute_triangle_count(unsigned int count, unsigned int nrepcodes)
{
	unsigned int perrep;
	unsigned int cost;

	cost = 0;
	perrep = (nrepcodes * (nrepcodes+1)) / 2;
	while (count >= perrep) {
		cost += nrepcodes;
		count -= perrep;
	}
	if (count > 0) {
		unsigned int n;
		n = isqrt(count);
		while ((n*(n+1)) >= 2*count) n --;
		while ((n*(n+1)) < 2*count) n ++;
		cost += n;
	}
	return(cost);
}

static void max_out_clear(void)
{
	out_clear = max_ocodes;
}

static void reset_out_clear(void)
{
	out_clear = out_clear_init;
	if (out_count >= out_clear) {
		output(code_clear);
		did_clear();
	}
}

static void rl_flush_fromclear(int count)
{
	int n;

#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush_fromclear %d\n",count);
#endif
	max_out_clear();
	rl_table_pixel = rl_pixel;
	n = 1;
	while (count > 0) {
		if (n == 1) {
			rl_table_max = 1;
			output_plain(rl_pixel);
			count --;
		  }
		  else if (count >= n) {
			rl_table_max = n;
			output_plain(rl_basecode+n-2);
			count -= n;
		  }
		  else if (count == 1) {
			rl_table_max ++;
			output_plain(rl_pixel);
			count = 0;
		  }
		  else {
			rl_table_max ++;
			output_plain(rl_basecode+count-2);
			count = 0;
		}
		if (out_count == 0) n = 1;
			else 			n++;
	}
	reset_out_clear();
#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush_fromclear leaving table_max=%d\n",rl_table_max);
#endif
}

static void rl_flush_clearorrep(int count)
{
	int withclr;

#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush_clearorrep %d\n",count);
#endif
	withclr = 1 + compute_triangle_count(count,max_ocodes);
	if (withclr < count) {
		output(code_clear);
		did_clear();
		rl_flush_fromclear(count);
	  }
	  else {
		for ( ;count>0;count--) output_plain(rl_pixel);
	}
}

static void rl_flush_withtable(int count)
{
	int repmax;
	int repleft;
	int leftover;

#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush_withtable %d\n",count);
#endif
	repmax = count / rl_table_max;
	leftover = count % rl_table_max;
	repleft = (leftover ? 1 : 0);
	if (out_count+repmax+repleft > max_ocodes) {
		repmax = max_ocodes - out_count;
		leftover = count - (repmax * rl_table_max);
		repleft = 1 + compute_triangle_count(leftover,max_ocodes);
	}
#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush_withtable repmax=%d leftover=%d repleft=%d\n",repmax,leftover,repleft);
#endif
	if (1+compute_triangle_count(count,max_ocodes) < repmax+repleft) {
		output(code_clear);
		did_clear();
		rl_flush_fromclear(count);
		return;
	}
	max_out_clear();
	for (;repmax>0;repmax--) output_plain(rl_basecode+rl_table_max-2);
	if (leftover) {
		if (just_cleared) {
			rl_flush_fromclear(leftover);
		  }
		  else if (leftover == 1) {
			output_plain(rl_pixel);
		  }
		  else {
			output_plain(rl_basecode+leftover-2);
		}
	}
	reset_out_clear();
}

static void rl_flush(void)
{
	int table_reps;
	int table_extra;

#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush [ %d %d\n",rl_count,rl_pixel);
#endif
	if (rl_count == 1) {
		output_plain(rl_pixel);
		rl_count = 0;
#ifdef VERBOSE
		if (VERBOSE) printf("rl_flush ]\n");
#endif
		return;
	}
	if (just_cleared) {
		rl_flush_fromclear(rl_count);
	  }
	  else if ((rl_table_max < 2) || (rl_table_pixel != rl_pixel)) {
		rl_flush_clearorrep(rl_count);
	  }
	  else {
		rl_flush_withtable(rl_count);
	}
#ifdef VERBOSE
	if (VERBOSE) printf("rl_flush ]\n");
#endif
	rl_count = 0;
}

static void compress(int init_bits, FILE *outfile, int background)
{
	int c;

	ofile = outfile;
	obuf = 0;
	obits = 0;
	oblen = 0;
	code_clear = 1 << (init_bits - 1);
	code_eof = code_clear + 1;
	rl_basecode = code_eof + 1;
	out_bump_init = (1 << (init_bits - 1)) - 1;
/* for images with a lot of runs, making out_clear_init larger will
    give better compression. */ 
	out_clear_init = (init_bits <= 3) ? 9 : (out_bump_init-1);
	out_bits_init = init_bits;
	max_ocodes = (1 << GIFBITS) - ((1 << (out_bits_init - 1)) + 3);
	did_clear();
	output(code_clear);
	rl_count = 0;
	while (1) {
		c = GIFNextPixel();
		if ((rl_count > 0) && (c != rl_pixel)) rl_flush();
		if (c == EOF) break;
		if (rl_pixel == c) {
			rl_count ++;
		  }
		  else {
			rl_pixel = c;
			rl_count = 1;
		}
	}
	output(code_eof);
	output_flush();
}

static void GIFEncode(FILE *fp, int GWidth, int GHeight, int GInterlace, int Background,
							int Transparent, int BitsPerPixel, int *Red, int *Green, int *Blue, int lctf)
{
	int B;
	int RWidth, RHeight;
	int LeftOfs, TopOfs;
	int Resolution;
	int ColorMapSize;
	int InitCodeSize;
	int i;
	unsigned char c=0x00;

	Interlace = GInterlace;

	ColorMapSize = 1 << BitsPerPixel;

	RWidth = Width = GWidth;
	RHeight = Height = GHeight;
	LeftOfs = TopOfs = 0;

	Resolution = BitsPerPixel;

/*
 * Calculate number of bits we are expecting
 */
	CountDown = (long)Width * (long)Height;

/*
 * Indicate which pass we are on (if interlace)
 */
	Pass = 0;

/*
 * The initial code size
 */
	if( BitsPerPixel <= 1 ) InitCodeSize = 2;
        else 				InitCodeSize = BitsPerPixel;

/*
 * Set up the current x and y position
 */
	curx = cury = 0;

/*
 * Write the Magic header
	fwrite( Transparent < 0 ? "GIF87a" : "GIF89a", 1, 6, fp );
 */

/*
 * Write out the screen width and height
	Putword( RWidth, fp );
	Putword( RHeight, fp );
 */

/*
 * Indicate that there is a global colour map
 */
/*	B = 0x80;*/       /* Yes, there is a color map */

/*
 * OR in the resolution
 */
/*	B |= (Resolution - 1) << 4;		*/

/*
 * OR in the Bits per Pixel
 */
/*	B |= (BitsPerPixel - 1);		*/

/*
 * Write it out
 */
/*	fputc( B, fp );					*/

/*
 * Write out the Background colour
 */
/*	fputc( Background, fp );		*/

/*
 * Byte of 0's (future expansion)
 */
/*	fputc( 0, fp );					*/

/*
 * Write out the Global Colour Map
	for( i=0; i<ColorMapSize; ++i ) {
		fputc( Red[i], fp );
		fputc( Green[i], fp );
		fputc( Blue[i], fp );
	}
 */

	/*
	 * Write out extension for transparent colour index, if necessary.
	if ( Transparent >= 0 ) {
		fputc( '!', fp );
		fputc( 0xf9, fp );
		fputc( 4, fp );
		fputc( 1, fp );
		fputc( 0, fp );
		fputc( 0, fp );
		fputc( (unsigned char) Transparent, fp );
		fputc( 0, fp );
	}
	 */

/*
 * Write an Image separator
	fputc( ',', fp );
 */

/*
 * Write the Image header
 */

	Putword( LeftOfs, fp );
	Putword( TopOfs, fp );
	Putword( Width, fp );
	Putword( Height, fp );

/*
 * Write out whether or not the image is interlaced
 */

	if( Interlace ) c|=0x40;

/*
 * Write out the Local Colour Map
 */
	if (lctf && globalct==0) {
		c|=0x80|(BitsPerPixel-1);
		fputc( c, fp );
		for( i=0; i<ColorMapSize; ++i ) {
			fputc( Red[i], fp );
			fputc( Green[i], fp );
			fputc( Blue[i], fp );
		}
	  }
	  else fputc( c, fp );

/*
 * Write out the initial code size
 */
	fputc( InitCodeSize, fp );

/*
 * Go and actually compress the data
 */
	compress( InitCodeSize+1, fp, Background );

/*
 * Write out a Zero-length packet (to end the series)
 */
	fputc( 0, fp );

/*
 * Write the GIF file terminator
	fputc( ';', fp );
 */
}

/*-----------------------------------------------------------------------
 *
 * End of miGIF section  - See copyright notice at start of section.
 *
/*-----------------------------------------------------------------------

/* +-------------------------------------------------------------------+ */
/* | Copyright 1990, 1991, 1993, David Koblas.  (koblas@netcom.com)    | */
/* |   Permission to use, copy, modify, and distribute this software   | */
/* |   and its documentation for any purpose and without fee is hereby | */
/* |   granted, provided that the above copyright notice appear in all | */
/* |   copies and that both that copyright notice and this permission  | */
/* |   notice appear in supporting documentation.  This software is    | */
/* |   provided "as is" without express or implied warranty.           | */
/* +-------------------------------------------------------------------+ */

/*
static int GetDataBlock_(FILE *fd, unsigned char *buf)
{
       unsigned char   count;

       if (! ReadOK(fd,&count,1)) {
               return -1;
       }

       ZeroDataBlock = count == 0;

       if ((count != 0) && (! ReadOK(fd, buf, count))) {
               return -1;
       }

       return count;
}
*/

static int GetDataBlock_(FILE *fd, unsigned char *buf)
{
	unsigned char count;
	int nc;

	nc=get_gifbytes(&count,1);
#ifdef DIRECT
	fwrite(&count, 1, 1, fd);
#endif

	ZeroDataBlock = count == 0;

/*	if (count!=255) printf("Block# %04d\n",count);			*/
	if (count != 0) {
		nc=get_gifbytes(buf,count);
#ifdef DIRECT
		fwrite(buf, 1, nc, fd);
#endif
	}

	return count;
}

static int GetDataBlock(FILE *fd, unsigned char *buf)
{
	int rv;
	int i;

	rv = GetDataBlock_(fd, buf);
#ifdef VERBOSE
	if (VERBOSE) {
		printf("[GetDataBlock returning %d",rv);
		if (rv > 0) {
			printf(":");
			for (i=0;i<rv;i++) printf(" %02x",buf[i]);
		}
		printf("]\n");
	}
#endif
	return(rv);
}

static int GetCode_(FILE *fd, int code_size, int flag)
{
	static unsigned char    buf[280];
	static int              curbit, lastbit, done, last_byte;
	int                     i, j, ret;
	unsigned char           count;

	if (flag) {
		curbit = 0;
		lastbit = 0;
		done = FALSE;
		return 0;
	}

	if ( (curbit+code_size) >= lastbit) {
		if (done) {
			if (curbit >= lastbit) {
				/* Oh well */
			}                        
			return -1;
		}
		buf[0] = buf[last_byte-2];
		buf[1] = buf[last_byte-1];

		if ((count = GetDataBlock(fd, &buf[2])) == 0) done = TRUE;

		last_byte = 2 + count;
		curbit = (curbit - lastbit) + 16;
		lastbit = (2+count)*8 ;
	}

	ret = 0;
	for (i = curbit, j = 0; j < code_size; ++i, ++j) {
			ret |= ((buf[ i / 8 ] & (1 << (i % 8))) != 0) << j;
	}

	curbit += code_size;
	return ret;
}

static int GetCode(FILE *fd, int code_size, int flag)
{
	int rv;

	rv = GetCode_(fd, code_size,flag);

#ifdef VERBOSE
	if (VERBOSE) printf("[GetCode(,%d,%d) returning %d]\n",code_size,flag,rv);
#endif

	return(rv);
}

static int LWZReadByte_(FILE *fd, int flag, int input_code_size)
{
	static int      fresh = FALSE;
	int             code, incode;
	static int      code_size, set_code_size;
	static int      max_code, max_code_size;
	static int      firstcode, oldcode;
	static int      clear_code, end_code;
	static int      table[2][(1<< MAX_LWZ_BITS)];
	static int      stack[(1<<(MAX_LWZ_BITS))*2], *sp;
	register int    i;

	if (flag) {
		set_code_size = input_code_size;
		code_size = set_code_size+1;
		clear_code = 1 << set_code_size ;
		end_code = clear_code + 1;
		max_code_size = 2*clear_code;
		max_code = clear_code+2;

		GetCode(fd, 0, TRUE);

		fresh = TRUE;

		for (i = 0; i < clear_code; ++i) {
			table[0][i] = 0;
			table[1][i] = i;
		}
		for (; i < (1<<MAX_LWZ_BITS); ++i)
			table[0][i] = table[1][0] = 0;
			sp = stack;
		return 0;
	  }
	  else if (fresh) {
		fresh = FALSE;
		do {
			firstcode = oldcode = GetCode(fd, code_size, FALSE);
		} while (firstcode == clear_code);
		return firstcode;
	}

	if (sp > stack) return *--sp;

	while ((code = GetCode(fd, code_size, FALSE)) >= 0) {
		if (code == clear_code) {
			for (i = 0; i < clear_code; ++i) {
				table[0][i] = 0;
				table[1][i] = i;
			}
			for (; i < (1<<MAX_LWZ_BITS); ++i) table[0][i] = table[1][i] = 0;
			code_size = set_code_size+1;
			max_code_size = 2*clear_code;
			max_code = clear_code+2;
			sp = stack;
			firstcode = oldcode = GetCode(fd, code_size, FALSE);
			return firstcode;
		  } 
		  else if (code == end_code) {
			int             count;
			unsigned char   buf[260];
			if (ZeroDataBlock) return -2;
			while ((count = GetDataBlock(fd, buf)) > 0) ;
			if (count != 0) return -2;
		}

		incode = code;

		if (code >= max_code) {
			*sp++ = firstcode;
			code = oldcode;
		}

		while (code >= clear_code) {
			*sp++ = table[1][code];
			if (code == table[0][code]) {
					/* Oh well */
			}
			code = table[0][code];
		}

		*sp++ = firstcode = table[1][code];

		if ((code = max_code) <(1<<MAX_LWZ_BITS)) {
			table[0][code] = oldcode;
			table[1][code] = firstcode;
			++max_code;
			if ((max_code >= max_code_size) &&
						(max_code_size < (1<<MAX_LWZ_BITS))) {
				max_code_size *= 2;
				++code_size;
			}
		}

		oldcode = incode;

		if (sp > stack) return *--sp;
	}
	return code;
}

static int LWZReadByte(FILE *fd, int flag, int input_code_size)
{
	int rv;

	rv = LWZReadByte_(fd, flag,input_code_size);

#ifdef VERBOSE
	if (VERBOSE) printf("[LWZReadByte(,%d,%d) returning %d]\n",flag,input_code_size,rv);
#endif

	return(rv);
}

void ImageSetPixel(int x, int y, int color)
{
	if (!(((y < 0) || (y >= sy)) || ((x < 0) || (x >= sx)))) pixels[y*sx+x] = color;
}

get_image_outline(int *gx1,int *gy1,int *gwid1,int *ghei1,int crop)
{
	int r, g, b, r0, g0, b0, i, j;
	int wid,hei,ss0,ss1,x0,y0;
	int xxx0,xxx1;

	r0=red[pixels[0]];
	g0=green[pixels[0]];
	b0=blue[pixels[0]];
	x0=sx;		y0=sy;
	for (wid=hei=ss1=i=0; i < sy; i++) {
		for (ss0=j=0; j < sx; j++) {
			r = red[pixels[i*sx+j]];
			g = green[pixels[i*sx+j]];
			b = blue[pixels[i*sx+j]];
			if (r!=r0 || g!=g0 || b!=b0) {
				if (ss0==0) {
					ss0=1;	xxx0=j;
				}
				xxx1=j;
			}
		}
		if (ss0) {
			if (ss1==0) {
				ss1=1;	y0=i;
			}
			if (x0>xxx0) x0=xxx0;
			if (wid<xxx1) wid=xxx1;
			hei=i;
		}
	}

	wid-=x0-1-2*crop;		hei-=y0-1-2*crop;
	x0-=crop;				y0-=crop;
	if (x0<0) x0=0;
	if (y0<0) y0=0;
	if (x0+wid-1>sx) wid=sx-x0+1;
	if (y0+hei-1>sy) hei=sy-y0+1;

	*gx1=x0;
	*gy1=y0;
	*gwid1=wid;
	*ghei1=hei;
}

crop_image(int x0,int y0,int wid,int hei)
{
	int i, j;

	for (i=0; i < hei; i++) {
		for (j=0; j < wid; j++) pixels[i*wid+j]=pixels[(i+y0)*sx+j+x0];
	}
	sx=wid;	sy=hei;
	if (sx>xmax) xmax=sx;
	if (sy>ymax) ymax=sy;
}

static void ReadImage(FILE *fd, int len, int height, unsigned char (*cmap)[MAXCOLORMAPSIZE],
										int lctf, int interlace, int ignore)
{
	unsigned char c;
	int v, i, xpos = 0, ypos = 0, pass = 0, nc;
	int BitsPerPixel;
	static int ncrop=0;

	sx=len;		sy=height;
	if (pixels!=NULL) free(pixels);
	pixels = (unsigned char *) malloc(sizeof(unsigned char *)*sx*sy);

/* Stash the color map into the image */
	for (i=0; (i<gdMaxColors); i++) {
		red[i] = cmap[CM_RED][i];	
		green[i] = cmap[CM_GREEN][i];	
		blue[i] = cmap[CM_BLUE][i];	
		usecol[i] = 1;
	}
/* Many (perhaps most) of these colors will remain marked usecol. */
	colorsTotal = gdMaxColors;

/*
**  Initialize the Compression routines
*/
	nc=get_gifbytes(&c,1);
#ifdef DIRECT
	fwrite(&c, 1, 1, fd);
#endif
	if (LWZReadByte(fd, TRUE, c) < 0) return;
/*
**  If this is an "uninteresting picture" ignore it.
*/
	if (ignore) {
		while (LWZReadByte(fd, FALSE, c) >= 0) ;
		return;
	}

	while ((v = LWZReadByte(fd, FALSE,c)) >= 0 ) {
		/* This how we recognize which colors are actually used. */
		if (usecol[v]) usecol[v]=0;
		ImageSetPixel(xpos, ypos, v);
		++xpos;
		if (xpos == len) {
			xpos = 0;
			if (interlace) {
				switch (pass) {
					case 0:
					case 1:
						ypos += 8; break;
					case 2:
						ypos += 4; break;
					case 3:
						ypos += 2; break;
				}

				if (ypos >= height) {
					++pass;
					switch (pass) {
						case 1:
							ypos = 4; break;
						case 2:
							ypos = 2; break;
						case 3:
							ypos = 1; break;
						default:
							goto fini;
					}
				}
			  }
			  else {
				++ypos;
			}
		}
		if (ypos >= height) break;
	}

fini:
	if (LWZReadByte(fd, FALSE,c)>=0) {
			/* Ignore extra */
	}

	if (cropimage) {
		if (autocrop) {
			get_image_outline(&gx0,&gy0,&gwidth,&gheight,croppixel);
			ncrop++;
			printf("Page No.%05d  Auto cropped: %dx%d+%d+%d\n",ncrop,gwidth,gheight,gx0,gy0);
			if (swanime) autocrop=0;
		}
		crop_image(gx0,gy0,gwidth,gheight);
	}

	for (i=colorsTotal-1; i>=0; i--) {
		if (usecol[i]==0) break;
		colorsTotal--;
	} 
#ifdef SPEAK
	printf("Total color #: %d\n",colorsTotal);
#endif

	if (!ZeroDataBlock) {
		nc=get_gifbytes(&c,1);
#ifdef DIRECT
		fwrite(&c, 1, 1, fd);
#endif
	}

	BitsPerPixel = colorstobpp(colorsTotal);
/* Clear any old values in statics strewn through the GIF code */
	init_statics();
/* All set, let's do it. */
/*		printf("Do Encode\n");			*/
	GIFEncode(fd, sx, sy, interlace, 0, transparent, BitsPerPixel, red, green, blue, lctf);

}

/*	End of copies from GD1.3 	*/
#endif

static void read_colormap(FILE *fd, int number, unsigned char (*cmap)[MAXCOLORMAPSIZE], int com)
{
	int i,nc,i3;
	unsigned char rgb[3*MAXCOLORMAPSIZE];

	nc=get_gifbytes(rgb,3*number);
	for (i3 = 0; i3 < 3*number; i3+=3) {
		if (revbw) {
			if (rgb[i3]==0 && rgb[i3+1]==0 && rgb[i3+2]==0) {
				rgb[i3] = rgb[i3+1] = rgb[i3+2] = 255;
			  }
			  else if (rgb[i3]==255 && rgb[i3+1]==255 && rgb[i3+2]==255) {
				rgb[i3] = rgb[i3+1] = rgb[i3+2] = 0;
			}
		}
	}

	if (com) {
		fwrite(rgb, 1, nc, fd);
		return;
	}

	for (i = i3 = 0; i < number; i++, i3+=3) {
		cmap[CM_RED][i] = rgb[i3] ;
		cmap[CM_GREEN][i] = rgb[i3+1] ;
		cmap[CM_BLUE][i] = rgb[i3+2] ;
	}
}

static void read_imageblock(FILE *imout, unsigned char (*ColorMap)[MAXCOLORMAPSIZE],
											unsigned char *cct, int ignore, int check)
{
	int nc,lctf,slct;
	int left,top,width,height;
	unsigned char str[260];
	unsigned char localColorMap[3][MAXCOLORMAPSIZE];

	nc=get_gifbytes(str,9);
	left=Makeword(str[0],str[1]);
	top=Makeword(str[2],str[3]);
	width=Makeword(str[4],str[5]);
	height=Makeword(str[6],str[7]);
#ifdef SPEAK
	printf("Block Image #%05d: (%4d,%4d)-(%4d,%4d)\n",ncount,left,top,width,height);
#endif

	if (check) {
		lctf=str[8]&COLORMAPBIT;
		if (lctf) {
			slct=2<<(str[8]&0x07);
			read_colormap(imout, slct, ColorMap, 0);
			*cct=str[8];
			return;
		}
	}

#ifdef GD
	if (resize) {
#ifdef SPEAK
		printf("Reencode GIF images\n");
#endif
		str[0]=left&0xff;
		str[1]=left>>8;
		str[2]=top&0xff;
		str[3]=top>>8;
		str[4]=width&0xff;
		str[5]=width>>8;
		str[6]=height&0xff;
		str[7]=height>>8;
		lctf=str[8]&COLORMAPBIT;
		fputc( 0x2c, imout);
		if (lctf) {
			slct=2<<(str[8]&0x07);
			read_colormap(imout, slct, localColorMap, 0);
			ReadImage(imout, width, height, localColorMap, lctf, BitSet(str[8], INTERLACEBIT), ignore);
		  }
		  else {
			ReadImage(imout, width, height, ColorMap, lctf, BitSet(str[8], INTERLACEBIT), ignore);
		}
	  }
	  else {
#endif
/*store		printf("Direct store GIF images\n");			*/
		fputc( 0x2c, imout);
		fwrite(str, 1, 9, imout);
		lctf=str[8]&COLORMAPBIT;
		if (lctf) {
			slct=2<<(str[8]&0x07);
			read_colormap(imout, slct, localColorMap, 1);
		}
		nc=get_gifbytes(str,1);
		nc=fwrite(str, 1, 1, imout);
		read_block_data(str,imout,0);
#ifdef GD
	}
#endif
}

static void write_header(unsigned char *header, unsigned char cct,
								unsigned char (*cmap)[MAXCOLORMAPSIZE], FILE *fp)
{
	int i,cn;

	if (fp == NULL) return;
	fwrite(header, 1, nhead, fp);
	if (cct&COLORMAPBIT) {
		cn=2<<(cct&0x07);
		for(i=0;i<cn;i++) {
			fputc( cmap[CM_RED][i], fp );
			fputc( cmap[CM_GREEN][i], fp );
			fputc( cmap[CM_BLUE][i], fp );
		}
	}
}

static int process_gif(int check, int na, int na0)
{
	int nc,gctf,lctf,sgct,slct,ind;
	unsigned char str[SIZE];
	struct stat statbuf;
	static FILE *imout;
	int imageNumber=1,imageCount=0;
	unsigned char ColorMap[3][MAXCOLORMAPSIZE];
	unsigned char header[1024],cgct;
	static unsigned char localColorMap[3][MAXCOLORMAPSIZE];
	static unsigned char clct='\0';

	nc=get_gifbytes(str,4);
	nc=get_gifbytes(str,3);
	cgct=str[0];
	gctf=cgct&COLORMAPBIT;
	set_buffer(1,header);
	if (gctf) {
		sgct=2<<(cgct&0x07);
		read_colormap(imout, sgct, ColorMap, 0);
	}

/*	Main Blocks		*/

	if (swanime) {
		ind=1;
		if (addimage) {
			if (addimage > 1) ind=0;
			  else {
#ifdef SPEAK
				printf("GIF Animation Image\n");
#endif
				sprintf(str,"%s_add.gif",gifname);
			}
			addimage++;
		  }
		  else {
#ifdef SPEAK
			printf("GIF Animation Image %d\n",na);
#endif
			sprintf(str,"%s_a%.3d.gif",gifname,na);
		}
		if (ind) {
			imout = fopen(str, "wb");
			if (check || clct=='\0') {
				write_header(header,cgct,ColorMap,imout);
			  }
			  else {
				write_header(header,clct,localColorMap,imout);
			}
			write_agif(imout);
			xmax=ymax=0;
		}
	}

	while (1) {
		nc=get_gifbytes(str,1);
		if (str[0]==0x3b) {
		/*	Read Termination		*/
			if (imageNumber==0 || imageCount<imageNumber) {
				error_end("File is incomplete (wrong termination) !!!\n");
			}
			break;
		}
		if (str[0]==0x2c) {	/* , */
		/*	Read Image Blocks		*/
			ncount++;
			++imageCount;
			if (swanime==0) {
			/*	Break up into GIF images		*/
				xmax=ymax=0;
				if (storecount>0 && ncount!=storecount) {
					nc=get_gifbytes(str,9);
					lctf=str[8]&COLORMAPBIT;
					if (lctf) {
						slct=2<<(str[8]&0x07);
						nc=get_gifbytes(str,3*slct);
					}
					nc=get_gifbytes(str,1);
					read_block_data(str,NULL,0);
				  }
				  else {
					if (nskip>1)
					  	sprintf(str,"%s_%.2d_%.4d.gif",gifname,(ncount-1)%nskip+1,(ncount-1)/nskip+1);
					  else
					  	sprintf(str,"%s_%.4d.gif",gifname,ncount);
					imout = fopen(str, "wb");
					write_header(header,cgct,ColorMap,imout);
					read_imageblock(imout,ColorMap,&clct,imageCount!=imageNumber,0);
					fputc( 0x3b, imout);
					if (xmax+ymax>0) {
						fseek(imout,REAGIONPOS,SEEK_SET);
						Putword( xmax, imout );
						Putword( ymax, imout );
					}
					fclose(imout);
				}
			  }
			  else if ((na0<0 && (ncount-1)%nskip==na-1) || ncount>=na0) {
				if (globalct && check) {
			/*	Read one time to make a local colormap to a global colormap		*/
					read_imageblock(imout,localColorMap,&clct,imageCount!=imageNumber,1);
					if (clct) {
						fclose(imout);
						ncount=0;
						return 1;
					}
				  }
				  else {
			/*	Rearrange in a new GIF animatin		*/
					read_imageblock(imout,ColorMap,&clct,imageCount!=imageNumber,0);
				}
			  }
			  else {
			/*	Skip this block				*/
				nc=get_gifbytes(str,9);
				lctf=str[8]&COLORMAPBIT;
				if (lctf) {
					slct=2<<(str[8]&0x07);
					nc=get_gifbytes(str,3*slct);
				}
				nc=get_gifbytes(str,1);
				read_block_data(str,NULL,0);
			}
		  }
		  else if (str[0]==0x21) {	/* ! */
			nc=get_gifbytes(str,1);
			switch (str[0]) {
				case 0xff:
				/*	Read Applocation Extension		*/
					nc=get_gifbytes(str,12);
					read_block_data(str,NULL,str[0]);
					break;
				case 0xfe:
				/*	Read Comment Extension		*/
					read_block_data(str,NULL,str[0]);
					break;
				case 0xf9:
				/*	Read Graphic Control Extension		*/
					nc=get_gifbytes(str,6);
					if (imageCount>0) ++imageNumber;
					break;
				case 0x01:
				/*	Read Plain Text Extension		*/
					nc=get_gifbytes(str,13);
					read_block_data(str,NULL,str[0]);
					break;
				default:
					fprintf(stderr,"%02x: ",str[0]);
					error_end("File is incomplete (wrong code after !) !!!\n");
			}
		  }
		  else {
			fprintf(stderr,"%02x: ",str[0]);
			error_end("File is incomplete (wrong start code) !!!\n");
		}
	}

	if (swanime) {
		if (addimage != 2) {
			fputc( 0x3b, imout);
			if (xmax+ymax>0) {
				fseek(imout,REAGIONPOS,SEEK_SET);
				Putword( xmax, imout );
				Putword( ymax, imout );
			}
			fclose(imout);
		}
		printf("  Animation: %05d Images\n",ncount);
	}
	return 0;
}

check_ext(char *str1,char *ext)
{
	int n=0,j=0,d=0,nj=0,nd=0;
	char c,*str2=gifname;

	while (1) {
		c=*str1;
		if (c!=' ' && c!='\t') break;
		str1++;
	}
	if (c<' ') return -1;

	while (c=(*str1++)) {
		if (c=='.') {  j=1;  nj=n;  }
		  else if (c=='/') {  d=1;  nd=n+1;  }
		(*str2++)=c;	n++;
	}

	if (j==0 || nd>nj) {
		(*str2++)='.';		nj=n;
		while (*ext) (*str2++)=*ext++;
	}
	*str2='\0';

	for (j=nd;j<nj;j++) gifname[j-nd]=gifname[j];
	gifname[nj-nd]='\0';
	return 0;
}

int main(int argc, char *argv[])
{
	int i,k=0,nc,na=1,namax=1,autoc;
	char name[100],name2[100],*st,str[10];
	long fpos;
	struct stat statbuf;
	FILE *fpg2=NULL;

	for (i=1;i<argc;i++) {
		if (*argv[i]!='-') {  
			if (k && addimage==0) {
				fputs("Specify only 1 file name !\n",stderr);
				exit(1);
			  }
			  else if (k == 1) {
				strcpy(name2,argv[i]);
				swanime=1;
			  }
			  else if (k == 0) {
				strcpy(name,argv[i]);
			}
			k++;
		  }
		  else {
			st=argv[i];
			switch (*(++st)) {
				case 'a': 	case 'A':
					if (*(++st) == 'd' || *(st) == 'D' ) {
						addimage=1;
						na=0;
					  }
					  else {
						swanime=1;
						if (*st) {
							nanim=atoi(st);
							if (nanim<=0) nanim=1;
							na=nanim;		namax=na;
						  }
						  else {
							na=0;		namax=1;
						}
					}
					stanime=1;
					continue;
				case 'n': 	case 'N':
					if (*(++st)) {
						storecount=atoi(st);
						if (storecount<=0) storecount=0;
					}
					stanime=0;
					continue;
				case 'd': 	case 'D':
					swanime=1;
					if (stanime==0) {
						na=0;		namax=1;
					}
					if (*(++st)) delay=atoi(st);
					continue;
				case 'g': 	case 'G':
					if (*(++st) == 'c' || *st == 'C') {
						globalct=1;
					}
					continue;
				case 'c':	case 'C':
					cropimage=1;		autocrop=1;		croppixel=0;		resize=1;
					if (*(++st)) croppixel=atoi(st);
					continue;
				case 's':	case 'S':
					if (*(++st)) nskip=atoi(st);
					nskipset=1;
					continue;
				case 'r':	case 'R':
					if (*(++st) == 'b' || *st == 'B') {
						if (*(++st) == 'w' || *st == 'W') revbw=1;
					}
					continue;
				default:
					help_menu();
			}
		  }
next:	;
	}

	if (k == 1) {
		if ((fpg1=fopen(name,"rb"))==NULL) {
			fprintf(stderr,"No such File : %s\n",name);
			exit(1);
		}
		fprintf(stderr,"Processing %s .....\n",name);
	  }
	  else if (k == 2) {
		if ((fpg1=fopen(name,"rb"))==NULL) {
			fprintf(stderr,"No such File : %s\n",name);
			exit(1);
		}
		if ((fpg2=fopen(name2,"rb"))==NULL) {
			fprintf(stderr,"No such File : %s\n",name);
			exit(1);
		}
		fprintf(stderr,"Processing %s and %s .....\n",name,name2);
	  }
	  else help_menu();

	if (swanime) {
		if (addimage) {
			printf("Add %s to %s.\n",name2,name);
		  }
		  else {
			printf("Make a reduced GIF animation (%d).\n",nanim);
		}
		printf("  Delay = %d\n",delay);
		if (globalct) printf("  Use global color table\n");
	  }
	  else {
		printf("Break up into GIF images.\n");
	}
	if (autocrop) {
		printf("  AutoCrop : Yes,  Pixel = %d\n",croppixel);
		autoc=autocrop;
	}
	  else {
		printf("  AutoCrop : No\n",croppixel);
	}

/*	Read GIF Header		*/
	set_buffer(0,NULL);
	nc=get_gifbytes(str,6);
	k=check_words(str,"GIF89a",6);
	if (k) {
		k=check_words(str,"GIF87a",6);
		if (k) {
			fprintf(stderr,"This is not a GIF File : %s\n",name);
			exit(1);
		}
#ifdef SPEAK
		printf("GIF87a File\n");
	  }
	  else printf("GIF89a File\n");
#else
	}
#endif

	check_ext(name,"gif");
	if (swanime) {
		if (globalct) {
			fpos=nr;
			if (process_gif(1,na+1,na)) {
				nc=get_gifbytes(str,-6);
				process_gif(0,na+1,na);
			}
		  }
		  else {
			globalct=0;
			process_gif(0,na+1,na);
		}
	  }
	  else {
		do {
			if (globalct) {
				fpos=nr;
				if (process_gif(1,na+1,-1)) {
					nc=get_gifbytes(str,-6);
					process_gif(0,na+1,-1);
				}
			  }
			  else {
				globalct=0;
				process_gif(0,na+1,-1);
			}
			if (na==0) namax=nskip;
			na++;
			if (na<namax) {
				nc=get_gifbytes(str,-6);
				if (autoc) autocrop=1;
			  }
			  else break;
		} while (1);
	}
	fclose(fpg1);
	if (fpg2 == NULL) exit(0);

/*	Processing Second File  */
	fpg1=fpg2;
/*	Read GIF Header		*/
	set_buffer(0,NULL);
	nc=get_gifbytes(str,6);
	k=check_words(str,"GIF89a",6);
	if (k) {
		k=check_words(str,"GIF87a",6);
		if (k) {
			fprintf(stderr,"This is not a GIF File : %s\n",name2);
			exit(1);
		}
#ifdef SPEAK
		printf("GIF87a File\n");
	  }
	  else printf("GIF89a File\n");
#else
	}
#endif

	check_ext(name2,"gif");
	if (swanime) {
		if (globalct) {
			fpos=nr;
			if (process_gif(1,na+1,na)) {
				nc=get_gifbytes(str,-6);
				process_gif(0,na+1,na);
			}
		  }
		  else {
			globalct=0;
			process_gif(0,na+1,na);
		}
	  }

	fclose(fpg1);
	exit(0);
}
