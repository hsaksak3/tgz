/***********************************************
 *             F  R  A  M  E  S  V.7           *
 *             Basic Canvas routines           *
 ***********************************************
*/
#include <stdio.h>

#define NOT_USED_TPLOT
#include "frames.h"
#include "frames_canvas.h"

#define CUBUFMAX		500
#define IWINBIT			2

static frames_canvas gcanvas[MAXFP];
static double	*shbuf[MAXDEFCUMAPP+MAXSYSCOLMAP];
static int 		*nbuf[MAXDEFCUMAPP+MAXSYSCOLMAP],n256map=0,def256map=0,colmapset=0,numfp=0,NFP=0;

static int		bgbackrgb[3]={-1,-1,-1};
static int		windowsize[4]={WINWIDTH,WINHEIGHT,0,0},graphstep=1,defcsize=BASECOLVAL;

#ifdef FBEXCH
static int		fb_exchange=1, giffb_exchange=1;
#else
#ifdef GIFFBEXCH
static int		fb_exchange=0, giffb_exchange=1;
#else
static int		fb_exchange=0, giffb_exchange=0;
#endif
#endif

#ifdef ENDIAN_CONVERT
static int *ENDIAN_INT;
static double *ENDIAN_DOUBLE;
void convert_integern(int *n,...)
{
	union linteg { char c[4];	signed int l; } b;
	char d;
	int **np=&n,i;

	for (i=1;i<=*n;i++) {
		b.l=*np[i];
		d=b.c[0];	b.c[0]=b.c[3];	b.c[3]=d;
		d=b.c[1];	b.c[1]=b.c[2];	b.c[2]=d;
		*np[i]=b.l;
	}
}

void convert_doublen(int *n,double *x,...)
{
	union linteg { char c[8];	double l; } b;
	char d;
	int i;
	double **xp=&x;

	for (i=0;i<*n;i++) {
		b.l=*xp[i];
		d=b.c[0];	b.c[0]=b.c[7];	b.c[7]=d;
		d=b.c[1];	b.c[1]=b.c[6];	b.c[6]=d;
		d=b.c[2];	b.c[2]=b.c[5];	b.c[5]=d;
		d=b.c[3];	b.c[3]=b.c[4];	b.c[4]=d;
		*xp[i]=b.l;
	}
}

void convert_pointer(int *n,double *x)
{
	ENDIAN_INT=n;
	ENDIAN_DOUBLE=x;
}

void convert_integer(int *n,...)
{
	union linteg { char c[4];	signed int l; } b;
	char d;
	int **np=&n,i=0;

	while (np[i] != ENDIAN_INT) {
		b.l=*np[i];
		d=b.c[0];	b.c[0]=b.c[3];	b.c[3]=d;
		d=b.c[1];	b.c[1]=b.c[2];	b.c[2]=d;
		*np[i]=b.l;
		i++;
	}
}

void convert_double(double *x,...)
{
	union linteg { char c[8];	double l; } b;
	char d;
	int i=0;
	double **xp=&x;

	while (xp[i] != ENDIAN_DOUBLE) {
		b.l=*xp[i];
		d=b.c[0];	b.c[0]=b.c[7];	b.c[7]=d;
		d=b.c[1];	b.c[1]=b.c[6];	b.c[6]=d;
		d=b.c[2];	b.c[2]=b.c[5];	b.c[5]=d;
		d=b.c[3];	b.c[3]=b.c[4];	b.c[4]=d;
		*xp[i]=b.l;
		i++;
	}
}
#endif

frames_canvas *get_gcanvasp(void)
{
	return &gcanvas[NFP];
}

void get_canvas_rgb(int rgb[])
{
	if (numfp==0) {
		rgb[0]=bgbackrgb[0];
		rgb[1]=bgbackrgb[1];
		rgb[2]=bgbackrgb[2];
	  }
	  else {
		rgb[0]=gcanvas[NFP].r;
		rgb[1]=gcanvas[NFP].g;
		rgb[2]=gcanvas[NFP].b;
	}
}

void get_canvas_charsize(int *csize)
{
	if (numfp==0) {
		*csize=defcsize;
	  }
	  else {
		*csize=gcanvas[NFP].csize;
	}
}

void get_canvas_hlstable(int colset,int *nmap,double ***shp,int ***np)
{
	*nmap=n256map-colset;
	if (*nmap>0) {
		*shp=&shbuf[colset];		*np=&nbuf[colset];
	}
}

int get_current_hlstable(double **shp,int **np)
{
	if (colmapset<=0) return colmapset;
	*shp=shbuf[colmapset-1];		*np=nbuf[colmapset-1];
	return colmapset;
}

void set_canvas_status(int status,int onoff)
{
	if (onoff == STATUSON)	gcanvas[NFP].status |= status;
			else			gcanvas[NFP].status ^= status;
}

#define rgbmax 		65536
#define rgbmax1		(rgbmax-1)
#define rgbmax6 	(6*rgbmax)
void gcanvasbackgroundhls(double *dh,double *dl,double *ds)
{
	unsigned int w1,w2,fh,fl,fs;
	int wh,r,g,b;

	if (*dh < 0) {
		bgbackrgb[0]=-1;
		return;
	}

	fh=rgbmax*(*dh)/60;		fl=rgbmax1*(*dl);		fs=rgbmax1*(*ds);
	if (fl>rgbmax1) fl=rgbmax1;
	if (fs>rgbmax1) fs=rgbmax1;

	if ( fl < rgbmax/2 ) w2 = fl*(rgbmax+fs)/rgbmax;
				else     w2 = rgbmax1-(rgbmax-fs)*(rgbmax-fl)/rgbmax;
	w1 = 2*fl-w2;

	if ( fs < rgbmax/1024 ) r = g = b = fl;
	  else {
		wh = fh+2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		r = ( wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
			( wh < 3*rgbmax? w2:
			( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));

		g = ( fh <   rgbmax? w1+(w2-w1)*fh/rgbmax:
			( fh < 3*rgbmax? w2:
			( fh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-fh)/rgbmax: w1 )));

		wh = fh-2*rgbmax;
		if( wh >= rgbmax6 ) wh-=rgbmax6;
		if( wh <        0 ) wh+=rgbmax6;

		b = ( wh <   rgbmax? w1+(w2-w1)*wh/rgbmax:
			( wh < 3*rgbmax? w2:
			( wh < 4*rgbmax? w1+(w2-w1)*(4*rgbmax-wh)/rgbmax: w1 )));
	}
/*	printf("r g b : %d %d %d\n",r,g,b);		*/

	bgbackrgb[0]=r;
	bgbackrgb[1]=g;
	bgbackrgb[2]=b;
}

void gcanvaswindowsize(int *bx,int *by,int *ox,int *oy)
{
	windowsize[0]=*bx;
	windowsize[1]=*by;
	windowsize[2]=*ox;
	windowsize[3]=*oy;

}

void getcanvas_windowsize(int *bx,int *by,int *ox,int *oy)
{
	if (numfp==0) {
		*bx=windowsize[0];
		*by=windowsize[1];
		*ox=windowsize[2];
		*oy=windowsize[3];
	  }
	  else {
		*bx = gcanvas[NFP].width;		*by = gcanvas[NFP].height;
		*ox = gcanvas[NFP].xoff;		*oy = gcanvas[NFP].yoff;
	}
}

void getcanvaswindowsize(int *bx,int *by,int *ox,int *oy)
{
	getcanvas_windowsize(bx,by,ox,oy);
}

void gcanvasgraphstep(int *step)
{
	graphstep=*step;
}

void gcanvascharsize(double *csize)
{
	defcsize=(*csize)*BASECOLVAL;
}

static void initialize_canvas(int nfp,int outlet)
{
	gcanvas[nfp].width=windowsize[0];				gcanvas[nfp].height=windowsize[1];
	gcanvas[nfp].xoff =windowsize[2];				gcanvas[nfp].yoff  =windowsize[3];
	gcanvas[nfp].csize=defcsize;
	gcanvas[nfp].windowmode[0]=graphstep&0xff;		gcanvas[nfp].windowmode[1]=fb_exchange;
	gcanvas[nfp].windowmode[2]=0;
	gcanvas[nfp].agifopion[0]=0;
	gcanvas[nfp].agifopion[1]=GIFBASEDELAY;		gcanvas[nfp].agifopion[2]=0;
	gcanvas[nfp].outlet=outlet;
	gcanvas[nfp].status=0;
	gcanvas[nfp].window=-1;
	gcanvas[nfp].r=-1;
}

void initializecanvas(int *nfp,int *outlet)
{
	initialize_canvas(*nfp,*outlet);
}

/*		windsw ==  2  :   disuse window & not opened (resumable)
		windsw == -1  :      use window & not opened
		windsw ==  0  :   disuse window &     opened
		windsw ==  1  :      use window &     opened
*/
void getcanvaswindowstatus(int *nfp, int *windsw, int *windno)
{
	int nf=*nfp;

	if (nf < 0) nf = NFP;
	if (gcanvas[nf].outlet & IWINBIT) {
		if (gcanvas[nf].window < 0) *windsw = -1;
			else 					*windsw =  1;
	  }
	  else {
		if (gcanvas[nf].window < 0) *windsw =  2;
			else 					*windsw =  0;
	}
	*windno = gcanvas[nf].window;
}

void setcanvaswindownumber(int *n)
{
	gcanvas[NFP].window=*n;
}

void exchangefandbcolor(int *mode)
{
#ifdef FBEXCH
	if (mode) {
		fb_exchange=0;		giffb_exchange=0;
	}
#else
#ifdef GIFFBEXCH
	if (mode) {
		fb_exchange=1;		giffb_exchange=0;
	}
#else
	if (mode) {
		fb_exchange=1;		giffb_exchange=1;
	}
#endif
#endif
}

void cleargcanvasall(int *nfp,int *rate)
{
	int i;

	for (i=0;i<MAXFP;i++) {
		gcanvas[i].fp=NULL;		gcanvas[i].fname=NULL;
		gcanvas[i].colset=0;	gcanvas[i].page=0;			gcanvas[i].window=-1;
	}
	n256map=0;		def256map=0;		numfp=0;		NFP=*nfp;

	windowsize[0]=WINWIDTH;			windowsize[1]=WINHEIGHT;
	windowsize[2]=0;				windowsize[3]=0;
	bgbackrgb[0]=-1;
	graphstep=1;				defcsize=BASECOLVAL;

/*  0 is reserved (changable)	*/
	*rate=WINRATE;
	initialize_canvas(0,IWINBIT);
}

#ifdef CompaqVisual
void gcanvascreate(char *name,int length,int *nfp,int *mode,int *ind)				/* Compaq demands character length	*/
#else
void gcanvascreate(char *name,int *nfp,int *mode,int *ind)
#endif
{
	static char canvasstr[MAXFP*128],*fnp;

	if (numfp==0) fnp=canvasstr;

	if (*nfp<0 || *nfp>=MAXFP) *ind=-1;
	  else if (gcanvas[*nfp].fname!=NULL) *ind=-2;
/*	  else if ((gcanvas[*nfp].fp=fopen(name,"wb"))==NULL) *ind=-1;	*/
	  else {
		gcanvas[*nfp].fname=fnp;			gcanvas[*nfp].gifoption=-1;
		while (*name) (*fnp++)=(*name++);
		(*fnp++)='\0';
		*ind=numfp++;
	  }
}

void gcanvascheck(int *nfp,int *ind)
{
	if (gcanvas[*nfp].fname!=NULL) *ind=0;
							  else *ind=-1;
}

void getcanvasname(char *str,int *nn)
{
	char *name=gcanvas[NFP].fname;
	int n=0;
	if (name != NULL) {
		while (*name) {
			*str++ = *name++;
			n++;
		}
	}
	*nn = n;
}

void setcanvasbackground(int *nfp, int *color, int *mode)
{
	int c=*color;
	if (fb_exchange) c=(c?0:1);
	gcanvas[*nfp].windowmode[1] = c;
	gcanvas[*nfp].windowmode[2] = (*mode==1?2:0);		/*  2: common window	*/
	gcanvas[*nfp].r=bgbackrgb[0];
	gcanvas[*nfp].g=bgbackrgb[1];
	gcanvas[*nfp].b=bgbackrgb[2];
}

void getcanvasbackground(int *color, int *mode)
{
	*color = gcanvas[NFP].windowmode[1];
	*mode = gcanvas[NFP].windowmode[2];
}

void gcanvasgifoption(int *nfp,int *bw,int *interlace,int *transparent,int *coltable,int *anime)
{
	int c=(*bw)&1,c1;
	if (*bw < 0) {
		if (gcanvas[*nfp].gifoption<0) {
			gcanvas[*nfp].gifoption = (*interlace)<<2 | (*transparent)<<3 | (*coltable)<<4 | (*anime)<<5;
		  }
		  else {
			gcanvas[*nfp].gifoption = (gcanvas[*nfp].gifoption & 0x0f)  | (*coltable)<<4 | (*anime)<<5;
		}
	  }
	  else {
		c1=c;
		if (fb_exchange) c^=1;
		gcanvas[*nfp].windowmode[1] = c;
		if (giffb_exchange) c1^=1;
		gcanvas[*nfp].gifoption = c1 | (*bw)&2 | (*interlace)<<2 | (*transparent)<<3 | (*coltable)<<4 | (*anime)<<5;
	}
}

void gcanvasagifoption(int *nfp,int *delay,int *loop)
{
	if (*delay>0) {
		gcanvas[*nfp].agifopion[1]=(*delay)&0xff;		gcanvas[*nfp].agifopion[2]=(*delay)>>8;
	}
	if (*loop>0) {
		gcanvas[*nfp].agifopion[0]=(*loop)&0xff;
	}
}

void setcanvaspointer(int *nf,int *outlet)
{
	int status;
	NFP=*nf;
	*outlet=gcanvas[NFP].outlet;

/*	get_canves_size(bx,by,ox,oy);		*/
}

void setcanvasoutlet(int *nfp,int *outlet)
{
	gcanvas[*nfp].outlet=*outlet;
}

void getcanvasoutlet(int *nfp,int *outlet)
{
	*outlet=gcanvas[*nfp].outlet;
}

void advancecanvaspage(void)
{
	gcanvas[NFP].page++;
}


void gcanvasallclose(void)
{
	int i;

	for (i=0;i<MAXFP;i++) {
		if (gcanvas[i].fp!=NULL) {
#ifndef NOPLT
			plt_fileclose(gcanvas[i].fp);
#endif
			gcanvas[i].fp=NULL;
		}
		gcanvas[i].fname=NULL;
	}
}

void gcanvasclose(int *nfp)
{
	int i=*nfp;
	if (gcanvas[i].fp!=NULL) {
#ifndef NOPLT
		plt_fileclose(gcanvas[i].fp);
#endif
		gcanvas[i].fp=NULL;
	}
	gcanvas[i].fname=NULL;
	if (i==0) gcanvas[0].outlet=IWINBIT;		/*  0 is reserved (changable)	*/
}

void storehlstables(double *sh,double *sl,double *ss,int *div,int *mode,int *cdef
													,int *cumap,int *cusys,int *mret)
{
	static double hlsbuf[CUBUFMAX*3],*sspmax;
	static int ndivbuf[CUBUFMAX],*nnpmax,ismax,inmax;
	int i,is0,in0,cn,mc;

/*	printf("colmapset=%d  *cumap=%d  *cusys=%d\n",colmapset,*cumap,*cusys);		*/
	colmapset=0;
	if (*cusys>0) {
		colmapset=*cusys+MAXDEFCUMAPP;
		mode=nbuf[colmapset-1];		div=mode+1;
	  }
	  else if (*cumap>0) {
		colmapset=*cumap;
		mode=nbuf[colmapset-1];		div=mode+1;
	}

/*	color setting point		*/
	if (*mode<=0 || *div<=0) {
		if (*mode<0 || *div<=0) cn=*cdef;
		  else					cn=*div;
	  }
	  else {
		in0=*mode;
		if (in0==1) cn=*div;
		  else {
/*	color setting point		*/
			for (i=cn=0;i<in0;i++) {
				mc=div[i]-1;
				if (mc<0) mc=1;
				cn+=mc;
			}
			cn++;
		}
	}
	*mret=cn;
	if (*cumap>=0 || *cusys>0) return;

	if (def256map==0) {
		sspmax=hlsbuf;		nnpmax=ndivbuf;
		ismax=inmax=0;
	}

	if (*cusys==0) colmapset=*cumap;

	if (*cusys<0) {
		colmapset=*cusys-MAXDEFCUMAPP;
		in0=*mode+1;	is0=in0;
		if (ismax+is0*3<CUBUFMAX && inmax+in0<CUBUFMAX) {
			mc=-colmapset-1;
			shbuf[mc]=sspmax;
			for (i=0;i<is0;i++) *sspmax++ = sh[i];
			for (i=0;i<is0;i++) *sspmax++ = sl[i];
			for (i=0;i<is0;i++) *sspmax++ = ss[i];
			nbuf[mc]=nnpmax;
			*nnpmax++ = *mode;
			for (i=0;i<in0-1;i++) *nnpmax++ = div[i];
			ismax += is0*3;
			inmax += in0;
			def256map++;
		}
	  }
	  else if (n256map<MAXDEFCUMAPP) {
		if (*mode==0) {
			in0=2;			is0=0;
		  }
		  else {
			in0=*mode+1;	is0=in0;
		}
		if (ismax+is0*3<CUBUFMAX && inmax+in0<CUBUFMAX) {
			shbuf[n256map]=sspmax;
			for (i=0;i<is0;i++) *sspmax++ = sh[i];
			for (i=0;i<is0;i++) *sspmax++ = sl[i];
			for (i=0;i<is0;i++) *sspmax++ = ss[i];
			nbuf[n256map]=nnpmax;
			*nnpmax++ = *mode;
			for (i=0;i<in0-1;i++) *nnpmax++ = div[i];
			ismax += is0*3;
			inmax += in0;
			n256map++;			def256map++;
		}
	}
}
