/**************************************************************
 *   gctest.c    Test for Frames called from C program        *
 **************************************************************/
#include <stdio.h>
#include <math.h>

#include "frames.h"
#define N           5
#define IMAX       20
#define JMAX       20

main()
{
    int n0=0,nm=3,i,j,nn,n=N+1,ind=10,ix1=100,ix2=550,iy1=70,iy2=390;
    double x1[2],y1[N+1],y2[N+1];
    double xmin=0.0,xmax=2.0,ymin=-1.5,ymax=1.5;
    double x,y,dx,dy,dd,yy,x0=1,y0=0;
    double f[JMAX+1][IMAX+1];

    fr_ginit();
    fr_gfile("gtest_c",&n0);
//    fr_giffile("gtest_c",&nm,&n0);
    fr_frame2d(&xmin,&xmax,&ymin,&ymax,&ind);
    fr_xyname("X-axis","Y-datas");

    dx = (xmax-xmin)/N;
    for (i=0;i<=N;i++) y2[i] = 0.1*sin(10*dx*i);

    nn=7;          dy = 2.0/nn;
    x1[0] = xmin;   x1[1] = xmax;
    for (i=1;i<=nn;i++) {
        yy=dy*i-1.0;
        dd=20*dy*i;  fr_setcircle(&dd);
        for (j=0;j<=N;j++) y1[j] = y2[j] + yy;
        ind=101;     fr_graph2d(x1,y1,&n,&i,&ind);
        ind=103;     fr_graph2d(x1,y1,&n,&i,&ind);
    }

    fr_gpause();     fr_gclear();

    xmin=-3;     xmax=3;        ymin=-2;   ymax=2;
    dx = (xmax - xmin)/IMAX;    dy = (ymax - ymin)/JMAX;
    for (i=0;i<=IMAX;i++) {
        for (j=0;j<=JMAX;j++) {
            x=dx*i+xmin;    y=dy*j+ymin;
            f[j][i]=exp(-0.5*((x-x0)*(x-x0)+(y-y0)*(y-y0)))
                      -exp(-1.2*((x-1.5)*(x-1.5)+(y-0.5)*(y-0.5)));
        }
    }

    fr_view2d(&ix1,&iy1,&ix2,&iy2);
    x=1;      y=1;    ind=1;    fr_aspect2d(&x,&y,&ind);
    ind=0;    fr_frame2d(&xmin,&xmax,&ymin,&ymax,&ind);
    fr_xyname("Re","Im");
    ix1=IMAX+1;     iy1=JMAX+1;
    n=20;           ind=-2;
    fr_contour(f,&ix1,&iy1,&n,&ind);

    fr_gend();
}
