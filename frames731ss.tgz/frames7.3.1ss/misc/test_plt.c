/*************************************************************************
 *   test_plt.c     Test for Data Restoring Routine from PLT File        *
 *************************************************************************/
#include <stdio.h>
#include "frames_plt.h"

main()
{
	int com,i,j,n;
	frames_data dat;

	if (open_plt_file("graph")) {
		printf("Cannot open plt file !\n");
		exit(1);
	}
	dat.com=0;
	while (1) {
		com=get_frames_command(1);
		if (com==0) exit(0);
		if (com<0) printf("clear stop\n");
		if (com==FRAMES_CONTOUR) {
			printf("command = %04d\n",com);
			get_frames_data(&dat);
			printf("%d %d\n",dat.nx,dat.ny);
			for (j=0,n=0;j<dat.ny;j++) {
				for (i=0;i<dat.nx;i++,n++) printf("%d %d %lf\n",i,j,dat.X[n]);
			}
		  }
		  else if (com==FRAMES_GRAPH2D) {
			get_frames_data(&dat);
			if (dat.md/100==0) {
				printf("command = %04d\n",com);
				printf("%d\n",dat.n);
				for (i=0;i<dat.n;i++) printf("%d %lf %lf\n",i,dat.X[i],dat.Y[i]);
			}
		  }
		  else if (com==FRAMES_GRAPH3D) {
			get_frames_data(&dat);
			if (dat.md/100==0) {
				printf("command = %04d\n",com);
				printf("%d\n",dat.n);
				for (i=0;i<dat.n;i++) printf("%d %lf %lf %lf\n",i,dat.X[i],dat.Y[i],dat.Z[i]);
			}
		  }
		  else if (com==FRAMES_FILEINT) {
			get_frames_data(&dat);
			if (dat.n==1) {
				printf("command = %04d\n",com);
				printf("%d\n",dat.nx);
			}
		  }
		  else if (com==FRAMES_FILEDBLE) {
			get_frames_data(&dat);
			if (dat.n==1) {
				printf("command = %04d\n",com);
				printf("%lf\n",dat.x1);
			}
		  }
		  else get_frames_data(NULL);
	}
    free_frames_data(&dat);
}
