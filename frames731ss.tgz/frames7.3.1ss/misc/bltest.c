/**********************************
 *       F r a m e s  V.6         *
 *     Integer Order Checker      *
 *    Programed by T. Taguchi     *
 **********************************
*/

#include <stdio.h>

main()
{
	union linteg { char c[4];	int l; } b;

	b.l=1;
	if (b.c[0]==1) 
		printf("This is a Little Endian Machine.  Use -DDEC & gsend_little.f.\n");
	  else if (b.c[3]==1) printf("This is a Big Endian Machine.  Use gsend_big.f.\n");
	  else printf("This machine is stupid !!\n");
	printf("b[0]-b[3] = %02d %02d %02d %02d\n",b.c[0],b.c[1],b.c[2],b.c[3]);
	exit(0);
}
