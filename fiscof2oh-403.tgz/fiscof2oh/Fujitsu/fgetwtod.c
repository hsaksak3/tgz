/* To use this fast function, "-lfjcex" option is needed for ld. */
#include <sys/time.h>
#include <stdio.h>
#include <fjcex.h>

double fgetwtod_ ()
{
   static double wtod;
   static double time0;
   static int init=0;
   if ( init == 0 ) {
      init = 1;
      time0 = __gettod()/1000000;
   }
   wtod = __gettod()/1000000 - time0;
   return( wtod );
}

void ffflushall_ ()
{
    fflush( NULL ) ;
}
