!----------------------------------------------------------------------
! check simulation parameters
!
!
! namelist param
!      sdelt  : Omega_pe x Delta_t
!      sgrid  : Lambda_De / mesh_size
!      wncmax : maximum electron density [critical density]
!      wte    : fundamental electron temperature [keV]
!      slramm : fundamental laser wavelength [micron]
!
!    coded by Sakagami,H. (NIFS) 22/07/26
!----------------------------------------------------------------------
      implicit none
      integer :: ifsec
      real*8  :: sdelt, sgrid, wncmax, wte, slramm, &
                 svte, scr, scfl, slram, sdtfs, slmic
      save
!....
      namelist /param/ sdelt, sgrid, wncmax, wte, slramm
!....
      sdelt  = 0.1d0
      sgrid  = 1.0d0
      wncmax = 10.0d0
      wte    = 10.0d0
      slramm = 1.06d0
!..
      read(5,nml=param)
      write(6,nml=param)
!...
      svte = sdelt * sgrid
      scr  = 22.6054d0 / sqrt( wte )
      scfl = scr * svte
      slram  = 2.0d0 * acos(-1.0d0) * sgrid * scr * sqrt( wncmax )
      sdtfs = sdelt / sqrt( wncmax ) * slramm * 0.5308846d0
      ifsec = 1.0d0 / sdtfs
      slmic  = slram / slramm
!....
      if( sdelt .gt. 0.2d0 ) then
         write(6,*) '### sdelt should be <= 0.2'
      end if
      if( sgrid .gt. 1.0d0 .or. sgrid .lt. 0.25d0 ) then
         write(6,*) '### sgrid should be >= 0.25 and <= 1'
      end if
      if( wte .lt. 1.0d0 ) then
         write(6,*) '### wte should be >= 1'
      end if
      write(6,*) '@@@ CFL condition     :', scfl
      if( scfl .gt. 1.0d0 ) then
         write(6,*) '### CFL must be <= 1 in 1D'
      end if
      if( scfl .gt. 1.0d0/sqrt(2.0d0) ) then
         write(6,'(a,f6.4,a)') '### CFL must be <= 1/sqrt(2) (=', 1.0d0/sqrt(2.0d0), ') in 2D'
      end if
      if( scfl .gt. 1.0d0/sqrt(3.0d0) ) then
         write(6,'(a,f6.4,a)') '### CFL must be <= 1/sqrt(3) (=', 1.0d0/sqrt(3.0d0), ') in 3D'
      end if
      write(6,*) '@@@ # mesh per micron :', slmic
      write(6,*) '@@@ time step per fs  :', ifsec
!....
      stop
      end
