!----------------------------------------------------------------------
! write pfeed data as text (2D)
!
! file: FISCOF2_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
!    coded by Sakagami, H. 24/06/20
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: ltx = 500
      real*8, parameter :: alcut = 0.3d0 ! MeV
      integer :: irx, irxp1, imx, imxp1, imxh, inx, inxp1, iyx, iyxx, &
                 ilsrty, i, ir, im, in, iy, it, itx, itn, &
                 il, ilx, id1, id2, id3, id4, icol, icolc, icold, &
                 ilcut, icidl, iet1, iet2, iet3, iet4, isned, ixy, imxhh
      real*8 :: wrang, wintt, wotint, woxp, woyps, woype, wnepm1, &
                wnpnc, wlramm, wlram, wgrid, wlpwr, &
                wnc, weight, woywid, wcoefn, wcoefw, wcoefj, &
                wp, wgam, wth, womg, wdomg, wdomg2, wtot, wnum, &
                wintmn, wintmx, wyps, wype, wtimen, wtimex, &
                wtime(ltx), wtotal(ltx)
      real*8, allocatable :: &
                weng(:), wengb(:), wmue(:), wdisrmny(:,:,:,:), wvc(:)
      character cbuff*80, cdum*3, cident*18, cfile*128, cloc*4, cseq*4, cform*32
!
! physical constant [MKSA], smevj:MeV->J
      real*8, parameter :: sme  = 9.1093897d-31, &
                           sc   = 2.99792458d08, &
                           smec = sme * sc, &
                           smecc= smec * sc, &
                           spi  = 3.1415926535897931d0, &
                           se   = 1.602176462d-19, &
                           seps0= 8.854187817d-12, &
                           smevj= 1.602176462d-13
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF2_TIMEPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 )
      end if
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!....                                                  * read headers *
! ------ start 1/2 -------
! ident character             = i20tmpulse       
! Sn                          =      36      
!  or
! Equal Division              =      32      
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       1       
!  or
! observation position of y   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! # of division for x         =       1       
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
      read(*,1100) cbuff(1:16)
      if( cbuff(14:14) .eq. '-' ) then
         ilx = 1
      else
         read( cbuff(14:16), '(i1,a1,i1)' ) il, cdum(1:1), ilx
      end if
      read(*,1000) cbuff(1:27), cdum, cident(1:16)
      cident(17:18) = ' '
      read(*,1001) cbuff(1:27), cdum, imx
      if( cbuff(1:2) .eq. 'Sn' ) then
         isned = 1
      else
         isned = 2
      end if
      read(*,1001) cbuff(1:27), cdum, inx
      read(*,1001) cbuff(1:27), cdum, irx
      read(*,1003) cbuff(1:27), cdum, wrang
      read(*,1002) cbuff(1:27), cdum, wintt
      read(*,1002) cbuff(1:27), cdum, wotint
      read(*,1002) cbuff(1:27), cdum, woxp
      if( cbuff(25:25) .eq. 'x' ) then
         ixy = 1
      else if( cbuff(25:25) .eq. 'y' ) then
         ixy = 2
      else
         write(0,*) '### ERROR: position is not x or y', cbuff(25:25)
         stop
      end if
      read(*,1002) cbuff(1:27), cdum, woyps
      read(*,1002) cbuff(1:27), cdum, woype
      read(*,1001) cbuff(1:27), cdum, iyx
      read(*,1002) cbuff(1:27), cdum, wnepm1
      read(*,1002) cbuff(1:27), cdum, wnpnc
      read(*,1002) cbuff(1:27), cdum, wlramm
      read(*,1002) cbuff(1:27), cdum, wlram
      read(*,1002) cbuff(1:27), cdum, wgrid
      read(*,1003) cbuff(1:27), cdum, wlpwr
      read(*,1001) cbuff(1:27), cdum, ilsrty
 1100 format(a16)
 1000 format(a27,a3,a16)
 1001 format(a27,a3,i7)
 1002 format(a27,a3,f11.3)
 1003 format(a27,a3,e11.4)
      wnc    = (spi*2.d0*sc/(wlramm*1.d-6))**2 * seps0 * sme / (se**2)
      wintt  = wintt * 1.d-15
      wotint  = wotint * 1.d-15
      weight = wnc * (wlramm*1.d-6/wlram)/wnepm1
      woywid = abs( woype - woyps ) / wlramm * wlram / iyx
      wcoefn = weight / wintt / woywid
      wcoefw = wcoefn*smevj
!     wcoefj = wcoefw*wotint / iyx * 1.0d-12
      wcoefj = wcoefw*wotint * 1.0d-12
      write(0,*) 'ident   = ', cident
      write(0,*) 'irx     = ', irx
      if( isned .eq. 1 ) then
         write(0,*) 'Sn  imx = ', imx
      else
         write(0,*) 'EqD imx = ', imx
      end if
      write(0,*) 'inx     = ', inx
      write(0,*) 'iyx     = ', iyx
      write(0,*) 'nc #/m3 = ', wnc
      write(0,*) 'weigh   = ', weight
      write(0,*) 'delta-p = ', wrang, ' *mec'
      write(0,*) 'integ-t = ', wintt, ' sec'
      if( ixy .eq. 1 ) then
         write(0,*) 'obs. Xp = ', woxp, ' micron'
         write(0,*) 'obs. Yp = ', woyps, '~', woype, ' micron'
      else
         write(0,*) 'obs. Yp = ', woxp, ' micron'
         write(0,*) 'obs. Xp = ', woyps, '~', woype, ' micron'
      end if
! initialize scalar
      irxp1 = irx + 1
      imxp1 = imx + 1
      imxh  = imx / 2
      imxhh = mod( imx, 2 )
      inxp1 = inx + 1
!  allocate array
      allocate ( &
         weng(irx),wvc(irx),wengb(irxp1),wmue(imxp1), &
         wdisrmny(irx,imx,inx,0:iyx) )
!  initialize
      if( isned .eq. 1 ) then
         if( imx .eq. 36 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.93207305669784500D-01
            wmue( 3) = -9.80307489633560200D-01
            wmue( 4) = -9.60150837898254400D-01
            wmue( 5) = -9.32884603738784800D-01
            wmue( 6) = -8.98714393377304100D-01
            wmue( 7) = -8.57888221740722700D-01
            wmue( 8) = -8.10711771249771100D-01
            wmue( 9) = -7.57532685995101900D-01
            wmue(10) = -6.98745220899581900D-01
            wmue(11) = -6.34784460067749000D-01
            wmue(12) = -5.66123992204666100D-01
            wmue(13) = -4.93272125720977800D-01
            wmue(14) = -4.16768252849578900D-01
            wmue(15) = -3.37178781628608700D-01
            wmue(16) = -2.55092948675155600D-01
            wmue(17) = -1.71118497848510700D-01
            wmue(18) = -8.58771540224552200D-02
            wmue(19) =  0.00000000000000000D+00
            wmue(20) =  8.58771540224552200D-02
            wmue(21) =  1.71118497848510700D-01
            wmue(22) =  2.55092948675155600D-01
            wmue(23) =  3.37178781628608700D-01
            wmue(24) =  4.16768252849578900D-01
            wmue(25) =  4.93272125720977800D-01
            wmue(26) =  5.66123992204666100D-01
            wmue(27) =  6.34784460067749000D-01
            wmue(28) =  6.98745220899581900D-01
            wmue(29) =  7.57532685995101900D-01
            wmue(30) =  8.10711860656738300D-01
            wmue(31) =  8.57888072729110700D-01
            wmue(32) =  8.98714631795883200D-01
            wmue(33) =  9.32884305715560900D-01
            wmue(34) =  9.60150927305221600D-01
            wmue(35) =  9.80307668447494500D-01
            wmue(36) =  9.93206858634948700D-01
            wmue(37) =  1.00000000000000000D+00
         else if( imx .eq. 16 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.42144960000000000D-01
            wmue( 3) = -8.68379005000000000D-01
            wmue( 4) = -7.87674650000000000D-01
            wmue( 5) = -6.97571140000000000D-01
            wmue( 6) = -5.93635069999999900D-01
            wmue( 7) = -4.65944585000000000D-01
            wmue( 8) = -2.71738260000000000D-01
            wmue( 9) =  0.00000000000000000D+00
            wmue(10) =  2.71738260000000000D-01
            wmue(11) =  4.65944585000000000D-01
            wmue(12) =  5.93635069999999900D-01
            wmue(13) =  6.97571140000000000D-01
            wmue(14) =  7.87674650000000000D-01
            wmue(15) =  8.68379005000000000D-01
            wmue(16) =  9.42144960000000000D-01
            wmue(17) =  1.00000000000000000D+00
         else
            write(0,*) '### ERROR: imx', imx
            stop
         end if
      else
         wdomg2 = spi / ( (imx-2)*2 + 2 )
         wdomg  = wdomg2 * 2.0d0
         wmue(1) = -1.0d0
         do im = 2, imx
            wmue(im) = cos( spi - wdomg2 - wdomg * (im-2) )
         end do
         wmue(imxp1) = 1.0d0
      end if
! initialize array
      do ir = 1, irx
         wp   = ( dble(ir)-0.5d0 ) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         weng(ir) = smecc * ( wgam - 1.d0 ) / smevj
         wvc(ir) = sqrt( 1.0d0 - 1.0d0 / ( 1.0d0 + wp**2 ) )
      end do
      do ir = 1, irxp1
         wp   = dble(ir-1) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         wengb(ir)= smecc * ( wgam - 1.d0 ) / smevj
      end do
! set low energy cut
      ilcut = 1
      do ir = 1, irx
         if( weng(ir) .gt. alcut ) then
            ilcut = ir
            exit
         end if
      end do
! zero setting
      itx = 0
      do iy = 0, iyx
        do in = 1, inx
          do im = 1, imx
            do ir = 1, irx
              wdisrmny(ir,im,in,iy) = 0.0d0
            end do
          end do
        end do
      end do
!....
      icidl = index( cident//' ', ' ' ) - 1
      if( ilx .gt. 1 ) then
         cident(icidl+1:icidl+1) = '-'
         write( cident(icidl+2:icidl+2), '(i1)' ) il
         icidl = icidl + 2
      end if
!
      cform = '(xxxxxx(e12.4,:,'',''))'
      write( cform(2:7), '(i6)' ) irx*imx*inx
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
    1 continue
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) '### ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
!$$$
      if( itx .gt. ltx ) then
         write(0,*) '### ERROR : itx .gt. ltx', itx, ltx
         stop
      end if
!$$$
      read( cbuff(9:20), '(f12.3)' ) wtime(itx)
      write(0,*) 'itx,time = ', itx, wtime(itx)
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime(itx) - wtime(itx-1) ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime(itx)-wtimen) .ge. 1.0d0 .and. &
             (wtime(itx)-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         go to 1
      end if
!                                             * read until 'total = ' *
    2 continue
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .eq. 'total = ') then
         read( cbuff(9:22), '(f14.3)' ) wtotal(itx)
         write(0,*) 'total = ', wtotal(itx)
!...         
         call rmnynrm( wdisrmny, wmue, irx, imx, inx, iyx, ilcut )
!...
         cseq = '-'
         write( cseq(2:4), '(i3.3)' ) itx-1
         cfile = 'momentum-'//cident(1:icidl)//cseq//'.txt'
         open( 7, file=cfile, form='FORMATTED' )
         write( 7, '(f8.2)' ) wtime(itx)
         write( 7, '(i3,'','',i3,'','',i3)' ) irx, imx, inx
         write( 7, cform ) wdisrmny(:,:,:,0)
         close ( 7 )
!        do iy = 1, iyx
!          do in = 1, inx
!            do im = 1, imx
!              do ir = 1, irx
!                if( wdisrmny(ir,im,in,iy) .gt. 1.0d0 ) &
!                   write(0,*) ir,im,in,wdisrmny(ir,im,in,iy)
!              end do
!            end do
!          end do
!        end do
!... for each domain
         if( iyx .gt. 1 ) then
           if( iyx .le. 9 ) then
             if( ixy .eq. 1 ) then
               cloc = 'y*-'
             else
               cloc = 'x*-'
             end if
           else
             if( ixy .eq. 1 ) then
               cloc = 'y**-'
             else
               cloc = 'x**-'
             end if
           end if
!
           do iy = 1, iyx
             if( iyx .le. 9 ) then
               write( cloc(2:2), '(i1)' ) iy
             else
               write( cloc(2:3), '(i2.2)' ) iy
             end if
             cfile = 'momentum-'//trim(cloc)//cident(1:icidl)//cseq//'.txt'
             open( 7, file=cfile, form='FORMATTED' )
             write( 7, '(f8.2)' ) wtime(itx)
             write( 7, '(i3,'','',i3,'','',i3)' ) irx, imx, inx
             write( 7, cform ) wdisrmny(:,:,:,iy)
             close( 7 )
           end do
         end if
!...
         if( abs(wtime(itx)-wtimex) .le. 1.0d0 .or. &
                (wtime(itx)-wtimex) .gt. 0.0d0 ) then
            write(0,*) 'process was stopped by time param.', wtimex
            go to 90
         end if
         go to 1
      end if
!...
      read( cbuff, '(4i4,f12.3)' ) id1,id2,id3,id4,wnum
!..
      if( isned .eq. 2 ) id2 = imxp1 - id2
!..                           correction distribution with cos(theta) V/C
      wnum = wnum / ( abs(wmue(id2)+wmue(id2+1))/2.0d0 ) / wvc(id1)
! Momentum distribution
      wdisrmny(id1,id2,id3,id4) = wdisrmny(id1,id2,id3,id4) + wnum

      goto 2

   90 continue
!...         
      write(0,*) 'reading data ',itx
!....
      stop
!....
  999 continue
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
      end
!----------------------------------------------------------------------
      subroutine rmnynrm( rdat, rmue, krx, kmx, knx, kyx, klcut )
!
      implicit none
      integer :: krx, kmx, knx, kyx, klcut, iy, in, im, ir
      real*8 :: rdat(krx,kmx,knx,0:kyx), rmue(kmx+1), area
!....
      do iy = 1, kyx
        do in = 1, knx
          do im = 1, kmx
            do ir = klcut, krx
              area = ( ir - 0.5d0 )**2 * &
                     sin( (acos(rmue(im))+acos(rmue(im+1)))/2.0d0 ) * &
                     ( acos(rmue(im))-acos(rmue(im+1)) ) * &
                     acos( -1.0d0 ) * 2.0d0 / knx
              rdat(ir,im,in,iy) = rdat(ir,im,in,iy) / area
              rdat(ir,im,in,0) = rdat(ir,im,in,0) + rdat(ir,im,in,iy)
            end do
            do ir = 1, klcut-1
              rdat(ir,im,in,iy) = rdat(klcut,im,in,iy)
              rdat(ir,im,in,0) = rdat(ir,im,in,0) + rdat(ir,im,in,iy)
            end do
          end do
        end do
      end do
!....
      return
      end
