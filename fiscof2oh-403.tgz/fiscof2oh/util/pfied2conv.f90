!----------------------------------------------------------------------
! pfied data (2D) convert
!
!... Input data
! 
! file: FISCOF2_CONVPARAM_FILE (default: ./conv.param)
!      1 cident   : new identification character
!      2 wyfac    : Y direction expansion factor
!      3 wtfac    : time expansion factor
!      4 mode = 1 : fix beam intensity
!             = 2 : fix beam energy
!
! file: FISCOF2_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
!
!    coded by Sakagami, H. 17/01/26 (NIFS)
!----------------------------------------------------------------------
      implicit none
      integer :: mode, itx, i, iis, id1, id2, id3, id4
      real*4 :: wtimen, wtimex, wtime, wtotal, wnum, wnumt, &
                wval, wyfac, wtfac, wtimeo
      character cbuff*80, cdum*3, cident*16, cfile*128, coident*16
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF2_TIMEPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 )
      end if
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!....                                        * read convert parameter *
      call getenv ( 'FISCOF2_CONVPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=998 )
      else
         open( 7,file='./conv.param',form='FORMATTED',status='OLD',&
               err=997 )
      end if
      read( 7, '(a16)' ) cident
      read( 7, * ) wyfac
      read( 7, * ) wtfac
      read( 7, * ) mode
      close ( 7 )
      if ( mode .le. 0 .or. mode .ge. 3 ) then
        write(0,*) '### ERROR: invalid conv. mode', mode
        stop
      end if
!....                                                  * read headers *
! ------ start ------- 
! ident character             = v2r23        
! Sn                          =      36      
!  or
! Equal Division              =      32      
! # of mesh for omega         =      16      
! # of mesh for momentum      =      50      
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       0.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       3
! # of particle/mesh at nc    =      10.000  
! mass ratio                  =    1836.000
! number of ion species       =       2
! range(1)                    =       5.000
! average Z(1)                =      30.000  
! average weight number(1)    =      60.000  
! density at center(1)        =       0.000
! range(2)                    =       5.000
! average Z(2)                =       1.000
! average weight number(2)    =       1.000
! density at center(2)        =       0.000
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      71.017  
! Debye length/mesh size      =       0.500
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     111     
! laser pulse parameters      =       1.000   1000.000      0.000
      read(*,1001) cbuff
      write(*,1003)
      read(*,1000) cbuff(1:27), cdum, coident
      write(*,1000) cbuff(1:27), cdum, cident
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1002) cbuff(1:27), cdum, wval, cbuff(28:80)
      write(*,1002) cbuff(1:27), cdum, wval*wtfac, trim(cbuff(28:80))
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1002) cbuff(1:27), cdum, wval, cbuff(28:80)
      write(*,1002) cbuff(1:27), cdum, wval*wyfac, trim(cbuff(28:80))
      read(*,1002) cbuff(1:27), cdum, wval, cbuff(28:80)
      write(*,1002) cbuff(1:27), cdum, wval*wyfac, trim(cbuff(28:80))
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1004) cbuff(1:27), cdum, iis
      write(*,1004) cbuff(1:27), cdum, iis
      do i = 1, iis
        read(*,1001) cbuff
        write(*,1001) trim(cbuff)
        read(*,1001) cbuff
        write(*,1001) trim(cbuff)
        read(*,1001) cbuff
        write(*,1001) trim(cbuff)
        read(*,1001) cbuff
        write(*,1001) trim(cbuff)
      end do
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
      read(*,1001) cbuff
      write(*,1001) trim(cbuff)
 1000 format(a27,a3,a16)
 1001 format(a)
 1002 format(a27,a3,f11.3,a)
 1003 format( '------ start - converted -------' )
 1004 format(a27,a3,i7)
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
      itx = 0
    1 continue
      wnumt = 0.0d0
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) 'ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
      read( cbuff(9:20), '(f12.3)' ) wtime
      write(0,*) 'itx,time = ', itx, wtime
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime - wtimeo ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime-wtimen) .ge. 1.0d0 .and. &
             (wtime-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         itx = itx - 1
         go to 1
      end if
!...
      write(*,1100) wtime*wtfac
 1100 format( '--------------------'/' time = ', f12.3 )
!.
      wtimeo = wtime
      i = 1
!...
    2 continue
!                                             * read until 'total = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:6) .eq. 'total(' ) then
        read( cbuff(7:7), '(i1)' ) id1
        if( id1 .ne. i ) then
          write(0,*) '### ERROR: # ion  = ', i, id1
        end if
        read( cbuff(12:23), '(f12.3)' ) wtotal
        write(*,1300) i, wnumt
 1300   format( 'total(',i1,') = ', f12.3 )
!..
        if( i .lt. iis ) then
          i = i + 1
          wnumt = 0.0d0
          go to 2
        end if
!..
        if( abs(wtime-wtimex) .le. 1.0d0 .or. &
          (wtime-wtimex) .gt. 0.0d0 ) then
          write(0,*) 'process was stopped by time param.', wtimex
          go to 90
        end if
!
        go to 1
      end if
!
      read( cbuff, 1200 ) id1,id2,id3,id4,wnum
 1200 format( 4i4, f12.3 )
!                                             * convert  wnum *
      if ( mode .eq. 1 ) then 
        wnum = wnum * wyfac
      end if
      write(*,1200) id1,id2,id3,id4,wnum
      wnumt = wnumt + wnum
!...
      go to 2

   90 continue  
      write(*,1005)
 1005 format( '------ end - converted -------' )

      write(0,*) 'identification character: ', &
                 trim(coident), ' --> ', trim(cident)
      write(0,*) 'conv. mode', mode
      write(0,*) 'Y direction expansion factor', wyfac
      write(0,*) 'time expansion factor', wtfac
      stop
!...
  999 continue  
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
!..
  998 continue  
      write(0,*) '### ERROR: conv param file not found. file="', &
         trim(cfile), '"'
      stop
!..
  997 continue
      write(0,*) '### ERROR: default conv param file not found.'
      stop
!....
      end
