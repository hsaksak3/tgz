c  bug test for b2pep and b2pip
c
c    generally, weps is -15 + log(mesh)
c
c    <remarks>
c     real*4:yu-ko-keta = about  7 (IEEE)
c     real*8:yu-ko-keta = about 16 (IEEE)
c
      real*8 x,xx,xxx,xmesh,weps
      weps  = 1.0d-10
c1023   weps  = 1.0d-12
c65535  weps  = 1.0d-11
      ixmesh = 524287
      ixmesh =1048575
c     ixmesh = 1023
c     ixmesh = 65535
      x = 0.9999999999999999d0
c     x = 0.9999999
cout  x = 0.99999999
      ix = x
      xx = x + ixmesh
      xxx = x + ixmesh -weps
      ixx = xx
      ixxx = xxx
      write(*,*) x, ix, xx, ixx
      write(*,*) x, ix, xxx, ixxx
      write(*,1000) x, ix, xx, ixx
      write(*,1000) x, ix, xxx, ixxx
 1000 format(f20.16, i10, f25.16, i10)
      stop
      end
