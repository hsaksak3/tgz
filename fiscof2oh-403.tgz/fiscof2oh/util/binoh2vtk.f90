!----------------------------------------------------------------------
! convert binary files of OhHelp version to single VTK file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   cvtfntp: file name template for VTK file
!          : default is '&K-&I-%%.vtk'
!          : &I is replaced by identification character in binary file
!          : &K is replaced by header in binary file
!          : %% is replaced by file sequence number, not unit#
!   ctype  : file data type ASCII or BINARY (default)
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   iseq   : initial sequence number of VTK file (default is 0)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!
!  VTK binary data must be "BIG_ENDIAN", and convert='BIG_ENDIAN' in 
! OPEN statement is used in this program, assuming "gfortran".
!  But it's not standard, and you should modify it to fit your 
! environments. You can use environment variable or compiler option,
! such as "setenv GFORTRAN_CONVERT_UNIT big_endian:7" or 
! "-fconvert=big-endian" for gfortran.
! note: take care of "_" or "-" between "big" and "endian".
!
!----------------------------------------------------------------------
      use parameter, only:lionspx
      implicit none
      integer, parameter :: iun0 = 9
      integer :: i, il, ico, idn, iunit, ixl, iyl, ixyl, intt, &
                 ixps, iyps, ixpe, iype, intx, inty, &
                 irank, ixn, iyn, icnt, ion, iseq
      real*4, allocatable :: wwrk(:,:,:,:)
      real*8, allocatable :: awrk(:,:,:,:)
      real*8  :: wxps, wyps, wxpe, wype, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aundef=-1.0d20, aundeff=-1.1d20, &
                 aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, cform*32, &
                 cbifntp*64, cvtfntp*64, cfile*128, ctype*6, cbuff*80, &
                 ctitle(lionspx)*32
!
      integer :: iun, ir, isize, ixas, ixae, ixal, iyas, iyae, iyal
      integer :: idivx, idivy, ixals, iyals, i0s, ipixel
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:)
      real*8  :: wx0s, wy0s
      real*8, allocatable :: gwrk(:,:,:,:)
      character cidents*16
!.
      namelist /param/ ckind, cbifntp, cidentb, cvtfntp, ctype, &
               wts, wte, intt, iseq, wxps, wxpe, wyps, wype, intx, inty
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cvtfntp = '&K-&I-%%.vtk'
      ctype   = 'BINARY'
      wts     = 0.0
      wte     = 9999.0
      intt    = 1
      iseq    = 0
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      intx    = 1
      inty    = 1
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'fde' )
         iun = 20
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Density'
      case( 'fdi' )
         iun = 21
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Density'
      case( 'fea' )
         iun = 22
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Electric_Field'
      case( 'fer' )
         iun = 23
         ico = 3
         idn = 1
         ctitle(1) = 'Electric_Field'
      case( 'fba' )
         iun = 24
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Magnetic_Field'
      case( 'fbr' )
         iun = 25
         ico = 3
         idn = 1
         ctitle(1) = 'Magnetic_Field'
      case( 'fje' )
         iun = 28
         ico = 3
         idn = 3
         ctitle(1) = 'Electron_Current'
         ctitle(2) = 'Electron_Current(hot)'
         ctitle(3) = 'Electron_Current(cold)'
      case( 'fji' )
         iun = 29
         ico = 3
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Current'
      case( 'fjt' )
         iun = 42
         ico = 3
         idn = 1
         ctitle(1) = 'Total_Current'
      case( 'fede' )
         iun = 27
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Energy_Density'
      case( 'fedi' )
         iun = 36
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Energy_Density'
      case( 'fdc' )
         iun = 41
         ico = 1
         idn = 1
         ctitle(1) = 'Charge_Density'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!..
      i0s = 0
      ipixel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, ckind, cfile ) 
      end if 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      if( ion .eq. 0 ) then
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0, &
                     irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0, &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
      else
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0, &
                     idn, (aionam(i),aionaz(i),i=1,idn), &
                     irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0, &
                    idn, (aionam(i),aionaz(i),i=1,idn), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
      end if
!..
      if( ixyl .ne. -1 ) then
         if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) ) then
           write(0,*) '### ERROR: data size mismatch', &
                      ixas,ixae,iyas,iyae 
           stop
         end if
      end if
!..
      if( ir-1 .eq. 0 ) then
!.                              * check instantaneous flag for fer/fbr *
         if( chead(1:3) .eq. 'feR' ) then
            idn = 2
            ctitle(2) = 'Electric_Field(inst.)'
         else if( chead(1:3) .eq. 'fbR' ) then
            idn = 2
            ctitle(2) = 'Magnetic_Field(inst.)'
         end if
!
         isize = idivx * idivy
         ixals = ixal
         iyals = iyal
         cidents = cident
         allocate( ixass(isize), ixaes(isize), ixans(isize), &
                   iyass(isize), iyaes(isize), iyans(isize) )
         allocate( gwrk(ico,ixal,iyal,idn) )
!.
      else if( ir .le. isize ) then
         if( cident .ne. cidents ) then
            write(0,*) '### ERROR: cident mismatch ', cident, cidents
            stop
         end if
         if( ixal.ne.ixals .or. iyal.ne.iyals ) then
            write(0,*) '### ERROR: total size mismatch', &
                       ixal,ixals,iyal,iyals
            stop
         end if
      end if
!..
      if( i0s .eq. 0 .and. ixyl .ne. -1 ) then
         wx0s = wx0
         wy0s = wy0
         i0s = 1
      end if
!..
      ixass(ir) = ixas
      ixaes(ir) = ixae
      ixans(ir) = ixae - ixas + 1
      iyass(ir) = iyas
      iyaes(ir) = iyae
      iyans(ir) = iyae - iyas + 1
!
      ipixel = ipixel + ixans(ir)*iyans(ir)
!..
      if( ir .eq. isize ) exit
!..
      end do
!...
      if( ipixel .ne. ixal*iyal ) then
         write(0,*) '### ERROR: total #pixel mismatch', &
                       ipixel,ixal,iyal
         stop
      end if
!...
      if( wxps .le. aundef ) then
         ixps = 1
      else
         ixps = ( wxps + wx0s ) / wxmic
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: invalid xps', wxps, ixps
            write(0,*) '###        : ixps is assumed as 1'
            ixps = 1
         end if
      end if
      if( wxpe .le. aundef ) then
         ixpe = ixal
      else
         ixpe = ( wxpe + wx0s ) / wxmic
         if( ixpe .gt. ixal ) then
            write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
            write(0,*) '###        : ixpe is assumed as', ixal
            ixpe = ixal
         end if
      end if
      if( ixps .gt. ixpe ) then
         write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
         stop
      end if
      if( wyps .le. aundef ) then
         iyps = 1
      else
         iyps = ( wyps + wy0s ) / wymic
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: invalid yps', wyps, iyps
            write(0,*) '###        : iyps is assumed as 1'
            iyps = 1
         end if
      end if
      if( wype .le. aundef ) then
         iype = iyal
      else
         iype = ( wype + wy0s ) / wymic
         if( iype .gt. iyal ) then
            write(0,*) '### WARNING: invalid ype', wype, iype
            write(0,*) '###        : iype is assumed as', iyal
            iype = iyal
         end if
      end if
      if( iyps .gt. iype ) then
         write(0,*) '### ERROR: yps gt ype', wyps, wype
         stop
      end if
!.
      ixn  = ( ixpe - ixps ) / intx + 1
      if( ixn .lt. 2 ) then
         write(0,*) '### ERROR: invalid x interval', &
	               ixps,ixpe,intx
         stop
      end if
      iyn  = ( iype - iyps ) / inty + 1
      if( iyn .lt. 2 ) then
         write(0,*) '### ERROR: invalid y interval', &
                       iyps,iype,inty
         stop
      end if
!..
      wxps = ( ixps-1 ) * wxmic - wx0s
      wyps = ( iyps-1 ) * wymic - wy0s
      wxpe = wxps + wxmic * intx * ( ixn - 1 )
      wype = wyps + wymic * inty * ( iyn - 1 )
      write(*,*) '----- ixps, ixpe, wxps, wxpe = ', ixps,ixpe,wxps,wxpe
      write(*,*) '----- iyps, iype, wyps, wype = ', iyps,iype,wyps,wype
      write(*,*) '----- ixn, iyn = ', ixn, iyn
      write(*,*) '----- header: ', chead, ', ident: ', cident
!..
      if( ion .eq. 1 ) then
         do i = 2, idn
            ctitle(i) = ctitle(1)
         end do
         il = len_trim( ctitle(1) )
         do i = 1, idn
            call o2ionlabel( i, aionam(i), aionaz(i), ctitle(i)(il+1:) )
         end do
      end if
!....
      if( ctype(1:1) .ne. 'A' .and. ctype(1:1) .ne. 'a' ) then
         allocate( wwrk(ico,ixn,iyn,idn) )
      end if
      icnt = iseq
!....
    1 continue
!...
         do ir = 1, isize
!...
         iunit = iun0 + ir
!...
         if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 ) then
            allocate( awrk(ico,ixans(ir),iyans(ir),idn) )
            read(iunit, end=99) wtime, awrk
            gwrk(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) = &
                                                         awrk(:,:,:,:)
            deallocate( awrk )
         end if
!.
         end do
!...
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- seq#, time = ', icnt, wtime
!.
         call fntpcnv ( cvtfntp, -1, icnt, cident, chead, cfile )
!.
         if( ctype(1:1) .eq. 'A' .or. ctype(1:1) .eq. 'a' ) then
            open(7, file=cfile, form='FORMATTED' )
            write(7,'(a)') '# vtk DataFile Version 3.0'
            write(cbuff,'(f8.2)') wtime 
            write(7,'(a)') trim(cident)//',time='//trim(adjustl(cbuff))
            write(7,'(a)') 'ASCII' 
            write(7,'(a)') 'DATASET STRUCTURED_POINTS'
            write(7,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, 1
            write(7,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, 0.0
            write(7,'(a,1x,3e12.4)') 'SPACING', &
                                       intx*wxmic,inty*wymic,0.0
            write(7,'(a,1x,i9)') 'POINT_DATA', ixn*iyn
            do i = 1, idn
               if( ico .eq. 1 ) then
                  write(7,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                  write(7,'(a)') 'LOOKUP_TABLE default'
               else
                  write(7,'(a,1x,a,1x,a)') 'VECTORS', &
                                                trim(ctitle(i)), 'float'
               end if
               write(7, '(6e12.4)' ) &
                  gwrk(:,ixps:ixpe:intx,iyps:iype:inty,i)
            end do
            close(7)
         else
            open(7, file=cfile, access='STREAM', form='UNFORMATTED', &
                    convert='BIG_ENDIAN' )
            write(cbuff,'(a)') '# vtk DataFile Version 3.0'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(f8.2)') wtime 
            write(7) &
             trim(cident)//',time='//trim(adjustl(cbuff))//new_line('A')
            write(cbuff,'(a)') 'BINARY' 
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a)') 'DATASET STRUCTURED_POINTS'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, 1
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, 0.0
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'SPACING', &
                                       intx*wxmic,inty*wymic,0.0
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,i9)') 'POINT_DATA', ixn*iyn
            write(7) trim(cbuff)//new_line('A')
            wwrk(:,:,:,:) = &
               gwrk(:,ixps:ixpe:intx,iyps:iype:inty,:)
            do i = 1, idn
               if( ico .eq. 1 ) then
                  write(cbuff,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                  write(7) trim(cbuff)//new_line('A')
                  write(cbuff,'(a)') 'LOOKUP_TABLE default'
                  write(7) trim(cbuff)//new_line('A')
               else
                  write(cbuff,'(a,1x,a,1x,a)') 'VECTORS', &
                                                trim(ctitle(i)), 'float'
                  write(7) trim(cbuff)//new_line('A')
               end if
               write(7) wwrk(:,:,:,i)
            end do
            close(7)
         end if
!.
         icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
