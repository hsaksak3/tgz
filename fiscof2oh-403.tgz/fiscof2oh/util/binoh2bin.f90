!----------------------------------------------------------------------
! convert binary files of OhHelp version to single binary file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof2 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: lomax = 9, iun0 = 9
      integer :: i, ii, i3, i4, i5, iunit, ixl, iyl, ixyl, ionl, &
                 irank
      integer :: idat2(2,lomax)
      real*8, allocatable :: work1(:),work2(:,:),work22(:,:), &
                           work3(:,:,:),work4(:,:,:,:),work5(:,:,:,:,:)
      real*8  :: wxmic, wx0, wymic, wy0, wts, wte, wtime, wteps=0.05
      real*8  :: wmax,wdat2(6,lomax),wdat22(lomax,lomax),wdat23(2,lomax)
      real*8  :: work
      character ckind*5, chead*4, cident*16, cidentb*16, cidents*16
      character cbifntp*64, cfile*128
!
      integer :: iun, ir, isize, ixas, ixae, ixal, iyas, iyae, iyal
      integer :: idivx, idivy, ixals, iyals, i0s, ipixel
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:)
      real*8  :: wx0s, wy0s
      real*8, allocatable :: gork2(:,:), gork3(:,:,:), gork4(:,:,:,:), &
                             gork5(:,:,:,:,:), gampx(:)
!.
      namelist /param/ ckind, cbifntp, cidentb, wts, wte
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      wts     = 0.0d0
      wte     = 9999.0d0
!..
      read(*,param)
      write(*,param)
!....
      select case( ckind )
      case( 'fde' )
         iun = 20
      case( 'fdi' )
         iun = 21
      case( 'fea' )
         iun = 22
      case( 'fer' )
         iun = 23
      case( 'fba' )
         iun = 24
      case( 'fbr' )
         iun = 25
      case( 'pem' )
         iun = 26
      case( 'fede' )
         iun = 27
      case( 'fje' )
         iun = 28
      case( 'fji' )
         iun = 29
      case( 'pim' )
         iun = 30
      case( 'fte' )
         iun = 33
      case( 'pee' )
         iun = 34
      case( 'pie' )
         iun = 35
      case( 'fedi' )
         iun = 36
      case( 'peph' )
         iun = 37
      case( 'piph' )
         iun = 38
      case( 'fdc' )
         iun = 41
      case( 'fjt' )
         iun = 42
      case default
         write( 0, * ) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!
      i0s = 0
      ipixel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cbifntp,ir-1,iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp,ir-1,iun, cidentb, ckind, cfile )
      end if 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      if( ckind(1:1) .eq. 'p' ) then
        select case( ckind )
        case( 'pem' )
          read( iunit ) chead, cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
!
        case( 'pee' )
          read( iunit ) chead, cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
!
        case( 'peph' )
          read( iunit ) chead, cident, ixl, iyl, ixyl, &
                                      ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, &
                                      ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                       irank,idivx,idivy
!
        case( 'pim' )
          read( iunit ) chead, cident, ixl, iyl, ionl, &
            ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
            ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl), &
            irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
            ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
            ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl), &
            irank,idivx,idivy
!
        case( 'pie' )
          read( iunit ) chead, cident, ixl, iyl, ionl, &
           ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
           ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl), &
           irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
           ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
           ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl), &
           irank,idivx,idivy
!
        case( 'piph' )
          read( iunit ) chead, cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                    irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                    irank,idivx,idivy
        end select
        if( ir-1 .eq. 0 ) then
          isize = idivx * idivy
          cidents = cident
          select case( ckind )
          case( 'pem' )
            allocate( work3(ixl,3,iyl), work4(ixl,ixl,3,iyl), &
                      gork3(ixl,3,iyl), gork4(ixl,ixl,3,iyl) )
          case( 'pee' )
            allocate( work2(ixl,iyl), gork2(ixl,iyl) )
          case( 'peph' )
            allocate( work3(ixl,iyl,ixyl), gork3(ixl,iyl,ixyl) )
          case( 'pim' )
             allocate( & 
                work4(ixl,3,iyl,ionl), work5(ixl,ixl,3,iyl,ionl), &
                gork4(ixl,3,iyl,ionl), gork5(ixl,ixl,3,iyl,ionl) )
          case( 'pie' )
            allocate( work3(ixl,iyl,ionl), gork3(ixl,iyl,ionl) )
          case( 'piph' )
            allocate(work4(ixl,iyl,ixyl,ionl),gork4(ixl,iyl,ixyl,ionl))
          end select
        else if( ir .le. isize ) then
          if( cident .ne. cidents ) then
            write(0,*) '### ERROR: cident mismatch',cidents, cident
            stop
          end if
        end if
!
      else 
!.
         if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
             ckind .eq. 'fedi' ) then
            read( iunit ) chead,cident,ixyl,ixl,iyl, &
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,&
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         else
            read( iunit ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0,&
               irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0,&
               irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         end if
!
         if( ixyl .ne. -1 ) then
            if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) ) then
              write(0,*) '### ERROR: data size mismatch', &
                         ixas,ixae,iyas,iyae
              stop
            end if
         end if
!.
         if( ir-1 .eq. 0 ) then
            isize = idivx * idivy
            ixals = ixal
            iyals = iyal
            cidents = cident
            allocate( ixass(isize), ixaes(isize), ixans(isize), &
                      iyass(isize), iyaes(isize), iyans(isize) )
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fedi' ) then
               allocate( gork3(ixal,iyal,ionl) )
            else if( ckind .eq. 'fji' ) then
               allocate( gork4(3,ixal,iyal,ionl), work1(ionl), &
                         gampx(ionl) )
            else if( ckind .eq. 'fje' ) then
               allocate( gork4(3,ixal,iyal,3), gampx(1) )
            else if( ckind .eq. 'fjt' ) then
               allocate( gork3(3,ixal,iyal), gampx(1) )
            else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' ) then
!                               * check instantaneous flag for fer/fbr *
               if( chead(3:3) .eq. 'R' ) then
                  allocate( gork4(3,ixal,iyal,2) )
               else
                  allocate( gork3(3,ixal,iyal) )
               end if
            else if( ckind .eq. 'fte' ) then
               allocate( gork3(ixal,iyal,2) )
!                                                        * other cases *
            else
               allocate( gork2(ixal,iyal) )
            end if
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch',cidents, cident
               stop
            end if
            if( ixal.ne.ixals .or. iyal.ne.iyals ) then
               write(0,*) '### ERROR: total size mismatch', &
                          ixal,ixals,iyal,iyals
               stop
            end if
         end if
!..
         if( i0s .eq. 0 .and. ixyl .ne. -1 ) then
            wx0s = wx0
            wy0s = wy0
            i0s = 1
         end if
!..
         ixass(ir) = ixas
         ixaes(ir) = ixae
         ixans(ir) = ixae - ixas + 1
         iyass(ir) = iyas
         iyaes(ir) = iyae
         iyans(ir) = iyae - iyas + 1
!
         ipixel = ipixel + ixans(ir)*iyans(ir)
!..
      end if
!..
      if( ir .eq. isize ) exit
!..
      end do
!...
      if( ckind(1:1) .eq. 'f' ) then
         if( ipixel .ne. ixal*iyal ) then
            write(0,*) '### ERROR: total #pixel mismatch', &
                          ipixel,ixal,iyal
            stop
         end if
      end if
!....
      write( *, * ) '----- header: ', chead, ', ident: ', cident
!..
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cbifntp, -1, iun, cident, &
                                        'fE'//ckind(4:4), cfile )
      else
         call fntpcnv ( cbifntp, -1, iun, cident, ckind, cfile )
      end if
      open( iun0, file=cfile, form='UNFORMATTED' )
      chead(4:4) = '2'
      if( ckind .eq. 'pem' ) then
         write( iun0 ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
      else if( ckind .eq. 'pee' ) then
         write( iun0 ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
      else if( ckind .eq. 'peph' ) then
         write( iun0 ) chead, cident, ixl, iyl, ixyl, & 
                                        ((wdat2(i,ii),i=1,6),ii=1,ixyl)
      else if( ckind .eq. 'pim' ) then
         write( iun0 ) chead, cident, ixl, iyl, ionl, & 
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl)
      else if( ckind .eq. 'pie' ) then
         write( iun0 ) chead, cident, ixl, iyl, ionl, & 
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
      else if( ckind .eq. 'piph' ) then
         write( iun0 ) chead, cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl)
      else
         if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
             ckind .eq. 'fedi' ) then
            write( iun0 ) chead,cident,ixal*iyal,ixal,iyal, &
                          wxmic,wx0s,wymic,wy0s, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl)
         else
            write( iun0 ) chead,cident,ixal*iyal,ixal,iyal, &
                          wxmic,wx0s,wymic,wy0s
         end if
      end if
!.......................................................................
    1 continue
!...
         do ir = 1, isize
!..
         iunit = iun0 + ir
!.
         select case( ckind )
         case( 'pem' )
            read( iunit, end=99 ) wtime, &
                        (((work3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl), &
             ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
               gork4(:,:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
!
         case( 'pee' )
            read( iunit, end=99 ) wtime, work2
            if( ir .eq. 1 ) then
               gork2(:,:) = 0.0d0
            end if
            gork2(:,:) = gork2(:,:) + work2(:,:)
!
         case( 'peph' )
            read( iunit, end=99 ) wtime, work3
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
!
         case( 'pim' )
            read( iunit, end=99 ) wtime, &
                (( ((work4(i,i3,i4,i5),i=1,ixl),i3=1,3), &
                  (((work5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
            if( ir .eq. 1 ) then
               gork4(:,:,:,:) = 0.0d0
               gork5(:,:,:,:,:) = 0.0d0
            end if
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
            gork5(:,:,:,:,:) = gork5(:,:,:,:,:) + work5(:,:,:,:,:)
!
         case( 'pie' )
            read( iunit, end=99 ) wtime, work3
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
!
         case( 'piph' )
            read( iunit, end=99 ) wtime, work4
            if( ir .eq. 1 ) then
               gork4(:,:,:,:) = 0.0d0
            end if
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
!
         case default 
            if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 ) then
               if( ckind .eq. 'fdi' .or. ckind .eq. 'fedi' ) then
                  allocate( work3(ixans(ir),iyans(ir),ionl) )
                  read( iunit, end=99 ) wtime, work3
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) = &
                                                          work3(:,:,:)
                  deallocate( work3 )
               else if( ckind .eq. 'fji' ) then
                  allocate( work4(3,ixans(ir),iyans(ir),ionl) )
                  read( iunit, end=99 ) wtime, work4, work1
                  gork4(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) &
                     = work4(:,:,:,:)
                  deallocate( work4 )
                  if( ir .eq. 1 ) gampx(:) = 0.0d0 
                  do i4 = 1, ionl 
                    gampx(i4) = max( gampx(i4), work1(i4) )
                  end do
               else if( ckind .eq. 'fje' ) then
                  allocate( work4(3,ixans(ir),iyans(ir),3) )
                  read( iunit, end=99 ) wtime, work4, work
                  gork4(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) &
                     = work4(:,:,:,:)
                  deallocate( work4 )
                  if( ir .eq. 1 ) gampx(1) = 0.0d0 
                  gampx(1) = max( gampx(1), work )
               else if( ckind .eq. 'fjt' ) then
                  allocate( work3(3,ixans(ir),iyans(ir)) )
                  read( iunit, end=99 ) wtime, work3, work
                  gork3(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir)) = &
                                                          work3(:,:,:)
                  deallocate( work3 )
                  if( ir .eq. 1 ) gampx(1) = 0.0d0 
                  gampx(1) = max( gampx(1), work )
               else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' ) then
                  if( chead(3:3) .eq. 'R' ) then
                     allocate( work4(3,ixans(ir),iyans(ir),2) )
                     read( iunit, end=99 ) wtime, work4
                     gork4(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:)&
                        = work4(:,:,:,:)
                     deallocate( work4 )
                  else
                     allocate( work3(3,ixans(ir),iyans(ir)) )
                     read( iunit, end=99 ) wtime, work3
                  gork3(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir)) = &
                                                          work3(:,:,:)
                     deallocate( work3 )
                  end if
               else if( ckind .eq. 'fte' ) then
                  allocate( work3(ixans(ir),iyans(ir),2) )
                  read( iunit, end=99 ) wtime, work3
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) = &
                                                          work3(:,:,:)
                  deallocate( work3 )
!                                                       * other cases *
               else
                  allocate( work2(ixans(ir),iyans(ir)) )
                  read( iunit, end=99 ) wtime, work2
                  gork2(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir)) = &
                                                          work2(:,:)
                  deallocate( work2 )
               end if
            end if
         end select
!..
         end do
!...
         if( wtime .lt. wts-wteps ) then
	    go to 1
         end if
!...
         if( wtime .gt. wte+wteps ) then
            write( *, * ) '----- end at ', wtime
            go to 2
         end if
!...
         write( *, * ) '----- time = ', wtime
!...
         if( ckind .eq. 'pem' ) then
            write( iun0 ) wtime, &
                        (((gork3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl), &
             ((((gork4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
!
         else if( ckind .eq. 'pee' ) then
            write( iun0 ) wtime, gork2
!
         else if( ckind .eq. 'peph' ) then
            write( iun0 ) wtime, gork3
!
         else if( ckind .eq. 'pim' ) then
            write( iun0 ) wtime, &
                (( ((gork4(i,i3,i4,i5),i=1,ixl),i3=1,3), &
                  (((gork5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
!
         else if( ckind .eq. 'pie' ) then
            write( iun0 ) wtime, gork3
!
         else if( ckind .eq. 'piph' ) then
            write( iun0 ) wtime, gork4
!
         else
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fedi' ) then
               write( iun0 ) wtime, gork3
            else if( ckind .eq. 'fji' ) then
               write( iun0 ) wtime, gork4, gampx
            else if( ckind .eq. 'fje' ) then
               write( iun0 ) wtime, gork4, gampx(1)
            else if( ckind .eq. 'fjt' ) then
               write( iun0 ) wtime, gork3, gampx(1)
            else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                     ckind .eq. 'fte' ) then
               if( chead(3:3) .eq. 'R' ) then
                  write( iun0 ) wtime, gork4
               else
                  write( iun0 ) wtime, gork3
               end if
!                                                       * other cases *
            else
                  write( iun0 ) wtime, gork2
            end if
         end if
!...
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
