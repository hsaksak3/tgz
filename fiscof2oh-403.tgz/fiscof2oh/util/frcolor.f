      implicit real*8 (a-h,o-z)
      parameter (imax=20,jmax=20)
      real*8 f(0:imax,0:jmax)
      real*8 sh(4),sl(4),ss(4)
      integer ndiv(3)
      character*16 char


      xmin = -3.d0
      xmax =  3.d0
      ymin = -2.d0
      ymax =  2.d0
      dx   = (xmax - xmin)/imax
      dy   = (ymax - ymin)/jmax

      x0 = 1.0d0
      y0 = 0.0d0

      do j = 0, jmax
         do i = 0, imax
            x=dx*i+xmin
            y=dy*j+ymin
            f(i,j)=exp(-0.5*((x-x0)**2+(y-y0)**2))
     +              -exp(-1.2*((x-1.5)**2+(y-0.5)**2))
         enddo
      enddo

      call fr_ginit

      sh(1) = 0.0d0
      sl(1) = 0.02d0
      ss(1) = 1.0d0
      ndiv(1) = 40
      sh(2) = 0.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 50
      sh(3) = 60.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 40
      sh(4) = 60.0d0
      sl(4) = 0.98d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )

      sh(1) = 180.0d0
      sl(1) = 0.9d0
      ss(1) = 1.0d0
      ndiv(1) = 60
      sh(2) = 240.0d0
      sl(2) = 0.1d0
      ss(2) = 1.0d0
      ndiv(2) = 10
      sh(3) = 360.0d0
      sl(3) = 0.1d0
      ss(3) = 1.0d0
      ndiv(3) = 60
      sh(4) = 390.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )

      sh(1) = 240.0d0
      sl(1) = 0.25d0
      ss(1) = 1.0d0
      ndiv(1) = 20
      sh(2) = 240.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 90
      sh(3) = 0.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 20
      sh(4) = 0.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )

      sh(1) = 240.0d0
      sl(1) = 0.2d0
      ss(1) = 1.0d0
      ndiv(1) = 50
      sh(2) = 240.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 30
      sh(3) = 0.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 50
      sh(4) = 0.0d0
      sl(4) = 0.2d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )

      call fr_opencanvas ( 1, 'frcolor', 10 )

      do i = 0, 4
         call fr_gclear
         call fr_aspect2d(1.0d0,1.d0,0)
         call fr_frame2d(xmin,xmax,ymin,ymax,3)
	 call fr_hlsrecall ( i )
         call fr_contour(f,imax+1,jmax+1,1,-2)
         call fr_xyname('re','im')
         call fr_colorbar(210,470,200,15,21)
	 char = 'color num = #'
	 write( char(13:13), '(i1)' ) i
	 call fr_fpchars ( 150.0d0, 15.0d0, char, 7, 1, -1, 0, 0 )
      end do

      call fr_gend

      stop
      end
