!----------------------------------------------------------------------
! plot binary files of OhHelp version with Frames.
!
! namelist param
!   ckind  : observation kind
!   ioflag : observation flag
!   cbifntp: file name template for binary file
!   cidentb: identification character for cbifntp
!   cfrfntp: file name template for Frames plt file
!   wts    : start time
!   wte    : end time
!   wxps   : start x position
!   wyps   : start y position
!   wxpe   : end x position
!   wype   : end y position
!   intx   : data interval for x
!   inty   : data interval for y
!   iminlog: minimum log data exponent (default is 5)
!   wminlog: minimum data for log (default is 1.0d-12)
!
      implicit none
      integer, parameter :: lomax = 9, iun0 = 9
      integer :: i, ii, i3, i4, i5, in, iunit, ixl, iyl, ixyl, ionl, &
                 ixps, iyps, ixpe, iype, intx, inty, ixn, iyn, &
                 irank, ioflag, ifrm, ilog, icrsx, icrsy, icol, iminlog
      integer :: idat2(2,lomax)
      real*8, allocatable :: work1(:),work2(:,:),work22(:,:), &
                           work3(:,:,:),work4(:,:,:,:),work5(:,:,:,:,:)
      real*8  :: wxps, wyps, wxpe, wype, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wminlog, wteps=0.05
      real*8  :: wmax,wdat2(6,lomax),wdat22(lomax,lomax),wdat23(2,lomax)
      real*8  :: wxm, wxx, wym, wyx, work
      character ckind*5, chead*4, cident*16, cidentb*16, cform*32
      character cbifntp*64, cfrfntp*64, cfile*128, clabel*20, crange*32
!
      integer :: iun, ir, isize, ixas, ixae, ixal, iyas, iyae, iyal
      integer :: idivx, idivy, ixals, iyals, i0s, ipixel
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:)
      real*8  :: wx0s, wy0s
      real*8, allocatable :: gork2(:,:), gork3(:,:,:), gork4(:,:,:,:), &
                             gork5(:,:,:,:,:), gampx(:)
      character cidents*16
!.
      namelist /param/ ckind, ioflag, cbifntp, cidentb, cfrfntp, &
                       wts, wte, wxps, wyps, wxpe, wype, intx, inty, &
                       iminlog, wminlog
!....
      ckind   = ' '
      ioflag  = 5
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cfrfntp = '&K-&I-###'
      wts     = 0.0
      wte     = 999999.0
      wxps    = -1000.0
      wyps    = -1000.0
      wxpe    = 1000.0
      wype    = 1000.0
      intx    = 1
      inty    = 1
      iminlog = 5
      wminlog = 1.0d-12
!..
      read(*,param)
      write(*,param)
!....
      select case( ckind )
      case( 'fde' )
         iun = 20
      case( 'fdi' )
         iun = 21
      case( 'fea' )
         iun = 22
      case( 'fer' )
         iun = 23
      case( 'fba' )
         iun = 24
      case( 'fbr' )
         iun = 25
      case( 'pem' )
         iun = 26
      case( 'fede' )
         iun = 27
      case( 'fje' )
         iun = 28
      case( 'fji' )
         iun = 29
      case( 'pim' )
         iun = 30
      case( 'fte' )
         iun = 33
      case( 'pee' )
         iun = 34
      case( 'pie' )
         iun = 35
      case( 'fedi' )
         iun = 36
      case( 'peph' )
         iun = 37
      case( 'piph' )
         iun = 38
      case( 'fdc' )
         iun = 41
      case( 'fjt' )
         iun = 42
      case default
         write( 0, * ) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
      ifrm = mod( ioflag, 10 )
      ilog = mod( ioflag/10, 10 )
      icrsx = mod( ioflag/100, 100 )
      icrsy = ioflag/10000
!
      i0s = 0
      ipixel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cbifntp,ir-1,iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp,ir-1,iun, cidentb, ckind, cfile )
      end if 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      if( ckind(1:1) .eq. 'p' ) then
        select case( ckind )
        case( 'pem' )
          read( iunit ) chead, cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
!
        case( 'pee' )
          read( iunit ) chead, cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, &
                                       ((wdat2(i,ii),i=1,5),ii=1,iyl), &
                                       irank,idivx,idivy
!
        case( 'peph' )
          read( iunit ) chead, cident, ixl, iyl, ixyl, &
                                      ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                       irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, &
                                      ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                       irank,idivx,idivy
!
        case( 'pim' )
          read( iunit ) chead, cident, ixl, iyl, ionl, &
            ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
            ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl), &
            irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
            ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
            ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl), &
            irank,idivx,idivy
!
        case( 'pie' )
          read( iunit ) chead, cident, ixl, iyl, ionl, &
           ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
           ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl), &
           irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
           ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
           ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl), &
           irank,idivx,idivy
!
        case( 'piph' )
          read( iunit ) chead, cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                    irank,idivx,idivy
          write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl), &
                                    irank,idivx,idivy
        end select
        if( ir-1 .eq. 0 ) then
          isize = idivx * idivy
          cidents = cident
          select case( ckind )
          case( 'pem' )
            allocate( work3(ixl,3,iyl), work4(ixl,ixl,3,iyl), &
                      gork3(ixl,3,iyl), gork4(ixl,ixl,3,iyl) )
          case( 'pee' )
            allocate( work2(ixl,iyl), gork2(ixl,iyl) )
          case( 'peph' )
            allocate( work3(ixl,iyl,ixyl), gork3(ixl,iyl,ixyl) )
          case( 'pim' )
             allocate( & 
                work4(ixl,3,iyl,ionl), work5(ixl,ixl,3,iyl,ionl), &
                gork4(ixl,3,iyl,ionl), gork5(ixl,ixl,3,iyl,ionl) )
          case( 'pie' )
            allocate( work3(ixl,iyl,ionl), gork3(ixl,iyl,ionl) )
          case( 'piph' )
            allocate(work4(ixl,iyl,ixyl,ionl),gork4(ixl,iyl,ixyl,ionl))
          end select
        else if( ir .le. isize ) then
          if( cident .ne. cidents ) then
            write(0,*) '### ERROR: cident mismatch',cidents, cident
            stop
          end if
        end if
!
      else 
!.
         if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
             ckind .eq. 'fedi' ) then
            read( iunit ) chead,cident,ixyl,ixl,iyl, &
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,&
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         else
            read( iunit ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0,&
               irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0,&
               irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         end if
!
         if( ixyl .ne. -1 ) then
            if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) ) then
              write(0,*) '### ERROR: data size mismatch', &
                         ixas,ixae,iyas,iyae
              stop
            end if
         end if
!.
         if( ir-1 .eq. 0 ) then
            isize = idivx * idivy
            ixals = ixal
            iyals = iyal
            cidents = cident
            allocate( ixass(isize), ixaes(isize), ixans(isize), &
                      iyass(isize), iyaes(isize), iyans(isize) )
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fedi' ) then
               allocate( gork3(ixal,iyal,ionl) )
            else if( ckind .eq. 'fji' ) then
               allocate( gork4(ixal,iyal,3,ionl), work1(ionl), &
                         gampx(ionl) )
            else if( ckind .eq. 'fje' ) then
               allocate( gork4(ixal,iyal,3,3), gampx(1) )
            else if( ckind .eq. 'fjt' ) then
               allocate( gork3(ixal,iyal,3), gampx(1) )
            else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' ) then
!                               * check instantaneous flag for fer/fbr *
               if( chead(3:3) .eq. 'R' ) then
                  allocate( gork4(ixal,iyal,3,2) )
               else
                  allocate( gork3(ixal,iyal,3) )
               end if
            else if( ckind .eq. 'fte' ) then
               allocate( gork3(ixal,iyal,2) )
!                                                        * other cases *
            else
               allocate( gork2(ixal,iyal) )
            end if
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch',cidents, cident
               stop
            end if
            if( ixal.ne.ixals .or. iyal.ne.iyals ) then
               write(0,*) '### ERROR: total size mismatch', &
                          ixal,ixals,iyal,iyals
               stop
            end if
         end if
!..
         if( i0s .eq. 0 .and. ixyl .ne. -1 ) then
            wx0s = wx0
            wy0s = wy0
            i0s = 1
         end if
!..
         ixass(ir) = ixas
         ixaes(ir) = ixae
         ixans(ir) = ixae - ixas + 1
         iyass(ir) = iyas
         iyaes(ir) = iyae
         iyans(ir) = iyae - iyas + 1
!
         ipixel = ipixel + ixans(ir)*iyans(ir)
!..
      end if
!..
      if( ir .eq. isize ) exit
!..
      end do
!...
      if( ckind(1:1) .eq. 'f' ) then
         if( ipixel .ne. ixal*iyal ) then
            write(0,*) '### ERROR: total #pixel mismatch', &
                          ipixel,ixal,iyal
            stop
         end if
      end if
!...
      if( ckind(1:1) .eq. 'f' ) then
         ixps = ( wxps + wx0s ) / wxmic
         if( ixps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid xps', wxps, ixps
            write( 0, * ) '###        : ixps is assumed as 1'
            ixps = 1
         end if
         ixpe = ( wxpe + wx0s ) / wxmic
         if( ixpe .gt. ixal ) then
            write( 0, * ) '### WARNING: invalid xpe', wxpe, ixpe
            write( 0, * ) '###        : ixpe is assumed as', ixal
            ixpe = ixal
         end if
         if( ixps .gt. ixpe ) then
            write( 0, * ) '### ERROR: xps gt xpe', wxps, wxpe
            stop
         end if
         iyps = ( wyps + wy0s ) / wymic
         if( iyps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid yps', wyps, iyps
            write( 0, * ) '###        : iyps is assumed as 1'
            iyps = 1
         end if
         iype = ( wype + wy0s ) / wymic
         if( iype .gt. iyal ) then
            write( 0, * ) '### WARNING: invalid ype', wype, iype
            write( 0, * ) '###        : iype is assumed as', iyal
            iype = iyal
         end if
         if( iyps .gt. iype ) then
            write( 0, * ) '### ERROR: yps gt ype', wyps, wype
            stop
         end if
!.
         ixn  = ( ixpe - ixps ) / intx + 1
         if( ixn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid x interval', &
	                  ixps,ixpe,intx
            stop
         end if
         iyn  = ( iype - iyps ) / inty + 1
         if( iyn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid y interval', &
	                  iyps,iype,inty
            stop
         end if
!..
         write( *, * ) '----- ixps, ixpe, iyps, iype = ', &
	                      ixps, ixpe, iyps, iype
         write( *, * ) '----- ixn, iyn = ', ixn, iyn
      end if
!....
      write( *, * ) '----- header: ', chead, ', ident: ', cident
!..
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cfrfntp, -1, 1, cident, &
                                        'fE'//ckind(4:4), cfile )
      else
         call fntpcnv ( cfrfntp, -1, 1, cident, ckind, cfile )
      end if
      call frames_init
      call frames_file ( cfile, 1, ifrm )
!.......................................................................
    1 continue
!...
         do ir = 1, isize
!..
         iunit = iun0 + ir
!.
         select case( ckind )
         case( 'pem' )
            read( iunit, end=99 ) wtime, &
                        (((work3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl), &
             ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
               gork4(:,:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
!
         case( 'pee' )
            read( iunit, end=99 ) wtime, work2
            if( ir .eq. 1 ) then
               gork2(:,:) = 0.0d0
            end if
            gork2(:,:) = gork2(:,:) + work2(:,:)
!
         case( 'peph' )
            read( iunit, end=99 ) wtime, work3
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
!
         case( 'pim' )
            read( iunit, end=99 ) wtime, &
                (( ((work4(i,i3,i4,i5),i=1,ixl),i3=1,3), &
                  (((work5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
            if( ir .eq. 1 ) then
               gork4(:,:,:,:) = 0.0d0
               gork5(:,:,:,:,:) = 0.0d0
            end if
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
            gork5(:,:,:,:,:) = gork5(:,:,:,:,:) + work5(:,:,:,:,:)
!
         case( 'pie' )
            read( iunit, end=99 ) wtime, work3
            if( ir .eq. 1 ) then
               gork3(:,:,:) = 0.0d0
            end if
            gork3(:,:,:) = gork3(:,:,:) + work3(:,:,:)
!
         case( 'piph' )
            read( iunit, end=99 ) wtime, work4
            if( ir .eq. 1 ) then
               gork4(:,:,:,:) = 0.0d0
            end if
            gork4(:,:,:,:) = gork4(:,:,:,:) + work4(:,:,:,:)
!
         case default 
            if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 ) then
               if( ckind .eq. 'fdi' .or. ckind .eq. 'fedi' ) then
                  allocate( work3(ixans(ir),iyans(ir),ionl) )
                  read( iunit, end=99 ) wtime, work3
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) = &
                                                          work3(:,:,:)
                  deallocate( work3 )
               else if( ckind .eq. 'fji' ) then
                  allocate( work4(3,ixans(ir),iyans(ir),ionl) )
                  read( iunit, end=99 ) wtime, work4, work1
                  do i4 = 1, ionl
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1,i4) &
                      = work4(1,:,:,i4)
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2,i4) &
                      = work4(2,:,:,i4)
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),3,i4) &
                      = work4(3,:,:,i4)
                  end do
                  deallocate( work4 )
                  if( ir .eq. 1 ) gampx(:) = 0.0d0
                  do i4 = 1, ionl
                    gampx(i4) = max( gampx(i4), work1(i4) )
                  end do
               else if( ckind .eq. 'fje' ) then
                  allocate( work4(3,ixans(ir),iyans(ir),3) )
                  read( iunit, end=99 ) wtime, work4, work
                  do i4 = 1, 3
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1,i4) &
                      = work4(1,:,:,i4)
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2,i4) &
                      = work4(2,:,:,i4)
                   gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),3,i4) &
                      = work4(3,:,:,i4)
                  end do
                  deallocate( work4 )
                  if( ir .eq. 1 ) gampx(1) = 0.0d0
                  gampx(1) = max( gampx(1), work )
               else if( ckind .eq. 'fjt' ) then
                  allocate( work3(3,ixans(ir),iyans(ir)) )
                  read( iunit, end=99 ) wtime, work3, work
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1) = &
                                                          work3(1,:,:)
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2) = &
                                                          work3(2,:,:)
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),3) = &
                                                          work3(3,:,:)
                  deallocate( work3 )
                  if( ir .eq. 1 ) gampx(1) = 0.0d0
                  gampx(1) = max( gampx(1), work )
               else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' ) then
                  if( chead(3:3) .eq. 'R' ) then
                     allocate( work4(3,ixans(ir),iyans(ir),2) )
                     read( iunit, end=99 ) wtime, work4
                     do i4 = 1, 2
                       gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1,i4) &
                         = work4(1,:,:,i4)
                       gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2,i4) &
                         = work4(2,:,:,i4)
                       gork4(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),3,i4) &
                         = work4(3,:,:,i4)
                    end do
                    deallocate( work4 )
                  else
                     allocate( work3(3,ixans(ir),iyans(ir)) )
                     read( iunit, end=99 ) wtime, work3
                     gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1) =&
                                                          work3(1,:,:)
                     gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2) =&
                                                          work3(2,:,:)
                     gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),3) =&
                                                          work3(3,:,:)
                     deallocate( work3 )
                  end if
               else if( ckind .eq. 'fte' ) then
                  allocate( work3(ixans(ir),iyans(ir),2) )
                  read( iunit, end=99 ) wtime, work3
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),1) = &
                                                          work3(:,:,1)
                  gork3(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),2) = &
                                                          work3(:,:,2)
                  deallocate( work3 )
!                                                       * other cases *
               else
                  allocate( work2(ixans(ir),iyans(ir)) )
                  read( iunit, end=99 ) wtime, work2
                  gork2(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir)) = &
                                                          work2(:,:)
                  deallocate( work2 )
               end if
            end if
         end select
!..
         end do
!...
         if( wtime .lt. wts-wteps ) then
	    go to 1
         end if
!...
         if( wtime .gt. wte+wteps ) then
            write( *, * ) '----- end at ', wtime
            go to 2
         end if
!...
         write( *, * ) '----- time = ', wtime
!..
         if( ckind .eq. 'pem' ) then
           do ii = 1, iyl
             call o2pdraw6 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, &
                         gork3(1,1,ii), gork3(1,2,ii), gork3(1,3,ii), &
                   gork4(1,1,1,ii), gork4(1,1,2,ii), gork4(1,1,3,ii), &
                   ixl, wdat2(1,ii), &
                  wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), wdat2(5,ii), &
                     'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pem' ) 
           end do
!
         else if( ckind .eq. 'pee' ) then
           do ii = 1, iyl
             call o2pdraw1 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, gork2(1,ii), ixl, wdat2(1,ii), &
                  wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), wdat2(5,ii), &
                                         'MeV', 'number[a.u.]', 'pee' )
           end do
!
         else if( ckind .eq. 'peph' ) then
           do ii = 1, ixyl
             call o2pdrawph ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, gork3(1,1,ii), ixl, iyl, &
                       wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), &
                       wdat2(4,ii), wdat2(5,ii), wdat2(6,ii), &
                      'x[micron]', 'Ux/c', 'peph' )
           end do
!
         else if( ckind .eq. 'pim' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
             do ii = 1, iyl
               call o2pdraw6 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, &
                gork4(1,1,ii,i4), gork4(1,2,ii,i4), gork4(1,3,ii,i4), &
          gork5(1,1,1,ii,i4), gork5(1,1,2,ii,i4), gork5(1,1,3,ii,i4), &
                  ixl, wdat22(ii,i4), &
                  wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), &
             'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pim'//clabel ) 
             end do
           end do
!
         else if( ckind .eq. 'pie' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
             do ii = 1, iyl
               call o2pdraw1 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, gork3(1,ii,i4), ixl, wdat22(ii,i4), &
                  wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), &
                                 'MeV', 'number[a.u.]', 'pie'//clabel )
             end do
           end do
!
         else if( ckind .eq. 'piph' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat22(1,i4), wdat22(2,i4), clabel )
             do ii = 1, ixyl
               call o2pdrawph ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, gork4(1,1,ii,i4), ixl, iyl, &
                       wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), &
                       wdat2(4,ii), wdat2(5,ii), wdat2(6,ii), &
                      'x[micron]', 'Ux/c', 'piph'//clabel )
             end do
           end do
!
         else if( ckind .eq. 'fji' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
         gampx(i4), gork4(1,1,1,i4), gork4(1,1,2,i4), gork4(1,1,3,i4), &
                                 ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                       'fjxi'//clabel, 'fjyi'//clabel, 'fjzi'//clabel, &
                     'fjxyi'//clabel, 'fjyzi'//clabel, 'fjxzi'//clabel )
            end do
!
         else if( ckind .eq. 'fdi' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                              1, ilog, 3, icrsx, icrsy, &
                              gork3(1,1,i4), ixal, iyal, &
                              wxmic, wx0s, wymic, wy0s, 'fdi'//clabel )
            end do
!
         else if( ckind .eq. 'fedi' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                              1, 0, 1, 0, 0, &
                              gork3(1,1,i4), ixal, iyal, &
                              wxmic, wx0s, wymic, wy0s, 'fedi'//clabel )
            end do
!
         else if( ckind .eq. 'fje' ) then
            call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
            gampx(1), gork4(1,1,1,1), gork4(1,1,2,1), gork4(1,1,3,1), &
                                ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                    'fjxe', 'fjye', 'fjze', 'fjxye', 'fjyze', 'fjxze' )
            call o2fdraw5 ( cident, wtime, 1, 3, icrsx, 1, &
            gampx(1), gork4(1,1,1,2), gork4(1,1,2,2), gork4(1,1,3,2), &
                                ixal, iyal, wxmic, wx0s, wymic, wy0s, &
  'fjxe[h]', 'fjye[h]', 'fjze[h]', 'fjxye[h]', 'fjyze[h]', 'fjxze[h]' )
            call o2fdraw5 ( cident, wtime, 1, 3, icrsx, 4, &
            gampx(1), gork4(1,1,1,3), gork4(1,1,2,3), gork4(1,1,3,3), &
                                ixal, iyal, wxmic, wx0s, wymic, wy0s, &
  'fjxe[c]', 'fjye[c]', 'fjze[c]', 'fjxye[c]', 'fjyze[c]', 'fjxze[c]' )
!
         else if( ckind .eq. 'fjt' ) then
            call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
                  gampx(1), gork3(1,1,1), gork3(1,1,2), gork3(1,1,3), &
                                ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                    'fjxt', 'fjyt', 'fjzt', 'fjxyt', 'fjyzt', 'fjxzt' )
!
         else if( ckind .eq. 'fte' ) then
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                            1, 0, 1, 0, 0, gork3(1,1,1), ixal, iyal, &
                            wxmic, wx0s, wymic, wy0s, 'fte[MeV] ' )
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                            1, 0, 1, 0, 0, gork3(1,1,2), ixal, iyal, &
                            wxmic, wx0s, wymic, wy0s, 'fpe[Gbar] ' )
!
         else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr') then
            if( chead(3:3) .eq. 'R' ) then
               clabel = 'r'
               if( ckind .eq. 'fbr' ) clabel(2:5) = '[MG]'
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                       gork4(1,1,1,1), gork4(1,1,2,1), gork4(1,1,3,1), &
                       ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
               clabel = 'r(inst.)'
               if( ckind .eq. 'fbr' ) clabel(9:12) = '[MG]'
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                       gork4(1,1,1,2), gork4(1,1,2,2), gork4(1,1,3,2), &
                       ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
            else
               clabel = 'r'
               if( ckind .eq. 'fbr' ) clabel(2:5) = '[MG]'
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                           gork3(1,1,1), gork3(1,1,2), gork3(1,1,3), &
                           ixal, iyal, wxmic, wx0s, wymic, wy0s, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
            end if
!                                                       * other cases *
         else
            icol = 1
            if( ckind .eq. 'fde' ) icol = 3
            if( ckind .eq. 'fdc' ) icol = 2
            clabel = ckind
            if( ckind .eq. 'fba' ) clabel(4:7) = '[MG]'
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                       1, ilog, icol, icrsx, icrsy, gork2, ixal, iyal, &
                       wxmic, wx0s, wymic, wy0s, clabel )
         end if
!...
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!...
    2 continue
      call frames_term
!....
      stop
      end
