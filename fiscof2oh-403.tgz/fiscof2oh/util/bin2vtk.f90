!----------------------------------------------------------------------
! convert binary file to VTK file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   cvtfntp: file name template for VTK file
!          : default is '&K-&I-%%.###.vtk'
!          : &I is replaced by identification character in binary file
!          : &K is replaced by header in binary file
!          : ## is replaced by irank (MPI rank number)
!          : %% is replaced by file sequence number, not unit#
!   ctype  : file data type ASCII or BINARY (default)
!   irank  : MPI rank number (default is -1)
!          : should be -1 if nonparallel run
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   iseq   : initial sequence number of VTK file (default is 0)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!
!  VTK binary data must be "BIG_ENDIAN", and convert='BIG_ENDIAN' in 
! OPEN statement is used in this program, assuming "gfortran".
!  But it's not standard, and you should modify it to fit your 
! environments. You can use environment variable or compiler option,
! such as "setenv GFORTRAN_CONVERT_UNIT big_endian:7" or 
! "-fconvert=big-endian" for gfortran.
! note: take care of "_" or "-" between "big" and "endian".
!
!----------------------------------------------------------------------
      use parameter, only:lionspx
      implicit none
      integer :: i, il, ico, idn, iunit, ixl, iyl, ixyl, intt, &
                 ixps, iyps, ixpe, iype, intx, inty, &
                 irank, ixn, iyn, icnt, ion, iseq
      real*4, allocatable :: wwrk(:,:,:,:)
      real*8, allocatable :: awrk(:,:,:,:)
      real*8  :: wxps, wyps, wxpe, wype, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aundef=-1.0d20, aundeff=-1.1d20, &
                 aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, cform*32, &
                 cbifntp*64, cvtfntp*64, cfile*128, ctype*6, cbuff*80, &
                 ctitle(lionspx)*32
!.
      namelist /param/ ckind, cbifntp, cidentb, cvtfntp, ctype, irank, &
               wts, wte, intt, iseq, wxps, wxpe, wyps, wype, intx, inty
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cvtfntp = '&K-&I-%%.###.vtk'
      ctype   = 'BINARY'
      irank   = -1
      wts     = 0.0
      wte     = 9999.0
      intt    = 1
      iseq    = 0
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      intx    = 1
      inty    = 1
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'fde' )
         iunit = 20
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Density'
      case( 'fdi' )
         iunit = 21
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Density'
      case( 'fea' )
         iunit = 22
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Electric_Field'
      case( 'fer' )
         iunit = 23
         ico = 3
         idn = 1
         ctitle(1) = 'Electric_Field'
      case( 'fba' )
         iunit = 24
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Magnetic_Field'
      case( 'fbr' )
         iunit = 25
         ico = 3
         idn = 1
         ctitle(1) = 'Magnetic_Field'
      case( 'fje' )
         iunit = 28
         ico = 3
         idn = 3
         ctitle(1) = 'Electron_Current'
         ctitle(2) = 'Electron_Current(hot)'
         ctitle(3) = 'Electron_Current(cold)'
      case( 'fji' )
         iunit = 29
         ico = 3
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Current'
      case( 'fjt' )
         iunit = 42
         ico = 3
         idn = 1
         ctitle(1) = 'Total_Current'
      case( 'fede' )
         iunit = 27
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Energy_Density'
      case( 'fedi' )
         iunit = 36
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Energy_Density'
      case( 'fdc' )
         iunit = 41
         ico = 1
         idn = 1
         ctitle(1) = 'Charge_Density'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!....
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, irank, iunit, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp, irank, iunit, cidentb, ckind, cfile ) 
      end if 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      if( ion .eq. 0 ) then
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0
      else
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0, &
                     idn, (aionam(i),aionaz(i),i=1,idn)
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0, &
                    idn, (aionam(i),aionaz(i),i=1,idn)
      end if
!.                              * check instantaneous flag for fer/fbr *
      if( chead(1:3) .eq. 'feR' ) then
         idn = 2
         ctitle(2) = 'Electric_Field(inst.)'
      else if( chead(1:3) .eq. 'fbR' ) then
         idn = 2
         ctitle(2) = 'Magnetic_Field(inst.)'
      end if
!..
      if( wxps .le. aundef ) then
         ixps = 1
      else
         ixps = ( wxps + wx0 ) / wxmic
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: invalid xps', wxps, ixps
            write(0,*) '###        : ixps is assumed as 1'
            ixps = 1
         end if
      end if
      if( wxpe .le. aundef ) then
         ixpe = ixl
      else
         ixpe = ( wxpe + wx0 ) / wxmic
         if( ixpe .gt. ixl ) then
            write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
            write(0,*) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
      end if
      if( ixps .gt. ixpe ) then
         write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
         stop
      end if
      if( wyps .le. aundef ) then
         iyps = 1
      else
         iyps = ( wyps + wy0 ) / wymic
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: invalid yps', wyps, iyps
            write(0,*) '###        : iyps is assumed as 1'
            iyps = 1
         end if
      end if
      if( wype .le. aundef ) then
         iype = iyl
      else
         iype = ( wype + wy0 ) / wymic
         if( iype .gt. iyl ) then
            write(0,*) '### WARNING: invalid ype', wype, iype
            write(0,*) '###        : iype is assumed as', iyl
            iype = iyl
         end if
      end if
      if( iyps .gt. iype ) then
         write(0,*) '### ERROR: yps gt ype', wyps, wype
         stop
      end if
!.
      ixn  = ( ixpe - ixps ) / intx + 1
      if( ixn .lt. 2 ) then
         write(0,*) '### ERROR: invalid x interval', &
	               ixps,ixpe,intx
         stop
      end if
      iyn  = ( iype - iyps ) / inty + 1
      if( iyn .lt. 2 ) then
         write(0,*) '### ERROR: invalid y interval', &
                       iyps,iype,inty
         stop
      end if
!..
      wxps = ( ixps-1 ) * wxmic - wx0
      wyps = ( iyps-1 ) * wymic - wy0
      wxpe = wxps + wxmic * intx * ( ixn - 1 )
      wype = wyps + wymic * inty * ( iyn - 1 )
      write(*,*) '----- ixps, ixpe, wxps, wxpe = ', ixps,ixpe,wxps,wxpe
      write(*,*) '----- iyps, iype, wyps, wype = ', iyps,iype,wyps,wype
      write(*,*) '----- ixn, iyn = ', ixn, iyn
      write(*,*) '----- header: ', chead, ', ident: ', cident
!..
      if( ion .eq. 1 ) then
         do i = 2, idn
            ctitle(i) = ctitle(1)
         end do
         il = len_trim( ctitle(1) )
         do i = 1, idn
            call o2ionlabel( i, aionam(i), aionaz(i), ctitle(i)(il+1:) )
         end do
      end if
!....
      allocate( awrk(ico,ixl,iyl,idn) )
      if( ctype(1:1) .ne. 'A' .and. ctype(1:1) .ne. 'a' ) then
         allocate( wwrk(ico,ixn,iyn,idn) )
      end if
      icnt = iseq
    1 continue
         read(iunit, end=99) wtime, awrk
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- seq#, time = ', icnt, wtime
!.
         call fntpcnv ( cvtfntp, irank, icnt, cident, chead, cfile )
!.
         if( ctype(1:1) .eq. 'A' .or. ctype(1:1) .eq. 'a' ) then
            open(7, file=cfile, form='FORMATTED' )
            write(7,'(a)') '# vtk DataFile Version 3.0'
            write(cbuff,'(f8.2)') wtime 
            write(7,'(a)') trim(cident)//',time='//trim(adjustl(cbuff))
            write(7,'(a)') 'ASCII' 
            write(7,'(a)') 'DATASET STRUCTURED_POINTS'
            write(7,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, 1
            write(7,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, 0.0
            write(7,'(a,1x,3e12.4)') 'SPACING', &
                                       intx*wxmic,inty*wymic,0.0
            write(7,'(a,1x,i9)') 'POINT_DATA', ixn*iyn
            do i = 1, idn
               if( ico .eq. 1 ) then
                  write(7,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                  write(7,'(a)') 'LOOKUP_TABLE default'
               else
                  write(7,'(a,1x,a,1x,a)') 'VECTORS', &
                                                trim(ctitle(i)), 'float'
               end if
               write(7, '(6e12.4)' ) &
                  awrk(:,ixps:ixpe:intx,iyps:iype:inty,i)
            end do
            close(7)
         else
            open(7, file=cfile, access='STREAM', form='UNFORMATTED', &
                    convert='BIG_ENDIAN' )
            write(cbuff,'(a)') '# vtk DataFile Version 3.0'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(f8.2)') wtime 
            write(7) &
             trim(cident)//',time='//trim(adjustl(cbuff))//new_line('A')
            write(cbuff,'(a)') 'BINARY' 
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a)') 'DATASET STRUCTURED_POINTS'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, 1
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, 0.0
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'SPACING', &
                                       intx*wxmic,inty*wymic,0.0
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,i9)') 'POINT_DATA', ixn*iyn
            write(7) trim(cbuff)//new_line('A')
            wwrk(:,:,:,:) = &
               awrk(:,ixps:ixpe:intx,iyps:iype:inty,:)
            do i = 1, idn
               if( ico .eq. 1 ) then
                  write(cbuff,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                  write(7) trim(cbuff)//new_line('A')
                  write(cbuff,'(a)') 'LOOKUP_TABLE default'
                  write(7) trim(cbuff)//new_line('A')
               else
                  write(cbuff,'(a,1x,a,1x,a)') 'VECTORS', &
                                                trim(ctitle(i)), 'float'
                  write(7) trim(cbuff)//new_line('A')
               end if
               write(7) wwrk(:,:,:,i)
            end do
            close(7)
         end if
!.
         icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
