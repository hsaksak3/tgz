      include "implicit.h"
      include "parameter.h"
      real*8
     $    sjxe(-1:lssxp3,-1:lssyp2), sjxi(0:lssxp2,0:lssyp1,lionspx),
     $    sjye(-1:lssxp2,-1:lssyp3), sjyi(0:lssxp1,0:lssyp2,lionspx),
     $    sjxeo(-1:lssxp3,-1:lssyp2), sjxio(0:lssxp2,0:lssyp1,lionspx),
     $    sjyeo(-1:lssxp2,-1:lssyp3), sjyio(0:lssxp1,0:lssyp2,lionspx)
c....
      read(61) sjxe, sjye
      read(71) sjxeo, sjyeo
      werrx = 0.0d0
      ixerx = -1
      iyerx = -1
      werrs = 0.0d0
c..
      do iy = -1, lssyp2
         do ix = -1, lssxp2
            werr = ( sjxe(ix,iy) - sjxeo(ix,iy) )**2 + 
     $             ( sjye(ix,iy) - sjyeo(ix,iy) )**2
	    if( werr .gt. werrx ) then
	       werrx = werr
	       ixerx = ix
	       iyerx = iy
	    end if
	    werrs = werrs + werr
         end do
      end do   
c..
      werrx = sqrt( werrx )
      werrs = sqrt( werrs )
      write(*,*) '@@@ sje', werrs, werrx, ixerx, iyerx
c....     
      read(60) sjxi, sjyi
      read(70) sjxio, sjyio
      werrx = 0.0d0
      ixerx = -1
      iyerx = -1
      werrs = 0.0d0
c..
      do io = 1, 1
      do iy = 0, lssyp1
         do ix = 0, lssxp1
            werr = ( sjxi(ix,iy,io) - sjxio(ix,iy,io) )**2 + 
     $             ( sjyi(ix,iy,io) - sjyio(ix,iy,io) )**2
	    if( werr .gt. werrx ) then
	       werrx = werr
	       ixerx = ix
	       iyerx = iy
	    end if
	    werrs = werrs + werr
         end do
      end do   
      end do   
c..
      werrx = sqrt( werrx )
      werrs = sqrt( werrs )
      write(*,*) '@@@ sji', werrs, werrx, ixerx, iyerx
c....
      stop
      end
