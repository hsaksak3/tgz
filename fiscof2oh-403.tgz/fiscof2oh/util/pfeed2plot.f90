!----------------------------------------------------------------------
! plot pfeed data (2D)
!
! file: FISCOF2_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
! original coded by Sakagami,H. for 1D
! extended to 2D by Hata,M.
!  reconstrcuted by Sakagami,H. 11/02/22
! modified by Sakagami, H. 12/11/01 for time.param file
! modified by Sakagami, H. 14/05/19 for ENV and wtimen
! modified by Sakagami, H. 15/11/18 for equal division,
!             distribution correction, norm. in OMEGA with new ENV var.
! modified by Sakagami, H. 18/05/30 for multi locations
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: ltx = 500, its = 6, itd = 5
      real*8, parameter :: alcut = 0.3d0 ! MeV
      real*8, parameter :: aet0=0.0d0,aet1=0.5d0, &
                           aet2=2.0d0,aet3=5.0d0,aet4=10.0d0
      integer :: irx, irxp1, imx, imxp1, imxh, inx, inxp1, iyx, iyxx, &
                 ilsrty, i, ir, im, in, iy, it, itx, itn, i2d3d,&
                 il, ilx, id1, id2, id3, id4, icol, icolc, icold, &
                 ilcut, icidl, iet1, iet2, iet3, iet4, isned, ixy, imxhh
      real*8 :: wrang, wintt, wotint, woxp, woyps, woype, wnepm1, &
                wnpnc, wlramm, wlram, wgrid, wlpwr, &
                wnc, weight, woywid, wcoefn, wcoefw, wcoefj, &
                wp, wgam, wth, womg, wdomg, wdomg2, wtot, wnum, &
                wintmn, wintmx, wyps, wype, wtimen, wtimex, &
                wtime(ltx), wtotal(ltx), wsum(ltx)
      real*8, allocatable :: &
                weng(:), wengb(:), wmue(:), wint(:,:), wflue(:,:), &
                wpedrmy(:,:,:), wdisrmy(:,:,:), wdisrny(:,:,:), &
                wpedrmyt(:,:,:), wdisrmyt(:,:,:), wdisrnyt(:,:,:), &
                wetot(:,:,:), wetots(:,:,:), &
                wnumtot(:,:,:), wnumtots(:,:,:), &
                wspec(:,:,:), wspecta(:,:), wspecti(:,:), &
                whwhm(:,:), whwhmt(:,:,:), work(:,:), &
                wxrm(:,:), wyrm(:,:), wxrn(:,:), wyrn(:,:), &
                wxea(:,:), wyea(:,:), wxhwhm(:,:), wyhwhm(:,:), &
                wang(:), wadis(:), waidis(:), wadisx(:), &
                wxadis(:,:), wyadis(:,:), wadist(:,:), wvc(:)
      character cbuff*80, cdum*3, cident*18, crange*16, cfile*128, &
                cypos*7, cxpos*12
!
! physical constant [MKSA], smevj:MeV->J
      real*8, parameter :: sme  = 9.1093897d-31, &
                           sc   = 2.99792458d08, &
                           smec = sme * sc, &
                           smecc= smec * sc, &
                           spi  = 3.1415926535897931d0, &
                           se   = 1.602176462d-19, &
                           seps0= 8.854187817d-12, &
                           smevj= 1.602176462d-13
! contour color
      real*8, parameter :: sh(4) = (/240.0d0, 240.0d0, 0.0d0, 0.0d0/), &
                           sl(4) = (/0.25d0, 0.5d0, 0.5d0, 0.9d0/), &
                           ss(4) = (/1.0d0, 1.0d0, 1.0d0, 1.0d0/)
      integer, parameter :: ndiv(3) = (/20, 90, 20/)
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF2_TIMEPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 )
      end if
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!..
      i2d3d = 2
      call getenv ( 'FISCOF2_NORMALIZE_OMEGA', cbuff )
      if( cbuff(1:1) .eq. '3' ) i2d3d = 3
!....                                                  * read headers *
! ------ start 1/2 -------
! ident character             = i20tmpulse       
! Sn                          =      36      
!  or
! Equal Division              =      32      
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       1       
!  or
! observation position of y   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! # of division for x         =       1       
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
      read(*,1100) cbuff(1:16)
      if( cbuff(14:14) .eq. '-' ) then
         ilx = 1
      else
         read( cbuff(14:16), '(i1,a1,i1)' ) il, cdum(1:1), ilx
      end if
      read(*,1000) cbuff(1:27), cdum, cident(1:16)
      cident(17:18) = ' '
      read(*,1001) cbuff(1:27), cdum, imx
      if( cbuff(1:2) .eq. 'Sn' ) then
         isned = 1
      else
         isned = 2
      end if
      read(*,1001) cbuff(1:27), cdum, inx
      read(*,1001) cbuff(1:27), cdum, irx
      read(*,1003) cbuff(1:27), cdum, wrang
      read(*,1002) cbuff(1:27), cdum, wintt
      read(*,1002) cbuff(1:27), cdum, wotint
      read(*,1002) cbuff(1:27), cdum, woxp
      if( cbuff(25:25) .eq. 'x' ) then
         ixy = 1
      else if( cbuff(25:25) .eq. 'y' ) then
         ixy = 2
      else
         write(0,*) '### ERROR: position is not x or y', cbuff(25:25)
         stop
      end if
      read(*,1002) cbuff(1:27), cdum, woyps
      read(*,1002) cbuff(1:27), cdum, woype
      read(*,1001) cbuff(1:27), cdum, iyx
      read(*,1002) cbuff(1:27), cdum, wnepm1
      read(*,1002) cbuff(1:27), cdum, wnpnc
      read(*,1002) cbuff(1:27), cdum, wlramm
      read(*,1002) cbuff(1:27), cdum, wlram
      read(*,1002) cbuff(1:27), cdum, wgrid
      read(*,1003) cbuff(1:27), cdum, wlpwr
      read(*,1001) cbuff(1:27), cdum, ilsrty
 1100 format(a16)
 1000 format(a27,a3,a16)
 1001 format(a27,a3,i7)
 1002 format(a27,a3,f11.3)
 1003 format(a27,a3,e11.4)
      wnc    = (spi*2.d0*sc/(wlramm*1.d-6))**2 * seps0 * sme / (se**2)
      wintt  = wintt * 1.d-15
      wotint  = wotint * 1.d-15
      weight = wnc * (wlramm*1.d-6/wlram)/wnepm1
      woywid = abs( woype - woyps ) / wlramm * wlram / iyx
      wcoefn = weight / wintt / woywid
      wcoefw = wcoefn*smevj
!     wcoefj = wcoefw*wotint / iyx * 1.0d-12
      wcoefj = wcoefw*wotint * 1.0d-12
      write(0,*) 'ident   = ', cident
      write(0,*) 'irx     = ', irx
      if( isned .eq. 1 ) then
         write(0,*) 'Sn  imx = ', imx
      else
         write(0,*) 'EqD imx = ', imx
      end if
      write(0,*) 'inx     = ', inx
      write(0,*) 'iyx     = ', iyx
      write(0,*) 'nc #/m3 = ', wnc
      write(0,*) 'weigh   = ', weight
      write(0,*) 'delta-p = ', wrang, ' *mec'
      write(0,*) 'integ-t = ', wintt, ' sec'
      if( ixy .eq. 1 ) then
         write(0,*) 'obs. Xp = ', woxp, ' micron'
         write(0,*) 'obs. Yp = ', woyps, '~', woype, ' micron'
      else
         write(0,*) 'obs. Yp = ', woxp, ' micron'
         write(0,*) 'obs. Xp = ', woyps, '~', woype, ' micron'
      end if
      if( i2d3d .eq. 2 ) then
         write(0,*) 'Omga NM = 2D'
      else
         write(0,*) 'Omga NM = 3D'
      end if
! set position characters
      write( crange, '(f5.1)' ) woxp
      cxpos(8:12) = adjustl( crange )
      if( ixy .eq. 1 ) then
         cxpos(1:7) = 'X pos.:'
         cypos(1:7) = 'Y pos.:'
      else
         cxpos(1:7) = 'Y pos.:'
         cypos(1:7) = 'X pos.:'
      end if
! initialize scalar
      irxp1 = irx + 1
      imxp1 = imx + 1
      imxh  = imx / 2
      imxhh = mod( imx, 2 )
      inxp1 = inx + 1
!  allocate array
      allocate ( &
         weng(irx),wvc(irx),wengb(irxp1),wmue(imxp1), &
         wint(ltx,0:iyx), wflue(ltx,0:iyx), &
         wpedrmy(irxp1,imxp1,0:iyx), wpedrmyt(irxp1,imxp1,0:iyx), &
         wdisrmy(irxp1,imxp1,0:iyx), wdisrmyt(irxp1,imxp1,0:iyx), &
         wdisrny(irxp1,inxp1,0:iyx), wdisrnyt(irxp1,inxp1,0:iyx), &
         wetot(ltx,6,0:iyx), wetots(ltx,6,0:iyx), &
         wnumtot(ltx,6,0:iyx), wnumtots(ltx,6,0:iyx), &
         wspec(irx,ltx,0:iyx), wspecta(irx,0:iyx), wspecti(irx,0:iyx), &
         whwhm(irx,0:iyx), whwhmt(ltx,irx,0:iyx), work(imxh,2), &
         wxrm(irxp1,imxp1), wyrm(irxp1,imxp1), &
         wxrn(irxp1,inxp1), wyrn(irxp1,inxp1), &
         wxea(irxp1,imxp1), wyea(irxp1,imxp1), &
         wang(imxh), wadis(imxh), waidis(imxh), wadisx(ltx), &
         wadist(ltx,imxh) )
!  initialize
      if( isned .eq. 1 ) then
         if( imx .eq. 36 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.93207305669784500D-01
            wmue( 3) = -9.80307489633560200D-01
            wmue( 4) = -9.60150837898254400D-01
            wmue( 5) = -9.32884603738784800D-01
            wmue( 6) = -8.98714393377304100D-01
            wmue( 7) = -8.57888221740722700D-01
            wmue( 8) = -8.10711771249771100D-01
            wmue( 9) = -7.57532685995101900D-01
            wmue(10) = -6.98745220899581900D-01
            wmue(11) = -6.34784460067749000D-01
            wmue(12) = -5.66123992204666100D-01
            wmue(13) = -4.93272125720977800D-01
            wmue(14) = -4.16768252849578900D-01
            wmue(15) = -3.37178781628608700D-01
            wmue(16) = -2.55092948675155600D-01
            wmue(17) = -1.71118497848510700D-01
            wmue(18) = -8.58771540224552200D-02
            wmue(19) =  0.00000000000000000D+00
            wmue(20) =  8.58771540224552200D-02
            wmue(21) =  1.71118497848510700D-01
            wmue(22) =  2.55092948675155600D-01
            wmue(23) =  3.37178781628608700D-01
            wmue(24) =  4.16768252849578900D-01
            wmue(25) =  4.93272125720977800D-01
            wmue(26) =  5.66123992204666100D-01
            wmue(27) =  6.34784460067749000D-01
            wmue(28) =  6.98745220899581900D-01
            wmue(29) =  7.57532685995101900D-01
            wmue(30) =  8.10711860656738300D-01
            wmue(31) =  8.57888072729110700D-01
            wmue(32) =  8.98714631795883200D-01
            wmue(33) =  9.32884305715560900D-01
            wmue(34) =  9.60150927305221600D-01
            wmue(35) =  9.80307668447494500D-01
            wmue(36) =  9.93206858634948700D-01
            wmue(37) =  1.00000000000000000D+00
         else if( imx .eq. 16 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.42144960000000000D-01
            wmue( 3) = -8.68379005000000000D-01
            wmue( 4) = -7.87674650000000000D-01
            wmue( 5) = -6.97571140000000000D-01
            wmue( 6) = -5.93635069999999900D-01
            wmue( 7) = -4.65944585000000000D-01
            wmue( 8) = -2.71738260000000000D-01
            wmue( 9) =  0.00000000000000000D+00
            wmue(10) =  2.71738260000000000D-01
            wmue(11) =  4.65944585000000000D-01
            wmue(12) =  5.93635069999999900D-01
            wmue(13) =  6.97571140000000000D-01
            wmue(14) =  7.87674650000000000D-01
            wmue(15) =  8.68379005000000000D-01
            wmue(16) =  9.42144960000000000D-01
            wmue(17) =  1.00000000000000000D+00
         else
            write(0,*) '### ERROR: imx', imx
            stop
         end if
      else
         wdomg2 = spi / ( (imx-2)*2 + 2 )
         wdomg  = wdomg2 * 2.0d0
         wmue(1) = -1.0d0
         do im = 2, imx
            wmue(im) = cos( spi - wdomg2 - wdomg * (im-2) )
         end do
         wmue(imxp1) = 1.0d0
      end if
! initialize array
      do ir = 1, irx
         wp   = ( dble(ir)-0.5d0 ) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         weng(ir) = smecc * ( wgam - 1.d0 ) / smevj
         wvc(ir) = sqrt( 1.0d0 - 1.0d0 / ( 1.0d0 + wp**2 ) )
      end do
      do ir = 1, irxp1
         wp   = dble(ir-1) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         wengb(ir)= smecc * ( wgam - 1.d0 ) / smevj
      end do
      do im = 1, imxp1
         wth= acos(wmue(im))
         do ir = 1,irxp1
            wxrm(ir,im) = (ir-1) * wrang * cos(wth)
            wyrm(ir,im) = (ir-1) * wrang * sin(wth)
            wxea(ir,im) = wengb(ir)
            wyea(ir,im) = wth / spi * 180.d0
         end do
      end do
      wdomg  = spi*2.0d0 / inx
      wdomg2 = wdomg / 2.0d0
      do in = 1, inxp1
         womg= wdomg * (in-1) - wdomg2
         do ir = 1, irxp1
            wxrn(ir,in) = (ir-1) * wrang * cos(womg)
            wyrn(ir,in) = (ir-1) * wrang * sin(womg)
         end do
      end do
      do im = 1, imxh
         wang(imxh-im+1) = ( acos(wmue(imxh+im+imxhh)) + &
            acos(wmue(imxh+im+1+imxhh)) )/2.0d0 / acos( -1.0d0 ) * 180.d0
      end do
! set energy boundary
!     iet1 = -1
!     iet2 = -1
!     iet3 = -1
!     iet4 = -1
!     do ir = 1, irx
!        if( iet1 .le. 0 .and. weng(ir) .gt. aet1 ) then
!           iet1 = ir
!        else if( iet2 .le. 0 .and. weng(ir) .gt. aet2 ) then
!           iet2 = ir
!        else if( iet3 .le. 0 .and. weng(ir) .gt. aet3 ) then
!           iet3 = ir
!        else if( iet4 .le. 0 .and. weng(ir) .gt. aet4 ) then
!           iet4 = ir
!           exit
!        end if
!     end do
      iet1 = sqrt( (aet1*smevj/smecc+1.0d0)**2-1.0d0)/wrang + 0.5d0
      iet2 = sqrt( (aet2*smevj/smecc+1.0d0)**2-1.0d0)/wrang + 0.5d0
      iet3 = sqrt( (aet3*smevj/smecc+1.0d0)**2-1.0d0)/wrang + 0.5d0
      iet4 = sqrt( (aet4*smevj/smecc+1.0d0)**2-1.0d0)/wrang + 0.5d0
! set low energy cut
      ilcut = 1
      do ir = 1, irx
         if( weng(ir) .gt. alcut ) then
            ilcut = ir
            exit
         end if
      end do
! zero setting
      itx = 0
      do it = 1, ltx
         wsum(it)  = 0.d0
      end do
      do iy = 0, iyx
         do it = 1, ltx
            wint(it,iy)  = 0.d0
            wflue(it,iy)  = 0.d0
         end do
      end do
      do iy = 0, iyx
         do ir = 1, irx
            wspecta(ir,iy) = 0.d0
            wspecti(ir,iy) = 0.d0
            do it = 1, ltx
               wspec(ir,it,iy) = 0.d0
            end do
         end do
      end do
      do iy = 0, iyx
        do i = 1, 6
          do it = 1, ltx
            wetot(it,i,iy) = 0.d0
            wetots(it,i,iy) = 0.d0
            wnumtot(it,i,iy) = 0.d0
            wnumtots(it,i,iy) = 0.d0
          end do
        end do
      end do
      do iy = 0, iyx
        do im = 1, imx
          do ir = 1, irx
            wpedrmy(ir,im,iy) = 0.0d0
            wpedrmyt(ir,im,iy) = 0.0d0
            wdisrmy(ir,im,iy) = 0.0d0
            wdisrmyt(ir,im,iy) = 0.0d0
          end do
        end do
      end do
      do iy = 0, iyx
        do in = 1, inx
          do ir = 1, irx
            wdisrny(ir,in,iy) = 0.0d0
            wdisrnyt(ir,in,iy) = 0.0d0
          end do
        end do
      end do
!....
      call fr_ginit
!.
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!..
      icidl = index( cident//' ', ' ' ) - 1
      if( ilx .gt. 1 ) then
         cident(icidl+1:icidl+1) = '-'
         write( cident(icidl+2:icidl+2), '(i1)' ) il
         icidl = icidl + 2
      end if
      call fr_opencanvas( 1, 'pfeed2plot1-'//cident(1:icidl), 10 )
      call fr_opencanvas( 2, 'pfeed2plot2-'//cident(1:icidl), 10 )
      call fr_opencanvas( 3, 'pfeed2plot3-'//cident(1:icidl), 10 )
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
    1 continue
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) '### ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
!$$$
      if( itx .gt. ltx ) then
         write(0,*) '### ERROR : itx .gt. ltx', itx, ltx
         stop
      end if
!$$$
      read( cbuff(9:20), '(f12.3)' ) wtime(itx)
      write(0,*) 'itx,time = ', itx, wtime(itx)
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime(itx) - wtime(itx-1) ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime(itx)-wtimen) .ge. 1.0d0 .and. &
             (wtime(itx)-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         itx = itx - 1
         go to 1
      end if
!                                             * read until 'total = ' *
    2 continue
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .eq. 'total = ') then
         read( cbuff(9:22), '(f14.3)' ) wtotal(itx)
         write(0,*) 'total, sum = ', wtotal(itx), wsum(itx)
!...         
         call rmynrm( wdisrmy, wmue, irxp1, imxp1, iyx, ilcut, i2d3d )
!.
         call rmynrm( wpedrmy, wmue, irxp1, imxp1, iyx, ilcut, i2d3d )
!
         call adistcalc( wpedrmy, irxp1, imxp1, iyx, ilcut, &
                         wadis, waidis, imxh, wadisx(itx) )
         do im = 1, imxh
            wadist(itx,im) = wadis(im)
         end do
!
         call hwhmcalc( wpedrmy, wmue, whwhm, work, irxp1, imxp1, iyx, &
                        imxh )
         do iy = 0, iyx
           do ir = 1, irx
              whwhmt(itx,ir,iy) = whwhm(ir,iy)
           end do
         end do
!
         do iy = 0, iyx
           do im = 1, imx
             do ir = 1, irx
               wdisrmy(ir,im,iy) = log10( wdisrmy(ir,im,iy) + 1.0d0 )
               wpedrmy(ir,im,iy) = log10( wpedrmy(ir,im,iy) + 1.0d0 )
             end do
           end do
         end do
!.
         call rnynrm( wdisrny, irxp1, inxp1, iyx, ilcut )
         do iy = 0, iyx
           do in = 1, inx
             do ir = 1, irx
               wdisrny(ir,in,iy) = log10( wdisrny(ir,in,iy) + 1.0d0 )
             end do
           end do
         end do
!...
         call fr_canvas ( 1 )
!
         call rmycont( wdisrmy, wxrm, wyrm, irxp1, imxp1, iyx, &
                    wtime(itx), woyps, woype, cident, 'Instantaneous ', &
                    cxpos, cypos )
!
         call rnycont( wdisrny, wxrn, wyrn, irxp1, inxp1, iyx, &
                    wtime(itx), woyps, woype, cident, 'Instantaneous ', &
                    cxpos, cypos )
!...
         call fr_canvas ( 2 )
!
         call eaycont( wpedrmy, wxea, wyea, irxp1, imxp1, iyx, &
                wtime(itx), woyps, woype, cident, 'Instantaneous ', &
                    cxpos, cypos )
!
         call adistgraph( wang, wadis, waidis, imxh, &
                   wtime(itx), woyps, woype, cident, 'Instantaneous ', &
                    cxpos, cypos )
!
         call hwhmgraph( weng, whwhm, irx, iyx, &
                   wtime(itx), woyps, woype, cident, 'Instantaneous ', &
                    cxpos, cypos )
!...
         do iy = 0, iyx
           do im = 1, imx
             do ir = 1, irx
               wdisrmy(ir,im,iy) = 0.0d0
               wpedrmy(ir,im,iy) = 0.0d0
             end do
           end do
         end do
!.
         do iy = 0, iyx
           do in = 1, inx
             do ir = 1, irx
               wdisrny(ir,in,iy) = 0.0d0
             end do
           end do
         end do
!..
         if( abs(wtime(itx)-wtimex) .le. 1.0d0 .or. &
                (wtime(itx)-wtimex) .gt. 0.0d0 ) then
            write(0,*) 'process was stopped by time param.', wtimex
            go to 90
         end if
         go to 1
      end if
!...
      read( cbuff, '(4i4,f12.3)' ) id1,id2,id3,id4,wnum
      if( isned .eq. 2 ) id2 = imxp1 - id2
! ..forward-directed component 
      if(id2.gt.imx/2) then 

! Intensity  [W/m2]
         wint(itx,id4) = wint(itx,id4) + wnum * weng(id1) * wcoefw 

! Spectrum   [num/m2/sec in id1-group]
         wspec(id1,itx,id4) = wspec(id1,itx,id4) + wnum * wcoefn

! Total      [num/m2/sec]
         wsum(itx) = wsum(itx) + wnum * wcoefn

! Energy [J/m2/sec] & number [#/m2/sec] for each range
         if( id1 .le. iet1 ) then
            wetot(itx,1,id4) = wetot(itx,1,id4) + wnum*weng(id1)*wcoefj
            wnumtot(itx,1,id4) = wnumtot(itx,1,id4) + wnum*wcoefn
         else if( id1 .le. iet2 ) then
            wetot(itx,2,id4) = wetot(itx,2,id4) + wnum*weng(id1)*wcoefj
            wnumtot(itx,2,id4) = wnumtot(itx,2,id4) + wnum*wcoefn
         else if( id1 .le. iet3 ) then
            wetot(itx,3,id4) = wetot(itx,3,id4) + wnum*weng(id1)*wcoefj
            wnumtot(itx,3,id4) = wnumtot(itx,3,id4) + wnum*wcoefn
         else if( id1 .le. iet4 ) then
            wetot(itx,4,id4) = wetot(itx,4,id4) + wnum*weng(id1)*wcoefj
            wnumtot(itx,4,id4) = wnumtot(itx,4,id4) + wnum*wcoefn
         else
            wetot(itx,5,id4) = wetot(itx,5,id4) + wnum*weng(id1)*wcoefj
            wnumtot(itx,5,id4) = wnumtot(itx,5,id4) + wnum*wcoefn
         end if
      end if

! Momentum Ppara / Pperp
      wpedrmy(id1,id2,id4) = wpedrmy(id1,id2,id4) + wnum
      wpedrmyt(id1,id2,id4) = wpedrmyt(id1,id2,id4) + wnum

!..                           correction distribution with cos(theta) V/C
      wnum = wnum / ( abs(wmue(id2)+wmue(id2+1))/2.0d0 ) / wvc(id1)

! Momentum distribution Ppara / Pperp
      wdisrmy(id1,id2,id4) = wdisrmy(id1,id2,id4) + wnum
      wdisrmyt(id1,id2,id4) = wdisrmyt(id1,id2,id4) + wnum

! Momentum distribution Ppara / Omega
      wdisrny(id1,id3,id4) = wdisrny(id1,id3,id4) + wnum
      wdisrnyt(id1,id3,id4) = wdisrnyt(id1,id3,id4) + wnum

      goto 2

   90 continue
!...         
      write(0,*) 'reading data ',itx
!....
      call rmynrm( wdisrmyt, wmue, irxp1, imxp1, iyx, ilcut, i2d3d )
!.
      call rmynrm( wpedrmyt, wmue, irxp1, imxp1, iyx, ilcut, i2d3d )
!
      call adistcalc( wpedrmyt, irxp1, imxp1, iyx, ilcut, &
                         wadis, waidis, imxh, wnum )
!
      call hwhmcalc( wpedrmyt, wmue, whwhm, work, irxp1, imxp1, iyx, &
                        imxh )
!
      do iy = 0, iyx
         do im = 1, imx
            do ir = 1, irx
               wdisrmyt(ir,im,iy) = log10( wdisrmyt(ir,im,iy) + 1.0d0 )
               wpedrmyt(ir,im,iy) = log10( wpedrmyt(ir,im,iy) + 1.0d0 )
            end do
         end do
      end do
!..
      call rnynrm( wdisrnyt, irxp1, inxp1, iyx, ilcut )
      do iy = 0, iyx
         do in = 1, inx
            do ir = 1, irx
               wdisrnyt(ir,in,iy) = log10( wdisrnyt(ir,in,iy) + 1.0d0 )
           end do
        end do
      end do
!...
      call fr_canvas ( 1 )
!
      call rmycont( wdisrmyt, wxrm, wyrm, irxp1, imxp1, iyx, &
                    1.0d30, woyps, woype, cident, 'Time-Integrated ', &
                    cxpos, cypos )
!
      call rnycont( wdisrnyt, wxrn, wyrn, irxp1, inxp1, iyx, &
                    1.0d30, woyps, woype, cident, 'Time-Integrated ', &
                    cxpos, cypos )
!...
      call fr_canvas ( 2 )
!..
      call eaycont( wpedrmyt, wxea, wyea, irxp1, imxp1, iyx, &
                1.0d30, woyps, woype, cident, 'Time-Integrated ', &
                    cxpos, cypos )
!.
      call adistgraph( wang, wadis, waidis, imxh, &
                   1.0d30, woyps, woype, cident, 'Time-Integrated ', &
                    cxpos, cypos )
!.
      call hwhmgraph( weng, whwhm, irx, iyx, &
                 1.0d30, woyps, woype, cident, 'Time-Integrated ', &
                    cxpos, cypos )

!.
      allocate( wxadis(itx,imxh), wyadis(itx,imxh) )
      do im = 1, imxh
         do it = 1, itx
            wxadis(it,im) = wtime(it)
            wyadis(it,im) = wang(im)
         end do
      end do
      call fr_gclear
      call fr_aspect2d( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( wtime(1), wtime(itx), 0.0d0, 90.0d0, 13 )
      call fr_xyname( 'Time[fs]', 'Angle[deg.]' )
      call fr_setcontour( 0.0d0, 1.0d0, 2 )
      call fr_sqrcontour( wxadis, wyadis, wadist(1:itx,1:imxh), &
                          itx, imxh, 1, -2, 0 )
      call fr_colorbar ( 400, 465, 200, 15, 2 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 7, 1 )
      call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars( 200.0d0,15.0d0, &
                       'Normalized Angular Distribution',7,1,-1,0,0)
!
      do im = 1, imxh
         do it = 1, itx
            wadist(it,im) = wadist(it,im) * wadisx(it)
         end do
      end do
      call fr_gclear
      call fr_aspect2d( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( wtime(1), wtime(itx), 0.0d0, 90.0d0, 13 )
      call fr_xyname( 'Time[fs]', 'Angle[deg.]' )
      call fr_sqrcontour( wxadis, wyadis, wadist(1:itx,1:imxh), &
                          itx, imxh, 1, -2, 0 )
      call fr_colorbar ( 400, 465, 200, 15, 2 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 7, 1 )
      call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars( 200.0d0,15.0d0, &
                       'Angular Distribution',7,1,-1,0,0)
      deallocate( wxadis, wyadis )
!.
      allocate( wxhwhm(itx,irx), wyhwhm(itx,irx) )
      do ir = 1, irx
         do it = 1, itx
            wxhwhm(it,ir) = wtime(it)
            wyhwhm(it,ir) = weng(ir)
         end do
      end do
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, weng(irx), 13 )
         call fr_xyname( 'Time[fs]', 'Energy[MeV]' )
         call fr_setcontour( 0.0d0, 90.0d0, 2 )
         call fr_sqrcontour( wxhwhm, wyhwhm, whwhmt(1:itx,1:irx,iy), &
                             itx, irx, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
         else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0,15.0d0, 'HWHM[deg.]', 7,1,-1,0,0 )
      end do
      deallocate( wxhwhm, wyhwhm )
!.... convert unit
!.. intensity [W/m2] --> [W/cm2]
      do iy = 1, iyx
         do it = 1, itx
            wint(it,iy) = wint(it,iy) * 1.0d-4
            if( wint(it,iy) .lt. 1.0d10) wint(it,iy) = 1.0d10
            wint(it,0) = wint(it,0) + wint(it,iy) / iyx
         end do
      end do
!.. total beam fluence [J/cm2]
!..    changed to [J/micron2]
      do iy = 1, iyx
         wflue(1,iy) = wint(1,iy) * wotint * 1.0d-8
         do it = 2, itx
            wflue(it,iy) = wflue(it-1,iy) + wint(it,iy) * wotint*1.0d-8
            wflue(it,0) = wflue(it,0) + wflue(it,iy) / iyx
         end do
      end do
!.. Energy [J/m2/sec] & Number [#/m2/sec] for each range
!.. -> [J/micron2/fsec] & [#/micron2/fsec]
      do iy = 1, iyx
        do it = 1, itx
          do i = 1, 5
            wetot(it,i,iy) = wetot(it,i,iy) * 1.0d3
            wnumtot(it,i,iy) = wnumtot(it,i,iy) * 1.0d-27
          end do
        end do 
      end do 
!.. total beam energy [J/micron2] & total number [#/micron2] for each range
      do iy = 1, iyx
        do i = 1, 5
          wetots(1,i,iy) = wetot(1,i,iy)
          wnumtots(1,i,iy) = wnumtot(1,i,iy)
          do it = 2, itx
            wetots(it,i,iy) = wetots(it-1,i,iy) + wetot(it,i,iy)
            wnumtots(it,i,iy) = wnumtots(it-1,i,iy) + wnumtot(it,i,iy)
          end do
        end do
        do it = 1, itx
          wetot(it,6,iy) = wetot(it,1,iy)
          wnumtot(it,6,iy) = wnumtot(it,1,iy)
          wetots(it,6,iy) = wetots(it,1,iy)
          wnumtots(it,6,iy) = wnumtots(it,1,iy)
        end do
        do i = 2, 5
          do it = 1, itx
            wetot(it,6,iy) = wetot(it,6,iy) + wetot(it,i,iy)
            wnumtot(it,6,iy) = wnumtot(it,6,iy) + wnumtot(it,i,iy)
            wetots(it,6,iy) = wetots(it,6,iy) + wetots(it,i,iy)
            wnumtots(it,6,iy) = wnumtots(it,6,iy) + wnumtots(it,i,iy)
          end do
        end do
        do i = 1, 6
          do it = 1, itx
            wetot(it,i,0) = wetot(it,i,0) + wetot(it,i,iy) / iyx
            wnumtot(it,i,0) = wnumtot(it,i,0) + wnumtot(it,i,iy) / iyx
            wetots(it,i,0) = wetots(it,i,0) + wetots(it,i,iy) / iyx
            wnumtots(it,i,0) = wnumtots(it,i,0) + wnumtots(it,i,iy)/iyx
          end do
        end do
      end do
!.. spectrum [number/m2/sec/J] --> [number/micron^2/fsec/J]
      do iy = 1, iyx
        do it = 1, itx
          do ir = 1, irx
            wspec(ir,it,iy) = &
                  wspec(ir,it,iy)/smevj/(wengb(ir+1)-wengb(ir))*1.0d-27
            if( wspec(ir,it,iy) .lt. 1.0d10) wspec(ir,it,iy) = 1.0d10
            wspec(ir,it,0) = wspec(ir,it,0) + wspec(ir,it,iy) / iyx
          end do
        end do
      end do
!.. time-averaged/integrated spectrum
      do iy = 1, iyx
         do it = 2, itx
            do ir= 1, irx
               wnum = 0.5d0 * ( wspec(ir,it,iy)+wspec(ir,it-1,iy) ) * &
                      ( wtime(it)-wtime(it-1) ) 
               wspecta(ir,iy) = wspecta(ir,iy) + wnum / & 
                                ( wtime(itx)-wtime(1) )
               wspecti(ir,iy) = wspecti(ir,iy) +  wnum
           end do
         end do
         do ir= 1, irx
            wspecta(ir,0) = wspecta(ir,0) + wspecta(ir,iy) / iyx
            wspecti(ir,0) = wspecti(ir,0) + wspecti(ir,iy) / iyx
         end do
      end do
!.... output text file
!..   intensity
      open( 7, file='intensity-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'Intensity[W/cm^2] CenterPos.[micron]'
      cbuff = '(a,xx(",",f10.2))'
      write(cbuff(4:5),'(i2)') iyx
      write(7,cbuff) 'Time[fs],  Total', &
                     (woyps+(woype-woyps)/iyx*(iy-0.5),iy=1,iyx)
      cbuff = '(f8.1,xx(",",e12.4))'
      write(cbuff(7:8),'(i2)') iyx+1
      do it = 1, itx
         write(7,cbuff) wtime(it), (wint(it,iy),iy=0,iyx)
      end do
      close( 7 )
!..   beam fluence
      open( 7, file='fluence-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'Fluence[J/micron^2]  CenterPos.[micron]'
      cbuff = '(a,xx(",",f10.2))'
      write(cbuff(4:5),'(i2)') iyx
      write(7,cbuff) 'Time[fs],  Total', &
                     (woyps+(woype-woyps)/iyx*(iy-0.5),iy=1,iyx)
      cbuff = '(f8.1,xx(",",e12.4))'
      write(cbuff(7:8),'(i2)') iyx+1
      do it = 1, itx
         write(7,cbuff) wtime(it), (wflue(it,iy),iy=0,iyx)
      end do
      close( 7 )
!..   instantaneous beam energy for each range
      open( 7, file='energy-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'EnergyRange[MeV]'
      cbuff = '(a,5(",",f10.3),",",2x,a)'
      write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
      cbuff = '(f8.1,6(",",e12.4))'
      do it = 1, itx
         write(7,cbuff) wtime(it), (wetot(it,i,0),i=1,6)
      end do
      close( 7 )
!..   time integrated beam energy for each range
      open( 7, file='intenergy-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'EnergyRange[MeV]'
      cbuff = '(a,5(",",f10.3),",",2x,a)'
      write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
      cbuff = '(f8.1,6(",",e12.4))'
      do it = 1, itx
         write(7,cbuff) wtime(it), (wetots(it,i,0),i=1,6)
      end do
      close( 7 )
!..   instantaneous number
      open( 7, file='number-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'EnergyRange[MeV]'
      cbuff = '(a,5(",",f10.3),",",2x,a)'
      write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
      cbuff = '(f8.1,6(",",e12.4))'
      do it = 1, itx
         write(7,cbuff) wtime(it), (wnumtot(it,i,0),i=1,6)
      end do
      close( 7 )
!..   time integrated number
      open( 7, file='intnumber-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'EnergyRange[MeV]'
      cbuff = '(a,5(",",f10.3),",",2x,a)'
      write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
      cbuff = '(f8.1,6(",",e12.4))'
      do it = 1, itx
         write(7,cbuff) wtime(it), (wnumtots(it,i,0),i=1,6)
      end do
      close( 7 )
!... for each domain
      if( iyx .gt. 1 ) then
!
      if( iyx .le. 9 ) then
        if( ixy .eq. 1 ) then
          crange = 'y*-'
        else
          crange = 'x*-'
        end if
      else
        if( ixy .eq. 1 ) then
          crange = 'y**-'
        else
          crange = 'x**-'
        end if
      end if
!
      do iy = 1, iyx
        if( iyx .le. 9 ) then
          write( crange(2:2), '(i1)' ) iy
        else
          write( crange(2:3), '(i2.2)' ) iy
        end if
        wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
        wype = woyps + ( woype-woyps ) / iyx *  iy
!..   instantaneous beam energy for each range
        open( 7, file='energy-'//trim(crange)//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
        cbuff = '("# ",a,2x,a,2x,a,f6.1," ~ ",f6.1)'
        write(7,cbuff) cident, 'EnergyRange[MeV]', cypos, wyps, wype
        cbuff = '(a,5(",",f10.3),",",2x,a)'
        write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
        cbuff = '(f8.1,6(",",e12.4))'
        do it = 1, itx
           write(7,cbuff) wtime(it), (wetot(it,i,iy),i=1,6)
        end do
        close( 7 )
!..   time integrated beam energy for each range
        open( 7, file='intenergy-'//trim(crange)//cident(1:icidl)//'.txt',&
                                                     form='FORMATTED' )
        cbuff = '("# ",a,2x,a,2x,a,f6.1," ~ ",f6.1)'
        write(7,cbuff) cident, 'EnergyRange[MeV]', cypos, wyps, wype
        cbuff = '(a,5(",",f10.3),",",2x,a)'
        write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
        cbuff = '(f8.1,6(",",e12.4))'
        do it = 1, itx
           write(7,cbuff) wtime(it), (wetots(it,i,iy),i=1,6)
        end do
        close( 7 )
!..   instantaneous number
        open( 7, file='number-'//trim(crange)//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
        cbuff = '("# ",a,2x,a,2x,a,f6.1," ~ ",f6.1)'
        write(7,cbuff) cident, 'EnergyRange[MeV]', cypos, wyps, wype
        cbuff = '(a,5(",",f10.3),",",2x,a)'
        write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
        cbuff = '(f8.1,6(",",e12.4))'
        do it = 1, itx
         write(7,cbuff) wtime(it), (wnumtot(it,i,iy),i=1,6)
        end do
        close( 7 )
!..   time integrated number
        open( 7, file='intnumber-'//trim(crange)//cident(1:icidl)//'.txt',&
                                                     form='FORMATTED' )
        cbuff = '("# ",a,2x,a,2x,a,f6.1," ~ ",f6.1)'
        write(7,cbuff) cident, 'EnergyRange[MeV]', cypos, wyps, wype
        cbuff = '(a,5(",",f10.3),",",2x,a)'
        write(7,cbuff) 'Time[fs]',aet0,aet1,aet2,aet3,aet4,'Total'
        cbuff = '(f8.1,6(",",e12.4))'
        do it = 1, itx
         write(7,cbuff) wtime(it), (wnumtots(it,i,iy),i=1,6)
        end do
        close( 7 )
      end do
!
      end if
!..   spectrum
      open( 7, file='spectrum-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'Number[a.u.] CenterPos.[micron]'
      cbuff = '(a,xx(",",f10.2))'
      write(cbuff(4:5),'(i2)') iyx
      write(7,cbuff) 'Energy[MeV],  Total', &
                     (woyps+(woype-woyps)/iyx*(iy-0.5),iy=1,iyx)
      cbuff = '(f10.3,xx(",",e12.4))'
      write(cbuff(8:9),'(i2)') iyx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir), (wspecti(ir,iy),iy=0,iyx)
      end do
      close( 7 )
!..   time average spectrum 
      open( 7, file='avespectrum-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'Number[a.u.] CenterPos.[micron]'
      cbuff = '(a,xx(",",f10.2))'
      write(cbuff(4:5),'(i2)') iyx
      write(7,cbuff) 'Energy[MeV],  Total', &
                     (woyps+(woype-woyps)/iyx*(iy-0.5),iy=1,iyx)
      cbuff = '(f10.3,xx(",",e12.4))'
      write(cbuff(8:9),'(i2)') iyx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir), (wspecta(ir,iy),iy=0,iyx)
      end do
      close( 7 )
!..   angle distribution
      open( 7, file='angdis-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident
      cbuff = '(a)'
      write(7,cbuff) 'Angle[deg.],  f(theta),  F(theta)'
      cbuff = '(f7.2,2(",",e12.4))'
      do im = 1, imxh
         write(7,cbuff) wang(im), wadis(im), waidis(im)
      end do
      close( 7 )
!..   hwhm
      open( 7, file='hwhm-'//cident(1:icidl)//'.txt', &
                                                     form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident, 'HWHM[deg.] Time[fs]'
      cbuff = '(a,xxx(",",f8.1),",",2x,a)'
      write(cbuff(4:6),'(i3)') itx
      write(7,cbuff) 'Energy[MeV]', (wtime(it),it=1,itx),'Time-Integrated'
      cbuff = '(f10.3,xxx(",",f7.2))'
      write(cbuff(8:10),'(i3)') itx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir), (whwhmt(it,ir,0),it=1,itx), whwhm(ir,0)
      end do
      close( 7 )
!.... 
      call fr_canvas ( 3 )
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 0, iyx
         if( wtime(1).eq.0.0d0 ) wint(1,iy) = min(wint(1,iy),wint(2,iy))
         do it = 1, itx
            wint(it,iy) = log10( wint(it,iy) )
            wintmn = min( wintmn, wint(it,iy) )
            wintmx = max( wintmx, wint(it,iy) )
         end do
      end do
      wintmn = int( wintmn )
      wintmx = int( wintmx ) + 1
!.
      call fr_setaxis( 2 )
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Intensity[W/cm^2]' )
      call fr_graph2d( wtime(1), wint(1,0), itx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      if( iyx .gt. 1 ) then
         do iy = 1, iyx
            icol = mod( iy-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( wtime(1), wint(1,iy), itx, icol, 1 )
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call fr_fpchars ( 575.0d0, 490.0d0-iy*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wyps, wype, icol, 0 )
            it = ( itx-1 ) * iy / iyx + 1
            write( cdum, '(i3)' ) iy
            call fr_2dmove ( wtime(it), wint(it,iy), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 )
         end do
         call fr_gclear
         call fr_aspect3d ( 1.0d0, 1.0d0, 1.0d0, 1 )
         call fr_frame3d( wtime(1), wtime(itx), woyps, woype, &
                          wintmn, wintmx, 3 )
         call fr_xyzname( 'Time[fs]','y[micron]','Intensity[W/cm^2]' )
         call fr_profile( wint(1:itx,1:iyx), itx, iyx, -2, 1 )
         call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end if
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 0, iyx
         do it = 1, itx
            wintmn = min( wintmn, wflue(it,iy) )
            wintmx = max( wintmx, wflue(it,iy) )
         end do
      end do
!.
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Fluence[J/micron^2]' )
      call fr_graph2d( wtime(1), wflue(1,0), itx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      if( iyx .gt. 1 ) then
         do iy = 1, iyx
            icol = mod( iy-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( wtime(1), wflue(1,iy), itx, icol, 1 )
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call fr_fpchars ( 575.0d0, 490.0d0-iy*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wyps, wype, icol, 0 )
            it = ( itx-1 ) * iy / iyx + 1
            write( cdum, '(i3)' ) iy
            call fr_2dmove ( wtime(it), wflue(it,iy), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 )
         end do
         call fr_gclear
         call fr_aspect3d ( 1.0d0, 1.0d0, 1.0d0, 1 )
         call fr_frame3d( wtime(1), wtime(itx), woyps, woype, &
                          wintmn, wintmx, 3 )
         call fr_xyzname('Time[fs]','y[micron]','Fluence[J/micron^2]')
         call fr_profile( wflue(1:itx,1:iyx), itx, iyx, -2, 1 )
         call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end if
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 1, iyx
        do i = 1, 5
         if( wtime(1).eq.0.0d0 ) &
            wetot(1,i,iy) = min(wetot(1,i,iy),wetot(2,i,iy))
          do it = 1, itx
            wintmn = min( wintmn, wetot(it,i,iy) )
            wintmx = max( wintmx, wetot(it,i,iy) )
          end do
        end do
      end do
!.
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
!
        call fr_gclear
        call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
        call fr_xyname( 'Time[fs]', 'Energy[J/micron^2/fsec]' )
        do i = 1, 5
          icol = mod( i-1, 5 ) + 1
          if( icol .eq. 2 ) icol = 6
          call fr_graph2d( wtime(1), wetot(1,i,iy), itx, icol, 1 )
          if( i .eq. 1 ) then
            crange = '     < xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet1
          else if( i .eq. 2 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet1
            write( crange(8:11), '(f4.1)' ) aet2
          else if( i .eq. 3 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet2
            write( crange(8:11), '(f4.1)' ) aet3
          else if( i .eq. 4 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet3
            write( crange(8:11), '(f4.1)' ) aet4
          else
            crange = '     > xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet4
          end if
          call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
          call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
          if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
          else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
          end if
          call fr_fpchars ( 500.0d0, 490.0d0-i*15.0d0, crange, icol, &
                              1, -1, 0, 0 )
        end do
        call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end do
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 1, iyx
        do i = 1, 5
          do it = 1, itx
            wintmn = min( wintmn, wetots(it,i,iy) )
            wintmx = max( wintmx, wetots(it,i,iy) )
          end do
        end do
      end do
!.
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
!
        call fr_gclear
        call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
        call fr_xyname('Time[fs]','Time-Integrated Energy[J/micron^2]')
        do i = 1, 5
          icol = mod( i-1, 5 ) + 1
          if( icol .eq. 2 ) icol = 6
          call fr_graph2d( wtime(1), wetots(1,i,iy), itx, icol, 1 )
          if( i .eq. 1 ) then
            crange = '     < xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet1
          else if( i .eq. 2 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet1
            write( crange(8:11), '(f4.1)' ) aet2
          else if( i .eq. 3 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet2
            write( crange(8:11), '(f4.1)' ) aet3
          else if( i .eq. 4 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet3
            write( crange(8:11), '(f4.1)' ) aet4
          else
            crange = '     > xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet4
          end if
          call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
          call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
          if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
          else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
          end if
          call fr_fpchars ( 500.0d0, 490.0d0-i*15.0d0, crange, icol, &
                              1, -1, 0, 0 )
        end do
        call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end do
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 1, iyx
        do i = 1, 5
          if( wtime(1).eq.0.0d0 ) &
            wnumtot(1,i,iy) = min(wnumtot(1,i,iy),wnumtot(2,i,iy))
          do it = 1, itx
            wintmn = min( wintmn, wnumtot(it,i,iy) )
            wintmx = max( wintmx, wnumtot(it,i,iy) )
          end do
        end do
      end do
!.
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
!
        call fr_gclear
        call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
        call fr_xyname( 'Time[fs]', 'Number[#/micron^2/fsec]' )
        do i = 1, 5
          icol = mod( i-1, 5 ) + 1
          if( icol .eq. 2 ) icol = 6
          call fr_graph2d( wtime(1), wnumtot(1,i,iy), itx, icol, 1 )
          if( i .eq. 1 ) then
            crange = '     < xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet1
          else if( i .eq. 2 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet1
            write( crange(8:11), '(f4.1)' ) aet2
          else if( i .eq. 3 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet2
            write( crange(8:11), '(f4.1)' ) aet3
          else if( i .eq. 4 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet3
            write( crange(8:11), '(f4.1)' ) aet4
          else
            crange = '     > xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet4
          end if
          call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
          call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
          if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
          else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
          end if
          call fr_fpchars ( 500.0d0, 490.0d0-i*15.0d0, crange, icol, &
                              1, -1, 0, 0 )
        end do
        call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end do
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iy = 1, iyx
        do i = 1, 5
          do it = 1, itx
            wintmn = min( wintmn, wnumtots(it,i,iy) )
            wintmx = max( wintmx, wnumtots(it,i,iy) )
          end do
        end do
      end do
!.
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
!
        call fr_gclear
        call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
        call fr_xyname( 'Time[fs]', 'Time-Integrated &
                      Number[#/micron^2]' )
        do i = 1, 5
          icol = mod( i-1, 5 ) + 1
          if( icol .eq. 2 ) icol = 6
          call fr_graph2d( wtime(1), wnumtots(1,i,iy), itx, icol, 1 )
          if( i .eq. 1 ) then
            crange = '     < xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet1
          else if( i .eq. 2 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet1
            write( crange(8:11), '(f4.1)' ) aet2
          else if( i .eq. 3 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet2
            write( crange(8:11), '(f4.1)' ) aet3
          else if( i .eq. 4 ) then
            crange = 'xx.x - xx.x[MeV]'
            write( crange(1:4), '(f4.1)' ) aet3
            write( crange(8:11), '(f4.1)' ) aet4
          else
            crange = '     > xx.x[MeV]'
            write( crange(8:11), '(f4.1)' ) aet4
          end if
          call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
          call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
          if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
          else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
          end if
          call fr_fpchars ( 500.0d0, 490.0d0-i*15.0d0, crange, icol, &
                              1, -1, 0, 0 )
        end do
        call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      end do
!..
      wintmx = 0.0d0
      do iy = 0, iyx
        do it = its, itx, itd
            do ir = 1, irx
               wspec(ir,it,iy) = log10( wspec(ir,it,iy) )
               wintmx = max( wintmx, wspec(ir,it,iy) )
            end do
         end do
      end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
      icold = ( (itx-its) / itd + 1 - 1 ) / 6 + 1
!.
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
         icol  = 1
         icolc = 0
         call fr_gclear
         call fr_setaxis( 2 )
         call fr_frame2d( 0.0d0, weng(irx), wintmn, wintmx, 10 )
         call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
         do it = its, itx, itd
            call fr_graph2d( weng, wspec(1,it,iy), irx, icol, 1 )
            write( cbuff(1:8), '(f8.2)' ) wtime(it)
            call fr_fpchars ( 320.0d0+icolc*60.0d0,15.0d0+icol*15.0d0, &
                              cbuff(1:8), icol, 1, -1, 0, 0 )
            icolc = icolc + 1
            if( icolc .ge. icold ) then
               icol = icol + 1
               icolc = 0
            end if
         end do
         call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
         else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 200.0d0, 15.0d0, 'Instantaneous Spectrum', &
                        7, 1, -1, 0, 0 )
      end do
!..
      wintmx = 0.0d0
      do iy = 0, iyx
         do ir = 1, irx
            wspecta(ir,iy) = log10( wspecta(ir,iy) )
            wintmx = max( wintmx, wspecta(ir,iy) )
         end do
      end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
!.
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( 0.0d0, weng(irx), wintmn, wintmx, 10 )
      call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
      call fr_graph2d( weng, wspecta(1,0), irx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 2, 1 )
      if( iyx .gt. 1 ) then
         do iy = 1, iyx
            icol = mod( iy-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( weng, wspecta(1,iy), irx, icol, 1 )
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call fr_fpchars ( 575.0d0, 490.0d0-iy*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wyps, wype, icol, 0 )
            ir = irx / iyx * iy
            write( cdum, '(i3)' ) iy
            call fr_2dmove ( weng(ir), wspecta(ir,iy), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 ) 
         end do
      end if
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 200.0d0, 15.0d0, 'Time-Averaged Spectrum', &
                        7, 1, -1, 0, 0 )
!..
      wintmx = 0.0d0
      do iy = 0, iyx
         do ir = 1, irx
            wspecti(ir,iy) = log10( wspecti(ir,iy) )
            wintmx = max( wintmx, wspecti(ir,iy) )
         end do
      end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
!.
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( 0.0d0, weng(irx), wintmn, wintmx, 10 )
      call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
      call fr_graph2d( weng, wspecti(1,0), irx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, cxpos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, cypos, 7, 1, -1, 0, 0 )
      call yposchar( woyps, woype, 2, 1 )
      if( iyx .gt. 1 ) then
         do iy = 1, iyx
            icol = mod( iy-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( weng, wspecti(1,iy), irx, icol, 1 )
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call fr_fpchars ( 575.0d0, 490.0d0-iy*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wyps, wype, icol, 0 )
            ir = irx / iyx * iy
            write( cdum, '(i3)' ) iy
            call fr_2dmove ( weng(ir), wspecti(ir,iy), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 ) 
         end do
      end if
      call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 200.0d0, 15.0d0, 'Time-Integrated Spectrum', &
                        7, 1, -1, 0, 0 )
!....
      call fr_gend
!....
      stop
!....
  999 continue
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
      end
!----------------------------------------------------------------------
      subroutine rmycont( rdat, rxp, ryp, krx1, kmx1, kyx, &
                       rtime, royps, roype, eident, ecom, expos, eypos )
!
      implicit none
      integer :: krx1, kmx1, kyx, iy, iyxx
      real*8 :: rdat(krx1,kmx1,0:kyx), rxp(krx1,kmx1), ryp(krx1,kmx1), &
                rtime, royps, roype, arx, ayps, aype
      character :: cbuff*16, eident*(*), ecom*(*), expos*(*), eypos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = sqrt( rxp(krx1,1)**2 + ryp(krx1,1)**2 )
      iyxx = kyx
      if( kyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
         call fr_gclear
         call fr_aspect2d ( 2.0d0, 1.0d0, 1 )
         call fr_frame2d( -arx, arx, 0.0d0, arx ,13 )
         call fr_xyname( 'Ppara/m_ec', 'Pperp/m_ec' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,iy), krx1,kmx1,1,-4,0 )
         call fr_colorbar ( 215, 440, 200, 15, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, expos, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 470.0d0, eypos, 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( royps, roype, 7, 1 )
         else
            ayps = royps + ( roype-royps ) / kyx * (iy-1)
            aype = royps + ( roype-royps ) / kyx *  iy
            call yposchar( ayps, aype, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 200.0d0,15.0d0, &
                        ecom//'Dist. Ppara vs. Pperp', 7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rnycont( rdat, rxp, ryp, krx1, knx1, kyx, &
                      rtime, royps, roype, eident, ecom, expos, eypos )
!
      implicit none
      integer :: krx1, knx1, kyx, iy, iyxx
      real*8 :: rdat(krx1,knx1,0:kyx), rxp(krx1,knx1), ryp(krx1,knx1), &
                rtime, royps, roype, arx, ayps, aype
      character :: cbuff*16, eident*(*), ecom*(*), expos*(*), eypos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = sqrt( rxp(krx1,1)**2 + ryp(krx1,1)**2 )
      iyxx = kyx
      if( kyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
         call fr_gclear
         call fr_aspect2d ( 1.0d0, 1.0d0, 1 )
         call fr_frame2d( -arx, arx, -arx, arx ,13 )
         call fr_xyname( 'P/m_ec', 'P/m_ec' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,iy), &
                          krx1, knx1, 1, -4, 0 )
         call fr_colorbar ( 495, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, expos, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 470.0d0, eypos, 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( royps, roype, 7, 1 )
         else
            ayps = royps + ( roype-royps ) / kyx * (iy-1)
            aype = royps + ( roype-royps ) / kyx *  iy
            call yposchar( ayps, aype, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 200.0d0,15.0d0, &
                       ecom//'Dist. Ppara vs. Omega', 7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine eaycont( rdat, rxp, ryp, krx1, kmx1, kyx, &
                      rtime, royps, roype, eident, ecom, expos, eypos )
!
      implicit none
      integer :: krx1, kmx1, kyx, iy, iyxx
      real*8 :: rdat(krx1,kmx1,0:kyx), rxp(krx1,kmx1), ryp(krx1,kmx1), &
                rtime, royps, roype, arx, ayps, aype
      character :: cbuff*16, eident*(*), ecom*(*), expos*(*), eypos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = rxp(krx1,1)
      iyxx = kyx
      if( kyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
         call fr_gclear
         call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( 0.0d0, arx, 0.0d0, 180.0d0 ,13 )
         call fr_xyname( 'Energy[MeV]', 'Angle[deg.]' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,iy), &
                          krx1, kmx1, 1, -4, 0 )
         call fr_colorbar ( 400, 465, 200, 15, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, expos, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 470.0d0, eypos, 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( royps, roype, 7, 1 )
         else
            ayps = royps + ( roype-royps ) / kyx * (iy-1)
            aype = royps + ( roype-royps ) / kyx *  iy
            call yposchar( ayps, aype, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 200.0d0,15.0d0, ecom//'Angle vs. Energy', &
                              7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine adistgraph( rang, radis, raidis, kmx, &
                      rtime, royps, roype, eident, ecom, expos, eypos )
!
      implicit none
      integer :: kmx
      real*8 :: rang(kmx), radis(kmx), raidis(kmx), rtime,royps,roype
      character :: cbuff*16, eident*(*), ecom*(*), expos*(*), eypos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( 0.0d0, 90.0d0, 0.0d0, 1.0d0, 10 )
      call fr_xyname( 'Angle[deg]', 'Distribution[a.u.]' )
      call fr_graph2d( rang, radis, kmx, 2, 1 )
      call fr_graph2d( rang, raidis, kmx, 4, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, expos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, eypos, 7, 1, -1, 0, 0 )
      call yposchar( royps, roype, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 200.0d0,15.0d0, ecom//'Angular Distribution', &
                              7, 1, -1, 0, 0 )
      call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine yposchar( rys, rye, kcol, kbx )
!
      implicit none
      integer :: istr, ichs, kcol, kbx
      real*8 :: rys, rye
      character :: cbuff*16, cstr*8
!....
      write( cstr, '(f6.1)' ) rys
      ichs = 1
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      ichs = ichs+istr
      cbuff(ichs:ichs+2) = ' ~ '
      ichs = ichs+3
      write( cstr, '(f6.1)' ) rye
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      call fr_fpchars ( 1.0d0, 0.0d0, cbuff(1:ichs+istr-1), &
                        kcol, kbx, -1, 0, 1 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine hwhmcalc( rdat, rmue, rhwhm, rwrk, krx1, kmx1, kyx, &
                           kmxh )
!
      implicit none
      integer, parameter :: iman = 3
      real*8, parameter :: athres = 0.1d0
      integer :: krx1, kmx1, kyx, kmxh, iy, im,imx, ir,irx, iyxx, i,inx
      real*8 :: rdat(krx1,kmx1,0:kyx), rmue(krx1), &
                rhwhm(krx1-1,0:kyx), rwrk(kmxh,2), anx, anx2, at1, at2
!....
      irx = krx1 - 1
      imx = kmx1 - 1
!....
      iyxx = kyx
      if( kyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
        do ir = 1, irx
!..                                           * moving average *
          do im = 1, kmxh
            rwrk(im,1) = rdat(ir,im+kmxh,iy)
          end do
          do i = 1, iman
            rwrk(1,2) = ( rwrk(1,1)+rwrk(2,1) ) / 2.0d0
            do im = 2, kmxh-1
              rwrk(im,2) = ( rwrk(im-1,1)+rwrk(im,1)+rwrk(im+1,1) ) &
                           / 3.0d0
            end do
            rwrk(kmxh,2) = ( rwrk(kmxh-1,1)+rwrk(kmxh,1) ) / 2.0d0
            do im = 1, kmxh
              rwrk(im,1) = rwrk(im,2)
            end do
          end do
!..                                               * find max *
          anx = 0.0d0
          inx = 0
          do im = kmxh, 1, -1
             if( rwrk(im,1) .gt. anx ) then
                anx = rwrk(im,1)
                inx = im
             end if
          end do
          if( anx .le. athres ) then
             rhwhm(ir,iy) = -1.0d0
          else
!..                                               * find hwhm *
             anx2 = anx / 2.0d0
             rhwhm(ir,iy) = 90.0d0
             do im = inx, 1, -1
                if( rwrk(im,1) .le. anx2 ) then
                   at1 = acos( rmue(im+kmxh)   )
                   at2 = acos( rmue(im+kmxh+1) )
                   rhwhm(ir,iy) = ( at1 + ( at2 - at1 ) * &
                     ( anx2-rwrk(im,1) ) / ( rwrk(im+1,1)-rwrk(im,1) ) &
                     ) * 180.0d0 / acos( -1.0d0 )
                   exit
                end if
             end do
          end if
!..
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine hwhmgraph( reng, rhwhm, krx, kyx, &
                      rtime, royps, roype, eident, ecom, expos, eypos )
!
      implicit none
      integer :: krx, kyx, iy, iyxx, icol
      real*8 :: reng(krx),rhwhm(krx,0:kyx),rtime,royps,roype,ayps,aype
      character :: cbuff*16, eident*(*), ecom*(*), expos*(*), eypos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( 0.0d0, reng(krx), 0.0d0, 90.0d0, 10 )
      call fr_xyname( 'Energy[MeV]', 'HWHM[deg.]' )
      call fr_graph2d( reng, rhwhm(1,0), krx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, expos, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 470.0d0, eypos, 7, 1, -1, 0, 0 )
      call yposchar( royps, roype, 2, 1 )
      if( kyx .gt. 1 ) then
         do iy = 1, kyx
            icol = mod( iy-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( reng, rhwhm(1,iy), krx, icol, 1 )
            ayps = royps + ( roype-royps ) / kyx * (iy-1)
            aype = royps + ( roype-royps ) / kyx *  iy
            call fr_fpchars ( 575.0d0, 490.0d0-iy*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( ayps, aype, icol, 0 )
         end do
      end if
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 200.0d0,15.0d0, ecom//'HWHM', &
                              7, 1, -1, 0, 0 )
      call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rmynrm( rdat, rmue, krx1, kmx1, kyx, klcut, km )
!
      implicit none
      integer :: krx1, kmx1, kyx, klcut, km, iy, im, ir
      real*8 :: rdat(krx1,kmx1,0:kyx), rmue(kmx1), area
!....
      do iy = 1, kyx
        do im = 1, kmx1-1
          do ir = klcut, krx1-1
            if( km .eq. 2 ) then
              area = ( ir - 0.5d0 ) * &
                     ( acos(rmue(im))-acos(rmue(im+1)) )
            else
              area = 2.0d0 * acos( -1.0d0 ) * ( ir - 0.5d0 )**2 * &
                     sin( (acos(rmue(im))+acos(rmue(im+1)))/2.0d0 ) * &
                     ( acos(rmue(im))-acos(rmue(im+1)) )
            end if
            rdat(ir,im,iy) = rdat(ir,im,iy) / area
            rdat(ir,im,0) = rdat(ir,im,0) + rdat(ir,im,iy)
          end do
          do ir = 1, klcut-1
            rdat(ir,im,iy) = rdat(klcut,im,iy)
            rdat(ir,im,0) = rdat(ir,im,0) + rdat(ir,im,iy)
          end do
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rnynrm( rdat, krx1, knx1, kyx, klcut )
!
      implicit none
      integer :: krx1, knx1, kyx, klcut, iy, in, ir
      real*8 :: rdat(krx1,knx1,0:kyx), area
!....
      do iy = 1, kyx
        do in = 1, knx1-1
          do ir = klcut, krx1-1
            area = 2.0d0 * ( ir - 0.5d0 )**2 * &
                   acos( -1.0d0 ) * 2.0d0 / ( knx1-1 )
            rdat(ir,in,iy) = rdat(ir,in,iy) / area
            rdat(ir,in,0) = rdat(ir,in,0) + rdat(ir,in,iy)
          end do
          do ir = 1, klcut-1
            rdat(ir,in,iy) = rdat(klcut,in,iy)
            rdat(ir,in,0) = rdat(ir,in,0) + rdat(ir,in,iy)
          end do
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine adistcalc( rdat, krx1, kmx1, kyx, klcut, &
                            radis, raidis, kl, radisx )
!
      implicit none
      integer :: krx1, kmx1, kyx, klcut, kl, im, ir
      real*8 :: rdat(krx1,kmx1,0:kyx), radis(kl), raidis(kl), &
                radisx, wtmp, wtmp2
!....
      wtmp = 1.0d-10
      do im = 1, kl
         wtmp2 = 0.0d0
         do ir = klcut, krx1-1
            wtmp2 = wtmp2 + rdat(ir,im+kl,0)
         end do
         wtmp = max( wtmp, wtmp2 )
         radis(kl-im+1) = wtmp2
      end do
      do im = 1, kl
         radis(im) = radis(im) / wtmp
      end do
      radisx = wtmp
      raidis(1) = radis(1)
      do im = 2, kl
         raidis(im) = raidis(im-1) + radis(im)
      end do
      wtmp = max( 1.0d-10, raidis(kl) )
      do im = 1, kl
         raidis(im) = raidis(im) / wtmp
      end do
!....
      return
      end
