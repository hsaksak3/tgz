!----------------------------------------------------------------------
! plot binary file with Frames.
!
! namelist param
!   ckind  : observation kind
!   ioflag : observation flag
!   cbifntp: file name template for binary file
!   cidentb: identification character for cbifntp
!   cfrfntp: file name template for Frames plt file
!   irank  : MPI rank number (should be -1 if nonparallel run)
!   wts    : start time
!   wte    : end time
!   wxps   : start x position
!   wyps   : start y position
!   wxpe   : end x position
!   wype   : end y position
!   intx   : data interval for x
!   inty   : data interval for y
!   iminlog: minimum log data exponent (default is 5)
!   wminlog: minimum data for log (default is 1.0d-12)
!
      implicit none
      integer, parameter :: lomax = 9
      integer :: i, ii, i3, i4, i5, in, iunit, ixl, iyl, ixyl, ionl, &
                 ixps, iyps, ixpe, iype, intx, inty, ixn, iyn, iofekl, &
                 irank, ioflag, ifrm, ilog, icrsx, icrsy, icol, iminlog
      integer :: idat2(2,lomax)
      real*8, allocatable::work1(:),work2(:,:),work22(:,:), &
                           work3(:,:,:),work4(:,:,:,:),work5(:,:,:,:,:)
      real*8  :: wxps, wyps, wxpe, wype, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wminlog, wteps=0.05
      real*8  :: wmax,wdat2(6,lomax),wdat22(lomax,lomax),wdat23(2,lomax)
      real*8  :: wxm, wxx, wym, wyx, work
      character ckind*5, chead*4, cident*16, cidentb*16, cform*32
      character cbifntp*64, cfrfntp*64, cfile*128, clabel*20, crange*32
!.
      namelist /param/ ckind, ioflag, cbifntp, cidentb, cfrfntp, irank,&
                       wts, wte, wxps, wyps, wxpe, wype, intx, inty, &
                       iminlog, wminlog
!....
      ckind   = ' '
      ioflag  = 5
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cfrfntp = '&K-&I-###'
      irank   = -1
      wts     = 0.0
      wte     = 999999.0
      wxps    = -1000.0
      wyps    = -1000.0
      wxpe    = 1000.0
      wype    = 1000.0
      intx    = 1
      inty    = 1
      iminlog = 5
      wminlog = 1.0d-12
!..
      read(*,param)
      write(*,param)
!....
      if( ckind .eq. 'fde' ) then
         iunit = 20
      else if( ckind .eq. 'fdi' ) then
         iunit = 21
      else if( ckind .eq. 'fea' ) then
         iunit = 22
      else if( ckind .eq. 'fer' ) then
         iunit = 23
      else if( ckind .eq. 'fba' ) then
         iunit = 24
      else if( ckind .eq. 'fbr' ) then
         iunit = 25
      else if( ckind .eq. 'pem' ) then
         iunit = 26
      else if( ckind .eq. 'fede' ) then
         iunit = 27
      else if( ckind .eq. 'fje' ) then
         iunit = 28
      else if( ckind .eq. 'fji' ) then
         iunit = 29
      else if( ckind .eq. 'pim' ) then
         iunit = 30
      else if( ckind .eq. 'fek' ) then
         iunit = 31
      else if( ckind .eq. 'fte' ) then
         iunit = 33
      else if( ckind .eq. 'pee' ) then
         iunit = 34
      else if( ckind .eq. 'pie' ) then
         iunit = 35
      else if( ckind .eq. 'fedi' ) then
         iunit = 36
      else if( ckind .eq. 'peph' ) then
         iunit = 37
      else if( ckind .eq. 'piph' ) then
         iunit = 38
      else if( ckind .eq. 'fdc' ) then
         iunit = 41
      else if( ckind .eq. 'fjt' ) then
         iunit = 42
      else
         write( 0, * ) 'ERROR: invalid obs. kind ', ckind
         stop
      end if
      ifrm = mod( ioflag, 10 )
      ilog = mod( ioflag/10, 10 )
      icrsx = mod( ioflag/100, 100 )
      icrsy = mod( ioflag/10000, 100 )
!....
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cbifntp,irank,iunit, cidentb, &
                                        'fE'//ckind(4:4), cfile )
      else
         call fntpcnv ( cbifntp,irank,iunit, cidentb, ckind, cfile )
      end if
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      if( ckind .eq. 'pem' ) then
         read( iunit ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         allocate( work3(ixl,3,iyl), work4(ixl,ixl,3,iyl) )
!
      else if( ckind .eq. 'pee' ) then
         read( iunit ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         allocate( work2(ixl,iyl) )
!
      else if( ckind .eq. 'peph' ) then
         read( iunit ) chead, cident, ixl, iyl, ixyl, &
                                        ((wdat2(i,ii),i=1,6),ii=1,ixyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, &
                                        ((wdat2(i,ii),i=1,6),ii=1,ixyl)
         allocate( work3(ixl,iyl,ixyl) )
!
      else if( ckind .eq. 'pim' ) then
         read( iunit ) chead, cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4),i=1,iyl)
         allocate( work4(ixl,3,iyl,ionl), work5(ixl,ixl,3,iyl,ionl) )
!
      else if( ckind .eq. 'pie' ) then
         read( iunit ) chead, cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         allocate( work3(ixl,iyl,ionl) )
!
      else if( ckind .eq. 'piph' ) then
         read( iunit ) chead, cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl)
         write( *, * ) chead, ' ', cident, ixl, iyl, ixyl, ionl, &
                                    ((wdat22(i,ii),i=1,2),ii=1,ionl), &
                                    ((wdat2(i,ii),i=1,6),ii=1,ixyl)
         allocate( work4(ixl,iyl,ixyl,ionl) )
!
      else if( ckind .eq. 'fek' ) then
         read( iunit ) chead, cident, wmax, ixyl, &
       ((idat2(i,ii),i=1,2),ii=1,ixyl), ((wdat2(i,ii),i=1,4),ii=1,ixyl)
         write( *, * ) chead, ' ', cident, wmax, ixyl, &
       ((idat2(i,ii),i=1,2),ii=1,ixyl), ((wdat2(i,ii),i=1,4),ii=1,ixyl)
!
      else 
!.
         if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
             ckind .eq. 'fedi' ) then
            read( iunit ) chead,cident,ixyl,ixl,iyl, &
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl)
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,&
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl)
            if( ckind .eq. 'fji' ) then
               allocate( work3(3,ixyl,ionl), work2(ixyl,3), &
                         work1(ionl) )
            else
               allocate( work2(ixyl,ionl) )
            end if
         else
            read( iunit ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
            write( *, * ) chead,' ', cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
            if( ckind .eq. 'fje' ) then
               allocate( work3(3,ixyl,3), work2(ixyl,3) )
            else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                     ckind .eq. 'fjt' ) then
!                               * check instantaneous flag for fer/fbr *
               if( chead(3:3) .eq. 'R' ) then
                  allocate( work3(3,ixyl,2), work22(ixyl,3) )
               else
                  allocate( work2(3,ixyl), work22(ixyl,3) )
               end if
            else if( ckind .eq. 'fte' ) then
               allocate( work2(ixyl,2) )
!                                                        * other cases *
            else
               allocate( work1(ixyl) )
            end if
         end if
!.
         ixps = ( wxps + wx0 ) / wxmic
         if( ixps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid xps', wxps, ixps
            write( 0, * ) '###        : ixps is assumed as 1'
            ixps = 1
         end if
         ixpe = ( wxpe + wx0 ) / wxmic
         if( ixpe .gt. ixl ) then
            write( 0, * ) '### WARNING: invalid xpe', wxpe, ixpe
            write( 0, * ) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
         if( ixps .gt. ixpe ) then
            write( 0, * ) '### ERROR: xps gt xpe', wxps, wxpe
            stop
         end if
         iyps = ( wyps + wy0 ) / wymic
         if( iyps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid yps', wyps, iyps
            write( 0, * ) '###        : iyps is assumed as 1'
            iyps = 1
         end if
         iype = ( wype + wy0 ) / wymic
         if( iype .gt. iyl ) then
            write( 0, * ) '### WARNING: invalid ype', wype, iype
            write( 0, * ) '###        : iype is assumed as', iyl
            iype = iyl
         end if
         if( iyps .gt. iype ) then
            write( 0, * ) '### ERROR: yps gt ype', wyps, wype
            stop
         end if
!.
         ixn  = ( ixpe - ixps ) / intx + 1
         if( ixn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid x interval', &
	                  ixps,ixpe,intx
            stop
         end if
         iyn  = ( iype - iyps ) / inty + 1
         if( iyn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid y interval', &
	                  iyps,iype,inty
            stop
         end if
!..
         write( *, * ) '----- ixps, ixpe, iyps, iype = ', &
	                      ixps, ixpe, iyps, iype
         write( *, * ) '----- ixn, iyn = ', ixn, iyn
      end if
!....
      write( *, * ) '----- header: ', chead, ', ident: ', cident
!..
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cfrfntp, irank, 1, cident, &
                                        'fE'//ckind(4:4), cfile )
      else
         call fntpcnv ( cfrfntp, irank, 1, cident, ckind, cfile )
      end if
      call frames_init
      call frames_file ( cfile, 1, ifrm )
!.......................................................................
      iofekl = 0
    1 continue
         if( ckind .eq. 'pem' ) then
            read( iunit, end=99 ) wtime, &
                        (((work3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl), &
             ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
!
         else if( ckind .eq. 'pee' ) then
            read( iunit, end=99 ) wtime, work2
!
         else if( ckind .eq. 'peph' ) then
            read( iunit, end=99 ) wtime, work3
!
         else if( ckind .eq. 'pim' ) then
            read( iunit, end=99 ) wtime, &
                (( ((work4(i,i3,i4,i5),i=1,ixl),i3=1,3), &
                  (((work5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
!
         else if( ckind .eq. 'pie' ) then
            read( iunit, end=99 ) wtime, work3
!
         else if( ckind .eq. 'piph' ) then
            read( iunit, end=99 ) wtime, work4
!
         else if( ckind .eq. 'fek' ) then
            iofekl = iofekl + 1
            if( iofekl .gt. ixyl ) iofekl = 1
            ixl = idat2(1,iofekl)
            iyl = idat2(2,iofekl)
            allocate( work2(ixl,8), work22(iyl,8), work3(ixl,iyl,4) )
            do i4 = 1, 4
               i5 = i4*2 - 1
               read( iunit, end=99 ) wtime, in, in, &
                       (work2(i,i5),i=1,ixl),(work22(i,i5),i=1,iyl), &
                      ((work3(i,ii,i4),i=1,ixl),ii=1,iyl), &
                       (work2(i,i5+1),i=1,ixl),(work22(i,i5+1),i=1,iyl)
            end do
!
         else 
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
                ckind .eq. 'fedi' ) then
               if( ckind .eq. 'fji' ) then
                  read( iunit, end=99 ) wtime, work3, work1
               else
                  read( iunit, end=99 ) wtime, work2
               end if
            else
               if( ckind .eq. 'fje' ) then
                  read( iunit, end=99 ) wtime, work3, work
               else if( ckind .eq. 'fjt' ) then
                  read( iunit, end=99 ) wtime, work2, work
               else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                        ckind .eq. 'fte' ) then
                  if( chead(3:3) .eq. 'R' ) then
                     read( iunit, end=99 ) wtime, work3
                  else
                     read( iunit, end=99 ) wtime, work2
                  end if
!                                                       * other cases *
               else
                  read( iunit, end=99 ) wtime, work1
               end if
            end if
         end if
!...
         if( wtime .lt. wts-wteps ) then
	    if( ckind .eq. 'fek' ) deallocate( work2, work22, work3 )
	    go to 1
         end if
!...
         if( wtime .gt. wte+wteps ) then
            write( *, * ) '----- end at ', wtime
            go to 2
         end if
!...
         write( *, * ) '----- time = ', wtime
!..
         if( ckind .eq. 'pem' ) then
           do ii = 1, iyl
             call o2pdraw6 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, &
                         work3(1,1,ii), work3(1,2,ii), work3(1,3,ii), &
                   work4(1,1,1,ii), work4(1,1,2,ii), work4(1,1,3,ii), &
                   ixl, wdat2(1,ii), &
                  wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), wdat2(5,ii), &
                     'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pem' ) 
           end do
!
         else if( ckind .eq. 'pee' ) then
           do ii = 1, iyl
             call o2pdraw1 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, work2(1,ii), ixl, wdat2(1,ii), &
                  wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), wdat2(5,ii), &
                                         'MeV', 'number[a.u.]', 'pee' )
           end do
!
         else if( ckind .eq. 'peph' ) then
           do ii = 1, ixyl
             call o2pdrawph ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, work3(1,1,ii), ixl, iyl, &
                       wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), &
                       wdat2(4,ii), wdat2(5,ii), wdat2(6,ii), &
                      'x[micron]', 'Ux/c', 'peph' )
           end do
!
         else if( ckind .eq. 'pim' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
             do ii = 1, iyl
               call o2pdraw6 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, &
                work4(1,1,ii,i4), work4(1,2,ii,i4), work4(1,3,ii,i4), &
          work5(1,1,1,ii,i4), work5(1,1,2,ii,i4), work5(1,1,3,ii,i4), &
                  ixl, wdat22(ii,i4), &
                  wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), &
             'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pim'//clabel ) 
             end do
           end do
!
         else if( ckind .eq. 'pie' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
             do ii = 1, iyl
               call o2pdraw1 ( cident, wtime, wminlog, iminlog, &
                         1, ilog, work3(1,ii,i4), ixl, wdat22(ii,i4), &
                  wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), wdat2(4,ii), &
                                 'MeV', 'number[a.u.]', 'pie'//clabel )
             end do
           end do
!
         else if( ckind .eq. 'piph' ) then
           do i4 = 1, ionl
             call o2ionlabel ( i4, wdat22(1,i4), wdat22(2,i4), clabel )
             do ii = 1, ixyl
               call o2pdrawph ( cident, wtime, wminlog, iminlog, &
                         1, ilog, 3, work4(1,1,ii,i4), ixl, iyl, &
                       wdat2(1,ii), wdat2(2,ii), wdat2(3,ii), &
                       wdat2(4,ii), wdat2(5,ii), wdat2(6,ii), &
                      'x[micron]', 'Ux/c', 'piph'//clabel )
             end do
           end do
!
         else if( ckind .eq. 'fek' ) then
            if( iofekl .ge. 1 ) then
               write( *, * ) '----- iofekl = ', iofekl
            end if
            do i4 = 1, 4
              i5 = i4*2 - 1
              if( i4 .eq. 1 ) then
                 clabel = 'fek(Ex)'
              else if( i4 .eq. 2 ) then
                 clabel = 'fek(Ey)'
              else if( i4 .eq. 3 ) then
                 clabel = 'fek(Ez)'
              else
                 clabel = 'fek(|E|)'
              end if
              call o2fdrawk ( cident, wtime, 1, ilog, 3, &
                   work2(1,i5), work22(1,i5), work3(1,1,i4), &
                   work2(1,i5+1), work22(1,i5+1), ixl, iyl, & 
                   wdat2(1,iofekl), wdat2(2,iofekl), &
                   wdat2(3,iofekl), wdat2(4,iofekl), &
                   'Kx/K-L', 'Ky/K-L', 'number[a.u.]', clabel )
            end do
            deallocate( work2, work22, work3 )
!
         else if( ckind .eq. 'fji' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              work2(:,1) = work3(1,:,i4)
              work2(:,2) = work3(2,:,i4)
              work2(:,3) = work3(3,:,i4)
              call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
                        work1(i4), work2(1,1), work2(1,2), work2(1,3), &
                        ixl, iyl, wxmic, wx0, wymic, wy0, &
                       'fjxi'//clabel, 'fjyi'//clabel, 'fjzi'//clabel, &
                     'fjxyi'//clabel, 'fjyzi'//clabel, 'fjxzi'//clabel )
            end do
!
         else if( ckind .eq. 'fdi' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                              1, ilog, 3, icrsx, icrsy, &
                              work2(1,i4), ixl, iyl, &
                              wxmic, wx0, wymic, wy0, 'fdi'//clabel )
            end do
!
         else if( ckind .eq. 'fedi' ) then
            do i4 = 1, ionl 
              call o2ionlabel ( i4, wdat23(1,i4), wdat23(2,i4), clabel )
              call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                              1, 0, 1, 0, 0, &
                              work2(1,i4), ixl, iyl, &
                              wxmic, wx0, wymic, wy0, 'fedi'//clabel )
            end do
!
         else if( ckind .eq. 'fje' ) then
            work2(:,1) = work3(1,:,1)
            work2(:,2) = work3(2,:,1)
            work2(:,3) = work3(3,:,1)
            call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
                    work, work2(1,1), work2(1,2), work2(1,3), &
                    ixl, iyl, wxmic, wx0, wymic, wy0, &
                    'fjxe', 'fjye', 'fjze', 'fjxye', 'fjyze', 'fjxze' )
            work2(:,1) = work3(1,:,2)
            work2(:,2) = work3(2,:,2)
            work2(:,3) = work3(3,:,2)
            call o2fdraw5 ( cident, wtime, 1, 3, icrsx, 1, &
                    work, work2(1,1), work2(1,2), work2(1,3), &
                    ixl, iyl, wxmic, wx0, wymic, wy0, &
  'fjxe[h]', 'fjye[h]', 'fjze[h]', 'fjxye[h]', 'fjyze[h]', 'fjxze[h]' )
            work2(:,1) = work3(1,:,3)
            work2(:,2) = work3(2,:,3)
            work2(:,3) = work3(3,:,3)
            call o2fdraw5 ( cident, wtime, 1, 3, icrsx, 4, &
                    work, work2(1,1), work2(1,2), work2(1,3), &
                    ixl, iyl, wxmic, wx0, wymic, wy0, &
  'fjxe[c]', 'fjye[c]', 'fjze[c]', 'fjxye[c]', 'fjyze[c]', 'fjxze[c]' )
!
         else if( ckind .eq. 'fjt' ) then
            work22(:,1) = work2(1,:)
            work22(:,2) = work2(2,:)
            work22(:,3) = work2(3,:)
            call o2fdraw5 ( cident, wtime, 1, 2, icrsx, 2, &
                    work, work22(1,1), work22(1,2), work22(1,3), &
                    ixl, iyl, wxmic, wx0, wymic, wy0, &
                    'fjxt', 'fjyt', 'fjzt', 'fjxyt', 'fjyzt', 'fjxzt' )
         else if( ckind .eq. 'fte' ) then
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                            1, 0, 1, 0, 0, work2(1,1), ixl, iyl, &
                            wxmic, wx0, wymic, wy0, 'fte[MeV] ' )
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                            1, 0, 1, 0, 0, work2(1,2), ixl, iyl, &
                            wxmic, wx0, wymic, wy0, 'fpe[Gbar] ' )
!
         else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr') then
            if( chead(3:3) .eq. 'R' ) then
               clabel = 'r'
               if( ckind .eq. 'fbr' ) clabel(2:5) = '[MG]'
               work22(:,1) = work3(1,:,1)
               work22(:,2) = work3(2,:,1)
               work22(:,3) = work3(3,:,1)
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                           work22(1,1), work22(1,2), work22(1,3), &
                           ixl, iyl, wxmic, wx0, wymic, wy0, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
               clabel = 'r(inst.)'
               if( ckind .eq. 'fbr' ) clabel(9:12) = '[MG]'
               work22(:,1) = work3(1,:,2)
               work22(:,2) = work3(2,:,2)
               work22(:,3) = work3(3,:,2)
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                           work22(1,1), work22(1,2), work22(1,3), &
                           ixl, iyl, wxmic, wx0, wymic, wy0, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
            else
               clabel = 'r'
               if( ckind .eq. 'fbr' ) clabel(2:5) = '[MG]'
               work22(:,1) = work2(1,:)
               work22(:,2) = work2(2,:)
               work22(:,3) = work2(3,:)
               call o2fdraw3 ( cident, wtime, 1, 2, icrsx, icrsy, &
                           work22(1,1), work22(1,2), work22(1,3), &
                           ixl, iyl, wxmic, wx0, wymic, wy0, &
                     ckind(1:2)//'x'//clabel, ckind(1:2)//'y'//clabel, &
                     ckind(1:2)//'z'//clabel )
            end if
!                                                       * other cases *
         else
            icol = 1
            if( ckind .eq. 'fde' ) icol = 3
            if( ckind .eq. 'fdc' ) icol = 2
            clabel = ckind
            if( ckind .eq. 'fba' ) clabel(4:7) = '[MG]'
            call o2fdraw1 ( cident, wtime, wminlog, iminlog, &
                        1, ilog, icol, icrsx, icrsy, work1, ixl, iyl, &
                        wxmic, wx0, wymic, wy0, clabel )
         end if
!...
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!...
    2 continue
      call frames_term
!....
      stop
      end
