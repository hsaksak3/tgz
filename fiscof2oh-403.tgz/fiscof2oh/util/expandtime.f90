!------------------------------------------------------
! Expand time of p[ei]dfp data
!
      implicit none
      real, parameter :: wex = 3.0
      character, parameter :: cex*2 = 'x3'
      integer :: ipos
      real :: wtime1, wtime2
      character :: cbuff*128
!
    1 continue
      read( *, '(a128)', end=999 ) cbuff
      if( cbuff(1:30) .eq. 'ident character             = ' ) then
         ipos = len_trim(cbuff)
         cbuff(ipos+1:ipos+len_trim(cex)) = trim(cex)
         write(0,*) 'ident character: ',cbuff(31:ipos),' to ', &
                                        cbuff(31:ipos+len_trim(cex))
      else if( cbuff(1:30) .eq. 'observation interval        = ' ) then
         read( cbuff(31:41), '(f11.3)' ) wtime1
         wtime2 = wtime1 * wex
         write( cbuff(31:41), '(f11.3)' ) wtime2
         write(0,*) 'interval expanded:',wtime1,' to', wtime2
      else if( cbuff(1:8) .eq. ' time = ' ) then
         read( cbuff(9:20), '(f12.3)' ) wtime1
         wtime2 = wtime1 * wex
         write( cbuff(9:20), '(f12.3)' ) wtime2
         write(0,*) 'time expanded:',wtime1,' to', wtime2
      end if
      write( *, '(a)' ) trim(cbuff)
      go to 1
  999 continue
      stop
      end
