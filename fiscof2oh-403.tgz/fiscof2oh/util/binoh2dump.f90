!----------------------------------------------------------------------
! dump cross section of binary files of OhHelp version
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   cdufntp: file name template for dump file
!          : default is '&K-&I-%%.txt'
!          : &I is replaced by identification character in binary file
!          : &K is replaced by header in binary file
!          : %% is replaced by file sequence number, not unit#
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   iseq   : initial sequence number of dump file (default is 0)
!   wxcs   : x cross section position
!
!----------------------------------------------------------------------
      use parameter, only:lionspx
      implicit none
      integer, parameter :: iun0 = 9
      integer :: i, il, ico, idn, iunit, ixl, iyl, ixyl, intt, &
                 ixcs, iy, irank, icnt, ion, iseq
      real*4, allocatable :: wwrk(:,:,:,:)
      real*8, allocatable :: awrk(:,:,:,:)
      real*8  :: wxcs, wyp, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, cform*32, &
                 cbifntp*64, cdufntp*64, cfile*128, ctype*6, cbuff*80, &
                 ctitle(lionspx)*32
!
      integer :: iun, ir, isize, ixas, ixae, ixal, iyas, iyae, iyal
      integer :: idivx, idivy, ixals, iyals, i0s, ipixel
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:)
      real*8  :: wx0s, wy0s
      real*8, allocatable :: gwrk(:,:,:,:)
      character cidents*16
!.
      namelist /param/ ckind, cbifntp, cidentb, cdufntp, &
               wts, wte, iseq, wxcs
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cdufntp = '&K-&I-%%.txt'
      wts     = 0.0
      wte     = 9999.0
      iseq    = 0
      wxcs    = 0.0
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'fde' )
         iun = 20
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Density'
      case( 'fdi' )
         iun = 21
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Density'
      case( 'fea' )
         iun = 22
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Electric_Field'
      case( 'fer' )
         iun = 23
         ico = 3
         idn = 1
         ctitle(1) = 'Electric_Field'
      case( 'fba' )
         iun = 24
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Magnetic_Field'
      case( 'fbr' )
         iun = 25
         ico = 3
         idn = 1
         ctitle(1) = 'Magnetic_Field'
      case( 'fje' )
         iun = 28
         ico = 3
         idn = 3
         ctitle(1) = 'Electron_Current'
         ctitle(2) = 'Electron_Current(hot)'
         ctitle(3) = 'Electron_Current(cold)'
      case( 'fji' )
         iun = 29
         ico = 3
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Current'
      case( 'fjt' )
         iun = 42
         ico = 3
         idn = 1
         ctitle(1) = 'Total_Current'
      case( 'fede' )
         iun = 27
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Energy_Density'
      case( 'fedi' )
         iun = 36
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Energy_Density'
      case( 'fdc' )
         iun = 41
         ico = 1
         idn = 1
         ctitle(1) = 'Charge_Density'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!..
      i0s = 0
      ipixel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, ckind, cfile ) 
      end if 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      if( ion .eq. 0 ) then
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0, &
                     irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0, &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
      else
         read(iunit) chead, cident, ixyl, ixl, iyl, &
                     wxmic, wx0, wymic, wy0, &
                     idn, (aionam(i),aionaz(i),i=1,idn), &
                     irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
         write(*,*) chead, ' ', cident, ixyl, ixl, iyl, &
                    wxmic, wx0, wymic, wy0, &
                    idn, (aionam(i),aionaz(i),i=1,idn), &
                    irank,idivx,idivy,ixal,ixas,ixae,iyal,iyas,iyae
      end if
!..
      if( ixyl .ne. -1 ) then
         if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) ) then
           write(0,*) '### ERROR: data size mismatch', &
                      ixas,ixae,iyas,iyae 
           stop
         end if
      end if
!..
      if( ir-1 .eq. 0 ) then
!.                              * check instantaneous flag for fer/fbr *
         if( chead(1:3) .eq. 'feR' ) then
            idn = 2
            ctitle(2) = 'Electric_Field(inst.)'
         else if( chead(1:3) .eq. 'fbR' ) then
            idn = 2
            ctitle(2) = 'Magnetic_Field(inst.)'
         end if
!
         isize = idivx * idivy
         ixals = ixal
         iyals = iyal
         cidents = cident
         allocate( ixass(isize), ixaes(isize), ixans(isize), &
                   iyass(isize), iyaes(isize), iyans(isize) )
         allocate( gwrk(ico,ixal,iyal,idn) )
!.
      else if( ir .le. isize ) then
         if( cident .ne. cidents ) then
            write(0,*) '### ERROR: cident mismatch ', cident, cidents
            stop
         end if
         if( ixal.ne.ixals .or. iyal.ne.iyals ) then
            write(0,*) '### ERROR: total size mismatch', &
                       ixal,ixals,iyal,iyals
            stop
         end if
      end if
!..
      if( i0s .eq. 0 .and. ixyl .ne. -1 ) then
         wx0s = wx0
         wy0s = wy0
         i0s = 1
      end if
!..
      ixass(ir) = ixas
      ixaes(ir) = ixae
      ixans(ir) = ixae - ixas + 1
      iyass(ir) = iyas
      iyaes(ir) = iyae
      iyans(ir) = iyae - iyas + 1
!
      ipixel = ipixel + ixans(ir)*iyans(ir)
!..
      if( ir .eq. isize ) exit
!..
      end do
!...
      if( ipixel .ne. ixal*iyal ) then
         write(0,*) '### ERROR: total #pixel mismatch', &
                       ipixel,ixal,iyal
         stop
      end if
!...
      ixcs = ( wxcs + wx0s ) / wxmic
      if( ixcs .lt. 1 .or. ixcs .gt. ixal ) then
         write(0,*) '### ERROR: invalid xcs', wxcs, ixcs
         stop
      end if
!..
      write(*,*) '----- header: ', chead, ', ident: ', cident
!..
      if( ion .eq. 1 ) then
         do i = 2, idn
            ctitle(i) = ctitle(1)
         end do
         il = len_trim( ctitle(1) )
         do i = 1, idn
            call o2ionlabel( i, aionam(i), aionaz(i), ctitle(i)(il+1:) )
         end do
      end if
!....
      icnt = iseq
!....
    1 continue
!...
         do ir = 1, isize
!...
         iunit = iun0 + ir
!...
         if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 ) then
            allocate( awrk(ico,ixans(ir),iyans(ir),idn) )
            read(iunit, end=99) wtime, awrk
            gwrk(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),:) = &
                                                         awrk(:,:,:,:)
            deallocate( awrk )
         end if
!.
         end do
!...
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- seq#, time = ', icnt, wtime
!.
         call fntpcnv ( cdufntp, -1, icnt, cident, chead, cfile )
!.
         open(7, file=cfile, form='FORMATTED' )
         write(7,'(a)') '# dump cross section'
         write(cbuff,'(f8.2)') wtime 
         write(7,'(a)') '# '//trim(cident)//',time='//trim(adjustl(cbuff))
         write(7,'(a,e12.4)') '# x pos =', (ixcs-1)*wxmic-wx0s
         cbuff = '(e12.4, x('','', e12.4))'
         write(cbuff(9:9),'(i1)') ico 
         do i = 1, idn
            write(7,'(a)') '# '//trim(ctitle(i))
            do iy = 1, iyal
               write(7, cbuff ) (iy-1)*wymic-wy0s,gwrk(:,ixcs,iy,i)
            end do
         end do
         close(7)
!.
         icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
