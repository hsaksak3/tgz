c----------------------------------------------------------------------
c plot table data
c
      implicit real*8(a)
      parameter( lt = 1000, ln = 50 )
      dimension adata(lt,ln), axr(lt), ayr(lt), ion(ln)
      character*32 ctitle(ln)
      character*1023 cbuff
c....
      read( *, '(a)' ) cbuff
c.
      do i = 1023,1,-1
         if( .not. ( cbuff(i:i) .eq. ' ' .or. 
     $               cbuff(i:i) .eq. char(0) ) ) then
            iend = i+1
            cbuff(iend:iend) = ','
            go to 1
         end if
      end do
    1 continue
      in = 0
      is = 1
      do i = 1, iend
         if( cbuff(i:i) .eq. ',' ) then
            in = in + 1
            ctitle(in) = cbuff(is:i-1)
            write(*,*) ctitle(in)
            if( cbuff(is:is) .eq. '*' ) then
               ion(in) = 0
            else
               ion(in) = 1
            end if
            is = i+1
         end if
      end do
      write( *, * ) 'in = ', in
      it = 1
    2 continue
         read( *, *, end=3 ) ( adata(it,i),i=1,in )
         it = it + 1
         go to 2
    3 continue
      it = it - 1
      write( *, * ) 'it = ', it
c...
      if( ctitle(1)(1:5) .ne. 'angle' ) then
c
      aintmn = 1.0d30
      aintmx = -1.0d30
      do ii = 2, in
         do i = 1, it
            if( ion(ii) .eq. 1 ) then
c$$               write(*,*) i,ii,adata(i,ii)
               adata(i,ii) = log10( max( adata(i,ii), 1.0d-20 ) )
               aintmn = min( aintmn, adata(i,ii) )
               aintmx = max( aintmx, adata(i,ii) )
            end if
         end do
      end do
      aintmx = int( aintmx ) + 1
      aintmn = max( int( aintmn ), int( aintmx ) - 8 )
      do ii = 2, in
         do i = 1, it
            if( ion(ii) .eq. 1 ) then
               adata(i,ii) = max( aintmn, adata(i,ii) )
            end if
         end do
      end do
c.
      end if
c....
      call fr_ginit
c..
      call fr_opencanvas( 1, 'table', 11 )
c..
      if( ctitle(1)(1:5) .ne. 'angle' ) then
         call fr_setaxis( 2 )
         call fr_frame2d( 0.0d0, adata(it,1), aintmn, aintmx, 10 )
      else
         call fr_frame2d( 0.0d0, adata(it,1), 0.0d0, 1.0d0, 10 )
      end if
      icol = 1
      ipos = 1
      irep = 0
      do i = 2, in
         if( ion(i) .eq. 1 ) then
            icol = icol + 1
            if( icol .gt. 6 ) then
               icol = 2
               irep = irep + 1
            end if
            ipos = ipos + 1
            call fr_graph2d( adata(1,1), adata(1,i), it, icol, 1 )
            do ii = 1, irep
               do iii = 1, it
                  axr(iii) = adata(iii,1)
                  ayr(iii) = adata(iii,i) + (aintmx-aintmn)/400.0d0*ii
               end do
               call fr_graph2d( axr, ayr, it, icol, 1 )
               do iii = 1, it
                  axr(iii) = adata(iii,1) + adata(it,1)/600.0d0*ii
                  ayr(iii) = adata(iii,i)
               end do
               call fr_graph2d( axr, ayr, it, icol, 1 )
            end do
            ay = ipos*15.0d0 - 15.0d0
            call fr_fpchars ( 5.0d0, ay, ctitle(i), icol, 1, -1, 0, 0 )
            do ii = 1, irep
               call fr_fpchars ( 5.0d0+ii, ay, ctitle(i), icol, 
     $                           1, -1, 0, 0 )
               call fr_fpchars ( 5.0d0, ay+ii, ctitle(i), icol, 
     $                           1, -1, 0, 0 )
            end do
         end if
      end do
      call fr_xyname( ctitle(1), ' ' )
      call fr_gpause
c...
      call fr_gend
c....
      stop
      end
