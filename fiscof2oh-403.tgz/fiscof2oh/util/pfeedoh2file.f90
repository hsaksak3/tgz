!----------------------------------------------------------------------
! convert pfeed files written by OhHelp version to single file (2D)
!
! namelist param
!   cfpfntpe: file name template for pfeed file
!   cident  : identification character for template
!   iloc    : location number (should be -1 if total number is 1)
!   wopfeedm: minimum number of particles for output (default is 1)
! bellow parameters are needed for restart data
!   imx     : division number
!   inx     : # of mesh for omega
!   irx     : # of mesh for momentum
!   iyx     : # of division for y ( or x )
!
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: iun0 = 9
      integer :: ira, isize, iloc, iun, itmp, irx, imx, inx, iyx, &
                 id1, id2, id3, id4, iend, irest
      integer, allocatable :: itx(:)
      real*8  :: wopfeedm, wtmp, wnpnc, wtime, wtotal, wnum, wn, wnp
      real*8, allocatable :: wpfeed(:,:,:,:)
      character :: cfpfntpe*64, cbuff*80, cident*16, cfile*128, &
                   cidents*16
!.
      namelist /param/ cfpfntpe, cident, iloc, wopfeedm, &
                       imx, inx, irx, iyx
!....
      cfpfntpe = '&K-&I-%-###.dat'
      cident   = 'xxx'
      iloc     = -1
      wopfeedm = 1.0d0
      imx = -1
      inx = -1
      irx = -1
      iyx = -1
!..
      read(*,param)
      write(0,param)
!....                                              * search all files *
      do ira = 1, 999999
        iun = iun0 + ira
        call fntpcnv ( cfpfntpe, ira-1, iloc, cident, 'pfeed', cfile )
        open( iun, file=cfile, form='FORMATTED', status='OLD', err=1 )
      end do
    1 continue
      isize = iun - 1 - iun0
      if( isize .eq. 0 ) &
        open( iun, file=cfile, form='FORMATTED', status='OLD' )
      write(0,*) 'isize = ', isize
      call fntpcnv ( cfpfntpe, -1, iloc, cident, 'pfeed', cfile )
      open( 7, file=cfile, form='FORMATTED' )
!....                                                       * headers *
! ------ start 1/2 -------
! ident character             = i20tmpulse       
! Sn                          =      36      
!  or
! Equal Division              =      32      
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       1       
!  or
! observation position of y   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! # of division for x         =       1       
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
!..                              * read headers and check consistency *
      wnpnc = 0.0d0
      do ira = 1, isize
        iun = iun0 + ira
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            if( cbuff(8:12) .eq. 'start' ) then
              irest = 0
            else
              irest = 1
              if( imx .lt. 1 ) then
                write(0,*) '### ERROR: imx not specified', imx
                stop
              end if
              if( inx .lt. 1 ) then
                write(0,*) '### ERROR: inx not specified', inx
                stop
              end if
              if( irx .lt. 1 ) then
                write(0,*) '### ERROR: irx not specified', irx
                stop
              end if
              if( iyx .lt. 1 ) then
                write(0,*) '### ERROR: iyx not specified', iyx
                stop
              end if
              rewind iun
              cycle
            end if
          else
            if( cbuff(8:12) .eq. 'start') then
              if( irest .ne. 0 ) then
                write(0,*) '### ERROR: restart data mismatch', irest
                stop
              end if
            else
              if( irest .ne. 1 ) then
                write(0,*) '### ERROR: restart data mismatch', irest
                stop
              end if
              rewind iun
              cycle
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            cidents = cbuff(31:46)
          else
            if( cbuff(31:46) .ne. cidents ) then
              write(0,*) '### ERROR: cident mismatch', &
                 ira, cbuff(31:46),' ', cidents
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a46)') cbuff
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') imx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. imx ) then
              write(0,*) '### ERROR: imx mismatch', ira, itmp, imx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') inx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. inx ) then
              write(0,*) '### ERROR: inx mismatch', ira, itmp, inx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') irx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. irx ) then
              write(0,*) '### ERROR: irx mismatch', ira, itmp, irx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') iyx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. iyx ) then
              write(0,*) '### ERROR: iyx mismatch', ira, itmp, iyx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          read(cbuff(31:41),'(f11.3)') wtmp
          wnpnc = max( wnpnc, wtmp )
          if( ira .eq. isize ) then
            write(cbuff(31:41),'(f11.3)') wnpnc
            write(7,'(a)') trim(cbuff)
          end if
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
      end do
!..
      allocate ( wpfeed(irx,imx,inx,iyx), itx(isize) )
      itx(:) = 0
      iend = 0
!....
    2 continue
      wpfeed(:,:,:,:) = 0.0d0
      wnp = 0.0d0
!...
      do ira = 1, isize
        iun = ira + iun0
!                                              * skip until separator *
    3   continue
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:20) .ne. '--------------------') go to 3
!                                            * next must be 'time = ' *
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:8) .ne. ' time = ') then
           write(0,*) '### ERROR: not time = ', cbuff
           stop
        end if
        itx(ira) = itx(ira) + 1
        read( cbuff(9:20), '(f12.3)' ) wtime
        write(0,*) 'irank,itx,time = ', ira-1, itx(ira), wtime
!                                             * read until 'total = ' *
    4   continue
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:8) .eq. 'total = ') then
           read( cbuff(9:22), '(f14.3)' ) wtotal
           write(0,*) 'irank, partial total = ', ira-1, wtotal
           wnp = wnp + wtotal
           cycle
        end if
!.         
        read( cbuff(1:28), '(4i4,f12.3)' ) id1,id2,id3,id4,wnum
        wpfeed(id1,id2,id3,id4) = wpfeed(id1,id2,id3,id4) + wnum
        goto 4
!.
    9   continue
        iend = iend + 1
      end do
!...
      if( iend .ge. isize ) then
         if( cbuff(1:5) .eq. '-----' ) write(7,'(a)') trim(cbuff)
         go to 99
      end if
!...
      write(7,'(a)') '------------------------'
      write(7,'(a8,f12.3)') ' time = ', wtime
      wn = 0.0d0
      do id4 = 1, iyx
        do id3 = 1, inx
          do id2 = 1, imx
            do id1 = 1, irx
              if( wpfeed(id1,id2,id3,id4) .ge. wopfeedm ) then
                wn = wn + wpfeed(id1,id2,id3,id4)
                write(7,'(4i4,f12.3)') id1,id2,id3,id4, &
                                          wpfeed(id1,id2,id3,id4)
              end if
            end do
          end do
        end do
      end do
      write(7,'(a8,f14.3)') 'total = ', wn
      write(0,*) 'total = ', wn, wnp
!...         
      go to 2
!...         
   99 continue
      write(0,*) 'reading data ',itx(:)
!....
      stop
      end
