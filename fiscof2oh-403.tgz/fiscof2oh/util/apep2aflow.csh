#!/bin/csh
#
# apep2aflow.csh : convert anime pep gif file to anime flow gif file
#
# Usage: apep2aflow.csh in-apep.gif number_of_flow out-aflow.gif
#

if ( $#argv != 3 ) then
   echo "Usage: apep2aflow.csh in-apep.gif number_of_flow out-aflow.gif"
   exit 1
endif

which convertxx
if ( $status != 0 ) then
   echo "ERROR: apep2aflow.csh needs convert command in ImageMagick."
   exit 2
endif

set pwd = `pwd`
set tmpdir = /tmp

convert +adjoin $1 $tmpdir/apep2aflow$$_frame_%04d.gif

cd $tmpdir

set nfrm = `ls apep2aflow$$_frame_????.gif | wc -w`
@ nflw = $nfrm - $2 + 1
set cnt1 = 0
set cnt4 = 0

set geom = `identify -format "%w" apep2aflow$$_frame_0000.gif`
@ geom = $geom - 60
set geom = 60x20+$geom+0

echo -n "converting ."
while ( $cnt1 < $nflw )
   mv apep2aflow$$_frame_`printf "%04d" $cnt1`.gif apep2aflow$$_flow_`printf "%04d" $cnt1`.gif
   convert apep2aflow$$_flow_`printf "%04d" $cnt1`.gif -crop $geom apep2aflow$$_time.gif
   set cnt2 = 1
   @ cnt3 = $cnt1 + 1
   while ( $cnt2 < $2 )
      convert apep2aflow$$_flow_`printf "%04d" $cnt1`.gif apep2aflow$$_frame_`printf "%04d" $cnt3`.gif  -compose Lighten -composite apep2aflow$$_flow_`printf "%04d" $cnt1`.gif
      @ cnt2++
      @ cnt3++
   end
   composite -compose Copy -gravity NorthEast apep2aflow$$_time.gif apep2aflow$$_flow_`printf "%04d" $cnt1`.gif apep2aflow$$_flow_`printf "%04d" $cnt1`.gif
   @ cnt1++
   @ cnt4++
   if ( $cnt4 == 5 ) then
      echo -n "."
      set cnt4 = 0
   endif
end
echo " done"

convert apep2aflow$$_flow_????.gif $pwd/$3

/bin/rm -f apep2aflow$$_frame_????.gif apep2aflow$$_flow_????.gif apep2aflow$$_time.gif

cd $pwd

exit
