!----------------------------------------------------------------------
! convert binary file to text file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!   cidentb: identification character for cbifntp
!   irank  : MPI rank number (should be -1 if nonparallel run)
!   wts    : start time
!   wte    : end time
!   wxps   : start x position
!   wyps   : start y position
!   wxpe   : end x position
!   wype   : end y position
!   intx   : data interval for x
!   inty   : data interval for y
!
      implicit none
      integer, parameter :: lomax = 9
      integer :: i, ii, i3, i4, i5, in, iunit, ixl, iyl, ixyl, ionl, &
                 ixps, iyps, ixpe, iype, intx, inty, ixn, iyn, iofekl, &
                 irank
      integer :: idat2(2,lomax)
      real*8, allocatable::work1(:),work2(:,:),work22(:,:), &
                           work3(:,:,:),work4(:,:,:,:),work5(:,:,:,:,:)
      real*8  :: wxps, wyps, wxpe, wype, wxmic, wx0, wymic, wy0, &
                 wts, wte, wtime, wteps=0.05
      real*8  :: wmax,wdat2(5,lomax),wdat22(lomax,lomax),wdat23(2,lomax)
      character ckind*5, chead*4, cident*16, cidentb*16, cform*32
      character cbifntp*64, cfile*128
!.
      namelist /param/ ckind, cbifntp, cidentb, irank, wts, wte, &
                       wxps, wyps, wxpe, wype, intx, inty
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      irank   = -1
      wts     = 0.0
      wte     = 9999.0
      wxps    = -1000.0
      wyps    = -1000.0
      wxpe    = 1000.0
      wype    = 1000.0
      intx    = 1
      inty    = 1
!..
      read(*,param)
      write(0,param)
!....
      if( ckind .eq. 'fde' ) then
         iunit = 20
      else if( ckind .eq. 'fdi' ) then
         iunit = 21
      else if( ckind .eq. 'fea' ) then
         iunit = 22
      else if( ckind .eq. 'fer' ) then
         iunit = 23
      else if( ckind .eq. 'fba' ) then
         iunit = 24
      else if( ckind .eq. 'fbr' ) then
         iunit = 25
      else if( ckind .eq. 'pem' ) then
         iunit = 26
      else if( ckind .eq. 'fede' ) then
         iunit = 27
      else if( ckind .eq. 'fje' ) then
         iunit = 28
      else if( ckind .eq. 'fji' ) then
         iunit = 29
      else if( ckind .eq. 'pim' ) then
         iunit = 30
      else if( ckind .eq. 'fek' ) then
         iunit = 31
      else if( ckind .eq. 'fte' ) then
         iunit = 33
      else if( ckind .eq. 'pee' ) then
         iunit = 34
      else if( ckind .eq. 'pie' ) then
         iunit = 35
      else if( ckind .eq. 'fedi' ) then
         iunit = 36
      else if( ckind .eq. 'fdc' ) then
         iunit = 41
      else if( ckind .eq. 'fjt' ) then
         iunit = 42
      else
         write( 0, * ) 'ERROR: invalid obs. kind ', ckind
         stop
      end if
!....
      if( ckind .eq. 'fedi' .or. ckind .eq. 'fede' ) then
         call fntpcnv ( cbifntp,irank,iunit, cidentb, &
                                        'fE'//ckind(4:4), cfile )
      else
         call fntpcnv ( cbifntp,irank,iunit, cidentb, ckind, cfile )
      end if
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      if( ckind .eq. 'pem' ) then
         read( iunit ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         write( 0, * ) chead, ' ', cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         allocate( work3(ixl,3,iyl), work4(ixl,ixl,3,iyl) )
!
      else if( ckind .eq. 'pee' ) then
         read( iunit ) chead, cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         write( 0, * ) chead, ' ', cident, ixl, iyl, &
                                         ((wdat2(i,ii),i=1,5),ii=1,iyl)
         allocate( work2(ixl,iyl) )
!
      else if( ckind .eq. 'pim' ) then
         read( iunit ) chead, cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         write( 0, * ) chead, ' ', cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         allocate( work4(ixl,3,iyl,ionl), work5(ixl,ixl,3,iyl,ionl) )
!
      else if( ckind .eq. 'pie' ) then
         read( iunit ) chead, cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         write( 0, * ) chead, ' ', cident, ixl, iyl, ionl, &
             ( (wdat23(i,ii),i=1,2),ii=1,ionl), &
             ( (wdat22(i,ii),ii=1,ionl), (wdat2(ii,i),ii=1,4), i=1,iyl)
         allocate( work3(ixl,iyl,ionl) )
!
      else if( ckind .eq. 'fek' ) then
         read( iunit ) chead, cident, wmax, ixyl, &
       ((idat2(i,ii),i=1,2),ii=1,ixyl), ((wdat2(i,ii),i=1,4),ii=1,ixyl)
         write( 0, * ) chead, ' ', cident, wmax, ixl, &
       ((idat2(i,ii),i=1,2),ii=1,ixyl), ((wdat2(i,ii),i=1,4),ii=1,ixyl)
!
      else 
!.
         if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
             ckind .eq. 'fedi' ) then
            read( iunit ) chead,cident,ixyl,ixl,iyl, &
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl)
            write( 0, * ) chead,' ', cident,ixyl,ixl,iyl, &
	                  wxmic,wx0,wymic,wy0, &
                          ionl,( (wdat23(i,ii),i=1,2),ii=1,ionl)
            if( ckind .eq. 'fji' ) then
               allocate( work4(3,ixl,iyl,ionl) )
            else
               allocate( work3(ixl,iyl,ionl) )
            end if
         else
            read( iunit ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
            write( 0, * ) chead,' ', cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
            if( ckind .eq. 'fje' ) then
               allocate( work4(3,ixl,iyl,3) )
            else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                     ckind .eq. 'fjt' ) then
!                               * check instantaneous flag for fer/fbr *
               if( chead(3:3) .eq. 'R' ) then
                  allocate( work4(3,ixl,iyl,2) )
               else
                  allocate( work3(3,ixl,iyl) )
               end if
            else if( ckind .eq. 'fte' ) then
               allocate( work3(ixl,iyl,2) )
!                                                        * other cases *
            else
               allocate( work2(ixl,iyl) )
            end if
         end if
!.
         ixps = ( wxps + wx0 ) / wxmic
         if( ixps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid xps', wxps, ixps
            write( 0, * ) '###        : ixps is assumed as 1'
            ixps = 1
         end if
         ixpe = ( wxpe + wx0 ) / wxmic
         if( ixpe .gt. ixl ) then
            write( 0, * ) '### WARNING: invalid xpe', wxpe, ixpe
            write( 0, * ) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
         if( ixps .gt. ixpe ) then
            write( 0, * ) '### ERROR: xps gt xpe', wxps, wxpe
            stop
         end if
         iyps = ( wyps + wy0 ) / wymic
         if( iyps .lt. 1 ) then
            write( 0, * ) '### WARNING: invalid yps', wyps, iyps
            write( 0, * ) '###        : iyps is assumed as 1'
            iyps = 1
         end if
         iype = ( wype + wy0 ) / wymic
         if( iype .gt. iyl ) then
            write( 0, * ) '### WARNING: invalid ype', wype, iype
            write( 0, * ) '###        : iype is assumed as', iyl
            iype = iyl
         end if
         if( iyps .gt. iype ) then
            write( 0, * ) '### ERROR: yps gt ype', wyps, wype
            stop
         end if
!.
         ixn  = ( ixpe - ixps ) / intx + 1
         if( ixn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid x interval', &
	                  ixps,ixpe,intx
            stop
         end if
         iyn  = ( iype - iyps ) / inty + 1
         if( iyn .lt. 1 ) then
            write( 0, * ) '### ERROR: invalid y interval', &
	                  iyps,iype,inty
            stop
         end if
!..
         write( 0, * ) '----- ixps, ixpe, iyps, iype = ', &
	                      ixps, ixpe, iyps, iype
         write( 0, * ) '----- ixn, iyn = ', ixn, iyn
      end if
!....
      write( 0, * ) '----- header: ', chead, ', ident: ', cident
      write( *, * ) '----- header: ', chead, ', ident: ', cident
!.......................................................................
      iofekl = 0
    1 continue
         if( ckind .eq. 'pem' ) then
            read( iunit, end=99 ) wtime, &
                        (((work3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl), &
             ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
!
         else if( ckind .eq. 'pee' ) then
            read( iunit, end=99 ) wtime, work2
!
         else if( ckind .eq. 'pim' ) then
            read( iunit, end=99 ) wtime, &
                (( ((work4(i,i3,i4,i5),i=1,ixl),i3=1,3), &
                  (((work5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
!
         else if( ckind .eq. 'pie' ) then
            read( iunit, end=99 ) wtime, work3
!
         else if( ckind .eq. 'fek' ) then
            iofekl = iofekl + 1
            if( iofekl .gt. ixyl ) iofekl = 1
            ixl = idat2(1,iofekl)
            iyl = idat2(2,iofekl)
            allocate( work2(ixl,8), work22(iyl,8), work3(ixl,iyl,4) )
            do i4 = 1, 4
               i5 = i4*2 - 1
               read( iunit, end=99 ) wtime, in, in, &
                       (work2(i,i5),i=1,ixl),(work22(i,i5),i=1,iyl), &
                      ((work3(i,ii,i4),i=1,ixl),ii=1,iyl), &
                       (work2(i,i5+1),i=1,ixl),(work22(i,i5+1),i=1,iyl)
            end do
!
         else 
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
                ckind .eq. 'fedi' ) then
               if( ckind .eq. 'fji' ) then
                  read( iunit, end=99 ) wtime, work4
               else
                  read( iunit, end=99 ) wtime, work3
               end if
            else
               if( ckind .eq. 'fje' ) then
                  read( iunit, end=99 ) wtime, work4
               else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                        ckind .eq. 'fte' .or. ckind .eq. 'fjt' ) then
                  if( chead(3:3) .eq. 'R' ) then
                     read( iunit, end=99 ) wtime, work4
                  else
                     read( iunit, end=99 ) wtime, work3
                  end if
!                                                       * other cases *
               else
                  read( iunit, end=99 ) wtime, work2
               end if
            end if
         end if
!...
         if( wtime .lt. wts-wteps ) then
	    if( ckind .eq. 'fek' ) deallocate( work2, work22, work3 )
	    go to 1
         end if
!...
         if( wtime .gt. wte+wteps ) then
            write( *, * ) '----- end'
            go to 2
         end if
!...
         write( 0, * ) '----- time = ', wtime
         write( *, * ) '----- time = ', wtime
!..
         if( ckind .eq. 'pem' ) then
            cform = '(xxxxx(e12.4,:,'',''))'
            write( cform(2:6), '(i5)' ) ixl
            write( *, cform ) &
                           (((work3(i,ii,i3),i=1,ixl),ii=1,3),i3=1,iyl)
            cform = '(xxxxxxxxxx(e12.4,:,'',''))'
            write( cform(2:11), '(i10)' ) ixl*ixl
            write( *, cform ) &
             ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,ixl),i3=1,3),i4=1,iyl)
!
         else if( ckind .eq. 'pee' ) then
            cform = '(xxxxx(e12.4,:,'',''))'
            write( cform(2:6), '(i5)' ) ixl*iyl
            write( *, cform ) work2
!
         else if( ckind .eq. 'pim' ) then
            cform = '(xxxxx(e12.4,:,'',''))'
            write( cform(2:6), '(i5)' ) ixl
            write( *, cform ) &
            ((((work4(i,ii,i3,i4),i=1,ixl),ii=1,3),i3=1,iyl),i4=1,ionl)
            cform = '(xxxxxxxxxx(e12.4,:,'',''))'
            write( cform(2:11), '(i10)' ) ixl*ixl
            write( *, cform ) &
                (((((work5(i,ii,i3,i4,i5),i=1,ixl),ii=1,ixl),i3=1,3), &
                                                   i4=1,iyl),i5=1,ionl)
!
         else if( ckind .eq. 'pie' ) then
            cform = '(xxxxx(e12.4,:,'',''))'
            write( cform(2:6), '(i5)' ) ixl*iyl
            write( *, cform ) work3
!
         else if( ckind .eq. 'fek' ) then
            if( iofekl .ge. 1 ) then
               write( 0, * ) '----- iofekl = ', iofekl
               write( *, * ) '----- iofekl = ', iofekl
            end if
            do i4 = 1, 4
               i5 = i4*2 - 1
               cform = '(xxxxx(e12.4,:,'',''))'
               write( cform(2:6), '(i5)' ) ixl
               write( *, cform ) (work2(i,i5),i=1,ixl)
               cform = '(xxxxx(e12.4,:,'',''))'
               write( cform(2:6), '(i5)' ) iyl
               write( *, cform ) (work22(i,i5),i=1,iyl)
               cform = '(xxxxxxxxxx(e12.4,:,'',''))'
               write( cform(2:11), '(i10)' ) ixl*iyl
               write( *, cform ) ((work3(i,ii,i4),i=1,ixl),ii=1,iyl)
               cform = '(xxxxx(e12.4,:,'',''))'
               write( cform(2:6), '(i5)' ) ixl
               write( *, cform ) (work2(i,i5+1),i=1,ixl)
               cform = '(xxxxx(e12.4,:,'',''))'
               write( cform(2:6), '(i5)' ) iyl
               write( *, cform ) (work22(i,i5+1),i=1,iyl)
            end do
            deallocate( work2, work22, work3 )
!
         else 
            cform = '(xxxxxxxxxx(e12.4,:,'',''))'
            write( cform(2:11), '(i10)' ) ixn*iyn
            if( ckind .eq. 'fdi' .or. ckind .eq. 'fji' .or. &
                ckind .eq. 'fedi' ) then
               if( ckind .eq. 'fji' ) then
                  write( *, cform ) &
                     ((((work4(i3,i,ii,i4),i3=1,3),i=ixps,ixpe,intx), &
                                          ii=iyps,iype,inty),i4=1,ionl)
               else
                  write( *, cform ) &
      (((work3(i,ii,i3),i=ixps,ixpe,intx),ii=iyps,iype,inty),i3=1,ionl)
               end if
            else
               if( ckind .eq. 'fje' ) then
                  write( *, cform ) &
                     ((((work4(i3,i,ii,i4),i3=1,3),i=ixps,ixpe,intx), &
                                             ii=iyps,iype,inty),i4=1,3)
               else if( ckind .eq. 'fer' .or. ckind .eq. 'fbr' .or. &
                        ckind .eq. 'fjt' ) then
                  if( chead(3:3) .eq. 'R' ) then
                     write( *, cform ) &
                     ((((work4(i3,i,ii,i4),i3=1,3),i=ixps,ixpe,intx), &
                                             ii=iyps,iype,inty),i4=1,2)
                  else
                     write( *, cform ) &
         (((work3(i3,i,ii),i3=1,3),i=ixps,ixpe,intx),ii=iyps,iype,inty)
                  end if
               else if( ckind .eq. 'fte' ) then
                  write( *, cform ) &
         (((work3(i,ii,i3),i=ixps,ixpe,intx),ii=iyps,iype,inty),i3=1,2)
!                                                       * other cases *
               else
                  write( *, cform ) &
                     ((work2(i,ii),i=ixps,ixpe,intx),ii=iyps,iype,inty)
               end if
            end if
         end if
!...
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
