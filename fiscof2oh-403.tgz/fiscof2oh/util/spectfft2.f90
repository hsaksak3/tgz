!---------------------------------------------------------------------
! plot spectrum for Omega
!
      implicit none
      integer, parameter :: ldata = 100000, lspect = 16384*4
      integer, parameter :: lsp2 = lspect/2
      integer :: iffts3(15), i, ii, iii, is, ip, ids, iflag, idl, &
                 ist, ilen, ilen2, iofewl, iwmax
      real*8  :: data(3,ldata,5), spect(lspect) , wffts1(lspect), &
                 wffts2(lspect), awx(0:lsp2), amp(0:lsp2,0:3), &
		 wofewxp(5), wofewyp(5), &
		 wstcur, wdelt, wdt, wtime, awmax, ampmx
      character chead*4, cident*16, ctime*12, ctitle*24
!....
      read(32) chead, cident, wdelt, iofewl, &
               (wofewxp(i), wofewyp(i), i=1,iofewl)
      write(0,*) chead, ' ', cident, wdelt, iofewl, &
               (wofewxp(i), wofewyp(i), i=1,iofewl)
      ids = 0
    1 continue
         read(32,end=2)  wstcur, iflag, idl, &
        ( ( ( data(iii,ids+ii,i),iii=1,3),ii=1,idl),i=1,iofewl)
         write(*,*) 'wstcur, iflag, idl = ', wstcur, iflag, idl
         ids = ids + idl
      go to 1
    2 continue
      wdt = wstcur / ids
      write(*,*) 'ids, wdt = ', ids, wdt
!..
      write(0,*) 'enter ist, ilen, awmax'
      read(*,*) ist, ilen, awmax
!.
      ist = ist - 1
      ilen2 = ilen / 2
      wtime = ( ist + ilen2 ) * wdt
      ctime = 'xxxx.xx fsec'
      write( ctime(1:7), '(f7.2)' ) wtime
!..
      call rffti ( ilen, wffts2, iffts3 )
!....
      call fr_ginit 
      call fr_opencanvas( 1, 'spectfft-'//cident, 10 )
      chead = 'xyz'
!...
      do ip = 1, iofewl
!
	 do is = 0, ilen2
            amp(is,0) = 0.0d0
	 end do
         do is = 1, 3
            do i = 1, ilen
               spect(i) = data(is,ist+i,ip)
            end do
            call rfftf ( ilen, spect, wffts1, wffts2, iffts3 )
            amp(0,0) = amp(0,0) + spect(1)**2
            amp(0,is) = spect(1)**2
            do i = 1, ilen2-1
               amp(i,0) = amp(i,0) + spect(i*2)**2 + spect(i*2+1)**2
               amp(i,is) = spect(i*2)**2 + spect(i*2+1)**2
            end do
            amp(ilen2,0) = amp(ilen2,0) + spect(ilen)**2
            amp(ilen2,is) = spect(ilen)**2
         end do
!..
         ampmx = 0.0d0
         do i = 0, ilen2
            ampmx = max( ampmx, amp(i,0) )
            awx(i)  = wdelt / ilen * i
            if( awx(i) .gt. awmax ) then
               iwmax = i-1
               go to 20
            end if
         end do
         awmax = awx(ilen2)
         iwmax = ilen2
   20    continue
!....
         do is = 0, 3
            do i = 0, iwmax
               amp(i,is) = log10(max(sqrt(amp(i,is)/ampmx),1.0d-4))
            end do
         end do
	 ctitle = 'position (-xx.xx,-xx.xx)'
	 write( ctitle(11:16), '(f6.2)' ) wofewxp(ip)
	 write( ctitle(18:23), '(f6.2)' ) wofewyp(ip)
!....
         call fr_gclear
         call fr_frame2d ( 0.0d0, awmax, -4.0d0, 0.0d0, 11 )
         call fr_logaxis ( 2 )
         call fr_graph2d ( awx(0), amp(0,0), iwmax+1, 2, 1 )
         call fr_fpchars ( 50.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 150.0d0, 15.0d0, ctitle, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
         call fr_xyname ( 'omega[W/W-L]', 'spectrum[a.u.]' )
!...
         call fr_gclear
         call fr_frame2d ( 0.0d0, awmax, -4.0d0, 0.0d0, 11 )
         call fr_logaxis ( 2 )
	 do is = 1, 3
            call fr_graph2d ( awx(0), amp(0,is), iwmax+1, 2+is, 1 )
            call fr_fpchars ( 580.0d0, 5.0d0+12.0d0*is, chead(is:is), &
	                      2+is, 1, -1, 0, 0 )
	 end do
         call fr_fpchars ( 50.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 150.0d0, 15.0d0, ctitle, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
         call fr_xyname ( 'omega[W/W-L]', 'spectrum[a.u.]' )
!...
      end do
!....
      call fr_gend
!....
      stop
      end
