!----------------------------------------------------------------------
! check CP laser
!
      implicit none
      integer, parameter :: itmx=2000
      integer :: ixl, iyl, ixyl, icnt, ix, iy
      real*8, allocatable:: work(:,:,:)
      real*8  :: wxmic, wx0, wymic, wy0, wtime
      real*8  :: ey(itmx), ez(itmx)
      character cfile*16, chead*4, cident*16
!....
      write( *, * ) 'enter bin file name'
      read( *, '(a16)' ) cfile
!....
      open( 7, file=cfile, form='UNFORMATTED', status='OLD' )
      read( 7 ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
      write( *, * ) chead,cident,ixyl,ixl,iyl,wxmic,wx0,wymic,wy0
      allocate( work(ixl,iyl,3) )
!....
      write( *, * ) '----- header: ', chead, ', ident: ', cident
!..
      icnt = 0
      ix = ixl / 2
      iy = iyl / 2
    1 continue
!...
      read( 7, end=99 ) wtime, work
      icnt = icnt + 1
      ey(icnt) = work(ix,iy,2)
      ez(icnt) = work(ix,iy,3)
!...
      write( *, * ) '----- time = ', wtime, icnt
!...
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!....
      call fr_ginit
      call fr_opencanvas ( 1, 'check-cp-'//cident, 10 )
      if( mod(icnt,2) .eq. 1 ) icnt = icnt - 1
      call fr_graph2d ( ey, ez, icnt, 2, 5 )
      call fr_xyname( 'Y-comp', 'Z-comp' )
      call fr_fpchars( 5.0d0, 15.0d0, cfile, 7, 1, -1, 0, 0 )
      call fr_gend
!....
      stop
      end
