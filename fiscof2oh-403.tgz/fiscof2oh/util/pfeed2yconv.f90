!----------------------------------------------------------------------
! plot pfeed data (2D) convert
!
!... Input data
! 
! file: FISCOF2_YCONVPARAM_FILE (default: ./iyconv.param)
!      1 idy      : number of divisoin for y
!      2 wys, wye : observation position ys and ye
!      3 mode = 1 : fix beam intensity
!             = 2 : fix energy
!
! file: FISCOF2_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
!
!    coded by Sato,R.
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: ltx = 500
      integer :: idy, imx, inx, irx, iyx, llsrty, &
                 itx, id1, id2, id3, id4, iy, mode
      real*8 :: wrang, wintt, wotint, woxp, woyps, woype, wnepm1, &
                wnpnc, wlramm, wlram, wgrid, wlpwr, wnum, &
                slsrle, slsrwd, slsrtr, &
                wtimen, wtimex, wtime(ltx), wtotal(ltx), wnumt(ltx), &
                wys, wye, wyd, wyw
      character cbuff*80, cdum*3, cident*16, cfile*128, clsrty*16
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF2_TIMEPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 )
      end if
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!..                                          * default convert parameter *
      mode = 1
      idy  = 7
      wys  = -15.0d0
      wye  = 15.0d0
!....                                           * read convert parameter *
      call getenv ( 'FISCOF2_YCONVPARAM_FILE', cfile )
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=998 )
      else
         open( 7,file='./yconv.param',form='FORMATTED',status='OLD',&
               err=8 )
      end if
      read( 7, *, end=997 ) mode
      read( 7, *, end=997 ) idy
      read( 7, * ) wys, wye
      close ( 7 )
      if ( mode .le. 0 .or. mode .ge. 3 ) then
        write(0,*) 'mode is not corrected by yconv.param', mode
        stop
      end if
      if( idy .le. 0 ) then
        write(0,*) '### ERROR: idy less than 0 ', idy
        stop
      end if
      if ( wye .le. wys ) then
        write(0,*) 'wys greater than wye'
        stop
      end if
    8 continue
!....                                                  * read headers *
! ------ start -------
! ident character             = i20tmpulse       
! Sn                          =      36      
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       1       
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
      read(*,*) cdum
      read(*,1000) cbuff(1:27), cdum, cident
      read(*,1001) cbuff(1:27), cdum, imx
      read(*,1001) cbuff(1:27), cdum, inx
      read(*,1001) cbuff(1:27), cdum, irx
      read(*,1002) cbuff(1:27), cdum, wrang
      read(*,1002) cbuff(1:27), cdum, wintt
      read(*,1002) cbuff(1:27), cdum, wotint
      read(*,1002) cbuff(1:27), cdum, woxp
      read(*,1002) cbuff(1:27), cdum, woyps
      read(*,1002) cbuff(1:27), cdum, woype
      read(*,1001) cbuff(1:27), cdum, iyx
      read(*,1002) cbuff(1:27), cdum, wnepm1
      read(*,1002) cbuff(1:27), cdum, wnpnc
      read(*,1002) cbuff(1:27), cdum, wlramm
      read(*,1002) cbuff(1:27), cdum, wlram
      read(*,1002) cbuff(1:27), cdum, wgrid
      read(*,1002) cbuff(1:27), cdum, wlpwr
      read(*,1002) cbuff(1:27)
      read(*,1001) cbuff(1:27), cdum, llsrty
 1000 format(a27,a3,a16)
 1001 format(a27,a3,i7)
 1002 format(a27,a3,f11.3)
!... writing data
      write(*,1003)  cident, imx, inx, irx, wrang, wintt, &
                     wotint, woxp, wys, wye, idy, wnepm1, &
                     wnpnc, wlramm, wlram, wgrid, wlpwr
 1003 format( '--- start (converted) ---'/ &
            'ident character             = ', a16 / &
            'Sn                          = ', i7 / &
            '# of mesh for omega         = ', i7 / &
            '# of mesh for momentum      = ', i7 / &
            'range                       = ', f11.3 / &
            'integration time            = ', f11.3, ' [fsec]' / &
            'observation interval        = ', f11.3, ' [fsec]' / &
            'observation position of x   = ', f11.3, ' [micron]'/ &
            'observation position of ys  = ', f11.3, ' [micron]'/ &
            'observation position of ye  = ', f11.3, ' [micron]'/ &
            '# of division for y         = ', i7 / &
            '# of particle/mesh at nc    = ', f11.3 / &
            'density at center           = ', f11.3 / &
            'laser wavelength            = ', f11.3,' [micron]'/ &
            'laser wavelength/mesh size  = ', f11.3 / &
            'Debye length/mesh size      = ', f11.3 / &
            'laser peak intensity        = ', e11.4, &
                                           ' [W/cm^2-micron^2]'/ &
            'laser pulse shape (TYPE)    = '/ &
            'laser pulse parameters      = ')
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
      itx = 0
      wtime(ltx) = 0.0d0
      wtotal(ltx) = 0.0d0
      wnumt = 0.0d0
    1 continue
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) 'ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
      read( cbuff(9:20), '(f12.3)' ) wtime(itx)
      write(0,*) 'itx,time = ', itx, wtime(itx)
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime(itx) - wtime(itx-1) ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime(itx)-wtimen) .ge. 1.0d0 .and. &
             (wtime(itx)-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         itx = itx - 1
         go to 1
      end if
!...
      write(*,1100) wtime(itx)
 1100 format( '--------------------'/' time = ', f12.3 )
!...
      read(*, '(a80)', end=90 ) cbuff
    2 continue
!
      read( cbuff, '(4i4,f12.3)' ) id1,id2,id3,id4,wnum
!...
!                                             * convert  wnum *
 1200 format( 4i4, f12.3 )
      wyd = dble(iyx) / dble(idy)
      wyw = ( wye - wys ) / ( woype - woyps )
      if ( mode .eq. 1 ) then 
        wnum = wnum * wyd * wyw
        do iy = 1, idy
          write(*,1200) id1,id2,id3,iy,wnum
          wnumt(itx) = wnumt(itx) + wnum
        end do
      else if ( mode .eq. 2 ) then
        wnum = wnum * wyd**2 * wyw
        do iy = 1, idy
          write(*,1200) id1,id2,id3,iy,wnum
          wnumt(itx) = wnumt(itx) + wnum
        end do
      else
        go to 90
      end if
!                                             * read until 'total = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .eq. 'total = ') then
        read( cbuff(9:20), '(f12.3)' ) wtotal(itx)
        write(*,1300) wnumt(itx)
 1300   format( 'total = ', f13.3 )
      else
         go to 2
      end if
!..
      if( abs(wtime(itx)-wtimex) .le. 1.0d0 .or. &
        (wtime(itx)-wtimex) .gt. 0.0d0 ) then
        write(0,*) 'process was stopped by time.param.', wtimex
        go to 90
      end if
!...
      go to 1

   90 continue  

      write(0,*) 'y conv. mode', mode
      write(0,*) 'y start', woyps, '->', wys
      write(0,*) 'y end', woype, '->', wye
      write(0,*) 'y div.', iyx, '->', idy 
      stop
!...
  999 continue  
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
!..
  998 continue  
      write(0,*) '### ERROR: yconv param file not found. file="', &
         trim(cfile), '"'
      stop
!..
  997 continue
      write(0,*) '### ERROR: yconv param file not corrected. file="', &
         trim(cfile), '"'
      stop

      end
