c--------------------------------------------------------------------
      call igdfx_init
c....
      icolx = 10
      icoll = 21
      icolh = 10
c.
      wcolx = icolx
      wcoll = icoll
      wcoll1 = icoll - 1
      wcolh1 = icolh - 1
      weps  = 0.01
c....
      call igdfx_opngif ( 1, 640, 640 )
c....
      call igdfx_defvwp ( 1, 0.0, 1.0, 0.0, 1.0 )
      call igdfx_defwin ( 1, 0.0, 1.0, 0.0, 1.0 )
      call igdfx_deftrf ( 1, 1, 1 )
c...
      do ic = 1, 6
         whs = (ic-1)*60.
	 if( ic .eq. 5 ) then
            wls = 0.3
	 else
            wls = 0.2
	 end if
         wss = 1.0
         whe = (ic-1)*60.
         wle = 0.9
         wse = 1.0
         is = 10 + (ic-1) * icoll
         do i = 1, icoll
            wh = whs + ( whe - whs ) * (i-1) / wcoll1
            wl = wls + ( wle - wls ) * (i-1) / wcoll1
            ws = wss + ( wse - wss ) * (i-1) / wcoll1
            call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
            call igdfx_defcol ( is+i-1, ir, ig, ib )
         end do
      end do
c.
      ic = 7
      whs = 240.0
      wls = 0.6
      wss = 1.0
      whe = 240.0
      wle = 0.35
      wse = 0.25
      is = 10 + (ic-1) * icoll
      do i = 1, icolh
         wh = whs + ( whe - whs ) * (i-1) / wcolh1
         wl = wls + ( wle - wls ) * (i-1) / wcolh1
         ws = wss + ( wse - wss ) * (i-1) / wcolh1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
      call igdfx_hls2rgb ( 300.0, 0.2, 0.0, ir, ig, ib )
      call igdfx_defcol ( is+icolh, ir, ig, ib )
      whs = 0.0
      wls = 0.25
      wss = 0.25
      whe = 0.0
      wle = 0.7
      wse = 1.0
      is = is + icolh + 1
      do i = 1, icolh
         wh = whs + ( whe - whs ) * (i-1) / wcolh1
         wl = wls + ( wle - wls ) * (i-1) / wcolh1
         ws = wss + ( wse - wss ) * (i-1) / wcolh1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
c.
      ic = 8
      whs = 0.0
      wls = 0.3
      wss = 1.0
      whe = 60.0
      wle = 0.7
      wse = 1.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
c.
      ic = 9
      whs = 0.0
      wls = 0.2
      wss = 0.0
      whe = 0.0
      wle = 1.0
      wse = 0.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
c.
      ic = 10
      whs = 240.0
      wls = 0.5
      wss = 1.0
      whe = 0.0
      wle = 0.5
      wse = 1.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
c...
      call igdfx_sellcl ( 2 )
      do ii = 1, icolx
         wxs = (ii-1)/wcolx + weps
         wxe = ii/wcolx - weps
         is = 10 + (ii-1)*icoll
         do i = 1, icoll
            wys = (i-1)/wcoll + weps
            wye = i/wcoll - weps
            call igdfx_selfcl ( is+i-1 )
            call igdfx_drwrec ( wxs, wys, wxe, wye, 11 )
         end do
      end do
c...
      call igdfx_clsgif ( 1, 'color.gif$ ', 2 )
c....
      call igdfx_term
c....
      stop
      end
