!----------------------------------------------------------------------
! field plot
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!   cidentb: identification character for cbifntp
!   cfrfntp: file name template for Frames plt file
!   irank  : MPI rank number (should be -1 if nonparallel run)
!
      implicit none
      integer :: i, iunit, ixl, iyl, irank, lrank, ldivx, ldivy, sdid(2)
      integer :: ips, ixyz
      real*8, allocatable:: work4(:,:,:,:), awork(:,:)
      real*8  :: wtime
      character ckind*5, chead*4, cident*16, cidentb*16, ctime*16
      character cbifntp*64, cfrfntp*64, cfile*128, clabel*24
!.
      namelist /param/ ckind, cbifntp, cidentb, cfrfntp, irank
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cfrfntp = '&K-&I-###'
      irank   = 0
!..
      read(*,param)
      write(*,param)
!....
      if( ckind .eq. 'fer' ) then
         iunit = 63
      else if( ckind .eq. 'fbr' ) then
         iunit = 65
      else if( ckind .eq. 'fjt' ) then
         iunit = 82
      else
         write( 0, * ) 'ERROR: invalid obs. kind ', ckind
         stop
      end if
!....
      call fntpcnv ( cbifntp,irank,iunit, cidentb, ckind, cfile )
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      read( iunit ) chead,cident,ixl,iyl,lrank,ldivx,ldivy
      write( *, * ) chead,' ', cident,ixl,iyl,lrank,ldivx,ldivy
      allocate( work4(3,ixl,iyl,2), awork(ixl,iyl) )
!..
      call fntpcnv ( cfrfntp, irank, 1, cident, chead, cfile )
      call frames_init
      call frames_file ( cfile, 1, 5 )
!.......................................................................
    1 continue
        read( iunit, end=99 ) wtime, work4, sdid
!...
        write( *, * ) '----- time, sdid = ', wtime, sdid
!..
        ctime = 'xxxxx.xx fsec'
        write( ctime(1:8), '(f8.2)' ) wtime
        clabel = chead//' xyz = *, pri. = **'
        write( clabel(22:23), '(i2)' ) sdid(1)
!.
        do ips = 1, 2
          if( sdid(ips) .lt. 0 ) cycle
          do ixyz = 1, 3
            call fr_gclear
            call fr_aspect2d ( 1.0d0, 1.0d0, 0 ) 
            call fr_frame2d ( 1.0d0, dble(ixl), 1.0d0, dble(iyl), 3 ) 
            call fr_hlsrecall ( 2 )
            awork(:,:)  = work4(ixyz,:,:,ips)
            call fr_contour ( awork, ixl, iyl, 1, -2 )
            call fr_xyname ( 'x', 'y' )
            call fr_colorbar ( 350, 475, 200, 15, 2 ) 
            call fr_fpchars ( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 ) 
            write( clabel(12:12), '(i1)' ) ixyz
            call fr_fpchars ( 150.0d0, 15.0d0, clabel, 7, 1, -1, 0, 0 ) 
            call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
          end do
          clabel = chead//' xyz = *, sec. = **'
          write( clabel(22:23), '(i2)' ) sdid(2)
        end do
!..
      go to 1
!...
   99 continue
      write( *, * ) '----- end by EOF'
!...
    2 continue
      call frames_term
!....
      stop
      end
