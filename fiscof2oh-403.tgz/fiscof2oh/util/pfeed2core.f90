!----------------------------------------------------------------------
! plot pfeed data (2D) for core hitting
!
!... Input data
! 
! file: FISCOF2_COREPARAM_FILE (default: ./core.param)
!      1 icx            : number of core data
!      2 wcx, wcy, wcr  : first-core parameters (x, y, r)
!      3 wcx, wcy, wcr  : second-core parameters
!           repeat until line (icx + 1)
!
! file: FISCOF2_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
!... Output data
! wava
!       Mean Angle (X-Y) (degree in each momentum group)
! wdevm,wdevp
!       Standard deviations in plus and minus sides 
!       (degree in each momentum group)
! whit
!       Spectra of core hitting electron 
!
!... Remark
!       Calculation of spectra of hitting electron is somewhat different
!       from pfeed2plot ( time integ. is KUBUNKYUSEKI in this program )
!
!    coded by Hata,M.  11/12/29
! modified by Sakagami,H. 12/08/23
! modified by Sakagami, H. 12/11/01 for time.param file
! modified by Sakagami, H. 14/05/19 for ENV and wtimen
! modified by Sakagami, H. 15/11/18 for equal division
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: ltx = 500, its = 6, itd = 5, lcx = 9
      real*8, parameter :: alcut = 0.3d0 ! MeV
      integer :: ic, icx, irx, irxp1, imx, imxp1, imxh, inx, inxp1, &
                 iyx, iyxx,iyxp1, &
                 ilsrty, ir, im, in, iy, it, itx, &
                 id1, id2, id3, id4, isned, &
                 icidl, ndiv(3)
      real*8 :: wrang, wintt, wotint, woxp, woyps, woype, wnepm1, &
                wnpnc, wlramm, wlram, wgrid, wlpwr, &
                wnc, weight, woywid, wcoefn, wcoefw, wcoefj, &
                wp, wgam, wth, wnum, wdomg, wdomg2, &
                wyps, wype, wcx(lcx), wcy(lcx), wcr(lcx), wtimen, &
                wtimex, wtime(ltx), wtotal(ltx), sh(4), sl(4), ss(4)
      real*8, allocatable :: &
                weng(:), wengb(:), wvc(:), wmue(:), &
                wpedrmny(:,:,:,:), wpedrmnyt(:,:,:,:), &
                wxhwhm(:,:), wyhwhm(:,:), &
                wava(:,:), wavat(:,:,:), wdevm(:,:), wdevp(:,:), &
                wdevmt(:,:,:), wdevpt(:,:,:), &
                wnoem(:,:), wnoep(:,:), whit(:,:,:)
      character cbuff*80, cdum*3, cident*16, cfile*128
!
! physical constant [MKSA], smevj:MeV->J
      real*8, parameter :: sme  = 9.1093897d-31, &
                           sc   = 2.99792458d08, &
                           smec = sme * sc, &
                           smecc= smec * sc, &
                           spi  = 3.1415926535897931d0, &
                           se   = 1.602176462d-19, &
                           seps0= 8.854187817d-12, &
                           smevj= 1.602176462d-13
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF2_TIMEPARAM_FILE', cfile ) 
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else    
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 ) 
      end if  
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!....                                           * read core parameter *
!..                                          * default core parameter *
      icx = 4
      do ic = 1,icx
        wcx(ic) = 25.d0 * ic
        wcy(ic) =  0.d0
        wcr(ic) = 20.d0
      end do
      call getenv ( 'FISCOF2_COREPARAM_FILE', cfile ) 
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=998 )
      else    
         open( 7,file='./core.param',form='FORMATTED',status='OLD',&
               err=8 ) 
      end if  
      read( 7, * ) icx
      if( icx .gt. lcx ) then
        write(0,*) '### ERROR: icx .gt. lcx ', icx, lcx
        stop
      end if
      do ic = 1,icx
        read( 7, * ) wcx(ic), wcy(ic), wcr(ic)
      end do
      close( 7 )
    8 continue
!....                                                  * read headers *
! ------ start -------
! ident character             = i20tmpulse       
! Sn                          =      36      
!  or
! Equal Division              =      32
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for y         =       1       
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
      read(*,*) cdum
      read(*,1000) cbuff(1:27), cdum, cident
      read(*,1001) cbuff(1:27), cdum, imx
      if( cbuff(1:2) .eq. 'Sn' ) then 
         isned = 1
      else 
         isned = 2
      end if
      read(*,1001) cbuff(1:27), cdum, inx
      read(*,1001) cbuff(1:27), cdum, irx
      read(*,1003) cbuff(1:27), cdum, wrang
      read(*,1002) cbuff(1:27), cdum, wintt
      read(*,1002) cbuff(1:27), cdum, wotint
      read(*,1002) cbuff(1:27), cdum, woxp
      read(*,1002) cbuff(1:27), cdum, woyps
      read(*,1002) cbuff(1:27), cdum, woype
      read(*,1001) cbuff(1:27), cdum, iyx
      read(*,1002) cbuff(1:27), cdum, wnepm1
      read(*,1002) cbuff(1:27), cdum, wnpnc
      read(*,1002) cbuff(1:27), cdum, wlramm
      read(*,1002) cbuff(1:27), cdum, wlram
      read(*,1002) cbuff(1:27), cdum, wgrid
      read(*,1003) cbuff(1:27), cdum, wlpwr
      read(*,1002) cbuff(1:27)
      read(*,1001) cbuff(1:27), cdum, ilsrty
 1000 format(a27,a3,a16)
 1001 format(a27,a3,i7)
 1002 format(a27,a3,f11.3)
 1003 format(a27,a3,e11.4)
      wnc    = (spi*2.d0*sc/(wlramm*1.d-6))**2 * seps0 * sme / (se**2)
      wintt  = wintt * 1.d-15
      wotint  = wotint * 1.d-15
      weight = wnc * (wlramm*1.d-6/wlram)/wnepm1
      woywid = abs( woype - woyps ) / wlramm * wlram / iyx
      wcoefn = weight / wintt / woywid
      wcoefw = wcoefn*smevj
      wcoefj = wcoefw*wotint
      write(0,*) 'ident   = ', cident
      write(0,*) 'irx     = ', irx
      if( isned .eq. 1 ) then
         write(0,*) 'Sn  imx = ', imx
      else
         write(0,*) 'EqD imx = ', imx
      end if
      write(0,*) 'inx     = ', inx
      write(0,*) 'iyx     = ', iyx
      write(0,*) 'nc #/m3 = ', wnc
      write(0,*) 'weigh   = ', weight
      write(0,*) 'delta-p = ', wrang, ' *mec'
      write(0,*) 'integ-t = ', wintt, ' sec'
      write(0,*) 'obs. Xp = ', woxp, ' micron'
      write(0,*) 'obs. Yp = ', woyps, '~', woype, ' micron'
! initialize scalar
      irxp1 = irx + 1
      imxp1 = imx + 1
      imxh  = imx / 2
      inxp1 = inx + 1
      iyxp1 = iyx + 1
!  allocate array
      allocate ( &
         weng(irx),wengb(irxp1),wvc(irx),wmue(imxp1), &
         wpedrmny(irxp1,imxp1,inxp1,0:iyx), &
         wpedrmnyt(irxp1,imxp1,inxp1,0:iyx), &
         wava(irx,0:iyx), wavat(ltx,irx,0:iyx), &
         wdevm(irx,0:iyx), wdevp(irx,0:iyx), &
         wdevmt(ltx,irx,0:iyx), wdevpt(ltx,irx,0:iyx), &
         wnoem(irx,0:iyx), wnoep(irx,0:iyx), whit(irx,0:iyx,3) )
! Sn initialize
      if( isned .eq. 1 ) then
         if( imx .eq. 36 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.93207305669784500D-01
            wmue( 3) = -9.80307489633560200D-01
            wmue( 4) = -9.60150837898254400D-01
            wmue( 5) = -9.32884603738784800D-01
            wmue( 6) = -8.98714393377304100D-01
            wmue( 7) = -8.57888221740722700D-01
            wmue( 8) = -8.10711771249771100D-01
            wmue( 9) = -7.57532685995101900D-01
            wmue(10) = -6.98745220899581900D-01
            wmue(11) = -6.34784460067749000D-01
            wmue(12) = -5.66123992204666100D-01
            wmue(13) = -4.93272125720977800D-01
            wmue(14) = -4.16768252849578900D-01
            wmue(15) = -3.37178781628608700D-01
            wmue(16) = -2.55092948675155600D-01
            wmue(17) = -1.71118497848510700D-01
            wmue(18) = -8.58771540224552200D-02
            wmue(19) =  0.00000000000000000D+00
            wmue(20) =  8.58771540224552200D-02
            wmue(21) =  1.71118497848510700D-01
            wmue(22) =  2.55092948675155600D-01
            wmue(23) =  3.37178781628608700D-01
            wmue(24) =  4.16768252849578900D-01
            wmue(25) =  4.93272125720977800D-01
            wmue(26) =  5.66123992204666100D-01
            wmue(27) =  6.34784460067749000D-01
            wmue(28) =  6.98745220899581900D-01
            wmue(29) =  7.57532685995101900D-01
            wmue(30) =  8.10711860656738300D-01
            wmue(31) =  8.57888072729110700D-01
            wmue(32) =  8.98714631795883200D-01
            wmue(33) =  9.32884305715560900D-01
            wmue(34) =  9.60150927305221600D-01
            wmue(35) =  9.80307668447494500D-01
            wmue(36) =  9.93206858634948700D-01
            wmue(37) =  1.00000000000000000D+00
         else if( imx .eq. 16 ) then
            wmue( 1) = -1.00000000000000000D+00
            wmue( 2) = -9.42144960000000000D-01
            wmue( 3) = -8.68379005000000000D-01
            wmue( 4) = -7.87674650000000000D-01
            wmue( 5) = -6.97571140000000000D-01
            wmue( 6) = -5.93635069999999900D-01
            wmue( 7) = -4.65944585000000000D-01
            wmue( 8) = -2.71738260000000000D-01
            wmue( 9) =  0.00000000000000000D+00
            wmue(10) =  2.71738260000000000D-01
            wmue(11) =  4.65944585000000000D-01
            wmue(12) =  5.93635069999999900D-01
            wmue(13) =  6.97571140000000000D-01
            wmue(14) =  7.87674650000000000D-01
            wmue(15) =  8.68379005000000000D-01
            wmue(16) =  9.42144960000000000D-01
            wmue(17) =  1.00000000000000000D+00
         else
            write(0,*) '### ERROR: lopfeedsn', imx
            stop
         end if
      else
         wdomg2 = spi / ( (imx-2)*2 + 2 )
         wdomg  = wdomg2 * 2.0d0
         wmue(1) = -1.0d0
         do im = 2, imx
            wmue(im) = cos( spi - wdomg2 - wdomg * (im-2) )
         end do
         wmue(imxp1) = 1.0d0
      end if
! initialize array
      do ir = 1, irx
         wp   = ( dble(ir)-0.5d0 ) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         weng(ir) = smecc * ( wgam - 1.d0 ) / smevj
         wvc(ir) = sqrt( 1.0d0 - 1.0d0 / ( 1.0d0 + wp**2 ) )
      end do
      do ir = 1, irxp1
         wp   = dble(ir-1) * wrang
         wgam = sqrt( 1.d0 + wp**2 )
         wengb(ir)= smecc * ( wgam - 1.d0 ) / smevj
      end do
! zero setting
      itx = 0
      do iy = 0, iyx
        do in = 1, inx
          do im = 1, imx
            do ir = 1, irx
              wpedrmny(ir,im,in,iy) = 0.0d0
              wpedrmnyt(ir,im,in,iy) = 0.0d0
            end do
          end do
        end do
      end do
      wava  = 0.d0
      wavat = 0.d0
      wdevm = 0.d0
      wdevp = 0.d0
      wdevmt = 0.d0
      wdevpt = 0.d0
      whit   = 0.d0
!....
      call fr_ginit
!.
      sh(1) = 240.0d0
      sl(1) = 0.25d0
      ss(1) = 1.0d0
      ndiv(1) = 20
      sh(2) = 240.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 90
      sh(3) = 0.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 20
      sh(4) = 0.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!
      sh(1) = 180.0d0
      sl(1) = 0.9d0
      ss(1) = 1.0d0
      ndiv(1) = 60
      sh(2) = 240.0d0
      sl(2) = 0.1d0
      ss(2) = 1.0d0
      ndiv(2) = 10
      sh(3) = 360.0d0
      sl(3) = 0.1d0
      ss(3) = 1.0d0
      ndiv(3) = 60
      sh(4) = 390.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!..
      icidl = index( cident//' ', ' ' ) - 1
      call fr_opencanvas( 1, 'pfeed2core1-'//cident(1:icidl), 10 )
      call fr_opencanvas( 2, 'pfeed2core2-'//cident(1:icidl), 10 )
      call fr_opencanvas( 3, 'pfeed2core3-'//cident(1:icidl), 10 )
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
    1 continue
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) '### ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
!$$$
      if( itx .gt. ltx ) then
         write(0,*) '### ERROR : itx .gt. ltx', itx, ltx
         stop
      end if
!$$$
      read( cbuff(9:20), '(f12.3)' ) wtime(itx)
      write(0,*) 'itx,time = ', itx, wtime(itx)
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime(itx) - wtime(itx-1) ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime(itx)-wtimen) .ge. 1.0d0 .and. &
             (wtime(itx)-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         itx = itx - 1
         go to 1
      end if
!                                             * read until 'total = ' *
    2 continue
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .eq. 'total = ') then
         read( cbuff(9:20), '(f12.3)' ) wtotal(itx)
         write(0,*) 'total, sum = ', wtotal(itx)
!...         
         call fr_canvas ( 1 )
!.
         call aveangcalc( wpedrmny, wava, wdevm, wdevp, wnoem, &
                          wnoep, wmue, irxp1, imxp1, inxp1, iyx )
!.
         call anggraph( wava, wdevm, wdevp, weng, irx, imxp1, iyx, &
                   wtime(itx), woyps, woype, cident, 'Instantaneous ' )
!
         do iy = 0, iyx
           do ir = 1, irx
              wavat(itx,ir,iy) = wava(ir,iy)
              wdevmt(itx,ir,iy) = wdevm(ir,iy)
              wdevpt(itx,ir,iy) = wdevp(ir,iy)
           end do
         end do
!...         
         call fr_canvas ( 2 )
!.
         do ic = 1,icx
           whit = 0.d0
           call corehitcalc( wava, wdevm,wdevp,wnoem,wnoep, irxp1,iyx, &
                 wcx(ic), wcy(ic), wcr(ic), whit(1,0,2), woyps, woype )
!.
           call directhitcalc( wpedrmny, wmue, irxp1,imxp1,inxp1, iyx,&
                 wcx(ic), wcy(ic), wcr(ic), whit(1,0,1), woyps, woype )
           do iy = 0, iyx
             do in = 1, inx
               do im = imxh+1, imx
                 do ir = 1, irx
                   whit(ir,iy,3) = whit(ir,iy,3) + wpedrmny(ir,im,in,iy)
                 end do
               end do
             end do
           end do
!..convert unit [number/obsy/int-t in ir-group] --> 
!                           [number/m^2/s/J] --> [number/micron^2/fs/J]
!..wcoefn = weight / wintt / woywid = 
!          weight[#/m^2/1-particle] / int-time[s] / diveided-y-width[m]
           do iy = 0, iyx
             do ir = 1, irx
               whit(ir,iy,1) = whit(ir,iy,1) / &
               (wengb(ir+1)-wengb(ir)) / smevj * wcoefn * 1.0d-27 / iyx
               whit(ir,iy,2) = whit(ir,iy,2) / &
               (wengb(ir+1)-wengb(ir)) / smevj * wcoefn * 1.0d-27 / iyx
               whit(ir,iy,3) = whit(ir,iy,3) / &
               (wengb(ir+1)-wengb(ir)) / smevj * wcoefn * 1.0d-27 / iyx
             end do
           end do
           whit = log10( whit + 1.0d-30 )
           call hitgraph( whit, weng, irx, iyx, 3, &
                wtime(itx), wcx(ic), wcy(ic), wcr(ic), woyps, woype, &
                cident, 'Instantaneous ' )
         end do
!...
         do iy = 0, iyx
           do in = 1, inx
             do im = 1, imx
               do ir = 1, irx
                 wpedrmny(ir,im,in,iy) = 0.0d0
               end do
             end do
           end do
         end do
!..
         if( abs(wtime(itx)-wtimex) .le. 1.0d0 .or. &
                (wtime(itx)-wtimex) .gt. 0.0d0 ) then
            write(0,*) 'process was stopped by time.param.', wtimex
            go to 90
         end if
         go to 1
      end if
!...
      read( cbuff, '(4i4,f12.3)' ) id1,id2,id3,id4,wnum
      if( isned .eq. 2 ) id2 = imxp1 - id2

! Momentum distribution Ppara / Pperp / Omega
      wpedrmny(id1,id2,id3,id4) = wpedrmny(id1,id2,id3,id4) + wnum
      wpedrmnyt(id1,id2,id3,id4) = wpedrmnyt(id1,id2,id3,id4) + wnum
      wpedrmny(id1,id2,id3,0)   = wpedrmny(id1,id2,id3,0) + wnum
      wpedrmnyt(id1,id2,id3,0)  = wpedrmnyt(id1,id2,id3,0) + wnum

      goto 2

   90 continue
!...         
      write(0,*) 'reading data ',itx
!....
      call fr_canvas ( 1 )
!.
      call aveangcalc( wpedrmnyt, wava, wdevm, wdevp, wnoem, wnoep, &
                       wmue, irxp1, imxp1, inxp1, iyx )
!.
      call anggraph( wava, wdevm, wdevp, weng, irx, imxp1, iyx, &
                     1.0d30, woyps, woype, cident, 'Time-Integrated ' )
!..
      call fr_canvas ( 2 )
!.
      do ic = 1,icx
        whit = 0.d0
        call corehitcalc( wava, wdevm,wdevp,wnoem,wnoep, irxp1, iyx, &
                 wcx(ic), wcy(ic), wcr(ic), whit(1,0,2), woyps, woype )
!.
        call directhitcalc( wpedrmnyt, wmue, irxp1, imxp1, inxp1, iyx, &
                 wcx(ic), wcy(ic), wcr(ic), whit(1,0,1), woyps, woype )
        do iy = 0, iyx
          do in = 1, inx
            do im = imxh+1, imx
              do ir = 1, irx
                whit(ir,iy,3) = whit(ir,iy,3) + wpedrmnyt(ir,im,in,iy)
              end do
            end do
          end do
        end do
!..convert unit [number/obsy in itx and ir-group] --> 
!                      [number/m^2/J in itx(s)] --> [number/micron^2/J]
        do iy = 0, iyx
          do ir = 1, irx
            whit(ir,iy,1) = whit(ir,iy,1) / &
                     (wengb(ir+1)-wengb(ir)) / &
                     smevj * wcoefn * 1.0d-12 * wotint / iyx
            whit(ir,iy,2) = whit(ir,iy,2) / &
                     (wengb(ir+1)-wengb(ir)) / &
                     smevj * wcoefn * 1.0d-12 * wotint / iyx
            whit(ir,iy,3) = whit(ir,iy,3) / &
                     (wengb(ir+1)-wengb(ir)) / &
                     smevj * wcoefn * 1.0d-12 * wotint / iyx
          end do
        end do
!..output
        cbuff = 'cx-'
        write( cbuff(2:2), '(i1)' ) ic
        open( 7, form='FORMATTED', &
                 file='corehit-'//cbuff(1:3)//cident(1:icidl)//'.txt' )
        write( 7, * ) '# xpos, ypos, radius of core'
        write( 7, '(a2,3f10.4)' ) '# ', wcx(ic), wcy(ic), wcr(ic)
        write( 7, * ) cident
        write( 7, * ) 'Energy[MeV] #model #direct #source'
        do ir = 1,irx
           write( 7, '(4e14.5)' ) &
                     weng(ir), whit(ir,0,1), whit(ir,0,2), whit(ir,0,3)
        end do
        close( 7 )
        whit = log10( whit + 1.0d-30 )
        call hitgraph ( whit, weng, irx, iyx, 3, &
              1.0d30, wcx(ic), wcy(ic), wcr(ic), woyps, woype, &
              cident, 'Time-Integrated ' )
      end do
!...
      call fr_canvas ( 3 )
!..
      allocate( wxhwhm(itx,irx), wyhwhm(itx,irx) )
      do ir = 1, irx
         do it = 1, itx
            wxhwhm(it,ir) = wtime(it)
            wyhwhm(it,ir) = weng(ir)
         end do
      end do
      iyxx = iyx
      if( iyx .eq. 1 ) iyxx = 0
      do iy = 0, iyxx
! average angle
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, weng(irx), 13 )
         call fr_xyname( 'Time[fs]', 'Energy[MeV]' )
         call fr_setcontour( -90.0d0, 90.0d0, 2 )
         call fr_hlsrecall ( 2 )
         call fr_sqrcontour( wxhwhm, wyhwhm, wavat(1:itx,1:irx,iy), &
                             itx, irx, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, 'Y pos.:', 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
         else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0,15.0d0, 'mean angle[deg.]', &
                          7,1,-1,0,0 )
!
! sta. dev.(-) of average angle
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, weng(irx), 13 )
         call fr_xyname( 'Time[fs]', 'Energy[MeV]' )
         call fr_setcontour( 0.0d0, 90.0d0, 2 )
         call fr_hlsrecall ( 1 )
         call fr_sqrcontour( wxhwhm, wyhwhm, wdevmt(1:itx,1:irx,iy), &
                             itx, irx, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, 'Y pos.:', 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
         else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0,15.0d0, &
                    'st. deviation(-) of ave. ang.[deg.]', 7,1,-1,0,0 )
!
! sta. dev.(+) of average angle
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, weng(irx), 13 )
         call fr_xyname( 'Time[fs]', 'Energy[MeV]' )
         call fr_setcontour( 0.0d0, 90.0d0, 2 )
         call fr_sqrcontour( wxhwhm, wyhwhm, wdevpt(1:itx,1:irx,iy), &
                             itx, irx, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 450.0d0, 'Y pos.:', 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( woyps, woype, 7, 1 )
         else
            wyps = woyps + ( woype-woyps ) / iyx * (iy-1)
            wype = woyps + ( woype-woyps ) / iyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0,15.0d0, &
                    'st. deviation(+) of ave. ang.[deg.]', 7,1,-1,0,0 )
      end do
      deallocate( wxhwhm, wyhwhm )
!.... output text file
!..   ave. angle and st. dev.
      do iy = 0,iyx
        cbuff = 'yxx-'
        write( cbuff(2:3), '(i2.2)' ) iy
        open( 7, form='FORMATTED', &
              file='aveangdev-'//cbuff(1:4)//cident(1:icidl)//'.txt' )
        write( 7, * ) cident
        write( 7, * ) 'ti-es[MeV] ave.ang. st.dev.minus plus[degree]'
        do ir = 1, irx
           write( 7, '(f8.3,3e13.5)' ) &
                      weng(ir), wava(ir,iy), wdevm(ir,iy), wdevp(ir,iy)
        end do
        close( 7 )
      end do
!.... 
      call fr_gend
!....
      stop
!....
  999 continue
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
!....
  998 continue
      write(0,*) '### ERROR: core param file not found. file="', &
         trim(cfile), '"'
      stop
      end
!----------------------------------------------------------------------
      subroutine yposchar( rys, rye, kcol, kbx )
!
      implicit none
      integer :: istr, ichs, kcol, kbx
      real*8 :: rys, rye
      character :: cbuff*16, cstr*8
!....
      write( cstr, '(f5.1)' ) rys
      ichs = 1
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      ichs = ichs+istr
      cbuff(ichs:ichs+2) = ' ~ '
      ichs = ichs+3
      write( cstr, '(f5.1)' ) rye
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      call fr_fpchars ( 1.0d0, 0.0d0, cbuff(1:ichs+istr-1), &
                        kcol, kbx, -1, 0, 1 )
!....
      return
      end
!----------------------------------------------------------------------
! The following is wroted by Hata M. (Nagoya Univ.)
!----------------------------------------------------------------------
      subroutine aveangcalc( rdat, rava, rdevm, rdevp, rnoem, rnoep, &
                             rmue, krx1, kmx1, knx1, kyx )
!
      implicit none
      integer :: krx1, kmx1, knx1, kyx, iy, ir, im, in, im90
      real*8 :: rdat(krx1,kmx1,knx1,0:kyx), &
                adomg, adomg2, ath, adth, aomg, ax, ay, az, &
                rava(krx1-1,0:kyx), anoe(krx1-1,0:kyx), &
                rnoem(krx1-1,0:kyx), rnoep(krx1-1,0:kyx), &
                rdevm(krx1-1,0:kyx), rdevp(krx1-1,0:kyx), &
                rmue(kmx1)
!....
      rava = 0.d0
      anoe = 0.d0
      rnoem = 0.d0
      rnoep = 0.d0
      rdevm = 0.d0
      rdevp = 0.d0
      adomg  = acos(-1.d0)*2.0d0 / ( knx1 - 1 )
      adomg2 = adomg / 2.0d0
      im90 = (kmx1 + 1) / 2
         do iy = 0, kyx
           do in = 1, knx1-1
             do im = im90, kmx1-1
               do ir = 1, krx1-1
!                ath  = acos(rmue(im))
                 ath  = ( acos(rmue(im)) + acos(rmue(im+1)) ) / 2.d0
                 aomg = adomg * (in-1) - adomg2
                 ax = ir * cos(ath)
                 ay = ir * sin(ath) * cos(aomg)
                 az = ir * sin(ath) * sin(aomg)
                 ath = 180.d0 / acos(-1.d0) * atan2(ay,ax)
                 rava(ir,iy) = rava(ir,iy) + ath * rdat(ir,im,in,iy)
                 anoe(ir,iy) = anoe(ir,iy) + rdat(ir,im,in,iy)
               end do
             end do
           end do
         end do
         do iy = 0, kyx
           do ir = 1, krx1-1
             if(anoe(ir,iy) .lt. 0.1d0 ) anoe(ir,iy) = 1.d0
             rava(ir,iy) = rava(ir,iy) / anoe(ir,iy)
           end do
         end do
!
         do iy = 0, kyx
           do in = 1, knx1-1
             do im = im90, kmx1-1
               do ir = 1, krx1-1
                 ath  = ( acos(rmue(im)) + acos(rmue(im+1)) ) / 2.d0
                 aomg = adomg * (in-1) - adomg2
                 ax = ir * cos(ath)
                 ay = ir * sin(ath) * cos(aomg)
                 az = ir * sin(ath) * sin(aomg)
                 ath = 180.d0 / acos(-1.d0) * atan2(ay,ax)
                 adth= ath-rava(ir,iy)
                 if(adth .lt. 0.d0) then
                   rdevm(ir,iy) = rdevm(ir,iy) + adth**2 * &
                                  rdat(ir,im,in,iy)
                   rnoem(ir,iy) = rnoem(ir,iy) + rdat(ir,im,in,iy)
                 else
                   rdevp(ir,iy) = rdevp(ir,iy) + adth**2 * &
                                  rdat(ir,im,in,iy)
                   rnoep(ir,iy) = rnoep(ir,iy) + rdat(ir,im,in,iy)
                 end if
               end do
             end do
           end do
         end do
         do iy = 0, kyx
           do ir = 1, krx1-1
              if(rnoem(ir,iy) .lt. 0.1d0) then
                rdevm(ir,iy) = sqrt(rdevm(ir,iy) / 1.d0)
                if(rdevm(ir,iy) .lt. 0.1d0) rdevm(ir,iy) = 0.1d0
              else
                rdevm(ir,iy) = sqrt(rdevm(ir,iy) / rnoem(ir,iy))
              end if
              if(rnoep(ir,iy) .lt. 0.1d0) then
                rdevp(ir,iy) = sqrt(rdevp(ir,iy) / 1.d0)
              else
                rdevp(ir,iy) = sqrt(rdevp(ir,iy) / rnoep(ir,iy))
              end if
! maybe not needed because of line 555
              if(rdevm(ir,iy) .lt. 0.1d0) rdevm(ir,iy) = 0.1d0
! for avoiding derf(inf)
              if(rdevp(ir,iy) .lt. 0.1d0) rdevp(ir,iy) = 0.1d0
           end do
         end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine anggraph( rava, rdevm, rdevp, rxp, krx, kmx1, kyx, &
                          rtime, royps, roype, eident, ecom )
!
      implicit none
      integer :: krx, kmx1, kyx, iy, iyxx, icol, im90
      real*8 :: rxp(krx), &
                rtime, royps, roype, arx, ayps, aype, &
                rava(krx,0:kyx), rdevm(krx,0:kyx), &
                rdevp(krx,0:kyx), wam(krx), wap(krx)
      character :: cbuff*16, eident*(*), ecom*(*)
!....
      im90 = (kmx1 + 1) / 2

      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = rxp(krx)
      iyxx = kyx
      if( kyx .eq. 1 ) iyxx = 0
! mean ang.
      do iy = 0, iyxx
         wam(:) = rava(:,iy) - rdevm(:,iy)
         wap(:) = rava(:,iy) + rdevp(:,iy)
         call fr_gclear
         call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( 0.0d0, arx, -90.0d0, 90.0d0 ,13 )
         call fr_xyname( 'Energy[MeV]', 'Angle[deg.]' )
         call fr_graph2d( rxp, rava(1,iy), krx, 2, 1 )
         call fr_graph2d( rxp, wam, krx, 1, 1 )
         call fr_graph2d( rxp, wap, krx, 3, 1 )
         call fr_fpchars ( 500.0d0, 425.0d0, 'Mean Ang.', &
                           2, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 450.0d0, '- st. dev.', &
                           1, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 475.0d0, '+ st. dev.', &
                           3, 1, -1, 0, 0 )
         call fr_fpchars ( 5.0d0, 450.0d0, 'Y pos.:', 7, 1, -1, 0, 0 )
         if( iy .eq. 0 ) then
            call yposchar( royps, roype, 7, 1 )
         else
            ayps = royps + ( roype-royps ) / kyx * (iy-1)
            aype = royps + ( roype-royps ) / kyx *  iy
            call yposchar( ayps, aype, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 200.0d0,15.0d0, ecom//'Mean Angle (X-Y)', &
                              7, 1, -1, 0, 0 )
         call fr_fpchars ( 525.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine directhitcalc( rdat, rmue, krx1, kmx1, knx1, kyx, &
                          rcx, rcy, rcr, rhit, royps, roype )
!
      implicit none
      integer :: krx1, kmx1, knx1, kyx, iy, ir, im, in, im90, idiv
      real*8 :: rdat(krx1,kmx1,knx1,0:kyx), rmue(kmx1), &
                royps, roype, ayph, adx, ady, &
                ath, aths, athe, axp, ayp, artd, ar2, rcx, rcy, rcr,&
                ax, ay, az, aomg, adomg, adomg2, &
                athit, rhit(krx1-1,0:kyx)
      integer, parameter :: idivx = 10
!....
      athit = 0.d0
      im90 = (kmx1 + 1) / 2
      adomg  = acos(-1.d0)*2.0d0 / ( knx1 - 1 )
      adomg2 = adomg / 2.0d0
      do iy = 1, kyx
       do idiv = 1,idivx
       !ayph = royps + ( roype-royps ) / kyx *  (iy-0.5d0)
        ayph = royps + ( roype-royps ) / kyx * &
                       ( (iy-1) + (idiv-0.5d0)/idivx )
        adx  = - rcx
        ady  = ayph - rcy
        ar2  = rcr**2
        artd = sqrt( ar2**2 * ady**2 + &
                        (adx**2 + ady**2) * (ar2 * adx**2 - ar2**2) )
        ayp  = ( ar2*ady + artd ) / (adx**2 + ady**2)
        axp  = (ar2 - ady * ayp) / adx - adx
        ayp  = ayp + rcy  ! inverse conversion
        athe = 180.d0 / acos(-1.d0) * atan2((ayp - ayph),axp)
        ayp  = ( ar2*ady - artd ) / (adx**2 + ady**2)
        axp  = (ar2 - ady * ayp) / adx - adx
        ayp  = ayp + rcy  ! inverse conversion
        aths = 180.d0 / acos(-1.d0) * atan2((ayp - ayph),axp)
        do in = 1, knx1-1
          do im = im90, kmx1-1
            do ir = 1, krx1-1
              ath  = ( acos(rmue(im)) + acos(rmue(im+1)) ) / 2.d0
              aomg = adomg * (in-1) - adomg2
              ax = ir * cos(ath)
              ay = ir * sin(ath) * cos(aomg)
              az = ir * sin(ath) * sin(aomg)
              ath = 180.d0 / acos(-1.d0) * atan2(ay,ax)
              if( ath .le. athe .and. ath .ge. aths ) then
                rhit(ir,iy) = rhit(ir,iy) + rdat(ir,im,in,iy)/idivx
              end if
            end do
          end do
        end do
       end do
      end do
      do iy = 1,kyx
        do ir = 1,krx1-1
          athit  = athit + rhit(ir,iy)
          rhit(ir,0) = rhit(ir,0) + rhit(ir,iy)
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine corehitcalc( rava, rdevm,rdevp,rnoem,rnoep,krx1,kyx, &
                          rcx, rcy, rcr, rhit, royps, roype )
!
      implicit none
      integer :: krx1, kyx, iy, ir, idiv
      real*8 :: royps, roype, ayph, ar2, artd, axp, ayp, &
                aths, athe, rcx, rcy, rcr,&
                accs, acce, adx, ady,&
                athit, derf,&
                rava(krx1-1,0:kyx), rdevm(krx1-1,0:kyx), &
                rdevp(krx1-1,0:kyx), &
                rnoem(krx1-1,0:kyx), rnoep(krx1-1,0:kyx), &
                rhit(krx1-1,0:kyx)
      integer, parameter :: idivx = 10
!     character :: cbuff*16, eident*(*), ecom*(*)
!....
      athit = 0.d0
      do iy = 1, kyx
       do idiv = 1,idivx ! divide
       !ayph = royps + ( roype-royps ) / kyx * (iy-0.5d0)
        ayph = royps + ( roype-royps ) / kyx * &
                       ( (iy-1) + (idiv-0.5d0)/idivx )
        adx  = - rcx
        ady  = ayph - rcy
        ar2  = rcr**2
        artd = sqrt( ar2**2 * ady**2 + &
                          (adx**2 + ady**2) * (ar2 * adx**2 - ar2**2) )
        ayp  = ( ar2*ady + artd ) / (adx**2 + ady**2)
        axp  = (ar2 - ady * ayp) / adx - adx
        ayp  = ayp + rcy  ! inverse conversion
        athe = 180.d0 / acos(-1.d0) * atan2((ayp - ayph),axp)
        ayp  = ( ar2*ady - artd ) / (adx**2 + ady**2)
        axp  = (ar2 - ady * ayp) / adx - adx
        ayp  = ayp + rcy  ! inverse conversion
        aths = 180.d0 / acos(-1.d0) * atan2((ayp - ayph),axp)
        do ir = 1, krx1-1
          acce = athe - rava(ir,iy)
          accs = aths - rava(ir,iy)
          if(accs*acce .lt. 0.d0) then
            rhit(ir,iy) = rhit(ir,iy) + rnoep(ir,iy) / idivx * &
                         derf(acce/rdevp(ir,iy)) &
                       - rnoem(ir,iy) / idivx * derf(accs/rdevm(ir,iy))
          else
            if(accs .ge. 0.d0) then
              rhit(ir,iy) = rhit(ir,iy) + rnoep(ir,iy) / idivx * &
                            derf(acce/rdevp(ir,iy)) &
                       - rnoep(ir,iy) / idivx * derf(accs/rdevp(ir,iy))
            else
              rhit(ir,iy) = rhit(ir,iy) + rnoem(ir,iy) / idivx * &
                            derf(acce/rdevm(ir,iy)) &
                       - rnoem(ir,iy) / idivx * derf(accs/rdevm(ir,iy))
            end if
          end if
          if(rhit(ir,iy) .lt. 0.d0) then
            write(*,*) accs, acce, rava(ir,iy)
            write(*,*) 'hit', rhit(ir,iy)
          end if
        end do
       end do 
      end do
      do iy = 1, kyx
        do ir = 1,krx1-1
          athit  = athit + rnoem(ir,iy) + rnoep(ir,iy)
          rhit(ir,0) = rhit(ir,0) + rhit(ir,iy)
        end do
      end do
      athit = 0.d0
      do ir = 1,krx1-1
        athit  = athit + rhit(ir,0)
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine hitgraph( rhit, reng, krx, kyx, khx, &
                      rtime, rcx, rcy, rcr, royps, roype, eident, ecom )
!
      implicit none
      integer :: i, iy, krx, kyx, khx, iyxx
      real*8 :: reng(krx), &
                rtime, rcx, rcy, rcr, arx, anumx, &
                royps, roype, wyps, wype, &
                rhit(krx,0:kyx,khx)
      character :: cbuff*48, eident*(*), ecom*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = reng(krx)
      iyxx = kyx
      if(iyxx .eq. 1) iyxx = 0
      do iy = 0,iyxx
        anumx=1.d-30
        do i = 1,krx
          anumx=max(anumx,rhit(i,iy,3))
        end do
        anumx=int( anumx ) + 1
!.
        call fr_gclear
        call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
        call fr_setaxis( 2 )
        call fr_frame2d( 0.0d0, arx, anumx - 6.d0, anumx ,13 )
        call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
        call fr_graph2d( reng, rhit(1,iy,3), krx, 7, 1 ) ! all ele.
        call fr_graph2d( reng, rhit(1,iy,1), krx, 1, 1 ) ! direct
        call fr_graph2d( reng, rhit(1,iy,2), krx, 2, 1 ) ! model
        call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
        call fr_fpchars ( 150.0d0,15.0d0, &
                             ecom//'spectra of hitting electrons', &
                                7, 1, -1, 0, 0 )
        call fr_fpchars ( 525.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
        call fr_fpchars ( 500.0d0, 425.0d0, ' Model Calc.', 2,1,-1,0,0 )
        call fr_fpchars ( 500.0d0, 450.0d0, 'Direct Calc.', 1,1,-1,0,0 )
        call fr_fpchars ( 500.0d0, 475.0d0, 'All electron', 7,1,-1,0,0 )
        call fr_fpchars ( 5.0d0, 450.0d0, 'Y pos.:', 7, 1, -1, 0, 0 )
        if( iy .eq. 0 ) then
            call yposchar( royps, roype, 7, 1 )
        else
            wyps = royps + ( roype-royps ) / kyx * (iy-1)
            wype = royps + ( roype-royps ) / kyx *  iy
            call yposchar( wyps, wype, 7, 1 )
         end if
        cbuff(21:48) = '     ,      ,     [micron]'
        write( cbuff(21:25), '(f5.1)' ) rcx
        write( cbuff(27:32), '(f6.1)' ) rcy
        write( cbuff(34:38), '(f5.1)' ) rcr
        call fr_fpchars ( 5.0d0, 475.0d0, 'core param.(x,y,r):', &
                          7, 1, -1, 0, 0 )
        call fr_fpchars ( 175.0d0, 475.0d0, cbuff(21:46), 7,1,-1,0,0 )
      end do

      return
      end
