#!/bin/csh

binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = 'fde'
    ioflag = 010315
 &end
EOD

binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = 'fdi'
    ioflag = 020205
 &end
EOD

binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = 'fje'
    ioflag = 1005
 &end
EOD

binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = 'fji'
    ioflag = 505
 &end
EOD

foreach kind (fte fede fedi fdc fea fer fba fbr)
binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = '$kind'
    ioflag = 5
 &end
EOD
end

binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = 'pem'
    ioflag = 115
 &end
EOD

foreach kind (pim peph)
binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = '$kind'
    ioflag = 5
 &end
EOD
end

foreach kind (pee pie piph)
binoh2plot << EOD
 &param
    cbifntp = './bin/fort.%%.##'
    cfrfntp = './plt/&K-&I-##'
    ckind  = '$kind'
    ioflag = 15
 &end
EOD
end

exit
