********************************************************
*                 F  R  A  M  E  S  V.7                *
*      PLT FILE DATA STORING SUBROUTINES FOR FRAMES    *
*                PROGRAMMED BY T.TAGUCHI               *
********************************************************
      SUBROUTINE FR_FILEMAX(MAXP)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT

      IF (IGCANVAS.LT.0) RETURN

      CALL SETGFILEMAXPAGE(MAXP)

      RETURN
      END

      SUBROUTINE GFILEFLUSHCLS

      CALL FLUSHBUFFER(IND,-2)

      RETURN
      END

      SUBROUTINE FLUSHBUFFER(IND,IE)
      COMMON /GCANVASCOM/ IGCANVAS,IGPLT
      CHARACTER CH*20

      IF (IE.LT.0) THEN
         CALL FLUSHBUFFERPAGES(IER,-IE)
       ELSE
         IER = IE
      ENDIF

      IF (IER.GT.1) THEN
         WRITE(CH,*) IER
         CALL FRAMESERROR(
     +          'MAXIMUM GRAPHIC FILE PAGE IS EXCEEDED !  MAX(kB)='//CH)
         IND = 1
       ELSE IF (IER.EQ.1) THEN
         CALL FRAMESERROR('GRAPHIC FILING ERROR: NO MORE SPACE !')
         IND = 1
       ELSE
         IND = 0
      ENDIF

      IF (IND.NE.0) IGPLT = -1

      RETURN
      END

      SUBROUTINE GFILEFRAME(X1,X2,Y1,Y2,IND)
      COMMON /GFILEFRCOM/ XTAN,YTAN,ZTAN,X0,Y0,Z0
      REAL*8 X1,X2,Y1,Y2,XTAN,YTAN,ZTAN,X0,Y0,Z0,XMAX
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      PARAMETER (XMAX=2.D7)
      SAVE /GFILEFRCOM/

      CALL GSENDBYTE(2,1)
      CALL GSENDBYTE(IND,1)
      CALL GSENDBYTE(LOGFORM+LABELAX*8,1)
      CALL GSEND8BYTE(X1,X2,1,0)
      CALL GSEND8BYTE(Y1,Y2,1,0)

      XTAN = XMAX/(X2 - X1)
      YTAN = XMAX/(Y2 - Y1)
*      X0   = MIN(X1,X2)
*      Y0   = MIN(Y1,Y2)
      X0   = (X1+X2)/2
      Y0   = (Y1+Y2)/2

      RETURN
      END

      SUBROUTINE GFILE3FRAME(X1,X2,Y1,Y2,Z1,Z2,IND)
      COMMON /GFILEFRCOM/ XTAN,YTAN,ZTAN,X0,Y0,Z0
      REAL*8 X1,X2,Y1,Y2,Z1,Z2,XTAN,YTAN,ZTAN,X0,Y0,Z0,XMAX
      COMMON /DEFFRAMCOM/ IDFFR2,IDFFR3,LOGFORM,LABELAX
      PARAMETER (XMAX=2.D7)
      SAVE /GFILEFRCOM/

      CALL GSENDBYTE(IND,1)
      CALL GSENDBYTE(LOGFORM+LABELAX*8,1)
      CALL GSEND8BYTE(X1,X2,1,0)
      CALL GSEND8BYTE(Y1,Y2,1,0)
      CALL GSEND8BYTE(Z1,Z2,1,0)

      XTAN = XMAX/(X2 - X1)
      YTAN = XMAX/(Y2 - Y1)
      ZTAN = XMAX/(Z2 - Z1)
*      X0   = MIN(X1,X2)
*      Y0   = MIN(Y1,Y2)
*      Z0   = MIN(Z1,Z2)
      X0   = (X1+X2)/2
      Y0   = (Y1+Y2)/2
      Z0   = (Z1+Z2)/2

      RETURN
      END

      SUBROUTINE GSEND8BYTE(X,Y,N,MODE)
      COMMON /GFILEFRCOM/ XTAN,YTAN,ZTAN,X0,Y0,Z0
      REAL*8 X(N),Y(N),XTAN,YTAN,ZTAN,X0,Y0,Z0
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP

      IF (MODE.LE.0) THEN
         CALL GSENDDDOUBLE1(X(1))
         IF (MODE.EQ.0) CALL GSENDDDOUBLE1(Y(1))
       ELSE IF (MODE.EQ.1) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(XTAN*(X(I)-X0))
            CALL GSENDSREAL(YTAN*(Y(I)-Y0))
         ENDDO
       ELSE IF (MODE.EQ.2) THEN
         DO I = 1, N
            CALL GSENDDOUBLE1(X(I))
            CALL GSENDDOUBLE1(Y(I))
         ENDDO
       ELSE IF (MODE.EQ.3) THEN
         DO I = 1, N
            CALL GSENDDOUBLE1(X(I))
         ENDDO
       ELSE IF (MODE.EQ.4) THEN
         CALL GSENDDDOUBLE1(Y(1))
         DO I = 1, N
            CALL GSENDDOUBLE1(X(I)-Y(1))
         ENDDO
       ELSE IF (MODE.EQ.5) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(XTAN*(X(I)-X0))
         ENDDO
       ELSE IF (MODE.EQ.6) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(YTAN*(Y(I)-Y0))
         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE GSEND38BYTE(X,Y,Z,N,MODE)
      PARAMETER (XTC=1.D6/36.D0,YTC=1.D7,ZTC=1.D7)
      COMMON /GFILEFRCOM/ XTAN,YTAN,ZTAN,X0,Y0,Z0
      REAL*8 X(N),Y(N),Z(1),XTAN,YTAN,ZTAN,X0,Y0,Z0
      COMMON /REGIONSCOM/ NXDMIN,NXDMAX,NYDMIN,NYDMAX,NSTEP

      IF (MODE.EQ.0) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(ZTAN*(Z(I)-Z0))
         ENDDO
       ELSE IF (MODE.EQ.1) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(XTAN*(X(I)-X0))
            CALL GSENDSREAL(YTAN*(Y(I)-Y0))
            CALL GSENDSREAL(ZTAN*(Z(I)-Z0))
         ENDDO
       ELSE IF (MODE.EQ.2) THEN
         DO I = 1, N
            CALL GSENDDOUBLE1(X(I))
            CALL GSENDDOUBLE1(Y(I))
            CALL GSENDDOUBLE1(Z(I))
         ENDDO
       ELSE IF (MODE.EQ.5) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(YTAN*(Y(I)-Y0))
            CALL GSENDSREAL(ZTAN*(Z(I)-Z0))
         ENDDO
       ELSE IF (MODE.EQ.6) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(XTAN*(X(I)-X0))
            CALL GSENDSREAL(ZTAN*(Z(I)-Z0))
         ENDDO
       ELSE IF (MODE.EQ.7) THEN
         IF (NSTEP.GE.0) THEN
            NS = 1
          ELSE
            NS = -NSTEP
         ENDIF
         DO I = 1, N*NS, NS
            CALL GSENDSREAL(XTAN*(X(I)-X0))
            CALL GSENDSREAL(YTAN*(Y(I)-Y0))
         ENDDO
*       ELSE IF (MODE.EQ.8) THEN
*         DO I = 1, N
*            CALL GSENDSREAL(XTC*X(I))
*            CALL GSENDSREAL(YTC*Y(I))
*            CALL GSENDSREAL(ZTC*Z(I))
*         ENDDO
      ENDIF

      RETURN
      END

      SUBROUTINE GSENDDOUBLE1(F)
      REAL*8 F
      CHARACTER CH*20
*     REQUIRE 3 BYTES

      WRITE(CH,'(E11.5)') F
      CH(2:2) = ' '
      IF (F.GE.0.D0) CH(1:1) = ' '
      IF (CH(8:8).EQ.'E'.OR.CH(8:8).EQ.'e') CH(8:8) = ' '
      READ(CH,'(I7,I4)',err=999) N1,N2
      IF (N2.LE.-32) THEN
          N1 = 0
        ELSE
          N1 = IOR(ISHFT(N1,6),IAND(N2,63))
      ENDIF
      CALL GSENDBYTE(N1,3)
      RETURN
  999 continue
      WRITE(CH,'(E11.5)') F
      write(*,*) 'Frames ERROR in GSENDDOUBLE1', F, CH
      CALL GSENDBYTE(0,3)
      return
      END

      SUBROUTINE GSENDDDOUBLE1(F)
      REAL*8 F
      CHARACTER CH*20
*     REQUIRE 5 BYTES

      WRITE(CH,'(E15.9)') F
      CH(2:2) = ' '
      IF (F.GE.0.D0) CH(1:1) = ' '
      IF (CH(12:12).EQ.'E'.OR.CH(12:12).EQ.'e') CH(12:12) = ' '
      READ(CH,'(I11,I4)',err=999) N1,N2
      CALL GSENDBYTE(N1,4)
      CALL GSENDBYTE(N2,1)
      RETURN
  999 continue
      WRITE(CH,'(E15.9)') F
      write(*,*) 'Frames ERROR in GSENDDDOUBLE1', F, CH
      CALL GSENDBYTE(0,4)
      CALL GSENDBYTE(0,1)
      return
      END

      SUBROUTINE GSENDBYTE(B,N)
      INTEGER B(N)

      CALL GSEND1BYTEBYTES(B,N,IER)
      IF (IER.NE.0) CALL FLUSHBUFFER(IND,IER)

      RETURN
      END

      SUBROUTINE GSENDCHAR(B,N)
      CHARACTER B*(*)

      CALL GSEND1BYTECHARS(B,-N,IER)
      IF (IER.NE.0) CALL FLUSHBUFFER(IND,IER)

      RETURN
      END

      SUBROUTINE GSENDSREAL(T)
      REAL*8 T
*     REQUIRE 3 BYTES

      CALL GSENDSREALPROC(NINT(T),3,IER)
      IF (IER.NE.0) CALL FLUSHBUFFER(IND,IER)

      RETURN
      END

      SUBROUTINE GSENDHLSDATA(SH,SL,SS,NDIV,MODE)
      REAL*8 SH(*),SL(*),SS(*)

      CALL GSENDHLSDATAPROC(SH,SL,SS,NDIV,MODE,IER)
      IF (IER.NE.0) CALL FLUSHBUFFER(IND,IER)

      RETURN
      END
