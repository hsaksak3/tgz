!-----------------------------------------------------------------------
! Compute 2D Particle Electron Force
!
      subroutine c2pef
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/09
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ixei, ixeh, iyei, iyeh
      real*8  :: wdxi,wx1i,wx2i,wx3i,wx4i, &
                 wdxh,wx1h,wx2h,wx3h,wx4h, &
                 wdyi,wy1i,wy2i,wy3i,wy4i, &
                 wdyh,wy1h,wy2h,wy3h,wy4h, &
                 wex,wbx,wez,wbz,wey,wby, &
                 wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2pef', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP          PRIVATE(ixei,wdxi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  ixeh,wdxh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                  iyei,wdyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  iyeh,wdyh,wy1h,wy2h,wy3h,wy4h, &
!$OMP                  wex,wbx,wez,wbz,wey,wby, &
!$OMP                  wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac)
      do i = lnoes, lnoee
!..
         ixei = sxe(i)
         wdxi = sxe(i) - ixei - s1o2
         wx1i = (s1o2-wdxi)**3*s1o6
         wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
         wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
         wx4i = (s1o2+wdxi)**3*s1o6
!
         ixeh = sxe(i) + s1o2
         wdxh = sxe(i) - ixeh
         wx1h = (s1o2-wdxh)**3*s1o6
         wx2h = (s1o2+wdxh)**2*(wdxh-s3o2)*s1o2 + s2o3
         wx3h =-(s1o2-wdxh)**2*(wdxh+s3o2)*s1o2 + s2o3
         wx4h = (s1o2+wdxh)**3*s1o6
!.
         iyei = sye(i)
         wdyi = sye(i) - iyei - s1o2
         wy1i = (s1o2-wdyi)**3*s1o6
         wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
         wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
         wy4i = (s1o2+wdyi)**3*s1o6
!
         iyeh = sye(i) + s1o2
         wdyh = sye(i) - iyeh
         wy1h = (s1o2-wdyh)**3*s1o6
         wy2h = (s1o2+wdyh)**2*(wdyh-s3o2)*s1o2 + s2o3
         wy3h =-(s1o2-wdyh)**2*(wdyh+s3o2)*s1o2 + s2o3
         wy4h = (s1o2+wdyh)**3*s1o6
#ifdef OHHELP
         ixei = ixei - oh_ixs
         ixeh = ixeh - oh_ixs
         iyei = iyei - oh_iys
         iyeh = iyeh - oh_iys
#endif
!..
         wex = sex(ixeh-1,iyei-1)*wx1h*wy1i+sex(ixeh  ,iyei-1)*wx2h*wy1i &
            + sex(ixeh+1,iyei-1)*wx3h*wy1i+sex(ixeh+2,iyei-1)*wx4h*wy1i &
            + sex(ixeh-1,iyei  )*wx1h*wy2i+sex(ixeh  ,iyei  )*wx2h*wy2i &
            + sex(ixeh+1,iyei  )*wx3h*wy2i+sex(ixeh+2,iyei  )*wx4h*wy2i &
            + sex(ixeh-1,iyei+1)*wx1h*wy3i+sex(ixeh  ,iyei+1)*wx2h*wy3i &
            + sex(ixeh+1,iyei+1)*wx3h*wy3i+sex(ixeh+2,iyei+1)*wx4h*wy3i &
            + sex(ixeh-1,iyei+2)*wx1h*wy4i+sex(ixeh  ,iyei+2)*wx2h*wy4i &
            + sex(ixeh+1,iyei+2)*wx3h*wy4i+sex(ixeh+2,iyei+2)*wx4h*wy4i
!
         wbx = sbx(ixeh-1,iyei-1)*wx1h*wy1i+sbx(ixeh  ,iyei-1)*wx2h*wy1i &
            + sbx(ixeh+1,iyei-1)*wx3h*wy1i+sbx(ixeh+2,iyei-1)*wx4h*wy1i &
            + sbx(ixeh-1,iyei  )*wx1h*wy2i+sbx(ixeh  ,iyei  )*wx2h*wy2i &
            + sbx(ixeh+1,iyei  )*wx3h*wy2i+sbx(ixeh+2,iyei  )*wx4h*wy2i &
            + sbx(ixeh-1,iyei+1)*wx1h*wy3i+sbx(ixeh  ,iyei+1)*wx2h*wy3i &
            + sbx(ixeh+1,iyei+1)*wx3h*wy3i+sbx(ixeh+2,iyei+1)*wx4h*wy3i &
            + sbx(ixeh-1,iyei+2)*wx1h*wy4i+sbx(ixeh  ,iyei+2)*wx2h*wy4i &
            + sbx(ixeh+1,iyei+2)*wx3h*wy4i+sbx(ixeh+2,iyei+2)*wx4h*wy4i &
            + sextbx
!.
         wez = sez(ixeh-1,iyeh-1)*wx1h*wy1h+sez(ixeh  ,iyeh-1)*wx2h*wy1h &
            + sez(ixeh+1,iyeh-1)*wx3h*wy1h+sez(ixeh+2,iyeh-1)*wx4h*wy1h &
            + sez(ixeh-1,iyeh  )*wx1h*wy2h+sez(ixeh  ,iyeh  )*wx2h*wy2h &
            + sez(ixeh+1,iyeh  )*wx3h*wy2h+sez(ixeh+2,iyeh  )*wx4h*wy2h &
            + sez(ixeh-1,iyeh+1)*wx1h*wy3h+sez(ixeh  ,iyeh+1)*wx2h*wy3h &
            + sez(ixeh+1,iyeh+1)*wx3h*wy3h+sez(ixeh+2,iyeh+1)*wx4h*wy3h &
            + sez(ixeh-1,iyeh+2)*wx1h*wy4h+sez(ixeh  ,iyeh+2)*wx2h*wy4h &
            + sez(ixeh+1,iyeh+2)*wx3h*wy4h+sez(ixeh+2,iyeh+2)*wx4h*wy4h
!
         wbz = sbz(ixeh-1,iyeh-1)*wx1h*wy1h+sbz(ixeh  ,iyeh-1)*wx2h*wy1h &
            + sbz(ixeh+1,iyeh-1)*wx3h*wy1h+sbz(ixeh+2,iyeh-1)*wx4h*wy1h &
            + sbz(ixeh-1,iyeh  )*wx1h*wy2h+sbz(ixeh  ,iyeh  )*wx2h*wy2h &
            + sbz(ixeh+1,iyeh  )*wx3h*wy2h+sbz(ixeh+2,iyeh  )*wx4h*wy2h &
            + sbz(ixeh-1,iyeh+1)*wx1h*wy3h+sbz(ixeh  ,iyeh+1)*wx2h*wy3h &
            + sbz(ixeh+1,iyeh+1)*wx3h*wy3h+sbz(ixeh+2,iyeh+1)*wx4h*wy3h &
            + sbz(ixeh-1,iyeh+2)*wx1h*wy4h+sbz(ixeh  ,iyeh+2)*wx2h*wy4h &
            + sbz(ixeh+1,iyeh+2)*wx3h*wy4h+sbz(ixeh+2,iyeh+2)*wx4h*wy4h &
            + sextbz
!.
         wey = sey(ixei-1,iyeh-1)*wx1i*wy1h+sey(ixei  ,iyeh-1)*wx2i*wy1h &
            + sey(ixei+1,iyeh-1)*wx3i*wy1h+sey(ixei+2,iyeh-1)*wx4i*wy1h &
            + sey(ixei-1,iyeh  )*wx1i*wy2h+sey(ixei  ,iyeh  )*wx2i*wy2h &
            + sey(ixei+1,iyeh  )*wx3i*wy2h+sey(ixei+2,iyeh  )*wx4i*wy2h &
            + sey(ixei-1,iyeh+1)*wx1i*wy3h+sey(ixei  ,iyeh+1)*wx2i*wy3h &
            + sey(ixei+1,iyeh+1)*wx3i*wy3h+sey(ixei+2,iyeh+1)*wx4i*wy3h &
            + sey(ixei-1,iyeh+2)*wx1i*wy4h+sey(ixei  ,iyeh+2)*wx2i*wy4h &
            + sey(ixei+1,iyeh+2)*wx3i*wy4h+sey(ixei+2,iyeh+2)*wx4i*wy4h
!
         wby = sby(ixei-1,iyeh-1)*wx1i*wy1h+sby(ixei  ,iyeh-1)*wx2i*wy1h &
            + sby(ixei+1,iyeh-1)*wx3i*wy1h+sby(ixei+2,iyeh-1)*wx4i*wy1h &
            + sby(ixei-1,iyeh  )*wx1i*wy2h+sby(ixei  ,iyeh  )*wx2i*wy2h &
            + sby(ixei+1,iyeh  )*wx3i*wy2h+sby(ixei+2,iyeh  )*wx4i*wy2h &
            + sby(ixei-1,iyeh+1)*wx1i*wy3h+sby(ixei  ,iyeh+1)*wx2i*wy3h &
            + sby(ixei+1,iyeh+1)*wx3i*wy3h+sby(ixei+2,iyeh+1)*wx4i*wy3h &
            + sby(ixei-1,iyeh+2)*wx1i*wy4h+sby(ixei  ,iyeh+2)*wx2i*wy4h &
            + sby(ixei+1,iyeh+2)*wx3i*wy4h+sby(ixei+2,iyeh+2)*wx4i*wy4h &
            + sextby
!..
         wax = suxe(i) - wex * s1o2
         way = suye(i) - wey * s1o2
         waz = suze(i) - wez * s1o2
         wtf = s1o2 / sqrt( s1o1 + (wax**2+way**2+waz**2)*scg1 )
         wcx = - wbx * wtf
         wcy = - wby * wtf
         wcz = - wbz * wtf
         wc2 = wcx**2 + wcy**2 + wcz**2
         wac = wax * wcx + way * wcy + waz * wcz
!.
         sfxe(i) = ( ( wax + way * wcz - waz * wcy + wac * wcx ) / &
                  ( s1o1 + wc2 ) - suxe(i) ) * s2o1
         sfye(i) = ( ( way + waz * wcx - wax * wcz + wac * wcy ) / &
                  ( s1o1 + wc2 ) - suye(i) ) * s2o1
         sfze(i) = ( ( waz + wax * wcy - way * wcx + wac * wcz ) / &
                  ( s1o1 + wc2 ) - suze(i) ) * s2o1
      end do
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c2pef', 1 )
!....
      return
      end
