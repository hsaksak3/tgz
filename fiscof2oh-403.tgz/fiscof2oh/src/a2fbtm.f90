!-----------------------------------------------------------------------
! Advance 2D Field magnetic(B) - TM (half step)
!
      subroutine a2fbtm
!
!   <arguments>
!     none
!
!   <remarks>
!     "sdeyxdxy" was already divided by 2 for an half step and changed
!    its sign.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use parameter
      use field
      include "implicit.h"
      integer :: ix, iy
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'a2fbtm', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sbz(ix,iy) = sbz(ix,iy) + sdeyxdxy(ix,iy)
         end do
      end do
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'a2fbtm', 1 )
!....
      return
      end
