!-------------------------------------------------------------------
! Set 2D ALLoCate array
!                           /
      subroutine s2allc ( kmode )
!
!   <arguments>
!     kmode :  = 0 --> allocate particle array
!           : != 0 --> allocate field array
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/28
! modified by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
      use parameter
      use constant
      use particle
      use field
#ifdef OHHELP
      use oh_param
#endif
      include "implicit.h"
      integer :: kmode
      save
!....
      call fdebug ( 's2allc', 0 )
!....                                                      * particle *
      if( kmode .eq. 0 ) then
         allocate( spdat1(lnox), spdat2(lnox) )
!...                                                          * field *
      else
#ifndef OHHELP
         allocate ( &
         sde0(lssxlm1:lssxup1,lssylm1:lssyup1), &
         sde(lssxlm1:lssxup1,lssylm1:lssyup1), &
         sdi(lssxlm1:lssxup1,lssylm1:lssyup1,lionspl), &
         sebxy(4,lblxlm1:lblxup1,lblylm1:lblyup1), &
         sez(lblxlm1:lblxup1,lblylm1:lblyup1), &
         sbz(lblxlm1:lblxup1,lblylm1:lblyup1), &
         sjxyzt(3,lssxlm2:lssxup3,lssylm2:lssyup3), &
         sdezdy(lssxl:lssxup1,lssylm1:lssyup1), &
         sdezdx(lssxlm1:lssxup1,lssyl:lssyup1), &
         sdeyxdxy(lssxl:lssxup1,lssyl:lssyup1), &
         sjxe(lssxlm2:lssxup3,lssylm2:lssyup2), &
         sjxi(lssxlm2:lssxup3,lssylm2:lssyup2,lionspl), &
         sjye(lssxlm2:lssxup2,lssylm2:lssyup3), &
         sjyi(lssxlm2:lssxup2,lssylm2:lssyup3,lionspl), &
         sjze(lssxlm1:lssxup2,lssylm1:lssyup2), &
         sjzi(lssxlm1:lssxup2,lssylm1:lssyup2,lionspl), &
         sezxxl(lblxl:lssxlm1,lblyl:lblyu), &
         sezyxl(lblxl:lssxlm1,lssyl:lssyup1), &
         sbzxxl(lblxl:lssxlm1,lblyl:lblyu), &
         sbzyxl(lblxl:lssxlm1,lssyl:lssyup1), &
         sezxxu(lssxup2:lblxu,lblyl:lblyu), &
         sezyxu(lssxup2:lblxu,lssyl:lssyup1), &
         sbzxxu(lssxup2:lblxu,lblyl:lblyu), &
         sbzyxu(lssxup2:lblxu,lssyl:lssyup1), &
         sezxyl(lssxl:lssxup1,lblyl:lssylm1), &
         sezyyl(lblxl:lblxu,lblyl:lssylm1), &
         sbzxyl(lssxl:lssxup1,lblyl:lssylm1), &
         sbzyyl(lblxl:lblxu,lblyl:lssylm1), &
         sezxyu(lssxl:lssxup1,lssyup2:lblyu), &
         sezyyu(lblxl:lblxu,lssyup2:lblyu), &
         sbzxyu(lssxl:lssxup1,lssyup2:lblyu), &
         sbzyyu(lblxl:lblxu,lssyup2:lblyu) &
         )
#else
         call s2ext_conv( 0 )
!
         allocate ( &
         sde0(oh_alosizes(1,1,FDE):oh_alosizes(2,1,FDE), &
              oh_alosizes(1,2,FDE):oh_alosizes(2,2,FDE)), &
         oh_sde(oh_alosizes(1,1,FDE):oh_alosizes(2,1,FDE), &
                oh_alosizes(1,2,FDE):oh_alosizes(2,2,FDE),2), &
            sdi(oh_alosizes(1,1,FDI):oh_alosizes(2,1,FDI), &
                oh_alosizes(1,2,FDI):oh_alosizes(2,2,FDI),lionspl), &
         oh_sexyz(3,oh_alosizes(1,1,FE):oh_alosizes(2,1,FE), &
                    oh_alosizes(1,2,FE):oh_alosizes(2,2,FE),2), &
         oh_sbxyz(3,oh_alosizes(1,1,FB):oh_alosizes(2,1,FB), &
                    oh_alosizes(1,2,FB):oh_alosizes(2,2,FB),2), &
         oh_sjxyzt(3,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                     oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),2), &
         oh_sdezdy(oh_alosizes(1,1,FE):oh_alosizes(2,1,FE), &
                   oh_alosizes(1,2,FE):oh_alosizes(2,2,FE),2), & 
         oh_sdezdx(oh_alosizes(1,1,FE):oh_alosizes(2,1,FE), &
                   oh_alosizes(1,2,FE):oh_alosizes(2,2,FE),2), & 
         oh_sdeyxdxy(oh_alosizes(1,1,FE):oh_alosizes(2,1,FE), &
                     oh_alosizes(1,2,FE):oh_alosizes(2,2,FE),2), & 
         oh_sjxe(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),2), &
         oh_sjxi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),lionspl,2), &
         oh_sjye(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),2), &
         oh_sjyi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),lionspl,2), &
         oh_sjze(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),2), &
         oh_sjzi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),lionspl,2), &
         oh_sebpmlxl(4, lblxl:lssxlm1, &
                     oh_alosizes(1,2,FB):oh_alosizes(2,2,FB), 2), &
         oh_sebpmlxu(4, lssxup2:lblxu, &
                     oh_alosizes(1,2,FB):oh_alosizes(2,2,FB), 2), &
         oh_sebpmlyl(4, oh_alosizes(1,1,FB):oh_alosizes(2,1,FB), &
                     lblyl:lssylm1, 2), &
         oh_sebpmlyu(4, oh_alosizes(1,1,FB):oh_alosizes(2,1,FB), &
                     lssyup2:lblyu, 2) &
         )
!                                                     * pml parameters *
         oh_lebpmlxl = 4 * (lssxlm1-lblxl+1) * &
                       (oh_alosizes(2,2,FB)-oh_alosizes(1,2,FB)+1)
         oh_lebpmlxu = 4 * (lblxu-lssxup2+1) * &
                       (oh_alosizes(2,2,FB)-oh_alosizes(1,2,FB)+1)
         oh_lebpmlyl = 4*(oh_alosizes(2,1,FB)-oh_alosizes(1,1,FB)+1) * &
                       (lssylm1-lblyl+1) 
         oh_lebpmlyu = 4*(oh_alosizes(2,1,FB)-oh_alosizes(1,1,FB)+1) * &
                       (lblyu-lssyup2+1)
#endif
         allocate ( &
         scaxl(lblxl:lssxlm1), scaxlh(lblxlm1:lssxlm2), &
         scbbtexl(lblxlm1:lssxlm2),sccbtexl(lblxlm1:lssxlm2), &
         scbetmxl(lblxlm1:lssxlm2), sccetmxl(lblxlm1:lssxlm2), &
         scbetexl(lblxl:lssxlm1), sccetexl(lblxl:lssxlm1), &
         scbbtmxl(lblxl:lssxlm1), sccbtmxl(lblxl:lssxlm1), &
         scaxu(lssxup2:lblxu), scaxuh(lssxup2:lblxu), &
         scbbtexu(lssxup2:lblxu), sccbtexu(lssxup2:lblxu), &
         scbetmxu(lssxup2:lblxu), sccetmxu(lssxup2:lblxu), &
         scbetexu(lssxup2:lblxu), sccetexu(lssxup2:lblxu), &
         scbbtmxu(lssxup2:lblxu), sccbtmxu(lssxup2:lblxu), &
         scayl(lblyl:lssylm1), scaylh(lblylm1:lssylm2), &
         scbbteyl(lblylm1:lssylm2),sccbteyl(lblylm1:lssylm2), &
         scbetmyl(lblylm1:lssylm2), sccetmyl(lblylm1:lssylm2), &
         scbeteyl(lblyl:lssylm1), scceteyl(lblyl:lssylm1), &
         scbbtmyl(lblyl:lssylm1), sccbtmyl(lblyl:lssylm1), &
         scayu(lssyup2:lblyu), scayuh(lssyup2:lblyu), &
         scbbteyu(lssyup2:lblyu), sccbteyu(lssyup2:lblyu), &
         scbetmyu(lssyup2:lblyu), sccetmyu(lssyup2:lblyu), &
         scbeteyu(lssyup2:lblyu), scceteyu(lssyup2:lblyu), &
         scbbtmyu(lssyup2:lblyu), sccbtmyu(lssyup2:lblyu) &
         )
      end if
!....
      call fdebug ( 's2allc', 1 )
!....
      return
      end
