!----------------------------------------------------------------------
! frames interface routines
!
      subroutine frames_init
      real*8 sh(4), sl(4), ss(4)
      integer ndiv(3)
!....
      call fr_ginit
!....
      sh(1) = 0.0d0
      sl(1) = 0.02d0
      ss(1) = 1.0d0
      ndiv(1) = 40
      sh(2) = 0.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 50
      sh(3) = 60.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 40
      sh(4) = 60.0d0
      sl(4) = 0.98d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!
      sh(1) = 180.0d0
      sl(1) = 0.9d0
      ss(1) = 1.0d0
      ndiv(1) = 60
      sh(2) = 240.0d0
      sl(2) = 0.1d0
      ss(2) = 1.0d0
      ndiv(2) = 10
      sh(3) = 360.0d0
      sl(3) = 0.1d0
      ss(3) = 1.0d0
      ndiv(3) = 60
      sh(4) = 390.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!
      sh(1) = 240.0d0
      sl(1) = 0.25d0
      ss(1) = 1.0d0
      ndiv(1) = 20
      sh(2) = 240.0d0
      sl(2) = 0.5d0
      ss(2) = 1.0d0
      ndiv(2) = 90
      sh(3) = 0.0d0
      sl(3) = 0.5d0
      ss(3) = 1.0d0
      ndiv(3) = 20
      sh(4) = 0.0d0
      sl(4) = 0.9d0
      ss(4) = 1.0d0
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!....
      return
      end
!----------------------
      subroutine frames_term
!.
      call fr_gend
!.
      return
      end
!----------------------
      subroutine frames_file ( efile, kcan, kmode )
      include "implicit.h"
      integer :: kcan, kmode, imode, iplt, igif
      character*(*) efile
!.....
      imode = mod( kmode-2,3 ) + 1
      iplt = mod( imode,2 )
      igif = imode / 2
      imode = 200*igif + iplt*10
!..
      call fr_opencanvas ( kcan, efile, imode )
!....
      return
      end
!----------------------
      subroutine frames_body21 ( eident, ftime, knum, kcol, &
                                fdata,kl,kx,ky, &
                                fxmic,fx0m,fymic,fy0m, etitle )
      include "implicit.h"
      integer :: knum, kcol, kl, kx, ky
      real*8  :: ftime, fdata(kl), fxmic, fx0m, fymic, fy0m, &
                 axm, axx, aym, ayx
      character*16 ctime, eident
      character*(*) etitle
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      axm = - fx0m
      axx = fxmic * (kx-1) - fx0m
      aym = - fy0m
      ayx = fymic * (ky-1) - fy0m
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axm, axx, aym, ayx, 3 )
      call fr_hlsrecall ( kcol )
      call fr_contour ( fdata, kx, ky, 1, -2 )
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body22 ( eident, ftime, knum, kcol, kas, &
                                fdata,kx,ky, fxm, fxx, fym, fyx, &
                                exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer :: knum, kcol, kas, kx, ky
      real*8  :: ftime, fdata(kx,ky), fxm, fxx, fym, fyx
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, kas )
      call fr_frame2d ( fxm, fxx, fym, fyx, 3 )
      call fr_hlsrecall ( kcol )
      call fr_contour ( fdata, kx, ky, 1, -2 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_colorbar ( 350, 475, 200, 15, 2 )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body23 ( eident, ftime, knum, kcol, &
                                fxdat,fydat,kl,kx,ky,kint,fampx, &
                                fxmic,fx0m,fymic,fy0m, etitle )
      include "implicit.h"
      integer :: knum, kcol, kl, kx, ky, kint, &
                 ix, iy, ixx, iyy, ixy, inm
      real*8  :: ftime, fxdat(kl), fydat(kl), fampx, &
                 fxmic, fx0m, fymic, fy0m, axm, axx, aym, ayx, &
                 axd, ayd, ax, axs, axe, ay, ays, aye
      real*8, parameter :: avfac = 2.0d0
      character*16 ctime, eident
      character*(*) etitle
!.
      axm = - fx0m
      axx = fxmic * (kx-1) - fx0m
      aym = - fy0m
      ayx = fymic * (ky-1) - fy0m
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, 0 )
      call fr_frame2d ( axm, axx, aym, ayx, 3 )
      do iy = 1, ky, kint
         do ix = 1, kx, kint
            axd = 0.0d0
            ayd = 0.0d0
            inm = 0
            do iyy = iy, min(ky,iy+kint-1)
               do ixx = ix, min(kx,ix+kint-1)
                  ixy = ixx + (iyy-1)*kx
                  axd = axd + fxdat(ixy)
                  ayd = ayd + fydat(ixy)
                  inm = inm + 1
               end do
            end do
            axd = axd / inm
            ayd = ayd / inm
            if( axd**2+ayd**2 .ge. 5.0d-3 ) then
               ax = fxmic * (ix-1) - fx0m
               axs = ax - fxmic*kint*axd*avfac
               axe = ax + fxmic*kint*axd*avfac
               ay = fymic * (iy-1) - fy0m
               ays = ay - fymic*kint*ayd*avfac
               aye = ay + fymic*kint*ayd*avfac
               call fr_vector2d ( axs, ays, axe, aye, kcol, 1 )
            end if
         end do
      end do
      call fr_xyname ( 'x[micron]', 'y[micron]' )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      ctime = 'max = '
      write( ctime(7:16), '(e10.3)' ) fampx
      call fr_fpchars ( 400.0d0, 470.0d0, ctime, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body24 ( eident, ftime, knum, klog, fdata, kl, &
                                ffct, exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer, parameter :: llx24 = 301
      integer :: knum, klog, kl, i, icol, imin, imax
      real*8  :: ftime, fdata(kl), ffct, ax(llx24), amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      if( kl .gt. llx24 ) then
         write(0,*) '### [frames_body24] data overflow :', kl
         go to 999
      end if
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!     icol = mod( knum-1, 6 ) + 1
      icol = 2
      amin = 1.0d30
      amax = -1.0d30
      do i = 1, kl
         ax(i) = ( i - ( (kl-1)/2 + 1 ) ) / ffct
         amin = min( amin, fdata(i) )
         amax = max( amax, fdata(i) )
      end do
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         imin = amin
         imax = amax
         amin = imin
         amax = imax + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ax(1), ax(kl), amin, amax, 3 )
      call fr_graph2d ( ax, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body25 ( eident, ftime, knum, fdata,kl,kx,ky, &
                                kcros, klog, fxmic,fx0m,fymic,fy0m, etitle )
      include "implicit.h"
      integer, parameter :: llx25 = 65536
      integer :: knum, kl, kx, ky, kcros, klog, i, ix, ixs, ixx, &
                 iy, iyd, iy0, imin, imax, icol
      real*8  :: ftime, fdata(kl), fxmic, fx0m, fymic, fy0m, &
                 ax(llx25), ave(llx25), amin, amax, ay
      character*16 ctime, eident
      character*(*) etitle
!++++
      if( kx .gt. llx25 ) then
         write(0,*) '### [frames_body25] data overflow :', kx
         go to 999
      end if
!++++
!....
      do ix = 1, kx
         ax(ix) = (ix-1) * fxmic - fx0m
      end do
!.
      amin = 1.0d30
      amax = -1.0d30
      iyd = (ky-1) / kcros
      iy0 = 1 + iyd/2
      do i = 1, kcros
         ixs = ( iy0 + iyd * ( i-1 ) - 1 ) * kx
         do ix = 1, kx
            amin = min( amin, fdata(ixs+ix) )
            amax = max( amax, fdata(ixs+ix) )
         end do
      end do
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0
!...
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         imin = amin
         imax = amax
         amin = imin
         amax = imax + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ax(1), ax(kx), amin, amax, 3 )
      ctime = 'xxxxx.xx'
      do i = 1, kcros
         ixs = ( iy0 + iyd * ( i-1 ) - 1 ) * kx + 1
         icol = mod( i+1, 6 ) + 1
         call fr_graph2d ( ax, fdata(ixs), kx, icol, 1 )
         ixx = ( kx - 1 ) / kcros * ( i - 0.5d0 )
         ay = ( iy0 + iyd * ( i-1 ) - 1 ) * fymic - fy0m
         write( ctime(1:8), '(f8.2)' ) ay
         call fr_fpchars ( ax(1+ixx), fdata(ixs+ixx), ctime, icol, 0, -1, 0, 100 )
      end do
      call fr_xyname ( 'x[micron]', etitle )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ax(1), ax(kx), amin, amax, 3 )
      ctime = 'xxxxx.xx'
      do i = 1, kcros
         do ix = 1, kx
            ave(ix) = 0.0d0
         end do
         do iy = 1, iyd
            ixs = ( ( iy-1 ) + iyd * ( i-1 ) ) * kx
            do ix = 1, kx
               ave(ix) = ave(ix) + fdata(ixs+ix)
            end do
         end do
         do ix = 1, kx
            ave(ix) = ave(ix) / iyd
         end do
         icol = mod( i+1, 6 ) + 1
         call fr_graph2d ( ax, ave, kx, icol, 1 )
         ixs = ( iy0 + iyd * ( i-1 ) - 1 ) * kx + 1
         ixx = ( kx - 1 ) / kcros * ( i - 0.5d0 )
         ay = ( iy0 + iyd * ( i-1 ) - 1 ) * fymic - fy0m
         write( ctime(1:8), '(f8.2)' ) ay
         call fr_fpchars ( ax(1+ixx), fdata(ixs+ixx), ctime, icol, 0, -1, 0, 100 )
      end do
      call fr_xyname ( 'x[micron]', 'average-'//etitle )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body26 ( eident, ftime, knum, fdata,kl,kx,ky, &
                                kcros, klog, fxmic,fx0m,fymic,fy0m, etitle )
      include "implicit.h"
      integer, parameter :: lly26 = 65536
      integer :: knum, kl, kx, ky, kcros, klog, i, iy, iys, iyy, &
                 ix, ixd, ix0, imin, imax, icol
      real*8  :: ftime, fdata(kl), fxmic, fx0m, fymic, fy0m, &
                 ay(lly26), ad(lly26), amin, amax, atmp
      character*16 ctime, eident
      character*(*) etitle
!++++
      if( ky .gt. lly26 ) then
         write(0,*) '### [frames_body26] data overflow :', ky
         go to 999
      end if
!++++
!....
      do iy = 1, ky
         ay(iy) = (iy-1) * fymic - fy0m
      end do
!.
      amin = 1.0d30
      amax = -1.0d30
      ixd = (kx-1) / kcros
      ix0 = 1 + ixd/2
      do i = 1, kcros
         iys = ix0 + ixd * ( i-1 ) - kx
         do iy = 1, ky
            atmp = fdata(iys+iy*kx)
            amin = min( amin, atmp )
            amax = max( amax, atmp )
         end do
      end do
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0
!...
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         imin = amin
         imax = amax
         amin = imin
         amax = imax + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ay(1), ay(ky), amin, amax, 3 )
      ctime = 'xxxxx.xx'
      do i = 1, kcros
         iys = ix0 + ixd * ( i-1 ) - kx
         do iy = 1, ky
            ad(iy) = fdata(iys+iy*kx)
         end do
         icol = mod( i+1, 6 ) + 1
         call fr_graph2d ( ay, ad, ky, icol, 1 )
         iyy = ( ky - 1 ) / kcros * ( i - 0.5d0 )
         atmp = ( ix0 + ixd * ( i-1 ) - 1 ) * fxmic - fx0m
         write( ctime(1:8), '(f8.2)' ) atmp
         call fr_fpchars ( ay(1+iyy), ad(1+iyy), ctime, icol, 0, -1, 0, 100 )
      end do
      call fr_xyname ( 'y[micron]', etitle )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ay(1), ay(ky), amin, amax, 3 )
      ctime = 'xxxxx.xx'
      do i = 1, kcros
         do iy = 1, ky
            ad(iy) = 0.0d0
         end do
         do ix = 1, ixd
            iys = ( ix-1 ) + ixd * ( i-1 ) - kx + 1
            do iy = 1, ky
               ad(iy) = ad(iy) + fdata(iys+iy*kx)
            end do
         end do
         do iy = 1, ky
            ad(iy) = ad(iy) / ixd
         end do
         icol = mod( i+1, 6 ) + 1
         call fr_graph2d ( ay, ad, ky, icol, 1 )
         iyy = ( ky - 1 ) / kcros * ( i - 0.5d0 )
         atmp = ( ix0 + ixd * ( i-1 ) - 1 ) * fxmic - fx0m
         write( ctime(1:8), '(f8.2)' ) atmp
         call fr_fpchars ( ay(1+iyy), ad(1+iyy), ctime, icol, 0, -1, 0, 100 )
      end do
      call fr_xyname ( 'y[micron]', 'average-'//etitle )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
!----------------------
      subroutine frames_body27 ( eident, ftime, knum, klog, fx,fdata, &
                                 kl, exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer :: knum, klog, kl, i, icol, imin, imax
      real*8  :: ftime, fx(kl), fdata(kl), amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!     icol = mod( knum-1, 6 ) + 1
      icol = 2
      amin = 0.0d0
      amax = 1.0d0
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         amin = -6.0d0
         amax = 0.0d0
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( fx(1), fx(kl), amin, amax, 3 )
      call fr_graph2d ( fx, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
      return
      end
!----------------------
      subroutine frames_body28 ( eident, ftime, knum, klog, fdata, kl, &
                                ffct, exaxis, eyaxis, etitle, erange )
      include "implicit.h"
      integer, parameter :: llx28 = 201
      integer :: knum, klog, kl, i, icol, imin, imax
      real*8  :: ftime, fdata(kl), ffct, ax(llx28), amin, amax
      character*16 :: ctime, eident
      character*(*) :: exaxis, eyaxis, etitle, erange
!.
      if( kl .gt. llx28 ) then
         write(0,*) '### [frames_body28] data overflow :', kl
         go to 999
      end if
!.
      ctime = 'xxxxx.xx fsec'
      write( ctime(1:8), '(f8.2)' ) ftime
!     icol = mod( knum-1, 6 ) + 1
      icol = 2
      amin = 1.0d30
      amax = -1.0d30
      do i = 1, kl
         ax(i) = ( i - 1 ) / ffct
         amin = min( amin, fdata(i) )
         amax = max( amax, fdata(i) )
      end do
      if( abs(amin) .le. 1.0d-35 ) amin = 0.0d0
      if( abs(amax) .le. 1.0d-35 ) amax = 0.0d0
!.
      call fr_canvas ( knum )
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      if( klog .ge. 1 ) then
         imin = amin
         imax = amax
         amin = imin
         amax = imax + 1
         call fr_setaxis ( 2 )
      end if
      call fr_frame2d ( ax(1), ax(kl), amin, amax, 3 )
      call fr_graph2d ( ax, fdata, kl, icol, 1 )
      call fr_xyname ( exaxis, eyaxis )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 150.0d0, 15.0d0, etitle, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 5.0d0, 470.0d0, erange, 7, 1, -1, 0, 0 )
!.
  999 continue
      return
      end
