!----------------------------------------------------------------------
! Fast Particle parameters
!
      module fpprm
      use parameter
      integer :: &
         lopfeed, lopfeeda, lopfeedc, &
         lopfeedrl, lopfeedml, lopfeednl, lopfeedyl(lopfeedx), &
         lopfied, lopfieda, lopfiedc, &
         lopfiedrl, lopfiedml, lopfiednl, lopfiedyl(lopfiedx)
      real*8 :: &
         sopfeedx(lopfeedx), sopfeedys(lopfeedx), sopfeedye(lopfeedx), &
         sopfeedr, sopfeedm, &
         sopfiedx(lopfiedx), sopfiedys(lopfiedx), sopfiedye(lopfiedx), &
         sopfiedr(lionspx), sopfiedm(lionspx)
      character :: bfpfntpe*64, bfpfntpi*64
end module fpprm
