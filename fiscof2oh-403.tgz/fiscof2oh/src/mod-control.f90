!----------------------------------------------------------------------
! control
!
module control
      use parameter
      integer :: &
         lresti, lresto, &
         lbxlf, lbxlpe, lbxlpi, lbxuf, lbxupe, lbxupi, &
         lbylf, lbylpe, lbylpi, lbyuf, lbyupe, lbyupi, &
         lexlf, lexlpe, lexlpi, lexuf, lexupe, lexupi, &
         leylf, leylpe, leylpi, leyuf, leyupe, leyupi, &
         lblsgxl, lblsgxu, lblsgyl, lblsgyu, &
         lclflge, lclflgia, lclflgi(lionspx)
      real*8 :: &
         sextbx, sextby, sextbz, &
         sblsgxl, sblsgxu, sblsgyl, sblsgyu, &
         sclxpse(lclflgex), sclxpee(lclflgex), &
         sclypse(lclflgex), sclypee(lclflgex), &
         scluure(lclflgex), scluule(lclflgex), scluu0e(lclflgex), &
         sclfcte(lclflgex), &
         sclxpsi(lclflgix,lionspx), sclxpei(lclflgix,lionspx), &
         sclypsi(lclflgix,lionspx), sclypei(lclflgix,lionspx), &
         scluuri(lclflgix,lionspx), scluuli(lclflgix,lionspx), &
         scluu0i(lclflgix,lionspx), sclfcti(lclflgix,lionspx)
      character :: brestfntp*64
end module control
