!-----------------------------------------------------------------------
! Compute 2D Field current(J) Total
!
      subroutine c2fjt
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 14/09/04
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use field
      include "implicit.h"
      integer :: io, ix, iy
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2fjt', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      oh_sjxyzt(:,:,:,ips) = s0o1
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL PRIVATE(ix,io)
      if( lnoe .gt. 0 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               sjxt(ix,iy) = sjxe(ix,iy)
            end do
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               sjyt(ix,iy) = sjye(ix,iy)
            end do
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup2
            do ix = lssxlm1, lssxup2
               sjzt(ix,iy) = sjze(ix,iy)
            end do
         end do
      end if
      do io = 1, lionspl
         if( lionidl(io) .le. 0 ) cycle
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               sjxt(ix,iy) = sjxt(ix,iy) + sjxi(ix,iy,io)
            end do
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               sjyt(ix,iy) = sjyt(ix,iy) + sjyi(ix,iy,io)
            end do
         end do
!$OMP DO SCHEDULE(STATIC)
         do iy = lssylm1, lssyup2
            do ix = lssxlm1, lssxup2
               sjzt(ix,iy) = sjzt(ix,iy) + sjzi(ix,iy,io)
            end do
         end do
      end do
!...
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c2fjt', 1 )
!....
      return
      end
