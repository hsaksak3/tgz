!-------------------------------------------------------------------
! QSTaRT for POSition
!
      subroutine qstrtpos ( kp, knpme,ffd,ffp, fpdat1, kno, knox,&
                            kpc )
!
!   <arguments>
!     kp    : i  : index of profile
!     knpme : i  : effective number of particle per mesh
!     ffd   : i  : factor for density
!     ffp   : i  : factor for particle factor
!     fpdat1: io : structure of particle data type 1
!     kno   : io : index of structure
!     knox  : i  : size of structure
!     kpc   : i  : if kpc = -1 then particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/07/18
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
      use parameter
      use ptcltype
      use profile
      use constant
      include "implicit.h"
      type(ty1_particle) :: fpdat1(knox)
      integer, parameter :: lqn = 500
      real*8  :: aeps = 1.0d-6
      integer :: kpc
      integer :: kp, knpme, kno, knox, ity, iho, i, is, ii, inpm, &
                 ix, ixps, ixpe, ixd, iy, iyps, iype, iyd, ino0, ipos, &
                 ixcs, ixce
      real*8  :: ffd, ffp, wran(lqn), wx(lqn), wy(lqn), &
                 asc, asc2, ax, ay, wds, wid, wde, wpppnp, wsign, &
                 wrp, wrd, &
                 wxpes, wxpee, wxpss, wxpse, wypes, wypee, wypss, wypse
      real*8, allocatable :: aden(:)
      save
!....
      call fdebug ( 'qstrtpos', 0 )
!....
      if( .not. allocated(aden) ) allocate( aden( max(lssx,lssy) ) )
!.
      ity = mod( lpppty(kp), 10 )
      iho = lpppty(kp) / 10
!....
      if( ity .ge. 1 .and. ity .le. 3 ) then
!
      iyps = spppyps(kp) * slmic + lyp0
      iype = spppype(kp) * slmic + lyp0
      if( iyps .lt. iype ) then
         iyd = 1
!.
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: y position less than 1.',kp,iyps
            iyps = 1
         end if
         if( iype .gt. lssy ) then
            write(0,*) '### WARNING: y position greater than',lssy,'.', &
                      kp,iype
            iype = lssy
         end if
      else
         iyd = -1
!.
         if( iype .lt. 1 ) then
            write(0,*) '### WARNING: y position less than 1.',kp,iype
            iype = 1
         end if
         if( iyps .gt. lssy ) then
            write(0,*) '### WARNING: y position greater than',lssy,'.', &
                      kp,iyps
            iyps = lssy
         end if
      end if
      if( spppds(kp) .gt. s0o1 .or. spppde(kp) .gt. s0o1 ) then
         wxpss = spppxps(kp) * slmic + lxp0
         wxpes = spppxpe(kp) * slmic + lxp0
         wxpse = ( spppxps(kp)+spppds(kp) ) * slmic + lxp0
         wxpee = ( spppxpe(kp)+spppde(kp) ) * slmic + lxp0
         wpppnp = spppnp(kp)
         wsign = s1o1
      else
         wxpss = ( spppxps(kp)+spppds(kp) ) * slmic + lxp0
         wxpes = ( spppxpe(kp)+spppde(kp) ) * slmic + lxp0
         wxpse = spppxps(kp) * slmic + lxp0
         wxpee = spppxpe(kp) * slmic + lxp0
         wpppnp = spppnd(kp)
         wsign = -s1o1
      end if
      wds   = ( wxpes - wxpss ) / ( iype - iyps )
      wde   = ( wxpee - wxpse ) / ( iype - iyps )
!.
      if( iho .ge. 2 .and. iho .le. 6 ) then
         if( ity .eq. 2 ) then
            wrp = sqrt( &
           (sppphxo(lppphis(kp))-(spppxps(kp)+spppxpe(kp))*s1o2)**2 + &
           (sppphyo(lppphis(kp))-(spppyps(kp)+spppype(kp))*s1o2)**2 )
            wrd = sqrt( &
           (sppphxo(lppphis(kp))- &
           (spppxps(kp)+spppds(kp)+spppxpe(kp)+spppde(kp))*s1o2)**2 + &
           (sppphyo(lppphis(kp))-(spppyps(kp)+spppype(kp))*s1o2)**2 )
            if( iho .eq. 2 ) then
               asc = ( wrd-wrp )/log( spppnp(kp)/spppnd(kp) )
               wpppnp = spppnp(kp) * exp( wrp / asc )
            else
               asc = (wrd**2-wrp**2)/log(spppnp(kp)/spppnd(kp))
               wpppnp = spppnp(kp) * exp( wrp**2 / asc )
            end if
         else
            if( iho .eq. 2 .or. iho .eq. 4 .or. iho .eq. 5 ) then
               asc = sppphrr(lppphis(kp))
               if( iho .eq. 4 ) asc2 = sppphrr(lppphie(kp))
            else
               asc = sppphrr(lppphis(kp))**2 / log(s2o1)
            end if
            wpppnp = spppnp(kp)
         end if
      end if
!...
      do iy = iyps, iype-iyd, iyd
         ixps = wxpss + wds * ( iy - iyps )
         ixpe = wxpse + wde * ( iy - iyps )
!++++
         if( ixps .lt. 1 .or. ixpe .gt. lssx ) then
            write(0,*) '### ERROR: x system size overflow',kp,ixps,ixpe
            call s2ext_abort
         end if
!++++
!..
         if( ixps .lt. ixpe ) then
            ino0 = kno
            if( ity .eq. 1 ) then
               call qstrtflt ( ixps,ixpe,spppnp(kp)*ffd,snepm1,knpme, &
                               fpdat1, kno, knox, iy, kp, iho, kpc )
            else if( ity .eq. 2 .or. ity .eq. 3 ) then
               if( iho .eq. 0 ) then
                  wid = ( ixpe-ixps ) * slmicinv * wsign
                  if( ity .eq. 2 ) then
                     asc = wid / ( spppnd(kp) - spppnp(kp) )
                     do i = ixps, ixpe
                        ax = (i-ixps) * slmicinv
                        aden(i) = wpppnp + ax / asc
                     end do
                  else if( ity .eq. 3 ) then
                     asc = wid / log( spppnd(kp)/spppnp(kp) )
                     do i = ixps, ixpe
                        ax = (i-ixps) * slmicinv
                        aden(i) = wpppnp * exp( ax / asc )
                     end do
                  end if
               else if( iho .ge. 2 .and. iho .le. 6 ) then
                  do i = ixps, ixpe
                     ax = abs((i -lxp0)*slmicinv-sppphxo(lppphis(kp)))
                     ay = abs((iy-lyp0)*slmicinv-sppphyo(lppphis(kp)))
                     wrp = sqrt( ax**2 + ay**2 )
                     if( iho .eq. 2 .or. iho .eq. 5 ) then
                        aden(i) = wpppnp * exp( - wrp / asc )
                     else if( iho .eq. 4 ) then
                        aden(i) = wpppnp * &
                                      exp( -ax/asc )*exp( -ay**2/asc2 )
                     else
                        aden(i) = wpppnp * exp( - wrp**2 / asc )
                     end if
                     if( iho .eq. 5 .or. iho .eq. 6 ) then
                        aden(i) = min( aden(i), spppnd(kp) )
                     end if
                  end do
               else
                  write(0,*) '### ERROR: invalid lpppty.', lpppty(kp)
                  call s2ext_abort
               end if
               aden(ixpe+1) = s0o1
               do i = ixps, ixpe
                  aden(i) = aden(i) * ffd
               end do
               call qstrtprof ( ixps,ixpe, aden, lssx, snepm1, knpme, &
                                fpdat1, kno, knox, slmicinv, kpc )
            end if
!..
!----
      if( kpc .ne. -1 ) then
            ipos = -1
            inpm = 0
            is = ino0+1
            do i = ino0+1, kno
               ix = fpdat1(i)%x
               if( ix .ne. ipos ) then
                  if( inpm .ge. 2 ) then
                     call mt_drand3 ( wran, inpm )
                     call qssortr ( wran, wy, inpm )
                     do ii = is, is+inpm-1
                        fpdat1(ii)%y = wy(ii-is+1)
                     end do
                  end if
                  is = i
                  inpm = 0
                  ipos = ix
               end if
               inpm = inpm + 1
!++++
               if( inpm .gt. lqn ) then
                  write(0,*) '### ERROR: table overflow at qstrtpos#1.'
                  call s2ext_abort
               end if
!++++
               if( fpdat1(i)%x - ix .eq. s0o1 ) then
                  if( iyd .eq. -1 ) then
                     wy(i-is+1) = iy - aeps
                  end if
               else
                  wy(i-is+1) = iy + ( fpdat1(i)%x - ix ) * iyd 
               end if
            end do
            if( inpm .ge. 2 ) then
               call mt_drand3 ( wran, inpm )
               call qssortr ( wran, wy, inpm )
               do ii = is, is+inpm-1
                  fpdat1(ii)%y = wy(ii-is+1)
               end do
            end if
            do i = ino0+1, kno
               fpdat1(i)%pf = fpdat1(i)%pf * ffp
            end do
      end if
!----
         end if
!..
      end do
!....
      else if( ity .ge. 4 .and. ity .le. 6 ) then
!
      ixps = spppxps(kp) * slmic + lxp0
      ixpe = spppxpe(kp) * slmic + lxp0
      if( ixps .lt. ixpe ) then
         ixd = 1
!.
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: x position less than 1.',kp,ixps
            ixps = 1
         end if
         if( ixpe .gt. lssx ) then
            write(0,*) '### WARNING: x position greater than',lssx,'.',&
                      kp,ixpe
            ixpe = lssx
         end if
      else
         ixd = -1
!.
         if( ixpe .lt. 1 ) then
            write(0,*) '### WARNING: x position less than 1.',kp,ixpe
            ixpe = 1
         end if
         if( ixps .gt. lssx ) then
            write(0,*) '### WARNING: x position greater than',lssx,'.', &
                      kp,ixps
            ixps = lssx
         end if
      end if
      if( spppds(kp) .gt. s0o1 .or. spppde(kp) .gt. s0o1 ) then
         wypss = spppyps(kp) * slmic + lyp0
         wypes = spppype(kp) * slmic + lyp0
         wypse = ( spppyps(kp)+spppds(kp) ) * slmic + lyp0
         wypee = ( spppype(kp)+spppde(kp) ) * slmic + lyp0
         wpppnp = spppnp(kp)
         wsign = s1o1
      else
         wypss = ( spppyps(kp)+spppds(kp) ) * slmic + lyp0
         wypes = ( spppype(kp)+spppde(kp) ) * slmic + lyp0
         wypse = spppyps(kp) * slmic + lyp0
         wypee = spppype(kp) * slmic + lyp0
         wpppnp = spppnd(kp)
         wsign = -s1o1
      end if
      wds   = ( wypes - wypss ) / ( ixpe - ixps )
      wde   = ( wypee - wypse ) / ( ixpe - ixps )
!...
      do ix = ixps, ixpe-ixd, ixd
         iyps = wypss + wds * ( ix - ixps )
         iype = wypse + wde * ( ix - ixps )
!++++
         if( iyps .lt. 1 .or. iype .gt. lssy ) then
            write(0,*) '### ERROR: y system size overflow',kp,iyps,iype
            call s2ext_abort
         end if
!++++
!..
         if( iyps .lt. iype ) then
            ino0 = kno
            if( ity .eq. 4 ) then
               call qstrtflt ( iyps,iype,spppnp(kp)*ffd,snepm1,knpme, &
                               fpdat1, kno, knox, ix, kp, iho, kpc )
            else if( ity .eq. 5 .or. ity .eq. 6 ) then
               wid = ( iype-iyps ) * slmicinv * wsign
               if( ity .eq. 5 ) then
                  asc = wid / ( spppnd(kp) - spppnp(kp) )
                  do i = iyps, iype
                     ax = (i-iyps) * slmicinv
                     aden(i) = wpppnp + ax / asc
                  end do
               else if( ity .eq. 6 ) then
                  asc = wid / log( spppnd(kp)/spppnp(kp) )
                  do i = iyps, iype
                     ax = (i-iyps) * slmicinv
                     aden(i) = wpppnp * exp( ax / asc )
                  end do
               end if
               aden(iype+1) = s0o1
               do i = iyps, iype
                  aden(i) = aden(i) * ffd
               end do
               call qstrtprof ( iyps,iype, aden, lssy, snepm1, knpme, &
                                fpdat1, kno, knox, slmicinv, kpc )
            end if
!..
!----
      if( kpc .ne. -1 ) then
            ipos = -1
            inpm = 0
            is = ino0+1
            do i = ino0+1, kno
               fpdat1(i)%y = fpdat1(i)%x
               iy = fpdat1(i)%y
               if( iy .ne. ipos ) then
                  if( inpm .ge. 2 ) then
                     call mt_drand3 ( wran, inpm )
                     call qssortr ( wran, wx, inpm )
                     do ii = is, is+inpm-1
                        fpdat1(ii)%x = wx(ii-is+1)
                     end do
                  end if
                  is = i
                  inpm = 0
                  ipos = iy
               end if
               inpm = inpm + 1
!++++
               if( inpm .gt. lqn ) then
                  write(0,*) '### ERROR: table overflow at qstrtpos#2.'
                  call s2ext_abort
               end if
!++++
               if( fpdat1(i)%y - iy .eq. s0o1 ) then
                  if( ixd .eq. -1 ) then
                     wx(i-is+1) = ix - aeps
                  end if
               else
                  wx(i-is+1) = ix + ( fpdat1(i)%y - iy ) * ixd 
               end if
            end do
            if( inpm .ge. 2 ) then
               call mt_drand3 ( wran, inpm )
               call qssortr ( wran, wx, inpm )
               do ii = is, is+inpm-1
                  fpdat1(ii)%x = wx(ii-is+1)
               end do
            end if
            do i = ino0+1, kno
               fpdat1(i)%pf = fpdat1(i)%pf * ffp
            end do
      end if
!----
         end if
!..
      end do
!....
      else if( ity .eq. 7 ) then
!
      iyps = ( spppyps(kp) - spppds(kp) ) * slmic + 1 + lyp0
      iype = ( spppyps(kp) + spppds(kp) ) * slmic + lyp0
!++++
      if( iyps .lt. 1 .or. iype .gt. lssy ) then
         write(0,*) '### ERROR: y system size overflow',kp,iyps,iype
         call s2ext_abort
      end if
!++++
!...
      do iy = iyps, iype
         ixps = ( spppxps(kp) - sqrt( spppds(kp)**2 - &
             ( (iy-lyp0)*slmicinv - spppyps(kp) )**2 ) ) * slmic + lxp0
         ixpe = ( spppxps(kp) + sqrt( spppds(kp)**2 - &
             ( (iy-lyp0)*slmicinv - spppyps(kp) )**2 ) ) * slmic + lxp0
!++++
         if( ixps .lt. 1 .or. ixpe .gt. lssx ) then
            write(0,*) '### ERROR: x system size overflow',kp,ixps,ixpe
            call s2ext_abort
         end if
!++++
         ino0 = kno
         call qstrtflt ( ixps,ixpe,spppnp(kp)*ffd,snepm1,knpme, &
                                  fpdat1, kno, knox, iy, kp, iho, kpc )
!..
!----
      if( kpc .ne. -1 ) then
         ipos = -1
         inpm = 0
         is = ino0+1
         do i = ino0+1, kno
            ix = fpdat1(i)%x
            if( ix .ne. ipos ) then
               if( inpm .ge. 2 ) then
                  call mt_drand3 ( wran, inpm )
                  call qssortr ( wran, wy, inpm )
                  do ii = is, is+inpm-1
                     fpdat1(ii)%y = wy(ii-is+1)
                  end do
               end if
               is = i
               inpm = 0
               ipos = ix
            end if
            inpm = inpm + 1
!++++
            if( inpm .gt. lqn ) then
               write(0,*) '### ERROR: table overflow at qstrtpos#3.'
               call s2ext_abort
            end if
!++++
            if( fpdat1(i)%x - ix .eq. s0o1 ) then
               if( iyd .eq. -1 ) then
                  wy(i-is+1) = iy - aeps
               end if
            else
               wy(i-is+1) = iy + ( fpdat1(i)%x - ix ) * iyd 
            end if
         end do
         if( inpm .ge. 2 ) then
            call mt_drand3 ( wran, inpm )
            call qssortr ( wran, wy, inpm )
            do ii = is, is+inpm-1
               fpdat1(ii)%y = wy(ii-is+1)
            end do
         end if
         do i = ino0+1, kno
            fpdat1(i)%pf = fpdat1(i)%pf * ffp
         end do
      end if
!----
      end do
!....
      else if( ity .eq. 8 ) then
!
      iyps = ( spppyps(kp) - spppds(kp) ) * slmic + 1 + lyp0
      iype = ( spppyps(kp) + spppds(kp) ) * slmic + lyp0
!
      if( spppde(kp) .ge. s0o1 ) then
         ixcs =   spppxpe(kp) * slmic + 1 + lxp0
         ixce = ( spppxpe(kp) + spppde(kp) ) * slmic + lxp0
      else
         ixcs = ( spppxpe(kp) + spppde(kp) ) * slmic + 1 + lxp0
         ixce =   spppxpe(kp) * slmic + lxp0
      end if
!...
      do iy = iyps, iype
         ixps = ( spppxps(kp) - sqrt( spppds(kp)**2 - &
             ( (iy-lyp0)*slmicinv - spppyps(kp) )**2 ) ) * slmic + lxp0
         ixpe = ( spppxps(kp) + sqrt( spppds(kp)**2 - &
             ( (iy-lyp0)*slmicinv - spppyps(kp) )**2 ) ) * slmic + lxp0
!.
         ixps = max( ixps, ixcs )
         ixpe = min( ixpe, ixce )
!..
         if( ixpe .gt. ixps ) then
!++++
           if( iy .lt. 1 .or. iy .gt. lssy ) then
             write(0,*) '### ERROR: y system size overflow',kp,iy
             call s2ext_abort
           end if
           if( ixps .lt. 1 .or. ixpe .gt. lssx ) then
             write(0,*) '### ERROR: x system size overflow',kp,ixps,ixpe
             call s2ext_abort
           end if
!++++
           ino0 = kno
           call qstrtflt ( ixps,ixpe,spppnp(kp)*ffd,snepm1,knpme, &
                                   fpdat1, kno, knox, iy, kp, iho, kpc )
!..
!----
      if( kpc .ne. -1 ) then
           ipos = -1
           inpm = 0
           is = ino0+1
           do i = ino0+1, kno
             ix = fpdat1(i)%x
             if( ix .ne. ipos ) then
               if( inpm .ge. 2 ) then
                  call mt_drand3 ( wran, inpm )
                  call qssortr ( wran, wy, inpm )
                  do ii = is, is+inpm-1
                     fpdat1(ii)%y = wy(ii-is+1)
                  end do
               end if
               is = i
               inpm = 0
               ipos = ix
             end if
             inpm = inpm + 1
!++++
             if( inpm .gt. lqn ) then
                write(0,*) '### ERROR: table overflow at qstrtpos#4.'
                call s2ext_abort
             end if
!++++
             if( fpdat1(i)%x - ix .eq. s0o1 ) then
                if( iyd .eq. -1 ) then
                   wy(i-is+1) = iy - aeps
                end if
             else
                wy(i-is+1) = iy + ( fpdat1(i)%x - ix ) * iyd 
             end if
           end do
           if( inpm .ge. 2 ) then
             call mt_drand3 ( wran, inpm )
             call qssortr ( wran, wy, inpm )
             do ii = is, is+inpm-1
               fpdat1(ii)%y = wy(ii-is+1)
             end do
           end if
           do i = ino0+1, kno
             fpdat1(i)%pf = fpdat1(i)%pf * ffp
           end do
      end if
!----
         end if
      end do
!....
      else
!
         write(0,*) '### ERROR: invalid lpppty.', lpppty(kp)
         call s2ext_abort
      end if
!....
      call fdebug ( 'qstrtpos', 1 )
!....
      return
      end
