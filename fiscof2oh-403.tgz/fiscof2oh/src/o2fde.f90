!----------------------------------------------------------------------
! Observe 2D Field Density Electron
!                          /
      subroutine o2fde ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 20, ifn = 1
      integer :: kflag, i, iofde, ilog, icrsx, icrsy, ix, iy, ixy, &
                 iwdea
      real*8:: wminlog
      real*8, allocatable :: wdea(:)
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o2fde', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         if( lcfde .eq. 0 ) call c2fde
#ifdef OHHELP
         if( loxypl .gt. 0 ) then
#endif
         iwdea = iwdea + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wdea(ixy) = wdea(ixy) + sde(ix,iy)
            end do
         end do
#ifdef OHHELP
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do i = 1, loxypl
               wdea(i) = wdea(i) / ( iwdea * snepm1 )
            end do
            if( iofde .le. 4 ) then
               write(iun) sstcur, ( wdea(i),i=1,loxypl )
               flush(iun)
            end if
            if( iofde .ge. 2 ) then
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                               ifn, ilog, 3, icrsx, icrsy, &
                               wdea, loxpl, loypl, &
                               soxmic, soxp0m, soymic, soyp0m, 'fde ' )
            end if
          end if
!....
         else
            iofde = mod( lofde, 10 )
            ilog  = mod( lofde/10, 10 )
            icrsx = mod( lofde/100, 100 )
            icrsy = lofde/10000
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wdea) ) allocate( wdea(loxypl) )
            end if
!
            if( iofde .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fde', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fde2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               write(iun) 'fde3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if( iofde .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fde', bfile )
               call frames_file ( bfile, ifn, iofde )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwdea = 0
            do i = 1, loxypl
               wdea(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fde', 1 )
!....
      return
      end
