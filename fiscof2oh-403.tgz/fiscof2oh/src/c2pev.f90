!-----------------------------------------------------------------------
! Compute 2D Particle Electron Velocity
!
      subroutine c2pev
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/14
!-----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use particle
      include "implicit.h"
      integer :: i
      real*8  :: wtmp
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2pev', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wtmp)
      do i = lnoes, lnoee
         wtmp = s1o1 / sqrt( s1o1 + suue(i)**2 * scg1 )
         svxe(i) = suxe(i) * wtmp
         svye(i) = suye(i) * wtmp
         svze(i) = suze(i) * wtmp
      end do
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c2pev', 1 )
!....
      return
      end
