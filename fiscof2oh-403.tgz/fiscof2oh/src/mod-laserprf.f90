!----------------------------------------------------------------------
! laser profile
!
module laserprf
      use parameter
      integer :: &
         llsrbn, llsrty, llinx, lliny, llxps, llxpe, lltend, lltcur, &
         lbemty(llsrbx), lbemix(llsrbx)
      real*8 :: &
         slpwr, slramm, slomg, slram, &
         slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
         sbempw(llsrbx), sbemwl(llsrbx), sbemle(llsrbx), &
         sbemwd(llsrbx), sbemtr(llsrbx), sbemmn(llsrbx), &
         sbemfi(llsrbx), sbemal(llsrbx), &
         sbemxf(llsrbx), sbemyf(llsrbx), &
         sbeman(llsrbx), sbemph(llsrbx), sbemdl(llsrbx), &
         sbemanr(llsrbx), sbemomg(llsrbx), &
         sla(llsrbx), slinea(llsrbx), slinba(llsrbx), slinjy
end module laserprf
