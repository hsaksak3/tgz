!----------------------------------------------------------------------
! Set 2D EXTernal system ABORT
!
      subroutine s2ext_abort
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
#ifdef OHHELP
      use parameter
      include "implicit.h"
      include "mpif.h"
      integer :: ierr
#endif
!....
      call fdebug ( 's2ext_abort', 0 )
!....
      flush(6)
#ifdef OHHELP
      write(0,*) '### ABORT: called by lrank =', lrank
      call MPI_ABORT ( MPI_COMM_WORLD, lrank, ierr )
      if( ierr .ne. 0 ) &
         write(0,*) '### ERROR: MPI_ABORT, ierr =', ierr
      flush(0)
#endif
!....
      stop 99999
!....
      end
