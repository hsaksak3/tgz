!----------------------------------------------------------------------
! Advance 2D Field LaSeR
!
      subroutine a2flsr
!
!   <arguments>
!     none
!
!   <remarks>
!     preadvance laser just before the plasma.
!
!    coded by Sakagami,H. (NIFS) 10/08/17
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use profile
      use laserprf
      include "implicit.h"
      integer :: i, iok, ipolm, itrns, itype, iyin, iyd, iys, iye
      real*8  :: wx, wy, wt, wbw0, wxl
      save
!....
      call fdebug ( 'a2flsr', 0 )
!....
      if( llsrbn .eq. 0 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ no laser'
        go to 999
!...
      else if( llsrty .eq. -1 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ laser is excited at (',llinx,',',lliny,') by bz'
!...
      else if( llsrty .eq. -2 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ laser is excited at (',llinx,',',lliny,') by ez'
!...
      else if( llsrty .eq. -3 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ laser is excited at (',llinx,',',lliny,') ', &
                    'by bz and ez'
!...
      else if( llsrty .eq. -4 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ laser is excited at (',llinx,', * ) by jy'
!...
      else if( llsrty .eq. -5 ) then
        if( lrank .le. 0 ) &
        write(6,*) '@@@ laser is excited at (',llinx,',',lliny,') ', &
                    'by constant jz'
!...
      else
         iok = 1
         do i = 1, llsrbn
            itype = mod( lbemty(i), 10 )
            itrns = mod( lbemty(i)/10, 10 )
            ipolm = lbemty(i) / 100
            if( itype .lt. 1 .or. itype .gt. 4 ) iok = 0
            if( itrns .lt. 1 .or. itrns .gt. 4 ) iok = 0
            if( ipolm .lt. 1 .or. ipolm .gt. 4 ) iok = 0
            if( iok .eq. 1 ) then
               if( lbemix(i) .ge. 0 ) then
                  wxl = sbemxf(i) - ( lbemix(i)-lxp0 ) * slmicinv
               else
                  wxl = ( lssx+lbemix(i)-lxp0 ) * slmicinv - sbemxf(i)
               end if
               if( ipolm .eq. 1 ) then
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ TM laser is excited at (', &
                             lbemix(i),', * ) as beam #', i
               else if( ipolm .eq. 2 ) then
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ TE laser is excited at (', &
                             lbemix(i),', * ) as beam #', i
               else if( ipolm .eq. 3 ) then
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ R-CP laser is excited at (', &
                             lbemix(i),', * ) as beam #', i
               else
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ L-CP laser is excited at (', &
                             lbemix(i),', * ) as beam #', i
               end if
!..
               if( itrns .eq. 1 ) then
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ laser transvers width(mesh)', &
                              i, 'infinite'
               else
                  iyin = (wxl*tan(sbemanr(i)) + sbemyf(i))*slmic + lyp0
                  if( itrns .eq. 2 ) then
                     iyd = sqrt(-log(sbemmn(i))/log(s2o1)) * &
                             (sbemfi(i)/cos(sbemanr(i))) * s1o2 * slmic
                  else if( itrns .eq. 3 ) then
                     iyd = ( -log(sbemmn(i))/log(s2o1) )** &
                             (s1o1/sbemal(i)) * &
                             (sbemfi(i)/cos(sbemanr(i))) * s1o2 * slmic
                  else
                     wbw0 = s2o1 * sbemwl(i) * sbemfi(i) / spi
                     wx = wxl / cos(sbemanr(i))
                     wy = spi * wbw0**2 / sbemwl(i)
                     wt = wbw0 * sqrt( s1o1 + (wx/wy)**2 )
                     iyd = sqrt( -log(sbemmn(i))/s2o1 ) * &
                                           (wt/cos(sbemanr(i))) * slmic
                  end if
                  iys = iyin - iyd
                  if( iys .lt. 1 ) then
                     write(0,*) '### ERROR: transvers width(s)', &
                                 i,iys,iyin,iyd
                     call s2ext_abort
                  end if
                  iye = iyin + iyd
                  if( iye .gt. lssy ) then
                     write(0,*) '### ERROR: transvers width(e)', &
                                i,lssy,iye,iyin,iyd
                     call s2ext_abort
                  end if
                  if( lrank .le. 0 ) &
                  write(6,*) '@@@ laser center, transvers width(mesh)',&
                             i, iyin, iyd*2
               end if
            else
               write(0,*) '### ERROR: invalid lbemty =', i, lbemty(i)
               call s2ext_abort
            end if
         end do
      end if
!.
      if( llxps .lt. 0 ) llxps = lxps
      if( llxpe .lt. 0 ) llxpe = lxpe
      if( lltend .lt. 0 ) then
         if( lpprof .eq. 0 ) then
            lltend = 0
         else
            do i = 1, llsrbn
               if( lbemix(i) .ge. 0 ) then
                  iok = ( llxps - lbemix(i) - 10 )*scflinv
               else
                  iok = ( lssx+lbemix(i) - llxpe -10 )*scflinv
               end if
               lltend = max( lltend, iok )
            end do
         end if
      end if
      if( lrank .le. 0 ) &
      write(6,*) '@@@ llxps, llxpe, lltend = ', llxps, llxpe, lltend
    1 continue
      if( lltcur .ge. lltend ) go to 2
         lltcur = lltcur + 1
!.
         call c2flsr
!.
         call a2fbte
         call a2fbtm
         call b2fbte ( 1 )
         call b2fbtm ( 1 )
         call s2ext_exec( 3 )
! 
         call a2fete
         call a2fetm
         call b2fete
         call b2fetm
         call s2ext_exec( 2 )
!
         call c2fed
         call a2fbte
         call a2fbtm
         call b2fbte ( 0 )
         call b2fbtm ( 0 )
         call s2ext_exec( 3 )
      go to 1
    2 continue
!....
  999 continue
      call fdebug ( 'a2flsr', 1 )
!....
      return
      end
