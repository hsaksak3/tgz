!-----------------------------------------------------------------------
! Compute 2D Field current(J) Ion
!
      subroutine c2fji
!
!   <arguments>
!     none
!
!   <remarks>
!     do not care the boundary factors.
!
!    coded by Sakagami,H. (NIFS) 09/04/09
! modifedd by Sakagami,H. (NIFS) 10/06/07
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#include "spdat.macro"
#include "vector.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, ixi, iyi, ixih, iyih
      real*8  :: wdxh,wx1h,wx2h,wx3h,wx4h,wdyh,wy1h,wy2h,wy3h,wy4h
      real*8, allocatable :: wjzi(:,:)
#ifdef VECTOR
      real*8, allocatable :: vwjz(:,:,:)
      integer :: iv, iv2
#endif
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2fji', 0 )
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
#else
      if( oh_glnoi .gt. 0 ) then
#endif
!....
      if( .not. allocated(wjzi) ) then
#ifndef OHHELP
         allocate( wjzi(lssxlm1:lssxup2,lssylm1:lssyup2) )
#else
         allocate ( &
            wjzi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)) )
#endif
      end if
#ifdef VECTOR
#ifndef OHHELP
      allocate( vwjz(lvlen,lssxlm1:lssxup2,lssylm1:lssyup2) )
#else
      allocate ( &
            vwjz(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                       oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)) )
#endif
#endif
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL PRIVATE(io,ixih,wdxh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                     iyih,wdyh,wy1h,wy2h,wy3h,wy4h)
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup2
            do ix = lssxlm1, lssxup2
               wjzi(ix,iy) = s0o1
            end do
         end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm1, lssyup2
           do ix = lssxlm1, lssxup2
             do iv = 1, lvlen
               vwjz(iv,ix,iy) = s0o1
             end do
           end do
         end do
#endif
!...
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjzi)
         do i = lionids(io), lionide(io)
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vwjz)
         do iv2 = lionids(io), lionide(io), lvlen
!NEC$ IVDEP
         do iv = 1, min(lionide(io)-iv2+1, lvlen)
            i = iv + iv2 - 1
#endif
!..
            ixih = sxi(i) + s1o2
            wdxh = sxi(i) - ixih
            wx1h = (s1o2-wdxh)**3*s1o6
            wx2h = (s1o2+wdxh)**2*(wdxh-s3o2)*s1o2 + s2o3
            wx3h =-(s1o2-wdxh)**2*(wdxh+s3o2)*s1o2 + s2o3
            wx4h = (s1o2+wdxh)**3*s1o6
!.
            iyih = syi(i) + s1o2
            wdyh = syi(i) - iyih
            wy1h = (s1o2-wdyh)**3*s1o6
            wy2h = (s1o2+wdyh)**2*(wdyh-s3o2)*s1o2 + s2o3
            wy3h =-(s1o2-wdyh)**2*(wdyh+s3o2)*s1o2 + s2o3
            wy4h = (s1o2+wdyh)**3*s1o6
#ifdef OHHELP
            ixih = ixih - oh_ixs
            iyih = iyih - oh_iys
#endif
!..
            _wjzi(ixih-1,iyih-1) = _wjzi(ixih-1,iyih-1) + &
                          svzi(i) * spfi(i) * wx1h * wy1h
            _wjzi(ixih,  iyih-1) = _wjzi(ixih,  iyih-1) + &
                          svzi(i) * spfi(i) * wx2h * wy1h
            _wjzi(ixih+1,iyih-1) = _wjzi(ixih+1,iyih-1) + &
                          svzi(i) * spfi(i) * wx3h * wy1h
            _wjzi(ixih+2,iyih-1) = _wjzi(ixih+2,iyih-1) + &
                          svzi(i) * spfi(i) * wx4h * wy1h
!
            _wjzi(ixih-1,iyih  ) = _wjzi(ixih-1,iyih  ) + &
                          svzi(i) * spfi(i) * wx1h * wy2h
            _wjzi(ixih,  iyih  ) = _wjzi(ixih,  iyih  ) + &
                          svzi(i) * spfi(i) * wx2h * wy2h
            _wjzi(ixih+1,iyih  ) = _wjzi(ixih+1,iyih  ) + &
                          svzi(i) * spfi(i) * wx3h * wy2h
            _wjzi(ixih+2,iyih  ) = _wjzi(ixih+2,iyih  ) + &
                          svzi(i) * spfi(i) * wx4h * wy2h
!
            _wjzi(ixih-1,iyih+1) = _wjzi(ixih-1,iyih+1) + &
                          svzi(i) * spfi(i) * wx1h * wy3h
            _wjzi(ixih,  iyih+1) = _wjzi(ixih,  iyih+1) + &
                          svzi(i) * spfi(i) * wx2h * wy3h
            _wjzi(ixih+1,iyih+1) = _wjzi(ixih+1,iyih+1) + &
                          svzi(i) * spfi(i) * wx3h * wy3h
            _wjzi(ixih+2,iyih+1) = _wjzi(ixih+2,iyih+1) + &
                          svzi(i) * spfi(i) * wx4h * wy3h
!
            _wjzi(ixih-1,iyih+2) = _wjzi(ixih-1,iyih+2) + &
                          svzi(i) * spfi(i) * wx1h * wy4h
            _wjzi(ixih,  iyih+2) = _wjzi(ixih,  iyih+2) + &
                          svzi(i) * spfi(i) * wx2h * wy4h
            _wjzi(ixih+1,iyih+2) = _wjzi(ixih+1,iyih+2) + &
                          svzi(i) * spfi(i) * wx3h * wy4h
            _wjzi(ixih+2,iyih+2) = _wjzi(ixih+2,iyih+2) + &
                          svzi(i) * spfi(i) * wx4h * wy4h
#ifdef VECTOR
         end do
#endif
!.
         end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm1, lssyup2
           do ix = lssxlm1, lssxup2
             do iv = 1, lvlen
               wjzi(ix,iy) = wjzi(ix,iy) + vwjz(iv,ix,iy)
             end do
           end do
         end do
#endif
!..
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm1, lssyup2
               wjzi(lssxlm1,iy) = wjzi(lssxlm1,iy) + wjzi(lssxum1,iy)
               wjzi(lssxl  ,iy) = wjzi(lssxl  ,iy) + wjzi(lssxu  ,iy)
               wjzi(lssxlp1,iy) = wjzi(lssxlp1,iy) + wjzi(lssxup1,iy)
               wjzi(lssxlp3,iy) = wjzi(lssxlp3,iy) + wjzi(lssxup2,iy)
            end do
         end if
         if( lexuf .eq. 1 ) then
            if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm1, lssyup2
                  wjzi(lssxum1,iy) = wjzi(lssxlm1,iy)
                  wjzi(lssxu  ,iy) = wjzi(lssxl  ,iy)
                  wjzi(lssxup1,iy) = wjzi(lssxlp1,iy)
                  wjzi(lssxup2,iy) = wjzi(lssxlp3,iy)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm1, lssyup2
                  wjzi(lssxum1,iy) = wjzi(lssxlm1,iy) + wjzi(lssxum1,iy)
                  wjzi(lssxu  ,iy) = wjzi(lssxl  ,iy) + wjzi(lssxu  ,iy)
                  wjzi(lssxup1,iy) = wjzi(lssxlp1,iy) + wjzi(lssxup1,iy)
                  wjzi(lssxup2,iy) = wjzi(lssxlp3,iy) + wjzi(lssxup2,iy)
               end do
            end if
         end if
!..
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup2
               wjzi(ix,lssylm1) = wjzi(ix,lssylm1) + wjzi(ix,lssyum1)
               wjzi(ix,lssyl  ) = wjzi(ix,lssyl  ) + wjzi(ix,lssyu  )
               wjzi(ix,lssylp1) = wjzi(ix,lssylp1) + wjzi(ix,lssyup1)
               wjzi(ix,lssylp2) = wjzi(ix,lssylp2) + wjzi(ix,lssyup2)
            end do
         end if
         if( leyuf .eq. 1 ) then
            if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm1, lssxup2
                  wjzi(ix,lssyum1) = wjzi(ix,lssylm1)
                  wjzi(ix,lssyu  ) = wjzi(ix,lssyl  )
                  wjzi(ix,lssyup1) = wjzi(ix,lssylp1)
                  wjzi(ix,lssyup2) = wjzi(ix,lssylp2)
               end do
         else
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm1, lssxup2
                  wjzi(ix,lssyum1) = wjzi(ix,lssylm1) + wjzi(ix,lssyum1)
                  wjzi(ix,lssyu  ) = wjzi(ix,lssyl  ) + wjzi(ix,lssyu  )
                  wjzi(ix,lssyup1) = wjzi(ix,lssylp1) + wjzi(ix,lssyup1)
                  wjzi(ix,lssyup2) = wjzi(ix,lssylp2) + wjzi(ix,lssyup2)
               end do
            end if
         end if
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup2
            do ix = lssxlm1, lssxup2
               sjzi(ix,iy,io) = wjzi(ix,iy) * sionaz(io)
            end do
         end do
!...
      end do
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
#ifdef VECTOR
      deallocate ( vwjz )
#endif
      end if
!....
      call fdebug ( 'c2fji', 1 )
!....
      return
      end
