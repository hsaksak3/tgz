!----------------------------------------------------------------------
! field
!
module field
      integer :: lcfde, lcfdi
      real*8, allocatable, save :: &
        sde0(:,:), sdi(:,:,:), &
        scaxlh(:),scbbtexl(:),sccbtexl(:),scbetmxl(:),sccetmxl(:), &
        scaxl(:), scbetexl(:),sccetexl(:),scbbtmxl(:),sccbtmxl(:), &
        scaxuh(:),scbbtexu(:),sccbtexu(:),scbetmxu(:),sccetmxu(:), &
        scaxu(:), scbetexu(:),sccetexu(:),scbbtmxu(:),sccbtmxu(:), &
        scaylh(:),scbbteyl(:),sccbteyl(:),scbetmyl(:),sccetmyl(:), &
        scayl(:), scbeteyl(:),scceteyl(:),scbbtmyl(:),sccbtmyl(:), &
        scayuh(:),scbbteyu(:),sccbteyu(:),scbetmyu(:),sccetmyu(:), &
        scayu(:), scbeteyu(:),scceteyu(:),scbbtmyu(:),sccbtmyu(:)
#ifndef OHHELP
      real*8, allocatable, save :: &
        sde(:,:), &
        sebxy(:,:,:), sez(:,:), sbz(:,:), sjxyzt(:,:,:), &
        sdezdy(:,:), sdezdx(:,:), sdeyxdxy(:,:), &
        sjxe(:,:),   sjye(:,:),   sjze(:,:), &
        sjxi(:,:,:), sjyi(:,:,:), sjzi(:,:,:), &
        sezxxl(:,:), sezyxl(:,:), sbzxxl(:,:), sbzyxl(:,:), &
        sezxxu(:,:), sezyxu(:,:), sbzxxu(:,:), sbzyxu(:,:), &
        sezxyl(:,:), sezyyl(:,:), sbzxyl(:,:), sbzyyl(:,:), &
        sezxyu(:,:), sezyyu(:,:), sbzxyu(:,:), sbzyyu(:,:)
#else
      real*8, allocatable, save :: &
        oh_sde(:,:,:), &
        oh_sexyz(:,:,:,:), oh_sbxyz(:,:,:,:), oh_sjxyzt(:,:,:,:), &
        oh_sdezdy(:,:,:), oh_sdezdx(:,:,:), oh_sdeyxdxy(:,:,:), &
        oh_sjxe(:,:,:),   oh_sjye(:,:,:),   oh_sjze(:,:,:),   &
        oh_sjxi(:,:,:,:), oh_sjyi(:,:,:,:), oh_sjzi(:,:,:,:), &
        oh_sebpmlxl(:,:,:,:), oh_sebpmlxu(:,:,:,:), &
        oh_sebpmlyl(:,:,:,:), oh_sebpmlyu(:,:,:,:)
#endif
end module field
