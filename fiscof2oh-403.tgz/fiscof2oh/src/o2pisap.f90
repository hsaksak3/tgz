!----------------------------------------------------------------------
! Observe 2D Particle Ion Shock parameters Average Profile
!                             /
       subroutine o2pisap ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
! modified by Sakagami,H. ( NIFS ) 15/11/27 for include in fiscof2
!----------------------------------------------------------------------
#include "spdat.macro"
       use parameter
       use constant
       use observe
       use particle
       include "implicit.h"
       integer :: kflag, i, io, iopisap, icrsx, iwpisap, &
                  ix, iy, ixy, ixi, iyi
       real*8  :: wdx,wx1,wx2,wx3,wx4,wdy,wy1,wy2,wy3,wy4,wkev
       real*8, allocatable :: wn(:,:), wvxi(:,:), wti(:,:), &
                               wdia(:,:), wvxia(:,:), &
                               wtia(:,:), wpia(:,:)
       real*8, parameter :: wcns1 = 2.0d0, wminlog = 1.0d-3
       character*20 clabel
       save

       call fdebug ( 'o2pisap', 0 )
#ifndef OHHELP
       if(  .not. allocated(wn) ) &
          allocate( wn(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wvxi(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wti(lssxlm1:lssxup1,lssylm1:lssyup1), &
                    wdia(loxypl,lionspl), wvxia(loxypl,lionspl), &
                    wtia(loxypl,lionspl), wpia(loxypl,lionspl) )

       iopisap = mod( lopisap, 10 )
       icrsx   = mod( lopisap/100, 100 )

       if( kflag .ge. 2 ) then
          iwpisap = iwpisap + 1
          do io = 1, lionspl
             do iy = lssylm1, lssyup1
                do ix = lssxlm1, lssxup1
                    wn(ix,iy)    = s0o1
                    wvxi(ix,iy)  = s0o1
                    wti(ix,iy)   = s0o1
                end do
             end do

             do i = lionids(io), lionide(io)

                if( sxi(i) .lt. loxps .or. sxi(i) .gt. loxpe ) cycle
                if( syi(i) .lt. loyps .or. syi(i) .gt. loype ) cycle

                ixi = sxi(i)
                wdx = sxi(i) - ixi - s1o2
                wx1 = (s1o2-wdx)**3*s1o6
                wx2 = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
                wx3 =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
                wx4 = (s1o2+wdx)**3*s1o6

                iyi = syi(i)
                wdy = syi(i) - iyi - s1o2
                wy1 = (s1o2-wdy)**3*s1o6
                wy2 = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
                wy3 =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
                wy4 = (s1o2+wdy)**3*s1o6

                wn(ixi-1,iyi-1) = wn(ixi-1,iyi-1) + spfi(i) * wx1 * wy1
                wn(ixi  ,iyi-1) = wn(ixi  ,iyi-1) + spfi(i) * wx2 * wy1
                wn(ixi+1,iyi-1) = wn(ixi+1,iyi-1) + spfi(i) * wx3 * wy1
                wn(ixi+2,iyi-1) = wn(ixi+2,iyi-1) + spfi(i) * wx4 * wy1

                wn(ixi-1,iyi  ) = wn(ixi-1,iyi  ) + spfi(i) * wx1 * wy2
                wn(ixi  ,iyi  ) = wn(ixi  ,iyi  ) + spfi(i) * wx2 * wy2
                wn(ixi+1,iyi  ) = wn(ixi+1,iyi  ) + spfi(i) * wx3 * wy2
                wn(ixi+2,iyi  ) = wn(ixi+2,iyi  ) + spfi(i) * wx4 * wy2

                wn(ixi-1,iyi+1) = wn(ixi-1,iyi+1) + spfi(i) * wx1 * wy3
                wn(ixi  ,iyi+1) = wn(ixi  ,iyi+1) + spfi(i) * wx2 * wy3
                wn(ixi+1,iyi+1) = wn(ixi+1,iyi+1) + spfi(i) * wx3 * wy3
                wn(ixi+2,iyi+1) = wn(ixi+2,iyi+1) + spfi(i) * wx4 * wy3

                wn(ixi-1,iyi+2) = wn(ixi-1,iyi+2) + spfi(i) * wx1 * wy4
                wn(ixi  ,iyi+2) = wn(ixi  ,iyi+2) + spfi(i) * wx2 * wy4
                wn(ixi+1,iyi+2) = wn(ixi+1,iyi+2) + spfi(i) * wx3 * wy4
                wn(ixi+2,iyi+2) = wn(ixi+2,iyi+2) + spfi(i) * wx4 * wy4

                wvxi(ixi-1,iyi-1) = wvxi(ixi-1,iyi-1) + spfi(i) * wx1 * wy1 &
                                                      * svxi(i)
                wvxi(ixi  ,iyi-1) = wvxi(ixi  ,iyi-1) + spfi(i) * wx2 * wy1 &
                                                      * svxi(i)
                wvxi(ixi+1,iyi-1) = wvxi(ixi+1,iyi-1) + spfi(i) * wx3 * wy1 &
                                                      * svxi(i)
                wvxi(ixi+2,iyi-1) = wvxi(ixi+2,iyi-1) + spfi(i) * wx4 * wy1 &
                                                      * svxi(i)

                wvxi(ixi-1,iyi  ) = wvxi(ixi-1,iyi  ) + spfi(i) * wx1 * wy2 &
                                                      * svxi(i)
                wvxi(ixi  ,iyi  ) = wvxi(ixi  ,iyi  ) + spfi(i) * wx2 * wy2 &
                                                      * svxi(i)
                wvxi(ixi+1,iyi  ) = wvxi(ixi+1,iyi  ) + spfi(i) * wx3 * wy2 &
                                                      * svxi(i)
                wvxi(ixi+2,iyi  ) = wvxi(ixi+2,iyi  ) + spfi(i) * wx4 * wy2 &
                                                      * svxi(i)

                wvxi(ixi-1,iyi+1) = wvxi(ixi-1,iyi+1) + spfi(i) * wx1 * wy3 &
                                                      * svxi(i)
                wvxi(ixi  ,iyi+1) = wvxi(ixi  ,iyi+1) + spfi(i) * wx2 * wy3 &
                                                      * svxi(i)
                wvxi(ixi+1,iyi+1) = wvxi(ixi+1,iyi+1) + spfi(i) * wx3 * wy3 &
                                                      * svxi(i)
                wvxi(ixi+2,iyi+1) = wvxi(ixi+2,iyi+1) + spfi(i) * wx4 * wy3 &
                                                      * svxi(i)

                wvxi(ixi-1,iyi+2) = wvxi(ixi-1,iyi+2) + spfi(i) * wx1 * wy4 &
                                                      * svxi(i)
                wvxi(ixi  ,iyi+2) = wvxi(ixi  ,iyi+2) + spfi(i) * wx2 * wy4 &
                                                      * svxi(i)
                wvxi(ixi+1,iyi+2) = wvxi(ixi+1,iyi+2) + spfi(i) * wx3 * wy4 &
                                                      * svxi(i)
                wvxi(ixi+2,iyi+2) = wvxi(ixi+2,iyi+2) + spfi(i) * wx4 * wy4 &
                                                      * svxi(i)

                wti(ixi-1,iyi-1) = wti(ixi-1,iyi-1) + spfi(i) * wx1 * wy1 &
                                                      * (svxi(i))**2
                wti(ixi  ,iyi-1) = wti(ixi  ,iyi-1) + spfi(i) * wx2 * wy1 &
                                                      * (svxi(i))**2
                wti(ixi+1,iyi-1) = wti(ixi+1,iyi-1) + spfi(i) * wx3 * wy1 &
                                                      * (svxi(i))**2
                wti(ixi+2,iyi-1) = wti(ixi+2,iyi-1) + spfi(i) * wx4 * wy1 &
                                                      * (svxi(i))**2

                wti(ixi-1,iyi  ) = wti(ixi-1,iyi  ) + spfi(i) * wx1 * wy2 &
                                                      * (svxi(i))**2
                wti(ixi  ,iyi  ) = wti(ixi  ,iyi  ) + spfi(i) * wx2 * wy2 &
                                                      * (svxi(i))**2
                wti(ixi+1,iyi  ) = wti(ixi+1,iyi  ) + spfi(i) * wx3 * wy2 &
                                                      * (svxi(i))**2
                wti(ixi+2,iyi  ) = wti(ixi+2,iyi  ) + spfi(i) * wx4 * wy2 &
                                                      * (svxi(i))**2

                wti(ixi-1,iyi+1) = wti(ixi-1,iyi+1) + spfi(i) * wx1 * wy3 &
                                                      * (svxi(i))**2
                wti(ixi  ,iyi+1) = wti(ixi  ,iyi+1) + spfi(i) * wx2 * wy3 &
                                                      * (svxi(i))**2
                wti(ixi+1,iyi+1) = wti(ixi+1,iyi+1) + spfi(i) * wx3 * wy3 &
                                                      * (svxi(i))**2
                wti(ixi+2,iyi+1) = wti(ixi+2,iyi+1) + spfi(i) * wx4 * wy3 &
                                                      * (svxi(i))**2

                wti(ixi-1,iyi+2) = wti(ixi-1,iyi+2) + spfi(i) * wx1 * wy4 &
                                                      * (svxi(i))**2
                wti(ixi  ,iyi+2) = wti(ixi  ,iyi+2) + spfi(i) * wx2 * wy4 &
                                                      * (svxi(i))**2
                wti(ixi+1,iyi+2) = wti(ixi+1,iyi+2) + spfi(i) * wx3 * wy4 &
                                                      * (svxi(i))**2
                wti(ixi+2,iyi+2) = wti(ixi+2,iyi+2) + spfi(i) * wx4 * wy4 &
                                                      * (svxi(i))**2
             end do

             do iy = loyps, loype, loypi
                do ix = loxps, loxpe, loxpi
                   if ( wn(ix,iy) .gt. wcns1 ) then
                     wvxi(ix,iy) = wvxi(ix,iy) / wn(ix,iy)
                     wti(ix,iy)  = wti(ix,iy)  / wn(ix,iy) - wvxi(ix,iy)**2
                   else
                     wvxi(ix,iy) = s0o1
                     wti(ix,iy)  = s0o1
                   end if
                end do
             end do
             ixy = 0
             do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                 ixy = ixy + 1
                 wdia(ixy,io)  = wdia(ixy,io)  + wn(ix,iy)
                 wvxia(ixy,io) = wvxia(ixy,io) + wvxi(ix,iy)
                 wtia(ixy,io)  = wtia(ixy,io)  + wti(ix,iy)
                 wpia(ixy,io)  = wpia(ixy,io)  + wti(ix,iy) * wn(ix,iy)
               end do
             end do
          end do

       end if

       if( kflag .le. 2 ) then
          if( kflag .ge. 1 ) then
             do io = 1, lionspl
                do i = 1, loxypl
                   wdia(i,io)  = wdia(i,io) / ( snepm1*iwpisap )
                   wvxia(i,io) = wvxia(i,io) * scflinv / iwpisap
                   wtia(i,io)  = wtia(i,io) /svti(io)**2 * wkev/iwpisap
                   wpia(i,io)  = wpia(i,io) /svti(io)**2 * wkev &
                                         / ( snepm1 * iwpisap ) * scofp
                end do
             end do

             if( iopisap .le. 4 ) then
                write(40) sstcur, &
                    ( ( wdia(i,io),i=1,loxypl ),io=1,lionspl ), &
                    ( ( wvxia(i,io),i=1,loxypl ),io=1,lionspl), &
                    ( ( wtia(i,io),i=1,loxypl ),io=1,lionspl ), &
                    ( ( wpia(i,io),i=1,loxypl ),io=1,lionspl )
                flush(40)
             end if
             if( iopisap .ge. 2 ) then
                do io = 1, lionspl
                  if( icrsx .ge. 1 ) then
                     call o2ionlabel ( io,sionam(io),sionaz(io),clabel )
                     call frames_body25 ( bident, sstcur, &
                     20, wdia(1,io), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                             'Ion Density[Ni/Ncr]'//clabel )
                     call frames_body25 ( bident, sstcur, &
                     20, wvxia(1,io), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                        'Ion Mean X Velocity[V/c]'//clabel )
                     call frames_body25 ( bident, sstcur, &
                     20, wtia(1,io), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                       'Ion Temperature[KeV]'//clabel )
                     call frames_body25 ( bident, sstcur, &
                     20, wpia(1,io), loxypl, loxpl, loypl, icrsx, &
                     0, soxmic, soxp0m, soymic, soyp0m, &
                       'Ion X Pressure[Mbar]'//clabel )
                  end if
                end do
             end if
          else
             wkev = stemr * ( 22.6054d0 / scr )**2
             if( iopisap .le. 4 ) then
                call fntpcnv ( bbifntp, lrank,40,bident,'pisap',bfile)
                open( 40, file=bfile, form='UNFORMATTED' )
                write(40) 'pis2', bident,loxypl,loxpl,loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                          lionspl,(sionam(io),sionaz(io),io=1,lionspl)
                flush(40)
             end if
             if( iopisap .ge. 2 ) then
                call fntpcnv ( bfrfntp, lrank,20,bident,'pisap',bfile )
                call frames_file ( bfile, 20, iopisap )
             end if
          end if
          iwpisap = 0
          do io = 1, lionspl
             do i = 1, loxypl
                wdia(i,io)  = s0o1
                wvxia(i,io) = s0o1
                wtia(i,io)  = s0o1
                wpia(i,io)  = s0o1
             end do
          end do

       end if
#endif
       call fdebug ( 'o2pisap', 1 )

       return
       end
