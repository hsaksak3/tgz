!----------------------------------------------------------------------
! Set 2D EXTernal system TERMinate
!
      subroutine s2ext_term
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
#ifdef OHHELP
      include "implicit.h"
      integer :: ierr
#endif
!....
      call fdebug ( 's2ext_term', 0 )
!....
      call frames_term
!..
      call gdfxs_term
!....
#ifdef OHHELP
      call MPI_FINALIZE ( ierr )
      if( ierr .ne. 0 ) &
          write(0,*) '### ERROR: MPI_FINALIZE, ierr =', ierr
#endif
!....
      call fdebug ( 's2ext_term', 1 )
!....
      return
      end
