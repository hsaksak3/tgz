!----------------------------------------------------------------------
! Observe 2D Field Current Total
!                          /
      subroutine o2fjt ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/07/15
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 42, ifn = 22
      integer :: kflag, i, iofjt, int, ix,iy,ixy, iwfjta, idum
      real*8  :: wampx
      real*8, allocatable :: wfjx(:), wfjy(:), wfjz(:)
#ifdef OHHELP
      integer :: ips=1
!       integer, parameter :: iun2 = 82
!       integer :: ixsize, iysize
#endif
      save
!....
      call fdebug ( 'o2fjt', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwfjta = iwfjta + 1
         ixy = 0
         do iy = loyps, loype, loypi
           do ix = loxps, loxpe, loxpi
             ixy = ixy + 1
             wfjx(ixy) = wfjx(ixy) + sjxt(ix,iy)
             wfjy(ixy) = wfjy(ixy) + sjyt(ix,iy)
             wfjz(ixy) = wfjz(ixy) + sjzt(ix,iy)
           end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            wampx = -1.0d30
            do i = 1, loxypl
              wfjx(i) = wfjx(i) / ( iwfjta * snepm1 * scfl )
              wfjy(i) = wfjy(i) / ( iwfjta * snepm1 * scfl )
              wfjz(i) = wfjz(i) / ( iwfjta * snepm1 * scfl )
              wampx = max( wampx, &
                           wfjx(i)**2+wfjy(i)**2+wfjz(i)**2 )
            end do
            wampx = sqrt( wampx )
!..
            if( iofjt .le. 4 ) then
              write(iun) sstcur, &
                         (wfjx(i),wfjy(i),wfjz(i),i=1,loxypl), wampx
              flush(iun)
            end if
            if( iofjt .ge. 2 ) then
              call o2fdraw5 ( bident, sstcur, ifn, 2, int, 2, &
                    wampx, wfjx, wfjy, wfjz, loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
                    'fjxt', 'fjyt', 'fjzt', 'fjxyt', 'fjyzt', 'fjxzt' )
            end if
          end if
! #ifdef OHHELP
!           write(iun2) sstcur, oh_sjxyzt, oh_sdid
!           flush(iun2)
! #endif
!....
         else
            iofjt = mod( lofjt, 10 )
            idum  = mod( lofjt/10, 10 )
            int   = lofjt/100
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wfjx) ) &
               allocate( wfjx(loxypl), wfjy(loxypl), wfjz(loxypl) )
            end if
!
            if( iofjt .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fjt', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fjt2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               write(iun) 'fjt3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
! #ifdef OHHELP
!                ixsize = size( oh_sjxyzt, 2 )
!                iysize = size( oh_sjxyzt, 3 )
!                call fntpcnv ( bbifntp, lrank,iun2, bident,'fjt', bfile )
!               open( iun2, file=bfile, form='UNFORMATTED' )
!               write(iun2) 'fjtd', bident, ixsize, iysize, &
!                           lrank, ldivx, ldivy
!               flush(iun2)
!#endif
            end if
            if( iofjt .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fjt', bfile )
               call frames_file ( bfile, ifn, iofjt )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwfjta = 0
            do i = 1, loxypl
              wfjx(i) = s0o1
              wfjy(i) = s0o1
              wfjz(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fjt', 1 )
!....
      return
      end
