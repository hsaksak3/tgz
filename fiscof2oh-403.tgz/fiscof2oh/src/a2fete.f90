!-----------------------------------------------------------------------
! Advance 2D Field Electric - TE
!
      subroutine a2fete
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'a2fete', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sez(ix,iy) = sez(ix,iy) + ( sby(ix,iy) - sby(ix-1,iy) -  &
                         sbx(ix,iy) + sbx(ix,iy-1) ) * scb1 +  &
                         sjzt(ix,iy) * scj1
         end do
      end do
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'a2fete', 1 )
!....
      return
      end
