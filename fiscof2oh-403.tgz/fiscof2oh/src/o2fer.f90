!----------------------------------------------------------------------
! Observe 2D Field electric(E) Raw
!                          /
      subroutine o2fer ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 23, ifn = 4
      integer :: kflag, i, iofer, icrsx, icrsy, ix, iy, ixy, iwera, inst
      real*8, allocatable :: wexa(:), weya(:), weza(:), &
                             wexi(:), weyi(:), wezi(:)
      character(4) :: chead
#ifdef OHHELP
      integer :: ips=1
!       integer, parameter :: iun2 = 63
!       integer :: ixsize, iysize
#endif
      save
!....
      call fdebug ( 'o2fer', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwera = iwera + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wexa(ixy) = wexa(ixy) + sex(ix,iy)
               weya(ixy) = weya(ixy) + sey(ix,iy)
               weza(ixy) = weza(ixy) + sez(ix,iy)
            end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do i = 1, loxypl
               wexa(i) = wexa(i) / iwera * scofe
               weya(i) = weya(i) / iwera * scofe
               weza(i) = weza(i) / iwera * scofe
            end do
!
            if( inst .ne. 0 ) then
               ixy = 0
               do iy = loyps, loype, loypi
                  do ix = loxps, loxpe, loxpi
                     ixy = ixy + 1
                     wexi(ixy) = sex(ix,iy) * scofe
                     weyi(ixy) = sey(ix,iy) * scofe
                     wezi(ixy) = sez(ix,iy) * scofe
                  end do
               end do
            end if
!.
            if( iofer .le. 4 ) then
              if( inst .eq. 0 ) then
                write(iun) sstcur,(wexa(i),weya(i),weza(i),i=1,loxypl)
              else
                write(iun) sstcur,(wexa(i),weya(i),weza(i),i=1,loxypl),&
                                 (wexi(i),weyi(i),wezi(i),i=1,loxypl)
              end if
              flush(iun)
            end if
            if( iofer .ge. 2 ) then
               call o2fdraw3 ( bident, sstcur, ifn, 2, icrsx, icrsy, &
                            wexa, weya, weza, loxpl, loypl, &
                            soxmic, soxp0m, soymic, soyp0m, &
                            'fexr', 'feyr', 'fezr' ) 
               if( inst .ne. 0 ) &
                  call o2fdraw3 ( bident, sstcur, ifn, 2,icrsx,icrsy, &
                            wexi, weyi, wezi, loxpl, loypl, &
                            soxmic, soxp0m, soymic, soyp0m, &
                          'fexr(inst.)', 'feyr(inst.)', 'fezr(inst.)' ) 
            end if
          end if
! #ifdef OHHELP
!           write(iun2) sstcur, oh_sexyz, oh_sdid
!           flush(iun2)
! #endif
!....
         else
            iofer = mod( lofer, 10 )
            icrsx = mod( lofer/100, 100 )
            icrsy = mod( lofer/10000, 100 )
            inst  = lofer / 1000000
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wexa) ) &
                  allocate( wexa(loxypl), weya(loxypl), weza(loxypl) )
               if( inst .ne. 0 ) then
                  if( .not. allocated(wexi) ) &
                    allocate( wexi(loxypl), weyi(loxypl), wezi(loxypl) )
               end if
            end if
!
            if( iofer .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fer', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               chead = 'fer2'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               chead = 'fer3'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
! #ifdef OHHELP
!                ixsize = size( oh_sexyz, 2 )
!                iysize = size( oh_sexyz, 3 )
!                call fntpcnv ( bbifntp, lrank,iun2, bident,'fer', bfile )
!                open( iun2, file=bfile, form='UNFORMATTED' )
!                write(iun2) 'ferd', bident, ixsize, iysize, &
!                            lrank, ldivx, ldivy
!                flush(iun2)
! #endif
            end if
            if( iofer .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fer', bfile )
               call frames_file ( bfile, ifn, iofer )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwera = 0
            do i = 1, loxypl
               wexa(i) = s0o1
               weya(i) = s0o1
               weza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fer', 1 )
!....
      return
      end
