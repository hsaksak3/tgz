!----------------------------------------------------------------------
! debug
!
module debug
#ifndef OHHELP
      integer, parameter :: lsubx = 37
#else
      integer, parameter :: lsubx = 40
#endif
      integer :: ldebug, lsubcn(lsubx)
      real*8 ::  dtotst, dsubst(lsubx), dsubsm(lsubx)
      character :: bsubnm(lsubx)*8
end module debug
