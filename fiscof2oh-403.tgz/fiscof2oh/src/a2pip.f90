!-----------------------------------------------------------------------
! Advance 2D Particle Ion Position ( half step )
!                          /
      subroutine a2pip ( kmode )
!
!   <arguments>
!     kmode : mode 1 = save data
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!-----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use particle
      include "implicit.h"
      integer :: i, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug( 'a2pip',0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL
      if( kmode .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do i = lnois, lnoie
            sxio(i) = sxi(i)
            syio(i) = syi(i)
         end do
      end if
!$OMP DO SCHEDULE(STATIC)
      do i = lnois, lnoie
         sxi(i) = sxi(i) + svxi(i) * s1o2
         syi(i) = syi(i) + svyi(i) * s1o2
      end do
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug( 'a2pip', 1 )
!....
      return
      end
