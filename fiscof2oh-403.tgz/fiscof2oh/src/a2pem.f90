!-----------------------------------------------------------------------
! Advance 2D Particle Electron Momentum
!
      subroutine a2pem
!
!   <arguments>
!    none
!
!   <remarks>
!    none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!-----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use particle
      include "implicit.h"
      integer :: i
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'a2pem', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC)
      do i = lnoes, lnoee
         suxe(i) = suxe(i) + sfxe(i)
         suye(i) = suye(i) + sfye(i)
         suze(i) = suze(i) + sfze(i)
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
#ifdef OHHELP
      end do
#endif
!....
      call fdebug( 'a2pem', 1 )
!....
      return
      end
