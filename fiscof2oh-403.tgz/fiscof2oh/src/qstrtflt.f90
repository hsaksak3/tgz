!-------------------------------------------------------------------
! QSTaRT FLaT profile
!
      subroutine qstrtflt ( kms, kme, fn, fnpm1, knpme, &
                            fpdat1, kcnt, kcntx, kyx, kp, kho,&
                            kpc )
!
!   <arguments>
!     kms   : i  : start mesh number
!     kme   : i  : end mesh number
!     fn    : i  : number density
!     fnpm1 : i  : number of particle per mesh at profile = 1
!     knpme : i  : effective number of particle per mesh
!     fpdat1:  o : structure of particle data type 1
!     kcnt  : io : counter for structure
!     kcntx : i  : size of structure
!     kyx   : i  : y (or x) mesh number
!     kp    : i  : index of profile
!     kho   : i  : hollow flag
!     kpc   : i  : if kpc = -1 then particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 05/12/07
! modified by Sakagami,H. ( NIFS ) 08/02/05 : bug fix for inpm < 1
! modified by Sakagami,H. (NIFS) 21/04/13
!-------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use parameter
      use ptcltype
      include "implicit.h"
      type(ty1_particle) :: fpdat1(kcntx)
      integer :: kpc
      integer :: kms, kme, knpme, kcnt, kcntx, kyx, kp, kho, &
                 inpme, inpm, icnt, i, imesh, iho
      real*8  :: fn, fnpm1, anpm1, apf, adl, ax
      save
!....
      call fdebug ( 'qstrtflt', 0 )
!....
      anpm1 = fnpm1 / dble(2)
      inpme = knpme / dble(2)
      inpm  = anpm1 * fn
      if( inpm .gt. inpme ) inpm = inpme
      if( inpm .lt. 1 ) inpm = 1
      apf = ( anpm1*fn ) / inpm
      adl = 1.0d0 / inpm
!----
      if( kpc .ne. -1 ) then
!+++
      if( kcnt+(kme-kms)*inpm*2 .gt. kcntx ) then
         write(0,*) '### ERROR: overflow in qstrtflt', kcntx
         call s2ext_abort
      end if
!+++
      end if
!----
!....
      icnt = kcnt
      do imesh = kms, kme-1
         if( kho .eq. 1 ) then
            call qstrthol ( kp, imesh, kyx, iho )
            if( iho .ne. 0 ) cycle
         end if
         do i = 1, inpm
            ax = (i-0.5d0)*adl + imesh
#ifdef OHHELP
            oh_pcnt = oh_pcnt + 2
            oh_cyc  = ( oh_pcnt - 1 ) / oh_blkcyc
            oh_rank = mod( oh_cyc, oh_lsize )
            if( oh_rank .ne. lrank ) cycle 
#endif
            kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
            fpdat1(kcnt)%x  = ax
            fpdat1(kcnt)%pf = apf
      end if
!----
            kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
            fpdat1(kcnt)%x  = fpdat1(kcnt-1)%x
            fpdat1(kcnt)%pf = fpdat1(kcnt-1)%pf
      end if
!----
         end do
      end do
!....
      call fdebug ( 'qstrtflt', 1 )
!....
      return
      end
