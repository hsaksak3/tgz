      subroutine gdfxs_init
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_init is here. @@@'
      return
      end
      subroutine gdfxs_term
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_term is here. @@@'
      return
      end
      subroutine gdfxs_bodys
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_bodys is here. @@@'
      return
      end
      subroutine gdfxs_body21
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_body21 is here. @@@'
      return
      end
      subroutine gdfxs_body22
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_body22 is here. @@@'
      return
      end
      subroutine gdfxs_body23
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_body23 is here. @@@'
      return
      end
      subroutine gdfxs_body24
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_body24 is here. @@@'
      return
      end
      subroutine gdfxs_bodye
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_bodye is here. @@@'
      return
      end
