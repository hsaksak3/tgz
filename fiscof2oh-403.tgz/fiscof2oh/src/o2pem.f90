!----------------------------------------------------------------------
! Observe 2D Particle Electron Momentum
!                          /
      subroutine o2pem ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     If change lpmx here, must change in frames.f.
!
!    coded by Sakagami,H. (NIFS) 09/05/29
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: lpmx = 301, lpmx2 = (lpmx-1) / 2 + 1
      integer, parameter :: iun = 26, ifn = 7
      integer :: kflag, i, io, ix, iy ,iz, iopem, ilog, iopeml
      real*8  :: wopemxps(lopemx), wopemxpe(lopemx), &
                 wopemyps(lopemx), wopemype(lopemx), ww
      real*8, allocatable :: apemxyn(:,:,:), apemxzn(:,:,:), &
                             apemyzn(:,:,:), &
                             apemxn(:,:), apemyn(:,:), apemzn(:,:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o2pem', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         do io = 1, iopeml
            do iy = 1, lpmx
               apemxn(iy,io) = s0o1
               apemyn(iy,io) = s0o1
               apemzn(iy,io) = s0o1
               do ix = 1, lpmx
                  apemxyn(ix,iy,io) = s0o1
                  apemyzn(ix,iy,io) = s0o1
                  apemxzn(ix,iy,io) = s0o1
               end do
            end do
         end do
!.
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC), &
!$OMP       REDUCTION(+:apemxn,apemyn,apemzn,apemxyn,apemyzn,apemxzn), &
!$OMP       PRIVATE(io,ix,iy,iz,ww)
         do i = lnoes, lnoee
          do io = 1, iopeml
            if(sxe(i).ge.sopemxps(io).and.sxe(i).le.sopemxpe(io) .and. &
               sye(i).ge.sopemyps(io).and.sye(i).le.sopemype(io)) then
               ww = suxe(i) * scflinv * sopemfct(io)
               ix = sign( abs(ww) + s1o2, ww )
               ix = ix + lpmx2
               ix = max( ix, 1 )
               ix = min( ix, lpmx )
               ww = suye(i) * scflinv * sopemfct(io)
               iy = sign( abs(ww) + s1o2, ww )
               iy = iy + lpmx2
               iy = max( iy, 1 )
               iy = min( iy, lpmx )
               ww = suze(i) * scflinv * sopemfct(io)
               iz = sign( abs(ww) + s1o2, ww )
               iz = iz + lpmx2
               iz = max( iz, 1 )
               iz = min( iz, lpmx )
               apemxn(ix,io)     = apemxn(ix,io) + spfe(i)
               apemyn(iy,io)     = apemyn(iy,io) + spfe(i)
               apemzn(iz,io)     = apemzn(iz,io) + spfe(i)
               apemxyn(ix,iy,io) = apemxyn(ix,iy,io) + spfe(i)
               apemyzn(iy,iz,io) = apemyzn(iy,iz,io) + spfe(i)
               apemxzn(ix,iz,io) = apemxzn(ix,iz,io) + spfe(i)
             end if
           end do
         end do
#ifdef OHHELP
      end do
#endif
!..
         if( iopem .le. 4 ) then
            write(iun)sstcur, ( &
               (apemxn(ix,io),ix=1,lpmx), (apemyn(iy,io),iy=1,lpmx), &
               (apemzn(iz,io),iz=1,lpmx), &
              ((apemxyn(ix,iy,io),ix=1,lpmx),iy=1,lpmx), &
              ((apemyzn(ix,iy,io),ix=1,lpmx),iy=1,lpmx),  &
              ((apemxzn(ix,iy,io),ix=1,lpmx),iy=1,lpmx), io=1,iopeml )
            flush(iun)
         end if
!..
         if( iopem .ge. 2 ) then
            do io = 1, iopeml
               call o2pdraw6 ( bident, sstcur, sminlog, lminlog, &
               ifn, ilog, 3, apemxn(1,io), apemyn(1,io), apemzn(1,io), &
              apemxyn(1,1,io), apemyzn(1,1,io), apemxzn(1,1,io), lpmx, &
 sopemfct(io), wopemxps(io), wopemyps(io), wopemxpe(io), wopemype(io), &
                      'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', 'pem' )
            end do
         end if
!....
      else
         iopem  = mod( lopem, 10 )
         ilog   = mod( lopem/10, 10 )
         iopeml = mod( lopem/100, 10 )
!..
         if( .not. allocated(apemxyn) ) allocate( &
                 apemxyn(lpmx,lpmx,iopeml), apemyzn(lpmx,lpmx,iopeml), &
                 apemxzn(lpmx,lpmx,iopeml), &
                 apemxn(lpmx,iopeml), apemyn(lpmx,iopeml), &
                 apemzn(lpmx,iopeml) )
!..
         do io = 1, iopeml
            if( sopemxps(io) .le. sundef ) then
               sopemxps(io) = lxps
            else
               sopemxps(io) = sopemxps(io) * slmic + loxp0
            end if
            if( sopemxpe(io) .le. sundef ) then
               sopemxpe(io) = lxpe
            else
               sopemxpe(io) = sopemxpe(io) * slmic + loxp0
            end if
            if( sopemyps(io) .le. sundef ) then
               sopemyps(io) = lyps
            else
               sopemyps(io) = sopemyps(io) * slmic + loyp0
            end if
            if( sopemype(io) .le. sundef ) then
               sopemype(io) = lype
            else
               sopemype(io) = sopemype(io) * slmic + loyp0
            end if
            wopemxps(io) = ( sopemxps(io) - loxp0 ) * slmicinv
            wopemxpe(io) = ( sopemxpe(io) - loxp0 ) * slmicinv
            wopemyps(io) = ( sopemyps(io) - loyp0 ) * slmicinv
            wopemype(io) = ( sopemype(io) - loyp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopem[xy]p[se] = ', io, &
                wopemxps(io), wopemyps(io), wopemxpe(io), wopemype(io)
         end do
         if( iopem .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pem', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
            write(iun) 'pem2', bident, lpmx, iopeml, (sopemfct(io), &
     wopemxps(io),wopemyps(io),wopemxpe(io),wopemype(io),io=1,iopeml)
#else
            write(iun) 'pem3', bident, lpmx, iopeml, (sopemfct(io), &
     wopemxps(io),wopemyps(io),wopemxpe(io),wopemype(io),io=1,iopeml),&
     lrank, ldivx, ldivy
#endif
            flush(iun)
         end if
         if( iopem .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pem', bfile )
            call frames_file ( bfile, ifn, iopem )
         end if
!....
      end if
!....
      call fdebug ( 'o2pem', 1 )
!....
      return
      end
