!-----------------------------------------------------------------------
! Boundary condition 2D Field magnetic(B) - TM
!                           /
      subroutine b2fbtm ( kmode )
!
!   <arguments>
!     kmode : 0 = for all conditions except PML
!           : 1 = for all conditions
!
!   <remarks>
!     none
!
! original coded by Hata,M. (Nagoya Univ.) 11/06/24
!    coded by Sakagami,H. (NIFS) 11/07/27
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use field
      include "implicit.h"
      integer :: ix, iy, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'b2fbtm', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL
!....
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxlm1,iy) = sbz(lssxum1,iy)
            sbz(lssxl,iy) = sbz(lssxu,iy)
         end do
!..
      else if( lexlf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxlm1,iy) = s0o1
         end do
!..
      else if( lexlf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxlm1,iy) = sbz(lssxl,iy)*scb2 - sey(lssxlm1,iy)*sce2
         end do
!..
      else if( lexlf .eq. 4 ) then
         if( kmode .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblyl, lblyu
               do ix = lblxl, lssxlm1
                  sbzxxl(ix,iy) = scaxl(ix) * sbzxxl(ix,iy) - &
                      scbbtmxl(ix)*sey(ix,iy)+sccbtmxl(ix)*sey(ix-1,iy)
               end do
            end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyl, lssyup1
               do ix = lblxl, lssxlm1
                  sbzyxl(ix,iy) = sbzyxl(ix,iy) + &
                                ( sex(ix,iy) - sex(ix,iy-1) )
                  sbz(ix,iy)  = sbzxxl(ix,iy) + sbzyxl(ix,iy)
               end do
            end do
         end if
!.
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lblxlm1,iy) = sbz(lblxl,iy)*scb2 - sey(lblxlm1,iy)*sce2
         end do
      end if
!...
      if( lexuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxup2,iy) = sbz(lssxlp2,iy)
            sbz(lssxup1,iy) = sbz(lssxlp1,iy)
         end do
!..
      else if( lexuf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxup2,iy) = s0o1
         end do
!..
      else if( lexuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lssxup2,iy) = sbz(lssxup1,iy)*scb2 + sey(lssxup1,iy)*sce2
         end do
!..
      else if( lexuf .eq. 4 ) then
         if( kmode .ne. 0 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lblyl, lblyu
               do ix = lssxup2, lblxu
                  sbzxxu(ix,iy) = scaxu(ix) * sbzxxu(ix,iy) - &
                      scbbtmxu(ix)*sey(ix,iy)+sccbtmxu(ix)*sey(ix-1,iy)
               end do
            end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyl, lssyup1
               do ix = lssxup2, lblxu
                  sbzyxu(ix,iy) = sbzyxu(ix,iy) + &
                                ( sex(ix,iy) - sex(ix,iy-1) )
                  sbz(ix,iy)  = sbzxxu(ix,iy) + sbzyxu(ix,iy)
               end do
            end do
         end if
!.
!$OMP DO SCHEDULE(STATIC)
         do iy = lssyl, lssyup1
            sbz(lblxup1,iy) = sbz(lblxu,iy)*scb2 + sey(lblxu,iy)*sce2
         end do
      end if
!...
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssylm1) = sbz(ix,lssyum1)
            sbz(ix,lssyl) = sbz(ix,lssyu)
         end do
!..
      else if( leylf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssylm1) = s0o1
         end do
!..
      else if( leylf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssylm1) = sbz(ix,lssyl)*scb2 + sex(ix,lssylm1)*sce2
         end do
!..
      else if( leylf .eq. 4 ) then
         if( kmode .ne. 0 ) then
            do iy = lblyl, lssylm1
!$OMP DO SCHEDULE(STATIC)
               do ix = lblxl, lblxu
                  sbzyyl(ix,iy) = scayl(iy) * sbzyyl(ix,iy) + &
                      scbbtmyl(iy)*sex(ix,iy)-sccbtmyl(iy)*sex(ix,iy-1)
               end do
!.
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxl, lssxup1
                  sbzxyl(ix,iy) = sbzxyl(ix,iy) - &
                                ( sey(ix,iy) - sey(ix-1,iy) )
                  sbz(ix,iy)  = sbzxyl(ix,iy) + sbzyyl(ix,iy)
               end do
!.
               if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
                  do ix = lblxl, lssxlm1
                     sbz(ix,iy)  = sbzxxl(ix,iy) + sbzyyl(ix,iy)
                  end do
               end if
!.
               if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
                  do ix = lssxup2, lblxu
                     sbz(ix,iy)  = sbzxxu(ix,iy) + sbzyyl(ix,iy)
                  end do
               end if
            end do
         end if
!.
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lblylm1) = sbz(ix,lblyl)*scb2 + sex(ix,lblylm1)*sce2
         end do
      end if
!...
      if( leyuf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssyup2) = sbz(ix,lssylp2)
            sbz(ix,lssyup1) = sbz(ix,lssylp1)
         end do
!..
      else if( leyuf .eq. 2 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssyup2) = s0o1
         end do
!..
      else if( leyuf .eq. 3 ) then
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lssyup2) = sbz(ix,lssyup1)*scb2 - sex(ix,lssyup1)*sce2
         end do
!..
      else if( leyuf .eq. 4 ) then
         if( kmode .ne. 0 ) then
            do iy = lssyup2, lblyu
!$OMP DO SCHEDULE(STATIC)
               do ix = lblxl, lblxu
                  sbzyyu(ix,iy) = scayu(iy) * sbzyyu(ix,iy) + &
                      scbbtmyu(iy)*sex(ix,iy)-sccbtmyu(iy)*sex(ix,iy-1)
               end do
!.
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxl, lssxup1
                  sbzxyu(ix,iy) = sbzxyu(ix,iy) - &
                                ( sey(ix,iy) - sey(ix-1,iy) )
                  sbz(ix,iy)  = sbzxyu(ix,iy) + sbzyyu(ix,iy)
               end do
!.
               if( lexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
                  do ix = lblxl, lssxlm1
                     sbz(ix,iy)  = sbzxxl(ix,iy) + sbzyyu(ix,iy)
                  end do
               end if
!.
               if( lexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC)
                  do ix = lssxup2, lblxu
                     sbz(ix,iy)  = sbzxxu(ix,iy) + sbzyyu(ix,iy)
                  end do
               end if
            end do
         end if
!.
!$OMP DO SCHEDULE(STATIC)
         do ix = lblxl, lblxu
            sbz(ix,lblyup1) = sbz(ix,lblyu)*scb2 - sex(ix,lblyu)*sce2
         end do
      end if
!....
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'b2fbtm', 1 )
!....
      return
      end
