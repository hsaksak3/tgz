!----------------------------------------------------------------------
! observe
!
module observe
      use parameter
      integer :: &
         lstcur, lstend, lotnxt, &
         loxps, loxpe, loxpi, loxpl, loxp0, &
         loyps, loype, loypi, loypl, loyp0, &
         loxypl, &
         loeng, loenga, &
         lopem, lopee, lopim, lopie, &
         lofde, lofdea, lofdi, lofdia, lofdc, lofdca, &
         lofte, loftea, lofede, lofedi, &
         lofje, lofjea, lofji, lofjia, lofjt, lofjta, &
         lofea, lofeaa, lofer, lofera, lofba, lofbaa, lofbr, lofbra, &
         lopesap, lopesapa, lopisap, lopisapa, lopeph, lopiph, &
         lofek, lofew
      real*8 :: &
         soxps, soxpe, soxmic, soxp0m, soyps, soype, soymic, soyp0m, &
         sstcur, sstend, sotstr, sotend, sotint, sotnxt, &
         sofjehot, &
         sofekxps(lofekx), sofekxpe(lofekx), &
         sofekyps(lofekx), sofekype(lofekx), sofekmax, &
         sofewxp(lofewx), sofewyp(lofewx), &
         sopemxps(lopemx), sopemxpe(lopemx), &
         sopemyps(lopemx), sopemype(lopemx), sopemfct(lopemx), &
         sopeexps(lopeex), sopeexpe(lopeex), &
         sopeeyps(lopeex), sopeeype(lopeex), sopeefct(lopeex), &
         sopimxps(lopimx), sopimxpe(lopimx), &
         sopimyps(lopimx), sopimype(lopimx), sopimfct(lopimx,lionspx), &
         sopiexps(lopiex), sopiexpe(lopiex), &
         sopieyps(lopiex), sopieype(lopiex), sopiefct(lopiex,lionspx), &
         sopephxps(lopephx), sopephxpe(lopephx), &
         sopephyps(lopephx), sopephype(lopephx), &
         sopephuxm(lopephx), sopephuxx(lopephx), &
         sopiphxps(lopiphx), sopiphxpe(lopiphx), &
         sopiphyps(lopiphx), sopiphype(lopiphx), &
         sopiphuxm(lopiphx), sopiphuxx(lopiphx)
      character :: bbifntp*64, bfrfntp*64
end module observe
