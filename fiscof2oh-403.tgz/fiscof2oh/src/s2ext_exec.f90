!----------------------------------------------------------------------
! Set 2D EXTernal system EXECution
!                               /
      subroutine s2ext_exec ( kflag )
!
!   <arguments>
!     kflag :  1 = oh3_transbound
!             11 = oh3_transbound for init
!             21 = oh3_transbound for restart
!              2 = oh3_exchange_borders e_field
!              3 = oh3_exchange_borders b_field
!              4 = oh3_exchange_borders j_field
!              5 = oh3_allreduce_field j_field
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!---------------------------------------------------------------------
#ifdef OHHELP
      use parameter
      use control
      use constant
      use field
      use ptcltype
      use particle
      use observe
      use oh_param
      include "implicit.h"
      include "mpif.h"
      integer :: oh3_transbound
      integer :: kflag, iflag, imode, io, ipc, isc
      save
#endif
!....
      call fdebug ( 's2ext_exec', 0 )
!....
#ifdef OHHELP
      iflag = mod( kflag, 10 )
      imode = kflag / 10
!...
      select case( iflag )
!...oh3_transbound
      case( 1 )
        select case( imode )
!! init
        case( 1 )
          call s2ext_param( 3, 1 )
!! restart
        case( 2 )
          oh_nphgram = 0
          oh_nphgram(oh_sdid(1)+1,1,1) = oh_lnoe(1)
          if( oh_sdid(2) .ge. 0 ) &
             oh_nphgram(oh_sdid(2)+1,1,1) = oh_lnoe(2)
          do io = 1, lionspl 
            oh_nphgram(oh_sdid(1)+1,io+1,1) = oh_lionidl(io,1)
            if( oh_sdid(2) .ge. 0 ) &
               oh_nphgram(oh_sdid(2)+1,io+1,1) = oh_lionidl(io,2)
          end do
        end select
!.
        oh_currmode = oh3_transbound(oh_currmode,0)
!.
        call s2ext_conv ( 3 )
        call s2ext_param( 4, 0 )
!
        if( oh_currmode .eq. -1 ) then
          call oh3_bcast_field(oh_sexyz(1,2,2,1),oh_sexyz(1,2,2,2),FE)
          call oh3_bcast_field(oh_sbxyz(1,2,2,1),oh_sbxyz(1,2,2,2),FB)
          call s2ext_conv ( 1 )
          call s2ext_conv ( 2 )
!                                            * broadcast PML variables *
          if( lbxlf .eq. 4 ) then
             ipc = 0
             isc = 0
             if( oh_lexlf(1) .eq. 4 ) ipc = oh_lebpmlxl
             if( oh_sdid(2).ge.0.and.oh_lexlf(2).eq.4 ) isc=oh_lebpmlxl
             call oh1_broadcast( &
                oh_sebpmlxl(1,lblxl,oh_alosizes(1,2,FB),1), &
                oh_sebpmlxl(1,lblxl,oh_alosizes(1,2,FB),2), &
                ipc, isc, MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
          end if
          if( lbxuf .eq. 4 ) then
             ipc = 0
             isc = 0 
             if( oh_lexuf(1) .eq. 4 ) ipc = oh_lebpmlxu
             if( oh_sdid(2).ge.0.and.oh_lexuf(2).eq.4 ) isc=oh_lebpmlxu
             call oh1_broadcast( &
                oh_sebpmlxu(1,lssxup2,oh_alosizes(1,2,FB),1), &
                oh_sebpmlxu(1,lssxup2,oh_alosizes(1,2,FB),2), &
                ipc, isc, MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
          end if
          if( lbylf .eq. 4 ) then
             ipc = 0
             isc = 0 
             if( oh_leylf(1) .eq. 4 ) ipc = oh_lebpmlyl
             if( oh_sdid(2).ge.0.and.oh_leylf(2).eq.4 ) isc=oh_lebpmlyl
             call oh1_broadcast( &
                oh_sebpmlyl(1,oh_alosizes(1,1,FB),lblyl,1), &
                oh_sebpmlyl(1,oh_alosizes(1,1,FB),lblyl,2), &
                ipc, isc, MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
          end if
          if( lbyuf .eq. 4 ) then
             ipc = 0
             isc = 0 
             if( oh_leyuf(1) .eq. 4 ) ipc = oh_lebpmlyu
             if( oh_sdid(2).ge.0.and.oh_leyuf(2).eq.4 ) isc=oh_lebpmlyu
             call oh1_broadcast( &
                oh_sebpmlyu(1,oh_alosizes(1,1,FB),lssyup2,1), &
                oh_sebpmlyu(1,oh_alosizes(1,1,FB),lssyup2,2), &
                ipc, isc, MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
          end if
!
          write(0,*) '##### transbound & reassign', lstcur, oh_sdid
          oh_currmode = 1
        end if
!... oh3_exchange_borders e_field
      case( 2 )
        call oh3_exchange_borders(oh_sexyz(1,2,2,1),oh_sexyz(1,2,2,2), &
                                  FE,oh_currmode)
!... oh3_exchange_borders b_field
      case( 3 )
        call oh3_exchange_borders(oh_sbxyz(1,2,2,1),oh_sbxyz(1,2,2,2), &
                                  FB,oh_currmode)
!... oh3_exchange_borders j_field
      case( 4 )
        call oh3_exchange_borders(oh_sjxyzt(1,2,2,1), &
                                  oh_sjxyzt(1,2,2,2),FJT,oh_currmode)
        call s2ext_exec4
!... oh3_allreduce_field j_field
      case( 5 )
        if( oh_currmode .gt. 0 ) &
          call oh3_allreduce_field(oh_sjxyzt(1,2,2,1), &
                                   oh_sjxyzt(1,2,2,2),FJT)
!... debug for current
      case( 6 )
        oh_ixs = oh_alosizes(2,1,FJT)-oh_alosizes(1,1,FJT)+1
        oh_iys = oh_alosizes(2,2,FJT)-oh_alosizes(1,2,FJT)+1
        call fntpcnv ( bbifntp, lrank,20, bident,'dum', bfile ) 
        open( 20, file=bfile, form='UNFORMATTED' )
        write(20) 'dum2', bident, oh_ixs*oh_iys, oh_ixs, oh_iys, &
                       s1o1, dble(7-oh_sdoms(1,1,oh_sdid(1)+1)), &
                       s1o1, dble(7-oh_sdoms(1,2,oh_sdid(1)+1))
        oh_sjxyzt(:,:,:,1) = 0.0d0
        oh_sjxyzt(:,oh_alosizes(1,1,OJE):oh_alosizes(2,1,OJE), &
            oh_alosizes(1,2,OJE):oh_alosizes(2,2,OJE),1) = lrank + 1
        write(20) 0.0d0, oh_sjxyzt(1,:,:,1)
        oh_sjxyzt(:,:,:,1) = lrank + 1
        oh_sjxyzt(:,:,:,2) = lrank + 101
        write(20) 1.0d0, oh_sjxyzt(1,:,:,1)
        if( oh_currmode .gt. 0 ) &
          call oh3_allreduce_field(oh_sjxyzt(1,2,2,1), &
                                   oh_sjxyzt(1,2,2,2),FJT)
        write(20) 2.0d0, oh_sjxyzt(1,:,:,1)
        call oh3_exchange_borders(oh_sjxyzt(1,2,2,1), &
                                  oh_sjxyzt(1,2,2,2),FJT,oh_currmode)
        write(20) 3.0d0, oh_sjxyzt(1,:,:,1)
        call s2ext_exec4
        write(20) 4.0d0, oh_sjxyzt(1,:,:,1)
!
        oh_sjxyzt(:,:,:,1) = 0.0d0
        oh_ixs = oh_alosizes(1,1,OJE) + 3
        oh_ixe = oh_alosizes(2,1,OJE) - 2
        oh_iys = oh_alosizes(1,2,OJE) + 3
        oh_iye = oh_alosizes(2,2,OJE) - 2
        oh_sjxyzt(:,oh_ixs:oh_ixe, &
                    oh_iys:oh_iye,1) = 4.0d0
        oh_sjxyzt(:,oh_alosizes(1,1,FJT):oh_ixs, &
                    oh_iys:oh_iye,1) = 2.0d0
        oh_sjxyzt(:,oh_ixe+1:oh_alosizes(2,1,FJT), &
                    oh_iys:oh_iye,1) = 2.0d0
        oh_sjxyzt(:,oh_ixs:oh_ixe, &
                    oh_alosizes(1,2,FJT):oh_iys,1) = 2.0d0
        oh_sjxyzt(:,oh_ixs:oh_ixe, &
                    oh_iye+1:oh_alosizes(2,2,FJT),1) = 2.0d0
        oh_sjxyzt(:,oh_alosizes(1,1,FJT):oh_ixs, &
                    oh_alosizes(1,2,FJT):oh_iys,1) = 1.0d0
        oh_sjxyzt(:,oh_ixe+1:oh_alosizes(2,1,FJT), &
                    oh_alosizes(1,2,FJT):oh_iys,1) = 1.0d0
        oh_sjxyzt(:,oh_alosizes(1,1,FJT):oh_ixs, &
                    oh_iye+1:oh_alosizes(2,2,FJT),1) = 1.0d0
        oh_sjxyzt(:,oh_ixe+1:oh_alosizes(2,1,FJT), &
                    oh_iye+1:oh_alosizes(2,2,FJT),1) = 1.0d0
        write(20) 5.0d0, oh_sjxyzt(1,:,:,1)
        call oh3_exchange_borders(oh_sjxyzt(1,2,2,1), &
                                  oh_sjxyzt(1,2,2,2),FJT,oh_currmode)
        write(20) 6.0d0, oh_sjxyzt(1,:,:,1)
        call s2ext_exec4
        write(20) 7.0d0, oh_sjxyzt(1,:,:,1)
!
        close(20)
        call s2ext_term
        stop
      case( 7 )
        oh_ixs = oh_alosizes(2,1,FJT)-oh_alosizes(1,1,FJT)+1
        oh_iys = oh_alosizes(2,2,FJT)-oh_alosizes(1,2,FJT)+1
        call fntpcnv ( bbifntp, lrank,20, bident,'dum', bfile ) 
        open( 20, file=bfile, form='UNFORMATTED' )
        write(20) 'dum2', bident, oh_ixs*oh_iys, oh_ixs, oh_iys, &
                       s1o1, dble(7-oh_sdoms(1,1,oh_sdid(1)+1)), &
                       s1o1, dble(7-oh_sdoms(1,2,oh_sdid(1)+1))
        write(20) 0.0d0, oh_sjxyzt(1,:,:,1)
        if( oh_currmode .gt. 0 ) &
          call oh3_allreduce_field(oh_sjxyzt(1,2,2,1), &
                                   oh_sjxyzt(1,2,2,2),FJT)
        write(20) 2.0d0, oh_sjxyzt(1,:,:,1)
        call oh3_exchange_borders(oh_sjxyzt(1,2,2,1), &
                                  oh_sjxyzt(1,2,2,2),FJT,oh_currmode)
        write(20) 3.0d0, oh_sjxyzt(1,:,:,1)
        call s2ext_exec4
        write(20) 4.0d0, oh_sjxyzt(1,:,:,1)
        close(20)
        call s2ext_term
        stop
      end select
#endif
!....
      call fdebug ( 's2ext_exec', 1 )
!....
      return
      end
!----------------------------------------------------------------------
!
      subroutine s2ext_exec4
!
!   <arguments>
!
!   <remarks>
!
! original coded by Nii,D. (Osaka Univ.) 14/02/10
!----------------------------------------------------------------------
#ifdef OHHELP
      use field
      use oh_param
      include "implicit.h"
      integer :: iflag, iswitch, ips
      integer :: xs, xe, xl, ys, ye, yl, ik, ix, iy
!...
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle
!..
      do iflag = 1, 4
        iswitch = 0
! y lower
        if( iflag .eq. 1 .and. oh_leylf(ips) .eq. 0 ) then
          iswitch = 1
          xs = oh_alosizes(1,1,FJT)
          xe = oh_alosizes(1,1,FJT)
          xl = oh_alosizes(2,1,FJT) - oh_alosizes(1,1,FJT) + 1
          ys = oh_alosizes(1,2,FJT)
          ye = oh_alosizes(1,2,FJT) + oh_ctypes(3,2,1,FJT) + 1
          yl = oh_ctypes(3,2,1,FJT)
! y upper
        else if( iflag .eq. 2 .and. oh_leyuf(ips) .eq. 0 ) then
          iswitch = 2
          xs = oh_alosizes(1,1,FJT)
          xe = oh_alosizes(1,1,FJT)
          xl = oh_alosizes(2,1,FJT) - oh_alosizes(1,1,FJT) + 1
          ys = oh_alosizes(2,2,FJT) - oh_ctypes(3,1,1,FJT) + 1
          ye = oh_alosizes(2,2,FJT) - 2*oh_ctypes(3,1,1,FJT) + 1 - 1
          yl = oh_ctypes(3,1,1,FJT)
! x lower
        else if( iflag .eq. 3 .and. oh_lexlf(ips) .eq. 0 ) then
          iswitch = 3
          xs = oh_alosizes(1,1,FJT)
          xe = oh_alosizes(1,1,FJT) + oh_ctypes(3,2,1,FJT) + 1
          xl = oh_ctypes(3,2,1,FJT)
          ys = oh_alosizes(1,2,FJT) + oh_ctypes(3,2,1,FJT)
          ye = oh_alosizes(1,2,FJT) + oh_ctypes(3,2,1,FJT)
          yl = oh_alosizes(2,2,FJT) - oh_alosizes(1,2,FJT) - &
               oh_ctypes(3,1,1,FJT) - oh_ctypes(3,2,1,FJT) + 1
! x upper
        else if( iflag .eq. 4 .and. oh_lexuf(ips) .eq. 0 ) then
          iswitch = 4
          xs = oh_alosizes(2,1,FJT) - oh_ctypes(3,1,1,FJT) + 1
          xe = oh_alosizes(2,1,FJT) - 2*oh_ctypes(3,1,1,FJT) + 1 - 1
          xl = oh_ctypes(3,1,1,FJT)
          ys = oh_alosizes(1,2,FJT) + oh_ctypes(3,2,1,FJT)
          ye = oh_alosizes(1,2,FJT) + oh_ctypes(3,2,1,FJT)
          yl = oh_alosizes(2,2,FJT) - oh_alosizes(1,2,FJT) - &
               oh_ctypes(3,1,1,FJT) - oh_ctypes(3,2,1,FJT) + 1
        end if
!.
        if( iswitch .ne. 0 ) then
          do iy = 0, yl-1
            do ix = 0, xl-1
              do ik = 1, 3
                oh_sjxyzt(ik,xe+ix,ye+iy,ips) = &
                   oh_sjxyzt(ik,xe+ix,ye+iy,ips) + &
                   oh_sjxyzt(ik,xs+ix,ys+iy,ips)
              end do
            end do
          end do
        end if
!.
      end do
!..
      end do
!...
#endif
!....
      return
      end
