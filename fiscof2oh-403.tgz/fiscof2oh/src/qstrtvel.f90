!-------------------------------------------------------------------
! QSTaRT for VELocity
!
      subroutine qstrtvel ( fut, fpdat1, ks1, ke, kl )
!
!   <arguments>
!     fut   : i  : thermal relativistic velocity
!     fpdat1:  o : structure of particle data type 1
!     ks1   : i  : start index of structure - 1
!     ke    : i  : end index of structure
!     kl    : i  : size of structure
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 10/07/15
!----------------------------------------------------------------------
      use constant
      use ptcltype
      include "implicit.h"
      integer, parameter :: lqn = 120, lqn2 = lqn*2, lvn = 12
      type(ty1_particle) :: fpdat1(kl)
      integer :: ks1, ke, kl, irvv(lqn2), idivs(2), idive(2), &
                 inum2, icnt, idiv, imod, iadd, ilak, iqn, i, ii, iii, &
                 icnt0, iv
      real*8  :: fut
      real*8  :: wuu(lqn2), wran(lqn2), wux(lvn), wuy(lvn), wuz(lvn)
      save
!....
      call fdebug ( 'qstrtvel', 0 )
!....
      inum2 = ( ke - ks1 ) / 2
      icnt = ks1
!.
      idiv = inum2 / lqn
      if( idiv .eq. 0 ) then
!++++
         write(0,*) '### ERROR:Number of particles is too less.', inum2
         call s2ext_abort
!++++
      else
         imod = inum2 - lqn*idiv
         iadd = imod / idiv
         ilak = imod - iadd*idiv
         idivs(1) = 1
         idive(1) = idiv-ilak
         idivs(2) = idive(1)+1
         idive(2) = idiv
         iqn = lqn + iadd
      end if
!....
      do iii = 1, 2
         call qsmaxw3 ( wuu, fut, iqn )
         idiv = iqn / lvn
         imod = iqn - lvn*idiv
         do ii = idivs(iii), idive(iii)
            icnt0 = icnt
            do i = 1, idiv
               call qstrtv12 ( wux, wuy, wuz )
!rand          call qstrtvrand ( wux, wuy, wuz, lvn )
               do iv = 1, lvn
                  icnt = icnt + 1
                  fpdat1(icnt)%ux = wux(iv)
                  fpdat1(icnt)%uy = wuy(iv)
                  fpdat1(icnt)%uz = wuz(iv)
                  icnt = icnt + 1
                  fpdat1(icnt)%ux = -wux(iv)
                  fpdat1(icnt)%uy = -wuy(iv)
                  fpdat1(icnt)%uz = -wuz(iv)
               end do
            end do
            if( imod .gt. 0 ) then
               call qstrtvrand ( wux, wuy, wuz, imod )
               do i = 1, imod
                  icnt = icnt + 1
                  fpdat1(icnt)%ux = wux(i)
                  fpdat1(icnt)%uy = wuy(i)
                  fpdat1(icnt)%uz = wuz(i)
                  icnt = icnt + 1
                  fpdat1(icnt)%ux = -wux(i)
                  fpdat1(icnt)%uy = -wuy(i)
                  fpdat1(icnt)%uz = -wuz(i)
               end do
            end if
            do i = 1, iqn
               irvv(i) = i
            end do
            call mt_drand3 ( wran, iqn )
            call qssorti ( wran, irvv, iqn )
            icnt = icnt0
            do i = 1, iqn
               icnt = icnt + 1
               fpdat1(icnt)%ux = fpdat1(icnt)%ux * wuu(irvv(i))
               fpdat1(icnt)%uy = fpdat1(icnt)%uy * wuu(irvv(i))
               fpdat1(icnt)%uz = fpdat1(icnt)%uz * wuu(irvv(i))
               icnt = icnt + 1
               fpdat1(icnt)%ux = fpdat1(icnt)%ux * wuu(irvv(i))
               fpdat1(icnt)%uy = fpdat1(icnt)%uy * wuu(irvv(i))
               fpdat1(icnt)%uz = fpdat1(icnt)%uz * wuu(irvv(i))
            end do
         end do
         iqn = iqn + 1
      end do
!++++
      if( icnt .ne. ke ) then
         write(0,*) '### ERROR:Particle number mismatch in qstrtvel.', &
                    icnt, ke
         call s2ext_abort
      end if
!++++
!....
      call fdebug ( 'qstrtvel', 1 )
!....
      return
      end
