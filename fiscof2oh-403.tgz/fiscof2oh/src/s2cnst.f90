!----------------------------------------------------------------------
! Set 2D CoNSTants
!
      subroutine s2cnst
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/15
!----------------------------------------------------------------------
      use constant
      use laserprf
      include "implicit.h"
      integer :: i
      save
!....
      call fdebug ( 's2cnst', 0 )
!....
      scr1 = sdelt**2 / lnepm
!.
      sce2 = s2o1 / ( scfl + scfl**2 )
      sce3 = - ( s1o1 - scfl ) / ( s1o1 + scfl )
!.
      scb1 = scfl**2
      scb2 = - ( s1o1 - scfl ) / ( s1o1 + scfl )
      scb3 = ( s2o1 * scfl ) / ( s1o1 + scfl )
!.
      scj1 = - scr1
!.
      scg1 = scflinv**2
!.
      scoee = s2o1 * scr**2
      scoei = s2o1 * scr**2 / smasr
      scoef = s1o1 / ( scr1 * sgrid**2 * sdelt**2 )
      scoeb = scr**2 / scr1
      scofe = s1o1 / ( sqrt( sncinv ) * scfl * sdelt )
      scofe2 = s1o1 / ( sncinv*scfl**2*sdelt**2 )*1.368165d-2*s2o1
!     scofb = s1o1 / ( sqrt( sncinv ) *  sdelt )
      scofb = s1o1 / ( sqrt( sncinv ) *  sdelt * slramm ) * 107.096d0
      scoft = 0.510998903d0
!     scofp = s1o1 / ( sgrid**2 * sdelt**2 )
      scofp = s2pi**2 * 2.82395876d13 / ( slramm**2 * 1.0d-12 ) * &
              1.60217646d-19 * 1.0d6 * 1.0d-14
!..
      scofe2h = scofe2 * s1o2
      scofb2 = scofb ** 2
      scofb2h = scofb2 * s1o2
!...
      slinjy = s2o1*lnepm*scfl*scr*sgrid*slomg*sqrt(slpwr/1.368165d18)
      do i = 1, llsrbn
         slinea(i) = sla(i) * scfl * sdelt * sbemomg(i) * (scfl*s2o1)
         slinba(i) = sla(i) * sdelt * sbemomg(i) * (scfl*s2o1)
      end do
!...
      call mt_srand ( lrinit )
!....
      call fdebug ( 's2cnst', 1 )
!....
      return
      end
