!----------------------------------------------------------------------
! Set 2D RESTart file i/o
!                           /      /
      subroutine s2rest ( kflag, kunit )
!
!   <arguments>
!     kflag : read = 0, write = 1
!     kunit : Fortran unit#
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/06/12
! modified by Sakagami,H. (NIFS) 21/04/12
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use parameter
      use constant
      use control
      use observe
      use profile
      use particle
      use field
      use laserprf
      use fpprm
      include "implicit.h"
      integer :: kflag, kunit, issx, issy, i, io, icll, &
                 iclflge, iclflgia, idivx, idivy, iloadbf, &
                 ipmlxl, ipmlxu, ipmlyl, ipmlyu
      character cident*16, cvers*10, cversr*10
#ifndef OHHELP
      data cvers / 'fi2v3r02  ' /
#else
      integer :: ips, irs, ire
      data cvers / 'fi2ohv3r03' /
#endif
      save
!....
      call fdebug ( 's2rest', 0 )
!....
      if( kflag .eq. 0 ) then
         call fntpcnv ( brestfntp, lrank,kunit, bident,'rest', bfile )
         open( kunit, file=bfile, form='UNFORMATTED', status='OLD' )
         read( kunit ) cversr, cident
         if( cversr .ne. cvers ) then
            write(0,*) '### ERROR: my version=', cvers, &
                      ', restart file version=', cversr
            call s2ext_abort
         end if
         read( kunit ) &
            issx, issy, sstcur, lstcur, lopfeedc, lopfiedc, &
            lxps, lxpe, lxp0, loxp0, lyps, lype, lyp0, loyp0, &
            lnoe, lnoes, lnoee, lnoi, lnois, lnoie, lionspl, &
            idivx, idivy, iloadbf, ipmlxl, ipmlxu, ipmlyl, ipmlyu
         if( issx .ne. lssx .or. issy .ne. lssy ) then
            write(0,*) '### ERROR: system size mismatch', issx, issy
            call s2ext_abort
         end if
         if( ldivx .ne. idivx .or. ldivy .ne. idivy ) then
            write(0,*) '### ERROR: division number mismatch',idivx,idivy
            call s2ext_abort
         endif
         if( ipmlxl .ne. lpmlxl .or. ipmlxu .ne. lpmlxu .or. &
             ipmlyl .ne. lpmlyl .or. ipmlyu .ne. lpmlyu ) then
            write(0,*) '### ERROR: PML size mismatch', &
                                         ipmlxl, ipmlxu, ipmlyl, ipmlyu
            call s2ext_abort
         end if
#ifdef OHHELP
         read( kunit ) oh_glnoe, oh_glnoi, oh_sdid, oh_pbase, oh_totalp
         lnoie = oh_pbase(3)
         lnoe  = oh_pbase(2)
         lnoi  = oh_pbase(3) - oh_pbase(2)
#endif
         if( lnoie .gt. lnox ) then
            write(0,*) '### ERROR: particle overflow', lnoe, lnoi
            call s2ext_abort
         end if
         write(6,*) '@@@ RESTART: sstcur=', sstcur, ', cident=', cident
         if( lloadbf .ne. iloadbf ) then
            write(0,*) '### WARNING: lloadbf changed', lloadbf,iloadbf
         endif
         read( kunit ) &
            llsrbn,llsrty,llinx,lliny,llxps,llxpe,lltend,lltcur,lbemty,&
            lbemix, slpwr, slramm, slomg, slram, &
            slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
            sbempw, sbemwl, sbemle, sbemwd, sbemtr, sbemmn, sbemfi, &
            sbemal, sbemxf, sbemyf, sbeman, sbemph, sbemdl, &
            sbemanr, sbemomg, sla, slinea, slinba, slinjy
#ifndef OHHELP
         read( kunit ) &
            (spdat1(i),i=lnoes,lnoee), (spdat2(i),i=lnoes,lnoee), &
             spfen, spfex, spnoe
         if( lnoi .gt. 0 ) then
           read( kunit ) &
              (spdat1(i),i=lnois,lnoie), (spdat2(i),i=lnois,lnoie), &
              (lionids(i),i=1,lionspl), (lionide(i),i=1,lionspl), &
              (lionidl(i),i=1,lionspl), (spfin(i),i=1,lionspl), &
              (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
              (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
              (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
              (sionmm(i),i=1,lionspl), &
               spnoit
         end if
#else
         call s2ext_conv( 3 )
!
         read( kunit ) spfen, spfex, spnoe
         ire = 0
         do ips = 1, 2
           if( oh_sdid(ips) .lt. 0 ) cycle 
           irs = ire + 1
           ire = irs + oh_lnoe(ips) - 1
           read( kunit ) (spdat1(i),i=irs,ire), (spdat2(i),i=irs,ire)
         end do
         if( oh_glnoi .gt. 0 ) then
           read( kunit ) &
              (spfin(i),i=1,lionspl), &
              (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
              (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
              (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
              (sionmm(i),i=1,lionspl), spnoit
           do io = 1, lionspl
             do ips = 1, 2
               if( oh_sdid(ips) .lt. 0 ) cycle 
               irs = ire + 1
               ire = irs + oh_lionidl(io,ips) - 1
               read( kunit ) (spdat1(i),i=irs,ire),(spdat2(i),i=irs,ire)
             end do
           end do
         end if
#endif
#ifndef OHHELP
         read( kunit ) &
            lcfde, lcfdi, sde, sde0, sdi, sebxy, sez, sbz, sjxyzt, &
            sdezdy, sdezdx, sdeyxdxy, sextbx, sextby, sextbz, &
            sjxe, sjxi, sjye, sjyi, sjze, sjzi
         read( kunit ) &
            sezxxl, sezyxl, sbzxxl, sbzyxl, &
            sezxxu, sezyxu, sbzxxu, sbzyxu, &
            sezxyl, sezyyl, sbzxyl, sbzyyl, &
            sezxyu, sezyyu, sbzxyu, sbzyyu
#else
         read( kunit ) &
            lcfde, lcfdi, oh_sde, sde0, sdi, oh_sexyz, oh_sbxyz, &
            oh_sjxyzt, oh_sdezdy, oh_sdezdx, oh_sdeyxdxy, &
            sextbx, sextby, sextbz, &
            oh_sjxe, oh_sjxi, oh_sjye, oh_sjyi, oh_sjze, oh_sjzi
         read( kunit ) &
            oh_sebpmlxl, oh_sebpmlxu, oh_sebpmlyl, oh_sebpmlyu
#endif
         read( kunit ) iclflge
         if( iclflge .gt. 0 ) then
            icll = iclflge / 10
            lclflge = - iclflge
            read( kunit ) &
               (sclxpse(i),i=1,icll), (sclxpee(i),i=1,icll), &
               (sclypse(i),i=1,icll), (sclypee(i),i=1,icll), &
               (scluure(i),i=1,icll), (scluule(i),i=1,icll), &
               (scluu0e(i),i=1,icll), (sclfcte(i),i=1,icll)
         end if
#ifndef OHHELP
         if( lnoi .gt. 0 ) then
#else
         if( oh_glnoi .gt. 0 ) then
#endif
           read( kunit ) iclflgia
           if( iclflgia .gt. 0 ) then
             lclflgia = - iclflgia
             do io = 1, lionspl
               read( kunit ) lclflgi(io)
               if( lclflgi(io) .gt. 0 ) then
                 icll = lclflgi(io) / 10
                 read( kunit ) &
                  (sclxpsi(i,io),i=1,icll), (sclxpei(i,io),i=1,icll), &
                  (sclypsi(i,io),i=1,icll), (sclypei(i,io),i=1,icll), &
                  (scluuri(i,io),i=1,icll), (scluuli(i,io),i=1,icll), &
                  (scluu0i(i,io),i=1,icll), (sclfcti(i,io),i=1,icll)
               end if
             end do
           end if
         end if
         close( kunit )
!....
      else
         call fntpcnv ( brestfntp, lrank,kunit, bident,'rest', bfile )
         open( kunit, file=bfile, form='UNFORMATTED' )
         write( kunit ) cvers, bident
         write( kunit ) &
            lssx, lssy, sstcur, lstcur, lopfeedc, lopfiedc, &
            lxps, lxpe, lxp0, loxp0, lyps, lype, lyp0, loyp0, &
            lnoe, lnoes, lnoee, lnoi, lnois, lnoie, lionspl, &
            ldivx, ldivy, lloadbf, lpmlxl, lpmlxu, lpmlyl, lpmlyu
#ifdef OHHELP
         write( kunit ) oh_glnoe, oh_glnoi, oh_sdid, oh_pbase, oh_totalp
#endif
         write( kunit ) &
            llsrbn,llsrty,llinx,lliny,llxps,llxpe,lltend,lltcur,lbemty,&
            lbemix, slpwr, slramm, slomg, slram, &
            slsrle, slsrwd, slsrtr, slsrmn, slsrfi, slsral, &
            sbempw, sbemwl, sbemle, sbemwd, sbemtr, sbemmn, sbemfi, &
            sbemal, sbemxf, sbemyf, sbeman, sbemph, sbemdl, &
            sbemanr, sbemomg, sla, slinea, slinba, slinjy
#ifndef OHHELP
         write( kunit ) &
            (spdat1(i),i=lnoes,lnoee), (spdat2(i),i=lnoes,lnoee), &
             spfen, spfex, spnoe
         if( lnoi .gt. 0 ) then
           write( kunit ) &
              (spdat1(i),i=lnois,lnoie), (spdat2(i),i=lnois,lnoie), &
              (lionids(i),i=1,lionspl), (lionide(i),i=1,lionspl), &
              (lionidl(i),i=1,lionspl), (spfin(i),i=1,lionspl), &
              (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
              (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
              (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
              (sionmm(i),i=1,lionspl), spnoit
         end if
#else
         write( kunit ) spfen, spfex, spnoe
         do ips = 1, 2
           if( oh_sdid(ips) .lt. 0 ) cycle 
           write( kunit ) (spdat1(i),i=oh_lnoes(ips),oh_lnoee(ips)), &
                          (spdat2(i),i=oh_lnoes(ips),oh_lnoee(ips))
         end do
         if( oh_glnoi .gt. 0 ) then
           write( kunit ) &
              (spfin(i),i=1,lionspl), &
              (spfix(i),i=1,lionspl),   (spnoi(i),i=1,lionspl), &
              (sionaf(i),i=1,lionspl),  (sionaz(i),i=1,lionspl), &
              (sionam(i),i=1,lionspl),  (sionqm(i),i=1,lionspl), &
              (sionmm(i),i=1,lionspl), spnoit
           do io = 1, lionspl
             do ips = 1, 2
               if( oh_sdid(ips) .lt. 0 ) cycle 
               write( kunit ) &
                  (spdat1(i),i=oh_lionids(io,ips),oh_lionide(io,ips)), &
                  (spdat2(i),i=oh_lionids(io,ips),oh_lionide(io,ips))
             end do
           end do
         end if
#endif
#ifndef OHHELP
         write( kunit ) &
            lcfde, lcfdi, sde, sde0, sdi, sebxy, sez, sbz, sjxyzt, &
            sdezdy, sdezdx, sdeyxdxy, sextbx, sextby, sextbz, &
            sjxe, sjxi, sjye, sjyi, sjze, sjzi
         write( kunit ) &
            sezxxl, sezyxl, sbzxxl, sbzyxl, &
            sezxxu, sezyxu, sbzxxu, sbzyxu, &
            sezxyl, sezyyl, sbzxyl, sbzyyl, &
            sezxyu, sezyyu, sbzxyu, sbzyyu
#else
         write( kunit ) &
            lcfde, lcfdi, oh_sde, sde0, sdi, oh_sexyz, oh_sbxyz, &
            oh_sjxyzt, oh_sdezdy, oh_sdezdx, oh_sdeyxdxy, &
            sextbx, sextby, sextbz, &
            oh_sjxe, oh_sjxi, oh_sjye, oh_sjyi, oh_sjze, oh_sjzi
         write( kunit ) &
            oh_sebpmlxl, oh_sebpmlxu, oh_sebpmlyl, oh_sebpmlyu
#endif
         write( kunit ) lclflge
         if( lclflge .gt. 0 ) then
            icll = lclflge / 10
            write( kunit ) &
               (sclxpse(i),i=1,icll), (sclxpee(i),i=1,icll), &
               (sclypse(i),i=1,icll), (sclypee(i),i=1,icll), &
               (scluure(i),i=1,icll), (scluule(i),i=1,icll), &
               (scluu0e(i),i=1,icll), (sclfcte(i),i=1,icll)
         end if
#ifndef OHHELP
         if( lnoi .gt. 0 ) then
#else
         if( oh_glnoi .gt. 0 ) then
#endif
           write( kunit ) lclflgia
           if( lclflgia .gt. 0 ) then
             do io = 1, lionspl
               write( kunit ) lclflgi(io)
               if( lclflgi(io) .gt. 0 ) then
                 icll = lclflgi(io) / 10
                 write( kunit ) &
                  (sclxpsi(i,io),i=1,icll), (sclxpei(i,io),i=1,icll), &
                  (sclypsi(i,io),i=1,icll), (sclypei(i,io),i=1,icll), &
                  (scluuri(i,io),i=1,icll), (scluuli(i,io),i=1,icll), &
                  (scluu0i(i,io),i=1,icll), (sclfcti(i,io),i=1,icll)
               end if
             end do
           end if
         end if
         flush( kunit )
         close( kunit )
      end if
!....
      call fdebug ( 's2rest', 1 )
!....
      return
      end
