!-----------------------------------------------------------------------
! Compute 2D Field current(J) Ion with Current Conservation
!
      subroutine c2fjicc 
!
!   <arguments>
!     none    
!
!   <remarks>
!     lccsch : current conservation scheme
!            : = 0 : Esirkepov's scheme
!            : = 1 : 1st order ZigZag scheme
!            : = 3 : 3rd order ZigZag scheme and 2nd order interpolation
!
!    coded by Sakagami,H. (NIFS) 20/11/04
! modified by Sakagami,H. (NIFS) 21/04/14
!-----------------------------------------------------------------------
#include "spdat.macro"
#include "vector.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
#include "pindexoh.macro"
#endif
      use constant
      include "implicit.h"
!....
      call fdebug ('c2fjicc', 0 )
!....
      select case( lccsch )
      case( 0 )
        call c2fjicc_esirkepov
#ifndef VECTOR
#ifndef OHHELP
      case( 1 )
        call c2fjicc_zigzag1
#endif
#endif
      case( 3 )
        call c2fjicc_zigzag32
      case default 
        write(0,*) '### ERROR: invalid lccsch', lccsch
        call s2ext_abort
      end select
!....
      call fdebug ( 'c2fjicc', 1 )
!....
      return  
      end 
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Ion with Current Conservation
! by Esirkepov's scheme
!
      subroutine c2fjicc_esirkepov
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
! original by Hata,M. (Nagoya Univ.) 09/11/06
!    coded by Sakagami,H. (NIFS) 10/06/07
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use parameter
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix,iy, ixi,iyi, ixia,iyia, idxi,idyi, ii,ij
      real*8  :: wdx,wdy,wdxa,wdya
      real*8  :: wdffx(6), wdffy(6), wdjx(6,6), wdjy(6,6)
#ifndef VECTOR
      real*8  :: wffxo(6), wffx(6), wjjx(6,6), &
                 wffyo(6), wffy(6), wjjy(6,6)
#else
      real*8, allocatable :: vwffxo(:,:), vwffx(:,:), vwjjx(:,:,:), &
                             vwffyo(:,:), vwffy(:,:), vwjjy(:,:,:)
      integer :: iv, iv2
#endif
#ifdef OHHELP
      integer :: ips
#endif
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxi(:,:), wjyi(:,:)
      save
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
#else
      if( oh_glnoi .gt. 0 ) then
#endif
!....
      if ( .not. allocated(wjxi) ) then
#ifndef OHHELP
         allocate ( wjxi(lssxlm2:lssxup3,lssylm2:lssyup2), &
                    wjyi(lssxlm2:lssxup2,lssylm2:lssyup3) )
#else
         allocate ( &
            wjxi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)), &
            wjyi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)) )
#endif
      end if
!...
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
#endif
#ifndef VECTOR
!$OMP PARALLEL PRIVATE(io,ixi,wdx,wffxo,ixia,wdxa,idxi,wffx, &
!$OMP                     iyi,wdy,wffyo,iyia,wdya,idyi,wffy, &
!$OMP                     ii,ij,wjjx,wjjy,wdffx,wdffy,wdjx,wdjy,ix,iy)
#else
!$OMP PARALLEL PRIVATE(io,ixi,wdx,ixia,wdxa,idxi, &
!$OMP                     iyi,wdy,iyia,wdya,idyi, &
!$OMP                     ii,ij,wdffx,wdffy,wdjx,wdjy,ix,iy, &
!$OMP                     i,iv,vwffxo,vwffx,vwjjx,vwffyo,vwffy,vwjjy)
#endif
#ifdef VECTOR
      if ( .not. allocated(vwffxo) ) then
         allocate( vwffxo(lvlen,6), vwffx(lvlen,6), vwjjx(lvlen,6,6), &
                   vwffyo(lvlen,6), vwffy(lvlen,6), vwjjy(lvlen,6,6) )
      end if
      do iv = 1, lvlen
#endif
      _wffxo(1) = s0o1
      _wffxo(6) = s0o1
      _wffyo(1) = s0o1
      _wffyo(6) = s0o1
#ifdef VECTOR
      end do
#endif
!...
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               wjxi(ix,iy) = s0o1
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               wjyi(ix,iy) = s0o1
            end do
         end do
!...
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxi,wjyi)
#ifndef VECTOR
         do i = lionids(io), lionide(io)
#else
         do iv2 = lionids(io), lionide(io), lvlen
!NEC$ IVDEP
         do iv = 1, min(lionide(io)-iv2+1, lvlen)
            i = iv + iv2 - 1
#endif
            _wffx(1) = s0o1
            _wffx(2) = s0o1
            _wffx(5) = s0o1
            _wffx(6) = s0o1
            _wffy(1) = s0o1
            _wffy(2) = s0o1
            _wffy(5) = s0o1
            _wffy(6) = s0o1
!..
            ixi = sxio(i)
            wdx = sxio(i) - ixi - s1o2
            _wffxo(2) = (s1o2-wdx)**3*s1o6
            _wffxo(3) = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
            _wffxo(4) =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
            _wffxo(5) = (s1o2+wdx)**3*s1o6
!.
            iyi = syio(i)
            wdy = syio(i) - iyi - s1o2
            _wffyo(2) = (s1o2-wdy)**3*s1o6
            _wffyo(3) = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
            _wffyo(4) =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
            _wffyo(5) = (s1o2+wdy)**3*s1o6
!.
            ixia = sxi(i)
            wdxa = sxi(i) - ixia - s1o2
            idxi = ixia - ixi
            _wffx(2+idxi) = (s1o2-wdxa)**3*s1o6
            _wffx(3+idxi) = (s1o2+wdxa)**2*(wdxa-s3o2)*s1o2 + s2o3
            _wffx(4+idxi) =-(s1o2-wdxa)**2*(wdxa+s3o2)*s1o2 + s2o3
            _wffx(5+idxi) = (s1o2+wdxa)**3*s1o6
!.
            iyia = syi(i)
            wdya = syi(i) - iyia - s1o2
            idyi = iyia - iyi
            _wffy(2+idyi) = (s1o2-wdya)**3*s1o6
            _wffy(3+idyi) = (s1o2+wdya)**2*(wdya-s3o2)*s1o2 + s2o3
            _wffy(4+idyi) =-(s1o2-wdya)**2*(wdya+s3o2)*s1o2 + s2o3
            _wffy(5+idyi) = (s1o2+wdya)**3*s1o6
#ifdef VECTOR
         end do
         do iv = 1, min(lionide(io)-iv2+1, lvlen)
            i = iv + iv2 - 1
#endif
!..
!NEC$ UNROLL_COMPLETELY
            do ii = 1, 6
               wdffx(ii) = _wffx(ii) - _wffxo(ii)
               wdffy(ii) = _wffy(ii) - _wffyo(ii)
            end do
!..
!NEC$ UNROLL_COMPLETELY
            do ij = 1, 6
!NEC$ UNROLL_COMPLETELY
               do ii = 1, 6
                  wdjx(ii,ij) = - spfi(i)  * wdffx(ii) &
                             * ( _wffyo(ij) + s1o2 * wdffy(ij) )
                  wdjy(ii,ij) = - spfi(i)  * wdffy(ij) &
                             * ( _wffxo(ii) + s1o2 * wdffx(ii) )
               end do
            end do
!..
!NEC$ UNROLL_COMPLETELY
            do ij = 1, 6
               _wjjx(1,ij) = wdjx(1,ij)
               _wjjy(ij,1) = wdjy(ij,1)
!NEC$ UNROLL_COMPLETELY
               do ii = 1, 5
                  _wjjx(ii+1,ij) = _wjjx(ii,ij) + wdjx(ii+1,ij)
                  _wjjy(ij,ii+1) = _wjjy(ij,ii) + wdjy(ij,ii+1)
               end do
            end do
#ifdef VECTOR
         end do
         do iv = 1, min(lionide(io)-iv2+1, lvlen)
            i = iv + iv2 - 1 
            ixi = sxio(i) 
            iyi = syio(i) 
#endif
!..
#ifdef OHHELP
            ixi = ixi - oh_ixs
            iyi = iyi - oh_iys
#endif
            do ij = 1, 6
               iy = ij + iyi - 3
               do ii = 1, 6
                  ix = ii + ixi - 3
                  wjxi(ix+1,iy) = wjxi(ix+1,iy) + _wjjx(ii,ij)
                  wjyi(ix,iy+1) = wjyi(ix,iy+1) + _wjjy(ii,ij)
               end do
            end do
#ifdef VECTOR
         end do
#endif
         end do
!...
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxi(lssxlm2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
               wjxi(lssxlm1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
               wjxi(lssxl  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
               wjxi(lssxlp1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
               wjxi(lssxlp2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
               wjxi(lssxlp3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjyi(lssxlm2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
               wjyi(lssxlm1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
               wjyi(lssxl  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
               wjyi(lssxlp1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
               wjyi(lssxlp2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
            end do
         end if
!.
         if( lexuf .eq. 1 ) then
            if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
               end do
            end if
         end if
!..
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxi(ix,lssylm2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
               wjxi(ix,lssylm1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
               wjxi(ix,lssyl  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
               wjxi(ix,lssylp1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
               wjxi(ix,lssylp2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjyi(ix,lssylm2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
               wjyi(ix,lssylm1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
               wjyi(ix,lssyl  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
               wjyi(ix,lssylp1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
               wjyi(ix,lssylp2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
               wjyi(ix,lssylp3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
            end do
         end if
         if( leyuf .eq. 1 ) then
            if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
               end do
            end if
         end if
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               sjxi(ix,iy,io) = wjxi(ix,iy) * sionaz(io)
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               sjyi(ix,iy,io) = wjyi(ix,iy) * sionaz(io)
            end do
         end do
!...
      end do
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
      end if
!....
      return
      end
#ifndef VECTOR
#ifndef OHHELP
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Ion with Current Conservation
! by 1st order ZigZag scheme
!
      subroutine c2fjicc_zigzag1
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/10/28
!----------------------------------------------------------------------
      use parameter
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, &
                 ixi1, ixh1, iyi1, iyh1, ixi2, ixh2, iyi2, iyh2
      real*8  ::  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
                  wdxi1, wdxi2, wdyi1, wdyi2, &
                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxi(:,:), wjyi(:,:)
      save
!....
      if( lnoi .gt. 0 ) then
!....
      if ( .not. allocated(wjxi) ) then
         allocate ( wjxi(lssxlm2:lssxup3,lssylm2:lssyup2), &
                    wjyi(lssxlm2:lssxup2,lssylm2:lssyup3) )
      end if
!...
!$OMP PARALLEL PRIVATE(io,ixi1,ixh1,iyi1,iyh1,ixi2,ixh2,iyi2,iyh2, &
!$OMP                  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
!$OMP                  wdxi1, wdxi2, wdyi1, wdyi2, &
!$OMP                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i )
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               wjxi(ix,iy) = s0o1
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               wjyi(ix,iy) = s0o1
            end do
         end do
!...
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxi,wjyi)
         do i = lionids(io), lionide(io)
            ixi1 = sxio(i) 
            ixh1 = ixi1 + 1
            iyi1 = syio(i) 
            iyh1 = iyi1 + 1
            ixi2 = sxi(i)
            ixh2 = ixi2 + 1
            iyi2 = syi(i)
            iyh2 = iyi2 + 1
!.
            wmin = min(ixi1, ixi2) + 1
            wmax = max(ixi1, ixi2)
            wxr = min( wmin, max( wmax, (sxio(i)+sxi(i))*s1o2 ) )
            wmin = min(iyi1, iyi2) + 1
            wmax = max(iyi1, iyi2)
            wyr = min( wmin, max( wmax, (syio(i)+syi(i))*s1o2 ) )
!.
            wfx1 = ( wxr - sxio(i) ) * spfi(i) 
            wfx2 = ( sxi(i) - wxr  ) * spfi(i)
            wfy1 = ( wyr - syio(i) ) * spfi(i) 
            wfy2 = ( syi(i) - wyr  ) * spfi(i)
!.
            wdxi1 = (sxio(i)+wxr)*s1o2 - ixi1
            wdxi2 = (sxi(i) +wxr)*s1o2 - ixi2
            wdyi1 = (syio(i)+wyr)*s1o2 - iyi1
            wdyi2 = (syi(i) +wyr)*s1o2 - iyi2
!..
            wy1i = s1o1 - wdyi1 
            wy2i = wdyi1
!
            wjxi(ixh1,iyi1  ) = wjxi(ixh1,iyi1  ) + wfx1 * wy1i
            wjxi(ixh1,iyi1+1) = wjxi(ixh1,iyi1+1) + wfx1 * wy2i
!.
            wx1i = s1o1 - wdxi1 
            wx2i = wdxi1
!
            wjyi(ixi1  ,iyh1) = wjyi(ixi1  ,iyh1) + wfy1 * wx1i
            wjyi(ixi1+1,iyh1) = wjyi(ixi1+1,iyh1) + wfy1 * wx2i
!..
            wy1i = s1o1 - wdyi2 
            wy2i = wdyi2
!
            wjxi(ixh2,iyi2  ) = wjxi(ixh2,iyi2  ) + wfx2 * wy1i
            wjxi(ixh2,iyi2+1) = wjxi(ixh2,iyi2+1) + wfx2 * wy2i
!.
            wx1i = s1o1 - wdxi2
            wx2i = wdxi2
!
            wjyi(ixi2  ,iyh2) = wjyi(ixi2  ,iyh2) + wfy2 * wx1i
            wjyi(ixi2+1,iyh2) = wjyi(ixi2+1,iyh2) + wfy2 * wx2i
         end do
!...
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxi(lssxlm2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
               wjxi(lssxlm1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
               wjxi(lssxl  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
               wjxi(lssxlp1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
               wjxi(lssxlp2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
               wjxi(lssxlp3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjyi(lssxlm2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
               wjyi(lssxlm1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
               wjyi(lssxl  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
               wjyi(lssxlp1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
               wjyi(lssxlp2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
            end do
         end if
!.
         if( lexuf .eq. 1 ) then
            if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
               end do
            end if
         end if
!..
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxi(ix,lssylm2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
               wjxi(ix,lssylm1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
               wjxi(ix,lssyl  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
               wjxi(ix,lssylp1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
               wjxi(ix,lssylp2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjyi(ix,lssylm2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
               wjyi(ix,lssylm1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
               wjyi(ix,lssyl  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
               wjyi(ix,lssylp1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
               wjyi(ix,lssylp2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
               wjyi(ix,lssylp3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
            end do
         end if
         if( leyuf .eq. 1 ) then
            if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
               end do
            end if
         end if
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               sjxi(ix,iy,io) = wjxi(ix,iy) * sionaz(io)
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               sjyi(ix,iy,io) = wjyi(ix,iy) * sionaz(io)
            end do
         end do
!...
      end do
!$OMP END PARALLEL
!....
      end if
!....
      return
      end
#endif
#endif
!-----------------------------------------------------------------------
! Compute 2D Field current(J) Ion with Current Conservation
! by 3rd order ZigZag scheme and 2nd order interpolation
!
      subroutine c2fjicc_zigzag32
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/10/28
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use parameter
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, &
                 ixi1, ixh1, iyi1, iyh1, ixi2, ixh2, iyi2, iyh2
      real*8  ::  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
                  wdxi, wdyi, &
                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i
#ifdef VECTOR
      real*8, allocatable :: vwjx(:,:,:), vwjy(:,:,:)
      integer :: iv, iv2 
#endif
#ifdef OHHELP
      integer :: ips
#endif
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxi(:,:), wjyi(:,:)
      save
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
#else
      if( oh_glnoi .gt. 0 ) then
#endif
!....
      if ( .not. allocated(wjxi) ) then
#ifndef OHHELP
         allocate ( wjxi(lssxlm2:lssxup3,lssylm2:lssyup2), &
                    wjyi(lssxlm2:lssxup2,lssylm2:lssyup3) )
#else
         allocate ( &
            wjxi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)), &
            wjyi(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                 oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)) )
#endif
      end if
#ifdef VECTOR
#ifndef OHHELP
      allocate( vwjx(lvlen,lssxlm2:lssxup3,lssylm2:lssyup2), &
                vwjy(lvlen,lssxlm2:lssxup2,lssylm2:lssyup3) )
#else
      allocate( &
            vwjx(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                       oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)), &
            vwjy(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT), &
                       oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT)) )
#endif
#endif
!...
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL PRIVATE(io,ixi1,ixh1,iyi1,iyh1,ixi2,ixh2,iyi2,iyh2, &
!$OMP                  wmin, wmax, wxr, wyr, wfx1, wfx2, wfy1, wfy2, &
!$OMP                  wdxi, wdyi, &
!$OMP                  wx1i, wx2i, wx3i, wx4i, wy1i, wy2i, wy3i, wy4i )
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               wjxi(ix,iy) = s0o1
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               wjyi(ix,iy) = s0o1
            end do
         end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm2, lssyup2
           do ix = lssxlm2, lssxup3
             do iv = 1, lvlen
               vwjx(iv,ix,iy) = s0o1
             end do
           end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm2, lssyup3
           do ix = lssxlm2, lssxup2
             do iv = 1, lvlen
               vwjy(iv,ix,iy) = s0o1
             end do
           end do
         end do
#endif
!...
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxi,wjyi)
         do i = lionids(io), lionide(io)
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vwjx,vwjy)
         do iv2 = lionids(io), lionide(io), lvlen
!NEC$ IVDEP
         do iv = 1, min(lionide(io)-iv2+1, lvlen)
            i = iv + iv2 - 1
#endif
            ixi1 = sxio(i) 
            ixh1 = ixi1 + 1
            iyi1 = syio(i) 
            iyh1 = iyi1 + 1
            ixi2 = sxi(i)
            ixh2 = ixi2 + 1
            iyi2 = syi(i)
            iyh2 = iyi2 + 1
!.
            wmin = min(ixi1, ixi2) + 1
            wmax = max(ixi1, ixi2)
            wxr = min( wmin, max( wmax, (sxio(i)+sxi(i))*s1o2 ) )
            wmin = min(iyi1, iyi2) + 1
            wmax = max(iyi1, iyi2)
            wyr = min( wmin, max( wmax, (syio(i)+syi(i))*s1o2 ) )
!.
            wfx1 = ( wxr - sxio(i) ) * spfi(i) 
            wfx2 = ( sxi(i) - wxr  ) * spfi(i)
            wfy1 = ( wyr - syio(i) ) * spfi(i) 
            wfy2 = ( syi(i) - wyr  ) * spfi(i)
!..
            wdxi = (sxio(i)+wxr)*s1o2 - ixi1 - s1o2
            wdyi = (syio(i)+wyr)*s1o2 - iyi1 - s1o2
#ifdef OHHELP
            ixi1 = ixi1 - oh_ixs
            ixh1 = ixh1 - oh_ixs
            iyi1 = iyi1 - oh_iys
            iyh1 = iyh1 - oh_iys
#endif
!..
            wx1i = s1o2*(s1o2-wdxi)**2
            wx2i = s3o2*s1o2-wdxi**2
            wx3i = s1o2*(s1o2+wdxi)**2
            wy1i = (s1o2-wdyi)**3*s1o6
            wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
            wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
            wy4i = (s1o2+wdyi)**3*s1o6
!
            _wjxi(ixh1-1,iyi1-1) = _wjxi(ixh1-1,iyi1-1) + wfx1*wy1i*wx1i
            _wjxi(ixh1-1,iyi1  ) = _wjxi(ixh1-1,iyi1  ) + wfx1*wy2i*wx1i
            _wjxi(ixh1-1,iyi1+1) = _wjxi(ixh1-1,iyi1+1) + wfx1*wy3i*wx1i
            _wjxi(ixh1-1,iyi1+2) = _wjxi(ixh1-1,iyi1+2) + wfx1*wy4i*wx1i
            _wjxi(ixh1  ,iyi1-1) = _wjxi(ixh1  ,iyi1-1) + wfx1*wy1i*wx2i
            _wjxi(ixh1  ,iyi1  ) = _wjxi(ixh1  ,iyi1  ) + wfx1*wy2i*wx2i
            _wjxi(ixh1  ,iyi1+1) = _wjxi(ixh1  ,iyi1+1) + wfx1*wy3i*wx2i
            _wjxi(ixh1  ,iyi1+2) = _wjxi(ixh1  ,iyi1+2) + wfx1*wy4i*wx2i
            _wjxi(ixh1+1,iyi1-1) = _wjxi(ixh1+1,iyi1-1) + wfx1*wy1i*wx3i
            _wjxi(ixh1+1,iyi1  ) = _wjxi(ixh1+1,iyi1  ) + wfx1*wy2i*wx3i
            _wjxi(ixh1+1,iyi1+1) = _wjxi(ixh1+1,iyi1+1) + wfx1*wy3i*wx3i
            _wjxi(ixh1+1,iyi1+2) = _wjxi(ixh1+1,iyi1+2) + wfx1*wy4i*wx3i
!.
            wx1i = (s1o2-wdxi)**3*s1o6
            wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
            wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
            wx4i = (s1o2+wdxi)**3*s1o6
            wy1i = s1o2*(s1o2-wdyi)**2
            wy2i = s3o2*s1o2-wdyi**2
            wy3i = s1o2*(s1o2+wdyi)**2
!
            _wjyi(ixi1-1,iyh1-1) = _wjyi(ixi1-1,iyh1-1) + wfy1*wx1i*wy1i
            _wjyi(ixi1  ,iyh1-1) = _wjyi(ixi1  ,iyh1-1) + wfy1*wx2i*wy1i
            _wjyi(ixi1+1,iyh1-1) = _wjyi(ixi1+1,iyh1-1) + wfy1*wx3i*wy1i
            _wjyi(ixi1+2,iyh1-1) = _wjyi(ixi1+2,iyh1-1) + wfy1*wx4i*wy1i
            _wjyi(ixi1-1,iyh1  ) = _wjyi(ixi1-1,iyh1  ) + wfy1*wx1i*wy2i
            _wjyi(ixi1  ,iyh1  ) = _wjyi(ixi1  ,iyh1  ) + wfy1*wx2i*wy2i
            _wjyi(ixi1+1,iyh1  ) = _wjyi(ixi1+1,iyh1  ) + wfy1*wx3i*wy2i
            _wjyi(ixi1+2,iyh1  ) = _wjyi(ixi1+2,iyh1  ) + wfy1*wx4i*wy2i
            _wjyi(ixi1-1,iyh1+1) = _wjyi(ixi1-1,iyh1+1) + wfy1*wx1i*wy3i
            _wjyi(ixi1  ,iyh1+1) = _wjyi(ixi1  ,iyh1+1) + wfy1*wx2i*wy3i
            _wjyi(ixi1+1,iyh1+1) = _wjyi(ixi1+1,iyh1+1) + wfy1*wx3i*wy3i
            _wjyi(ixi1+2,iyh1+1) = _wjyi(ixi1+2,iyh1+1) + wfy1*wx4i*wy3i
!..
            wdxi = (sxi(i)+wxr)*s1o2 - ixi2 - s1o2
            wdyi = (syi(i)+wyr)*s1o2 - iyi2 - s1o2
#ifdef OHHELP
            ixi2 = ixi2 - oh_ixs
            ixh2 = ixh2 - oh_ixs
            iyi2 = iyi2 - oh_iys
            iyh2 = iyh2 - oh_iys
#endif
!..
            wx1i = s1o2*(s1o2-wdxi)**2
            wx2i = s3o2*s1o2-wdxi**2
            wx3i = s1o2*(s1o2+wdxi)**2
            wy1i = (s1o2-wdyi)**3*s1o6
            wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
            wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
            wy4i = (s1o2+wdyi)**3*s1o6
!
            _wjxi(ixh2-1,iyi2-1) = _wjxi(ixh2-1,iyi2-1) + wfx2*wy1i*wx1i
            _wjxi(ixh2-1,iyi2  ) = _wjxi(ixh2-1,iyi2  ) + wfx2*wy2i*wx1i
            _wjxi(ixh2-1,iyi2+1) = _wjxi(ixh2-1,iyi2+1) + wfx2*wy3i*wx1i
            _wjxi(ixh2-1,iyi2+2) = _wjxi(ixh2-1,iyi2+2) + wfx2*wy4i*wx1i
            _wjxi(ixh2  ,iyi2-1) = _wjxi(ixh2  ,iyi2-1) + wfx2*wy1i*wx2i
            _wjxi(ixh2  ,iyi2  ) = _wjxi(ixh2  ,iyi2  ) + wfx2*wy2i*wx2i
            _wjxi(ixh2  ,iyi2+1) = _wjxi(ixh2  ,iyi2+1) + wfx2*wy3i*wx2i
            _wjxi(ixh2  ,iyi2+2) = _wjxi(ixh2  ,iyi2+2) + wfx2*wy4i*wx2i
            _wjxi(ixh2+1,iyi2-1) = _wjxi(ixh2+1,iyi2-1) + wfx2*wy1i*wx3i
            _wjxi(ixh2+1,iyi2  ) = _wjxi(ixh2+1,iyi2  ) + wfx2*wy2i*wx3i
            _wjxi(ixh2+1,iyi2+1) = _wjxi(ixh2+1,iyi2+1) + wfx2*wy3i*wx3i
            _wjxi(ixh2+1,iyi2+2) = _wjxi(ixh2+1,iyi2+2) + wfx2*wy4i*wx3i
!.
            wx1i = (s1o2-wdxi)**3*s1o6
            wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
            wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
            wx4i = (s1o2+wdxi)**3*s1o6
            wy1i = s1o2*(s1o2-wdyi)**2
            wy2i = s3o2*s1o2-wdyi**2
            wy3i = s1o2*(s1o2+wdyi)**2
!
            _wjyi(ixi2-1,iyh2-1) = _wjyi(ixi2-1,iyh2-1) + wfy2*wx1i*wy1i
            _wjyi(ixi2  ,iyh2-1) = _wjyi(ixi2  ,iyh2-1) + wfy2*wx2i*wy1i
            _wjyi(ixi2+1,iyh2-1) = _wjyi(ixi2+1,iyh2-1) + wfy2*wx3i*wy1i
            _wjyi(ixi2+2,iyh2-1) = _wjyi(ixi2+2,iyh2-1) + wfy2*wx4i*wy1i
            _wjyi(ixi2-1,iyh2  ) = _wjyi(ixi2-1,iyh2  ) + wfy2*wx1i*wy2i
            _wjyi(ixi2  ,iyh2  ) = _wjyi(ixi2  ,iyh2  ) + wfy2*wx2i*wy2i
            _wjyi(ixi2+1,iyh2  ) = _wjyi(ixi2+1,iyh2  ) + wfy2*wx3i*wy2i
            _wjyi(ixi2+2,iyh2  ) = _wjyi(ixi2+2,iyh2  ) + wfy2*wx4i*wy2i
            _wjyi(ixi2-1,iyh2+1) = _wjyi(ixi2-1,iyh2+1) + wfy2*wx1i*wy3i
            _wjyi(ixi2  ,iyh2+1) = _wjyi(ixi2  ,iyh2+1) + wfy2*wx2i*wy3i
            _wjyi(ixi2+1,iyh2+1) = _wjyi(ixi2+1,iyh2+1) + wfy2*wx3i*wy3i
            _wjyi(ixi2+2,iyh2+1) = _wjyi(ixi2+2,iyh2+1) + wfy2*wx4i*wy3i
#ifdef VECTOR
         end do
#endif
         end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm2, lssyup2
           do ix = lssxlm2, lssxup3
             do iv = 1, lvlen
               wjxi(ix,iy) = wjxi(ix,iy) + vwjx(iv,ix,iy)
             end do
           end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iv)
         do iy = lssylm2, lssyup3
           do ix = lssxlm2, lssxup2
             do iv = 1, lvlen
               wjyi(ix,iy) = wjyi(ix,iy) + vwjy(iv,ix,iy)
             end do
           end do
         end do
#endif
!...
         if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup2
               wjxi(lssxlm2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
               wjxi(lssxlm1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
               wjxi(lssxl  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
               wjxi(lssxlp1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
               wjxi(lssxlp2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
               wjxi(lssxlp3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm2, lssyup3
               wjyi(lssxlm2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
               wjyi(lssxlm1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
               wjyi(lssxl  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
               wjyi(lssxlp1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
               wjyi(lssxlp2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
            end do
         end if
!.
         if( lexuf .eq. 1 ) then
            if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup2
                  wjxi(lssxum2,iy) = wjxi(lssxlm2,iy) + wjxi(lssxum2,iy)
                  wjxi(lssxum1,iy) = wjxi(lssxlm1,iy) + wjxi(lssxum1,iy)
                  wjxi(lssxu  ,iy) = wjxi(lssxl  ,iy) + wjxi(lssxu  ,iy)
                  wjxi(lssxup1,iy) = wjxi(lssxlp1,iy) + wjxi(lssxup1,iy)
                  wjxi(lssxup2,iy) = wjxi(lssxlp2,iy) + wjxi(lssxup2,iy)
                  wjxi(lssxup3,iy) = wjxi(lssxlp3,iy) + wjxi(lssxup3,iy)
               end do
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm2, lssyup3
                  wjyi(lssxum2,iy) = wjyi(lssxlm2,iy) + wjyi(lssxum2,iy)
                  wjyi(lssxum1,iy) = wjyi(lssxlm1,iy) + wjyi(lssxum1,iy)
                  wjyi(lssxu  ,iy) = wjyi(lssxl  ,iy) + wjyi(lssxu  ,iy)
                  wjyi(lssxup1,iy) = wjyi(lssxlp1,iy) + wjyi(lssxup1,iy)
                  wjyi(lssxup2,iy) = wjyi(lssxlp2,iy) + wjyi(lssxup2,iy)
               end do
            end if
         end if
!..
         if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup3
               wjxi(ix,lssylm2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
               wjxi(ix,lssylm1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
               wjxi(ix,lssyl  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
               wjxi(ix,lssylp1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
               wjxi(ix,lssylp2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
            end do
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm2, lssxup2
               wjyi(ix,lssylm2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
               wjyi(ix,lssylm1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
               wjyi(ix,lssyl  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
               wjyi(ix,lssylp1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
               wjyi(ix,lssylp2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
               wjyi(ix,lssylp3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
            end do
         end if
         if( leyuf .eq. 1 ) then
            if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup3
                  wjxi(ix,lssyum2) = wjxi(ix,lssylm2) + wjxi(ix,lssyum2)
                  wjxi(ix,lssyum1) = wjxi(ix,lssylm1) + wjxi(ix,lssyum1)
                  wjxi(ix,lssyu  ) = wjxi(ix,lssyl  ) + wjxi(ix,lssyu  )
                  wjxi(ix,lssyup1) = wjxi(ix,lssylp1) + wjxi(ix,lssyup1)
                  wjxi(ix,lssyup2) = wjxi(ix,lssylp2) + wjxi(ix,lssyup2)
               end do
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm2, lssxup2
                  wjyi(ix,lssyum2) = wjyi(ix,lssylm2) + wjyi(ix,lssyum2)
                  wjyi(ix,lssyum1) = wjyi(ix,lssylm1) + wjyi(ix,lssyum1)
                  wjyi(ix,lssyu  ) = wjyi(ix,lssyl  ) + wjyi(ix,lssyu  )
                  wjyi(ix,lssyup1) = wjyi(ix,lssylp1) + wjyi(ix,lssyup1)
                  wjyi(ix,lssyup2) = wjyi(ix,lssylp2) + wjyi(ix,lssyup2)
                  wjyi(ix,lssyup3) = wjyi(ix,lssylp3) + wjyi(ix,lssyup3)
               end do
            end if
         end if
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
               sjxi(ix,iy,io) = wjxi(ix,iy) * sionaz(io)
            end do
         end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
               sjyi(ix,iy,io) = wjyi(ix,iy) * sionaz(io)
            end do
         end do
      end do
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
#ifdef VECTOR
      deallocate( vwjx, vwjy )
#endif
      end if
!....
      return
      end
