!----------------------------------------------------------------------
! Observe 2D Field Density Ion
!                          /
      subroutine o2fdi ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 21, ifn = 2
      integer :: kflag, i, io, iofdi, ilog, icrsx, icrsy, &
                 ix, iy, ixy, iwdia
      real*8  :: wminlog
      real*8, allocatable :: wdia(:,:)
      character*20 clabel
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o2fdi', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         if( lcfdi .eq. 0 ) call c2fdi
#ifdef OHHELP
         if( loxypl .gt. 0 ) then
#endif
         iwdia = iwdia + 1
         do io = 1, lionspl
            ixy = 0
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  ixy = ixy + 1
                  wdia(ixy,io) = wdia(ixy,io) + sdi(ix,iy,io)
               end do
            end do
         end do
#ifdef OHHELP
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do io = 1, lionspl
               do i = 1, loxypl
                  wdia(i,io) = wdia(i,io) / ( iwdia * snepm1 )
               end do
            end do
            if( iofdi .le. 4 ) then
               write(iun) sstcur, ((wdia(i,io),i=1,loxypl),io=1,lionspl)
               flush(iun)
            end if
            if( iofdi .ge. 2 ) then
               do io = 1, lionspl
                  call o2ionlabel ( io, sionam(io), sionaz(io), clabel )
                  call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                               ifn, ilog, 3, icrsx, icrsy, &
                               wdia(1,io), loxpl, loypl, &
                         soxmic, soxp0m, soymic, soyp0m, 'fdi'//clabel )
               end do
            end if
          end if
!....
         else
            iofdi = mod( lofdi, 10 )
            ilog  = mod( lofdi/10, 10 )
            icrsx = mod( lofdi/100, 100 )
            icrsy = lofdi/10000
!..
            if( loxypl .gt. 0 ) then
              if(.not.allocated(wdia)) allocate( wdia(loxypl,lionspl) )
            end if
!
            if( iofdi .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fdi', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fdi2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(io),sionaz(io),io=1,lionspl)
#else
               write(iun) 'fdi3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(io),sionaz(io),io=1,lionspl), &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if( iofdi .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fdi', bfile )
               call frames_file ( bfile, ifn, iofdi )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwdia = 0
            do io = 1, lionspl
               do i = 1, loxypl
                  wdia(i,io) = s0o1
               end do
            end do
         end if
      end if
!....
      call fdebug ( 'o2fdi', 1 )
!....
      return
      end
