!----------------------------------------------------------------------
! Observe 2D Field Temperature Electron (+pressure)
!                          /
      subroutine o2fte ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output & clear
!                  2 = add & outpur & clear
!                  3 = add
!
!   <remarks>
!     This program also output 2D pressure profile.
!
!    coded by Hata,M. (Nagoya Univ.) 11/03/23
! modified by Sakagami,H. (NIFS) 11/06/30
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 33, ifn = 13
      integer :: kflag, i, ix, iy ,ixy, iofte, ilog, iwtea
      real*8  :: wgam, wminlogt, wminlogp, weps=1.0d-10
      real*8, allocatable :: wpeg(:,:), wtmpde(:,:), wte(:), wpe(:)
#ifdef OHHELP
      real*8, allocatable :: oh_wpegde(:,:,:,:)
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o2fte', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         iwtea = iwtea + 1
!..
#ifndef OHHELP
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wpeg,wtmpde), &
!$OMP          PRIVATE(ix,iy,wgam)
         do i = lnoes, lnoee
            if( sxe(i) .lt. loxps .or. sxe(i) .gt. loxpe ) cycle
            if( sye(i) .lt. loyps .or. sye(i) .gt. loype ) cycle
            ix = sxe(i)
            iy = sye(i)
            wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
            wpeg(ix,iy)   = wpeg(ix,iy) + wgam * spfe(i)
            wtmpde(ix,iy) = wtmpde(ix,iy) + spfe(i)
         end do
#else
         oh_wpegde(:,:,:,:) = s0o1
!.
         do ips = 1, 2
            if( oh_lnoe(ips) .le. 0 ) cycle 
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wpegde), &
!$OMP          PRIVATE(ix,iy,wgam)
            do i = oh_lnoes(ips), oh_lnoee(ips)
               ix = sxe(i) - oh_ixs
               iy = sye(i) - oh_iys
               wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
               oh_wpegde(1,ix,iy,ips) = oh_wpegde(1,ix,iy,ips) + &
                                        wgam*spfe(i)
               oh_wpegde(2,ix,iy,ips) = oh_wpegde(2,ix,iy,ips) + spfe(i)
            end do
         end do
!.
         call oh3_reduce_field &
                         ( oh_wpegde(1,1,1,1), oh_wpegde(1,1,1,2), OTE )
!..
         if( loxypl .gt. 0 ) then
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  wpeg(ix,iy)   = wpeg(ix,iy) + oh_wpegde(1,ix,iy,1)
                  wtmpde(ix,iy) = wtmpde(ix,iy) + oh_wpegde(2,ix,iy,1)
               end do
            end do
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            ixy = 0
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  ixy = ixy + 1
                  if ( wtmpde(ix,iy) .gt. weps ) then
                     wte(ixy) = (wpeg(ix,iy)/wtmpde(ix,iy)-s1o1) * &
                                s2o3 * scoft
                  else
                     wte(ixy) = s0o1
                  end if
                  wpe(ixy) = wtmpde(ix,iy) / iwtea / snepm1 * &
                             wte(ixy) * scofp
               end do
            end do
            if( iofte .le. 4 ) then
               write(iun) sstcur,(wte(i),i=1,loxypl),(wpe(i),i=1,loxypl)
               flush(iun)
            end if
            if( iofte .ge. 2 ) then
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                            ifn, 0, 1, 0, 0, wte, loxpl, loypl, &
                          soxmic, soxp0m, soymic, soyp0m, 'fte[MeV] ' )
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                            ifn, 0, 1, 0, 0, wpe, loxpl, loypl, &
                          soxmic, soxp0m, soymic, soyp0m, 'fpe[Gbar] ' )
            end if
          end if
!....
         else
            iofte = mod( lofte, 10 )
            ilog  = mod( lofte/10, 10 )
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wte) ) &
                     allocate( wpeg(loxps:loxpe,loyps:loype), &
                         wtmpde(loxps:loxpe,loyps:loype), &
                         wte(loxypl), wpe(loxypl) )
            end if
#ifdef OHHELP
            if( .not. allocated(oh_wpegde) ) allocate( &
             oh_wpegde(2,oh_alosizes(1,1,OTE):oh_alosizes(2,1,OTE), &
                         oh_alosizes(1,2,OTE):oh_alosizes(2,2,OTE),2) )
#endif
!
            if( iofte .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fte', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fte2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               write(iun) 'fte3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if(iofte .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fte', bfile )
               call frames_file ( bfile, ifn, iofte )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwtea = 0
            do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                  wpeg(ix,iy)   = s0o1
                  wtmpde(ix,iy) = s0o1
               end do
            end do
         end if
      end if
!....
      call fdebug ( 'o2fte', 1 )
!....
      return
      end
