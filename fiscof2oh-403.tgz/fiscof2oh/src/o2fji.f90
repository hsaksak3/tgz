!----------------------------------------------------------------------
! Observe 2D Field Current Ion
!                          /
      subroutine o2fji ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 29, ifn = 10
      integer :: kflag, i, io, iofji, int, ix,iy,ixy, iwfjia, idum
      real*8  :: wamp
      real*8, allocatable :: wfjx(:,:), wfjy(:,:), wfjz(:,:), wampx(:)
      character*20 clabel
#ifdef OHHELP
      real*8, allocatable :: oh_wfji(:,:,:,:,:)
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o2fji', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         iwfjia = iwfjia + 1
#ifndef OHHELP
         do io = 1, lionspl
           ixy = 0
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wfjx(ixy,io) = wfjx(ixy,io) + sjxi(ix,iy,io)
               wfjy(ixy,io) = wfjy(ixy,io) + sjyi(ix,iy,io)
               wfjz(ixy,io) = wfjz(ixy,io) + sjzi(ix,iy,io)
             end do
           end do
         end do
#else
         if( oh_pivflag .ne. 0 ) then
           call c2piv
           oh_pivflag = 0
         end if
         oh_wfji(:,:,:,:,:) = s0o1
!.
         do ips = 1, 2
            if( oh_lnoi(ips) .le. 0 ) cycle
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
            do io = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wfji), &
!$OMP          PRIVATE(ix,iy)
               do i = oh_lionids(io,ips), oh_lionide(io,ips)
                  ix = sxe(i) - oh_ixs
                  iy = sye(i) - oh_iys
                  oh_wfji(1,io,ix,iy,ips) = oh_wfji(1,io,ix,iy,ips) + &
                                            svxi(i) * spfi(i)
                  oh_wfji(2,io,ix,iy,ips) = oh_wfji(2,io,ix,iy,ips) + &
                                            svyi(i) * spfi(i)
                  oh_wfji(3,io,ix,iy,ips) = oh_wfji(3,io,ix,iy,ips) + &
                                            svzi(i) * spfi(i)
               end do
            end do
         end do
!.
         call oh3_reduce_field &
                      ( oh_wfji(1,1,1,1,1), oh_wfji(1,1,1,1,2), OJI )
!..
         if( loxypl .gt. 0 ) then
           do io = 1, lionspl
             ixy = 0
             do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                 ixy = ixy + 1 
                 wfjx(ixy,io) = wfjx(ixy,io) + oh_wfji(1,io,ix,iy,1) * &
                                               sionaz(io)
                 wfjy(ixy,io) = wfjy(ixy,io) + oh_wfji(2,io,ix,iy,1) * &
                                               sionaz(io)
                 wfjz(ixy,io) = wfjz(ixy,io) + oh_wfji(3,io,ix,iy,1) * &
                                               sionaz(io)
               end do
             end do
           end do
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do io = 1, lionspl
              wamp = -1.0d30
              do i = 1, loxypl
               wfjx(i,io) = wfjx(i,io) / ( iwfjia * snepm1 * scfl )
               wfjy(i,io) = wfjy(i,io) / ( iwfjia * snepm1 * scfl )
               wfjz(i,io) = wfjz(i,io) / ( iwfjia * snepm1 * scfl )
               wamp = max( wamp, &
                        wfjx(i,io)**2+wfjy(i,io)**2+wfjz(i,io)**2 )
              end do
              wampx(io) = sqrt( wamp )
            end do
!..
            if( iofji .le. 4 ) then
               write(iun) sstcur, &
         ((wfjx(i,io),wfjy(i,io),wfjz(i,io),i=1,loxypl),io=1,lionspl), &
                                                (wampx(io),io=1,lionspl)
               flush(iun)
            end if
            if( iofji .ge. 2 ) then
              do io = 1, lionspl
                call o2ionlabel ( io, sionam(io), sionaz(io), clabel )
                call o2fdraw5 ( bident, sstcur, ifn, 2, int, 2, &
                    wampx(io), &
                    wfjx(1,io), wfjy(1,io), wfjz(1,io), loxpl, loypl, &
                    soxmic, soxp0m, soymic, soyp0m, &
                    'fjxi'//clabel, 'fjyi'//clabel, 'fjzi'//clabel, &
                    'fjxyi'//clabel, 'fjyzi'//clabel, 'fjxzi'//clabel )
              end do
            end if
          end if
!....
         else
            iofji = mod( lofji, 10 )
            idum  = mod( lofji/10, 10 )
            int   = lofji/100
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wfjx) ) &
               allocate( wfjx(loxypl,lionspl), wfjy(loxypl,lionspl), &
                         wfjz(loxypl,lionspl), wampx(lionspl) )
            end if
#ifdef OHHELP
            if( .not. allocated(oh_wfji) ) allocate( &
         oh_wfji(3,lionspl,oh_alosizes(1,1,OJI):oh_alosizes(2,1,OJI), &
                           oh_alosizes(1,2,OJI):oh_alosizes(2,2,OJI),2) )
#endif
!
            if( iofji .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fji', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fji2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(io),sionaz(io),io=1,lionspl)
#else
               write(iun) 'fji3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                       lionspl,(sionam(io),sionaz(io),io=1,lionspl), &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if( iofji .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fji', bfile )
               call frames_file ( bfile, ifn, iofji )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwfjia = 0
            do io = 1, lionspl
              do i = 1, loxypl
                wfjx(i,io) = s0o1
                wfjy(i,io) = s0o1
                wfjz(i,io) = s0o1
              end do
            end do
         end if
      end if
!....
      call fdebug ( 'o2fji', 1 )
!....
      return
      end
