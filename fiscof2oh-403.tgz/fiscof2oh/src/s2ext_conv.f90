!!----------------------------------------------------------------------
! Set 2D EXTernal system parameter CONVert
!                               /
      subroutine s2ext_conv ( kflag )
!
!   <arguments>
!     kflag : mode 0 = set index data for init(pml edge)
!                 10 = set index data for init(no edge )
!                  1 = check & set neighbor infomation of subdomain
!                  2 = set field index data
!                  3 = set particle index data
!                 13 = set particle index data for zero clear
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!---------------------------------------------------------------------
#ifdef OHHELP
#include "spdat.macro"
      use parameter
      use oh_param
      use control
      use constant
      include "implicit.h"
      integer :: kflag, iflag, imode, ips, io, ipn
      save
#endif
!....
      call fdebug ( 's2ext_conv', 0 )
!....
#ifdef OHHELP
!...
      iflag = mod(kflag,10)
      imode = kflag / 10
!...
      select case( iflag )
!... init
      case( 0 ) 
        ips = 1
!.
        lssxl = 1
        lssxu = oh_sdoms(2,1,oh_sdid(ips)+1)-&
                oh_sdoms(1,1,oh_sdid(ips)+1)+1
        lssyl = 1
        lssyu = oh_sdoms(2,2,oh_sdid(ips)+1)-&
                oh_sdoms(1,2,oh_sdid(ips)+1)+1
        lblxl = lssxl
        lblxu = lssxu
        lblyl = lssyl
        lblyu = lssyu
!.
        if( imode .eq. 0 ) then
          if( lbxlf .eq. 4 ) then
            lblxl = 3
            lssxl = lblxl + lpmlxl
          end if
          if( lbxuf .eq. 4 ) lssxu = lblxu - lpmlxu - 1
          if( lbylf .eq. 4 ) then
            lblyl = 3
            lssyl = lblyl + lpmlyl
          end if
          if( lbyuf .eq. 4 ) lssyu = lblyu - lpmlyu - 1
        end if
!.
        lssxlm1 = lssxl - 1
        lssxlm2 = lssxl - 2
        lssxlp1 = lssxl + 1
        lssxlp2 = lssxl + 2
        lssxlp3 = lssxl + 3
        lssxum1 = lssxu - 1
        lssxum2 = lssxu - 2
        lssxup1 = lssxu + 1
        lssxup2 = lssxu + 2
        lssxup3 = lssxu + 3
        lssylm1 = lssyl - 1
        lssylm2 = lssyl - 2
        lssylp1 = lssyl + 1
        lssylp2 = lssyl + 2
        lssylp3 = lssyl + 3
        lssyum1 = lssyu - 1
        lssyum2 = lssyu - 2
        lssyup1 = lssyu + 1
        lssyup2 = lssyu + 2
        lssyup3 = lssyu + 3
!.
        lblxlm1 = lblxl - 1
        lblxup1 = lblxu + 1
        lblylm1 = lblyl - 1
        lblyup1 = lblyu + 1

!...check & set neighbor infomation of subdomain
      case( 1 ) 
        do ips = 1, 2
          oh_lexuf(ips)  = 0
          oh_lexlf(ips)  = 0
          oh_leyuf(ips)  = 0
          oh_leylf(ips)  = 0
          oh_lexlpe(ips) = 0
          oh_lexupe(ips) = 0
          oh_leylpe(ips) = 0
          oh_leyupe(ips) = 0
          oh_lexlpi(ips) = 0
          oh_lexupi(ips) = 0
          oh_leylpi(ips) = 0
          oh_leyupi(ips) = 0
  !.
          if( oh_sdid(ips) .lt. 0 ) cycle
  !.
          if( oh_sdoms(1,1,oh_sdid(ips)+1) .eq. oh_scoord(1,1) ) then
            if( lbxlf .ne. 1 ) oh_lexlf(ips) = lbxlf
            oh_lexlpe(ips) = lbxlpe
            oh_lexlpi(ips) = lbxlpi
          end if
          if( oh_sdoms(2,1,oh_sdid(ips)+1) .eq. oh_scoord(2,1) ) then
            if( lbxuf .ne. 1 ) oh_lexuf(ips) = lbxuf
            oh_lexupe(ips) = lbxupe
            oh_lexupi(ips) = lbxupi
          end if
          if( oh_sdoms(1,2,oh_sdid(ips)+1) .eq. oh_scoord(1,2) ) then
            if( lbylf .ne. 1 ) oh_leylf(ips) = lbylf
            oh_leylpe(ips) = lbylpe
            oh_leylpi(ips) = lbylpi
          end if
          if( oh_sdoms(2,2,oh_sdid(ips)+1) .eq. oh_scoord(2,2) ) then
            if( lbyuf .ne. 1 ) oh_leyuf(ips) = lbyuf
            oh_leyupe(ips) = lbyupe
            oh_leyupi(ips) = lbyupi
          end if
        end do

!...set new field index data
      case( 2 ) 
       do ips = 1, 2
        if( oh_sdid(ips) .lt. 0 ) cycle
!.
        oh_lssxl(ips) = 1
        oh_lssxu(ips) = oh_sdoms(2,1,oh_sdid(ips)+1)-&
                        oh_sdoms(1,1,oh_sdid(ips)+1)+1
        oh_lssyl(ips) = 1
        oh_lssyu(ips) = oh_sdoms(2,2,oh_sdid(ips)+1)-&
                        oh_sdoms(1,2,oh_sdid(ips)+1)+1
        oh_lblxl(ips) = oh_lssxl(ips)
        oh_lblxu(ips) = oh_lssxu(ips)
        oh_lblyl(ips) = oh_lssyl(ips)
        oh_lblyu(ips) = oh_lssyu(ips)
!.
        if( lbxlf .eq. 4 ) then
          if( oh_sdoms(1,1,oh_sdid(ips)+1) .eq. oh_scoord(1,1) ) then
            oh_lblxl(ips) = 3
            oh_lssxl(ips) = oh_lblxl(ips) + lpmlxl
          end if
        end if
        if( lbxuf .eq. 4 ) then
          if( oh_sdoms(2,1,oh_sdid(ips)+1) .eq. oh_scoord(2,1) ) then
            oh_lssxu(ips) = oh_lblxu(ips) - lpmlxu - 1 
          end if
        end if
        if( lbylf .eq. 4 ) then
          if( oh_sdoms(1,2,oh_sdid(ips)+1) .eq. oh_scoord(1,2) ) then
            oh_lblyl(ips) = 3
            oh_lssyl(ips) = oh_lblyl(ips) + lpmlyl
          end if
        end if
        if( lbyuf .eq. 4 ) then
          if( oh_sdoms(2,2,oh_sdid(ips)+1) .eq. oh_scoord(2,2) ) then
            oh_lssyu(ips) = oh_lblyu(ips) - lpmlyu - 1
          end if
        end if
!.
        oh_lssxlm1(ips) = oh_lssxl(ips) - 1
        oh_lssxlm2(ips) = oh_lssxl(ips) - 2
        oh_lssxlp1(ips) = oh_lssxl(ips) + 1
        oh_lssxlp2(ips) = oh_lssxl(ips) + 2
        oh_lssxlp3(ips) = oh_lssxl(ips) + 3
        oh_lssxum1(ips) = oh_lssxu(ips) - 1
        oh_lssxum2(ips) = oh_lssxu(ips) - 2
        oh_lssxup1(ips) = oh_lssxu(ips) + 1
        oh_lssxup2(ips) = oh_lssxu(ips) + 2
        oh_lssxup3(ips) = oh_lssxu(ips) + 3
        oh_lssylm1(ips) = oh_lssyl(ips) - 1
        oh_lssylm2(ips) = oh_lssyl(ips) - 2
        oh_lssylp1(ips) = oh_lssyl(ips) + 1
        oh_lssylp2(ips) = oh_lssyl(ips) + 2
        oh_lssylp3(ips) = oh_lssyl(ips) + 3
        oh_lssyum1(ips) = oh_lssyu(ips) - 1
        oh_lssyum2(ips) = oh_lssyu(ips) - 2
        oh_lssyup1(ips) = oh_lssyu(ips) + 1
        oh_lssyup2(ips) = oh_lssyu(ips) + 2
        oh_lssyup3(ips) = oh_lssyu(ips) + 3
!.
        oh_lblxlm1(ips) = oh_lblxl(ips) - 1
        oh_lblxup1(ips) = oh_lblxu(ips) + 1
        oh_lblylm1(ips) = oh_lblyl(ips) - 1
        oh_lblyup1(ips) = oh_lblyu(ips) + 1
      end do
!... set new particle index data
      case( 3 ) 
       do ips = 1, 2
!.
        if( oh_sdid(ips) .lt. 0 .or. imode .eq. 1 ) then
          oh_lnoe( ips) = 0
          oh_lnoes(ips) = 0
          oh_lnoee(ips) = -1
          oh_lnoi( ips) = 0
          oh_lnois(ips) = 0
          oh_lnoie(ips) = -1
          do io = 1, lionspl
            oh_lionidl(io,ips) = 0
            oh_lionids(io,ips) = 0
            oh_lionide(io,ips) = -1
          end do
          cycle
        end if
!.
        oh_lnoe(ips)  = oh_totalp(1,ips)
        oh_lnoes(ips) = oh_pbase(ips) + 1
        oh_lnoee(ips) = oh_pbase(ips) + oh_totalp(1,ips)
        oh_lnoi(ips)  = oh_pbase(ips+1) - oh_pbase(ips) - oh_lnoe(ips)
        oh_lnois(ips) = oh_pbase(ips) + oh_totalp(1,ips) + 1
        oh_lnoie(ips) = oh_pbase(ips+1)
        ipn = oh_pbase(ips)
!.
        do io = 1, lionspl
          ipn = ipn + oh_totalp(io,ips)
          oh_lionidl(io,ips) = oh_totalp(io+1,ips)
          oh_lionids(io,ips) = ipn + 1
          oh_lionide(io,ips) = ipn + oh_lionidl(io,ips)
        end do
      end do
!.
      oh_pevflag = 1
      oh_pivflag = 1
    end select
#endif
!....
      call fdebug ( 's2ext_conv', 1 )
!....
      return
      end
