!----------------------------------------------------------------------
! animation
!
module animation
      use parameter
      integer :: &
         latnxt, lagfl, lavpl, lawnl, &
         lamode(lagfx), lagifw(lagfx), lagifh(lagfx), &
         lagifv(lavpx,lagfx), lavpc(lavpx,lagfx), &
         lapepl, lapep(laxxx), lapepgt(laxxx), &
         lapeuxyl, lapeuxy(laxxx), lapeuxygt(laxxx), &
         lapeuxzl, lapeuxz(laxxx), lapeuxzgt(laxxx), &
         lapeuyzl, lapeuyz(laxxx), lapeuyzgt(laxxx), &
         lapexuxl, lapexux(laxxx), lapexuxgt(laxxx), &
         lapexuyl, lapexuy(laxxx), lapexuygt(laxxx), &
         lapexuzl, lapexuz(laxxx), lapexuzgt(laxxx), &
         lapipl, lapip(laxxx), lapipgt(laxxx), &
         lapiuxyl, lapiuxy(laxxx), lapiuxygt(laxxx), &
         lapixuxl, lapixux(laxxx), lapixuxgt(laxxx), &
         lapixuyl, lapixuy(laxxx), lapixuygt(laxxx), &
         lafdel, lafde(laxxx), lafdegt(laxxx), &
         lafdil, lafdi(laxxx), lafdigt(laxxx), &
         lafedel, lafede(laxxx), lafedegt(laxxx), &
         lafedil, lafedi(laxxx), lafedigt(laxxx), &
         lafjexl, lafjex(laxxx), lafjexgt(laxxx), &
         lafjeyl, lafjey(laxxx), lafjeygt(laxxx), &
         lafjezl, lafjez(laxxx), lafjezgt(laxxx), &
         lafeal, lafea(laxxx), lafeagt(laxxx), &
         lafexl, lafex(laxxx), lafexgt(laxxx), &
         lafeyl, lafey(laxxx), lafeygt(laxxx), &
         lafezl, lafez(laxxx), lafezgt(laxxx), &
         lafbal, lafba(laxxx), lafbagt(laxxx), &
         lafbxl, lafbx(laxxx), lafbxgt(laxxx), &
         lafbyl, lafby(laxxx), lafbygt(laxxx), &
         lafbzl, lafbz(laxxx), lafbzgt(laxxx)
      real*8 :: &
         satstr, satend, satint, satnxt, &
         savpxm(lavpx), savpxx(lavpx), savpym(lavpx), savpyx(lavpx), &
         sawnxm(lawnx), sawnxx(lawnx), sawnym(lawnx), sawnyx(lawnx), &
         sawnzm(lawnx), sawnzx(lawnx)
      character ::  banfntp(lagfx)*64, banfn(lagfx)*128
end module animation
