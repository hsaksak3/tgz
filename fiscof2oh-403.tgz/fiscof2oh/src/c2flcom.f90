!----------------------------------------------------------------------
! Compute 2D Field Laser COMponents
!                           /          /   /
      subroutine c2flcom ( kbn, fcom, kx, ky )
!                                /
!   <arguments>
!     kbn  : beam # ( 1 <= kbn <= llsrbn )
!     fcom : laser componetns
!     kx   : x size of fcom
!     ky   : y size of fcom
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/17
!----------------------------------------------------------------------
      use constant
      use profile
      use constant
      use laserprf
      include "implicit.h"
      integer :: kbn, kx, ky, init=0, ipolm, itrns, i, iy
      real*8  :: fcom(kx,ky), wx1, wx2, wx3, wy, wpht, wphmx, wphmn, &
                 wtdlx, wamp, wat, wt, wlt, wsign
      real*8, allocatable :: wph(:), wphcp(:), wphdl(:,:,:), &
                             wleatm(:), wlbatm(:), wleate(:), wlbate(:)
#ifdef VECTOR
      real*8, allocatable :: vwt(:,:), vwamp(:,:), vwy(:), vwat(:,:)
#endif
      save
!....
      call fdebug ( 'c2flcom', 0 )
!....
      if( init .eq. 0 ) then
         allocate( wph(llsrbn),wphcp(llsrbn),wphdl(3,ky,llsrbn), &
                   wleatm(llsrbn), wlbatm(llsrbn), &
                   wleate(llsrbn), wlbate(llsrbn) )
#ifdef VECTOR
         allocate( vwt(ky,3), vwamp(ky,3), vwy(ky), vwat(ky,3) )
#endif
         wtdlx = sundef
         do i = 1, llsrbn
           itrns = mod( lbemty(i)/10, 10 )
           ipolm = lbemty(i) / 100
           wleatm(i) = slinea(i) / s4o1
           wlbatm(i) = slinba(i) / s2o1
           wleate(i) = slinea(i) / s2o1
           wlbate(i) = slinba(i) / s4o1
           wph(i) = sbemph(i) * sd2r
           if( ipolm .eq. 3 ) then
              wphcp(i) = - 90.0d0 * sd2r
           else if( ipolm .eq. 4 ) then
              wphcp(i) =   90.0d0 * sd2r
           else
              wphcp(i) = s0o1
           end if
!..
           if( lbemix(i) .ge. 0 ) then
              wx1 = (lbemix(i)-lxp0)*slmicinv
           else
              wx1 = (lssx+lbemix(i)-lxp0)*slmicinv
           end if
           if( itrns .eq. 4 ) then
              wy = sbemyf(i)
              call c2flphs ( wx1, wy, i, wphmn )
           end if
!.
           wy = (1-lyp0)*slmicinv
           call c2flphs ( wx1, wy, i, wpht )
           if( itrns .eq. 4 ) then
              wpht = wpht - ( wpht - wphmn ) * sbemal(i)
           end if
           wphmx = wpht
           wy = (ky-lyp0)*slmicinv
           call c2flphs ( wx1, wy, i, wpht )
           if( itrns .eq. 4 ) then
              wpht = wpht - ( wpht - wphmn ) * sbemal(i)
           end if
           wphmx = max( wphmx, wpht )
           wtdlx = max( wtdlx, wphmx/(sbemomg(i)*sdelt) )
         end do
         do i = 1, llsrbn
           itrns = mod( lbemty(i)/10, 10 )
           if( itrns .eq. 4 ) then
              if( lbemix(i) .ge. 0 ) then
                wx1 = (lbemix(i)-lxp0)*slmicinv
              else
                wx1 = (lssx+lbemix(i)-lxp0)*slmicinv
              end if
              wy = sbemyf(i)
              call c2flphs ( wx1, wy, i, wphmn )
           end if
           do iy = 1, ky
             wy = (iy-lyp0)*slmicinv
!.
             if( lbemix(i) .ge. 0 ) then
                wx1 = (lbemix(i)-lxp0)*slmicinv
             else
                wx1 = (lssx+lbemix(i)-lxp0)*slmicinv
             end if
             call c2flphs( wx1, wy, i, wpht )
             if( itrns .eq. 4 ) then
               wpht = wpht - ( wpht - wphmn ) * sbemal(i)
             end if
             wphdl(1,iy,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
!.
             if( lbemix(i) .ge. 0 ) then
                wx1 = (lbemix(i)-s1o2-lxp0)*slmicinv
             else
                wx1 = (lssx+lbemix(i)+s1o2-lxp0)*slmicinv
             end if
             call c2flphs( wx1, wy, i, wpht )
             if( itrns .eq. 4 ) then
               wpht = wpht - ( wpht - wphmn ) * sbemal(i)
             end if
             wphdl(2,iy,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
!.
             if( lbemix(i) .ge. 0 ) then
                wx1 = (lbemix(i)-1-lxp0)*slmicinv
             else
                wx1 = (lssx+lbemix(i)+1-lxp0)*slmicinv
             end if
             call c2flphs( wx1, wy, i, wpht )
             if( itrns .eq. 4 ) then
               wpht = wpht - ( wpht - wphmn ) * sbemal(i)
             end if
             wphdl(3,iy,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
           end do
         end do
!..
         init = 1
      end if
!....
      itrns = mod( lbemty(kbn)/10, 10 )
      ipolm = lbemty(kbn) / 100
      if( lbemix(kbn) .ge. 0 ) then
         wsign = s1o1
      else
         wsign = -s1o1
      end if
!...                                                         * TM, CP *
      if( ipolm .ne. 2 ) then
         if( itrns .eq. 1 ) then
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wt,wlt,wamp)
            do iy = 1, ky
               wt  = lltcur + wphdl(1,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(1,iy) = wamp * wleatm(kbn) * sin( wlt + wph(kbn) )
!
               wt  = lltcur - s1o2 + wphdl(2,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(2,iy) = wsign * &
                            wamp * wlbatm(kbn) * sin( wlt + wph(kbn) )
!.
               wt  = lltcur + wphdl(3,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(3,iy) = wamp * wleatm(kbn) * sin( wlt + wph(kbn) )
            end do
#else
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               vwt(iy,1)  = lltcur + wphdl(1,iy,kbn)
               vwt(iy,2)  = lltcur - s1o2 + wphdl(2,iy,kbn)
               vwt(iy,3)  = lltcur + wphdl(3,iy,kbn)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               call c2flamp ( kbn, vwt(iy,1), vwamp(iy,1) )
               call c2flamp ( kbn, vwt(iy,2), vwamp(iy,2) )
               call c2flamp ( kbn, vwt(iy,3), vwamp(iy,3) )
            end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
            do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,1)
               fcom(1,iy) = vwamp(iy,1) * &
                            wleatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,2)
               fcom(2,iy) = vwamp(iy,2) * &
                            wsign * wlbatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,3)
               fcom(3,iy) = vwamp(iy,3) * &
                            wleatm(kbn) * sin( wlt + wph(kbn) )
            end do
!$OMP END PARALLEL
#endif
         else
!..
! Cutting the field at sbemmn level causes noise fields
! even if slstmn is 0.005, so calculations are extended
! upto the boundary.
! I'm not sure the factor of sqrt( cos(sbemanr(kbn)) ) for oblique
! laser, but it works.
            if( lbemix(kbn) .ge. 0 ) then
                wx1 = (lbemix(kbn)-lxp0)*slmicinv
                wx2 = (lbemix(kbn)-s1o2-lxp0)*slmicinv
                wx3 = (lbemix(kbn)-1-lxp0)*slmicinv
            else
                wx1 = (lssx+lbemix(kbn)-lxp0)*slmicinv
                wx2 = (lssx+lbemix(kbn)+s1o2-lxp0)*slmicinv
                wx3 = (lssx+lbemix(kbn)+1-lxp0)*slmicinv
            end if
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wy,wat,wt,wlt,wamp)
            do iy = 1, ky
               wy = (iy-lyp0)*slmicinv
!.
               call c2fltra( wx1, wy, kbn, wat )
               wt  = lltcur + wphdl(1,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(1,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                      wamp * wat * wleatm(kbn) * sin( wlt + wph(kbn) )
!.
               if( lbemix(kbn) .ge. 0 ) then
               else
               end if
               call c2fltra( wx2, wy, kbn, wat )
               wt  = lltcur - s1o2 + wphdl(2,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(2,iy) = sqrt( cos(sbemanr(kbn)) ) * &
              wsign * wamp * wat * wlbatm(kbn) * sin( wlt + wph(kbn) )
!.
               if( lbemix(kbn) .ge. 0 ) then
               else
               end if
               call c2fltra( wx3, wy, kbn, wat )
               wt  = lltcur + wphdl(3,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(3,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                      wamp * wat * wleatm(kbn) * sin( wlt + wph(kbn) )
            end do
#else
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               vwy(iy) = (iy-lyp0)*slmicinv
               vwt(iy,1) = lltcur + wphdl(1,iy,kbn)
               vwt(iy,2) = lltcur - s1o2 + wphdl(2,iy,kbn)
               vwt(iy,3) = lltcur + wphdl(3,iy,kbn)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               call c2fltra( wx1, vwy(iy), kbn, vwat(iy,1) )
               call c2flamp ( kbn, vwt(iy,1), vwamp(iy,1) )
               call c2fltra( wx2, vwy(iy), kbn, vwat(iy,2) )
               call c2flamp ( kbn, vwt(iy,2), vwamp(iy,2) )
               call c2fltra( wx3, vwy(iy), kbn, vwat(iy,3) )
               call c2flamp ( kbn, vwt(iy,3), vwamp(iy,3) )
            end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
            do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,1)
               fcom(1,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                            vwamp(iy,1) * vwat(iy,1) * &
                            wleatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,2)
               fcom(2,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                    wsign * vwamp(iy,2) * vwat(iy,2) * &
                            wlbatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,3)
               fcom(3,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                            vwamp(iy,3) * vwat(iy,3) * &
                            wleatm(kbn) * sin( wlt + wph(kbn) )
            end do
!$OMP END PARALLEL
#endif
         end if
      end if
!...                                                          * TE, CP *
      if( ipolm .ne. 1 ) then
         if( itrns .eq. 1 ) then
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wt,wlt,wamp)
            do iy = 1, ky
               wt  = lltcur - s1o2 + wphdl(1,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(4,iy) = &
              - wamp * wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
!
               wt  = lltcur + wphdl(2,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(5,iy) = wsign * &
                wamp * wleate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
!.
               wt  = lltcur - s1o2 + wphdl(3,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(6,iy) = &
              - wamp * wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
            end do
#else
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               vwt(iy,1)  = lltcur - s1o2 + wphdl(1,iy,kbn)
               vwt(iy,2)  = lltcur + wphdl(2,iy,kbn)
               vwt(iy,3)  = lltcur - s1o2 + wphdl(3,iy,kbn)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               call c2flamp ( kbn, vwt(iy,1), vwamp(iy,1) )
               call c2flamp ( kbn, vwt(iy,2), vwamp(iy,2) )
               call c2flamp ( kbn, vwt(iy,3), vwamp(iy,3) )
            end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
            do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,1)
               fcom(4,iy) = - vwamp(iy,1) * &
                       wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,2)
               fcom(5,iy) = vwamp(iy,2) * &
               wsign * wleate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,3)
               fcom(6,iy) = - vwamp(iy,3) * &
                       wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
            end do
!$OMP END PARALLEL
#endif
         else
!..
! Cutting the field at sbemmn level causes noise fields
! even if slstmn is 0.005, so calculations are extended
! upto the boundary.
! I'm not sure the factor of sqrt( cos(sbemanr(kbn)) ) for oblique
! laser, but it works.
            if( lbemix(kbn) .ge. 0 ) then
                wx1 = (lbemix(kbn)-lxp0)*slmicinv
                wx2 = (lbemix(kbn)-s1o2-lxp0)*slmicinv
                wx3 = (lbemix(kbn)-1-lxp0)*slmicinv
            else
                wx1 = (lssx+lbemix(kbn)-lxp0)*slmicinv
                wx2 = (lssx+lbemix(kbn)+s1o2-lxp0)*slmicinv
                wx3 = (lssx+lbemix(kbn)+1-lxp0)*slmicinv
            end if
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wy,wat,wt,wlt,wamp)
            do iy = 1, ky
               wy = (iy-lyp0)*slmicinv
!.
               call c2fltra( wx1, wy, kbn, wat )
               wt  = lltcur - s1o2 + wphdl(1,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(4,iy) = - sqrt( cos(sbemanr(kbn)) ) * &
         wamp * wat * wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
!.
               call c2fltra( wx2, wy, kbn, wat )
               wt  = lltcur + wphdl(2,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(5,iy) = sqrt( cos(sbemanr(kbn)) ) * &
 wsign * wamp * wat * wleate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
!.
               call c2fltra( wx3, wy, kbn, wat )
               wt  = lltcur - s1o2 + wphdl(3,iy,kbn)
               call c2flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(6,iy) = - sqrt( cos(sbemanr(kbn)) ) * &
         wamp * wat * wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
            end do
#else
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               vwy(iy) = (iy-lyp0)*slmicinv
               vwt(iy,1) = lltcur - s1o2 + wphdl(1,iy,kbn)
               vwt(iy,2) = lltcur + wphdl(2,iy,kbn)
               vwt(iy,3) = lltcur - s1o2 + wphdl(3,iy,kbn)
            end do
!$OMP DO SCHEDULE(STATIC)
            do iy = 1, ky
               call c2fltra( wx1, vwy(iy), kbn, vwat(iy,1) )
               call c2flamp ( kbn, vwt(iy,1), vwamp(iy,1) )
               call c2fltra( wx2, vwy(iy), kbn, vwat(iy,2) )
               call c2flamp ( kbn, vwt(iy,2), vwamp(iy,2) )
               call c2fltra( wx3, vwy(iy), kbn, vwat(iy,3) )
               call c2flamp ( kbn, vwt(iy,3), vwamp(iy,3) )
            end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
            do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,1)
               fcom(4,iy) = - sqrt( cos(sbemanr(kbn)) ) * &
                            vwamp(iy,1) * vwat(iy,1) * &
                       wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,2)
               fcom(5,iy) = sqrt( cos(sbemanr(kbn)) ) * &
                    wsign * vwamp(iy,2) * vwat(iy,2) * &
                       wleate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,3)
               fcom(6,iy) = - sqrt( cos(sbemanr(kbn)) ) * &
                            vwamp(iy,3) * vwat(iy,3) * &
                       wlbate(kbn) * sin( wlt + wph(kbn) + wphcp(kbn) )
            end do
!$OMP END PARALLEL
#endif
         end if
      end if
!....
      call fdebug ( 'c2flcom', 1 )
!....
      return
      end
