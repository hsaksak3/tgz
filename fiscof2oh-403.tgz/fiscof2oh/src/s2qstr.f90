!-------------------------------------------------------------------
! Set 2D Quiet STaRt
!                          /
      subroutine s2qstr ( kpc )
!
!   <arguments>
!     kpc : =-1 -> particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/07/14
! modified by Sakagami,H. (NIFS) 21/04/09
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use profile
      use constant
      use particle
      include "implicit.h"
#ifdef OHHELP
      include "mpif.h"
      integer :: ips=1, ierr
#else
      real*8  :: apfes(lpppx), acrct, anetc, apfis
#endif
      integer :: kpc
      integer :: i, io, ip, inoe,inoe0, inoi,inoi0, iionids, ity, iflg
      real*8  :: wfd, wfp, &
                 wute, wuti, wvte, wvti, wxs, wxe, wys, wye, &
                 wgam, wdxe, wdye, wdze, wran, wxx, wyy, &
                 wvxp, wvyp, wvxd, wvyd, wvxx, wvyy, wexp, wexd
      save
!....
      call fdebug ( 's2qstr', 0 )
!++++
      if( smasr .gt. 1.0d-29 ) then
         do ip = 1, lpppl
            if( lpppty(ip) .ne. -1 .and. lpppty(ip) .ne. -4 .and. &
                lpppty(ip) .ne. -7 ) then
              if( lpppis(ip) .lt. 1 .or. lpppis(ip) .gt. lionspl ) then
                write(0,*) '### ERROR: ion was not specified.',  &
                           ip, lpppis(ip)
                call s2ext_abort
              end if
            else
              if( lpppis(ip) .ne. 0 ) then
                write(0,*) &
           '### ERROR: ion was specified for lpppty<0.', ip, lpppis(ip)
                call s2ext_abort
              end if
            end if
         end do
      end if
!++++
!....
      inoe = 0
!....
      do ip = 1, lpppl
!..
         ity = lpppty(ip)
         if( lrank .le. 0 ) &
            write(6,*) 's2qstr(e)', ip, ity
!++++
         if( mod( abs(ity), 10 ) .le. 6 ) then
           if( spppds(ip)*spppde(ip) .lt. s0o1 .or. &
             (spppds(ip).eq.s0o1.and.spppde(ip).eq.s0o1) ) then
              write(0,*) '### ERROR: spppd[se].', spppds(ip), spppde(ip)
              call s2ext_abort
           end if
         else if( abs(ity) .eq. 7 .or. ity .eq. 8 ) then
           if( spppds(ip) .lt. s0o1 ) then
              write(0,*) '### ERROR: spppds.', spppds(ip)
              call s2ext_abort
           end if
         end if
!++++
         if( ity .ne. -1 .and. ity .ne. -4 .and. ity .ne. -7 ) then
            inoe0 = inoe
!..
            call qstrtpos ( ip, lnepme, s1o1,s1o1, spdat1,inoe,lnoex, &
                            kpc )
!----
      if( kpc .ne. -1 ) then
#ifndef OHHELP
            apfes(ip) = s0o1
            do i = inoe0+1, inoe
               apfes(ip) = apfes(ip) + spfe(i)
            end do
#endif
!.
            wvte = svte * sqrt( spppte(ip) )
            wute = wvte / sqrt( s1o1 - ( s3o1 * wvte**2 ) * scg1 )
            call qstrtvel ( wute, spdat1, inoe0, inoe, lnoex )
!.
            do i = inoe0+1, inoe
               suxe(i) = suxe(i) + spppudxe(ip)
               suye(i) = suye(i) + spppudye(ip)
               suze(i) = suze(i) + spppudze(ip)
            end do
      end if
!----
!..
         else
            wgam = sqrt( s1o1 + ( spppudxe(ip)**2 + spppudye(ip)**2 + &
                                  spppudze(ip)**2 ) * scg1 )
            wdxe = spppudxe(ip) / wgam * spppnp(ip)/( s1o1-spppnp(ip) )
            wdye = spppudye(ip) / wgam * spppnp(ip)/( s1o1-spppnp(ip) )
            wdze = spppudze(ip) / wgam * spppnp(ip)/( s1o1-spppnp(ip) )
            wgam = s1o1 / sqrt( s1o1 - ( wdxe**2 + wdye**2 + &
                                                     wdze**2 ) * scg1 )
            wdxe = wdxe * wgam
            wdye = wdye * wgam
            wdze = wdze * wgam
!.
            if( ity .eq. -1 ) then
              wys = min( spppyps(ip), spppype(ip) )
              wye = max( spppyps(ip), spppype(ip) )
              if( spppds(ip) .gt. s0o1 .or. spppde(ip) .gt. s0o1 ) then
                 wxs = min( spppxps(ip), spppxpe(ip) )
                 wxe =max(spppxps(ip)+spppds(ip),spppxpe(ip)+spppde(ip))
              else
                 wxs =min(spppxps(ip)+spppds(ip),spppxpe(ip)+spppde(ip))
                 wxe = max( spppxps(ip), spppxpe(ip) )
              end if
              wvxp = spppxpe(ip) - spppxps(ip)
              wvyp = spppype(ip) - spppyps(ip)
              wvxd = (spppxpe(ip)+spppde(ip))-(spppxps(ip)+spppds(ip))
              wvyd = wvyp
            else if( ity .eq. -4 ) then
              wxs = min( spppxps(ip), spppxpe(ip) )
              wxe = max( spppxps(ip), spppxpe(ip) )
              if( spppds(ip) .gt. s0o1 .or. spppde(ip) .gt. s0o1 ) then
                 wys = min( spppyps(ip), spppype(ip) )
                 wye =max(spppyps(ip)+spppds(ip),spppype(ip)+spppde(ip))
              else
                 wys =min(spppyps(ip)+spppds(ip),spppype(ip)+spppde(ip))
                 wye = max( spppyps(ip), spppype(ip) )
              end if
              wvxp = spppxpe(ip) - spppxps(ip)
              wvyp = spppype(ip) - spppyps(ip)
              wvxd = wvxp
              wvyd = (spppype(ip)+spppde(ip))-(spppyps(ip)+spppds(ip))
            end if
!..
            inoi  = 0
            inoi0 = 0
!..
!----
      if( kpc .ne. -1 ) then
            do i = 1, inoe
               wxx = ( sxe(i) - lxp0 ) * slmicinv
               wyy = ( sye(i) - lyp0 ) * slmicinv
               iflg = 0
!
               if( ity .eq. -1 ) then
                 if( wxx .ge. wxs .and. wxx .le. wxe .and. &
                     wyy .ge. wys .and. wyy .le. wye ) then
                    wvyy = wyy - spppyps(ip)
                    wvxx = wxx - spppxps(ip)
                    wexp = wvxx * wvyp - wvyy * wvxp
                    wvxx = wxx - (spppxps(ip)+spppds(ip))
                    wexd = wvxx * wvyd - wvyy * wvxd
                    if( wexp * wexd .lt. s0o1 ) iflg = 1
                 end if
               else if( ity .eq. -4 ) then
                 if( wxx .ge. wxs .and. wxx .le. wxe .and. &
                     wyy .ge. wys .and. wyy .le. wye ) then
                    wvxx = wxx - spppxps(ip)
                    wvyy = wyy - spppyps(ip)
                    wexp = wvxx * wvyp - wvyy * wvxp
                    wvyy = wyy - (spppyps(ip)+spppds(ip))
                    wexd = wvxx * wvyd - wvyy * wvxd
                    if( wexp * wexd .lt. s0o1 ) iflg = 1
                 end if
               else if( ity .eq. -7 ) then
                  if( (wxx-spppxps(ip))**2 + (wyy-spppyps(ip))**2 &
                                          .le. spppds(ip)**2 ) iflg = 1
               end if
               if( iflg .eq. 1 ) then
                  call mt_drand3 ( wran, 1 )
                  if( wran .le. spppnp(ip) ) then
                     suxe(i) = suxe(i) + spppudxe(ip)
                     suye(i) = suye(i) + spppudye(ip)
                     suze(i) = suze(i) + spppudze(ip)
                     inoi = inoi + 1
                   else
                     suxe(i) = suxe(i) - wdxe
                     suye(i) = suye(i) - wdye
                     suze(i) = suze(i) - wdze
                     inoi0 = inoi0 + 1
                   end if
                end if
            end do
            if( lrank .le. 0 ) &
            write(6,*) 'fast electron fraction', &
                                    spppnp(ip), real(inoi)/(inoi+inoi0)
      end if
!----
         end if
      end do
!..
      lnoe = inoe
      lnoes = 1
      lnoee = lnoes + lnoe - 1
      inoi = inoe
!....
      if( smasr .gt. 1.0d-29 ) then
         do io = 1, lionspl
         iionids = inoi + 1
!...
         do ip = 1, lpppl
         if( lpppis(ip) .eq. io ) then
!...
            ity = lpppty(ip)
            if( lrank .le. 0 ) &
               write(6,*) 's2qstr(i)', ip, ity
!...
            inoi0 = inoi
!..
            wfd = s1o1 / ( sionaz(io) * sionaf(io) )
            wfp = sionaf(io)
            call qstrtpos ( ip,lnipme(io),wfd,wfp, spdat1,inoi,lnox,&
                            kpc )
!----
      if( kpc .ne. -1 ) then
!..
#ifndef OHHELP
            apfis = s0o1
            do i = inoi0+1, inoi
               apfis = apfis + spfi(i)
            end do
            anetc = apfis * sionaz(io) - apfes(ip)
            acrct = - anetc / sionaz(io) / dble(inoi-inoi0)
            do i = inoi0+1, inoi
               spfi(i) = spfi(i) + acrct
            end do
#endif
!..
            wvti = svti(io) * sqrt( spppti(ip) )
            wuti = wvti / sqrt( s1o1 - ( s3o1 * wvti**2 ) * scg1 )
            call qstrtvel ( wuti, spdat1, inoi0, inoi, lnox )
!.
            do i = inoi0+1, inoi
               suxi(i) = suxi(i) + spppudxi(ip)
               suyi(i) = suyi(i) + spppudyi(ip)
               suzi(i) = suzi(i) + spppudzi(ip)
            end do
      end if
!----
         end if
!..
         end do
!..
         lionids(io) = iionids
         lionide(io) = inoi
         lionidl(io) = lionide(io)-lionids(io)+1
!++++
#ifndef OHHELP
         if( lionidl(io) .lt. 1 ) then
            write(0,*) '### ERROR: specified ion was not used.', io
            call s2ext_abort
         end if
#endif
!++++
         end do
!..
         lnois = lionids(1)
         lnoie = lionide(lionspl)
         lnoi  = lnoie - lnois + 1
!...
      else
         lnoi  = 0
         lnois = 0
         lnoie = -1
         lionspl = 0
      end if
!....
!----
      if( kpc .ne. -1 ) then
!----
      wxs =  1.0d30
      wys =  1.0d30
      wxe = -1.0d30
      wye = -1.0d30
      do i = lnoes, lnoee
         wxs = min( wxs, sxe(i) )
         wxe = max( wxe, sxe(i) )
         wys = min( wys, sye(i) )
         wye = max( wye, sye(i) )
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
!.
      do i = lnois, lnoie
         suui(i) = sqrt( suxi(i)**2 + suyi(i)**2 + suzi(i)**2 )
      end do
!..
#ifdef OHHELP
      call MPI_ALLREDUCE( MPI_IN_PLACE, wxe, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MAX, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wye, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MAX, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wxs, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MIN, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wys, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MIN, MPI_COMM_WORLD, ierr )
#endif
      lxps = wxs - 1
      lxpe = wxe + 2
      lyps = wys - 1
      lype = wye + 2
!----
      end if
!----
!....
      call fdebug ( 's2qstr', 1 )
!....
      return
      end
