!----------------------------------------------------------------------
! Observe 2D Particle Ion Energy (MeV)
!                          /
      subroutine o2pie ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     If change lpex here, must change in frames.f90.
!
!    coded by Sakagami,H. (NIFS) 12/05/30
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: lpex = 201, iun = 35, ifn = 15
      integer :: kflag, i, is, io, ig, iopie, ilog, iopiel
      real*8  :: wgam, &
                 wopiexps(lopiex), wopiexpe(lopiex), &
                 wopieyps(lopiex), wopieype(lopiex)
      real*8, allocatable :: apien(:,:,:)
      character :: clabel*20
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o2pie', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         do is = 1, lionspl
           do io = 1, iopiel
             do i = 1, lpex
               apien(i,io,is) = s0o1
             end do
           end do
         end do
!.
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
         do is = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:apien), &
!$OMP             PRIVATE(io,ig,wgam)
         do i = lionids(is), lionide(is)
          do io = 1, iopiel
            if(sxi(i).ge.sopiexps(io).and.sxi(i).le.sopiexpe(io) .and. &
               syi(i).ge.sopieyps(io).and.syi(i).le.sopieype(io)) then
               wgam = sqrt( s1o1 + suui(i)**2 * scg1 )
               ig = (wgam-s1o1)*scoft*sionmm(is)*sopiefct(io,is) + s1o1
               ig = min( ig, lpex )
               apien(ig,io,is) = apien(ig,io,is) + spfi(i)
             end if
           end do
         end do
         end do
#ifdef OHHELP
      end do  
#endif
!.
         if( iopie .le. 4 ) then
            write(iun) sstcur, &
                (((apien(i,io,is),i=1,lpex),io=1,iopiel),is=1,lionspl)
            flush(iun)
         end if
!.
         if( iopie .ge. 2 ) then
            do is = 1, lionspl
              call o2ionlabel ( is, sionam(is), sionaz(is), clabel )
              do io = 1, iopiel
                call o2pdraw1 ( bident, sstcur, sminlog, lminlog, &
                     ifn, ilog, apien(1,io,is), lpex, sopiefct(io,is), &
               wopiexps(io), wopieyps(io), wopiexpe(io), wopieype(io), &
                     'MeV', 'number[a.u.]', 'pie'//clabel ) 
              end do
            end do
         end if
!....
      else
         iopie  = mod( lopie, 10 )
         ilog   = mod( lopie/10, 10 )
         iopiel = mod( lopie/100, 10 )
!..
         if( .not. allocated(apien) ) &
            allocate(apien(lpex,iopiel,lionspl))
!..
         do io = 1, iopiel
            if( sopiexps(io) .le. sundef ) then
               sopiexps(io) = lxps
            else
               sopiexps(io) = sopiexps(io) * slmic + loxp0
            end if
            if( sopiexpe(io) .le. sundef ) then
               sopiexpe(io) = lxpe
            else
               sopiexpe(io) = sopiexpe(io) * slmic + loxp0
            end if
            if( sopieyps(io) .le. sundef ) then
               sopieyps(io) = lyps
            else
               sopieyps(io) = sopieyps(io) * slmic + loyp0
            end if
            if( sopieype(io) .le. sundef ) then
               sopieype(io) = lype
            else
               sopieype(io) = sopieype(io) * slmic + loyp0
            end if
            wopiexps(io) = ( sopiexps(io) - loxp0 ) * slmicinv
            wopiexpe(io) = ( sopiexpe(io) - loxp0 ) * slmicinv
            wopieyps(io) = ( sopieyps(io) - loyp0 ) * slmicinv
            wopieype(io) = ( sopieype(io) - loyp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopie[xy]p[se] = ', io, &
                wopiexps(io), wopieyps(io), wopiexpe(io), wopieype(io)
         end do
         if( iopie .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pie', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
            write(iun) 'pie2', bident, lpex, iopiel, lionspl, &
            ( (sionam(is),sionaz(is),is=1,lionspl), &
              (sopiefct(io,is),is=1,lionspl ), &
               wopiexps(io),wopieyps(io),wopiexpe(io),wopieype(io), &
               io=1,iopiel )
#else
            write(iun) 'pie3', bident, lpex, iopiel, lionspl, &
            ( (sionam(is),sionaz(is),is=1,lionspl), &
              (sopiefct(io,is),is=1,lionspl ), &
               wopiexps(io),wopieyps(io),wopiexpe(io),wopieype(io), &
               io=1,iopiel ), lrank, ldivx, ldivy
#endif
            flush(iun)
         end if
         if( iopie .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pie', bfile )
            call frames_file ( bfile, ifn, iopie )
         end if
!....
      end if
!....
      call fdebug ( 'o2pie', 1 )
!....
      return
      end
