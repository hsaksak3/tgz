!----------------------------------------------------------------------
! constants
!
module constant
      use ieee_arithmetic
      use parameter
      integer :: &
         lccsch, lrinit, lnepm, lnepme, lionspl,lnipme(lionspx),lminlog
      real*8 :: &
         sdelt, sgrid, snepm1, snepm1inv, sncmaxtl, &
         svte, svti(lionspx), smasr, stemr, sncinv, &
         slmic, slmicinv, scr, scfl, scflinv, sdtfs, &
         scr1, sce2, sce3, scb1, scb2, scb3, scj1, scj2, scj3, scg1, &
         scoee, scoei, scoef, scoeb, scofe, scofb, scofp, scoft, &
         scofe2, scofe2h, scofb2, scofb2h, &
         sundef, sundeff, sminlog, &
         s0o1, s1o2, s1o1, s3o2, s2o1, s3o1, s4o1, s1o6, s2o3, &
         spi, s2pi, sd2r
      character :: bident*16, bfile*128
      type(ieee_round_type) :: default_round_type
end module constant
