!-----------------------------------------------------------------------
! Advance 2D Field Electric - TM
!
      subroutine a2fetm
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'a2fetm', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
            sex(ix,iy) = sex(ix,iy)+(sbz(ix,iy+1)-sbz(ix,iy)) * scb1 + &
                                        sjxt(ix,iy) * scj1
            sey(ix,iy) = sey(ix,iy)+(sbz(ix,iy)-sbz(ix+1,iy)) * scb1 + &
                                        sjyt(ix,iy) * scj1
         end do
      end do
!.
!$OMP DO SCHEDULE(STATIC)
      do ix = lssxl, lssxup1
         sex(ix,lssylm1) = sex(ix,lssylm1) + &
                         ( sbz(ix,lssyl)-sbz(ix,lssylm1) ) * scb1 + &
                           sjxt(ix,lssylm1) * scj1
      end do
!$OMP DO SCHEDULE(STATIC)
      do iy = lssyl, lssyup1
         sey(lssxlm1,iy) = sey(lssxlm1,iy) + &
                         ( sbz(lssxlm1,iy)-sbz(lssxl,iy) ) * &
                           scb1 + sjyt(lssxlm1,iy) * scj1
      end do
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'a2fetm', 1 )
!....
      return
      end
