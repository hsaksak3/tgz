!-------------------------------------------------------------------
! QSTaRT with PROFile
!
      subroutine qstrtprof ( kms, kme, rn, kl, fnpm1, knpme, &
                            fpdat1, kcnt, kcntx, fmic, kpc )
!
!   <arguments>
!     kms   : i  : start mesh number
!     kme   : i  : end mesh number
!     rn    : i  : profile data
!     kl    : i  : size of "rn"
!     fnpm1 : i  : number of particle per mesh at profile = 1
!     knpme : i  : effective number of particle per mesh
!     fpdat1:  o : structure of particle data type 1
!     kcnt  : io : counter for structure
!     kcntx : i  : size of structure
!     fmic  : i  : factor from mesh number to micron
!     kpc   : i  : if kpc = -1 then particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 05/12/06
! modified by Sakagami,H. (NIFS) 21/04/13
!-------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use ptcltype
      include "implicit.h"
      real*8, parameter :: aeps=1.0d-3
      type(ty1_particle) :: fpdat1(kcntx)
      integer :: kpc
      integer :: kms, kme, kl, knpme, kcnt, kcntx, i, icnt, idum, &
                 iflag1, iflag2, im, imesh, ims, ino, inpme, ipos, ixe
      real*8  :: rn(kl), fnpm1, fmic, adxe, ai, aintgs, aintgd, &
                 an, ano, ancxe, anpm1, ax, adl
      save
!....
      call fdebug ( 'qstrtprof', 0 )
!....
      anpm1 = fnpm1 / 2
      inpme = knpme / 2
      ancxe = dble(inpme) / anpm1
      adl = 1.0d0 / inpme
!....
      ims = kms
      if( rn(ims) .lt. ancxe ) then
         iflag1 = -1
      else
         iflag1 = 1
      end if
!....                           * find greater or less than threshold *
      do im = kms+1, kme+1
!..
         if( rn(im) .lt. ancxe ) then
            iflag2 = -1
         else
            iflag2 = 1
         end if
!...                                                  * change flag ? *
         if( iflag1*iflag2 .lt. 0 .or. im .eq. kme+1 ) then
!..                                           * lower normal particle *
            if( iflag1 .lt. 0 ) then
               ano = 0.0d0
               do i = ims, im-1
                  ano = ano + rn(i)
               end do
               ino = ano * anpm1
!..
               aintgs = 0.0d0
               aintgd = ( rn(ims) + rn(ims+1) ) * 0.5d0
               ipos   = ims
               icnt   = kcnt
!..
               do i = 1, ino
                  do idum = 1, 10000
!.
                     ai = i / anpm1 - aintgs
!.
                     if( ai-aintgd .le. 0.0d0 ) then
                        if( abs(rn(ipos+1)-rn(ipos)).gt.aeps ) then
                           ax = ( dsqrt( &
                          rn(ipos)**2+2.d0*(rn(ipos+1)-rn(ipos))*ai) - &
                          rn(ipos) ) / (rn(ipos+1) - rn(ipos) )
                        else
                           ax = ai / rn(ipos)
                        end if
!----
      if( kpc .ne. -1 ) then
!+++
      if( kcnt+2 .gt. kcntx ) then
         write(0,*) '### ERROR: overflow in qstrtprof#1', kcntx,im
         call s2ext_abort
      end if
!+++
      end if
!----
#ifdef OHHELP
                        oh_pcnt = oh_pcnt + 2
                        oh_cyc  = ( oh_pcnt - 1 ) / oh_blkcyc
                        oh_rank = mod( oh_cyc, oh_lsize )
                        if( oh_rank .ne. lrank ) go to 10
#endif

                        kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                        fpdat1(kcnt)%x  = ax + ipos
                        fpdat1(kcnt)%pf = 1.0d0
      end if
!----
                        kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                        fpdat1(kcnt)%x  = fpdat1(kcnt-1)%x
                        fpdat1(kcnt)%pf = fpdat1(kcnt-1)%pf
      end if
!----
                        go to 10
                     else
                        ipos = ipos + 1
                        if( ipos .ge. im-1 ) go to 11
                        aintgs = aintgs + aintgd
                        aintgd = ( rn(ipos) + rn(ipos+1) ) * 0.5d0
                     end if
                  end do
                  write(0,*) '### ERROR: no integral point', i,im, &
                              ino, ano
                  call s2ext_abort
   10             continue
               end do
   11          continue
!.                                       * higher collective particle *
            else
!----
      if( kpc .ne. -1 ) then
!+++
      if( kcnt+(im-2-ims)*knpme .gt. kcntx ) then
         write(0,*) '### ERROR: overflow in qstrtprof#2', kcntx,im
         call s2ext_abort
      end if
!+++
      end if
!----
               icnt   = kcnt
               do imesh = ims, im-2
                  do i = 1, inpme
                     ax = (i-0.5d0)*adl + imesh
                     ixe = ax
                     adxe = ax - ixe
                     an= rn(ixe)*(1.0d0-adxe) + rn(ixe+1)*adxe
#ifdef OHHELP
                     oh_pcnt = oh_pcnt + 2
                     oh_cyc  = ( oh_pcnt - 1 ) / oh_blkcyc
                     oh_rank = mod( oh_cyc, oh_lsize )
                     if( oh_rank .ne. lrank ) cycle
#endif
                     kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                     fpdat1(kcnt)%x = ax
                     fpdat1(kcnt)%pf = an / ancxe
      end if
!----
                     kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                     fpdat1(kcnt)%x  = fpdat1(kcnt-1)%x
                     fpdat1(kcnt)%pf = fpdat1(kcnt-1)%pf
      end if
!----
                  end do
               end do
            end if
!.                                              * connection boundary *
            if( im .le. kme ) then
!----
      if( kpc .ne. -1 ) then
!+++
      if( kcnt+knpme .gt. kcntx ) then
         write(0,*) '### ERROR: overflow in qstrtprof#3', kcntx,im
         call s2ext_abort
      end if
!+++
      end if
!----
               icnt   = kcnt
               do i = 1, inpme
                  ax = (i-0.5d0)*adl + im-1
                  ixe = ax
                  adxe = ax - ixe
                  an = rn(ixe)*(1.0d0-adxe) + rn(ixe+1)*adxe
                  an = max( ancxe, an )
#ifdef OHHELP
                  oh_pcnt = oh_pcnt + 2
                  oh_cyc  = ( oh_pcnt - 1 ) / oh_blkcyc
                  oh_rank = mod( oh_cyc, oh_lsize )
                  if( oh_rank .ne. lrank ) cycle
#endif
                  kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                  fpdat1(kcnt)%x = ax
                  fpdat1(kcnt)%pf = an / ancxe
      end if
!----
                  kcnt = kcnt + 1
!----
      if( kpc .ne. -1 ) then
                  fpdat1(kcnt)%x  = fpdat1(kcnt-1)%x
                  fpdat1(kcnt)%pf = fpdat1(kcnt-1)%pf
      end if
!----
               end do
!..
               ims = im
               iflag1 = iflag2
            end if
         end if
!..
      end do
!....
      call fdebug ( 'qstrtprof', 1 )
!....
      return
      end
