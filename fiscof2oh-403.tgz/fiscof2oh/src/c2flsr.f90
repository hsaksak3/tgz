!----------------------------------------------------------------------
! Compute 2D Field LaSeR
!
      subroutine c2flsr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/17
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use laserprf
      include "implicit.h"
      integer :: i, ipolm, iy, id, ip1, ip2, ip3, iyy
      real*8  :: wamp, wlt, wlth
      real*8, allocatable :: wlsr(:,:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2flsr', 0 )
!....
      if( .not. allocated(wlsr) ) allocate( wlsr(6,lssyp1) )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
      oh_ixe = oh_sdoms(2,1,oh_sdid(ips)+1) - 1
      oh_iye = oh_sdoms(2,2,oh_sdid(ips)+1) - 1
#endif
      if( llsrty .lt. 0 ) then
         ip1 = llinx
         iyy = lliny
#ifdef OHHELP
         if( ip1 .le. oh_ixs .or. ip1 .gt. oh_ixe ) cycle 
         if( iyy .le. oh_iys .or. iyy .gt. oh_iye ) cycle 
         ip1 = ip1 - oh_ixs + 1
         iyy = iyy - oh_iys + 1
#endif
         if( llsrty .eq. -1 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy) = sbz(ip1,iyy) +  &
                                        wamp * sin( slomg*sdelt*wlth )
         else if( llsrty .eq. -2 ) then
            wlt = lltcur
            if( wlt*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 )
            else
               wamp = s0o1
            end if
            sez(ip1,iyy) = sez(ip1,iyy) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         else if( llsrty .eq. -3 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy) = sbz(ip1,iyy) +  &
                                        wamp * sin( slomg*sdelt*wlth )
            wamp = wamp * scfl
            wlt = lltcur
            sez(ip1,iyy) = sez(ip1,iyy) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         else if( llsrty .eq. -4 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = slinjy
            else
               wamp = s0o1
            end if
            do iy = lssyl, lssyup1
               sjyt(ip1,iy) = wamp * sin( slomg*sdelt*wlth )
            end do
         else if( llsrty .eq. -5 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = slinjy
            else
               wamp = s0o1
            end if
            sjzt(ip1,iyy) = wamp
         end if
      else
         do i = 1, llsrbn
            if( lbemix(i) .ge. 0 ) then
               ip1 = lbemix(i)
               ip2 = lbemix(i)
               ip3 = lbemix(i) - 1
            else
               ip1 = lssx + lbemix(i)
               ip2 = lssx + lbemix(i) + 1
               ip3 = lssx + lbemix(i) + 1
            end if
#ifdef OHHELP
            if( ip1 .le. oh_ixs .or. ip1 .gt. oh_ixe ) cycle 
            if( ip3 .le. oh_ixs .or. ip3 .gt. oh_ixe ) then 
               write(0,*) &
                 '### ERROR: ip1 & ip3 must be in same subdomain', &
                 i,ip1,ip3
               call s2ext_abort
            end if
            ip1 = ip1 - oh_ixs + 1
            ip2 = ip2 - oh_ixs + 1
            ip3 = ip3 - oh_ixs + 1
#endif
!..
            call c2flcom ( i, wlsr, 6, lssyp1 )
!..
            ipolm = lbemty(i) / 100
!.                                                   * TM, CP *
            if( ipolm .ne. 2 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyy)
               do iy = lssyl, lssyup1
                  iyy = iy
#ifdef OHHELP
                  iyy = iyy + oh_iys
#endif
                  sey(ip1,iy) = sey(ip1,iy) + wlsr(1,iyy)
                  sbz(ip2,iy) = sbz(ip2,iy) + wlsr(2,iyy)
                  sey(ip3,iy) = sey(ip3,iy) + wlsr(3,iyy)
               end do
            end if
!.                                                   * TE, CP *
            if( ipolm .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyy)
               do iy = lssyl, lssyup1
                  iyy = iy
#ifdef OHHELP
                  iyy = iyy + oh_iys
#endif
                  sby(ip1,iy) = sby(ip1,iy) + wlsr(4,iyy)
                  sez(ip2,iy) = sez(ip2,iy) + wlsr(5,iyy)
                  sby(ip3,iy) = sby(ip3,iy) + wlsr(6,iyy)
               end do
            end if
         end do
      end if
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c2flsr', 1 )
!....
      return
      end
