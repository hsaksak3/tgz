!----------------------------------------------------------------------
! Observe 2D Field Electric Amplitude
!                          /
      subroutine o2fea ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 22, ifn = 3
      integer :: kflag, i, iofea, icrsx, icrsy, ix, iy, ixy, iweaa
      real*8  :: wcofe2
      real*8, allocatable :: weaa(:)
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o2fea', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iweaa = iweaa + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               weaa(ixy) = weaa(ixy) + &
                           ( ( sex(ix,iy-1) + sex(ix,iy) )*s1o2 )**2 + &
                           ( ( sey(ix-1,iy) + sey(ix,iy) )*s1o2 )**2 + &
                                              sez(ix,iy)**2
            end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            if( iweaa .eq. 1 ) then
               wcofe2 = scofe2h
            else
               wcofe2 = scofe2 / iweaa
            end if
            do i = 1, loxypl
               weaa(i) = weaa(i)  * wcofe2
            end do
            if( iofea .le. 4 ) then
               write(iun) sstcur, ( weaa(i),i=1,loxypl )
               flush(iun)
            end if
            if( iofea .ge. 2 ) then
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                               ifn, 0, 1, icrsx, icrsy, &
                               weaa, loxpl, loypl, &
                               soxmic, soxp0m, soymic, soyp0m, 'fea ' )
            end if
          end if
!....
         else
            iofea = mod( lofea, 10 )
            icrsx = mod( lofea/100, 100 )
            icrsy = lofea/10000
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(weaa) ) allocate( weaa(loxypl) )
            end if
!
            if( iofea .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fea', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fea2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               write(iun) 'fea3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if( iofea .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fea', bfile )
               call frames_file ( bfile, ifn, iofea )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iweaa = 0
            do i = 1, loxypl
               weaa(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fea', 1 )
!....
      return
      end
