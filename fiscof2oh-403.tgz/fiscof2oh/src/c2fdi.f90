!-----------------------------------------------------------------------
! Compute 2D Field Density Ion
!
      subroutine c2fdi
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
      use oh_param
#endif
      use parameter
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, ixi, iyi
      real*8  :: wdx,wx1,wx2,wx3,wx4,wdy,wy1,wy2,wy3,wy4
#ifndef OHHELP
      real*8, allocatable :: wdi(:,:)
#else
      real*8, allocatable :: oh_wdi(:,:,:,:)
      integer :: ips
#endif
      save
!....
      call fdebug ('c2fdi', 0 )
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
!....
      if( .not. allocated(wdi) ) &
         allocate( wdi(lssxlm1:lssxup1,lssylm1:lssyup1) )
!....
!$OMP PARALLEL PRIVATE(io, &
!$OMP                  ixi,wdx,wx1,wx2,wx3,wx4,iyi,wdy,wy1,wy2,wy3,wy4)
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
               wdi(ix,iy) = s0o1
            end do
         end do
!..
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wdi)
         do i = lionids(io), lionide(io)
            ixi = sxi(i)
            wdx = sxi(i) - ixi - s1o2
            wx1 = (s1o2-wdx)**3*s1o6
            wx2 = (s1o2+wdx)**2*(wdx-s3o2)*s1o2 + s2o3
            wx3 =-(s1o2-wdx)**2*(wdx+s3o2)*s1o2 + s2o3
            wx4 = (s1o2+wdx)**3*s1o6
!.
            iyi = syi(i)
            wdy = syi(i) - iyi - s1o2
            wy1 = (s1o2-wdy)**3*s1o6
            wy2 = (s1o2+wdy)**2*(wdy-s3o2)*s1o2 + s2o3
            wy3 =-(s1o2-wdy)**2*(wdy+s3o2)*s1o2 + s2o3
            wy4 = (s1o2+wdy)**3*s1o6
!..
            wdi(ixi-1,iyi-1) = wdi(ixi-1,iyi-1) + spfi(i) * wx1 * wy1
            wdi(ixi,  iyi-1) = wdi(ixi,  iyi-1) + spfi(i) * wx2 * wy1
            wdi(ixi+1,iyi-1) = wdi(ixi+1,iyi-1) + spfi(i) * wx3 * wy1
            wdi(ixi+2,iyi-1) = wdi(ixi+2,iyi-1) + spfi(i) * wx4 * wy1
!.
            wdi(ixi-1,iyi  ) = wdi(ixi-1,iyi  ) + spfi(i) * wx1 * wy2
            wdi(ixi,  iyi  ) = wdi(ixi,  iyi  ) + spfi(i) * wx2 * wy2
            wdi(ixi+1,iyi  ) = wdi(ixi+1,iyi  ) + spfi(i) * wx3 * wy2
            wdi(ixi+2,iyi  ) = wdi(ixi+2,iyi  ) + spfi(i) * wx4 * wy2
!.
            wdi(ixi-1,iyi+1) = wdi(ixi-1,iyi+1) + spfi(i) * wx1 * wy3
            wdi(ixi,  iyi+1) = wdi(ixi,  iyi+1) + spfi(i) * wx2 * wy3
            wdi(ixi+1,iyi+1) = wdi(ixi+1,iyi+1) + spfi(i) * wx3 * wy3
            wdi(ixi+2,iyi+1) = wdi(ixi+2,iyi+1) + spfi(i) * wx4 * wy3
!.
            wdi(ixi-1,iyi+2) = wdi(ixi-1,iyi+2) + spfi(i) * wx1 * wy4
            wdi(ixi,  iyi+2) = wdi(ixi,  iyi+2) + spfi(i) * wx2 * wy4
            wdi(ixi+1,iyi+2) = wdi(ixi+1,iyi+2) + spfi(i) * wx3 * wy4
            wdi(ixi+2,iyi+2) = wdi(ixi+2,iyi+2) + spfi(i) * wx4 * wy4
         end do
!...
         if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do iy = lssylm1, lssyup1
               wdi(lssxlm1,iy) = wdi(lssxlm1,iy) + wdi(lssxum1,iy)
               wdi(lssxl  ,iy) = wdi(lssxl  ,iy) + wdi(lssxu  ,iy)
               wdi(lssxlp1,iy) = wdi(lssxlp1,iy) + wdi(lssxup1,iy)
            end do
         end if
         if( lexupi .eq. 1 ) then
            if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm1, lssyup1
                  wdi(lssxum1,iy) = wdi(lssxlm1,iy)
                  wdi(lssxu  ,iy) = wdi(lssxl  ,iy)
                  wdi(lssxup1,iy) = wdi(lssxlp1,iy)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do iy = lssylm1, lssyup1
                  wdi(lssxum1,iy) = wdi(lssxlm1,iy) + wdi(lssxum1,iy)
                  wdi(lssxu  ,iy) = wdi(lssxl  ,iy) + wdi(lssxu  ,iy)
                  wdi(lssxup1,iy) = wdi(lssxlp1,iy) + wdi(lssxup1,iy)
               end do
            end if
         end if
!.
         if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
            do ix = lssxlm1, lssxup1
               wdi(ix,lssylm1) = wdi(ix,lssylm1) + wdi(ix,lssyum1)
               wdi(ix,lssyl  ) = wdi(ix,lssyl  ) + wdi(ix,lssyu  )
               wdi(ix,lssylp1) = wdi(ix,lssylp1) + wdi(ix,lssyup1)
            end do
         end if
         if( leyupi .eq. 1 ) then
            if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm1, lssxup1
                  wdi(ix,lssyum1) = wdi(ix,lssylm1)
                  wdi(ix,lssyu  ) = wdi(ix,lssyl  )
                  wdi(ix,lssyup1) = wdi(ix,lssylp1)
               end do
            else
!$OMP DO SCHEDULE(STATIC)
               do ix = lssxlm1, lssxup1
                  wdi(ix,lssyum1) = wdi(ix,lssylm1) + wdi(ix,lssyum1)
                  wdi(ix,lssyu  ) = wdi(ix,lssyl  ) + wdi(ix,lssyu  )
                  wdi(ix,lssyup1) = wdi(ix,lssylp1) + wdi(ix,lssyup1)
               end do
            end if
         end if
!...
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
               sdi(ix,iy,io) = wdi(ix,iy)
            end do
         end do
!...
      end do
!$OMP END PARALLEL
!..
      lcfdi = 1
!....
      end if
#else
      if( oh_glnoi .gt. 0 ) then
!....
      if( .not. allocated(oh_wdi) ) &
         allocate( oh_wdi(lionspl,&
                    oh_alosizes(1,1,FDI):oh_alosizes(2,1,FDI), &
                    oh_alosizes(1,2,FDI):oh_alosizes(2,2,FDI),2) )
!....
      oh_wdi(:,:,:,:) = s0o1
!....
      do ips = 1,2
        if(oh_lnoi(ips) .le. 0 ) cycle
        oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
        oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
        do io = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wdi), &
!$OMP          PRIVATE(ixi,iyi)
          do i = oh_lionids(io,ips), oh_lionide(io,ips)
            ixi = sxi(i) - oh_ixs
            iyi = syi(i) - oh_iys
            oh_wdi(io,ixi,iyi,ips) = oh_wdi(io,ixi,iyi,ips) + spfi(i)
          end do
        end do
      end do
!.
      call oh3_reduce_field ( oh_wdi(1,1,1,1), oh_wdi(1,1,1,2), FDI )
!.
      do io = 1, lionspl
        do iy = oh_alosizes(1,2,FDI), oh_alosizes(2,2,FDI)
          do ix = oh_alosizes(1,1,FDI), oh_alosizes(2,1,FDI)
            sdi(ix,iy,io) = oh_wdi(io,ix,iy,1)
          end do
        end do
      end do
!..
      lcfdi = 1
!....
      end if
#endif
!....
      call fdebug ( 'c2fdi', 1 )
!....
      return
      end
