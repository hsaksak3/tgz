!----------------------------------------------------------------------
! Observe 2D Field magnetic(B) Amplitude
!                          /
      subroutine o2fba ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 24, ifn = 5
      integer :: kflag, i, iofba, incl, icrsx, icrsy, ix, iy, ixy, iwbaa
      real*8  :: wcofb2
      real*8, allocatable :: wbaa(:)
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o2fba', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwbaa = iwbaa + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               if( incl .eq. 0 ) then
                  wbaa(ixy) = wbaa(ixy) + sqrt( &
                     ( ( sbx(ix,iy-1) + sbx(ix,iy) )*s1o2 )**2 + &
                     ( ( sby(ix-1,iy) + sby(ix,iy) )*s1o2 )**2 + &
                                                 sbz(ix,iy)**2 )
               else
                  wbaa(ixy) = wbaa(ixy) + sqrt( &
                  ( ( sbx(ix,iy-1) + sbx(ix,iy) )*s1o2 + sextbx )**2 + &
                  ( ( sby(ix-1,iy) + sby(ix,iy) )*s1o2 + sextby )**2 + &
                                          ( sbz(ix,iy) + sextbz )**2 )
               end if
            end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
!unit       if( iwbaa .eq. 1 ) then
!unit          wcofb2 = scofb2h
!unit       else
!unit          wcofb2 = scofb2 / iwbaa
!unit       end if
            do i = 1, loxypl
!unit          wbaa(i) = wbaa(i) * wcofb2
               wbaa(i) = wbaa(i) / iwbaa * scofb
            end do
            if( iofba .le. 4 ) then
               write(iun) sstcur, ( wbaa(i),i=1,loxypl )
               flush(iun)
            end if
            if( iofba .ge. 2 ) then
               call o2fdraw1 ( bident, sstcur, sminlog, lminlog, &
                            ifn, 0, 1, icrsx, icrsy, &
                            wbaa, loxpl, loypl,  &
                            soxmic, soxp0m, soymic, soyp0m, 'fba[MG]' )
            end if
          end if
!....
         else
            iofba = mod( lofba, 10 )
            incl  = mod( lofba/10, 10 )
            icrsx = mod( lofba/100, 100 )
            icrsy = lofba/10000
!..
            if( loxypl .gt. 0 ) then
              if( .not. allocated(wbaa) ) allocate( wbaa(loxypl) )
            end if
!
            if( iofba .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fba', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               write(iun) 'fba2', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               write(iun) 'fba3', bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
            end if
            if( iofba .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fba', bfile )
               call frames_file ( bfile, ifn, iofba )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwbaa = 0
            do i = 1, loxypl
               wbaa(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fba', 1 )
!....
      return
      end
