!----------------------------------------------------------------------
! Observe 2D Field magnetic(B) Raw
!                          /
      subroutine o2fbr ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 25, ifn = 6
      integer :: kflag, i, iofbr, icrsx, icrsy, ix, iy, ixy, iwbra, &
                 incl, inst
      real*8, allocatable :: wbxa(:), wbya(:), wbza(:), &
                             wbxi(:), wbyi(:), wbzi(:)
      character(4) :: chead
#ifdef OHHELP
      integer :: ips=1
!       integer, parameter :: iun2 = 65
!       integer :: ixsize, iysize
#endif
      save
!....
      call fdebug ( 'o2fbr', 0 )
!....
      if( kflag .ge. 2 .and. loxypl .gt. 0 ) then
         iwbra = iwbra + 1
         ixy = 0
         do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
               ixy = ixy + 1
               wbxa(ixy) = wbxa(ixy) + sbx(ix,iy)
               wbya(ixy) = wbya(ixy) + sby(ix,iy)
               wbza(ixy) = wbza(ixy) + sbz(ix,iy)
               if( incl .ne. 0 ) then
                  wbxa(ixy) = wbxa(ixy) + sextbx
                  wbya(ixy) = wbya(ixy) + sextby
                  wbza(ixy) = wbza(ixy) + sextbz
               end if
            end do
         end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxypl .gt. 0 ) then
            do i = 1, loxypl
               wbxa(i) = wbxa(i) / iwbra * scofb
               wbya(i) = wbya(i) / iwbra * scofb
               wbza(i) = wbza(i) / iwbra * scofb
            end do
!
            if( inst .ne. 0 ) then
               ixy = 0
               do iy = loyps, loype, loypi
                  do ix = loxps, loxpe, loxpi
                     ixy = ixy + 1
                     wbxi(ixy) = sbx(ix,iy) * scofb
                     wbyi(ixy) = sby(ix,iy) * scofb
                     wbzi(ixy) = sbz(ix,iy) * scofb
                     if( incl .ne. 0 ) then
                        wbxi(ixy) = wbxi(ixy) + sextbx * scofb
                        wbyi(ixy) = wbyi(ixy) + sextby * scofb
                        wbzi(ixy) = wbzi(ixy) + sextbz * scofb
                     end if
                  end do
               end do
            end if
!.
            if( iofbr .le. 4 ) then
              if( inst .eq. 0 ) then
                write(iun) sstcur, (wbxa(i),wbya(i),wbza(i),i=1,loxypl)
              else
                write(iun) sstcur,(wbxa(i),wbya(i),wbza(i),i=1,loxypl),&
                                  (wbxi(i),wbyi(i),wbzi(i),i=1,loxypl)
              end if
              flush(iun)
            end if
            if( iofbr .ge. 2 ) then
               call o2fdraw3 ( bident, sstcur, ifn, 2, icrsx, icrsy, &
                            wbxa, wbya, wbza, loxpl, loypl, &
                            soxmic, soxp0m, soymic, soyp0m, &
                            'fbxr[MG]', 'fbyr[MG]', 'fbzr[MG]' ) 
               if( inst .ne. 0 ) &
                  call o2fdraw3 ( bident, sstcur, ifn, 2,icrsx,icrsy, &
                            wbxi, wbyi, wbzi, loxpl, loypl, &
                            soxmic, soxp0m, soymic, soyp0m, &
              'fbxr(inst.)[MG]', 'fbyr(inst.)[MG]', 'fbzr(inst.)[MG]' ) 
            end if
          end if
! #ifdef OHHELP
!           write(iun2) sstcur, oh_sbxyz, oh_sdid
!           flush(iun2)
! #endif
!....
         else
            iofbr = mod( lofbr, 10 )
            incl  = mod( lofbr/10, 10 )
            icrsx = mod( lofbr/100, 100 )
            icrsy = mod( lofbr/10000, 100 )
            inst  = lofer / 1000000
!..
            if( loxypl .gt. 0 ) then
               if( .not. allocated(wbxa) ) &
                  allocate( wbxa(loxypl), wbya(loxypl), wbza(loxypl) )
               if( inst .ne. 0 ) then
                  if( .not. allocated(wbxi) ) &
                    allocate( wbxi(loxypl), wbyi(loxypl), wbzi(loxypl) )
               end if
            end if
!
            if( iofbr .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fbr', bfile )
               open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
               chead = 'fbr2'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m
#else
               chead = 'fbr3'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxypl, loxpl, loypl, &
                                     soxmic, soxp0m, soymic, soyp0m, &
                                                lrank, ldivx, ldivy, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae
#endif
               flush(iun)
! #ifdef OHHELP
!                ixsize = size( oh_sbxyz, 2 )
!                iysize = size( oh_sbxyz, 3 )
!                call fntpcnv ( bbifntp, lrank,iun2, bident,'fbr', bfile )
!                open( iun2, file=bfile, form='UNFORMATTED' )
!                write(iun2) 'fbrd', bident, ixsize, iysize, &
!                            lrank, ldivx, ldivy
!                flush(iun2)
! #endif
            end if
            if( iofbr .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fbr', bfile )
               call frames_file ( bfile, ifn, iofbr )
            end if
         end if
         if( loxypl .gt. 0 ) then
            iwbra = 0
            do i = 1, loxypl
               wbxa(i) = s0o1
               wbya(i) = s0o1
               wbza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o2fbr', 1 )
!....
      return
      end
