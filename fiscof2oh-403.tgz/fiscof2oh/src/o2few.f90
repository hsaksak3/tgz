!----------------------------------------------------------------------
! Observe 2D Field Electric W (Omega) frequency spectrum
!                          /
      subroutine o2few ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output (last)
!                  2 = add and output if full
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/06/02
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use laserprf
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 32
      integer :: kflag, i, ii, iii, ix, iy, iofew, iofewl, icnt
      real*8  :: wdelt
      real*8, allocatable :: wfew(:,:,:)
#ifdef OHHELP
      integer :: ips=1, iposl
      integer, allocatable :: ipos(:)
#endif
      save
!....
      call fdebug ( 'o2few', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         if( kflag .eq. 1 .or. icnt .eq. ltimex ) then
            if( iofew .le. 4 ) then
               write(iun) sstcur, kflag, icnt, &
                  ((( wfew(iii,ii,i),iii=1,3),ii=1,icnt),i=1,iofewl)
               flush(iun)
            end if
            icnt = 0
         end if
!..
         if( kflag .ge. 2 ) then
            icnt = icnt + 1
            do i = 1, iofewl
#ifndef OHHELP
               ix = sofewxp(i) * slmic + loxp0
               iy = sofewyp(i) * slmic + loyp0
#else
               ix = sofewxp(ipos(i)) * slmic + loxp0 - &
                    oh_sdoms(1,1,oh_sdid(ips)+1) + 1
               iy = sofewyp(ipos(i)) * slmic + loyp0 - &
                    oh_sdoms(1,2,oh_sdid(ips)+1) + 1
#endif
               wfew(1,icnt,i) = ( sex(ix,iy-1) + sex(ix,iy) )*s1o2
               wfew(2,icnt,i) = ( sey(ix-1,iy) + sey(ix,iy) )*s1o2
               wfew(3,icnt,i) =   sez(ix,iy)
            end do
         end if
!....
      else
         iofew  = mod( lofew, 10 )
         iofewl = lofew/100
#ifdef OHHELP
         iposl = 0
         if( .not. allocated(ipos) ) allocate( ipos(iofewl) )
#endif
!..
         do i = 1, iofewl
            ix = sofewxp(i) * slmic + loxp0
            iy = sofewyp(i) * slmic + loyp0
#ifndef OHHELP
            write(6,*) '@@@ o2few', i, ix, iy
#else
            if( ix .lt. oh_sdoms(1,1,oh_sdid(1)+1) ) cycle
            if( ix .ge. oh_sdoms(2,1,oh_sdid(1)+1) ) cycle
            if( iy .lt. oh_sdoms(1,2,oh_sdid(1)+1) ) cycle
            if( iy .ge. oh_sdoms(2,2,oh_sdid(1)+1) ) cycle
!
            iposl = iposl + 1
            ipos(iposl) = i
            write(6,*) '@@@ o2few', i, ix, iy
#endif
         end do
#ifdef OHHELP
         iofewl = iposl
#endif
         if( iofewl .gt. 0 ) then
           if( .not. allocated(wfew) ) allocate( wfew(3,ltimex,iofewl) )
         end if
!
         if( iofew .le. 4 ) then
            wdelt = s2pi / ( sdelt * slomg )
            call fntpcnv ( bbifntp, lrank,iun, bident,'few', bfile )
            open( iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
            write(iun) 'few2', bident, wdelt, iofewl, &
                                (sofewxp(i), sofewyp(i), i=1,iofewl)
#else
            write(iun) 'few3', bident, wdelt, iofewl, &
                     (sofewxp(ipos(i)), sofewyp(ipos(i)), i=1,iofewl), &
                                                    lrank, ldivx, ldivy
#endif
            flush(iun)
         end if
!..
         icnt = 0
      end if
!....
      call fdebug ( 'o2few', 1 )
!....
      return
      end
