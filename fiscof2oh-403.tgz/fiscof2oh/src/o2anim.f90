!----------------------------------------------------------------------
! Observe 2D ANIMation
!
      subroutine o2anim
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#endif
      use parameter
      use constant
      use particle
      use field
      use animation
      use observe
      include "implicit.h"
      integer :: i, icol, io, it, ix, ixx, iy, iyy, int, ixz, ilog
      real*8  :: wvv
      real*8, allocatable :: work(:,:)
      character*4 clab
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o2anim', 0 )
!....
      if( .not. allocated(work) ) allocate( work(lssxu,lssyu) )
!....
      call gdfxs_bodys
!....
      if( lafeal .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = ( ( sex(ix,iy-1)+sex(ix,iy) )*s1o2 )**2 + &
                            ( ( sey(ix-1,iy)+sey(ix,iy) )*s1o2 )**2 + &
                                             sez(ix,iy)**2
            end do
         end do
         do it = 1, lafeal
            call gdfxs_body22 ( lafeagt(it), work,1,lssxu,1,lssyu, 10, &
        6, scofe2h,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fea' )
         end do
      end if
!..
      if( lafexl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sex(ix,iy)
            end do
         end do
         do it = 1, lafexl
            call gdfxs_body22 ( lafexgt(it), &
                                work,1,lssxu,1,lssyu,11, &
          7, scofe,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fex' )
         end do
      end if
!..
      if( lafeyl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sey(ix,iy)
            end do
         end do
         do it = 1, lafeyl
            call gdfxs_body22 ( lafeygt(it), &
                                work,1,lssxu,1,lssyu,11, &
          7, scofe,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fey' )
         end do
      end if
!..
      if( lafezl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sez(ix,iy)
            end do
         end do
         do it = 1, lafezl
            call gdfxs_body22 ( lafezgt(it), &
                              work,1,lssxu,1,lssyu,11, &
          7, scofe,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fez' )
         end do
      end if
!..
      if( lafbal .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = ( ( sbx(ix,iy-1)+sbx(ix,iy) )*s1o2 )**2 + &
                            ( ( sby(ix-1,iy)+sby(ix,iy) )*s1o2 )**2 + &
                                             sbz(ix,iy)**2
            end do
         end do
         do it = 1, lafbal
            call gdfxs_body22 ( lafbagt(it), work,1,lssxu,1,lssyu, 10, &
        3, scofb2h,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fba' )
         end do
      end if
!..
      if( lafbxl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sbx(ix,iy)
            end do
         end do
         do it = 1, lafbxl
            call gdfxs_body22 ( lafbxgt(it), &
                              work,1,lssxu,1,lssyu,11, &
          7, scofb,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fbx' )
         end do
      end if
!..
      if( lafbyl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sby(ix,iy)
            end do
         end do
         do it = 1, lafbyl
            call gdfxs_body22 ( lafbygt(it), &
                              work,1,lssxu,1,lssyu,11, &
          7, scofb,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fby' )
         end do
      end if
!..
      if( lafbzl .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = sbz(ix,iy)
            end do
         end do
         do it = 1, lafbzl
            call gdfxs_body22 ( lafbzgt(it), &
                              work,1,lssxu,1,lssyu,11, &
          7, scofb,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0, 'fbz' )
         end do
      end if
!..
      if( lafdel .ge. 1 ) then
         if( lcfde .eq. 0 ) call c2fde
         do it = 1, lafdel
            ilog = lafde(it) / 1000
            call gdfxs_body22 ( lafdegt(it), sde(0,0),0,lssxup1,0,lssyup1,&
               10, 5, snepm1inv,dble(loxp0),s0o1,dble(loyp0),s0o1,&
               slmicinv, ilog, 'fde' )
         end do
      end if
!..
      if( lafdil .ge. 1 ) then
         if( lcfdi .eq. 0 ) call c2fdi
         do it = 1, lafdil
            clab = ' '
            ilog = lafdi(it) / 1000
            do io = 1, lionspl
               if( io .eq. lionspl ) clab = 'fdi'
               icol = mod(io-1,6) + 1
               call gdfxs_body22 ( lafdigt(it), sdi(0,0,io), &
                                  0,lssxup1,0,lssyup1, 10, icol, &
                  snepm1inv,dble(loxp0),s0o1,dble(loyp0),s0o1, &
                  slmicinv, ilog, clab )
            end do
         end do
      end if
!..
      if( lafedel .ge. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
         do iy = lssyl, lssyu
            do ix = lssxl, lssxu
               work(ix,iy) = s0o1
            end do
         end do
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixx,iyy)
         do i = lnoes, lnoee
            ixx = sxe(i)
            iyy = sye(i)
            work(ixx,iyy) = work(ixx,iyy) + &
              ( sqrt( s1o1 + suue(i)**2 * scg1 ) - s1o1 ) * spfe(i)
         end do
         do it = 1, lafedel
            call gdfxs_body22 ( lafedegt(it), work,1,lssxu,1,lssyu,10,&
      8, snepm1inv,dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0,'fede' )
         end do
      end if
!..
      if( lafedil .ge. 1 ) then
         do it = 1, lafedil
            clab = ' '
            do io = 1, lionspl
               if( io .eq. lionspl ) clab = 'fedi'
               icol = mod(io-1,6) + 1
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
               do iy = lssyl, lssyu
                  do ix = lssxl, lssxu
                     work(ix,iy) = s0o1
                  end do
               end do
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixx,iyy)
               do i = lionids(io), lionide(io)
                  ixx = sxi(i)
                  iyy = syi(i)
                  work(ixx,iyy) = work(ixx,iyy) + &
                        ( sqrt( s1o1 + suui(i)**2 * scg1 ) - s1o1 ) * &
                        spfi(i) * sionam(io)
               end do
               call gdfxs_body22 ( lafedigt(it), work,1,lssxu,1,lssyu, &
               10, icol, snepm1inv,dble(loxp0),s0o1,dble(loyp0),s0o1,&
               slmicinv, 0, clab )
            end do
         end do
      end if
!..
      if( lafjexl .ge. 1 ) then
         do it = 1, lafjexl
            ixz = mod( lafjex(it)/1000, 10 )
            int = mod( lafjex(it)/10000, 10 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyl, lssyu
               do ix = lssxl, lssxu
                  work(ix,iy) = s0o1
               end do
            end do
            if( int .eq. 0 ) then
               icol = 7
            else
               icol = 5
            end if
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixx,iyy,wvv)
            do i = lnoes, lnoee
               ixx = sxe(i)
               iyy = sye(i)
               if( int .eq. 0 ) then
                  work(ixx,iyy) = work(ixx,iyy) - svxe(i) * spfe(i)
               else
                  if( ixz .ne. 1 ) then
                     wvv = svxe(i)
                  else
                     wvv = svze(i)
                  end if
                  if( int .eq. 1 .and. wvv .gt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svxe(i) * spfe(i)
                  else if( int .eq. 2 .and. wvv .lt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svxe(i) * spfe(i)
                  end if
               end if
            end do
            call gdfxs_body22 ( lafjexgt(it), work,1,lssxu,1,lssyu,11,&
                                icol, snepm1inv/scfl, &
                   dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0,'fjex' )
         end do
      end if
!..
      if( lafjeyl .ge. 1 ) then
         do it = 1, lafjeyl
            ixz = mod( lafjey(it)/1000, 10 )
            int = mod( lafjey(it)/10000, 10 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyl, lssyu
               do ix = lssxl, lssxu
                  work(ix,iy) = s0o1
               end do
            end do
            if( int .eq. 0 ) then
               icol = 7
            else
               icol = 5
            end if
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixx,iyy,wvv)
            do i = lnoes, lnoee
               ixx = sxe(i)
               iyy = sye(i)
               if( int .eq. 0 ) then
                  work(ixx,iyy) = work(ixx,iyy) - svye(i) * spfe(i)
               else
                  if( ixz .ne. 1 ) then
                     wvv = svxe(i)
                  else
                     wvv = svze(i)
                  end if
                  if( int .eq. 1 .and. wvv .gt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svye(i) * spfe(i)
                  else if( int .eq. 2 .and. wvv .lt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svye(i) * spfe(i)
                  end if
               end if
            end do
            call gdfxs_body22 ( lafjeygt(it), work,1,lssxu,1,lssyu,11,&
                                icol, snepm1inv/scfl, &
                   dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0,'fjey' )
         end do
      end if
!..
      if( lafjezl .ge. 1 ) then
         do it = 1, lafjezl
            ixz = mod( lafjez(it)/1000, 10 )
            int = mod( lafjez(it)/10000, 10 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
            do iy = lssyl, lssyu
               do ix = lssxl, lssxu
                  work(ix,iy) = s0o1
               end do
            end do
            if( int .eq. 0 ) then
               icol = 7
            else
               icol = 5
            end if
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixx,iyy,wvv)
            do i = lnoes, lnoee
               ixx = sxe(i)
               iyy = sye(i)
               if( int .eq. 0 ) then
                  work(ixx,iyy) = work(ixx,iyy) - svze(i) * spfe(i)
               else
                  if( ixz .ne. 1 ) then
                     wvv = svxe(i)
                  else
                     wvv = svze(i)
                  end if
                  if( int .eq. 1 .and. wvv .gt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svze(i) * spfe(i)
                  else if( int .eq. 2 .and. wvv .lt. sofjehot ) then
                     work(ixx,iyy) = work(ixx,iyy) - svze(i) * spfe(i)
                  end if
               end if
            end do
            call gdfxs_body22 ( lafjezgt(it), work,1,lssxu,1,lssyu,11,&
                                icol, snepm1inv/scfl, &
                   dble(loxp0),s0o1,dble(loyp0),s0o1,slmicinv,0,'fjez' )
         end do
      end if
!..
      if( lapepl .ge. 1 ) then
         do it = 1, lapepl
            int = max( lapep(it) / 1000, 1 )
            call gdfxs_body24 ( lapepgt(it), spdat1,spdat2, lnoe,int,&
           10,dble(loxp0),slmicinv,dble(loyp0),slmicinv,s0o1,scflinv, &
                                'pep' )
         end do
      end if
!..
      if( lapeuxyl .ge. 1 ) then
         do it = 1, lapeuxyl
            call gdfxs_body21 ( lapeuxygt(it), spdat1, lnoe, &
                               'ux','uy', spfen,spfex,4, &
                                s0o1, scflinv, s0o1,scflinv, 'peuxy' )
         end do
      end if
!..
      if( lapeuxzl .ge. 1 ) then
         do it = 1, lapeuxzl
            call gdfxs_body21 ( lapeuxzgt(it), spdat1, lnoe, &
                               'ux','uz', spfen,spfex,4, &
                                s0o1, scflinv, s0o1,scflinv, 'peuxz' )
         end do
      end if
!..
      if( lapeuyzl .ge. 1 ) then
         do it = 1, lapeuyzl
            call gdfxs_body21 ( lapeuyzgt(it), spdat1, lnoe, &
                               'uy','uz', spfen,spfex,4, &
                                s0o1, scflinv, s0o1,scflinv, 'peuyz' )
         end do
      end if
!..
      if( lapexuxl .ge. 1 ) then
         do it = 1, lapexuxl
            call gdfxs_body23 ( lapexuxgt(it), spdat1, lnoe,1, &
                               'x','ux','y', spfen,spfex,4,  &
              dble(loxp0),slmicinv,s0o1,scflinv,dble(loyp0),slmicinv, &
                                'pexux' )
         end do
      end if
!..
      if( lapexuyl .ge. 1 ) then
         do it = 1, lapexuyl
            call gdfxs_body23 ( lapexuygt(it), spdat1, lnoe,1, &
                               'x','uy','y', spfen,spfex,4,  &
              dble(loxp0),slmicinv,s0o1,scflinv,dble(loyp0),slmicinv, &
                                'pexuy' )
         end do
      end if
!..
      if( lapexuzl .ge. 1 ) then
         do it = 1, lapexuzl
            call gdfxs_body23 ( lapexuzgt(it), spdat1, lnoe,1, &
                               'x','uz','y', spfen,spfex,4,  &
              dble(loxp0),slmicinv,s0o1,scflinv,dble(loyp0),slmicinv, &
                                'pexuz' )
         end do
      end if
!..
      if( lapipl .ge. 1 ) then
         do it = 1, lapipl
            int = max( lapip(it) / 1000, 1 )
            do io = 1, lionspl
               icol = mod(io-1,6) + 1
               call gdfxs_body23 ( lapipgt(it), &
                                spdat1(lionids(io)), lionidl(io),int, &
                              'x','y','uu', spfin(io),spfix(io),icol, &
              dble(loxp0),slmicinv,dble(loyp0),slmicinv,s0o1,scflinv, &
                                  'pip' )
            end do
         end do
      end if
!..
      if( lapiuxyl .ge. 1 ) then
         do it = 1, lapiuxyl
            do io = 1, lionspl
               icol = mod(io-1,6) + 1
               call gdfxs_body21 ( lapiuxygt(it), &
                    spdat1(lionids(io)), lionidl(io), &
                    'ux','uy', spfin(io),spfix(io),icol,  &
                                s0o1, scflinv, s0o1,scflinv, 'piuxy' )
            end do
         end do
      end if
!..
      if( lapixuxl .ge. 1 ) then
         do it = 1, lapixuxl
            do io = 1, lionspl
               icol = mod(io-1,6) + 1
               call gdfxs_body23 ( lapixuxgt(it), &
                    spdat1(lionids(io)), lionidl(io), 1, &
                    'x', 'ux', 'y', spfin(io),spfix(io),icol, &
                    dble(loxp0),slmicinv,s0o1, &
                    scflinv,dble(loyp0),slmicinv, 'pixux' )
            end do
         end do
      end if
!..
      if( lapixuyl .ge. 1 ) then
         do it = 1, lapixuyl
            do io = 1, lionspl
               icol = mod(io-1,6) + 1
               call gdfxs_body23 ( lapixuygt(it), &
                    spdat1(lionids(io)), lionidl(io), 1, &
                    'x', 'uy', 'y', spfin(io),spfix(io),icol, &
                    dble(loxp0),slmicinv,s0o1, &
                    scflinv,dble(loyp0),slmicinv, 'pixuy' )
            end do
         end do
      end if
!....
      call gdfxs_bodye
!....
      call fdebug ( 'o2anim', 1 )
!....
      return
      end
