!-----------------------------------------------------------------------
! Compute 2D Particle Ion Force
!
      subroutine c2pif
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/09
! modified by Sakagami,H. (NIFS) 21/04/14
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ixii, ixih, iyii, iyih
      real*8  :: wdxi,wx1i,wx2i,wx3i,wx4i, &
                 wdxh,wx1h,wx2h,wx3h,wx4h, &
                 wdyi,wy1i,wy2i,wy3i,wy4i, &
                 wdyh,wy1h,wy2h,wy3h,wy4h, &
                 wex,wbx,wez,wbz,wey,wby, &
                 wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2pif', 0 )
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
#else
      if( oh_glnoi .gt. 0 ) then
#endif
!...
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL PRIVATE(ixii,wdxi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  ixih,wdxh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                  iyii,wdyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  iyih,wdyh,wy1h,wy2h,wy3h,wy4h, &
!$OMP                  wex,wbx,wez,wbz,wey,wby, &
!$OMP                  wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac)
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC)
      do i = lionids(io), lionide(io)
!..
         ixii = sxi(i)
         wdxi = sxi(i) - ixii - s1o2
         wx1i = (s1o2-wdxi)**3*s1o6
         wx2i = (s1o2+wdxi)**2*(wdxi-s3o2)*s1o2 + s2o3
         wx3i =-(s1o2-wdxi)**2*(wdxi+s3o2)*s1o2 + s2o3
         wx4i = (s1o2+wdxi)**3*s1o6
!
         ixih = sxi(i) + s1o2
         wdxh = sxi(i) - ixih
         wx1h = (s1o2-wdxh)**3*s1o6
         wx2h = (s1o2+wdxh)**2*(wdxh-s3o2)*s1o2 + s2o3
         wx3h =-(s1o2-wdxh)**2*(wdxh+s3o2)*s1o2 + s2o3
         wx4h = (s1o2+wdxh)**3*s1o6
!.
         iyii = syi(i)
         wdyi = syi(i) - iyii - s1o2
         wy1i = (s1o2-wdyi)**3*s1o6
         wy2i = (s1o2+wdyi)**2*(wdyi-s3o2)*s1o2 + s2o3
         wy3i =-(s1o2-wdyi)**2*(wdyi+s3o2)*s1o2 + s2o3
         wy4i = (s1o2+wdyi)**3*s1o6
!
         iyih = syi(i) + s1o2
         wdyh = syi(i) - iyih
         wy1h = (s1o2-wdyh)**3*s1o6
         wy2h = (s1o2+wdyh)**2*(wdyh-s3o2)*s1o2 + s2o3
         wy3h =-(s1o2-wdyh)**2*(wdyh+s3o2)*s1o2 + s2o3
         wy4h = (s1o2+wdyh)**3*s1o6
#ifdef OHHELP
         ixii = ixii - oh_ixs
         ixih = ixih - oh_ixs
         iyii = iyii - oh_iys
         iyih = iyih - oh_iys
#endif
!..
         wex = sex(ixih-1,iyii-1)*wx1h*wy1i+sex(ixih  ,iyii-1)*wx2h*wy1i &
            + sex(ixih+1,iyii-1)*wx3h*wy1i+sex(ixih+2,iyii-1)*wx4h*wy1i &
            + sex(ixih-1,iyii  )*wx1h*wy2i+sex(ixih  ,iyii  )*wx2h*wy2i &
            + sex(ixih+1,iyii  )*wx3h*wy2i+sex(ixih+2,iyii  )*wx4h*wy2i &
            + sex(ixih-1,iyii+1)*wx1h*wy3i+sex(ixih  ,iyii+1)*wx2h*wy3i &
            + sex(ixih+1,iyii+1)*wx3h*wy3i+sex(ixih+2,iyii+1)*wx4h*wy3i &
            + sex(ixih-1,iyii+2)*wx1h*wy4i+sex(ixih  ,iyii+2)*wx2h*wy4i &
            + sex(ixih+1,iyii+2)*wx3h*wy4i+sex(ixih+2,iyii+2)*wx4h*wy4i
!
         wbx = sbx(ixih-1,iyii-1)*wx1h*wy1i+sbx(ixih  ,iyii-1)*wx2h*wy1i &
            + sbx(ixih+1,iyii-1)*wx3h*wy1i+sbx(ixih+2,iyii-1)*wx4h*wy1i &
            + sbx(ixih-1,iyii  )*wx1h*wy2i+sbx(ixih  ,iyii  )*wx2h*wy2i &
            + sbx(ixih+1,iyii  )*wx3h*wy2i+sbx(ixih+2,iyii  )*wx4h*wy2i &
            + sbx(ixih-1,iyii+1)*wx1h*wy3i+sbx(ixih  ,iyii+1)*wx2h*wy3i &
            + sbx(ixih+1,iyii+1)*wx3h*wy3i+sbx(ixih+2,iyii+1)*wx4h*wy3i &
            + sbx(ixih-1,iyii+2)*wx1h*wy4i+sbx(ixih  ,iyii+2)*wx2h*wy4i &
            + sbx(ixih+1,iyii+2)*wx3h*wy4i+sbx(ixih+2,iyii+2)*wx4h*wy4i &
            + sextbx
!.
         wez = sez(ixih-1,iyih-1)*wx1h*wy1h+sez(ixih  ,iyih-1)*wx2h*wy1h &
            + sez(ixih+1,iyih-1)*wx3h*wy1h+sez(ixih+2,iyih-1)*wx4h*wy1h &
            + sez(ixih-1,iyih  )*wx1h*wy2h+sez(ixih  ,iyih  )*wx2h*wy2h &
            + sez(ixih+1,iyih  )*wx3h*wy2h+sez(ixih+2,iyih  )*wx4h*wy2h &
            + sez(ixih-1,iyih+1)*wx1h*wy3h+sez(ixih  ,iyih+1)*wx2h*wy3h &
            + sez(ixih+1,iyih+1)*wx3h*wy3h+sez(ixih+2,iyih+1)*wx4h*wy3h &
            + sez(ixih-1,iyih+2)*wx1h*wy4h+sez(ixih  ,iyih+2)*wx2h*wy4h &
            + sez(ixih+1,iyih+2)*wx3h*wy4h+sez(ixih+2,iyih+2)*wx4h*wy4h
!
         wbz = sbz(ixih-1,iyih-1)*wx1h*wy1h+sbz(ixih  ,iyih-1)*wx2h*wy1h &
            + sbz(ixih+1,iyih-1)*wx3h*wy1h+sbz(ixih+2,iyih-1)*wx4h*wy1h &
            + sbz(ixih-1,iyih  )*wx1h*wy2h+sbz(ixih  ,iyih  )*wx2h*wy2h &
            + sbz(ixih+1,iyih  )*wx3h*wy2h+sbz(ixih+2,iyih  )*wx4h*wy2h &
            + sbz(ixih-1,iyih+1)*wx1h*wy3h+sbz(ixih  ,iyih+1)*wx2h*wy3h &
            + sbz(ixih+1,iyih+1)*wx3h*wy3h+sbz(ixih+2,iyih+1)*wx4h*wy3h &
            + sbz(ixih-1,iyih+2)*wx1h*wy4h+sbz(ixih  ,iyih+2)*wx2h*wy4h &
            + sbz(ixih+1,iyih+2)*wx3h*wy4h+sbz(ixih+2,iyih+2)*wx4h*wy4h &
            + sextbz
!.
         wey = sey(ixii-1,iyih-1)*wx1i*wy1h+sey(ixii  ,iyih-1)*wx2i*wy1h &
            + sey(ixii+1,iyih-1)*wx3i*wy1h+sey(ixii+2,iyih-1)*wx4i*wy1h &
            + sey(ixii-1,iyih  )*wx1i*wy2h+sey(ixii  ,iyih  )*wx2i*wy2h &
            + sey(ixii+1,iyih  )*wx3i*wy2h+sey(ixii+2,iyih  )*wx4i*wy2h &
            + sey(ixii-1,iyih+1)*wx1i*wy3h+sey(ixii  ,iyih+1)*wx2i*wy3h &
            + sey(ixii+1,iyih+1)*wx3i*wy3h+sey(ixii+2,iyih+1)*wx4i*wy3h &
            + sey(ixii-1,iyih+2)*wx1i*wy4h+sey(ixii  ,iyih+2)*wx2i*wy4h &
            + sey(ixii+1,iyih+2)*wx3i*wy4h+sey(ixii+2,iyih+2)*wx4i*wy4h
!
         wby = sby(ixii-1,iyih-1)*wx1i*wy1h+sby(ixii  ,iyih-1)*wx2i*wy1h &
            + sby(ixii+1,iyih-1)*wx3i*wy1h+sby(ixii+2,iyih-1)*wx4i*wy1h &
            + sby(ixii-1,iyih  )*wx1i*wy2h+sby(ixii  ,iyih  )*wx2i*wy2h &
            + sby(ixii+1,iyih  )*wx3i*wy2h+sby(ixii+2,iyih  )*wx4i*wy2h &
            + sby(ixii-1,iyih+1)*wx1i*wy3h+sby(ixii  ,iyih+1)*wx2i*wy3h &
            + sby(ixii+1,iyih+1)*wx3i*wy3h+sby(ixii+2,iyih+1)*wx4i*wy3h &
            + sby(ixii-1,iyih+2)*wx1i*wy4h+sby(ixii  ,iyih+2)*wx2i*wy4h &
            + sby(ixii+1,iyih+2)*wx3i*wy4h+sby(ixii+2,iyih+2)*wx4i*wy4h &
            + sextby
!..
         wax = suxi(i) + wex * sionqm(io) * s1o2
         way = suyi(i) + wey * sionqm(io) * s1o2
         waz = suzi(i) + wez * sionqm(io) * s1o2
         wtf = s1o2/sqrt(s1o1+(wax**2+way**2+waz**2)*scg1) * sionqm(io)
         wcx = wbx * wtf
         wcy = wby * wtf
         wcz = wbz * wtf
         wc2 = wcx**2 + wcy**2 + wcz**2
         wac = wax * wcx + way * wcy + waz * wcz
!.
         sfxi(i) = ( ( wax + way * wcz - waz * wcy + wac * wcx ) / &
                  ( s1o1 + wc2 ) - suxi(i) ) * s2o1
         sfyi(i) = ( ( way + waz * wcx - wax * wcz + wac * wcy ) / &
                  ( s1o1 + wc2 ) - suyi(i) ) * s2o1
         sfzi(i) = ( ( waz + wax * wcy - way * wcx + wac * wcz ) / &
                  ( s1o1 + wc2 ) - suzi(i) ) * s2o1
      end do
!...
      end do
!...
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
      end if
!....
      call fdebug ( 'c2pif', 1 )
!....
      return
      end
