!----------------------------------------------------------------------
! Observe 2D Field DRAW type 1
      subroutine o2fdraw1 ( eident, fstcur, fminlog, kminlog, &
                    kfn, klog, kcol, kcrx, kcry, fdat, koxpl, koypl, &
                    foxmic, foxp0m, foymic, foyp0m, ettl )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i, ioxyl
      integer :: kfn, klog, kcol, kcrx, kcry, koxpl, koypl, kminlog
      real*8  :: wminlog 
      real*8  :: fstcur, fminlog 
      real*8  :: foxmic, foxp0m, foymic, foyp0m, fdat(koxpl*koypl)
      character*(*) :: eident, ettl
      save    
!....
      ioxyl = koxpl * koypl
!....
      if( klog .ge. 1 ) then
         wminlog = 0.0d0
         do i = 1, ioxyl
            wminlog = max( wminlog, fdat(i) )
         end do
         if( wminlog .le. 0.0d0 ) then
            wminlog = fminlog 
         else
            wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
         end if
         do i = 1, ioxyl
            fdat(i) = log10( max( fdat(i), wminlog ) )
         end do
      end if
!...
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fdat, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettl )
!..
      if( kcrx .ge. 1 ) then
         call frames_body25 ( eident, fstcur, kfn, & 
                              fdat, ioxyl, koxpl, koypl, kcrx, klog, &
                              foxmic, foxp0m, foymic, foyp0m, ettl )
      end if
!..
      if( kcry .ge. 1 ) then
         call frames_body26 ( eident, fstcur, kfn, & 
                              fdat, ioxyl, koxpl, koypl, kcry, klog, &
                              foxmic, foxp0m, foymic, foyp0m, ettl )
      end if
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Field DRAW type 3
      subroutine o2fdraw3 ( eident, fstcur, kfn, kcol, kcrx, kcry, &
                    fdax, fday, fdaz, koxpl, koypl, &
                    foxmic, foxp0m, foymic, foyp0m, &
                    ettlx, ettly, ettlz )
!
!   <remarks>
!     none
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i, ioxyl
      integer :: kfn, kcol, kcrx, kcry, koxpl, koypl
      real*8  :: fstcur
      real*8  :: foxmic, foxp0m, foymic, foyp0m, &
                 fdax(koxpl*koypl), fday(koxpl*koypl), fdaz(koxpl*koypl)
      character*(*) :: eident, ettlx, ettly, ettlz
      save    
!....
      ioxyl = koxpl * koypl
!....
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fdax, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettlx )
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fday, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettly )
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fdaz, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettlz )
!..
      if( kcrx .ge. 1 ) then
         call frames_body25 ( eident, fstcur, kfn, & 
                              fdax, ioxyl, koxpl, koypl, kcrx, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettlx )
         call frames_body25 ( eident, fstcur, kfn, & 
                              fday, ioxyl, koxpl, koypl, kcrx, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettly )
         call frames_body25 ( eident, fstcur, kfn, & 
                              fdaz, ioxyl, koxpl, koypl, kcrx, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettlz )
      end if
!..
      if( kcry .ge. 1 ) then
         call frames_body26 ( eident, fstcur, kfn, & 
                              fdax, ioxyl, koxpl, koypl, kcry, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettlx )
         call frames_body26 ( eident, fstcur, kfn, & 
                              fday, ioxyl, koxpl, koypl, kcry, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettly )
         call frames_body26 ( eident, fstcur, kfn, & 
                              fdaz, ioxyl, koxpl, koypl, kcry, 0, &
                              foxmic, foxp0m, foymic, foyp0m, ettlz )
      end if
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Field DRAW type 5
      subroutine o2fdraw5 ( eident, fstcur, kfn, kcol, kint, kcl2, &
                    fampx, fdax, fday, fdaz, koxpl, koypl, &
                    foxmic, foxp0m, foymic, foyp0m, &
                    ettlx, ettly, ettlz, ettlxy, ettlyz, ettlxz )
!
!   <remarks>
!     if kint >= 1, fdax, fday, fdaz are destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i, ioxyl
      integer :: kfn, kcol, kint, kcl2, koxpl, koypl
      real*8  :: fstcur, fampx, wampx
      real*8  :: foxmic, foxp0m, foymic, foyp0m, &
                 fdax(koxpl*koypl), fday(koxpl*koypl), fdaz(koxpl*koypl)
      character*(*) :: eident, &
                       ettlx, ettly, ettlz, ettlxy, ettlyz, ettlxz
      save    
!....
      ioxyl = koxpl * koypl
!....
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fdax, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettlx )
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fday, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettly )
      call frames_body21 ( eident, fstcur, kfn, kcol, &
                           fdaz, ioxyl, koxpl, koypl, &
                           foxmic, foxp0m, foymic, foyp0m, ettlz )
!..
      if( kint .ge. 1 ) then
         wampx = max( fampx, 1.0d-1 )
         do i = 1, ioxyl
            fdax(i) = fdax(i) / wampx
            fday(i) = fday(i) / wampx
            fdaz(i) = fdaz(i) / wampx
         end do
         call frames_body23 ( eident, fstcur, kfn, kcl2, & 
                  fdax, fday, ioxyl, koxpl, koypl, kint,  & 
                  wampx, foxmic, foxp0m, foymic, foyp0m, ettlxy )
         call frames_body23 ( eident, fstcur, kfn, kcl2, & 
                  fday, fdaz, ioxyl, koxpl, koypl, kint,  & 
                  wampx, foxmic, foxp0m, foymic, foyp0m, ettlyz )
         call frames_body23 ( eident, fstcur, kfn, kcl2, & 
                  fdax, fdaz, ioxyl, koxpl, koypl, kint,  & 
                  wampx, foxmic, foxp0m, foymic, foyp0m, ettlxz )
      end if
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Field DRAW type k (wave number)
      subroutine o2fdrawk ( eident, fstcur, kfn, klog, kcol, &
                    fkx, fky, fsp, fspx, fspy, kxl, kyl, &
                    fxs, fys, fxe, fye, &
                    ettlx, ettly, ettln, ettll )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: ix, iy
      integer :: kfn, klog, kcol, kxl, kyl
      real*8  :: fstcur, fxs, fys, fxe, fye
      real*8  :: fkx(kxl), fky(kyl), fsp(kxl,kyl), fspx(kxl), fspy(kyl)
      character :: crange*32
      character*(*) :: eident, ettlx, ettly, ettln, ettll
      save    
!....
      if( klog .ge. 1 ) then
         do iy = 1, kyl
            do ix = 1, kxl
               fsp(ix,iy) = log10( max( fsp(ix,iy), 1.0d-6 ) )
            end do
         end do
         do ix = 1, kxl
            fspx(ix) = log10( max( fspx(ix), 1.0d-6 ) )
         end do
         do iy = 1, kyl
            fspy(iy) = log10( max( fspy(iy), 1.0d-6 ) )
         end do
      end if
!..
      crange = 'range(-xx.x,-xx.x)(-xx.x,-xx.x)'
      write( crange(7:11),  '(f5.1)' ) fxs
      write( crange(13:17), '(f5.1)' ) fys
      write( crange(20:24), '(f5.1)' ) fxe
      write( crange(26:30), '(f5.1)' ) fye
      call frames_body22 ( eident, fstcur, kfn, kcol, 0, fsp, &
                        kxl, kyl, 0.0d0, fkx(kxl), 0.0d0, fky(kyl), &
                        ettlx, ettly, ettll, crange )
      call frames_body27 ( eident, fstcur, kfn, klog, fkx, fspx, & 
                        kxl, ettlx, ettln, ettll, crange )
      call frames_body27 ( eident, fstcur, kfn, klog, fky, fspy, & 
                        kyl, ettly, ettln, ettll, crange )
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Particle DRAW type 1
      subroutine o2pdraw1 ( eident, fstcur, fminlog, kminlog, &
                    kfn, klog, fdat, kl, fct, &
                    fxs, fys, fxe, fye, &
                    ettlx, ettly, ettll )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i
      integer :: kfn, klog, kl, kminlog
      real*8  :: wminlog 
      real*8  :: fstcur, fminlog, fct, fxs, fys, fxe, fye
      real*8  :: fdat(kl)
      character :: crange*32
      character*(*) :: eident, ettlx, ettly, ettll
      save    
!....
      if( klog .ge. 1 ) then
         wminlog = 0.0d0
         do i = 1, kl
            wminlog = max( wminlog, fdat(i) )
         end do
         if( wminlog .le. 0.0d0 ) then
            wminlog = fminlog 
         else
            wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
         end if
         do i = 1, kl
            fdat(i) = log10( max( fdat(i), wminlog ) )
         end do
      end if
!...
      crange = 'range(-xx.x,-xx.x)(-xx.x,-xx.x)'
      write( crange(7:11),  '(f5.1)' ) fxs
      write( crange(13:17), '(f5.1)' ) fys
      write( crange(20:24), '(f5.1)' ) fxe
      write( crange(26:30), '(f5.1)' ) fye
      call frames_body28 ( eident, fstcur, kfn, klog, fdat, &
                           kl, fct, ettlx, ettly, ettll, crange )
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Particle DRAW type 6
      subroutine o2pdraw6 ( eident, fstcur, fminlog, kminlog, &
              kfn, klog, kcol, fdax, fday, fdaz, fdaxy, fdayz, fdaxz, &
              kl, fct, fxs, fys, fxe, fye, &
              ettlx, ettly, ettlz, ettln, ettll )
!
!   <remarks>
!     if klog = 1, fdax, fday, fdaz, fdaxy, fdayz, fdaxz are destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i
      integer :: kfn, klog, kcol, kl, kminlog
      real*8  :: wminlog, wxm, wxx, wym, wyx
      real*8  :: fstcur, fminlog, fct, fxs, fys, fxe, fye
      real*8  :: fdax(kl), fday(kl), fdaz(kl), &
                 fdaxy(kl,kl), fdayz(kl,kl), fdaxz(kl,kl)
      character :: crange*32
      character*(*) :: eident, ettlx, ettly, ettlz, ettln, ettll
      save    
!....
      if( klog .ge. 1 ) then
          wminlog = maxval( fdax(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdax(:) = log10( max( fdax(:), wminlog) )
          wminlog = maxval( fday(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fday(:) = log10( max( fday(:), wminlog) )
          wminlog = maxval( fdaz(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdaz(:) = log10( max( fdaz(:), wminlog) )
          wminlog = maxval( fdaxy(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdaxy(:,:) = log10( max( fdaxy(:,:), wminlog) )
          wminlog = maxval( fdayz(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdayz(:,:) = log10( max( fdayz(:,:), wminlog) )
          wminlog = maxval( fdaxz(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog 
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdaxz(:,:) = log10( max( fdaxz(:,:), wminlog) )

      end if
!...
      crange = 'range(-xx.x,-xx.x)(-xx.x,-xx.x)'
      write( crange(7:11),  '(f5.1)' ) fxs
      write( crange(13:17), '(f5.1)' ) fys
      write( crange(20:24), '(f5.1)' ) fxe
      write( crange(26:30), '(f5.1)' ) fye
      wxx = kl / ( 2.0d0 * fct )
      wxm = - wxx 
      wyx = kl / ( 2.0d0 * fct )
      wym = - wyx
      call frames_body24 ( eident, fstcur, kfn, klog, &
                        fdax, kl, fct, &
                        ettlx, ettln, ettll, crange )
      call frames_body24 ( eident, fstcur, kfn, klog, &
                        fday, kl, fct, &
                        ettly, ettln, ettll, crange )
      call frames_body24 ( eident, fstcur, kfn, klog, &
                        fdaz, kl, fct, &
                        ettlz, ettln, ettll, crange )
      call frames_body22 ( eident, fstcur, kfn, kcol, 0, & 
                 fdaxy, kl, kl, wxm, wxx, wym, wyx, &
                        ettlx, ettly, ettll, crange )
      call frames_body22 ( eident, fstcur, kfn, kcol, 0, & 
                 fdayz, kl, kl, wxm, wxx, wym, wyx, &
                        ettly, ettlz, ettll, crange )
      call frames_body22 ( eident, fstcur, kfn, kcol, 0, & 
                 fdaxz, kl, kl, wxm, wxx, wym, wyx, &
                        ettlx, ettlz, ettll, crange )
!....
      return
      end
!----------------------------------------------------------------------
! Observe 2D Particle DRAW type PHase
      subroutine o2pdrawph ( eident, fstcur, fminlog, kminlog, &
                             kfn, klog, kcol, fdat, kxl, kul, &
                             fxs, fys, fxe, fye, fus, fue, &
                             ettlx, ettly, ettll )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i
      integer :: kfn, klog, kcol, kxl, kul, kminlog
      real*8  :: wminlog 
      real*8  :: fstcur, fminlog, fxs, fys, fxe, fye, fus, fue
      real*8  :: fdat(kxl,kul)
      character :: crange*32
      character*(*) :: eident, ettlx, ettly, ettll
      save    
!....
      if( klog .ge. 1 ) then
         wminlog = maxval( fdat(:,:) )
         if( wminlog .le. 0.0d0 ) then
            wminlog = fminlog 
         else
            wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
         end if
         fdat(:,:) = log10( max( fdat(:,:), wminlog) )
      end if
!...
      crange = 'range(-xx.x,-xx.x)(-xx.x,-xx.x)'
      write( crange(7:11),  '(f5.1)' ) fxs
      write( crange(13:17), '(f5.1)' ) fys
      write( crange(20:24), '(f5.1)' ) fxe
      write( crange(26:30), '(f5.1)' ) fye
      call frames_body22 ( eident, fstcur, kfn, kcol, -1, & 
                           fdat, kxl, kul, fxs, fxe, fus, fue, &
                           ettlx, ettly, ettll, crange )
!....
      return
      end
