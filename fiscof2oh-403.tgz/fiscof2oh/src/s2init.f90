!----------------------------------------------------------------------
! Set 2D INITial values
!
      subroutine s2init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/14
! modified by Sakagami,H. (NIFS) 21/04/09
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use profile
      use particle
      use field
      use observe
      use animation
      use fpprm
      use debug
      include "implicit.h"
      integer :: i, icll, io, ix, iy, ilx
#ifdef OHHELP
      include "mpif.h"
      integer :: ips, ierr, itmp, inoe, inoi
#endif
      real*8  :: wgam, wichg, wpfin, wpfix, wpnoi, wdemax, wg, wgh
      save
!....
      call fdebug ( 's2init', 0 )
!....
      if( lresti .eq. 0 ) then
         if ( lpprof .eq. 0 ) then
#ifndef OHHELP
            lnoe = 0
            lnoes = 0
            lnoee = -1
            lnoi = 0
            lnois = 0
            lnoie = -1
#else
            call s2ext_conv( 13 )
#endif
            lionspl = 0
            lxps = -10000
            lxpe = -10000
            lyps = -10000
            lype = -10000
            if( lrank .le. 0 ) &
               write(6,*) '@@@ no plasma'
            lnox = 1
         else if ( lpprof .eq. -1 ) then
            call s2rstr
         else if ( lpprof .eq. 1 ) then
            call s2qstr ( ldebug )
         else if ( lpprof .eq. 2 ) then
            call s2fstr
         else
            write(0,*) '### ERROR: not implemented. lpprof =',lpprof
            call s2ext_abort
         end if
!----
#ifdef OHHELP
         ips = 1
#endif
         if( ldebug .eq. -1 ) then
            write(6,*) '### particle number count mode'
            write(6,*) 'number of electrons = ', lnoe
            write(6,*) 'number of ions      = ', lnoi
            if( lnoi .gt. 0 ) then
               do io = 1, lionspl
                  write(6,*) 'io, ids, ide, idl = ', &
                        io, lionids(io), lionide(io), lionidl(io)
               end do
            end if
            call s2ext_term
!           stop 77777
            stop
         end if
!----
#ifdef OHHELP
         call MPI_ALLREDUCE( lnoe, oh_glnoe, 1, MPI_INTEGER, &
                                MPI_SUM, MPI_COMM_WORLD, ierr )
         call MPI_ALLREDUCE( lnoi, oh_glnoi, 1, MPI_INTEGER, &
                                MPI_SUM, MPI_COMM_WORLD, ierr )
         if( lrank .le. 0 ) then
            write(6,*) 'oh_glnoe, oh_glnoi =', oh_glnoe, oh_glnoi
         end if
!..
         call s2ext_exec ( 11 )
         call s2ext_conv ( 10 )
#endif
         spnoe = s0o1
         spfen = 1.0d20
         spfex = s0o1
!..
#ifdef OHHELP
         do ips = 1, 2
         if( oh_lnoe(ips) .le. 0 ) cycle
#endif
         if( lnoe .gt. 0 ) then
            do i = lnoes, lnoee
               wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
               svxe(i) = suxe(i) / wgam
               svye(i) = suye(i) / wgam
               svze(i) = suze(i) / wgam
            end do
!
            do i = lnoes, lnoee
               spnoe = spnoe + spfe(i)
               spfen = min( spfen, spfe(i) )
               spfex = max( spfex, spfe(i) )
            end do
!g77
!g77 This check is needed to suppress g77 optimization bug.
!g77
            if( spfex .lt. spfen ) then
               write(0,*) '### ERROR: invalid spfen, spfex ',spfen,spfex
               call s2ext_abort
            end if
         end if
#ifdef OHHELP
         end do
#endif
!...
#ifndef OHHELP
         if( lnoe .gt. 0 ) then
#else
         if( oh_glnoe .gt. 0 ) then
            ips = 1
#endif
            if( lrank .le. 0 ) then
              write(6,*) '@@@ lxps, lxpe = ', lxps, lxpe, &
                ' (',(lxps-lxp0)*slmicinv,(lxpe-lxp0)*slmicinv,')'
              write(6,*) '@@@ lyps, lype = ', lyps, lype, &
                ' (',(lyps-lyp0)*slmicinv,(lype-lyp0)*slmicinv,')'
            end if
#ifndef OHHELP
            write(6,*) '@@@ lnoe, spnoe, spfex, spfen = ', &
                    lnoe, spnoe, spfex, spfen
#else
            itmp = oh_lnoe(1) + oh_lnoe(2)
            write(6,*) '@@@ lnoe, spnoe, spfex, spfen = ', &
                    itmp, spnoe, spfex, spfen
            call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                 MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoe, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfen, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MIN, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfex, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
            if( lrank .le. 0 ) then
              write(6,*) 'global lnoe, spnoe, spfex, spfen = ', &
                          itmp, spnoe, spfex, spfen
            end if
#endif
!..
            call c2fde
!.                                            * check wncmax validity *
            wdemax = maxval( sde(:,:) )
#ifdef OHHELP
            call MPI_ALLREDUCE( MPI_IN_PLACE, wdemax, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
#endif
            if( abs(wdemax/snepm1*sncinv-s1o1) .gt. sncmaxtl ) then
               write(0,*) '### ERROR: invalid wncmax', &
                                 s1o1/sncinv, wdemax/snepm1, sncmaxtl
               call s2ext_abort
            end if
!...
         else
!                         * to avoid zero div in o2eng when no plasma *
            spnoe = s1o1
#ifdef OHHELP
            do ips = 1, 2
#endif
            sde(:,:) = s0o1
#ifdef OHHELP
            end do
#endif
         end if
!....
         wichg  = s0o1
         spnoit = s0o1
#ifdef OHHELP
         do io = 1, lionspl 
           spnoi(io) = s0o1
           spfin(io) = 1.0d20
           spfix(io) = s0o1
         end do
         do ips = 1, 2
         if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
!...                                                     * mobile ion *
         if( lnoi .gt. 0 ) then
            do i = lnois, lnoie
               wgam = sqrt( s1o1 + suui(i)**2 * scg1 )
               svxi(i) = suxi(i) / wgam
               svyi(i) = suyi(i) / wgam
               svzi(i) = suzi(i) / wgam
            end do
!
            do io = 1, lionspl
#ifdef OHHELP
               if( lionidl(io) .le. 0 ) cycle 
#endif
               wpnoi = s0o1
               wpfin = 1.0d20
               wpfix = s0o1
               do i = lionids(io), lionide(io)
                  wpnoi = wpnoi + spfi(i)
                  wpfin = min( wpfin, spfi(i) )
                  wpfix = max( wpfix, spfi(i) )
               end do
               if( wpfix .lt. wpfin ) then
                  write(0,*) '### ERROR: invalid wpfin,wpfix ', &
                            io, wpfin, wpfix
                  call s2ext_abort
               end if
#ifndef OHHELP
               spnoi(io) = wpnoi
               spfin(io) = wpfin
               spfix(io) = wpfix
#else
               spnoi(io) = spnoi(io) + wpnoi 
               spfin(io) = min( spfin(io), wpfin ) 
               spfix(io) = max( spfix(io), wpfix ) 
#endif
               spnoit  = spnoit  + wpnoi
               wichg = wichg + wpnoi * sionaz(io)
            end do
         end if
#ifdef OHHELP
         end do
#endif
!...
#ifndef OHHELP
         if( lnoi .gt. 0 ) then
            write(6,*) '@@@ lnoi, spnoit = ', lnoi, spnoit
            do io = 1, lionspl
               write(6,*) '@@@ io, idl, spnoi, spfix, spfin = ', &
                     io, lionidl(io), spnoi(io), spfix(io), spfin(io)
            end do
            write(6,*) '@@@ net total charge = ', wichg - spnoe
#else
         if( oh_glnoi .gt. 0 ) then
            ips = 1
            itmp = oh_lnoi(1) + oh_lnoi(2)
            write(6,*) '@@@ lnoi, spnoit = ', itmp, spnoit
            do io = 1, lionspl
               itmp = oh_lionidl(io,1) + oh_lionidl(io,2)
               write(6,*) '@@@ io, idl, spnoi, spfix, spfin = ', &
                     io, itmp, spnoi(io), spfix(io), spfin(io)
            end do
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoi, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfix, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfin, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_MIN, MPI_COMM_WORLD, ierr )
            do io = 1, lionspl
              itmp = oh_lionidl(io,1) + oh_lionidl(io,2)
              call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                          MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
              if( lrank .le. 0 ) &
              write(6,*) 'global io, idl, spnoi, spfix, spfin =', &
                          io, itmp, spnoi(io), spfix(io), spfin(io)
            end do
            itmp = oh_lnoi(1) + oh_lnoi(2)
            call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                 MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoit, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, wichg, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            if( lrank .le. 0 ) &
               write(6,*) 'global lnoi, spnoit, net total charge =', &
                          itmp, spnoit, wichg - spnoe
#endif
!..
            call c2fdi
!..                                                   * immobile ion *
         else
            if( lrank .le. 0 ) then
#ifndef OHHELP
               if( lnoe .gt. 0 ) write(6,*) '@@@ immobile ion'
#else
               if( oh_glnoe .gt. 0 ) write(6,*) '@@@ immobile ion'
#endif
            end if
#ifdef OHHELP
            ips = 1
#endif
            sde0(:,:) = sde(:,:)
            sdi(:,:,:) = s0o1
         end if
!...
#ifdef OHHELP
         do ips = 1, 2
#endif
         sjxe(:,:)  = s0o1
         sjye(:,:)  = s0o1
         sjze(:,:)  = s0o1
         sjxi(:,:,:)  = s0o1
         sjyi(:,:,:)  = s0o1
         sjzi(:,:,:)  = s0o1
         sjxt(:,:)  = s0o1
         sjyt(:,:)  = s0o1
         sjzt(:,:)  = s0o1
!..
#ifdef OHHELP
         end do
!..
         call s2ext_conv ( 0 ) 
!..
         do ips = 1, 2
#endif
         sex(:,:) = s0o1
         sey(:,:) = s0o1
         sez(:,:) = s0o1
         sbx(:,:) = s0o1
         sby(:,:) = s0o1
         sbz(:,:) = s0o1
         sezxxl(:,:) = s0o1
         sbzxxl(:,:) = s0o1
         sezyxl(:,:) = s0o1
         sbzyxl(:,:) = s0o1
         sezxxu(:,:) = s0o1
         sbzxxu(:,:) = s0o1
         sezyxu(:,:) = s0o1
         sbzyxu(:,:) = s0o1
         sezxyl(:,:) = s0o1
         sbzxyl(:,:) = s0o1
         sezyyl(:,:) = s0o1
         sbzyyl(:,:) = s0o1
         sezxyu(:,:) = s0o1
         sbzxyu(:,:) = s0o1
         sezyyu(:,:) = s0o1
         sbzyyu(:,:) = s0o1
#ifdef OHHELP
         end do
#endif
!.
         sextbx = sextbx / scofb
         sextby = sextby / scofb
         sextbz = sextbz / scofb
!.
         call c2fed
!....
      else
         call s2rest ( 0, lresti )
#ifdef OHHELP
         itmp = oh_lnoe(1)
         if( oh_sdid(2) .ge. 0 ) itmp = itmp + oh_lnoe(2)
         call MPI_REDUCE( itmp, inoe, 1, MPI_INTEGER, &
                                MPI_SUM, 0, MPI_COMM_WORLD, ierr )
         itmp = oh_lnoi(1)
         if( oh_sdid(2) .ge. 0 ) itmp = itmp + oh_lnoi(2)
         call MPI_REDUCE( itmp, inoi, 1, MPI_INTEGER, &
                                MPI_SUM, 0, MPI_COMM_WORLD, ierr )
         if( lrank .le. 0 ) then
            if( inoe .ne. oh_glnoe .or. inoi .ne. oh_glnoi ) then
               write(0,*) '### ERROR: total # particle mismatch', &
                          inoe, oh_glnoe, inoi, oh_glnoi
               call s2ext_abort
            end if
            write(6,*) 'oh_glnoe, oh_glnoi =', oh_glnoe, oh_glnoi
         end if
         call s2ext_exec( 21 )
#endif
      end if
!....
      if( lbxlf .eq. 4 ) then
         do ix = lblxl, lssxlm1
            wgh = sblsgxl * ( (lssxl-ix+s1o2)**(lblsgxl+1) - &
             (lssxl-ix-s1o2)**(lblsgxl+1) )/lpmlxl**lblsgxl/(lblsgxl+1)
            wg  = sblsgxl * ( (lssxl-ix)**(lblsgxl+1) - &
             (lssxl-ix-s1o1)**(lblsgxl+1) )/lpmlxl**lblsgxl/(lblsgxl+1)
            scaxlh(ix-1) = exp(-wgh)
            scaxl(ix)    = exp(-wg)
            scbbtexl(ix-1) = ( s1o1 - exp(-wgh) ) / wgh
            scbetexl(ix)   = ( s1o1 - exp(-wg) ) / wg * scb1
            scbetmxl(ix-1) = ( s1o1 - exp(-wgh) ) / wgh * scb1
            scbbtmxl(ix)   = ( s1o1 - exp(-wg) ) / wg
            sccbtexl(ix-1) = scbbtexl(ix-1)
            sccetexl(ix)   = scbetexl(ix)
            sccetmxl(ix-1) = scbetmxl(ix-1)
            sccbtmxl(ix)   = scbbtmxl(ix)
         end do
      end if
      if( lbxuf .eq. 4 ) then
         do ix = lssxup2, lblxu
            wgh = sblsgxu * ( (ix-lssxup1+s1o2)**(lblsgxu+1) - &
            (ix-lssxup1-s1o2)**(lblsgxu+1) )/lpmlxu**lblsgxu/(lblsgxu+1)
            wg  = sblsgxu * ( (ix-lssxup2+s1o1)**(lblsgxu+1) - &
            (ix-lssxup2)**(lblsgxu+1) )/lpmlxu**lblsgxu/(lblsgxu+1)
            scaxuh(ix) = exp(-wgh)
            scaxu(ix)  = exp(-wg)
            scbbtexu(ix) = ( s1o1 - exp(-wgh) ) / wgh
            scbetexu(ix) = ( s1o1 - exp(-wg) ) / wg * scb1
            scbetmxu(ix) = ( s1o1 - exp(-wgh) ) / wgh * scb1
            scbbtmxu(ix) = ( s1o1 - exp(-wg) ) / wg
            sccbtexu(ix) = scbbtexu(ix)
            sccetexu(ix) = scbetexu(ix)
            sccetmxu(ix) = scbetmxu(ix)
            sccbtmxu(ix) = scbbtmxu(ix)
         end do
      end if
      if( lbylf .eq. 4 ) then
         do iy = lblyl, lssylm1
            wgh = sblsgyl * ( (lssyl-iy+s1o2)**(lblsgyl+1) - &
             (lssyl-iy-s1o2)**(lblsgyl+1) )/lpmlyl**lblsgyl/(lblsgyl+1)
            wg  = sblsgyl * ( (lssyl-iy)**(lblsgyl+1) - &
             (lssyl-iy-s1o1)**(lblsgyl+1) )/lpmlyl**lblsgyl/(lblsgyl+1)
            scaylh(iy-1) = exp(-wgh)
            scayl(iy)    = exp(-wg)
            scbbteyl(iy-1) = ( s1o1 - exp(-wgh) ) / wgh
            scbeteyl(iy)   = ( s1o1 - exp(-wg) ) / wg * scb1
            scbetmyl(iy-1) = ( s1o1 - exp(-wgh) ) / wgh * scb1
            scbbtmyl(iy)   = ( s1o1 - exp(-wg) ) / wg
            sccbteyl(iy-1) = scbbteyl(iy-1)
            scceteyl(iy)   = scbeteyl(iy)
            sccetmyl(iy-1) = scbetmyl(iy-1)
            sccbtmyl(iy)   = scbbtmyl(iy)
         end do
      end if
      if( lbyuf .eq. 4 ) then
         do iy = lssyup2, lblyu
            wgh = sblsgyu * ( (iy-lssyup1+s1o2)**(lblsgyu+1) - &
            (iy-lssyup1-s1o2)**(lblsgyu+1) )/lpmlyu**lblsgyu/(lblsgyu+1)
            wg  = sblsgyu * ( (iy-lssyup2+s1o1)**(lblsgyu+1) - &
            (iy-lssyup2)**(lblsgyu+1) )/lpmlyu**lblsgyu/(lblsgyu+1)
            scayuh(iy) = exp(-wgh)
            scayu(iy)  = exp(-wg)
            scbbteyu(iy) = ( s1o1 - exp(-wgh) ) / wgh
            scbeteyu(iy) = ( s1o1 - exp(-wg) ) / wg * scb1
            scbetmyu(iy) = ( s1o1 - exp(-wgh) ) / wgh * scb1
            scbbtmyu(iy) = ( s1o1 - exp(-wg) ) / wg
            sccbteyu(iy) = scbbteyu(iy)
            scceteyu(iy) = scbeteyu(iy)
            sccetmyu(iy) = scbetmyu(iy)
            sccbtmyu(iy) = scbbtmyu(iy)
         end do
      end if
!...
      if( loxp0 .le. 0 ) loxp0 = lxp0
      if( soxps .le. sundef ) then
         loxps = lxps - 5
      else
         loxps = soxps * slmic + loxp0
      end if
      if( loxps .lt. 1 .or. loxps .gt. lssx ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. x start ', loxps, lxps, soxps
         loxps = 1
      end if
      if( soxpe .le. sundef ) then
         loxpe = lxpe + 5
      else
         loxpe = soxpe * slmic + loxp0
      end if
      if( loxpe .lt. 1 .or. loxpe .gt. lssx ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. x end ', loxpe, lxpe, soxpe
         loxpe = lssx
      end if
#ifdef OHHELP
      if( loxpe .eq. lssx ) loxpe = lssxm1
#endif
      loxpl  = ( loxpe - loxps ) / loxpi + 1
      soxp0m = ( loxp0 - loxps ) * slmicinv
      if( lrank .le. 0 ) &
        write(6,*) '@@@ loxps, loxpe, loxpl, loxpi, loxp0, soxp0m =', &
                        loxps, loxpe, loxpl, loxpi, loxp0, soxp0m
!.
      if( loyp0 .le. 0 ) loyp0 = lyp0
      if( soyps .le. sundef ) then
         loyps = lyps - 5
      else
         loyps = soyps * slmic + loyp0
      end if
      if( loyps .lt. 1 .or. loyps .gt. lssy ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. y start ', loyps, lyps, soyps
         loyps = 1
      end if
      if( soype .le. sundef ) then
         loype = lype + 5
      else
         loype = soype * slmic + loyp0
      end if
      if( loype .lt. 1 .or. loype .gt. lssy ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. y end ', loype, lype, soype
         loype = lssy
      end if
#ifdef OHHELP
      if( loype .eq. lssy ) loype = lssym1
#endif
      loypl  = ( loype - loyps ) / loypi + 1
      soyp0m = ( loyp0 - loyps ) * slmicinv
      if( lrank .le. 0 ) &
        write(6,*) '@@@ loyps, loype, loypl, loypi, loyp0, soyp0m =', &
                        loyps, loype, loypl, loypi, loyp0, soyp0m
      loxypl = loxpl * loypl
!.
#ifdef OHHELP
      oh_loxal = loxpl
      oh_loyal = loypl
!
      if( loxps .ge. oh_sdoms(2,1,oh_sdid(1)+1) .or. &
          loxpe .lt. oh_sdoms(1,1,oh_sdid(1)+1) ) then
         oh_soxp0m = sundef
         oh_loxps  = 0
         oh_loxpe  = -1
         oh_loxpl  = -1
         oh_loxas  = 0
         oh_loxae  = -1
      else
         if( loxps .ge. oh_sdoms(1,1,oh_sdid(1)+1) ) then
            oh_loxps = loxps
         else
            itmp = ( oh_sdoms(1,1,oh_sdid(1)+1)-1 - loxps ) / loxpi
            oh_loxps = ( itmp+1 ) * loxpi + loxps
         end if
         if( loxpe .eq. oh_scoord(2,1) .and. &
             loxpe .eq. oh_sdoms(2,1,oh_sdid(1)+1) ) then
            oh_loxpe = loxpe
         else if( loxpe .le. oh_sdoms(2,1,oh_sdid(1)+1)-1 ) then
            oh_loxpe = loxpe
         else
            itmp = ( oh_sdoms(2,1,oh_sdid(1)+1)-1 - loxps ) / loxpi
            oh_loxpe = itmp * loxpi + loxps
         end if
         oh_loxas  = ( oh_loxps - loxps ) / loxpi + 1
         oh_loxae  = ( oh_loxpe - loxps ) / loxpi + 1
         oh_soxp0m = ( loxp0 - oh_loxps ) * slmicinv
         oh_loxps = oh_loxps - oh_sdoms(1,1,oh_sdid(1)+1) + 1
         oh_loxpe = oh_loxpe - oh_sdoms(1,1,oh_sdid(1)+1) + 1
         oh_loxpl  = ( oh_loxpe - oh_loxps ) / loxpi + 1
      end if
      if( loyps .ge. oh_sdoms(2,2,oh_sdid(1)+1) .or. &
          loype .lt. oh_sdoms(1,2,oh_sdid(1)+1) ) then
         oh_soyp0m = sundef
         oh_loyps  = 0
         oh_loype  = -1
         oh_loypl  = -1
         oh_loyas  = 0
         oh_loyae  = -1
      else
         if( loyps .ge. oh_sdoms(1,2,oh_sdid(1)+1) ) then
            oh_loyps = loyps
         else
            itmp = ( oh_sdoms(1,2,oh_sdid(1)+1)-1 - loyps ) / loypi
            oh_loyps = ( itmp+1 ) * loypi + loyps
         end if
         if( loype .eq. oh_scoord(2,2) .and. &
             loype .eq. oh_sdoms(2,2,oh_sdid(1)+1) ) then
            oh_loype = loype
         else if( loype .le. oh_sdoms(2,2,oh_sdid(1)+1)-1 ) then
            oh_loype = loype
         else
            itmp = ( oh_sdoms(2,2,oh_sdid(1)+1)-1 - loyps ) / loypi
            oh_loype = itmp * loypi + loyps
         end if
         oh_loyas  = ( oh_loyps - loyps ) / loypi + 1
         oh_loyae  = ( oh_loype - loyps ) / loypi + 1
         oh_soyp0m = ( loyp0 - oh_loyps ) * slmicinv
         oh_loyps = oh_loyps - oh_sdoms(1,2,oh_sdid(1)+1) + 1
         oh_loype = oh_loype - oh_sdoms(1,2,oh_sdid(1)+1) + 1
         oh_loypl  = ( oh_loype - oh_loyps ) / loypi + 1
       end if
      if( oh_loxpl .gt. 0 .and. oh_loypl .gt. 0 ) then
         oh_loxypl = oh_loxpl * oh_loypl
      else
         oh_loxypl = -1
      end if
      write(6,*) '@@@ oh_loxps, oh_loxpe, oh_loxpl, oh_soxp0m =', &
                      oh_loxps, oh_loxpe, oh_loxpl, oh_soxp0m
      write(6,*) '@@@ oh_loyps, oh_loype, oh_loypl, oh_soyp0m =', &
                      oh_loyps, oh_loype, oh_loypl, oh_soyp0m
      write(6,*) '@@@ oh_loxypl =', oh_loxypl
      write(6,*) '@@@ oh_loxas, oh_loxae, oh_loxal =', &
                      oh_loxas, oh_loxae, oh_loxal
      write(6,*) '@@@ oh_loyas, oh_loyae, oh_loyal =', &
                      oh_loyas, oh_loyae, oh_loyal
#endif
!...
      if( lclflge .le. -1 ) then
         lclflge = - lclflge
         write(6,*) '@@@ RESTART: lclflge =', lclflge
         icll = lclflge / 10
         do i = 1, icll
           write(6,*) '@@@ sclxpse, sclxpee, sclypse, sclypee =',  &
                        sclxpse(i), sclxpee(i), sclypse(i), sclypee(i)
           write(6,*) '@@@ scluure, scluule, scluu0e, sclfcte =', &
                        scluure(i), scluule(i), scluu0e(i), sclfcte(i)
         end do
      else if( lclflge .ge. 1 ) then
        icll = lclflge / 10
        do i = 1, icll
          if( sclxpse(i) .le. sundef ) then
            sclxpse(i) = 2
          else
            sclxpse(i) = sclxpse(i) * slmic + loxp0
            if( sclxpse(i) .lt. 1 .or. sclxpse(i) .gt. lssx ) then
              if( lrank .le. 0 ) &
              write(0,*) '### WARNING: sclxpse is out of range', &
                         i, sclxpse(i)
            end if
          end if
          if( sclxpee(i) .le. sundef ) then
            sclxpee(i) = lssxm1
          else
            sclxpee(i) = sclxpee(i) * slmic + loxp0
            if( sclxpee(i).lt.sclxpse(i) .or. sclxpee(i).gt.lssx ) then
              if( lrank .le. 0 ) &
              write(0,*) '### WARNING: sclxpee is out of range', &
                         i,sclxpse(i),sclxpee(i)
            end if
          end if
          if( sclypse(i) .le. sundef ) then
            sclypse(i) = 2
          else
            sclypse(i) = sclypse(i) * slmic + loyp0
            if( sclypse(i) .lt. 1 .or. sclypse(i) .gt. lssy ) then
              if( lrank .le. 0 ) &
              write(0,*) '### WARNING: sclypse is out of range', &
                         i, sclypse(i)
            end if
          end if
          if( sclypee(i) .le. sundef ) then
            sclypee(i) = lssym1
          else
            sclypee(i) = sclypee(i) * slmic + loyp0
            if( sclypee(i).lt.sclypse(i) .or. sclypee(i).gt.lssy ) then
              if( lrank .le. 0 ) &
              write(0,*) '### WARNING: sclypee is out of range', &
                         i,sclypse(i),sclypee(i)
            end if
          end if
          if( lrank .le. 0 ) then
            write(6,*) '@@@ sclxpse, sclxpee, sclypse, sclypee', &
                    i,sclxpse(i),sclxpee(i),sclypse(i),sclypee(i)
            write(6,*) '@@@ scluure, scluule, scluu0e, sclfcte =', &
                      scluure(i), scluule(i), scluu0e(i), sclfcte(i)
          end if
        end do
#ifdef OHHELP
        do ips = 1, 2
#endif
        do i = lnoes, lnoee
          lclfle(i) = 0
        end do
#ifdef OHHELP
        end do
#endif
      end if
!...
      if( lclflgia .le. -1 ) then
         lclflgia = - lclflgia
         do io = 1, lionspl
            write(6,*) '@@@ RESTART: lclflgi =', io, lclflgi(io)
            icll = lclflgi(io) / 10
            do i = 1, icll
              write(6,*) '@@@ sclxpsi, sclxpei, sclypsi, sclypei =', &
              sclxpsi(i,io), sclxpei(i,io), sclypsi(i,io), sclypei(i,io)
              write(6,*) '@@@ scluuri, scluuli, scluu0i, sclfcti =', &
              scluuri(i,io), scluuli(i,io), scluu0i(i,io), sclfcti(i,io)
            end do
         end do
      else
        do io = 1, lionspl
          lclflgia = lclflgia + lclflgi(io)
        end do
        if( lclflgia .ge. 1 ) then
          do io = 1, lionspl
            if( lclflgi(io) .ge. 1 ) then
              icll = lclflgi(io) / 10
              do i = 1, icll
                if( sclxpsi(i,io) .le. sundef ) then
                  sclxpsi(i,io) = 2
                else
                  sclxpsi(i,io) = sclxpsi(i,io) * slmic + loxp0
                  if( sclxpsi(i,io) .lt. 1 .or. &
                      sclxpsi(i,io) .gt. lssx ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclxpsi is out of range', &
                               io, i, sclxpsi(i,io)
                  end if
                end if
                if( sclxpei(i,io) .le. sundef ) then
                  sclxpei(i,io) = lssxm1
                else
                  sclxpei(i,io) = sclxpei(i,io) * slmic + loxp0
                  if( sclxpei(i,io) .lt. sclxpsi(i,io) .or. &
                      sclxpei(i,io) .gt. lssx ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclxpei is out of range', &
                              io, i, sclxpsi(i,io), sclxpei(i,io)
                  end if
                end if
                if( sclypsi(i,io) .le. sundef ) then
                  sclypsi(i,io) = 2
                else
                  sclypsi(i,io) = sclypsi(i,io) * slmic + loyp0
                  if( sclypsi(i,io) .lt. 1 .or. &
                      sclypsi(i,io) .gt. lssy ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclypsi is out of range', &
                               io, i, sclypsi(i,io)
                  end if
                end if
                if( sclypei(i,io) .le. sundef ) then
                  sclypei(i,io) = lssym1
                else
                  sclypei(i,io) = sclypei(i,io) * slmic + loyp0
                  if( sclypei(i,io) .lt. sclypsi(i,io) .or. &
                      sclypei(i,io) .gt. lssy ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclypei is out of range', &
                               io, i, sclypsi(i,io), sclypei(i,io)
                  end if
                end if
                if( lrank .le. 0 ) then
                  write(6,*) '@@@ sclxpsi, sclxpei, sclypsi, sclypei', &
            io,i,sclxpsi(i,io),sclxpei(i,io),sclypsi(i,io),sclypei(i,io)
                  write(6,*) '@@@ scluuri, scluuli, scluu0i, sclfcti =', &
            scluuri(i,io), scluuli(i,io), scluu0i(i,io), sclfcti(i,io)
                end if
              end do
#ifdef OHHELP
              do ips = 1, 2
#endif
              do i = lionids(io), lionide(io)
                lclfli(i) = 0
              end do
#ifdef OHHELP
              end do
#endif
            end if
          end do
        end if
      end if
!...
      do i = 1, lawnx
         if( sawnxm(i) .le. sundef ) then
            sawnxm(i) = ( loxps - loxp0 ) * slmicinv
         end if
         if( sawnxx(i) .le. sundef ) then
            sawnxx(i) = ( loxpe - loxp0 ) * slmicinv
         end if
!
         if( sawnym(i) .le. sundef ) then
            sawnym(i) = ( loyps - loyp0 ) * slmicinv
         end if
         if( sawnyx(i) .le. sundef ) then
            sawnyx(i) = ( loype - loyp0 ) * slmicinv
         end if
      end do
!...
      ilx = lopfeed / 10
      do i = 1, ilx
        if( lopfeedyl(i) .gt. 0 ) then
          if( sopfeedx(i) .le. sundef ) then
            sopfeedx(i) = loxp0
          else
            sopfeedx(i) = sopfeedx(i) * slmic + loxp0
          end if
          if( sopfeedys(i) .le. sundef ) then
            sopfeedys(i) = loyps
          else
            sopfeedys(i) = sopfeedys(i) * slmic + loyp0
          end if
          if( sopfeedye(i) .le. sundef ) then
            sopfeedye(i) = loype
          else
            sopfeedye(i) = sopfeedye(i) * slmic + loyp0
          end if
!.
          if( sopfeedx(i) .lt. 1 .or. sopfeedx(i) .gt. lssx ) then
            write(0,*) '### ERROR: sopfeedx is out of range', &
                       i, lopfeedyl(i), sopfeedx(i)
            call s2ext_abort
          end if
          if( sopfeedys(i) .lt. 1 .or. sopfeedys(i) .gt. lssy ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfeedys is out of range', &
                       i, lopfeedyl(i), sopfeedys(i)
          end if
          if( sopfeedye(i) .lt. 1 .or. sopfeedye(i) .gt. lssy ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfeedye is out of range', &
                       i, lopfeedyl(i), sopfeedye(i)
          end if
          if( sopfeedys(i) .ge. sopfeedye(i) ) then
            write(0,*)'### ERROR: sopfeedys is greater than sopfeedye',&
                       i, lopfeedyl(i), sopfeedys(i), sopfeedye(i)
            call s2ext_abort
          end if
        else
          if( sopfeedx(i) .le. sundef ) then
            sopfeedx(i) = loyp0
          else
            sopfeedx(i) = sopfeedx(i) * slmic + loyp0
          end if
          if( sopfeedys(i) .le. sundef ) then
            sopfeedys(i) = loxps
          else
            sopfeedys(i) = sopfeedys(i) * slmic + loxp0
          end if
          if( sopfeedye(i) .le. sundef ) then
            sopfeedye(i) = loxpe
          else
            sopfeedye(i) = sopfeedye(i) * slmic + loxp0
          end if
!.
          if( sopfeedx(i) .lt. 1 .or. sopfeedx(i) .gt. lssy ) then
            write(0,*) '### ERROR: sopfeedx is out of range', &
                       i, lopfeedyl(i), sopfeedx(i)
            call s2ext_abort
          end if
          if( sopfeedys(i) .lt. 1 .or. sopfeedys(i) .gt. lssx ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfeedys is out of range', &
                       i, lopfeedyl(i), sopfeedys(i)
          end if
          if( sopfeedye(i) .lt. 1 .or. sopfeedye(i) .gt. lssx ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfeedye is out of range', &
                       i, lopfeedyl(i), sopfeedye(i)
          end if
          if( sopfeedys(i) .ge. sopfeedye(i) ) then
            write(0,*)'### ERROR: sopfeedys is greater than sopfeedye',&
                       i, lopfeedyl(i), sopfeedys(i), sopfeedye(i)
            call s2ext_abort
          end if
        end if
      end do
!...
      ilx = lopfied / 10
      do i = 1, ilx
        if( lopfiedyl(i) .gt. 0 ) then
          if( sopfiedx(i) .le. sundef ) then
            sopfiedx(i) = loxp0
          else
            sopfiedx(i) = sopfiedx(i) * slmic + loxp0
          end if
          if( sopfiedys(i) .le. sundef ) then
            sopfiedys(i) = loyps
          else
            sopfiedys(i) = sopfiedys(i) * slmic + loyp0
          end if
          if( sopfiedye(i) .le. sundef ) then
            sopfiedye(i) = loype
          else
            sopfiedye(i) = sopfiedye(i) * slmic + loyp0
          end if
!.
          if( sopfiedx(i) .lt. 1 .or. sopfiedx(i) .gt. lssx ) then
            write(0,*) '### ERROR: sopfiedx is out of range', &
                        i, lopfiedyl(i), sopfiedx(i)
            call s2ext_abort
          end if
          if( sopfiedys(i) .lt. 1 .or. sopfiedys(i) .gt. lssy ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfiedys is out of range', &
                        i, lopfiedyl(i), sopfiedys(i)
          end if
          if( sopfiedye(i) .lt. 1 .or. sopfiedye(i) .gt. lssy ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfiedye is out of range', &
                        i, lopfiedyl(i), sopfiedye(i)
          end if
          if( sopfiedys(i) .ge. sopfiedye(i) ) then
            write(0,*)'### ERROR: sopfiedys is greater than sopfiedye', &
                       i, lopfiedyl(i), sopfiedys(i), sopfiedye(i)
            call s2ext_abort
          end if
        else
          if( sopfiedx(i) .le. sundef ) then
            sopfiedx(i) = loyp0
          else
            sopfiedx(i) = sopfiedx(i) * slmic + loyp0
          end if
          if( sopfiedys(i) .le. sundef ) then
            sopfiedys(i) = loxps
          else
            sopfiedys(i) = sopfiedys(i) * slmic + loxp0
          end if
          if( sopfiedye(i) .le. sundef ) then
            sopfiedye(i) = loxpe
          else
            sopfiedye(i) = sopfiedye(i) * slmic + loxp0
          end if
!.
          if( sopfiedx(i) .lt. 1 .or. sopfiedx(i) .gt. lssy ) then
            write(0,*) '### ERROR: sopfiedx is out of range', &
                        i, lopfiedyl(i), sopfiedx(i)
            call s2ext_abort
          end if
          if( sopfiedys(i) .lt. 1 .or. sopfiedys(i) .gt. lssx ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfiedys is out of range', &
                        i, lopfiedyl(i), sopfiedys(i)
          end if
          if( sopfiedye(i) .lt. 1 .or. sopfiedye(i) .gt. lssx ) then
            if( lrank .le. 0 ) &
            write(0,*) '### WARNING: sopfiedye is out of range', &
                        i, lopfiedyl(i), sopfiedye(i)
          end if
          if( sopfiedys(i) .ge. sopfiedye(i) ) then
            write(0,*)'### ERROR: sopfiedys is greater than sopfiedye', &
                       i, lopfiedyl(i), sopfiedys(i), sopfiedye(i)
             call s2ext_abort
          end if
        end if
      end do
!....
      if( loeng .ge. 1 ) call o2eng ( 0 )
      if( lopem .ge. 1 ) call o2pem ( 0 )
      if( lopee .ge. 1 ) call o2pee ( 0 )
      if( lopie .ge. 1 ) call o2pie ( 0 )
      if( lopim .ge. 1 ) call o2pim ( 0 )
      if( lofde .ge. 1 ) call o2fde ( 0 )
      if( lofdi .ge. 1 ) call o2fdi ( 0 )
      if( lofdc .ge. 1 ) call o2fdc ( 0 )
      if( lofte .ge. 1 ) call o2fte ( 0 )
      if( lofer .ge. 1 ) call o2fer ( 0 )
      if( lofea .ge. 1 ) call o2fea ( 0 )
      if( lofek .ge. 1 ) call o2fek ( 0 )
      if( lofew .ge. 1 ) call o2few ( 0 )
      if( lofbr .ge. 1 ) call o2fbr ( 0 )
      if( lofba .ge. 1 ) call o2fba ( 0 )
      if( lofede .ge. 1 ) call o2fede ( 0 )
      if( lofedi .ge. 1 ) call o2fedi ( 0 )
      if( lofje .ge. 1 ) call o2fje ( 0 )
      if( lofji .ge. 1 ) call o2fji ( 0 )
      if( lofjt .ge. 1 ) call o2fjt ( 0 )
      if( lopeph .ge. 1 ) call o2peph( 0 )
      if( lopiph .ge. 1 ) call o2piph( 0 )
      if( lopesap .ge. 1 ) call o2pesap( 0 )
      if( lopisap .ge. 1 ) call o2pisap( 0 )
      if( lopfeed .ge. 1 ) call o2pfeed ( 0 )
      if( lopfied .ge. 1 ) call o2pfied ( 0 )
!....
      call fdebug ( 's2init', 1 )
!....
      return
      end
