!--------------------------------------------------------------------
!  maxwell distribution for 3D
!
!              fvx = velocity
!              fvt = thermal velocity
!               kn = size of array ( positive only )
!
!-------------------------------------------------------------------
      subroutine qsmaxw3 ( fvx, fvt, kn )
      include "real8.h"
      dimension fvx(kn)
      data aeps / 1.0d-8 /
      save
!....
!PGI  f(x) = -sqrt(2.0d0/api)*x*exp(-x**2/2.0d0)+erf(x/sqrt(2.0d0))-a
! for PGI compiler, derf must be specified as real*8 function
      f(x) = -sqrt(2.0d0/api)*x*exp(-x**2/2.0d0)+derf(x/sqrt(2.0d0))-a
      df(x) = sqrt(2.0d0/api)*x**2*exp(-x**2/2.0d0)
!....
      api = acos( -1.0d0 )
!..
      do i = 1, kn
         a = ( i - 0.5d0 ) / kn
         ax = 1.0d0
         do it = 1, 20
            adx = f(ax)/(df(ax))
            ax = ax - adx
            if( abs(adx) .lt. aeps ) go to 1
         end do
         write(0,*) '### ERROR: not converge in qsmaxw3'
         call s2ext_abort
    1    continue
         fvx(i) = ax
      end do
!..
      do i = 1, kn
         fvx(i) = fvx(i) * fvt
      end do
!....
      return
      end
