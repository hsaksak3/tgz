!-------------------------------------------------------------------
! Set 2D File read STaRt
!
      subroutine s2fstr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/03/18
!----------------------------------------------------------------------
#include "spdat.macro"
      use parameter
      use profile
      use constant
      use particle
      include "implicit.h"
      integer :: i, ixp0, iyp0
      real*8  :: wxs, wxe, wys, wye, aionaz(lionspx), aionam(lionspx)
      integer, parameter :: iunit = 7
      real*8, parameter  :: aeps = 1.0d-20
      save
!....
      call fdebug ( 's2fstr', 0 )
!....
      open( iunit, file=bprffn, form='UNFORMATTED', status='OLD' )
!...
      read( iunit ) ixp0, iyp0
      write(6,*) 's2fstr: ixp0, iyp0', ixp0, iyp0
!...
      read( iunit ) lnoe
      write(6,*) 's2fstr: lnoe', lnoe
!++++
      if( lnoe .gt. lnoex ) then
         write(0,*) '### ERROR: lnoe .gt. lnoex', lnoe, lnoex
         call s2ext_abort
      end if
!++++
      lnoes = 1
      lnoee = lnoes + lnoe - 1
      read( iunit ) (spdat1(i),i=lnoes,lnoee)
!...
      if( smasr .gt. 1.0d-29 ) then
!..
         read( iunit ) lnoi, lionspl
         write(6,*) 's2fstr: lnoi, lionspl', lnoi, lionspl
!++++
         if( lnoe+lnoi .gt. lnox ) then
            write(0,*) '### ERROR: lnoe+lnpi .gt. lnox', lnoe,lnoi,lnox
            call s2ext_abort
         end if
         if( lionspl .gt. lionspx ) then
            write(0,*) '### ERROR: lionspl .gt. lionspx',lionspl,lionspx
            call s2ext_abort
         end if
!++++
         read( iunit ) &
            (lionids(i),i=1,lionspl), (lionide(i),i=1,lionspl), &
            (aionaz(i),i=1,lionspl), (aionam(i),i=1,lionspl)
!++++
         do i = 1, lionspl
            write(6,*) 's2fstr(i):', i, lionids(i), lionide(i)
            if( abs( aionaz(i)-sionaz(i) ) .gt. aeps ) then
               write(0,*) '### ERROR: sionaz mismacth', &
                                                i, aionaz(i), sionaz(i)
               call s2ext_abort
            end if
            if( abs( aionam(i)-sionam(i) ) .gt. aeps ) then
               write(0,*) '### ERROR: sionam mismacth', &
                                                i, aionam(i), sionam(i)
               call s2ext_abort
            end if
         end do
!++++
         do i = 1, lionspl
            lionidl(i) = lionide(i) - lionids(i) + 1
            sionaz(i) = aionaz(i)
            sionam(i) = aionam(i)
            sionqm(i)  = sionaz(i) / sionam(i) * smasr
            sionmm(i)  = sionam(i) / smasr
         end do
!..
         lnois = lnoee + 1
         lnoie = lnois + lnoi - 1
         read( iunit ) (spdat1(i),i=lnois,lnoie)
!...
      else
         lnoi  = 0
         lnois = 0
         lnoie = -1
         lionspl = 0
      end if
!....
      wxs =  1.0d30
      wys =  1.0d30
      wxe = -1.0d30
      wye = -1.0d30
      do i = lnoes, lnoee
         sxe(i) = sxe(i) + ( lxp0 - ixp0 )
         sye(i) = sye(i) + ( lyp0 - iyp0 )
         wxs = min( wxs, sxe(i) )
         wxe = max( wxe, sxe(i) )
         wys = min( wys, sye(i) )
         wye = max( wye, sye(i) )
      end do
!.
      do i = lnois, lnoie
         sxi(i) = sxi(i) + ( lxp0 - ixp0 )
         syi(i) = syi(i) + ( lyp0 - iyp0 )
      end do
!...
      lxps = wxs - 1
      lxpe = wxe + 2
      lyps = wys - 1
      lype = wye + 2
!....
      call fdebug ( 's2fstr', 1 )
!....
      return
      end
