!----------------------------------------------------------------------
! Set 2D EXTernal system BEGINning
!
      subroutine s2ext_begin
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
#ifdef OHHELP
      use parameter
      include "implicit.h"
      include "mpif.h"
      integer :: ierr
#include "../ohhelp/oh_config.h"
#endif
!....
      call fdebug ( 's2ext_begin', 0 )
!....
#ifdef OHHELP
      if( OH_DIMENSION .ne. 2 ) then
         write(0,*) '### ERROR: OH_DIMENSION must be defined with 2', &
                    OH_DIMENSION
         stop 88888
      end if
      call MPI_INIT ( ierr )
      if( ierr .ne. 0 ) then
         write(0,*) '### ERROR: MPI_INIT, ierr =', ierr
         stop 88888
      end if
      call MPI_COMM_SIZE ( MPI_COMM_WORLD, lsize, ierr )
      if( ierr .ne. 0 ) then
         write(0,*) '### ERROR: MPI_COMM_SIZE, ierr =', ierr
         call s2ext_abort
      end if
      call MPI_COMM_RANK ( MPI_COMM_WORLD, lrank, ierr )
      if( ierr .ne. 0 ) then
         write(0,*) '### ERROR: MPI_COMM_RANK, ierr =', ierr
         call s2ext_abort
      end if
#endif
!....
      call fdebug ( 's2ext_begin', 1 )
!....
      return
      end
