!----------------------------------------------------------------------
! Set 2D EXTernal system INITialize
!
      subroutine s2ext_init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!----------------------------------------------------------------------
#ifdef OHHELP
      use parameter
      use control
      use particle
      use constant
      use oh_param
      include "implicit.h"
#endif
!....
      call fdebug ( 's2ext_init', 0 )
!....
      call frames_init
!..
      call gdfxs_init
!....
#ifdef OHHELP
!..
      oh_lsize  = lsize
      oh_nspec  = lionspl + 1
      oh_pcoord(1) = ldivx
      oh_pcoord(2) = ldivy
      oh_nn = oh_pcoord(1) * oh_pcoord(2)
!..
      allocate( oh_totalp(oh_nspec,2), oh_nphgram(oh_nn,oh_nspec,2), &
                oh_sdoms(2,2,oh_nn),  oh_bounds(2,2,oh_nn) )
!..
      oh_nbound       = 2
      oh_nbor(1,1)    = -1
      oh_sdoms(1,1,1) = 0
      oh_sdoms(2,1,1) = -1
!..
      oh_ftypes(:,FDE) = (/1, 0,0,  0,0, 0,0/)
      oh_ftypes(:,FDI) = (/max(lionspl,1), 0,0,  0,0, 0,0/)
      oh_ftypes(:,FE ) = (/3, 0,0, -2,2, 0,0/)
      oh_ftypes(:,FB ) = (/3, 0,0, -2,2, 0,0/)
      oh_ftypes(:,FJT) = (/3, 0,0,  0,0,-3,3/)
      oh_ftypes(:,OJE) = (/6, 0,0,  0,0, 0,0/)
      oh_ftypes(:,OJI) = (/3*max(lionspl,1), 0,0,  0,0, 0,0/)
      oh_ftypes(:,OTE) = (/2, 0,0,  0,0, 0,0/)
      oh_ftypes(1,oh_num_field+1) = -1
!.
      oh_cfields(:) = (/FDE,FDI,FE,FB,FJT,OJE,OJI,OTE,0/)
!.
      oh_ctypes(:,:,1,FDE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,1,FDI) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,1,FE ) = reshape((/ 0,0,2, -2,-2,2/), (/3,2/))
      oh_ctypes(:,:,1,FB ) = reshape((/ 0,0,2, -2,-2,2/), (/3,2/))
      oh_ctypes(:,:,1,FJT) = reshape((/-3,3,5, -2,-8,5/), (/3,2/))
      oh_ctypes(:,:,1,OJE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,1,OJI) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,1,OTE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
!.
      oh_ctypes(:,:,2,FDE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,FDI) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,FE ) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,FB ) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,FJT) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,OJE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,OJI) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
      oh_ctypes(:,:,2,OTE) = reshape((/ 0,0,0,  0, 0,0/), (/3,2/))
!..
      select case( lbxlf )
      case( 1 )
        select case( lbylf )
        case( 1 )
          oh_bcond(:,:)  = reshape((/1,1, 1,1/), (/2,2/))
          oh_scoord(:,:) = reshape((/1,lssx, 1,lssy/), (/2,2/))
        case ( 4 )
          oh_bcond(:,:)  = reshape((/1,1, 2,2/), (/2,2/))
          oh_scoord(:,:) = reshape((/1,lssx, lblyl,lblyu-1/), (/2,2/))
        end select
      case( 4 )
        select case( lbylf )
        case( 1 )
          oh_bcond(:,:)  = reshape((/2,2, 1,1/), (/2,2/))
          oh_scoord(:,:) = reshape((/lblxl,lblxu-1, 1,lssy/), (/2,2/))
        case( 4 )
          oh_bcond(:,:)  = reshape((/2,2, 2,2/), (/2,2/))
          oh_scoord(:,:) = reshape((/lblxl,lblxu-1, lblyl,lblyu-1/), &
                                   (/2,2/))
        end select
      end select
!..
      call oh3_init ( oh_sdid,oh_nspec,lloadbf,oh_nphgram,oh_totalp, &
                      spdat1, oh_pbase, lnox, oh_mycomm, oh_nbor, &
                      oh_pcoord,oh_sdoms,oh_scoord,oh_nbound,oh_bcond, &
                      oh_bounds, oh_ftypes, oh_cfields, oh_ctypes, &
                      oh_fsizes, 0, 0, 0 )
      oh_currmode = 0
      oh_pevflag = 0
      oh_pivflag = 0
!..
      oh_alosizes(:,:,FDE) = oh_fsizes(:,:,FDE) + 1
      oh_alosizes(:,:,FDI) = oh_fsizes(:,:,FDI) + 1
      oh_alosizes(:,:,FE)  = oh_fsizes(:,:,FE) + 2
      oh_alosizes(:,:,FB)  = oh_fsizes(:,:,FB) + 2
      oh_alosizes(:,:,FJT) = oh_fsizes(:,:,FJT) + 2
      oh_alosizes(:,:,OJE) = oh_fsizes(:,:,OJE) + 1
      oh_alosizes(:,:,OJI) = oh_fsizes(:,:,OJI) + 1
      oh_alosizes(:,:,OTE) = oh_fsizes(:,:,OTE) + 1
!..
      call s2ext_conv ( 1 )
      call s2ext_conv ( 2 )
!..
      write(6,*) '@@@ bounds =', oh_bounds(:,:,lrank+1)
      write(6,*) '@@@ Global coordin. xl,xu,yl,yu =', &
                     oh_scoord(:,:)
      write(6,*) '@@@ Global position xl,xu,yl,yu =', &
                     oh_sdoms(:,:,lrank+1)
      write(6,*) '@@@ Local position  xl,xu,yl,yu =', &
                     oh_lssxl(1), oh_lssxu(1), oh_lssyl(1), oh_lssyu(1)
      write(6,*) '@@@ Local domain size x,y =', &
                     oh_sdoms(2,:,lrank+1)-oh_sdoms(1,:,lrank+1)
      if( lrank .eq. 0 ) then
        write(6,*) '@@@ Load Balance Factor =', lloadbf
        write(6,*) '@@@ FDE size xl,xu,yl,yu =', oh_alosizes(:,:,FDE)
        write(6,*) '@@@ FDI size xl,xu,yl,yu =', oh_alosizes(:,:,FDI)
        write(6,*) '@@@ FE  size xl,xu,yl,yu =', oh_alosizes(:,:,FE)
        write(6,*) '@@@ FB  size xl,xu,yl,yu =', oh_alosizes(:,:,FB)
        write(6,*) '@@@ FJT size xl,xu,yl,yu =', oh_alosizes(:,:,FJT)
        write(6,*) '@@@ OJE size xl,xu,yl,yu =', oh_alosizes(:,:,OJE)
        write(6,*) '@@@ OJI size xl,xu,yl,yu =', oh_alosizes(:,:,OJI)
        write(6,*) '@@@ OTE size xl,xu,yl,yu =', oh_alosizes(:,:,OTE)
      end if
!..
#endif
!....
      call fdebug ( 's2ext_init', 1 )
!....
      return
      end
