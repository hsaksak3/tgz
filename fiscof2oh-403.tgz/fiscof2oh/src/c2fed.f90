!----------------------------------------------------------------------
! Compute 2D Field Electric Differenctial
!
      subroutine c2fed
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/15
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c2fed', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
!..                                                            * TE *
            sdezdx(ix,iy) = ( sez(ix+1,iy) - sez(ix,iy) ) * s1o2
            sdezdy(ix,iy) = ( sez(ix,iy) - sez(ix,iy+1) ) * s1o2
!..                                                            * TM *
            sdeyxdxy(ix,iy) = ( sex(ix  ,iy) - sex(ix,iy-1) + &
                                sey(ix-1,iy) - sey(ix,iy  ) ) * s1o2
         end do
      end do
!..                                                            * TE *
!$OMP DO SCHEDULE(STATIC)
      do ix = lssxl, lssxup1
         sdezdy(ix,lssylm1) = ( sez(ix,lssylm1) - sez(ix,lssyl) ) * s1o2
      end do
!$OMP DO SCHEDULE(STATIC)
      do iy = lssyl, lssyup1
         sdezdx(lssxlm1,iy) = ( sez(lssxl,iy) - sez(lssxlm1,iy) ) * s1o2
      end do
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c2fed', 1 )
!....
      return
      end
