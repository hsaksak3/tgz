!-----------------------------------------------------------------------
! Boundary condition 2D Particle Electron Position
!                          /
      subroutine b2pep ( kmode )
!
!   <arguments>
!    !kmode : mode 0 = for perfect reflection /
!    !                      avoid rounding error for periodic condition
!     kmode : mode 0 = for perfect reflection
!                  1 = for periodic condition
!                  2 = for perfect reflection
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use ieee_arithmetic
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, ixe, iye, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!perio weps is needed. Run following program !!
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx
!peri stop
!peri end
!perio weps problem was solved by ieee_set_rounding_mode(ieee_down)
!peri Run following program !!
!peri use :: ieee_arithmetic
!peri call ieee_set_rounding_mode(ieee_down)
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx
!peri stop
!peri end
!....
      call fdebug( 'b2pep', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
      if( lexlpe .eq. 1 ) &
         call ieee_set_rounding_mode(ieee_down)
!...
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixe)
      do i = lnoes, lnoee
         ixe = sxe(i)
         if( ixe .lt. 1 ) then
            if( lexlpe .eq. 0 ) then
            else if( lexlpe .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sxe(i) = sxe(i) + lssxm1
               end if
            else if( lexlpe .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sxe(i) = s2o1 - sxe(i)
                  svxe(i) = - svxe(i)
                  suxe(i) = - suxe(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. lexlpe =',lexlpe
               call s2ext_abort
            end if
         else if ( ixe .gt. lssxm1 ) then
            if( lexupe .eq. 0 ) then
            else if( lexupe .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sxe(i) = sxe(i) - lssxm1
               end if
            else if( lexupe .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sxe(i) = s2o1 * lssx - sxe(i)
                  svxe(i) = - svxe(i)
                  suxe(i) = - suxe(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. lexupe =',lexupe
               call s2ext_abort
            end if
         end if
      end do
#else
      select case( lexlpe )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixe)
          do i = lnoes, lnoee
            ixe = sxe(i)
            if( ixe .lt. 1 ) then
              sxe(i) = sxe(i) + lssxm1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixe)
          do i = lnoes, lnoee
            ixe = sxe(i)
            if( ixe .lt. 1 ) then
              sxe(i) = s2o1 - sxe(i)
              svxe(i) = - svxe(i)
              suxe(i) = - suxe(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. lexlpe =',lexlpe
        call s2ext_abort
      end select
!.
      select case( lexupe )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixe)
          do i = lnoes, lnoee
            ixe = sxe(i)
            if( ixe .gt. lssxm1 ) then
              sxe(i) = sxe(i) - lssxm1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixe)
          do i = lnoes, lnoee
            ixe = sxe(i)
            if( ixe .gt. lssxm1 ) then
              sxe(i) = s2o1 * lssx - sxe(i)
              svxe(i) = - svxe(i)
              suxe(i) = - suxe(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. lexupe =',lexupe
        call s2ext_abort
      end select
#endif
!..
      if( lexlpe .eq. 1 .and. leylpe .ne. 1 ) &
         call ieee_set_rounding_mode(default_round_type)
      if( lexlpe .ne. 1 .and. leylpe .eq. 1 ) &
         call ieee_set_rounding_mode(ieee_down)
!..
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iye)
      do i = lnoes, lnoee
         iye = sye(i)
         if( iye .lt. 1 ) then
            if( leylpe .eq. 0 ) then
            else if( leylpe .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sye(i) = sye(i) + lssym1
               end if
            else if( leylpe .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sye(i) = s2o1 - sye(i)
                  svye(i) = - svye(i)
                  suye(i) = - suye(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. leylpe =',leylpe
               call s2ext_abort
            end if
         else if ( iye .gt. lssym1 ) then
            if( leyupe .eq. 0 ) then
            else if( leyupe .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sye(i) = sye(i) - lssym1
               end if
            else if( leyupe .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sye(i) = s2o1 * lssy - sye(i)
                  svye(i) = - svye(i)
                  suye(i) = - suye(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. leyupe =',leyupe
               call s2ext_abort
            end if
         end if
      end do
#else
      select case( leylpe )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iye)
          do i = lnoes, lnoee
            iye = sye(i)
            if( iye .lt. 1 ) then
              sye(i) = sye(i) + lssym1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iye)
          do i = lnoes, lnoee
            iye = sye(i)
            if( iye .lt. 1 ) then
              sye(i) = s2o1 - sye(i)
              svye(i) = - svye(i)
              suye(i) = - suye(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. leylpe =',leylpe
        call s2ext_abort
      end select
!.
      select case( leyupe )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iye)
          do i = lnoes, lnoee
            iye = sye(i)
            if( iye .gt. lssym1 ) then
              sye(i) = sye(i) - lssym1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iye)
          do i = lnoes, lnoee
            iye = sye(i)
            if( iye .gt. lssym1 ) then
              sye(i) = s2o1 * lssy - sye(i)
              svye(i) = - svye(i)
              suye(i) = - suye(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. leyupe =',leyupe
        call s2ext_abort
      end select
#endif
!....
      if( leylpe .eq. 1 ) &
        call ieee_set_rounding_mode(default_round_type)
#ifdef OHHELP
      if( kmode .eq. 1 ) call s2ext_param( 1, ips )
      end do
#endif
!....
      call fdebug( 'b2pep', 1 )
!....
      return
      end
