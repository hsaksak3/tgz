!-----------------------------------------------------------------------
! Boundary condition 2D Particle Ion Position
!                          /
      subroutine b2pip ( kmode )
!
!   <arguments>
!    !kmode : mode 0 = for perfect reflection /
!    !                      avoid rounding error for periodic condition
!     kmode : mode 0 = for perfect reflection
!                  1 = for periodic condition
!                  2 = for perfect reflection
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use ieee_arithmetic
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, ixi, iyi, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!perio weps is needed. Run following program !!
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx
!peri stop
!peri end
!perio weps problem was solved by ieee_set_rounding_mode(ieee_down)
!peri Run following program !!
!peri use :: ieee_arithmetic
!peri call ieee_set_rounding_mode(ieee_down)
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx 
!peri stop
!peri end
!....
      call fdebug( 'b2pip', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
      if( lexlpi .eq. 1 ) &
         call ieee_set_rounding_mode(ieee_down)
!...
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixi)
      do i = lnois, lnoie
         ixi = sxi(i)
         if( ixi .lt. 1 ) then
            if( lexlpi .eq. 0 ) then
            else if( lexlpi .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sxi(i) = sxi(i) + lssxm1
               end if
            else if( lexlpi .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sxi(i) = s2o1 - sxi(i)
                  svxi(i) = - svxi(i)
                  suxi(i) = - suxi(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. lexlpi =',lexlpi
               call s2ext_abort
            end if
         else if ( ixi .gt. lssxm1 ) then
            if( lexupi .eq. 0 ) then
            else if( lexupi .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  sxi(i) = sxi(i) - lssxm1
               end if
            else if( lexupi .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  sxi(i) = s2o1 * lssx - sxi(i)
                  svxi(i) = - svxi(i)
                  suxi(i) = - suxi(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. lexupi =',lexupi
               call s2ext_abort
            end if
         end if
      end do
#else
      select case( lexlpi )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixi)
          do i = lnois, lnoie
            ixi = sxi(i)
            if( ixi .lt. 1 ) then
              sxi(i) = sxi(i) + lssxm1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixi)
          do i = lnois, lnoie
            ixi = sxi(i)
            if( ixi .lt. 1 ) then
              sxi(i) = s2o1 - sxi(i)
              svxi(i) = - svxi(i)
              suxi(i) = - suxi(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. lexlpi =',lexlpi
        call s2ext_abort
      end select
!.
      select case( lexupi )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixi)
          do i = lnois, lnoie
            ixi = sxi(i)
            if( ixi .gt. lssxm1 ) then
              sxi(i) = sxi(i) - lssxm1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ixi)
          do i = lnois, lnoie
            ixi = sxi(i)
            if( ixi .gt. lssxm1 ) then
              sxi(i) = s2o1 * lssx - sxi(i)
              svxi(i) = - svxi(i)
              suxi(i) = - suxi(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. lexupi =',lexupi
        call s2ext_abort
      end select
#endif
!..
      if( lexlpi .eq. 1 .and. leylpi .ne. 1 ) &
         call ieee_set_rounding_mode(default_round_type)
      if( lexlpi .ne. 1 .and. leylpi .eq. 1 ) &
         call ieee_set_rounding_mode(ieee_down)
!..
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyi)
      do i = lnois, lnoie
         iyi = syi(i)
         if( iyi .lt. 1 ) then
            if( leylpi .eq. 0 ) then
            else if( leylpi .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  syi(i) = syi(i) + lssym1
               end if
            else if( leylpi .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  syi(i) = s2o1 - syi(i)
                  svyi(i) = - svyi(i)
                  suyi(i) = - suyi(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. leylpi =',leylpi
               call s2ext_abort
            end if
         else if ( iyi .gt. lssym1 ) then
            if( leyupi .eq. 0 ) then
            else if( leyupi .eq. 1 ) then
               if( kmode .eq. 1 ) then
                  syi(i) = syi(i) - lssym1
               end if
            else if( leyupi .eq. 2 ) then
               if( kmode .ne. 1 ) then
                  syi(i) = s2o1 * lssy - syi(i)
                  svyi(i) = - svyi(i)
                  suyi(i) = - suyi(i)
               end if
            else
               write(0,*) '### ERROR: not implemented. leyupi =',leyupi
               call s2ext_abort
            end if
         end if
      end do
#else
      select case( leylpi )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyi)
          do i = lnois, lnoie
            iyi = syi(i)
            if( iyi .lt. 1 ) then
              syi(i) = syi(i) + lssym1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyi)
          do i = lnois, lnoie
            iyi = syi(i)
            if( iyi .lt. 1 ) then
              syi(i) = s2o1 - syi(i)
              svyi(i) = - svyi(i)
              suyi(i) = - suyi(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. leylpi =',leylpi
        call s2ext_abort
      end select
!.
      select case( leyupi )
      case( 0 )
      case( 1 )
        if( kmode .eq. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyi)
          do i = lnois, lnoie
            iyi = syi(i)
            if( iyi .gt. lssym1 ) then
              syi(i) = syi(i) - lssym1
            end if
          end do
        end if
      case( 2 )
        if( kmode .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iyi)
          do i = lnois, lnoie
            iyi = syi(i)
            if( iyi .gt. lssym1 ) then
              syi(i) = s2o1 * lssy - syi(i)
              svyi(i) = - svyi(i)
              suyi(i) = - suyi(i)
            end if
          end do
        end if
      case default
        write(0,*) '### ERROR: not implemented. leyupi =',leyupi
        call s2ext_abort
      end select
#endif
!....
      if( leylpi .eq. 1 ) &
         call ieee_set_rounding_mode(default_round_type)
#ifdef OHHELP
      if( kmode .eq. 1 ) call s2ext_param( 2, ips )
      end do
#endif
!....
      call fdebug( 'b2pip', 1 )
!....
      return
      end
