!----------------------------------------------------------------------
! plasma profile
!
module profile
      use parameter
      integer :: &
         lpprof, lxp0, lyp0, lxps, lxpe, lyps, lype, &
         lpppl, lpppis(lpppx), lpppty(lpppx), &
         lppphis(lpppx), lppphie(lpppx)
      real*8 :: &
         spppxps(lpppx), spppyps(lpppx), spppds(lpppx), &
         spppxpe(lpppx), spppype(lpppx), spppde(lpppx), &
         spppnp(lpppx), spppnd(lpppx), spppte(lpppx), spppti(lpppx), &
         spppudxe(lpppx), spppudye(lpppx), spppudze(lpppx), &
         spppudxi(lpppx), spppudyi(lpppx), spppudzi(lpppx), &
         sppphxo(lppphx), sppphyo(lppphx), sppphrr(lppphx)
      character :: bprffn*64
end module profile
