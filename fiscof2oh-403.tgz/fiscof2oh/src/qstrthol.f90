!-------------------------------------------------------------------
! QSTaRT for HOLlow
!
      subroutine qstrthol ( kp, kxy, kyx, kho )
!
!   <arguments>
!     kp    : i  : index of profile
!     kxy   : i  : x (or y) mesh number
!     kyx   : i  : y (or x) mesh number
!     kho   :  o : hollow flag ( > 0 = inside of hollow circles )
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/05/16
!----------------------------------------------------------------------
      use profile
      use constant
      include "implicit.h"
      integer :: kp, kxy, kyx, kho, i
      real*8  :: wx, wy
      save
!....
      kho = 0
!....
      if( lpppty(kp) .eq. 11 ) then
         wx = ( kxy - lxp0 ) * slmicinv
         wy = ( kyx - lyp0 ) * slmicinv
      else if( lpppty(kp) .eq. 14 ) then
         wx = ( kyx - lxp0 ) * slmicinv
         wy = ( kxy - lyp0 ) * slmicinv
      else
         write(0,*) '### ERROR: invalid lpppty.', kp, lpppty(kp)
         call s2ext_abort
      end if
!..
      do i = lppphis(kp), lppphie(kp)
         if((wx-sppphxo(i))**2+(wy-sppphyo(i))**2.le.sppphrr(i)**2)then
            kho = i
            exit
         end if
      end do
!....
      return
      end
