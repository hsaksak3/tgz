      subroutine frames_init
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_init is here. @@@'
      return
      end
      subroutine frames_term
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_term is here. @@@'
      return
      end
      subroutine frames_file
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_file  is here. @@@'
      return
      end
      subroutine frames_body21
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body21 is here. @@@'
      return
      end
      subroutine frames_body22
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body22 is here. @@@'
      return
      end
      subroutine frames_body23
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body23 is here. @@@'
      return
      end
      subroutine frames_body24
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body24 is here. @@@'
      return
      end
      subroutine frames_body25
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body25 is here. @@@'
      return
      end
      subroutine frames_body26
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body26 is here. @@@'
      return
      end
      subroutine frames_body27
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body27 is here. @@@'
      return
      end
      subroutine frames_body28
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body28 is here. @@@'
      return
      end
