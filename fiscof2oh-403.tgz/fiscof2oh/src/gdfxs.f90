!----------------------------------------------------------------------
! igdfx interface routines
!
!----------------------
      subroutine gdfxs_init
!....
      call igdfx_init
!....
      return
      end
!----------------------
      subroutine gdfxs_term
!....
      call igdfx_term
!....
      return
      end
!----------------------
      subroutine gdfxs_bodys
      use animation
      include "implicit.h"
      integer :: icoll, icolh, im, ic, is, i, ivp, iwn, itrf, igf, &
                 ir, ig, ib, iopen
      real*4  :: wls, wle, wss, wse, whs, whe, wh, wl, ws, &
                 wxm, wxx, wym, wyx, wcoll1, wcolh1
!....
      icoll = 21
      icolh = 10
!.
      wcoll1 = icoll - 1
      wcolh1 = icolh - 1
!....
      do im = 1, lagfl
!....
      call igdfx_inqgif ( im, iopen )
      if( iopen .eq. 0 ) then
!...
      call igdfx_opngif ( im, lagifw(im), lagifh(im) )
!..
      do ic = 1, 6
         whs = (ic-1)*60.
!                                     * blue is dark, so up lightness *
         if( ic .eq. 5 ) then
            wls = 0.3
         else
            wls = 0.2
         end if
         wss = 1.0
         whe = (ic-1)*60.
         wle = 0.9
         wse = 1.0
         is = 10 + (ic-1) * icoll
         do i = 1, icoll
            wh = whs + ( whe - whs ) * (i-1) / wcoll1
            wl = wls + ( wle - wls ) * (i-1) / wcoll1
            ws = wss + ( wse - wss ) * (i-1) / wcoll1
            call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
            call igdfx_defcol ( is+i-1, ir, ig, ib )
         end do
      end do
!.
      ic = 7
      whs = 240.0
      wls = 0.6
      wss = 1.0
      whe = 240.0
      wle = 0.35
      wse = 0.25
      is = 10 + (ic-1) * icoll
      do i = 1, icolh
         wh = whs + ( whe - whs ) * (i-1) / wcolh1
         wl = wls + ( wle - wls ) * (i-1) / wcolh1
         ws = wss + ( wse - wss ) * (i-1) / wcolh1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
      call igdfx_hls2rgb ( 300.0, 0.2, 0.0, ir, ig, ib )
      call igdfx_defcol ( is+icolh, ir, ig, ib )
      whs = 0.0
      wls = 0.25
      wss = 0.25
      whe = 0.0
      wle = 0.7
      wse = 1.0
      is = is + icolh + 1
      do i = 1, icolh
         wh = whs + ( whe - whs ) * (i-1) / wcolh1
         wl = wls + ( wle - wls ) * (i-1) / wcolh1
         ws = wss + ( wse - wss ) * (i-1) / wcolh1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
!.
      ic = 8
      whs = 0.0
      wls = 0.3
      wss = 1.0
      whe = 60.0
      wle = 0.7
      wse = 1.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
!.
      ic = 9
      whs = 0.0
      wls = 0.2
      wss = 0.0
      whe = 0.0
      wle = 1.0
      wse = 0.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
!.
      ic = 10
      whs = 240.0
      wls = 0.5
      wss = 1.0
      whe = 0.0
      wle = 0.5
      wse = 1.0
      is = 10 + (ic-1) * icoll
      do i = 1, icoll
         wh = whs + ( whe - whs ) * (i-1) / wcoll1
         wl = wls + ( wle - wls ) * (i-1) / wcoll1
         ws = wss + ( wse - wss ) * (i-1) / wcoll1
         call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
         call igdfx_defcol ( is+i-1, ir, ig, ib )
      end do
!..
      do i = 1, lavpl
         wxm = savpxm(i)
         wxx = savpxx(i)
         wym = savpym(i)
         wyx = savpyx(i)
         call igdfx_defvwp ( i, wxm, wxx, wym, wyx )
      end do
!..
      do i = 1, lawnl
         wxm = sawnxm(i)
         wxx = sawnxx(i)
         wym = sawnym(i)
         wyx = sawnyx(i)
         call igdfx_defwin ( i, wxm, wxx, wym, wyx )
      end do
!..
      itrf = 0
      do i = 1, lavpl
         lagifv(i,im) = 0
         lavpc(i,im)  = 0
      end do
!.
      do i = 1, lafdel
         igf = mod( lafde(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafde(i) / 10, 10 )
            iwn = mod( lafde(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafdegt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafdil
         igf = mod( lafdi(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafdi(i) / 10, 10 )
            iwn = mod( lafdi(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafdigt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafedel
         igf = mod( lafede(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafede(i) / 10, 10 )
            iwn = mod( lafede(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafedegt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafedil
         igf = mod( lafedi(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafedi(i) / 10, 10 )
            iwn = mod( lafedi(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafedigt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafjexl
         igf = mod( lafjex(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafjex(i) / 10, 10 )
            iwn = mod( lafjex(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafjexgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafjeyl
         igf = mod( lafjey(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafjey(i) / 10, 10 )
            iwn = mod( lafjey(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafjeygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafjezl
         igf = mod( lafjez(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafjez(i) / 10, 10 )
            iwn = mod( lafjez(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafjezgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafeal
         igf = mod( lafea(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafea(i) / 10, 10 )
            iwn = mod( lafea(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafeagt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafexl
         igf = mod( lafex(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafex(i) / 10, 10 )
            iwn = mod( lafex(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafexgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafeyl
         igf = mod( lafey(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafey(i) / 10, 10 )
            iwn = mod( lafey(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafeygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafezl
         igf = mod( lafez(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafez(i) / 10, 10 )
            iwn = mod( lafez(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafezgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafbal
         igf = mod( lafba(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafba(i) / 10, 10 )
            iwn = mod( lafba(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafbagt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafbxl
         igf = mod( lafbx(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafbx(i) / 10, 10 )
            iwn = mod( lafbx(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafbxgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafbyl
         igf = mod( lafby(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafby(i) / 10, 10 )
            iwn = mod( lafby(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafbygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lafbzl
         igf = mod( lafbz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lafbz(i) / 10, 10 )
            iwn = mod( lafbz(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lafbzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapepl
         igf = mod( lapep(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapep(i) / 10, 10 )
            iwn = mod( lapep(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapepgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapeuxyl
         igf = mod( lapeuxy(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapeuxy(i) / 10, 10 )
            iwn = mod( lapeuxy(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapeuxygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapeuxzl
         igf = mod( lapeuxz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapeuxz(i) / 10, 10 )
            iwn = mod( lapeuxz(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapeuxzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapeuyzl
         igf = mod( lapeuyz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapeuyz(i) / 10, 10 )
            iwn = mod( lapeuyz(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapeuyzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapexuxl
         igf = mod( lapexux(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapexux(i) / 10, 10 )
            iwn = mod( lapexux(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapexuxgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapexuyl
         igf = mod( lapexuy(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapexuy(i) / 10, 10 )
            iwn = mod( lapexuy(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapexuygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapexuzl
         igf = mod( lapexuz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapexuz(i) / 10, 10 )
            iwn = mod( lapexuz(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapexuzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapipl
         igf = mod( lapip(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapip(i) / 10, 10 )
            iwn = mod( lapip(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapipgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapiuxyl
         igf = mod( lapiuxy(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapiuxy(i) / 10, 10 )
            iwn = mod( lapiuxy(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapiuxygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapixuxl
         igf = mod( lapixux(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapixux(i) / 10, 10 )
            iwn = mod( lapixux(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapixuxgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapixuyl
         igf = mod( lapixuy(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapixuy(i) / 10, 10 )
            iwn = mod( lapixuy(i) / 100, 10 )
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapixuygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!..
      else
         do i = 1, lavpl
            lagifv(i,im) = -1
            lavpc(i,im)  = -1
         end do
      end if
!....
      end do
!....
      return
      end
!----------------------
      subroutine gdfxs_body21 ( kno, fpdat1,kl, ex, ey, fsn,fsx,kic, &
                               fxof, fxfac, fyof, fyfac, elab )
      use animation
      include "implicit.h"
      type ty1_particle
         sequence
         real*8  :: fpv(5), fuu, fpf
         integer :: knid, kclfl
      end type ty1_particle
      type(ty1_particle) :: fpdat1(kl)
      integer :: kno, kl, kic, ix, iy, igf, itf, ivp, iwn, i, ics, icol
      real*8  :: fsn, fsx, fxof, fxfac, fyof, fyfac, &
                 aeps=1.0d-6
      real*4  :: wx, wy, w0o1=0.0, &
                 wvxm, wvxx, wvym, wvyx, wwxm, wwxx, wwym, wwyx
      character*(*) ex, ey, elab
      character*24 cvalue
!....
      igf = mod( kno, 10 )
      itf = kno / 10
!.
      if( ex .eq. 'x' ) then
         ix = 1
      else if( ex .eq. 'y' ) then
         ix = 2
      else if( ex .eq. 'ux' ) then
         ix = 3
      else if( ex .eq. 'uy' ) then
         ix = 4
      else if( ex .eq. 'uz' ) then
         ix = 5
      else
         write(0,*) '### ERROR: invalid ex ', ex
      end if
!
      if( ey .eq. 'x' ) then
         iy = 1
      else if( ey .eq. 'y' ) then
         iy = 2
      else if( ey .eq. 'ux' ) then
         iy = 3
      else if( ey .eq. 'uy' ) then
         iy = 4
      else if( ey .eq. 'uz' ) then
         iy = 5
      else
         write(0,*) '### ERROR: invalid ey ', ey
      end if
!..
      call igdfx_selgif ( igf )
      call igdfx_seltrf ( itf )
!..
      ics = 10 + (kic-1) * 21 + 20
      do i = 1, kl
         icol = ics - (fpdat1(i)%fpf- fsn)/max(fsx-fsn,aeps) * 20.0d0
         call igdfx_sellcl ( icol )
         wx = ( fpdat1(i)%fpv(ix) - fxof ) * fxfac
         wy = ( fpdat1(i)%fpv(iy) - fyof ) * fyfac
         call igdfx_drwpoi ( wx, wy )
      end do
!...
      if( elab(1:1) .ne. ' ' ) then
         call igdfx_inqtrf ( itf, ivp, iwn, wvxm, wvxx, wvym, wvyx, &
                                        wwxm, wwxx, wwym, wwyx )
         call igdfx_sellcl ( 3 )
         call igdfx_drwlin ( wwxm, w0o1, wwxx, w0o1 )
         call igdfx_drwlin ( w0o1, wwym, w0o1, wwyx )
!.
         ix = lagifw(igf) *  wvxx - 60
         iy = lagifh(igf) * ( 1.0 - wvym ) - lavpc(ivp,igf)*10 - 15
         write( cvalue(1:10), '(e10.3)' ) wwxx
         cvalue(11:24) = '$'
         call igdfx_seltcl ( ics )
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         ix = lagifw(igf) * wvxm  + 2
         write( cvalue(1:10), '(e10.3)' ) wwym
         cvalue(11:12) = ', '
         write( cvalue(13:22), '(e10.3)' ) wwxm
         cvalue(23:24) = '$'
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         iy = lagifh(igf) * ( 1.0 - wvyx ) + lavpc(ivp,igf)*10 + 2
         write( cvalue(1:10), '(e10.3)' ) wwyx
         call igdfx_drwtxt ( ix, iy, 2, &
                           cvalue(1:10)//' '//elab(1:len(elab))//'$ ' )
!.
         lavpc(ivp,igf) = lavpc(ivp,igf) + 1
      end if
!....
      return
      end
!----------------------
      subroutine gdfxs_body22 ( kno, fdata,kxs,kxe,kys,kye,kclip,kic, &
                             fnrm,fxof,fxd,fyof,fyd, ffac, klog, elab )
!
! kclip : xy (y=lower clip, x=upper clip)
!
      use animation
      include "implicit.h"
      integer :: kno, kxs, kxe, kys, kye, kclip, kic, klog, &
                 igf, itf, ics, ilc, iuc, ix, iy, icol, ivp, iwn
      real*8  :: fdata(kxs:kxe,kys:kye), fnrm, fxof, fxd, fyof, fyd, &
                 ffac, aeps=1.0d-6, aawnzm, aawnzx, adata, &
                 aminlog=1.0d-3
      real*4  :: wxs, wys, wxe, wye, w0o1=0.0, &
                 wvxm, wvxx, wvym, wvyx, wwxm, wwxx, wwym, wwyx
      character*(*) elab
      character*16 cvalue
!....
      igf = mod( kno, 10 )
      itf = kno / 10
      ics = 10 + (kic-1) * 21
!.
      ilc = mod( kclip, 2)
      iuc = kclip / 10
!.
      call igdfx_selgif ( igf )
      call igdfx_seltrf ( itf )
      call igdfx_inqtrf ( itf, ivp, iwn, wvxm, wvxx, wvym, wvyx, &
                                        wwxm, wwxx, wwym, wwyx )
!..
      if( sawnzm(iwn) .gt. sawnzx(iwn) ) then
         aawnzm = 1.0d30
         aawnzx = -1.0d30
         do iy = kys, kye
           wys = ( iy - fyof - fyd - 0.5d0 ) * ffac
           wye = ( iy - fyof - fyd + 0.5d0 ) * ffac
           do ix = kxs, kxe
             wxs = ( ix - fxof - fxd - 0.5d0 ) * ffac
             wxe = ( ix - fxof - fxd + 0.5d0 ) * ffac
             if( wxs .ge. sawnxm(iwn) .and. wxe .le. sawnxx(iwn) .and. &
                wys .ge. sawnym(iwn) .and. wye .le. sawnyx(iwn) ) then
               adata = fdata(ix,iy) * fnrm
               aawnzm = min( aawnzm, adata )
               aawnzx = max( aawnzx, adata )
             end if
           end do
         end do
      else
         aawnzm = sawnzm(iwn)
         aawnzx = sawnzx(iwn)
      end if
!.
      if( klog .eq. 1 ) then
         aawnzm = log10( max( aawnzm, aminlog ) )
         aawnzx = log10( max( aawnzx, aminlog ) )
      end if
!..
      do iy = kys, kye
         wys = ( iy - fyof - fyd - 0.5d0 ) * ffac
         wye = ( iy - fyof - fyd + 0.5d0 ) * ffac
         do ix = kxs, kxe
            wxs = ( ix - fxof - fxd - 0.5d0 ) * ffac
            wxe = ( ix - fxof - fxd + 0.5d0 ) * ffac
            if( wxs .ge. sawnxm(iwn) .and. wxe .le. sawnxx(iwn) .and. &
               wys .ge. sawnym(iwn) .and. wye .le. sawnyx(iwn) ) then
               adata = fdata(ix,iy) * fnrm
               if( klog .eq. 1 ) adata = log10( max( adata, aminlog ) )
               icol = ( adata - aawnzm ) /  &
                                  max( aawnzx - aawnzm, aeps ) * 22.0d0
               if( icol .lt. 1 .and. ilc .eq. 1 ) icol = 1
               if( icol .gt. 21 .and. iuc .eq. 1 ) icol = 21
               if( icol .ge. 1 .and. icol .le. 21 ) then
                  call igdfx_selfcl ( ics+icol-1 )
                  call igdfx_drwrec ( wxs, wys, wxe, wye, 10 )
               end if
            end if
         end do
      end do
!...
      if( elab(1:1) .ne. ' ' ) then
         call igdfx_sellcl ( 3 )
         call igdfx_drwlin ( wwxm, w0o1, wwxx, w0o1 )
         call igdfx_drwlin ( w0o1, wwym, w0o1, wwyx )
!.
         call igdfx_selfcl ( 3 )
         wys = ( (lavpc(ivp,igf)-1) * 10 + 13.0d0 ) * &
                                 (wwyx-wwym)/((wvyx-wvym)*lagifh(igf))
         wye = (  lavpc(ivp,igf) * 10 + 15.0d0 ) * &
                                 (wwyx-wwym)/((wvyx-wvym)*lagifh(igf))
         wxe = 6.5d0 * 10 * (wwxx-wwxm)/((wvxx-wvxm)*lagifw(igf))
         call igdfx_drwrec ( wwxm, wwym+wys, wwxm+wxe, wwym+wye, 10 )
         wxe = 6.5d0 * (11+len(elab)) *  &
                                 (wwxx-wwxm)/((wvxx-wvxm)*lagifw(igf))
         call igdfx_drwrec ( wwxm, wwyx-wys, wwxm+wxe, wwyx-wye, 10 )
!.
         ix = lagifw(igf) * wvxm  + 2
         iy = lagifh(igf) * ( 1.0 - wvym ) - lavpc(ivp,igf)*10 - 15
         write( cvalue(1:10), '(e10.3)' ) aawnzm
         cvalue(11:16) = '$'
         call igdfx_seltcl ( ics )
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         iy = lagifh(igf) * ( 1.0 - wvyx ) + lavpc(ivp,igf)*10 + 2
         write( cvalue(1:10), '(e10.3)' ) aawnzx
         call igdfx_seltcl ( ics+20 )
         call igdfx_drwtxt ( ix, iy, 2, &
                           cvalue(1:10)//' '//elab(1:len(elab))//'$ ' )
!.
         lavpc(ivp,igf) = lavpc(ivp,igf) + 1
      end if
!....
      return
      end
!----------------------
      subroutine gdfxs_body23 ( kno, fpdat1,kl,ki, ex, ey, eth, &
                                fsn,fsx,kic, &
                     fxof,fxfac, fyof,fyfac, fthof,fthfac, elab )
      use animation
      include "implicit.h"
      type ty1_particle
         sequence
         real*8  :: fpv(6), fpf
         integer :: knid, kclfl
      end type ty1_particle
      type(ty1_particle) :: fpdat1(kl)
      integer :: kno, kl,ki, kic, igf, itf, ix,iy,ith, i, ics, icol, &
                 ivp, iwn
      real*8  :: fsn, fsx, fxof, fxfac, fyof, fyfac, fthof, fthfac, &
                 aeps=1.0d-6, ath
      real*4  :: wx, wy, w0o1=0.0, &
                 wvxm, wvxx, wvym, wvyx, wwxm, wwxx, wwym, wwyx
      character*(*) ex, ey, eth, elab
      character*24 cvalue
!....
      igf = mod( kno, 10 )
      itf = kno / 10
!.
      if( ex .eq. 'x' ) then
         ix = 1
      else if( ex .eq. 'y' ) then
         ix = 2
      else if( ex .eq. 'ux' ) then
         ix = 3
      else if( ex .eq. 'uy' ) then
         ix = 4
      else if( ex .eq. 'uz' ) then
         ix = 5
      else
         write(0,*) '### ERROR: invalid ex ', ex
      end if
!
      if( ey .eq. 'x' ) then
         iy = 1
      else if( ey .eq. 'y' ) then
         iy = 2
      else if( ey .eq. 'ux' ) then
         iy = 3
      else if( ey .eq. 'uy' ) then
         iy = 4
      else if( ey .eq. 'uz' ) then
         iy = 5
      else
         write(0,*) '### ERROR: invalid ey ', ey
      end if
!
      if( eth .eq. 'x' ) then
         ith = 1
      else if( eth .eq. 'y' ) then
         ith = 2
      else if( eth .eq. 'ux' ) then
         ith = 3
      else if( eth .eq. 'uy' ) then

      else if( eth .eq. 'uz' ) then
         ith = 5
      else if( eth .eq. 'uu' ) then
         ith = 6
      else
         write(0,*) '### ERROR: invalid eth ', eth
      end if
!..
      call igdfx_selgif ( igf )
      call igdfx_seltrf ( itf )
      call igdfx_inqtrf ( itf, ivp, iwn, wvxm, wvxx, wvym, wvyx, &
                                         wwxm, wwxx, wwym, wwyx )
!..
      ics = 10 + (kic-1) * 21 + 20
      do i = 1, kl, ki
         ath = ( fpdat1(i)%fpv(ith)  - fthof ) * fthfac
         if( ath.ge.sawnzm(iwn) .and. ath.le.sawnzx(iwn) ) then
            icol = ics - (fpdat1(i)%fpf-fsn)/max(fsx-fsn,aeps) * 20.0d0
            call igdfx_sellcl ( icol )
            wx = ( fpdat1(i)%fpv(ix) - fxof ) * fxfac
            wy = ( fpdat1(i)%fpv(iy) - fyof ) * fyfac
            call igdfx_drwpoi ( wx, wy )
         end if
      end do
!...
      if( elab(1:1) .ne. ' ' ) then
         call igdfx_sellcl ( 3 )
         call igdfx_drwlin ( wwxm, w0o1, wwxx, w0o1 )
         call igdfx_drwlin ( w0o1, wwym, w0o1, wwyx )
!.
         ix = lagifw(igf) *  wvxx - 60
         iy = lagifh(igf) * ( 1.0 - wvym ) - lavpc(ivp,igf)*10 - 15
         write( cvalue(1:10), '(e10.3)' ) wwxx
         cvalue(11:24) = '$'
         call igdfx_seltcl ( ics )
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         ix = lagifw(igf) * wvxm  + 2
         write( cvalue(1:10), '(e10.3)' ) wwym
         cvalue(11:12) = ', '
         write( cvalue(13:22), '(e10.3)' ) wwxm
         cvalue(23:24) = '$'
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         iy = lagifh(igf) * ( 1.0 - wvyx ) + lavpc(ivp,igf)*10 + 2
         write( cvalue(1:10), '(e10.3)' ) wwyx
         call igdfx_drwtxt ( ix, iy, 2, &
                           cvalue(1:10)//' '//elab(1:len(elab))//'$ ' )
!.
         lavpc(ivp,igf) = lavpc(ivp,igf) + 1
      end if
!....
      return
      end
!----------------------
      subroutine gdfxs_body24 ( kno, fpdat1,fpdat2, kl,ki,kic, &
                     fxof,fxfac, fyof,fyfac, fthof,fthfac, elab )
      use animation
      use ptcltype
      include "implicit.h"
      type(ty1_particle) :: fpdat1(kl)
      type(ty2_particle) :: fpdat2(kl)
      integer :: kno, kl,ki, kic, igf, itf, i, ics, icol, ivp, iwn, &
                 ix, iy, inum
      real*8  :: fxof, fxfac, fyof, fyfac, fthof, fthfac, ath
      real*4  :: wxs, wys, wxe, wye, w0o1=0.0, &
                 wvxm, wvxx, wvym, wvyx, wwxm, wwxx, wwym, wwyx
      character*(*) elab
      character*24 cvalue
!....
      igf = mod( kno, 10 )
      itf = kno / 10
!..
      call igdfx_selgif ( igf )
      call igdfx_seltrf ( itf )
      call igdfx_inqtrf ( itf, ivp, iwn, wvxm, wvxx, wvym, wvyx, &
                                         wwxm, wwxx, wwym, wwyx )
!..
      inum = 0
      ics = 10 + (kic-1) * 21
      do i = 1, kl, ki
         inum = inum + 1
         ath = ( fpdat1(i)%uu  - fthof ) * fthfac
         if( ath.ge.sawnzm(iwn) .and. ath.le.sawnzx(iwn) ) then
            icol = ics + mod(inum,21)
            call igdfx_sellcl ( icol )
            wxs = ( fpdat2(i)%xo - fxof ) * fxfac
            wys = ( fpdat2(i)%yo - fyof ) * fyfac
            wxe = ( fpdat1(i)%x - fxof ) * fxfac
            wye = ( fpdat1(i)%y - fyof ) * fyfac
            call igdfx_drwlin ( wxs, wys, wxe, wye )
         end if
      end do
!...
      if( elab(1:1) .ne. ' ' .and. lavpc(ivp,igf) .ge. 0 ) then
         call igdfx_sellcl ( 3 )
         call igdfx_drwlin ( wwxm, w0o1, wwxx, w0o1 )
         call igdfx_drwlin ( w0o1, wwym, w0o1, wwyx )
!.
         ix = lagifw(igf) *  wvxx - 60
         iy = lagifh(igf) * ( 1.0 - wvym ) - lavpc(ivp,igf)*10 - 15
         write( cvalue(1:10), '(e10.3)' ) wwxx
         cvalue(11:24) = '$'
         call igdfx_seltcl ( 2 )
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         ix = lagifw(igf) * wvxm  + 2
         write( cvalue(1:10), '(e10.3)' ) wwym
         cvalue(11:12) = ', '
         write( cvalue(13:22), '(e10.3)' ) wwxm
         cvalue(23:24) = '$'
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         iy = lagifh(igf) * ( 1.0 - wvyx ) + lavpc(ivp,igf)*10 + 2
         write( cvalue(1:10), '(e10.3)' ) wwyx
         call igdfx_drwtxt ( ix, iy, 2, &
                           cvalue(1:10)//' '//elab(1:len(elab))//'$ ' )
!.
         lavpc(ivp,igf) = lavpc(ivp,igf) + 1
      end if
!....
      return
      end
!----------------------
      subroutine gdfxs_bodye
      use parameter
      use constant
      use observe
      use animation
      include "implicit.h"
      integer :: im, i, iapp
      character(16) :: ctime, ctimeo=' $ '
      save
!....
      write( ctime(1:8), '(f8.2)' ) sstcur
      ctime(9:16) = '$'
!....
      do im = 1, lagfl
!...
         iapp = lamode(im) / 10
!...
         call igdfx_selgif ( im )
!..
         do i = 1, lavpl
            if( lagifv(i,im) .gt. 0 ) call igdfx_drwvwp ( i )
         end do
!..
         if( iapp .eq. 1 ) then
            call igdfx_seltcl ( 1 )
            call igdfx_drwtxt ( lagifw(im)-60, 5, 3, ctimeo )
            ctimeo = ctime
         end if
         call igdfx_seltcl ( 2 )
         call igdfx_drwtxt ( lagifw(im)-60, 5, 3, ctime )
!..
         call fntpcnv ( banfntp(im), lrank,im, bident,'an', bfile )
         call igdfx_clsgif ( im, trim(bfile)//'$ ', lamode(im) )
!....
      end do
!....
      return
      end
