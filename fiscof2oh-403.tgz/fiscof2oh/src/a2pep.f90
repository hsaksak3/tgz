!-----------------------------------------------------------------------
! Advance 2D Particle Electron Position ( half step )
!                          /
      subroutine a2pep ( kmode )
!
!   <arguments>
!     kmode : mode 1 = save data
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
! modified by Sakagami,H. (NIFS) 21/04/13
!-----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use particle
      include "implicit.h"
      integer :: i, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug( 'a2pep',0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL
      if( kmode .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
         do i = lnoes, lnoee
            sxeo(i) = sxe(i)
            syeo(i) = sye(i)
         end do
      end if
!$OMP DO SCHEDULE(STATIC)
      do i = lnoes, lnoee
         sxe(i) = sxe(i) + svxe(i) * s1o2
         sye(i) = sye(i) + svye(i) * s1o2
      end do
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug( 'a2pep', 1 )
!....
      return
      end
