#include <stdio.h>
#define gdMaxColors 256

typedef struct gdImageStruct {
        unsigned char ** pixels; 
        int sx;
        int sy;
        int colorsTotal;
        int red[gdMaxColors];
        int green[gdMaxColors];
        int blue[gdMaxColors]; 
        int open[gdMaxColors];
        int transparent;
        int *polyInts;
        int polyAllocated;
        struct gdImageStruct *brush; 
        struct gdImageStruct *tile;     
        int brushColorMap[gdMaxColors];
        int tileColorMap[gdMaxColors];
        int styleLength;
        int stylePos;
        int *style; 
        int interlace;
} gdImage;

typedef gdImage * gdImagePtr;

main (argc,argv)
int argc;
char *argv[];
{
	int isp;
	gdImagePtr im;

	isp = sizeof(im);
	printf("size of gdImagePtr: %d\n", isp);
}
