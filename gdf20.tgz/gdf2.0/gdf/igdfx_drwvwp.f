c----------------------------------------------------------------------
c igdfx draw viewport frame
c                                 /
      subroutine igdfx_drwvwp ( kvpno )
c
c   <arguments>
c     kvpno : viewport number
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_drwvwp] image was not selected'
         go to 999
      end if
      if( lgxvpt(kvpno,lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_drwvwp] viewport was not selected'
	 go to 999
      end if
c....
      ixm = sgxvpt(1,kvpno,lgxgic) * ( lgxwht(1,lgxgic) - 1 )
      ixx = sgxvpt(3,kvpno,lgxgic) * ( lgxwht(1,lgxgic) - 1 )
      iym = sgxvpt(2,kvpno,lgxgic) * ( lgxwht(2,lgxgic) - 1 )
      iyx = sgxvpt(4,kvpno,lgxgic) * ( lgxwht(2,lgxgic) - 1 )
      iym = lgxwht(2,lgxgic) - 1 - iym
      iyx = lgxwht(2,lgxgic) - 1 - iyx
c..
      call igdf_line ( lgximt(lgxgic), ixm ,iym, ixx, iym,
     $                                               lgxclt(3,lgxgic) )
      call igdf_line ( lgximt(lgxgic), ixx ,iym, ixx, iyx,
     $                                               lgxclt(3,lgxgic) )
      call igdf_line ( lgximt(lgxgic), ixx ,iyx, ixm, iyx,
     $                                               lgxclt(3,lgxgic) )
      call igdf_line ( lgximt(lgxgic), ixm ,iyx, ixm, iym,
     $                                               lgxclt(3,lgxgic) )
c....
  999 continue
      return
      end
