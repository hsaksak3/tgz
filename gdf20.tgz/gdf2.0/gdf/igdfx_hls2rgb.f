c----------------------------------------------------------------------
c convert hls to rgb
c                                 /   /   /
      subroutine igdfx_hls2rgb ( fh, fl, fs, kr, kg, kb )
c                                            /   /   /
c  <arguments>
c     fh : hue
c     fl : lightness
c     fs : saturation
c     kr : red intensity
c     kg : green intensity
c     kb : blue intensity
c
c  <remarks>
c     values must be in the range as follows.
c        0 <= fh <= 360
c        0 <= fl <= 1
c        0 <= fs <= 1
c        0 <= kr <= 255
c        0 <= kg <= 255
c        0 <= kb <= 255
c
c    coded by sakagami,h. ( HIT ) 00/10/18
c----------------------------------------------------------------------
c....
      data weps / 1.0e-3 /
c....
      if( fl .le. 0.5 ) then
         w2 = fl * ( 1.0 + fs )
      else
         w2 = fl + fs - fl * fs
      end if
      w1 = 2.0 * fl - w2
c....
      if( fs .le. weps ) then
         wr = fl
         wg = fl
         wb = fl
      else
         wh = fh + 120.0
         if( wh .gt. 360.0 ) wh = wh - 360.0
         if( wh .lt.   0.0 ) wh = wh + 360.0
c..
         if( wh .le. 60.0 ) then
            wr = w1 + ( w2 - w1 ) * wh / 60.0
         else if( wh .le. 180.0 ) then
            wr = w2
         else if( wh .le. 240.0 ) then
            wr = w1 + ( w2 - w1 ) * ( 240.0 - wh ) / 60.0
         else
            wr = w1
         end if
c...
         if( fh .le. 60.0 ) then
            wg = w1 + ( w2 - w1 ) * fh / 60.0
         else if( fh .le. 180.0 ) then
            wg = w2
         else if( fh .le. 240.0 ) then
            wg = w1 + ( w2 - w1 ) * ( 240.0 - fh ) / 60.0
         else
            wg = w1
         end if
c...
         wh = fh - 120.0
         if( wh .gt. 360.0 ) wh = wh - 360.0
         if( wh .lt.   0.0 ) wh = wh + 360.0
c..
         if( wh .le. 60.0 ) then
            wb = w1 + ( w2 - w1 ) * wh / 60.0
         else if( wh .le. 180.0 ) then
            wb = w2
         else if( wh .le. 240.0 ) then
            wb = w1 + ( w2 - w1 ) * ( 240.0 - wh ) / 60.0
         else
            wb = w1
         end if
      end if
c....
      kr = wr * 255.0
      kg = wg * 255.0
      kb = wb * 255.0
c....
      return
      end
