c----------------------------------------------------------------------
c igdfx common
c
      parameter( lgxgix = 10, lgxvpx = 6, lgxwnx = 10, lgxtfx = 20 )
      integer*8 lgximt
      common /igdfxj/ lgximt(lgxgix)
      common /igdfxi/ lgxgic, lgxwht(2,lgxgix),
     $                lgxtfc(lgxgix), lgxtft(2,lgxtfx,lgxgix),
     $                lgxvpt(lgxvpx,lgxgix), lgxwnt(lgxwnx,lgxgix),
     $                lgxlcl(lgxgix), lgxfcl(lgxgix), lgxtcl(lgxgix),
     $                lgxclt(255,lgxgix)
      common /igdfxr/ sgxvpt(4,lgxvpx,lgxgix), sgxwnt(4,lgxwnx,lgxgix)
