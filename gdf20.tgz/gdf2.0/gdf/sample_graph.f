	dimension tamex(4),tamey(4),tamey2(4),tamey3(4)
	tamex(1)=1.0
	tamex(2)=5.0
	tamex(3)=11.0
	tamey(1)=1.0
	tamey(2)=10.0
	tamey(3)=22.0
	tamey2(1)=5.0	
	tamey2(2)=14.0
	tamey2(3)=26.0
	tamey3(1)=1.0	
	tamey3(2)=25.0
	tamey3(3)=121.0
	
	call igdg_board(1,3,640,480,'graph$' )
	call igdg_raph(tamex,tamey,tamey2,tamey3,3,3)
	
        stop
	end
