c----------------------------------------------------------------------
c igdfx inquire transformation
c                                /  
      subroutine igdfx_inqtrf( ktfno, kvp, kwn, fvxm, fvxx, fvym, fvyx,
     $                                          fwxm, fwxx, fwym, fwyx )
c                                      /    /    //    //    //    //
c
c   <arguments>
c     ktfno      : transformation number
c     fv[xy][mx] : viewport 
c     fw[xy][mx] : window
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_inqtrf] image was not selected'
         go to 999
      end if  
      if( ktfno .lt. 1 .or. ktfno .gt. lgxtfx ) then
         write(*,*) '[igdfx_inqtrf] ktfno is invalid : ', ktfno
         go to 999
      end if  
      if( lgxtft(1,ktfno,lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_inqtrf] transform was not defined : ', ktfno
         go to 999
      end if
c....
      kvp = lgxtft(1,ktfno,lgxgic)
      kwn = lgxtft(2,ktfno,lgxgic)
c....
      fvxm = sgxvpt(1,kvp,lgxgic)
      fvxx = sgxvpt(3,kvp,lgxgic)
      fvym = sgxvpt(2,kvp,lgxgic)
      fvyx = sgxvpt(4,kvp,lgxgic)
c..
      fwxm = sgxwnt(1,kwn,lgxgic)
      fwxx = sgxwnt(3,kwn,lgxgic)
      fwym = sgxwnt(2,kwn,lgxgic)
      fwyx = sgxwnt(4,kwn,lgxgic)
c....
  999 continue
      return
      end
