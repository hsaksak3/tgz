#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gdfontt.h"
#include "gdfonts.h"
#include "gdfontmb.h"
#include "gdfontl.h"
#include "gdfontg.h"

#ifdef LINUX
#define igdg_gaugeoff_ igdg_gaugeoff__
#define igdg_gaugeon_ igdg_gaugeon__
#define igdg_board_ igdg_board__
#define igdg_option_ igdg_option__
#define igdg_raph_ igdg_raph__
#endif

#ifdef HP
#define igdg_gaugeoff_ igdg_gaugeoff
#define igdg_gaugeon_ igdg_gaugeon
#define igdg_board_ igdg_board
#define igdg_option_ igdg_option
#define igdg_raph_ igdg_raph
#endif

#ifdef UPCASE
#define igdg_gaugeoff_ IGDG_GAUGEOFF
#define igdg_gaugeon_ IGDG_GAUGEON
#define igdg_board_ IGDG_BOARD
#define igdg_option_ IGDG_OPTION
#define igdg_raph_ IGDG_RAPH
#endif

/* prototype declaration added by Sakagami,H. 21/09/08 */
void igdg_xlog_(float, float, int, int);
void igdg_ylog_(float, float, int, int);
void jgdg_tate_(float, float, float, int);
void jgdg_yoko_(float, float, float, int);
void jgdg_xset_(int, int);
void jgdg_yset_(int, int);
void suu_moji(double, char*, int);

gdImagePtr glob_im;
int glob_ox, glob_oy,glob_ix, glob_iy,glob_ldx,glob_ldy;
int glob_glay,glob_sentai,glob_lengx,glob_lengy;
int glob_color[3],glob_optchk,glob_daisyou,glob_uemigi,glob_masu;
int glob_bodchk,glob_siku,glob_tnsn;
int glob_xcalesz,glob_ycalesz;
int glob_gagechk;
int gifbs;
float glob_gminx,glob_gmaxx,glob_gminy,glob_gmaxy;
float glob_spby1x,glob_spby1y,glob_mchkx,glob_mchky;
int white,black,red,green,blue,unred,ungreen,unblue;
double gif_num;
char xname[64],yname[64],gra_name[64],gra_name2[64];
FILE *out;
FILE *in;
/**********倍率任意設定**********************/
void igdg_gaugeoff_(tiix,oox,tiiy,ooy)
float *tiix,*oox,*tiiy,*ooy;
{
glob_gagechk=1;
glob_gminx=*tiix;
glob_gmaxx=*oox;
glob_gminy=*tiiy;
glob_gmaxy=*ooy;
}

void igdg_gaugeon_()
{
glob_gagechk=0;
}
/**********ボード設定******************************/
void igdg_board_(haikei,tensen,xhava,ytakasa,name)
int *haikei,*xhava,*ytakasa,*tensen;
char *name;
{
int ii=0,iii=0;

glob_bodchk = 1;
glob_siku = *haikei;
glob_tnsn = *tensen;
glob_ix = *xhava;
glob_ox = (*xhava)+150;
glob_iy = *ytakasa;
glob_oy = (*ytakasa)+150;
glob_ldx = 100;
glob_ldy = (*ytakasa)+50;
gif_num=1;
while((*(name+ii)!='$')||(*(name+ii)=='$'&&*(name+ii+1)=='$'))
{
	if(*(name+ii)!='$'){
	gra_name[iii]=*(name+ii);
	}
	else{gra_name[iii]=*(name+ii);
	ii++;}
ii++;
iii++;
}
gra_name[iii]='\0';
gifbs=0;
if(gra_name[iii-4]=='.'&&gra_name[iii-3]=='g'&&gra_name[iii-2]=='i'&&gra_name[iii-1]=='f')gra_name[iii-4]='\0';
else if(gra_name[iii-4]=='.'&&gra_name[iii-3]=='G'&&gra_name[iii-2]=='I'&&gra_name[iii-1]=='F'){
gra_name[iii-4]='\0';
gifbs=1;
}

strcpy(gra_name2,gra_name);
}
/**************************************************/

/**********オプション設定                          ******************/

void igdg_option_(sentai,memori,color1,color2,color3,mojx,mojy)
int *sentai,*memori,*color1,*color2,*color3;
char *mojx,*mojy;
{
int ii=0,iii=0,jj=0,jjj=0,amari;

glob_sentai=*sentai;                  /* 線形対数*/

glob_daisyou=(*memori)/100;   /* 目盛大小*/ 
amari=(*memori)%100;
glob_uemigi=amari/10;         /* 上右    */
glob_masu=amari%10;           /* マス目  */

glob_color[0] =*color1;               /* 色設定  */
glob_color[1] =*color2; 
glob_color[2] =*color3;
glob_optchk=1;
while((*(mojx+ii)!='$')||(*(mojx+ii)=='$'&&*(mojx+ii+1)=='$'))
{
	if(*(mojx+ii)!='$'){
	xname[iii]=*(mojx+ii);
	}
	else{xname[iii]=*(mojx+ii);
	ii++;}
ii++;
iii++;
}
xname[iii]='\0';
glob_lengx=iii;
while((*(mojy+jj)!='$')||(*(mojy+jj)=='$'&&*(mojy+jj+1)=='$'))
{
	if(*(mojy+jj)!='$'){
	yname[jjj]=*(mojy+jj);
	}
	else{yname[jjj]=*(mojy+jj);
	jj++;}
jj++;
jjj++;
}
yname[jjj]='\0';
glob_lengy=jjj;
}

/***********  メイン関数                              ***************/
void igdg_raph_(xx,yy1,yy2,yy3,ykaz,zenbu)
float *xx,*yy1,*yy2,*yy3;
int *zenbu,*ykaz;
{
float xmax,ymax,xmin,ymin,sax,say;
int setox,setoy,logcheck,setlogx,setlogy,stlinex[3],stliney[3];
float ketax,ketay,ketaxmax,ketaxmin,ketaymax,ketaymin;
int i,ilogx,ilogy,iloxmax,iloxmin,iloymax,iloymin;
int ktxcontrol=2,ktycontrol=2,lo_ycale,lo_xcale;
double logx,logy,loxmax,loxmin,loymax,loymin;
char numb[3];

if(glob_optchk!=1){
glob_color[0]=3;
glob_color[1]=4;
glob_color[2]=5;
}


/***********設定初期化**********************/
	xmax=*xx;
	xmin=*xx;
	ymax=*yy1;	
	ymin=*yy1;
/***********最大最小調査******************/
for(i=0;i<(*zenbu);i++)
	{
	if(xmax<*xx)xmax=*xx;
	if(xmin>*xx)xmin=*xx;
		xx++;

	}

	for(i=0;i<*zenbu;i++)
		{
		if(ymax<*yy1)ymax=*yy1;
		if(ymin>*yy1)ymin=*yy1;
			if(*ykaz>1){
		if(ymax<*yy2)ymax=*yy2;
		if(ymin>*yy2)ymin=*yy2;
		yy2++;
			}
			if(*ykaz>2){
		if(ymax<*yy3)ymax=*yy3;
		if(ymin>*yy3)ymin=*yy3;
		yy3++;
			}
		
		yy1++;
		
		}
	/**********元に戻す**********/
		for(i=0;i<*zenbu;i++)
		{

			if(*ykaz>1){
		yy2--;
			}
			if(*ykaz>2){
		yy3--;
			}
		xx--;
		yy1--;
		}
/***********任意設定する?*****************/
if(glob_gagechk==1){
xmax=glob_gmaxx;
xmin=glob_gminx;
ymax=glob_gmaxy;
ymin=glob_gminy;
}
/********************************************/
	if(glob_sentai==2&&ymin<=0) {
	printf("Error\n");
	exit(0);
	}
	if(glob_sentai==3&&xmin<=0) {
	printf("Error\n");
	exit(0);
	}
	if(glob_sentai==4&&(xmin<=0||ymin<=0)) {
	printf("Error\n");
	exit(0);
	}
	

/***********切の良い桁調査****************/
	sax=xmax-xmin;
	say=ymax-ymin;
	loxmax=ceil(log10(xmax));
	loxmin=floor(log10(xmin));
	loymax=ceil(log10(ymax));
	loymin=floor(log10(ymin));
	logx=log10(sax);
	logy=log10(say);

	iloxmax=loxmax;
	iloxmin=loxmin;
	iloymax=loymax;
	iloymin=loymin;
	ilogx=logx;
	ilogy=logy;
	

/******printf("mami==%d,%d\n",ilogx,ilogy);*******/
	ketax=pow(10.0,ilogx);
	ketay=pow(10.0,ilogy);
	ketaxmax=pow(10.0,iloxmax);
	ketaxmin=pow(10.0,iloxmin);
	ketaymax=pow(10.0,iloymax);
	ketaymin=pow(10.0,iloymin);
/*	printf("%f,%f,%f,%f\n",ketaxmax,ketaxmin,ketaymax,ketaymin);*/
/*********************************************/

/******           区切り決定   ***************/
	while(sax/ketax<3){
		if(ktxcontrol%3 != 0){
			ketax=ketax/2;
			ktxcontrol++;
		}
		else{
			ketax=ketax*2/5;
			ktxcontrol++;
		}
	lo_xcale=ktxcontrol/3;
	lo_xcale=ilogx-lo_xcale;
	}
	if(lo_xcale<0){
	glob_xcalesz=lo_xcale*(-1);
	}
	
	while(say/ketay<3){
		if(ktycontrol%3 != 0){
			ketay=ketay/2;
			ktycontrol++;
		}
		else{
			ketay=ketay*2/5;
			ktycontrol++;
		}
	lo_ycale=ktycontrol/3;
	lo_ycale=ilogy-lo_ycale;
	}
	if(lo_ycale<0){
	glob_ycalesz=lo_ycale*(-1);
	}

/****** GIF FILE  基本設定           *********/
if( glob_bodchk == 1)glob_im = gdImageCreate(glob_ox,glob_oy);
if( glob_bodchk != 1)glob_im = gdImageCreate(790,630);
if(glob_siku==1)
	{white = gdImageColorAllocate(glob_im,0,0,0);}
else   {white  =gdImageColorAllocate(glob_im,255,255,255);}

glob_glay   =gdImageColorAllocate(glob_im,200,200,200);

if(glob_siku==1)
	{black  =gdImageColorAllocate(glob_im,255,255,255);}
else   {black  =gdImageColorAllocate(glob_im,0,0,0);}

red    =gdImageColorAllocate(glob_im,255,0,0);
green  =gdImageColorAllocate(glob_im,0,255,0);
blue   =gdImageColorAllocate(glob_im,0,0,255);
unred  =gdImageColorAllocate(glob_im,0,255,255);
ungreen=gdImageColorAllocate(glob_im,255,0,255);
unblue =gdImageColorAllocate(glob_im,255,255,0);

if( glob_bodchk != 1)
	{
	glob_ox=790;/*全幅*/
	glob_oy=630;/*全高*/
	glob_ix=640;  /*画面横*/
	glob_iy=480;/*画面縦*/
	glob_ldx=100;/*左下x*/
	glob_ldy=530;/*左下y*/
	}
gdImageString(glob_im,gdFontGiant,(glob_ix+150)/2-(glob_lengx/2*10),glob_oy-50,xname,black);
gdImageStringUp(glob_im,gdFontGiant,20,(glob_iy+150)/2+(glob_lengy/2*10),yname,black);

 /***********   点 打ち込み **********************************/
for(i=0;i<3;i++){
stlinex[i]=0;
 stliney[i]=0;
}
 
	for(i=0;i<*zenbu;i++){
		switch(glob_sentai){

		case(2):/* 線ーLOG */	
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((log10(*yy1)-iloymin)/(iloymax-iloymin));
			break;
		case(3):/* LOGー線  */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((*yy1-ymin)/(ymax-ymin));
			break;
		case(4):/* LOGーLOG */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((log10(*yy1)-iloymin)/(iloymax-iloymin));
			break;
		default:/* 線ー線 */
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((*yy1-ymin)/(ymax-ymin));
			break;	
		}
		if(glob_tnsn!=2)
		{
		gdImageArc(glob_im,setox,setoy,15,15,0,360,glob_color[0]);
		gdImageFillToBorder(glob_im,setox,setoy,glob_color[0],glob_color[0]);
		}
		if(glob_tnsn!=1&&stlinex[0]!=0)
		{
		gdImageLine(glob_im,stlinex[0],stliney[0],setox,setoy,glob_color[0]);
		}	
		stlinex[0]=setox;
		stliney[0]=setoy;
yy1++;

/*************/
if(*ykaz>1)
{
		switch(glob_sentai){

		case(2):/* 線ーLOG */	
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((log10(*yy2)-iloymin)/(iloymax-iloymin));
			break;
		case(3):/* LOGー線  */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((*yy2-ymin)/(ymax-ymin));
			break;
		case(4):/* LOGーLOG */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((log10(*yy2)-iloymin)/(iloymax-iloymin));
			break;
		default:/* 線ー線 */
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((*yy2-ymin)/(ymax-ymin));
			break;	
		}

		if(glob_tnsn!=2)
		{
		gdImageArc(glob_im,setox,setoy,15,15,0,360,glob_color[1]);
		gdImageFillToBorder(glob_im,setox,setoy,glob_color[1],glob_color[1]);
		}
		if(glob_tnsn!=1&&stlinex[1]!=0)
		{
		gdImageLine(glob_im,stlinex[1],stliney[1],setox,setoy,glob_color[1]);
		}	
		stlinex[1]=setox;
		stliney[1]=setoy;

*yy2++;
}
/**********/
if(*ykaz>2)
{
		switch(glob_sentai){

		case(2):/* 線ーLOG */	
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((log10(*yy3)-iloymin)/(iloymax-iloymin));
			break;
		case(3):/* LOGー線  */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((*yy3-ymin)/(ymax-ymin));
			break;
		case(4):/* LOGーLOG */
			setox=glob_ldx+glob_ix*((log10(*xx)-iloxmin)/(iloxmax-iloxmin));
			setoy=glob_ldy-glob_iy*((log10(*yy3)-iloymin)/(iloymax-iloymin));
			break;
		default:/* 線ー線 */
			setox=glob_ldx+glob_ix*((*xx-xmin)/(xmax-xmin));
			setoy=glob_ldy-glob_iy*((*yy3-ymin)/(ymax-ymin));
			break;	
		}

		if(glob_tnsn!=2)
		{
		gdImageArc(glob_im,setox,setoy,15,15,0,360,glob_color[2]);
		gdImageFillToBorder(glob_im,setox,setoy,glob_color[2],glob_color[2]);
		}
		if(glob_tnsn!=1&&stlinex[2]!=0)
		{
		gdImageLine(glob_im,stlinex[2],stliney[2],setox,setoy,glob_color[2]);
		}	
		stlinex[2]=setox;
		stliney[2]=setoy;

*yy3++;
}
*xx++;
}
/***********************/
gdImageFilledRectangle(glob_im,0,0,glob_ldx,glob_oy,white);
gdImageFilledRectangle(glob_im,100,0,glob_ix+100,50,white);
gdImageFilledRectangle(glob_im,glob_ix+100,0,glob_ox,glob_oy,white);
gdImageFilledRectangle(glob_im,100,glob_ldy,glob_ix+100,glob_oy,white);
/***********************/
/*******     目盛設定   **************************/
switch(glob_sentai){

	case 2:  /* 線ーLOG */
		igdg_ylog_(ketaymin,ketaymax,glob_glay,black);
		jgdg_yoko_(xmin,xmax,ketax,black);
	if(glob_daisyou==1) jgdg_xset_(5,black);
		break;
	case 3: /* LOGー線  */
		igdg_xlog_(ketaxmin,ketaxmax,glob_glay,black);
		jgdg_tate_(ymin,ymax,ketay,black);
	if(glob_daisyou==1)jgdg_yset_(5,black);
		break;
	case 4: /* LOGーLOG */
		igdg_xlog_(ketaxmin,ketaxmax,glob_glay,black);
		igdg_ylog_(ketaymin,ketaymax,glob_glay,black);
		break;
	default: /* 線ー線 */
 		jgdg_yoko_(xmin,xmax,ketax,black);
 		jgdg_tate_(ymin,ymax,ketay,black);
 	if(glob_daisyou==1)
 		{
 		jgdg_xset_(5,black);
 		jgdg_yset_(5,black);
 		}
 		break;

 }
 gdImageRectangle(glob_im,100,50,glob_ix+100,glob_iy+50,black);
/**************/
if(glob_bodchk==1){
	/*suu_moji(gif_num,numb,0);
	strcat(gra_name,numb);
	gif_num++;*/
	if(gifbs==1){
		strcat(gra_name,".GIF");
		gifbs=0;
	}
	else{strcat(gra_name,".gif");}
	
	out=fopen(gra_name,"wb");
	strcpy(gra_name,gra_name2);
}
else{       out=fopen("gdg.gif","wb");}
gdImageGif(glob_im,out);
fclose(out);
gdImageDestroy(glob_im);
}

/***********線形横目盛大                               ****************/
 void jgdg_yoko_(left,right,tabal,col)
 float left,right,tabal;
 int col;
 {
char motu[64];
int ii,line,kai,nagasa;
float amari;
double irehen;

kai = (left)/(tabal);
if(left<0)kai=kai-1.0;
amari=(left)-((tabal)*kai);
irehen=(tabal)*kai;

if(irehen==left)
{
suu_moji(left,motu,1);
nagasa=strlen(motu);
gdImageString(glob_im,gdFontGiant,glob_ldx-(nagasa/2*10),glob_ldy+10,motu,col);
}
			/*
			suu_moji(right,motu);
			nagasa=strlen(motu);
			gdImageString(glob_im,gdFontGiant,glob_ldx+glob_ix-(nagasa/2*10),glob_ldy+10,motu,col);
			*/
glob_spby1x=glob_ix/(((right)-(left))/(tabal));

for(ii=0;ii*glob_spby1x<=glob_ix;ii++)
 	{  irehen=irehen+(tabal);
  suu_moji(irehen,motu,1);
	    nagasa=strlen(motu);
 	line = glob_ldx + glob_spby1x*((tabal)-amari)/(tabal) + glob_spby1x * ii;
 
 	glob_mchkx=glob_spby1x*((tabal)-amari)/(tabal);
 	
 	if(line<=glob_ox-50)
 	{
 	if(glob_masu==1)gdImageLine(glob_im,line,50,line,50+glob_iy,glob_glay);
	if(glob_uemigi==1)gdImageLine(glob_im,line,50,line,60,col);

 	gdImageLine(glob_im,line,glob_ldy,line,glob_ldy-10,col);
 	gdImageString(glob_im,gdFontGiant,line-(nagasa/2*10),glob_ldy+10,motu,col);
 	}
 
 }
 }
 
 /***************      線形縦目盛大               ***************************/
 void jgdg_tate_(down,up,tabal,col)
 float down,up,tabal;
 int col;
 { 
 char motu[64];
 int ii,line,kai,nagasa;
 float amari;
 double irehen;
 kai = (down)/(tabal);
  if(down<0)kai=kai-1.0;
 amari=(down)-((tabal)*kai);
 irehen=tabal*kai;
if(irehen==down){
  suu_moji(down,motu,2);
 nagasa=strlen(motu);
 gdImageString(glob_im,gdFontGiant,glob_ldx-10-nagasa*10,glob_ldy-10,motu,col);
 }
 	/*
 	suu_moji(up,motu);
	 nagasa=strlen(motu);
 	gdImageString(glob_im,gdFontGiant,glob_ldx-10-nagasa*10,glob_ldy-glob_iy-10,motu,col);
	*/
 glob_spby1y=glob_iy/(((up)-(down))/(tabal));/*1目当間*/
 
 for(ii=0;ii*glob_spby1y<=600;ii++)
 {
 irehen=irehen+(tabal);
  suu_moji(irehen,motu,2);
 nagasa=strlen(motu);
 line = glob_ldy - glob_spby1y*((tabal)-amari)/(tabal) - glob_spby1y * ii;
 
 	glob_mchky=glob_spby1y*((tabal)-amari)/(tabal);
 	if(line>=50)
 	{
 	if(glob_masu==1)gdImageLine(glob_im,100,line,100+glob_ix,line,glob_glay);
 	if(glob_uemigi==1)gdImageLine(glob_im,glob_ox-50,line,glob_ox-60,line,col);

 	gdImageLine(glob_im,glob_ldx,line,glob_ldx+10,line,col);
 	gdImageString(glob_im,gdFontGiant,glob_ldx-10-nagasa*10,line-10,motu,col);}
 
 }
 }
 /************              線形横目盛小             ********************/
 void jgdg_xset_(kosuu,col)
 int kosuu,col;
 {
 int ii,line;
 float min_spby1x;
 ii=1;/* 初期化 */
 min_spby1x=glob_spby1x/(kosuu);
 
 while(glob_mchkx-min_spby1x*ii > 0)
 { 
  line=glob_ldx+glob_mchkx-min_spby1x * ii;
  if(glob_uemigi==1)gdImageLine(glob_im,line,50,line,55,col);
  gdImageLine(glob_im,line,glob_ldy,line,glob_ldy-5,col);
  ii=ii+1;
  }
  ii=0;/* また初期化 */
  
  while(glob_mchkx+min_spby1x *ii <= glob_ix)
  {
  if(ii%(kosuu)!=0)
  {
  line = glob_ldx + glob_mchkx + min_spby1x * ii;
  if(glob_uemigi==1)gdImageLine(glob_im,line,50,line,55,col);
  gdImageLine(glob_im,line,glob_ldy,line,glob_ldy-5,col);
  }
  
  ii=ii+1;
  }
  }
  
 /**********     線形縦目盛小                       *********************/ 
 void jgdg_yset_(kosuu,col)
 int kosuu,col;
 {
 int ii,line;
 float min_spby1y;
 ii=1;/* 初期化 */
 min_spby1y=glob_spby1y/(kosuu);
 
 while(glob_mchky-min_spby1y*ii > 0)
 { 
  line=glob_ldy-glob_mchky+min_spby1y * ii;
  if(glob_uemigi==1)gdImageLine(glob_im,glob_ox-50,line,glob_ox-55,line,col);
  gdImageLine(glob_im,glob_ldx,line,glob_ldx+5,line,col);
  ii=ii+1;
  }
  ii=0;/* 再初期化 */
  
  while(glob_iy-glob_mchky-min_spby1y *ii >= 0)
  {/*printf("%d,%lf\n",ii,glob_mchky-min_spby1y *ii);*/
  if(ii%(kosuu)!=0)
  {
  line = glob_ldy - glob_mchky - min_spby1y * ii;
   if(glob_uemigi==1)gdImageLine(glob_im,glob_ox-50,line,glob_ox-55,line,col);
  gdImageLine(glob_im,glob_ldx,line,glob_ldx+5,line,col);
  }
  
  ii=ii+1;
  }  
  }
  
 /* main(){
  double kaz=0.00043;
  char imo[80];
  int tyou;
  suu_moji(kaz,imo,tyou);
  }*/
/***********     数字文字列変換                      *******************/  
void suu_moji(suu,moji,xydotti)
char moji[80];
int xydotti;
double suu;

{

if(xydotti==1){
	if(glob_xcalesz==1)sprintf(moji,"%5.1f",suu);
	else if(glob_xcalesz==2)sprintf(moji,"%5.2f",suu);
	else if(glob_xcalesz==3)sprintf(moji,"%5.3f",suu);
	else if(glob_xcalesz==4)sprintf(moji,"%5.4f",suu);
	else               sprintf(moji,"%g",suu);
	}
else if(xydotti==2){
	if(glob_ycalesz==1)sprintf(moji,"%5.1f",suu);
	else if(glob_ycalesz==2)sprintf(moji,"%5.2f",suu);
	else if(glob_ycalesz==3)sprintf(moji,"%5.3f",suu);
	else if(glob_ycalesz==4)sprintf(moji,"%5.4f",suu);
	else               sprintf(moji,"%g",suu);
	}
else               sprintf(moji,"%g",suu);
}
/**********対数横目盛                                *******************/


void igdg_xlog_(min,max,col,col2)
float min,max;
int col,col2;
{ 
char motu[64];
double xx,hitotu,wa,mini,minketa,maxketa;
float saketa;
int line,i,j,nagasa;
minketa=log10(min);
maxketa=log10(max);
saketa=maxketa-minketa;
hitotu=glob_ix/saketa;
mini=min;
for(i=0;i<saketa;i++){
suu_moji(mini,motu,1) ;  
	nagasa=strlen(motu);
	wa=0;
	for(j=0;j<9;j++){
		wa=wa+mini;
		line=glob_ldx+hitotu*(log10(wa)-minketa);
		if(j!=0){
		gdImageLine(glob_im,line,50,line,50+glob_iy,col);
		}
		else {
		gdImageLine(glob_im,line,50,line,50+glob_iy,col2);
gdImageString(glob_im,gdFontGiant,line-(nagasa/2*10),glob_ldy+10,motu,col2);
		}
	}
	mini=mini*10;
}
suu_moji(mini,motu,1);
nagasa=strlen(motu);
gdImageString(glob_im,gdFontGiant,glob_ox-50-(nagasa/2*10),glob_ldy+10,motu,col2);

}

/***************   対数縦目盛                       ************************/
void igdg_ylog_(min,max,col,col2)
float min,max;
int col,col2;
{ 
char motu[64];
double xx,hitotu,wa,mini,minketa,maxketa;
float saketa;
int line,i,j,nagasa;
minketa=log10(min);
maxketa=log10(max);
saketa=maxketa-minketa;
hitotu=glob_iy/saketa;
mini=min;
for(i=0;i<saketa;i++){
suu_moji(mini,motu,2);
 	nagasa=strlen(motu);
	wa=0;
		for(j=0;j<9;j++){
		wa=wa+mini;
		line=glob_ldy-hitotu*(log10(wa)-minketa);
			if(j!=0){gdImageLine(glob_im,100,line,100+glob_ix,line,col);}
			else    {gdImageLine(glob_im,100,line,100+glob_ix,line,col2);
gdImageString(glob_im,gdFontGiant,glob_ldx-nagasa*10,line-10,motu,col2);
			}
		}
	mini=mini*10;
}
suu_moji(mini,motu,2);
nagasa=strlen(motu);
gdImageString(glob_im,gdFontGiant,glob_ldx-nagasa*10,40,motu,col2);
}



 
 
 
  
  
  
