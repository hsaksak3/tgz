c----------------------------------------------------------------------
c igdfx draw line
c                                /    /    /    /
      subroutine igdfx_drwlin ( fxs, fys, fxe, fye )
c
c   <arguments>
c     f[xy][se]  : line coordinate
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_drwlin] image was not selected'
         go to 999
      end if
      if( lgxtfc(lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_drwlin] transform was not selected'
	 go to 999
      end if
c....
      call igdfx_wc2sc ( fxs, fys, ixs, iys, icnds )
      call igdfx_wc2sc ( fxe, fye, ixe, iye, icnde )
c..
      if( icnds+icnde .eq. 0 ) call igdf_line ( lgximt(lgxgic), 
     $              ixs ,iys, ixe, iye, lgxclt(lgxlcl(lgxgic),lgxgic) )
c....
  999 continue
      return
      end
