      	integer*8 im, im1, im2
      	integer*8 igdf_ic, igdf_cfgif, igdf_cfgd,igdf_cfxbm
	
	im = igdf_ic(200,200)
	iwhite = igdf_cal(im,250,250,250)
	ired   = igdf_cal(im,255,0,0)
	iblack = igdf_cal(im,0,0,0)
        do i = 1, 40
           call igdf_bgr(im)
	   call igdf_arc(im,50+i*2,100+i,50+i/2,50-i/2,0,360,iblack)
	   call igdf_fill(im,50+i*2,100+i,ired)
	   call igdf_ani(im,'anim1$')
	   call igdf_ani(im,'anim2$')
        end do
	call igdf_idy(im)

	im = igdf_ic(200,200)
	iback = igdf_cal(im,250,128,128)
	icol1 = igdf_cal(im,128,250,250)
	icol2 = igdf_cal(im,0,128,128)
	do i = 1, 200
	   idum = igdf_cal(im,i,i,i)
	end do
	call igdf_anigc (im,'anim2$')
	call igdf_idy(im)

        call igdf_anist( 'anim3$', 3, 2, 0 )
        do i = 1, 40
	   im = igdf_ic(200,200)
	   iwhite = igdf_cal(im,250,250,250)
	   iblue  = igdf_cal(im,0,0,255)
	   call igdf_arc(im,100,100,200-i*2,10+i*4,0,360,iblue)
	   call igdf_fill(im,100,100,iblue)
	   call igdf_ani(im,'anim3$')
	   call igdf_idy(im)
        end do

	im1 = igdf_ic(200,200)
	iblac1 = igdf_cal(im1,0,0,0)
	iwhit1 = igdf_cal(im1,250,250,250)
	ired1  = igdf_cal(im1,255,0,0)
	call igdf_arc(im1,50,100,100,100,0,360,iwhit1)
	call igdf_fill(im1,50,100,ired1)
	im2 = igdf_ic(200,200)
	iblac2 = igdf_cal(im2,0,0,0)
	iblue2 = igdf_cal(im2,0,0,250)
	igree2 = igdf_cal(im2,0,255,0)
	call igdf_arc(im2,150,100,100,100,0,360,iblue2)
	call igdf_fill(im2,150,100,igree2)
        call igdf_anist( 'anim4$', 1, 100, 1 )
        do i = 1, 20
	   call igdf_ani(im1,'anim4$')
	   call igdf_ani(im2,'anim4$')
        end do
	call igdf_idy(im1)
	call igdf_idy(im2)

        stop
	end
