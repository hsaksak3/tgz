c--------------------------------------------------------------------
      call igdfx_init
c...
      call igdfx_opngif ( 1, 640, 640 )
c...
      call igdfx_defvwp ( 1, 0.0, 0.49, 0.51, 1.0 )
      call igdfx_defvwp ( 2, 0.0, 0.49, 0.0, 0.49 )
      call igdfx_defvwp ( 3, 0.51, 1.0, 0.0, 1.0 )
      call igdfx_defwin ( 1, -5.0, 5.0, -5.0, 5.0 )
      call igdfx_defwin ( 2, -10.0, 10.0, -10.0, 10.0 )
      call igdfx_defwin ( 3, -5.0, 5.0, -5.0, 5.0 )
c..
      do it = 1, 3
         call igdfx_deftrf ( it, it, it )
      end do
c...
      do it = 1, 3
c..
         call igdfx_seltrf ( it )
c..
         call igdfx_sellcl ( it+3 )
         call igdfx_drwlin ( -4.9, -4.9, 4.9, -4.9 )
         call igdfx_drwlin ( 4.9, -4.9, 4.9, 4.9 )
         call igdfx_drwlin ( 4.9, 4.9, -4.9, 4.9 )
         call igdfx_drwlin ( -4.9, 4.9, -4.9, -4.9 )
         call igdfx_drwlin ( -4.9, -4.9, 4.9, 4.9 )
         call igdfx_drwlin ( 4.9, -4.9, -4.9, 4.9 )
c.
         call igdfx_sellcl ( 7-it )
         call igdfx_selfcl ( it+6 )
	 ifil = (it/2) * 10 + mod(it,2)
         call igdfx_drwrec ( -2.0, -1.0, 2.0, 1.0, ifil )
      end do
c..
      do it = 1, 3
         call igdfx_drwvwp ( it )
      end do
      call igdfx_seltcl ( 2 )
      call igdfx_drwtxt ( 320, 320, 4, 'gdfx.gif$ ' )
      call igdfx_seltcl ( 3 )
      call igdfx_drwtxt ( 320, 350, 2, 'sample text$ ' )
c...
      call igdfx_clsgif ( 1, 'gdfx.gif$ ', 2 )
c...
      call igdfx_term
c....
      stop
      end
