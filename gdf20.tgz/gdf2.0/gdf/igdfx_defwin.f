c----------------------------------------------------------------------
c igdfx define window
c                                 /      /     /     /     /
      subroutine igdfx_defwin ( kwnno, fwxm, fwxx, fwym, fwyx )
c
c   <arguments>
c     kwnno      : window number ( 1 =< kwnno =< lgxwnx )
c     fw[xy][mx] : window min & mac (WC)
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_defwin] image was not selected'
	 go to 999
      end if
      if( kwnno .lt. 1 .or. kwnno .gt. lgxwnx ) then
         write(*,*) '[igdfx_defwin] kwnno is invalid : ', kwnno
	 go to 999
      end if
      if( lgxwnt(kwnno,lgxgic) .ne. 0 ) then
        write(*,*) '[igdfx_defwin] window was already defined : ', kwnno
	go to 999
      end if
c....
      lgxwnt(kwnno,lgxgic) = kwnno + lgxgic
c..
      sgxwnt(1,kwnno,lgxgic) = fwxm
      sgxwnt(2,kwnno,lgxgic) = fwym
      sgxwnt(3,kwnno,lgxgic) = fwxx
      sgxwnt(4,kwnno,lgxgic) = fwyx
c....
  999 continue
      return
      end
