c----------------------------------------------------------------------
c igdfx select text color
c                                 /
      subroutine igdfx_seltcl ( kcol )
c
c   <arguments>
c     kcol  : color number ( 1 =< kcol =< 255 )
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( NIFS ) 09/05/12
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_seltcl] image was not selected'
         go to 999
      end if
      if( kcol .lt. 1 .or. kcol .gt. 255 ) then
         write(*,*) '[igdfx_seltcl] kcol is invalid : ', kcol
	 go to 999
      end if
      if( lgxclt(kcol,lgxgic) .eq. -1 ) then
         write(*,*) '[igdfx_seltcl] color was not defined : ', kcol
	 go to 999
      end if
c....
      lgxtcl(lgxgic) = kcol
c....
  999 continue
      return
      end
