#include <stdlib.h>
#include <string.h>
#include "gd.h"
#include "gdfontt.h"
#include "gdfonts.h"
#include "gdfontmb.h"
#include "gdfontl.h"
#include "gdfontg.h"
gdImagePtr im;
FILE *out;
FILE *in;
int gifbs;
int ngif_on;
int agif_on;
int ic_chk;

/* static added by Sakagami,H. 05/11/25 */
static struct hozon{
	char file_name[64];
	int hgifbs;
int kiokunum;
int kiokuketa;
int lord;
}hoz[10];

/* static added by Sakagami,H. 05/11/25 */
static struct anihozon{
		char file_name[64];
	int agifbs;
	int kiokutien;
	int kiokukai;
	int lord;
	int ani_chk;
	int glc_table;
}aniho[10];

#ifdef LINUX
#define igdf_ic_ igdf_ic__
#define igdf_cfgif_ igdf_cfgif__
#define igdf_cfgd_ igdf_cfgd__
#define igdf_cfxbm_ igdf_cfxbm__
#define igdf_ccl_ igdf_ccl__
#define igdf_cex_ igdf_cex__
#define igdf_cal_ igdf_cal__
#define igdf_cdel_ igdf_cdel__
#define igdf_spx_ igdf_spx__
#define igdf_igif_ igdf_igif__
#define igdf_igd_ igdf_igd__
#define igdf_idy_ igdf_idy__
#define igdf_line_ igdf_line__
#define igdf_dline_ igdf_dline__
#define igdf_rect_ igdf_rect__
#define igdf_arc_ igdf_arc__
#define igdf_bgr_ igdf_bgr__
#define igdf_frec_ igdf_frec__
#define igdf_ftb_ igdf_ftb__
#define igdf_fill_ igdf_fill__
#define igdf_pol_ igdf_pol__
#define igdf_fpol_ igdf_fpol__
#define igdf_gpix_ igdf_gpix__
#define igdf_blue_ igdf_blue__
#define igdf_red_ igdf_red__
#define igdf_green_ igdf_green__
#define igdf_safe_ igdf_safe__
#define igdf_sx_ igdf_sx__
#define igdf_sy_ igdf_sy__
#define igdf_tran_ igdf_tran__
#define igdf_intl_ igdf_intl__
#define igdf_ctotal_ igdf_ctotal__
#define igdf_icred_ igdf_icred__
#define igdf_icblue_ igdf_icblue__
#define igdf_icgreen_ igdf_icgreen__
#define igdf_gil_ igdf_gil__
#define igdf_gtran_ igdf_gtran__
#define igdf_char_ igdf_char__
#define igdf_chup_ igdf_chup__
#define igdf_string_ igdf_string__
#define igdf_strup_ igdf_strup__
#define igdf_copy_ igdf_copy__
#define igdf_cpr_ igdf_cpr__
#define igdf_brush_ igdf_brush__
#define igdf_tile_ igdf_tile__
#define igdf_sstyle_ igdf_sstyle__
#define igdf_ani_ igdf_ani__
#define igdf_ngif_ igdf_ngif__
#define igdf_ngst_ igdf_ngst__
#define igdf_anist_ igdf_anist__
#define igdf_anigc_ igdf_anigc__
#endif

#ifdef HP
#define igdf_ic_ igdf_ic
#define igdf_cfgif_ igdf_cfgif
#define igdf_cfgd_ igdf_cfgd
#define igdf_cfxbm_ igdf_cfxbm
#define igdf_ccl_ igdf_ccl
#define igdf_cex_ igdf_cex
#define igdf_cal_ igdf_cal
#define igdf_cdel_ igdf_cdel
#define igdf_spx_ igdf_spx
#define igdf_igif_ igdf_igif
#define igdf_igd_ igdf_igd
#define igdf_idy_ igdf_idy
#define igdf_line_ igdf_line
#define igdf_dline_ igdf_dline
#define igdf_rect_ igdf_rect
#define igdf_arc_ igdf_arc
#define igdf_bgr_ igdf_bgr
#define igdf_frec_ igdf_frec
#define igdf_ftb_ igdf_ftb
#define igdf_fill_ igdf_fill
#define igdf_pol_ igdf_pol
#define igdf_fpol_ igdf_fpol
#define igdf_gpix_ igdf_gpix
#define igdf_blue_ igdf_blue
#define igdf_red_ igdf_red
#define igdf_green_ igdf_green
#define igdf_safe_ igdf_safe
#define igdf_sx_ igdf_sx
#define igdf_sy_ igdf_sy
#define igdf_tran_ igdf_tran
#define igdf_intl_ igdf_intl
#define igdf_ctotal_ igdf_ctotal
#define igdf_icred_ igdf_icred
#define igdf_icblue_ igdf_icblue
#define igdf_icgreen_ igdf_icgreen
#define igdf_gil_ igdf_gil
#define igdf_gtran_ igdf_gtran
#define igdf_char_ igdf_char
#define igdf_chup_ igdf_chup
#define igdf_string_ igdf_string
#define igdf_strup_ igdf_strup
#define igdf_copy_ igdf_copy
#define igdf_cpr_ igdf_cpr
#define igdf_brush_ igdf_brush
#define igdf_tile_ igdf_tile
#define igdf_sstyle_ igdf_sstyle
#define igdf_ani_ igdf_ani
#define igdf_ngif_ igdf_ngif
#define igdf_ngst_ igdf_ngst
#define igdf_anist_ igdf_anist
#define igdf_anigc_ igdf_anigc
#endif

#ifdef UPCASE
#define igdf_ic_ IGDF_IC
#define igdf_cfgif_ IGDF_CFGIF
#define igdf_cfgd_ IGDF_CFGD
#define igdf_cfxbm_ IGDF_CFXBM
#define igdf_ccl_ IGDF_CCL
#define igdf_cex_ IGDF_CEX
#define igdf_cal_ IGDF_CAL
#define igdf_cdel_ IGDF_CDEL
#define igdf_spx_ IGDF_SPX
#define igdf_igif_ IGDF_IGIF
#define igdf_igd_ IGDF_IGD
#define igdf_idy_ IGDF_IDY
#define igdf_line_ IGDF_LINE
#define igdf_dline_ IGDF_DLINE
#define igdf_rect_ IGDF_RECT
#define igdf_arc_ IGDF_ARC
#define igdf_bgr_ IGDF_BGR
#define igdf_frec_ IGDF_FREC
#define igdf_ftb_ IGDF_FTB
#define igdf_fill_ IGDF_FILL
#define igdf_pol_ IGDF_POL
#define igdf_fpol_ IGDF_FPOL
#define igdf_gpix_ IGDF_GPIX
#define igdf_blue_ IGDF_BLUE
#define igdf_red_ IGDF_RED
#define igdf_green_ IGDF_GREEN
#define igdf_safe_ IGDF_SAFE
#define igdf_sx_ IGDF_SX
#define igdf_sy_ IGDF_SY
#define igdf_tran_ IGDF_TRAN
#define igdf_intl_ IGDF_INTL
#define igdf_ctotal_ IGDF_CTOTAL
#define igdf_icred_ IGDF_ICRED
#define igdf_icblue_ IGDF_ICBLUE
#define igdf_icgreen_ IGDF_ICGREEN
#define igdf_gil_ IGDF_GIL
#define igdf_gtran_ IGDF_GTRAN
#define igdf_char_ IGDF_CHAR
#define igdf_chup_ IGDF_CHUP
#define igdf_string_ IGDF_STRING
#define igdf_strup_ IGDF_STRUP
#define igdf_copy_ IGDF_COPY
#define igdf_cpr_ IGDF_CPR
#define igdf_brush_ IGDF_BRUSH
#define igdf_tile_ IGDF_TILE
#define igdf_sstyle_ IGDF_SSTYLE
#define igdf_ani_ IGDF_ANI
#define igdf_ngif_ IGDF_NGIF
#define igdf_ngst_ IGDF_NGST
#define igdf_anist_ IGDF_ANIST
#define igdf_anigc_ IGDF_ANIGC
#endif

/* prototype declaration added by Sakagami,H. 21/09/08 */
void suutan(char*, char*);
void suu_moju(int, double, char*);
void gdImageAni(gdImagePtr, FILE*, int, int, int);
void gdGColSet(gdImagePtr, FILE*);

/*************    画面作成 (横、縦、ID)   **************************/
gdImagePtr igdf_ic_(a,b)
int *a,*b;
{
gdImagePtr im;
int i;
im = gdImageCreate(*a,*b);

if(ic_chk!=100){
	ic_chk=100;
for(i=0;i<10;i++){
	if(ngif_on!=100){
		hoz[i].kiokunum=0;
		hoz[i].kiokuketa=4;
		hoz[i].lord=0;
	 strcpy(hoz[i].file_name,"gdg$");
	hoz[i].hgifbs=0;
	}
	if(agif_on!=100){
	 strcpy(aniho[i].file_name,"anime$");
	aniho[i].kiokutien=10;
	aniho[i].kiokukai=0;
	aniho[i].lord=0;
	aniho[i].agifbs=0;
	aniho[i].ani_chk =0;
	aniho[i].glc_table =0;
	}
}
}
return(im);
}
/**********  GIFを開く (ID,ファイル名)      ***********************/
gdImagePtr igdf_cfgif_(name)
char *name;
{
gdImagePtr bang;
char xname[64];
suutan(xname,name);

in = fopen(xname,"rb");
bang = gdImageCreateFromGif(in);
fclose(in);
return(bang);
}
/**********  GDを開く (ID,ファイル名)      ***********************/
gdImagePtr igdf_cfgd_(name)
char *name;
{
gdImagePtr bang;
char xname[64];
suutan(xname,name);

in = fopen(xname,"rb");
bang = gdImageCreateFromGd(in);
fclose(in);
return(bang);
}
/**********  XBMを開く (ID,ファイル名)      ***********************/
gdImagePtr igdf_cfxbm_(name)
char *name;
{
gdImagePtr bang;
char xname[64];
suutan(xname,name);
in = fopen(xname,"rb");
bang = gdImageCreateFromXbm(in);
fclose(in);
return(bang);
}
/*********** 近い色を探す(ID,赤、緑、青、パレット値) ***************/
int igdf_ccl_(bang,r,g,b)
int *r,*g,*b;
gdImagePtr *bang;
{
int cl;
cl = gdImageColorClosest(*bang,*r,*g,*b);
return(cl);
}
/********* 色存在確認(ID、赤、緑、青、パレット値) ************/
int igdf_cex_(bang,r,g,b)
int *r,*g,*b;
gdImagePtr *bang;
{
int cl;
cl = gdImageColorExact(*bang,*r,*g,*b);
return(cl);
}
/***********      色設定 (ID,赤、緑、青、色名)  **********************/
int igdf_cal_(bang,r,g,b)
int *r,*g,*b;
gdImagePtr *bang;
{
int cl;
cl = gdImageColorAllocate(*bang,*r,*g,*b);
return(cl);
}
/************ 色解放 (ID,色名)  ****************/
void igdf_cdel_(bang,cl)
int *cl;
gdImagePtr *bang;
{
gdImageColorDeallocate(*bang,*cl);
}
/*********        点 (ID,位置、色名)     ************************/
void igdf_spx_(bang,a,b,cl)
int *a,*b,*cl;
gdImagePtr *bang;
{
gdImageSetPixel(*bang,*a,*b,*cl);
}


/*********        書き込み(ID,ファイル名)   **********************/
void igdf_igif_(bang,name)
gdImagePtr *bang;
char *name;
{
char xname[64];
suutan(xname,name);
if(gifbs==2){
strcat(xname,".GIF");
gifbs=0;
}
else{
strcat(xname,".gif");
}
out=fopen(xname,"wb");
gdImageGif(*bang,out);
fclose(out);
}
/*********        書き込みGD(ID,ファイル名)   **********************/
void igdf_igd_(bang,name)
gdImagePtr *bang;
char *name;
{
char xname[64];
suutan(xname,name);
out=fopen(xname,"wb");
gdImageGd(*bang,out);
fclose(out);
}
/********       終わり  (ID)       ***********************/
void igdf_idy_(bang)
gdImagePtr *bang;
{
gdImageDestroy(*bang);
}
/******         線  (ID,始め、終り、色名)   ************************/
void igdf_line_(bang,a,b,c,d,cl)
int *a,*b,*c,*d,*cl;
gdImagePtr *bang;
{
gdImageLine(*bang,*a,*b,*c,*d,*cl);
}
 
/************ 点線  (ID,始め、終り、色名)   **********************/
void igdf_dline_(bang,a,b,c,d,cl)
int *a,*b,*c,*d,*cl;
gdImagePtr *bang;
{
gdImageDashedLine(*bang,*a,*b,*c,*d,*cl);
}
/***********  長方形   (ID,左上、右下、色名)     *********************/

void igdf_rect_(bang,ax,ay,bx,by,cl)
int *ax,*bx,*ay,*by,*cl;
gdImagePtr *bang;
{
gdImageRectangle(*bang,*ax,*ay,*bx,*by,*cl);
}
/* 円  (ID,中心、幅、高さ、始め（度)、終り（度)、色名) ******************/

void igdf_arc_(bang,ax,ay,wid,hig,stt,ende,cl)
int *ax,*ay,*cl,*hig,*wid,*stt,*ende;
gdImagePtr *bang;
{
 gdImageArc(*bang,*ax,*ay,*wid,*hig,*stt,*ende,*cl);
}

/*********    背景    (ID,横、縦、色名 )   ********************/
void igdf_bgr_(bang)
gdImagePtr *bang;
{
	int c,d;
	c = gdImageSX(*bang);
	d = gdImageSY(*bang);
gdImageFilledRectangle(*bang,0,0,c,d,0);
}

/*********    塗り潰し長方形   (ID,左上、右下、色名) ****************/
void igdf_frec_(bang,ax,ay,bx,by,cl)
int *ax,*bx,*ay,*by,*cl;
gdImagePtr *bang;
{
gdImageFilledRectangle(*bang,*ax,*ay,*bx,*by,*cl);
}
/*****        囲まれた範囲の塗り潰し  (ID,始点、柵色、色名)   ****************/
void igdf_ftb_(bang,ax,ay,bcl,cl)
int *ax,*ay,*bcl,*cl;
gdImagePtr *bang;
{
gdImageFillToBorder(*bang,*ax,*ay,*bcl,*cl);
}

/*****    指定した面の塗り潰し  (ID,始点、色名)    *****************/
void igdf_fill_(bang,ax,ay,cl)
int *ax,*ay,*cl;
gdImagePtr *bang;
{
gdImageFill(*bang,*ax,*ay,*cl);
}
/***多角形  (ID,始め位置、総点数、色名)**********/
void igdf_pol_(bang,poont,zenbu,cl)
int *zenbu,*cl;
gdPointPtr poont;
gdImagePtr *bang;
{int i;
gdImagePolygon(*bang,poont,*zenbu,*cl);
}

/***塗り潰し多角形  (ID,始め位置、総点数、色名)**********/
void igdf_fpol_(bang,poont,zenbu,cl)
int *zenbu,*cl;
gdPointPtr poont;
gdImagePtr *bang;
{int i;
gdImageFilledPolygon(*bang,poont,*zenbu,*cl);
}
/*****色取得 ( ID、取得位置、戻り値) *****************/
void igdf_gpix_(bang,ax,ay,col,aka,midori,aoo)
int *ax,*ay,*col, *aka,*midori,*aoo;
gdImagePtr *bang;
{ int c;
	c = gdImageGetPixel(*bang,*ax,*ay);
*col = c;
*aka =(*bang)->red[c];
*midori =(*bang)->green[c];
*aoo =(*bang)->blue[c];
}
/***** 青取得 ( ID、色名、戻り値) ****************/
int igdf_blue_(bang,cl)
int *cl;
gdImagePtr *bang;
{ 
int c;
c = gdImageBlue(*bang,*cl);
return(c);
}
/***** 赤取得 ( ID、色名、戻り値) ****************/
int igdf_red_(bang,cl)
int *cl;
gdImagePtr *bang;
{ 
int c;
c = gdImageRed(*bang,*cl);
return(c);
}
/***** 緑取得 ( ID、色名、戻り値)  ****************/
int igdf_green_(bang,cl)
int *cl;
gdImagePtr *bang;
{ 
int c;
c = gdImageGreen(*bang,*cl);
return(c);
}
/*******  枠内チェック(ID、X座標、Y座標,戻り値)**********/
int igdf_safe_(bang,ax,ay)
int *ax, *ay;
gdImagePtr *bang;
{ 
int c;
c = gdImageBoundsSafe(*bang,*ax,*ay);
return(c);
}
/****** 横取得(ID,戻り値)**********************/
int igdf_sx_(bang)
gdImagePtr *bang;
{ 
int c;
c = gdImageSX(*bang);
return(c);
}
/****** 縦取得(ID,戻り値)**********************/
int igdf_sy_(bang)
gdImagePtr *bang;
{ 
int c;
c = gdImageSY(*bang);
return(c);
}
/******* 透過GIF (ID,透過色)********************/
void igdf_tran_(bang,cl)
int *cl;
gdImagePtr *bang;
{
gdImageColorTransparent(*bang,*cl);
}
/******* インターレスGIF(ID)  **********/
void igdf_intl_(bang)
gdImagePtr *bang;
{
gdImageInterlace(*bang,1);
}

/*****  パレット数(ID、返り値) ************************/
int igdf_ctotal_(bang)
gdImagePtr *bang;
{
int suu;
suu = gdImageColorsTotal(*bang);
return(suu);
}

/****************************
int igdf_icred_(bang,co)
int *co;
gdImagePtr *bang;
{
int mod;
mod = gdImageColorRed(*bang,*co);
return(mod);
}
****************************
int igdf_icblue_(bang,co)
int *co, ;
gdImagePtr *bang;
{
int mod;
mod = gdImageColorBlue(*bang,*co);
return(mod);
}
****************************
int igdf_icgreen_(bang,co)
int *co;
gdImagePtr *bang;
{
int mod;
mod = gdImageColorGreen(*bang,*co);
return(mod);
}
/****** インターレス確認 (ID、返り値)  *******************/
int igdf_gil_(bang)
gdImagePtr *bang;
{
int chk;
chk = gdImageGetInterlaced(*bang);
return(chk);
}
/******** 透過確認 (ID、返り値) *****************/
int igdf_gtran_(bang)
gdImagePtr *bang;
{
int chk;
chk = gdImageGetTransparent(*bang);
return(chk);
}
/********* 文字(ID,大きさ、位置X、位置Y,文字、色)************************/
void igdf_char_(bang,x,y,moji,cl,s)
gdImagePtr *bang;
int *x,*y,*cl,*s;
char *moji;
{
if(*s==1)gdImageChar(*bang,gdFontTiny,*x,*y,*moji,*cl);
if(*s==2)gdImageChar(*bang,gdFontSmall,*x,*y,*moji,*cl);
if(*s==3)gdImageChar(*bang,gdFontMediumBold,*x,*y,*moji,*cl);
if(*s==4)gdImageChar(*bang,gdFontLarge,*x,*y,*moji,*cl);
if(*s==5)gdImageChar(*bang,gdFontGiant,*x,*y,*moji,*cl);
}

/********** 文字横(ID,大きさ、位置X、位置Y,文字、色)***************/
void igdf_chup_(bang,x,y,moji,cl,s)
gdImagePtr *bang;
int *x,*y,*cl,*s;
char *moji;
{
if(*s==1)gdImageCharUp(*bang,gdFontTiny,*x,*y,*moji,*cl);
if(*s==2)gdImageCharUp(*bang,gdFontSmall,*x,*y,*moji,*cl);
if(*s==3)gdImageCharUp(*bang,gdFontMediumBold,*x,*y,*moji,*cl);
if(*s==4)gdImageCharUp(*bang,gdFontLarge,*x,*y,*moji,*cl);
if(*s==5)gdImageCharUp(*bang,gdFontGiant,*x,*y,*moji,*cl);
}

/**********文字列(ID,大きさ、位置X、位置Y,文字列、色)***************/
void igdf_string_(bang,x,y,moji,cl,s) 
gdImagePtr *bang; 
int *x,*y,*cl,*s; 
char *moji; 
{
char xname[64];
suutan(xname,moji);
if(*s==1)gdImageString(*bang,gdFontTiny,*x,*y,xname,*cl);
if(*s==2)gdImageString(*bang,gdFontSmall,*x,*y,xname,*cl);
if(*s==3)gdImageString(*bang,gdFontMediumBold,*x,*y,xname,*cl);
if(*s==4)gdImageString(*bang,gdFontLarge,*x,*y,xname,*cl);
if(*s==5)gdImageString(*bang,gdFontGiant,*x,*y,xname,*cl);
}

/**********文字列横(ID,大きさ、位置X、位置Y,文字列、色)***************/
void igdf_strup_(bang,x,y,moji,cl,s) 
gdImagePtr *bang; 
int *x,*y,*cl,*s; 
char *moji; 
{char xname[64];
suutan(xname,moji);
if(*s==1)gdImageStringUp(*bang,gdFontTiny,*x,*y,xname,*cl);
if(*s==2)gdImageStringUp(*bang,gdFontSmall,*x,*y,xname,*cl);
if(*s==3)gdImageStringUp(*bang,gdFontMediumBold,*x,*y,xname,*cl);
if(*s==4)gdImageStringUp(*bang,gdFontLarge,*x,*y,xname,*cl);
if(*s==5)gdImageStringUp(*bang,gdFontGiant,*x,*y,xname,*cl);
}

/***複写(後ID,前ID、後左、上、前左、上、幅、高さ)****/
void igdf_copy_(afban,befban,afx,afy,befx,befy,wit,hei)
gdImagePtr *afban,*befban; 
int *afx,*afy,*befx,*befy,*wit,*hei;
{
gdImageCopy(*afban,*befban,*afx,*afy,*befx,*befy,*wit,*hei);
}
/*複写で大きさ変更(後ID,前ID、後左、上、前左、上、後幅、高さ、前幅、高さ)*/
void igdf_cpr_(afban,befban,afx,afy,befx,befy,afw,afh,befw,befh)
int *afx,*afy,*befx,*befy,*afw,*afh,*befw,*befh;
gdImagePtr *afban,*befban; 
{
gdImageCopyResized(*afban,*befban,*afx,*afy,*befx,*befy,*afw,*afh,*befw,*befh);
}
/**********ブラシを指定(キャンバスID,筆ID,筆)********************/
int igdf_brush_(bang,fid)
gdImagePtr *bang,*fid;
{
int fude;
gdImageSetBrush(*bang,*fid);
fude=gdBrushed;
return(fude);
}
/**********タイルを指定(キャンバスID,タイルID,タイル)*************/
int igdf_tile_(bang,tail)
gdImagePtr *bang,*tail;
{
int fude;
gdImageSetTile(*bang,*tail);
fude = gdTiled;
return(fude);
}

/*********破線のスタイル指定(ID,配列、合計)****************/
int igdf_sstyle_(bang,poont,zenbu)
int *zenbu,*poont;
gdImagePtr *bang;
{int i,fude;
gdImageSetStyle(*bang,poont,*zenbu);
fude=gdStyled;
return(fude);

}

/*********   書き込みアニメ(ID,ファイル名)   **********************/
void igdf_ani_(bang,mojx)
gdImagePtr *bang;
char *mojx;
{
	int i,kaisuu,delay,col_table;
char xname[64];
suutan(xname,mojx);
	
		for(i=0;i<10;i++){
		if(aniho[i].lord==1){
			if(strcmp(aniho[i].file_name,xname)==0&&aniho[i].agifbs==gifbs){
				kaisuu=aniho[i].kiokukai;
				delay=aniho[i].kiokutien;
				col_table=aniho[i].glc_table;
				break;
			}
		}
		else{/*lord==0*/
			aniho[i].lord=1;
			strcpy(aniho[i].file_name,xname);
			aniho[i].agifbs=gifbs;
		kaisuu=aniho[i].kiokukai;
		delay=aniho[i].kiokutien;
		col_table=aniho[i].glc_table;
			break;
		}
	}	
		
if(gifbs==2){
strcat(xname,".GIF");
gifbs=0;
}
else{
strcat(xname,".gif");
}
	
if(aniho[i].ani_chk==0)out=fopen(xname,"wb");
else 	out=fopen(xname,"r+b");
gdImageAni(*bang,out,kaisuu,delay,col_table);
fclose(out);
aniho[i].ani_chk=1;
}
/*********終端入力***************************/

void suutan(afmoj,bfmoj)
char afmoj[64],*bfmoj;
{
int ii=0,iii=0;
while((*(bfmoj+ii)!='$')||(*(bfmoj+ii)=='$'&&*(bfmoj+ii+1)=='$'))
{
	if(*(bfmoj+ii)!='$')
	{
	afmoj[iii]=*(bfmoj+ii);
	}
	else
	{
	afmoj[iii]=*(bfmoj+ii);
	ii++;
	}
ii++;
iii++;
}
afmoj[iii]='\0';
gifbs=0;
	if(afmoj[iii-4]=='.'&&afmoj[iii-3]=='g'&&afmoj[iii-2]=='i'&&afmoj[iii-1]=='f'){
		afmoj[iii-4]='\0';
		gifbs=1;
	}
else if(afmoj[iii-4]=='.'&&afmoj[iii-3]=='G'&&afmoj[iii-2]=='I'&&afmoj[iii-1]=='F'){
afmoj[iii-4]='\0';
gifbs=2;
}
}
/**************** 複数指定(ID,ファイル名）    ***********************/
void igdf_ngif_(bang,name)
gdImagePtr *bang;
char *name;
{
int i,keta;
double gif_num;
char xname[64],x2name[64],numb[3];
	suutan(xname,name);
	strcpy(x2name,xname);
	
	for(i=0;i<10;i++){
		if(hoz[i].lord==1){
			if(strcmp(hoz[i].file_name,xname)==0&&hoz[i].hgifbs==gifbs){
				gif_num=hoz[i].kiokunum;
				keta=hoz[i].kiokuketa;
				break;
			}
		}
		else{/*lord==0*/
			hoz[i].lord=1;
			strcpy(hoz[i].file_name,xname);
			hoz[i].hgifbs=gifbs;
			gif_num=hoz[i].kiokunum;
			keta=hoz[i].kiokuketa;
			break;
		}
	}

	suu_moju(keta,gif_num,numb);
	strcat(xname,numb);
	gif_num++;
	hoz[i].kiokunum=gif_num;
	if(gifbs==2){
strcat(xname,".GIF");
gifbs=0;
}
else{
strcat(xname,".gif");
}
	out=fopen(xname,"wb");
	gdImageGif(*bang,out);
	fclose(out);
	strcpy(xname,x2name);
}
/***********     数字文字列変換                      *******************/  
void suu_moju(keta,sui,moju)
int keta;
double sui;
char moju[64];
{
char moja[64];
int mojulong,i;
 sprintf(moja,"%g",sui);
 mojulong=strlen(moja);
 
 mojulong=keta-mojulong;
 strcpy(moju,"");
 for(i=0;i<mojulong;i++){
 strcat(moju,"0");
 }
 strcat(moju,moja);
}

/*********** 数字文字列設定(ファイル名，開始番号，桁）***********/
void igdf_ngst_(fname,num,keta)
int *num,*keta;
char *fname;
{
	char xname[64];
	int i;
	ngif_on=100;
	suutan(xname,fname);
	for(i=0;i<10;i++){
		if(hoz[i].lord==0){
			hoz[i].hgifbs=gifbs;
			strcpy(hoz[i].file_name,xname);
			hoz[i].kiokunum=*num;
			hoz[i].kiokuketa=*keta;
			hoz[i].lord=1;
			break;
		}
	}
}
/***アニメ設定（ファイル名，繰り返し回数，遅延時間，グローバル使用）***/
void igdf_anist_(fname,kai,tien,glct)
int *kai,*tien,*glct;
char *fname;
{
	char xname[64];
	int i;
	agif_on=100;
	suutan(xname,fname);
	for(i=0;i<10;i++){
		if(aniho[i].lord==0){
			aniho[i].agifbs=gifbs;
			strcpy(aniho[i].file_name,xname);
			aniho[i].kiokukai=*kai;
			aniho[i].kiokutien=*tien;
			aniho[i].lord=1;
			aniho[i].glc_table=*glct;
			break;
		}
	}
}
/**********グローバルカラー変更（インデックス，ファイル名）******************/
void igdf_anigc_(bang,name)
gdImagePtr *bang;
char *name;
{
	char xname[64];
	int i,kaisuu,delay,col_table;
	suutan(xname,name);
		for(i=0;i<10;i++){
		if(aniho[i].lord==1){
			if(strcmp(aniho[i].file_name,xname)==0&&aniho[i].agifbs==gifbs){
				kaisuu=aniho[i].kiokukai;
				delay=aniho[i].kiokutien;
				col_table=aniho[i].glc_table;
				break;
			}
		}
		else{/*lord==0*/
			aniho[i].lord=1;
			strcpy(aniho[i].file_name,xname);
			aniho[i].agifbs=gifbs;
		kaisuu=aniho[i].kiokukai;
		delay=aniho[i].kiokutien;
		col_table=aniho[i].glc_table;
			break;
		}
	}	
		
if(gifbs==2){
strcat(xname,".GIF");
gifbs=0;
}
else{
strcat(xname,".gif");
}

if((out=fopen(xname,"r+b"))==NULL){
printf("can't open writefile");
exit(0);
}
/*printf("okay2==%s\n",xname);*/
gdGColSet(*bang, out);
	fclose(out);
	}
