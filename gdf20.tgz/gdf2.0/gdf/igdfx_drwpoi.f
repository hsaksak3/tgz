c----------------------------------------------------------------------
c igdfx draw point
c                                /   /
      subroutine igdfx_drwpoi ( fx, fy )
c
c   <arguments>
c     f[xy]  : point coordinate
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_drwpoi] image was not selected'
         go to 999
      end if
      if( lgxtfc(lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_drwpoi] transform was not selected'
	 go to 999
      end if
c....
      call igdfx_wc2sc ( fx, fy, ix, iy, icnd )
c..
      if( icnd .eq. 0 ) call igdf_spx ( lgximt(lgxgic), ix, iy,
     $                                  lgxclt(lgxlcl(lgxgic),lgxgic) )
c....
  999 continue
      return
      end
