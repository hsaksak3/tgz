c----------------------------------------------------------------------
c igdfx close gif image
c                                 /      /     / 
      subroutine igdfx_clsgif ( kino, efile, kmode )
c
c   <arguments>
c     kino  : gif image number ( 1 =< kino =< lgxgix )
c     efile : gif file name
c     kmode : mode xy y:(=0:one by one, =1:anime gif, =2:only one)
c                     x:(=0:clear image, =1:remain image)
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c modified by Sakagami,H. ( HIT ) 03/05/03 for kmode = 2
c modified by Sakagami,H. ( HIT ) 03/05/27 for kmode = x*
c----------------------------------------------------------------------
      include "igdfx.h"
      character*32 efile
c....
      if( kino .lt. 1 .or. kino .gt. lgxgix ) then
         write(*,*) '[igdfx_clsgif] kino is invalid : ', kino
	 go to 999
      end if
      if( lgximt(kino) .eq. 0 ) then
         write(*,*) '[igdfx_clsgif] image was not opened : ', kino
	 go to 999
      end if
c....
      imode = mod( kmode, 10 )
      idy   = kmode / 10
c....
      if( imode .eq. 0 ) then
         call igdf_ngif ( lgximt(kino), efile )
      else if( imode .eq. 1 ) then
         call igdf_ani ( lgximt(kino), efile )
      else
         call igdf_igif ( lgximt(kino), efile )
      end if
c...
      if( idy .eq. 0 ) then
         call igdf_idy ( lgximt(kino) )
c..
         lgximt(kino) = 0
         lgxlcl(kino) = 0
         lgxfcl(kino) = 0
         lgxtcl(kino) = 0
         lgxwht(1,kino) = 0
         lgxwht(2,kino) = 0
         do i = 1, lgxvpx
            lgxvpt(i,kino) = 0
         end do
         do i = 1, lgxwnx
            lgxwnt(i,kino) = 0
         end do
         lgxtfc(kino) = 0
         do i = 1, lgxtfx
            lgxtft(1,i,kino) = 0
            lgxtft(2,i,kino) = 0
         end do
         do i = 1, 255
            lgxclt(i,kino) = -1
         end do
      end if
c....
  999 continue
      return
      end
