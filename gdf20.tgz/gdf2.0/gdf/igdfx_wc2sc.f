c----------------------------------------------------------------------
c igdfx convert from WC to SC
c                               /   /
      subroutine igdfx_wc2sc ( fx, fy, kx, ky, kcnd )
c                                      /   /    /
c   <arguments>
c     f[xy]  : world coordinate
c     k[xy]  : screen coordinate
c     kcnd   : condition code ( =0:normal, !=0:out of view port )
c
c   <remarks>
c     no error check !
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      iwn = lgxtft(2,lgxtfc(lgxgic),lgxgic)
c....
      wnx = ( fx - sgxwnt(1,iwn,lgxgic) ) /
     $      ( sgxwnt(3,iwn,lgxgic) - sgxwnt(1,iwn,lgxgic) )
      if( wnx .lt. 0.0 .or. wnx .gt. 1.0 ) then
         kcnd = 1
	 go to 999
      end if
      wny = ( fy - sgxwnt(2,iwn,lgxgic) ) /
     $      ( sgxwnt(4,iwn,lgxgic) - sgxwnt(2,iwn,lgxgic) )
      if( wny .lt. 0.0 .or. wny .gt. 1.0 ) then
         kcnd = 2
	 go to 999
      end if
c..
      kcnd = 0
c..
      ivp = lgxtft(1,lgxtfc(lgxgic),lgxgic)
c..
      wvx = sgxvpt(1,ivp,lgxgic) + wnx *
     $      ( sgxvpt(3,ivp,lgxgic) - sgxvpt(1,ivp,lgxgic) )
      wvy = sgxvpt(2,ivp,lgxgic) + wny *
     $      ( sgxvpt(4,ivp,lgxgic) - sgxvpt(2,ivp,lgxgic) )
c..
      kx = wvx * ( lgxwht(1,lgxgic) - 1 )
      ky = wvy * ( lgxwht(2,lgxgic) - 1 )
      ky = lgxwht(2,lgxgic) - 1 - ky
c....
  999 continue
      return
      end
