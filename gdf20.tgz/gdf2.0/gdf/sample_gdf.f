        integer*8 im
        integer*8 igdf_ic, igdf_cfgif, igdf_cfgd,igdf_cfxbm

	integer white,red,blue,black,green,stl,line,pnt,pnt2
	dimension stl(10),pnt(2,3),pnt2(2,6)
        character*3 char
	
	im=igdf_ic(300,300)
	
	white=igdf_cal(im,255,255,255)
	black=igdf_cal(im,0,0,0)
	green=igdf_cal(im,0,255,0)
	red=igdf_cal(im,255,0,0)
	blue=igdf_cal(im,0,0,255)

	stl(1)=blue
	stl(2)=blue
	stl(3)=blue
	stl(4)=blue
	stl(5)=blue
	stl(6)=red
	stl(7)=red
	stl(8)=red
	stl(9)=red
	stl(10)=red

	pnt(1,1)=250
	pnt(2,1)=100
	pnt(1,2)=230
	pnt(2,2)=160
	pnt(1,3)=300
	pnt(2,3)=200

	pnt2(1,1)=30
	pnt2(2,1)=220
	pnt2(1,2)=100
	pnt2(2,2)=210
	pnt2(1,3)=200
	pnt2(2,3)=290
	pnt2(1,4)=100
	pnt2(2,4)=260
	pnt2(1,5)=10
	pnt2(2,5)=295
	pnt2(1,6)=70
	pnt2(2,6)=230

	call igdf_line(im,0,0,80,80,black)
	call igdf_dline(im,100,0,180,80,green)
	line= igdf_sstyle(im,stl,10)
	call igdf_line(im,200,0,280,80,line)
	
	call igdf_arc(im,30,150,50,80,0,360,black)
	call igdf_arc(im,90,150,50,80,0,360,black)
	call igdf_fill(im,90,150,blue)
	
	call igdf_frec(im,120,110,160,190,red)
	call igdf_rect(im,170,110,210,190,black)
	
 	call igdf_pol(im,pnt,3,black)
 	call igdf_fpol(im,pnt2,6,green)

	call igdf_strup(im,270,290,'fortran gif$',blue,3) 
	call igdf_string(im,200,240,'text$',red,5) 

	call igdf_igif(im,'gdf1$')
	call igdf_idy(im)
	
        char(3:3) = '$'
        call igdf_ngst( 'gdf2-$', 10, 2 )
        do i = 1, 10
	   im = igdf_ic(200,200)
	   iblack = igdf_cal(im,0,0,0)
	   iblue  = igdf_cal(im,0,0,255)
	   iwhite = igdf_cal(im,255,255,255)
	   call igdf_arc(im,100,100,200-i*2,10+i*4,0,360,iblue)
	   call igdf_fill(im,100,100,iblue)
           write( char(1:2), '(i2)' ) i+9
	   call igdf_string(im,100,100,char,iwhite,5) 
	   call igdf_ngif(im,'gdf2-$')
	   call igdf_idy(im)
        end do

        stop
	end
