c----------------------------------------------------------------------
c igdfx define viewport
c                                 /      /     /     /     /
      subroutine igdfx_defvwp ( kvpno, fvxm, fvxx, fvym, fvyx )
c
c   <arguments>
c     kvpno      : viewport number ( 1 =< kvpno =< lgxvpx )
c     fv[xy][mx] : viewport min & mac (NDC)
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_defvwp] image was not selected'
	 go to 999
      end if
      if( kvpno .lt. 1 .or. kvpno .gt. lgxvpx ) then
         write(*,*) '[igdfx_defvwp] kvpno is invalid : ', kvpno
	 go to 999
      end if
      if( lgxvpt(kvpno,lgxgic) .ne. 0 ) then
         write(*,*) 
     $      '[igdfx_defvwp] view port was already defined : ', kvpno
	 go to 999
      end if
c....
      lgxvpt(kvpno,lgxgic) = kvpno + lgxgic
c..
      sgxvpt(1,kvpno,lgxgic) = fvxm
      sgxvpt(2,kvpno,lgxgic) = fvym
      sgxvpt(3,kvpno,lgxgic) = fvxx
      sgxvpt(4,kvpno,lgxgic) = fvyx
c....
  999 continue
      return
      end
