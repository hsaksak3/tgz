c----------------------------------------------------------------------
c igdfx draw rectangle
c                                /    /    /    /     /
      subroutine igdfx_drwrec ( fxs, fys, fxe, fye, kfil )
c
c   <arguments>
c     f[xy][se]  : rectangle coordinate
c     kfil : mode xy 00=draw rectangle with background color
c                    01=draw rectangle frame only
c                    10=fill rectangle only
c                    11=draw rectangle frame and fill rectangle
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( NIFS ) 09/05/12
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_drwlin] image was not selected'
         go to 999
      end if
      if( lgxtfc(lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_drwlin] transform was not selected'
	 go to 999
      end if
c....
      call igdfx_wc2sc ( fxs, fys, ixs, iys, icnds )
      call igdfx_wc2sc ( fxe, fye, ixe, iye, icnde )
c..
      ixm = min( ixs, ixe )
      ixx = max( ixs, ixe )
      iym = min( iys, iye )
      iyx = max( iys, iye )
c..
      if( icnds+icnde .eq. 0 ) then
	 if( kfil .eq. 0 ) then
            call igdf_frec ( lgximt(lgxgic), 
     $                          ixm ,iym, ixx, iyx, lgxclt(1,lgxgic) )
	 else
	    ifrm = mod( kfil, 2 )
	    ifil = kfil / 10
	    if( ifil .eq. 1 ) then
               call igdf_frec ( lgximt(lgxgic), ixm ,iym, ixx, iyx, 
     $                                 lgxclt(lgxfcl(lgxgic),lgxgic) )
            end if
	    if( ifrm .eq. 1 ) then
               call igdf_rect ( lgximt(lgxgic), ixm ,iym, ixx, iyx, 
     $                                 lgxclt(lgxlcl(lgxgic),lgxgic) )
            end if
         end if
      end if
c....
  999 continue
      return
      end
