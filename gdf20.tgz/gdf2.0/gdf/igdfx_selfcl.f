c----------------------------------------------------------------------
c igdfx select fill color
c                                 /
      subroutine igdfx_selfcl ( kcol )
c
c   <arguments>
c     kcol  : color number ( 1 =< kcol =< 255 )
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( NIFS ) 09/05/12
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_selfcl] image was not selected'
         go to 999
      end if
      if( kcol .lt. 1 .or. kcol .gt. 255 ) then
         write(*,*) '[igdfx_selfcl] kcol is invalid : ', kcol
	 go to 999
      end if
      if( lgxclt(kcol,lgxgic) .eq. -1 ) then
         write(*,*) '[igdfx_selfcl] color was not defined : ', kcol
	 go to 999
      end if
c....
      lgxfcl(lgxgic) = kcol
c....
  999 continue
      return
      end
