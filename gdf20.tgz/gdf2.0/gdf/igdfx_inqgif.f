c----------------------------------------------------------------------
c igdfx inquire gif image
c                                 /    
      subroutine igdfx_inqgif ( kino, kopen )
c                                       /
c   <arguments>
c     kino  : gif image number ( 1 =< kino =< lgxgix )
c     kopen : =0:image is not opened, =1:image is opened
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( NIFS ) 11/08/29
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( kino .lt. 1 .or. kino .gt. lgxgix ) then
         write(*,*) '[igdfx_clsgif] kino is invalid : ', kino
	 go to 999
      end if
c....
      if( lgximt(kino) .eq. 0 ) then
         kopen = 0
      else
         kopen = 1
      end if
c....
  999 continue
      return
      end
