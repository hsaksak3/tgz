c----------------------------------------------------------------------
c igdfx defile color
c                                 /    /   /   /
      subroutine igdfx_defcol ( kcol, kr, kg, kb )
c
c   <arguments>
c     kcol : color number
c     kr   : red   ( 0 =< kr =< 255 )
c     kg   : green ( 0 =< kg =< 255 )
c     kb   : blue  ( 0 =< kb =< 255 )
c
c   <remarks>
c     pre-defined color
c     1 : black (background )
c     2 : white
c     3 : gray
c     4 : red
c     5 : green
c     6 : blue
c     7 : skyblue
c     8 : purple
c     9 : yellow
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_defcol] image was not selected'
         go to 999
      end if  
      if( kcol .lt. 1 .or. kcol .gt. 255 ) then
         write(*,*) '[igdfx_defcol] kcol is invalid : ', kcol 
         go to 999
      end if  
      if( lgxclt(kcol,lgxgic) .ne. -1 ) then
         write(*,*) '[igdfx_defcol] color was already defined : ', kcol 
         go to 999
      end if  
c....                                  * allocate color and set table *
      lgxclt(kcol,lgxgic) = igdf_cal( lgximt(lgxgic), kr, kg, kb )
c....
  999 continue
      return
      end
