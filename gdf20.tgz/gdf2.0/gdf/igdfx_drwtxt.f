c----------------------------------------------------------------------
c igdfx draw text
c                                /   /    /      /
      subroutine igdfx_drwtxt ( kx, ky, kfont, etext )
c
c   <arguments>
c     kx    : x position
c     ky    : y position
c     kfont : font number
c     etext : text
c
c   <remarks>
c     Text string must be ended with '$'.
c
c    coded by Sakagami,H. ( HIT ) 02/07/01
c----------------------------------------------------------------------
      include "igdfx.h"
      character*(*) etext
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_drwvwp] image was not selected'
         go to 999
      end if
c....
      call igdf_string ( lgximt(lgxgic), kx, ky, etext, 
     $                           lgxclt(lgxtcl(lgxgic),lgxgic), kfont )
c....
  999 continue
      return
      end
