/******************************************************
 *                      gdex 1.0                      *
 *  GD Extention source to connect gd, gdf and gdfr   *
 *         Programmed by T. Taguchi for Frames        *
 *                   June  3, 2004                    *
 ******************************************************
*/

#define cost		gd_cosine_value
#define sint		gd_sine_value

#include "gd.c"

void gd_set_static_values(int RWidth,int RHeight)
{
	Width = RWidth;
	Height = RHeight;
	CountDown = (long)Width * (long)Height;
	Pass = 0;
	curx = cury = 0;
}

void gd_static_compress(int init_bits, FILE *outfile, gdImagePtr im, int background, int RInterlace)
{
	Interlace = RInterlace;
	compress( init_bits, outfile, im, background);
}

int gd_init_statics_colorstobpp(int colors)
{
	init_statics();
	return colorstobpp(colors);
}
