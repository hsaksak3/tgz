c----------------------------------------------------------------------
c igdfx select gif image
c                                 /
      subroutine igdfx_selgif ( kino )
c
c   <arguments>
c     kino  : gif image number ( 1 =< kino =< lgxgix )
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( kino .lt. 1 .or. kino .gt. lgxgix ) then
         write(*,*) '[igdfx_selgif] kino is invalid : ', kino
	 go to 999
      end if
      if( lgximt(kino) .eq. 0 ) then
         write(*,*) '[igdfx_selgif] image was not opened : ', kino
	 go to 999
      end if
c....
      lgxgic = kino
c....
  999 continue
      return
      end
