c----------------------------------------------------------------------
c igdfx terminate
c
      subroutine igdfx_term
c
c   <arguments>
c     none
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      do i = 1, lgxgix
         if( lgximt(i) .ne. 0 ) call igdf_idy ( lgximt(i) )
      end do
c....
      return
      end
