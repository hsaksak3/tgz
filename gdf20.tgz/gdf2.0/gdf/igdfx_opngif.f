c----------------------------------------------------------------------
c igdfx open gif image
c                                 /     /     / 
      subroutine igdfx_opngif ( kino, kwid, khigh )
c
c   <arguments>
c     kino  : gif image number ( 1 =< kino =< lgxgix )
c     kwid  : pixel width
c     khigh : pixel height
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
      integer*8 igdf_ic, igxim
c....
      if( kino .lt. 1 .or. kino .gt. lgxgix ) then
         write(*,*) '[igdfx_opngif] kino is invalid : ', kino
	 go to 999
      end if
      if( lgximt(kino) .ne. 0 ) then
         write(*,*) '[igdfx_opngif] image was already opened : ', kino
	 go to 999
      end if
c....                                              * create GIF image *
      igxim = igdf_ic ( kwid, khigh )
      lgximt(kino) = igxim
      lgxwht(1,kino) = kwid
      lgxwht(2,kino) = khigh
c..                                    * allocate color and set table *
c.                                              1 : black (background )
c.                                              2 : white
c.                                              3 : gray
c.                                              4 : red
c.                                              5 : green
c.                                              6 : blue
c.                                              7 : skyblue
c.                                              8 : purple
c.                                              9 : yellow
      lgxclt(1,kino) = igdf_cal( igxim, 0, 0, 0 )
      lgxclt(2,kino) = igdf_cal( igxim, 255, 255, 255 )
      lgxclt(3,kino) = igdf_cal( igxim, 128, 128, 128 )
      lgxclt(4,kino) = igdf_cal( igxim, 255, 0, 0 )
      lgxclt(5,kino) = igdf_cal( igxim, 0, 255, 0 )
      lgxclt(6,kino) = igdf_cal( igxim, 0, 0, 255 )
      lgxclt(7,kino) = igdf_cal( igxim, 0, 255, 255 )
      lgxclt(8,kino) = igdf_cal( igxim, 255, 0, 255 )
      lgxclt(9,kino) = igdf_cal( igxim, 255, 255, 0 )
c..
      do i = 1, lgxvpx
         lgxvpt(i,kino) = 0
      end do
      do i = 1, lgxwnx
         lgxwnt(i,kino) = 0
      end do
      lgxtfc(kino) = 0
      do i = 1, lgxtfx
         lgxtft(1,i,kino) = 0
         lgxtft(2,i,kino) = 0
      end do
c....                                                   * set default *
      lgxgic = kino
      lgxlcl(kino) = 2
      lgxfcl(kino) = 2
      lgxtcl(kino) = 2
c....
  999 continue
      return
      end
