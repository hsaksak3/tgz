/* <stdlib.h> added by Sakagami,H. 21/09/08 */
#include <stdlib.h>
#include "gd.h"

#define Putword(w, fp)  { fputc( (w)&0xff, fp ); fputc( ((w)>>8)&0xff, fp ); }
void gd_set_static_values(int,int);
void gd_static_compress(int, FILE *, gdImagePtr, int, int);
int gd_init_statics_colorstobpp(int);

/*********12/13***********/
int glct=0;
void gdGColSet(gdImagePtr im, FILE *fp)
{	
	int B,i;
	int interlace, transparent, BitsPerPixel;
	int Resolution;
	int ColorMapSize;
	int ColorMopSize,ColorMopSize1,ColorMopSize2;
	int *Red,*Green,*Blue;
	
	Red=im->red;
	Green=im->green;
	Blue=im->blue;
	interlace = im->interlace;
	transparent = im->transparent;
	BitsPerPixel = gd_init_statics_colorstobpp(im->colorsTotal);
	ColorMapSize = 1 << BitsPerPixel;
	
	fseek(fp,10,SEEK_SET); 
	Resolution = BitsPerPixel;

         B = 0x80;       

        B |= (Resolution - 1) << 4;
 
        B |= (BitsPerPixel - 1);

        fputc( B, fp );

        fputc( 0, fp );

        fputc( 0, fp );
/****12/11writing**************/
ColorMopSize=(256-ColorMapSize)*3;
/*	printf("clmap==%d,mop==%d\n",ColorMapSize,ColorMopSize);*/
        for( i=0; i<ColorMapSize; ++i ) {
                fputc( Red[i], fp );
                fputc( Green[i], fp );
                fputc( Blue[i], fp );
        }
if(glct==0){
	if(ColorMopSize > 256){
		ColorMopSize1=ColorMopSize/3;
		ColorMopSize2=ColorMopSize/3;
		ColorMopSize=ColorMopSize-ColorMopSize1-ColorMopSize2;
		/*printf("%d,%d,%d\n",ColorMopSize,ColorMopSize1,ColorMopSize2);
*/
				ColorMopSize1=ColorMopSize1-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize1, fp );
	        for( i=0; i<ColorMopSize1; ++i ) {
                fputc( 4, fp );
        }
	fputc( 0, fp );
		
				ColorMopSize2=ColorMopSize2-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize2, fp );
	        for( i=0; i<ColorMopSize2; ++i ) {
                fputc( 5, fp );
        }
	fputc( 0, fp );
		
				ColorMopSize=ColorMopSize-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize, fp );
	        for( i=0; i<ColorMopSize; ++i ) {
                fputc( 6, fp );
        }
	fputc( 0, fp );
		
	}
	else if(ColorMopSize > 0){
		ColorMopSize=ColorMopSize-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize, fp );
	        for( i=0; i<ColorMopSize; ++i ) {
                fputc( 0, fp );
        }
	fputc( 0, fp );
	}/*else end*/
}
}
/************************/

static void ANIEncode (FILE *fp, int GWidth, int GHeight, int GInterlace, int Background, int Transparent, int BitsPerPixel, int *Red, int *Green, int *Blue, gdImagePtr im,int kaisuu,int tienn,int glct2);

void gdImageAni(gdImagePtr im, FILE *out,int kaisuu,int tienn,int glct)
{
	int interlace, transparent, BitsPerPixel;
	interlace = im->interlace;
	transparent = im->transparent;
	BitsPerPixel = gd_init_statics_colorstobpp(im->colorsTotal);
	/* All set, let's do it. */
	ANIEncode(
		out, im->sx, im->sy, interlace, 0, transparent, BitsPerPixel,
		im->red, im->green, im->blue, im,kaisuu,tienn,glct);
}
/***************************************/
static void ANIEncode(FILE *fp, int GWidth, int GHeight, int GInterlace, int Background, 
		int Transparent, int BitsPerPixel, int *Red, int *Green, int *Blue, gdImagePtr im,int kaisuu,int tienn,int glct2)
{
        int B;
        int RWidth, RHeight;
        int LeftOfs, TopOfs;
        int RInterlace;
        int Resolution;
        int ColorMapSize;
	int ColorMopSize,ColorMopSize1,ColorMopSize2;
        int InitCodeSize;
        int i,icheck;
	int temp;
        char chc;

        RInterlace = GInterlace;
	glct=glct2;
        ColorMapSize = 1 << BitsPerPixel;

        RWidth = GWidth;
        RHeight = GHeight;

        gd_set_static_values(RWidth, RHeight);

        LeftOfs = TopOfs = 0;

        Resolution = BitsPerPixel;

        if( BitsPerPixel <= 1 )
                InitCodeSize = 2;
        else
                InitCodeSize = BitsPerPixel;
  
/***********初回通過 ********************************/
icheck=0;

chc=fgetc(fp);
if(chc!='G')
{
        fwrite( "GIF89a", 1, 6, fp );

        Putword( RWidth, fp );
        Putword( RHeight, fp );

         B = 0x80;       

        B |= (Resolution - 1) << 4;
 
        B |= (BitsPerPixel - 1);

        fputc( B, fp );

        fputc( Background, fp );

        fputc( 0, fp );
/****12/11writing**************/
ColorMopSize=(256-ColorMapSize)*3;
	/*printf("clmap==%d,mop==%d\n",ColorMapSize,ColorMopSize);
*/
        for( i=0; i<ColorMapSize; ++i ) {
                fputc( Red[i], fp );
                fputc( Green[i], fp );
                fputc( Blue[i], fp );
        }
if(glct==0){
	if(ColorMopSize > 256){
		ColorMopSize1=ColorMopSize/3;
		ColorMopSize2=ColorMopSize/3;
		ColorMopSize=ColorMopSize-ColorMopSize1-ColorMopSize2;
/*		printf("%d,%d,%d\n",ColorMopSize,ColorMopSize1,ColorMopSize2);*/
				ColorMopSize1=ColorMopSize1-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize1, fp );
	        for( i=0; i<ColorMopSize1; ++i ) {
                fputc( 0, fp );
        }
	fputc( 0, fp );
		
				ColorMopSize2=ColorMopSize2-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize2, fp );
	        for( i=0; i<ColorMopSize2; ++i ) {
                fputc( 1, fp );
        }
	fputc( 0, fp );
		
				ColorMopSize=ColorMopSize-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize, fp );
	        for( i=0; i<ColorMopSize; ++i ) {
                fputc( 2, fp );
        }
	fputc( 0, fp );
		
	}
	else if(ColorMopSize > 0){
		ColorMopSize=ColorMopSize-4;
	fputc( 0x21, fp );
	fputc( 0xfe, fp );
	fputc( ColorMopSize, fp );
	        for( i=0; i<ColorMopSize; ++i ) {
                fputc( 3, fp );
        }
	fputc( 0, fp );
	}/*else end*/
}
/**********アプリ  設定 *********************/
if(kaisuu!=1){
	    fputc( '!', fp );
	    fputc( 0xff, fp );
	    fputc( 0x0b, fp );
	    fputc( 'N', fp );
	    fputc( 'E', fp );
	    fputc( 'T', fp );
	    fputc( 'S', fp );
	    fputc( 'C', fp );
	    fputc( 'A', fp );
	    fputc( 'P', fp );
	    fputc( 'E', fp );
	    fputc( '2', fp );
	    fputc( '.', fp );
	    fputc( '0', fp );
	    fputc( 3, fp );
	    fputc( 1, fp );

if(kaisuu>65535){
	fprintf(stderr,"GIF repeat times are too large !!!\n");
	exit(0);
}
temp=kaisuu%256;
	    fputc( temp, fp );
temp=kaisuu/256;
	    fputc( temp, fp );
		
	    fputc( 0, fp );
		
}/*一回の時は不要*/

	    fputc( '!', fp );
	    fputc( 0xf9, fp );
	    fputc( 4, fp );
	    if(Transparent >= 0) fputc( 9, fp );
	    else fputc(8,fp);

if(tienn>65535){
	fprintf(stderr,"GIF Delay time is too large !!!\n");
	exit(0);
}
temp=tienn%256;
	    fputc( temp, fp );
temp=tienn/256;
	    fputc( temp, fp );

	    if(Transparent >= 0) fputc( (unsigned char) Transparent, fp );
	    else fputc( 0, fp);
	    fputc( 0, fp );
	    icheck=1;
              

}
/****************初回終り*********************/
/*********アニメ設定*********************/
	if(icheck!=1){
	fseek(fp,-1,SEEK_END); 
/*	chc=fgetc(fp);
	if(chc==';')fseek(fp,-2,SEEK_END);*/

	    fputc( '!', fp );
	    fputc( 0xf9, fp );
	    fputc( 4, fp );
	    if(Transparent >= 0) fputc( 9, fp );
	    else fputc(8,fp);

if(tienn>65535){
	fprintf(stderr,"GIF Delay time is too large !!!\n");
	exit(0);
}
temp=tienn%256;
	    fputc( temp, fp );
temp=tienn/256;
	    fputc( temp, fp );

	    if(Transparent >= 0) fputc( (unsigned char) Transparent, fp );
	    else fputc( 0, fp);
	    fputc( 0, fp );
              
}
 

        fputc( ',', fp );

        Putword( LeftOfs, fp );
        Putword( TopOfs, fp );
        Putword( RWidth, fp );
        Putword( RHeight, fp );
		
		/*******new writing  12/11************/
if(glct==1){
        RInterlace = GInterlace;

        ColorMapSize = 1 << BitsPerPixel;

        if( RInterlace )
	B = 0xc0;
        else
	B = 0x80;       
 
        B |= (BitsPerPixel - 1);

        fputc( B, fp );

        for( i=0; i<ColorMapSize; ++i ) {
                fputc( Red[i], fp );
                fputc( Green[i], fp );
                fputc( Blue[i], fp );
        }
}
/********************************/
else{
      if( RInterlace )
                fputc( 0x40, fp );
        else
                fputc( 0x00, fp );
}

        fputc( InitCodeSize, fp );

        gd_static_compress( InitCodeSize+1, fp, im, Background, RInterlace );

        fputc( 0, fp );

        fputc( ';', fp );
}
