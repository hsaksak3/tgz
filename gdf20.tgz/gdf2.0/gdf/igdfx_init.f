c----------------------------------------------------------------------
c igdfx initialize
c
      subroutine igdfx_init
c
c   <arguments>
c     none
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      lgxgic = 0
      do i = 1, lgxgix
         lgximt(i) = 0
	 lgxtfc(i) = 0
	 lgxlcl(i) = 0
	 lgxfcl(i) = 0
	 lgxtcl(i) = 0
	 lgxwht(1,i) = 0
	 lgxwht(2,i) = 0
	 do ii = 1, lgxvpx
	    lgxvpt(ii,i) = 0
	 end do
	 do ii = 1, lgxwnx
	    lgxwnt(ii,i) = 0
	 end do
	 do ii = 1, lgxtfx
	    lgxtft(1,ii,i) = 0
	    lgxtft(2,ii,i) = 0
	 end do
	 do ii = 1, 255
	    lgxclt(ii,i) = -1
	 end do
      end do
c....
      return
      end
