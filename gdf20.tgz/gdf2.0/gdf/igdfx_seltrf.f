c----------------------------------------------------------------------
c igdfx select transformation
c                                 /
      subroutine igdfx_seltrf ( ktfno )
c
c   <arguments>
c     ktfno      : transformation number ( 1 =< ktfno =< lgxtfx )
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_seltrf] image was not selected'
	 go to 999
      end if
      if( ktfno .lt. 1 .or. ktfno .gt. lgxtfx ) then
         write(*,*) '[igdfx_seltrf] ktfno is invalid : ', ktfno
	 go to 999
      end if
      if( lgxtft(1,ktfno,lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_seltrf] transform was not defined : ', ktfno
	 go to 999
      end if
c....
      lgxtfc(lgxgic) = ktfno
c....
  999 continue
      return
      end
