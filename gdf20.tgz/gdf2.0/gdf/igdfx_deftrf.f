c----------------------------------------------------------------------
c igdfx define transformation
c                                 /      /      /
      subroutine igdfx_deftrf ( ktfno, kvpno, kwnno )
c
c   <arguments>
c     ktfno      : transformation number ( 1 =< ktfno =< lgxtfx )
c     kvpno      : view port number ( 1 =< kvpno =< lgxvpx )
c     kwnno      : window number ( 1 =< kwnno =< lgxwnx )
c
c   <remarks>
c     none
c
c    coded by Sakagami,H. ( HIT ) 00/10/18
c----------------------------------------------------------------------
      include "igdfx.h"
c....
      if( lgxgic .lt. 1 .or. lgxgic .gt. lgxgix ) then
         write(*,*) '[igdfx_deftrf] image was not selected'
	 go to 999
      end if
      if( kvpno .lt. 1 .or. kvpno .gt. lgxvpx ) then
         write(*,*) '[igdfx_deftrf] kvpno is invalid : ', kvpno
	 go to 999
      end if
      if( lgxvpt(kvpno,lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_deftrf] viewport was not defined : ', kvpno
	 go to 999
      end if
      if( kwnno .lt. 1 .or. kwnno .gt. lgxwnx ) then
         write(*,*) '[igdfx_deftrf] kwnno is invalid : ', kwnno
	 go to 999
      end if
      if( lgxwnt(kwnno,lgxgic) .eq. 0 ) then
         write(*,*) '[igdfx_deftrf] window was not defined : ', kwnno
	 go to 999
      end if
      if( lgxtft(1,ktfno,lgxgic) .ne. 0 ) then
         write(*,*) 
     $      '[igdfx_deftrf] transform was already defined : ', ktfno
	 go to 999
      end if
c....
      lgxtft(1,ktfno,lgxgic) = kvpno
      lgxtft(2,ktfno,lgxgic) = kwnno
c..                                                     * set default *
      lgxtfc(lgxgic) = ktfno
c....
  999 continue
      return
      end
