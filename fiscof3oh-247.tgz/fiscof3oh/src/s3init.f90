!----------------------------------------------------------------------
! Set 3D INITial values
!
      subroutine s3init
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/14
!----------------------------------------------------------------------
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use profile
      use particle
      use field
      use pml
      use observe
      use animation
      use fpprm
      use debug
      include "implicit.h"
      integer :: i, icll, io, ix, iy, iz, ilx, &
                 issh, issv, issp, iohp0, iohps, iohpe, &
                 iovp0, iovps, iovpe, iopp0
#ifdef OHHELP
      include "mpif.h"
      integer :: ips, ierr, itmp, inoe, inoi
#endif
      real*8  :: wgam, wichg, wpfin, wpfix, wpnoi, wdemax, wgi, wgh
      save
!....
      call fdebug ( 's3init', 0 )
!....
      if( lresti .eq. 0 ) then
         if ( lpprof .eq. 0 ) then
#ifndef OHHELP
            lnoe = 0
            lnoes = 0
            lnoee = -1
            lnoi = 0
            lnois = 0
            lnoie = -1
#else
            call s3ext_conv( 13 )
#endif
            lionspl = 0
            lxps = -10000
            lxpe = -10000
            lyps = -10000
            lype = -10000
            lzps = -10000
            lzpe = -10000
            if( lrank .le. 0 ) &
            write(6,*) '@@@ no plasma'
            lnox = 1
         else if ( lpprof .eq. -1 ) then
            call s3rstr
         else if ( lpprof .eq. 1 ) then
            call s3qstr ( ldebug )
         else if ( lpprof .eq. 2 ) then
            call s3fstr
         else
            write(0,*) '### ERROR: not implemented. lpprof =',lpprof
            call s3ext_abort
         end if
!----
#ifdef OHHELP
         ips = 1
#endif
         if( ldebug .eq. -1 ) then
            write(6,*) '### particle number count mode'
            write(6,*) 'number of electrons = ', lnoe
            write(6,*) 'number of ions      = ', lnoi
            if( lnoi .gt. 0 ) then
               do io = 1, lionspl
                  write(6,*) 'io, ids, ide, idl = ', &
                        io, lionids(io), lionide(io), lionidl(io)
               end do
            end if
            call s3ext_term
            stop 77777
         end if
!----
#ifdef OHHELP
         call MPI_ALLREDUCE( lnoe, oh_glnoe, 1, MPI_INTEGER, &
                                MPI_SUM, MPI_COMM_WORLD, ierr )
         call MPI_ALLREDUCE( lnoi, oh_glnoi, 1, MPI_INTEGER, &
                                MPI_SUM, MPI_COMM_WORLD, ierr )
         if( lrank .le. 0 ) then
            write(6,*) 'oh_glnoe, oh_glnoi =', oh_glnoe, oh_glnoi
         end if
!..
         call s3ext_exec ( 11 )
         call s3ext_conv ( 10 )
#endif
         spnoe = s0o1
         spfen = 1.0d20
         spfex = s0o1
!..
#ifdef OHHELP
         do ips = 1, 2
         if( oh_lnoe(ips) .le. 0 ) cycle
#endif
         if( lnoe .gt. 0 ) then
            do i = lnoes, lnoee
               wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
               svxe(i) = suxe(i) / wgam
               svye(i) = suye(i) / wgam
               svze(i) = suze(i) / wgam
            end do
!
            do i = lnoes, lnoee
               spnoe = spnoe + spfe(i)
               spfen = min( spfen, spfe(i) )
               spfex = max( spfex, spfe(i) )
            end do
!g77
!g77 This check is needed to suppress g77 optimization bug.
!g77
            if( spfex .lt. spfen ) then
               write(0,*) '### ERROR: invalid spfen, spfex ',spfen,spfex
               call s3ext_abort
            end if
         end if
#ifdef OHHELP
         end do
#endif
!...
#ifndef OHHELP
         if( lnoe .gt. 0 ) then
#else
         if( oh_glnoe .gt. 0 ) then
            ips = 1
#endif
            if( lrank .le. 0 ) then
              write(6,*) '@@@ lxps, lxpe = ', lxps, lxpe, &
                ' (',(lxps-lxp0)*slmicinv,(lxpe-lxp0)*slmicinv,')'
              write(6,*) '@@@ lyps, lype = ', lyps, lype, &
                ' (',(lyps-lyp0)*slmicinv,(lype-lyp0)*slmicinv,')'
              write(6,*) '@@@ lzps, lzpe = ', lzps, lzpe, &
                ' (',(lzps-lzp0)*slmicinv,(lzpe-lzp0)*slmicinv,')'
            end if
#ifndef OHHELP
            write(6,*) '@@@ lnoe, spnoe, spfex, spfen = ', &
                    lnoe, spnoe, spfex, spfen
#else
            itmp = oh_lnoe(1) + oh_lnoe(2)
            write(6,*) '@@@ lnoe, spnoe, spfex, spfen = ', &
                    itmp, spnoe, spfex, spfen
            call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                 MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoe, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfen, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MIN, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfex, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
            if( lrank .le. 0 ) then
              write(6,*) 'global lnoe, spnoe, spfex, spfen = ', &
                          itmp, spnoe, spfex, spfen
            end if
#endif
!..
            call c3fde
!.                                            * check wncmax validity *
            wdemax = maxval( sde(:,:,:) )
#ifdef OHHELP
            call MPI_ALLREDUCE( MPI_IN_PLACE, wdemax, 1, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
#endif
            if( abs(wdemax/snepm1*sncinv-s1o1) .gt. sncmaxtl ) then
               write(0,*) '### ERROR: invalid wncmax', &
                                 s1o1/sncinv, wdemax/snepm1, sncmaxtl
               call s3ext_abort
            end if
!...
         else
!                         * to avoid zero div in o3eng when no plasma *
            spnoe = s1o1
#ifdef OHHELP
            do ips = 1, 2
#endif
            sde(:,:,:) = s0o1
#ifdef OHHELP
            end do
#endif
         end if
!....
         wichg  = s0o1
         spnoit = s0o1
#ifdef OHHELP
         do io = 1, lionspl 
           spnoi(io) = s0o1
           spfin(io) = 1.0d20
           spfix(io) = s0o1
         end do
         do ips = 1, 2
         if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
!...                                                     * mobile ion *
         if( lnoi .gt. 0 ) then
            do i = lnois, lnoie
               wgam = sqrt( s1o1 + suui(i)**2 * scg1 )
               svxi(i) = suxi(i) / wgam
               svyi(i) = suyi(i) / wgam
               svzi(i) = suzi(i) / wgam
            end do
!
            do io = 1, lionspl
#ifdef OHHELP
               if( lionidl(io) .le. 0 ) cycle 
#endif
               wpnoi = s0o1
               wpfin = 1.0d20
               wpfix = s0o1
               do i = lionids(io), lionide(io)
                  wpnoi = wpnoi + spfi(i)
                  wpfin = min( wpfin, spfi(i) )
                  wpfix = max( wpfix, spfi(i) )
               end do
               if( wpfix .lt. wpfin ) then
                  write(0,*) '### ERROR: invalid wpfin,wpfix ', &
                            io, wpfin, wpfix
                  call s3ext_abort
               end if
#ifndef OHHELP
               spnoi(io) = wpnoi
               spfin(io) = wpfin
               spfix(io) = wpfix
#else
               spnoi(io) = spnoi(io) + wpnoi 
               spfin(io) = min( spfin(io), wpfin ) 
               spfix(io) = max( spfix(io), wpfix ) 
#endif
               spnoit  = spnoit  + wpnoi
               wichg = wichg + wpnoi * sionaz(io)
            end do
         end if
#ifdef OHHELP
         end do
#endif
!...
#ifndef OHHELP
         if( lnoi .gt. 0 ) then
            write(6,*) '@@@ lnoi, spnoit = ', lnoi, spnoit
            do io = 1, lionspl
               write(6,*) '@@@ io, idl, spnoi, spfix, spfin = ', &
                     io, lionidl(io), spnoi(io), spfix(io), spfin(io)
            end do
            write(6,*) '@@@ net total charge = ', wichg - spnoe
#else
         if( oh_glnoi .gt. 0 ) then
            ips = 1
            itmp = oh_lnoi(1) + oh_lnoi(2)
            write(6,*) '@@@ lnoi, spnoit = ', itmp, spnoit
            do io = 1, lionspl
               itmp = oh_lionidl(io,1) + oh_lionidl(io,2)
               write(6,*) '@@@ io, idl, spnoi, spfix, spfin = ', &
                     io, itmp, spnoi(io), spfix(io), spfin(io)
            end do
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoi, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfix, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_MAX, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spfin, lionspl, &
                 MPI_DOUBLE_PRECISION, MPI_MIN, MPI_COMM_WORLD, ierr )
            do io = 1, lionspl
              itmp = oh_lionidl(io,1) + oh_lionidl(io,2)
              call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                          MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
              if( lrank .le. 0 ) &
              write(6,*) 'global io, idl, spnoi, spfix, spfin =', &
                          io, itmp, spnoi(io), spfix(io), spfin(io)
            end do
            itmp = oh_lnoi(1) + oh_lnoi(2)
            call MPI_ALLREDUCE( MPI_IN_PLACE, itmp, 1, &
                 MPI_INTEGER, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, spnoit, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            call MPI_ALLREDUCE( MPI_IN_PLACE, wichg, 1, &
                 MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr )
            if( lrank .le. 0 ) &
               write(6,*) 'global lnoi, spnoit, net total charge =', &
                          itmp, spnoit, wichg - spnoe
#endif
!..
            call c3fdi
!...                                                   * immobile ion *
         else
            if( lrank .le. 0 ) then
#ifndef OHHELP
               if( lnoe .gt. 0 ) write(6,*) '@@@ immobile ion'
#else
               if( oh_glnoe .gt. 0 ) write(6,*) '@@@ immobile ion'
#endif
            end if
#ifdef OHHELP
            ips = 1
#endif
            sde0(:,:,:) = sde(:,:,:)
            sdi(:,:,:,:) = s0o1
         end if
!...
#ifdef OHHELP
         do ips = 1, 2
#endif
         sjxe(:,:,:) = s0o1
         sjye(:,:,:) = s0o1
         sjze(:,:,:) = s0o1
         sjxi(:,:,:,:) = s0o1
         sjyi(:,:,:,:) = s0o1
         sjzi(:,:,:,:) = s0o1
         sjxt(:,:,:) = s0o1
         sjyt(:,:,:) = s0o1
         sjzt(:,:,:) = s0o1
#ifdef OHHELP
         end do
!..
         call s3ext_conv ( 0 )
!..
         do ips = 1, 2
#endif
         sbx(:,:,:) = s0o1
         sby(:,:,:) = s0o1
         sbz(:,:,:) = s0o1
         sex(:,:,:) = s0o1
         sey(:,:,:) = s0o1
         sez(:,:,:) = s0o1
!.
         sbyxxl(:,:,:) = s0o1
         sbyxxu(:,:,:) = s0o1
         sbyzxl(:,:,:) = s0o1
         sbyzxu(:,:,:) = s0o1
         sbzxxl(:,:,:) = s0o1
         sbzxxu(:,:,:) = s0o1
         sbzyxl(:,:,:) = s0o1
         sbzyxu(:,:,:) = s0o1
         seyxxl(:,:,:) = s0o1
         seyxxu(:,:,:) = s0o1
         seyzxl(:,:,:) = s0o1
         seyzxu(:,:,:) = s0o1
         sezxxl(:,:,:) = s0o1
         sezxxu(:,:,:) = s0o1
         sezyxl(:,:,:) = s0o1
         sezyxu(:,:,:) = s0o1
!
         sbxyyl(:,:,:) = s0o1
         sbxyyu(:,:,:) = s0o1
         sbxzyl(:,:,:) = s0o1
         sbxzyu(:,:,:) = s0o1
         sbzxyl(:,:,:) = s0o1
         sbzxyu(:,:,:) = s0o1
         sbzyyl(:,:,:) = s0o1
         sbzyyu(:,:,:) = s0o1
         sexyyl(:,:,:) = s0o1
         sexyyu(:,:,:) = s0o1
         sexzyl(:,:,:) = s0o1
         sexzyu(:,:,:) = s0o1
         sezxyl(:,:,:) = s0o1
         sezxyu(:,:,:) = s0o1
         sezyyl(:,:,:) = s0o1
         sezyyu(:,:,:) = s0o1
!
         sbxyzl(:,:,:) = s0o1
         sbxyzu(:,:,:) = s0o1
         sbxzzl(:,:,:) = s0o1
         sbxzzu(:,:,:) = s0o1
         sbyxzl(:,:,:) = s0o1
         sbyxzu(:,:,:) = s0o1
         sbyzzl(:,:,:) = s0o1
         sbyzzu(:,:,:) = s0o1
         sexyzl(:,:,:) = s0o1
         sexyzu(:,:,:) = s0o1
         sexzzl(:,:,:) = s0o1
         sexzzu(:,:,:) = s0o1
         seyxzl(:,:,:) = s0o1
         seyxzu(:,:,:) = s0o1
         seyzzl(:,:,:) = s0o1
         seyzzu(:,:,:) = s0o1
#ifdef OHHELP
         end do
#endif
!.
         sextbx = sextbx / scofb
         sextby = sextby / scofb
         sextbz = sextbz / scofb
!.
         call c3fed
!....
      else
         call s3rest ( 0, lresti )
#ifdef OHHELP
         itmp = oh_lnoe(1)
         if( oh_sdid(2) .ge. 0 ) itmp = itmp + oh_lnoe(2)
         call MPI_REDUCE( itmp, inoe, 1, MPI_INTEGER, &
                                MPI_SUM, 0, MPI_COMM_WORLD, ierr )
         itmp = oh_lnoi(1)
         if( oh_sdid(2) .ge. 0 ) itmp = itmp + oh_lnoi(2)
         call MPI_REDUCE( itmp, inoi, 1, MPI_INTEGER, &
                                MPI_SUM, 0, MPI_COMM_WORLD, ierr )
         if( lrank .le. 0 ) then
            if( inoe .ne. oh_glnoe .or. inoi .ne. oh_glnoi ) then
               write(0,*) '### ERROR: total # particle mismatch', &
                          inoe, oh_glnoe, inoi, oh_glnoi
               call s3ext_abort
            end if
            write(6,*) 'oh_glnoe, oh_glnoi =', oh_glnoe, oh_glnoi
         end if
         call s3ext_exec( 21 )
#endif
      end if
!....
      if( lbxluf .eq. 4 ) then
         do ix = lblxl, lssxlm1
            wgi = sblsgxl * ( (lssxl-ix+s1o2)**(lblsgxl+1) - &
             (lssxl-ix-s1o2)**(lblsgxl+1) )/lpmlxl**lblsgxl/(lblsgxl+1)
            wgh = sblsgxl * ( (lssxl-ix)**(lblsgxl+1) - &
             (lssxl-ix-s1o1)**(lblsgxl+1) )/lpmlxl**lblsgxl/(lblsgxl+1)
            scaxli(ix-1) = exp(-wgi)
            scaxlh(ix)   = exp(-wgh)
            scbbxlh(ix)   = ( s1o1 - exp(-wgh) ) / wgh
            scbexli(ix-1) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
         do ix = lssxup2, lblxu
            wgi = sblsgxu * ( (ix-lssxup1+s1o2)**(lblsgxu+1) - &
            (ix-lssxup1-s1o2)**(lblsgxu+1) )/lpmlxu**lblsgxu/(lblsgxu+1)
            wgh = sblsgxu * ( (ix-lssxup2+s1o1)**(lblsgxu+1) - &
            (ix-lssxup2)**(lblsgxu+1) )/lpmlxu**lblsgxu/(lblsgxu+1)
            scaxui(ix) = exp(-wgi)
            scaxuh(ix) = exp(-wgh)
            scbbxuh(ix) = ( s1o1 - exp(-wgh) ) / wgh
            scbexui(ix) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
      end if
      if( lbyluf .eq. 4 ) then
         do iy = lblyl, lssylm1
            wgi = sblsgyl * ( (lssyl-iy+s1o2)**(lblsgyl+1) - &
             (lssyl-iy-s1o2)**(lblsgyl+1) )/lpmlyl**lblsgyl/(lblsgyl+1)
            wgh = sblsgyl * ( (lssyl-iy)**(lblsgyl+1) - &
             (lssyl-iy-s1o1)**(lblsgyl+1) )/lpmlyl**lblsgyl/(lblsgyl+1)
            scayli(iy-1) = exp(-wgi)
            scaylh(iy)   = exp(-wgh)
            scbbylh(iy)   = ( s1o1 - exp(-wgh) ) / wgh
            scbeyli(iy-1) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
         do iy = lssyup2, lblyu
            wgi = sblsgyu * ( (iy-lssyup1+s1o2)**(lblsgyu+1) - &
            (iy-lssyup1-s1o2)**(lblsgyu+1) )/lpmlyu**lblsgyu/(lblsgyu+1)
            wgh = sblsgyu * ( (iy-lssyup2+s1o1)**(lblsgyu+1) - &
            (iy-lssyup2)**(lblsgyu+1) )/lpmlyu**lblsgyu/(lblsgyu+1)
            scayui(iy) = exp(-wgi)
            scayuh(iy) = exp(-wgh)
            scbbyuh(iy) = ( s1o1 - exp(-wgh) ) / wgh
            scbeyui(iy) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
      end if
      if( lbzluf .eq. 4 ) then
         do iz = lblzl, lsszlm1
            wgi = sblsgzl * ( (lsszl-iz+s1o2)**(lblsgzl+1) - &
             (lsszl-iz-s1o2)**(lblsgzl+1) )/lpmlzl**lblsgzl/(lblsgzl+1)
            wgh = sblsgzl * ( (lsszl-iz)**(lblsgzl+1) - &
             (lsszl-iz-s1o1)**(lblsgzl+1) )/lpmlzl**lblsgzl/(lblsgzl+1)
            scazli(iz-1) = exp(-wgi)
            scazlh(iz)   = exp(-wgh)
            scbbzlh(iz)   = ( s1o1 - exp(-wgh) ) / wgh
            scbezli(iz-1) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
         do iz = lsszup2, lblzu
            wgi = sblsgzu * ( (iz-lsszup1+s1o2)**(lblsgzu+1) - &
            (iz-lsszup1-s1o2)**(lblsgzu+1) )/lpmlzu**lblsgzu/(lblsgzu+1)
            wgh = sblsgzu * ( (iz-lsszup2+s1o1)**(lblsgzu+1) - &
            (iz-lsszup2)**(lblsgzu+1) )/lpmlzu**lblsgzu/(lblsgzu+1)
            scazui(iz) = exp(-wgi)
            scazuh(iz) = exp(-wgh)
            scbbzuh(iz) = ( s1o1 - exp(-wgh) ) / wgh
            scbezui(iz) = ( s1o1 - exp(-wgi) ) / wgi * scb1
         end do
      end if
!...
      if( loxp0 .le. 0 ) loxp0 = lxp0
      if( soxps .le. sundef ) then
         loxps = lxps - 5
      else
         loxps = soxps * slmic + loxp0
      end if
      if( loxps .lt. 1 .or. loxps .gt. lssx ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. x start ', loxps, lxps, soxps
         loxps = 1
      end if
      if( soxpe .le. sundef ) then
         loxpe = lxpe + 5
      else
         loxpe = soxpe * slmic + loxp0
      end if
      if( loxpe .lt. 1 .or. loxpe .gt. lssx ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. x end ', loxpe, lxpe, soxpe
         loxpe = lssx
      end if
#ifdef OHHELP
      if( loxpe .eq. lssx ) loxpe = lssxm1
#endif
      loxpl  = ( loxpe - loxps ) / loxpi + 1
      soxp0m = ( loxp0 - loxps ) * slmicinv
      if( lrank .le. 0 ) &
      write(6,*) '@@@ loxps, loxpe, loxpl, loxpi, loxp0, soxp0m = ', &
                 loxps, loxpe, loxpl, loxpi, loxp0, soxp0m
      do i = 1, locrsx
         if( soxcrs(i) .le. sundef ) then
            soxcrs(i) = soxmic*(loxpl-1)*s1o2-soxp0m
         else
            if( soxcrs(i) .lt. -soxp0m .or. &
                soxcrs(i) .gt. soxmic*(loxpl-1)-soxp0m ) then
               write(0,*) '### ERROR: soxcrs is out of range', &
                          i, soxcrs(i)
               call s3ext_abort
            end if
         end if
      end do
      if( sosltd(1) .le. sundef ) then
         sosltd(1) = soxmic*(loxpl-1)*s1o2-soxp0m
      else
         if( sosltd(1) .lt. -soxp0m .or. &
             sosltd(1) .gt. soxmic*(loxpl-1)-soxp0m ) then
            write(0,*) '### ERROR: sosltd(1) is out of range', sosltd(1)
            call s3ext_abort
         end if
      end if
!.
      if( loyp0 .le. 0 ) loyp0 = lyp0
      if( soyps .le. sundef ) then
         loyps = lyps - 5
      else
         loyps = soyps * slmic + loyp0
      end if
      if( loyps .lt. 1 .or. loyps .gt. lssy ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. y start ', loyps, lyps, soyps
         loyps = 1
      end if
      if( soype .le. sundef ) then
         loype = lype + 5
      else
         loype = soype * slmic + loyp0
      end if
      if( loype .lt. 1 .or. loype .gt. lssy ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. y end ', loype, lype, soype
         loype = lssy
      end if
#ifdef OHHELP
      if( loype .eq. lssy ) loype = lssym1
#endif
      loypl  = ( loype - loyps ) / loypi + 1
      soyp0m = ( loyp0 - loyps ) * slmicinv
      if( lrank .le. 0 ) &
      write(6,*) '@@@ loyps, loype, loypl, loypi, loyp0, soyp0m = ', &
                 loyps, loype, loypl, loypi, loyp0, soyp0m
      do i = 1, locrsx
         if( soycrs(i) .le. sundef ) then
            soycrs(i) = soymic*(loypl-1)*s1o2-soyp0m
         else
            if( soycrs(i) .lt. -soyp0m .or. &
                soycrs(i) .gt. soymic*(loypl-1)-soyp0m ) then
               write(0,*) '### ERROR: soycrs is out of range', &
                          i, soycrs(i)
               call s3ext_abort
            end if
         end if
      end do
      if( sosltd(2) .le. sundef ) then
         sosltd(2) = soymic*(loypl-1)*s1o2-soyp0m
      else
         if( sosltd(2) .lt. -soyp0m .or. &
             sosltd(2) .gt. soymic*(loypl-1)-soyp0m ) then
            write(0,*) '### ERROR: sosltd(2) is out of range', sosltd(2)
            call s3ext_abort
         end if
      end if
!.
      if( lozp0 .le. 0 ) lozp0 = lzp0
      if( sozps .le. sundef ) then
         lozps = lzps - 5
      else
         lozps = sozps * slmic + lozp0
      end if
      if( lozps .lt. 1 .or. lozps .gt. lssz ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. z start ', lozps, lzps, sozps
         lozps = 1
      end if
      if( sozpe .le. sundef ) then
         lozpe = lzpe + 5
      else
         lozpe = sozpe * slmic + lozp0
      end if
      if( lozpe .lt. 1 .or. lozpe .gt. lssz ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: obs. z end ', lozpe, lzpe, sozpe
         lozpe = lssz
      end if
#ifdef OHHELP
      if( lozpe .eq. lssz ) lozpe = lsszm1
#endif
      lozpl  = ( lozpe - lozps ) / lozpi + 1
      sozp0m = ( lozp0 - lozps ) * slmicinv
      if( lrank .le. 0 ) &
      write(6,*) '@@@ lozps, lozpe, lozpl, lozpi, lozp0, sozp0m = ', &
                 lozps, lozpe, lozpl, lozpi, lozp0, sozp0m
      do i = 1, locrsx
         if( sozcrs(i) .le. sundef ) then
            sozcrs(i) = sozmic*(lozpl-1)*s1o2-sozp0m
         else
            if( sozcrs(i) .lt. -sozp0m .or. &
                sozcrs(i) .gt. sozmic*(lozpl-1)-sozp0m ) then
               write(0,*) '### ERROR: sozcrs is out of range', &
                          i, sozcrs(i)
               call s3ext_abort
            end if
         end if
      end do
      if( sosltd(3) .le. sundef ) then
         sosltd(3) = sozmic*(lozpl-1)*s1o2-sozp0m
      else
         if( sosltd(3) .lt. -sozp0m .or. &
             sosltd(3) .gt. sozmic*(lozpl-1)-sozp0m ) then
            write(0,*) '### ERROR: sosltd(3) is out of range', sosltd(3)
            call s3ext_abort
         end if
      end if
!..
      loxyzpl = loxpl * loypl * lozpl
!...
#ifdef OHHELP
      write(6,*) '@@@ Global position (micron) =', &
                      ( oh_sdoms(1,1,lrank+1) - loxp0 ) * slmicinv, &
                      ( oh_sdoms(2,1,lrank+1) - loxp0 ) * slmicinv, &
                      ( oh_sdoms(1,2,lrank+1) - loyp0 ) * slmicinv, &
                      ( oh_sdoms(2,2,lrank+1) - loyp0 ) * slmicinv, &
                      ( oh_sdoms(1,3,lrank+1) - lozp0 ) * slmicinv, &
                      ( oh_sdoms(2,3,lrank+1) - lozp0 ) * slmicinv
!.
      oh_loxal = loxpl
      oh_loyal = loypl
      oh_lozal = lozpl
!
      if( loxps .ge. oh_sdoms(2,1,oh_sdid(1)+1) .or. &
          loxpe .lt. oh_sdoms(1,1,oh_sdid(1)+1) ) then
         oh_soxp0m = sundef
         oh_loxps  = 0
         oh_loxpe  = -1
         oh_loxpl  = -1
         oh_loxas  = 0
         oh_loxae  = -1
      else
         if( loxps .ge. oh_sdoms(1,1,oh_sdid(1)+1) ) then
            oh_loxps = loxps
         else
            itmp = ( oh_sdoms(1,1,oh_sdid(1)+1)-1 - loxps ) / loxpi
            oh_loxps = ( itmp+1 ) * loxpi + loxps
         end if
         if( loxpe .eq. oh_scoord(2,1) .and. &
             loxpe .eq. oh_sdoms(2,1,oh_sdid(1)+1) ) then
            oh_loxpe = loxpe
         else if( loxpe .le. oh_sdoms(2,1,oh_sdid(1)+1)-1 ) then
            oh_loxpe = loxpe
         else
            itmp = ( oh_sdoms(2,1,oh_sdid(1)+1)-1 - loxps ) / loxpi
            oh_loxpe = itmp * loxpi + loxps
         end if
         oh_loxas  = ( oh_loxps - loxps ) / loxpi + 1
         oh_loxae  = ( oh_loxpe - loxps ) / loxpi + 1
         oh_soxp0m = ( loxp0 - oh_loxps ) * slmicinv
         oh_loxps = oh_loxps - oh_sdoms(1,1,oh_sdid(1)+1) + 1
         oh_loxpe = oh_loxpe - oh_sdoms(1,1,oh_sdid(1)+1) + 1
         oh_loxpl  = ( oh_loxpe - oh_loxps ) / loxpi + 1
      end if
      if( loyps .ge. oh_sdoms(2,2,oh_sdid(1)+1) .or. &
          loype .lt. oh_sdoms(1,2,oh_sdid(1)+1) ) then
         oh_soyp0m = sundef
         oh_loyps  = 0
         oh_loype  = -1
         oh_loypl  = -1
         oh_loyas  = 0
         oh_loyae  = -1
      else
         if( loyps .ge. oh_sdoms(1,2,oh_sdid(1)+1) ) then
            oh_loyps = loyps
         else
            itmp = ( oh_sdoms(1,2,oh_sdid(1)+1)-1 - loyps ) / loypi
            oh_loyps = ( itmp+1 ) * loypi + loyps
         end if
         if( loype .eq. oh_scoord(2,2) .and. &
             loype .eq. oh_sdoms(2,2,oh_sdid(1)+1) ) then
            oh_loype = loype
         else if( loype .le. oh_sdoms(2,2,oh_sdid(1)+1)-1 ) then
            oh_loype = loype
         else
            itmp = ( oh_sdoms(2,2,oh_sdid(1)+1)-1 - loyps ) / loypi
            oh_loype = itmp * loypi + loyps
         end if
         oh_loyas  = ( oh_loyps - loyps ) / loypi + 1
         oh_loyae  = ( oh_loype - loyps ) / loypi + 1
         oh_soyp0m = ( loyp0 - oh_loyps ) * slmicinv
         oh_loyps = oh_loyps - oh_sdoms(1,2,oh_sdid(1)+1) + 1
         oh_loype = oh_loype - oh_sdoms(1,2,oh_sdid(1)+1) + 1
         oh_loypl  = ( oh_loype - oh_loyps ) / loypi + 1
       end if
      if( lozps .ge. oh_sdoms(2,3,oh_sdid(1)+1) .or. &
          lozpe .lt. oh_sdoms(1,3,oh_sdid(1)+1) ) then
         oh_sozp0m = sundef
         oh_lozps  = 0
         oh_lozpe  = -1
         oh_lozpl  = -1
         oh_lozas  = 0
         oh_lozae  = -1
      else
         if( lozps .ge. oh_sdoms(1,3,oh_sdid(1)+1) ) then
            oh_lozps = loyps
         else
            itmp = ( oh_sdoms(1,3,oh_sdid(1)+1)-1 - lozps ) / lozpi
            oh_lozps = ( itmp+1 ) * loypi + lozps
         end if
         if( lozpe .eq. oh_scoord(2,3) .and. &
             lozpe .eq. oh_sdoms(2,3,oh_sdid(1)+1) ) then
            oh_lozpe = lozpe
         else if( lozpe .le. oh_sdoms(2,3,oh_sdid(1)+1)-1 ) then
            oh_lozpe = lozpe
         else
            itmp = ( oh_sdoms(2,3,oh_sdid(1)+1)-1 - lozps ) / lozpi
            oh_lozpe = itmp * lozpi + lozps
         end if
         oh_lozas  = ( oh_lozps - lozps ) / lozpi + 1
         oh_lozae  = ( oh_lozpe - lozps ) / lozpi + 1
         oh_sozp0m = ( lozp0 - oh_lozps ) * slmicinv
         oh_lozps = oh_lozps - oh_sdoms(1,3,oh_sdid(1)+1) + 1
         oh_lozpe = oh_lozpe - oh_sdoms(1,3,oh_sdid(1)+1) + 1
         oh_lozpl  = ( oh_lozpe - oh_lozps ) / lozpi + 1
       end if
      if( oh_loxpl .gt. 0 .and. oh_loypl .gt. 0 .and. oh_lozpl .gt. 0) then
         oh_loxyzpl = oh_loxpl * oh_loypl * oh_lozpl
      else
         oh_loxyzpl = -1
      end if
      write(6,*) '@@@ oh_loxps, oh_loxpe, oh_loxpl, oh_soxp0m =', &
                      oh_loxps, oh_loxpe, oh_loxpl, oh_soxp0m
      write(6,*) '@@@ oh_loyps, oh_loype, oh_loypl, oh_soyp0m =', &
                      oh_loyps, oh_loype, oh_loypl, oh_soyp0m
      write(6,*) '@@@ oh_lozps, oh_lozpe, oh_lozpl, oh_sozp0m =', &
                      oh_lozps, oh_lozpe, oh_lozpl, oh_sozp0m
      write(6,*) '@@@ oh_loxyzpl =', oh_loxyzpl
      write(6,*) '@@@ oh_loxas, oh_loxae, oh_loxal =', &
                      oh_loxas, oh_loxae, oh_loxal
      write(6,*) '@@@ oh_loyas, oh_loyae, oh_loyal =', &
                      oh_loyas, oh_loyae, oh_loyal
      write(6,*) '@@@ oh_lozas, oh_lozae, oh_lozal =', &
                      oh_lozas, oh_lozae, oh_lozal
#endif
!...
      if( lclflge .le. -1 ) then
         lclflge = - lclflge
         if( lrank .le. 0 ) &
           write(6,*) '@@@ RESTART: lclflge =', lclflge
         icll = lclflge / 10
         do i = 1, icll
           if( lrank .le. 0 ) then
             write(6,*) '@@@ sclboe =', i, sclboe(:,i)
             write(6,*) '@@@ scluure, scluule, scluu0e, sclfcte =', &
                        scluure(i), scluule(i), scluu0e(i), sclfcte(i)
           end if
         end do
      else if( lclflge .ge. 1 ) then
        icll = lclflge / 10
        do i = 1, icll
          if( sclboe(1,i) .le. sundef ) then
            sclboe(1,i) = 2
          else
            sclboe(1,i) = sclboe(1,i) * slmic + loxp0
            if( sclboe(1,i) .lt. 1 .or. sclboe(1,i) .gt. lssx ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclxpse is out of range', &
                         i, sclboe(1,i)
            end if
          end if
          if( sclboe(4,i) .le. sundef ) then
            sclboe(4,i) = lssxm1
          else
            sclboe(4,i) = sclboe(4,i) * slmic + loxp0
            if( sclboe(4,i) .lt. 1 .or. sclboe(4,i) .gt. lssx ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclxpee is out of range', &
                         i, sclboe(4,i)
            end if
          end if
          if( sclboe(1,i) .ge. sclboe(4,i) ) then
            write(0,*) '### ERROR: Xe must be greater than Xs', &
                       i,sclboe(1,i),sclboe(4,i)
            call s3ext_abort
          end if
!
          if( sclboe(2,i) .le. sundef ) then
            sclboe(2,i) = 2
          else
            sclboe(2,i) = sclboe(2,i) * slmic + loyp0
            if( sclboe(2,i) .lt. 1 .or. sclboe(2,i) .gt. lssy ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclypse is out of range', &
                         i, sclboe(2,i)
            end if
          end if
          if( sclboe(5,i) .le. sundef ) then
            sclboe(5,i) = lssym1
          else
            sclboe(5,i) = sclboe(5,i) * slmic + loyp0
            if( sclboe(5,i) .lt. 1 .or. sclboe(5,i) .gt. lssy ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclypee is out of range', &
                         i, sclboe(5,i)
            end if
          end if
          if( sclboe(2,i) .ge. sclboe(5,i) ) then
            write(0,*) '### ERROR: Ye must be greater than Ys', &
                       i,sclboe(2,i),sclboe(5,i)
            call s3ext_abort
          end if
!
          if( sclboe(3,i) .le. sundef ) then
            sclboe(3,i) = 2
          else
            sclboe(3,i) = sclboe(3,i) * slmic + lozp0
            if( sclboe(3,i) .lt. 1 .or. sclboe(3,i) .gt. lssz ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclzpse is out of range', &
                         i, sclboe(3,i)
            end if
          end if
          if( sclboe(6,i) .le. sundef ) then
            sclboe(6,i) = lsszm1
          else
            sclboe(6,i) = sclboe(6,i) * slmic + lozp0
            if( sclboe(6,i) .lt. 1 .or. sclboe(6,i) .gt. lssz ) then
              if( lrank .le. 0 ) &
                write(0,*) '### WARNING: sclzpee is out of range', &
                         i, sclboe(6,i)
            end if
          end if
          if( sclboe(3,i) .ge. sclboe(6,i) ) then
            write(0,*) '### ERROR: Ze must be greater than Zs', &
                       i,sclboe(3,i),sclboe(6,i)
            call s3ext_abort
          end if
!
          if( lrank .le. 0 ) then
            write(6,*) '@@@ sclboe =', i, sclboe(:,i)
            write(6,*) '@@@ scluure, scluule, scluu0e, sclfcte =', &
                      scluure(i), scluule(i), scluu0e(i), sclfcte(i)
          end if
        end do
#ifdef OHHELP
        do ips = 1, 2
#endif
        do i = lnoes, lnoee
          lclfle(i) = 0
        end do
#ifdef OHHELP
        end do
#endif
      end if
!...
      if( lclflgia .le. -1 ) then
         lclflgia = - lclflgia
         do io = 1, lionspl
            if( lrank .le. 0 ) &
              write(6,*) '@@@ RESTART: lclflgi =', io, lclflgi(io)
            icll = lclflgi(io) / 10
            do i = 1, icll
              if( lrank .le. 0 ) then
                write(6,*) '@@@ sclboi =', i, io, sclboi(:,i,io)
                write(6,*) '@@@ scluuri, scluuli, scluu0i, sclfcti =', &
              scluuri(i,io), scluuli(i,io), scluu0i(i,io), sclfcti(i,io)
              end if
            end do
         end do
      else
        do io = 1, lionspl
          lclflgia = lclflgia + lclflgi(io)
        end do
        if( lclflgia .ge. 1 ) then
          do io = 1, lionspl
            if( lclflgi(io) .ge. 1 ) then
              icll = lclflgi(io) / 10
              do i = 1, icll
                if( sclboi(1,i,io) .le. sundef ) then
                  sclboi(1,i,io) = 2
                else
                  sclboi(1,i,io) = sclboi(1,i,io) * slmic + loxp0
                  if( sclboi(1,i,io) .lt. 1 .or. &
                      sclboi(1,i,io) .gt. lssx ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclxpsi is out of range', &
                              i, io, sclboi(1,i,io)
                  end if
                end if
                if( sclboi(4,i,io) .le. sundef ) then
                  sclboi(4,i,io) = lssxm1
                else
                  sclboi(4,i,io) = sclboi(4,i,io) * slmic + loxp0
                  if( sclboi(4,i,io) .lt. 1 .or. &
                      sclboi(4,i,io) .gt. lssx ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclxpei is out of range', &
                              i, io, sclboi(4,i,io)
                  end if
                end if
                if( sclboi(1,i,io) .ge. sclboi(4,i,io) ) then
                  write(0,*) '### ERROR: Xe must be greater than Xs', &
                             i, io, sclboi(1,i,io),sclboi(4,i,io)
                  call s3ext_abort
                end if
!
                if( sclboi(2,i,io) .le. sundef ) then
                  sclboi(2,i,io) = 2
                else
                  sclboi(2,i,io) = sclboi(2,i,io) * slmic + loyp0
                  if( sclboi(2,i,io) .lt. 1 .or. &
                      sclboi(2,i,io) .gt. lssy ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclypsi is out of range', &
                              i, io, sclboi(2,i,io)
                  end if
                end if
                if( sclboi(5,i,io) .le. sundef ) then
                  sclboi(5,i,io) = lssym1
                else
                  sclboi(5,i,io) = sclboi(5,i,io) * slmic + loyp0
                  if( sclboi(5,i,io) .lt. 1 .or. &
                      sclboi(5,i,io) .gt. lssy ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclypei is out of range', &
                              i, io, sclboi(5,i,io)
                  end if
                end if
                if( sclboi(2,i,io) .ge. sclboi(5,i,io) ) then
                  write(0,*) '### ERROR: Ye must be greater than Ys', &
                            i, io, sclboi(2,i,io),sclboi(5,i,io)
                  call s3ext_abort
                end if
!
                if( sclboi(3,i,io) .le. sundef ) then
                  sclboi(3,i,io) = 2
                else
                  sclboi(3,i,io) = sclboi(3,i,io) * slmic + lozp0
                  if( sclboi(3,i,io) .lt. 1 .or. &
                      sclboi(3,i,io) .gt. lssz ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclzpsi is out of range', &
                              i, io, sclboi(3,i,io)
                  end if
                end if
                if( sclboi(6,i,io) .le. sundef ) then
                  sclboi(6,i,io) = lsszm1
                else
                  sclboi(6,i,io) = sclboi(6,i,io) * slmic + lozp0
                  if( sclboi(6,i,io) .lt. 1 .or. &
                      sclboi(6,i,io) .gt. lssz ) then
                    if( lrank .le. 0 ) &
                    write(0,*) '### WARNING: sclzpei is out of range', &
                              i, io, sclboi(6,i,io)
                  end if
                end if
                if( sclboi(3,i,io) .ge. sclboi(6,i,io) ) then
                  write(0,*) '### ERROR: Ze must be greater than Zs', &
                            i, io, sclboi(3,i,io),sclboi(6,i,io)
                  call s3ext_abort
                end if
!
                if( lrank .le. 0 ) then
                 write(6,*) '@@@ sclboi =', i, io, sclboi(:,i,io)
                 write(6,*) '@@@ scluuri, scluuli, scluu0i, sclfcti =',&
              scluuri(i,io), scluuli(i,io), scluu0i(i,io), sclfcti(i,io)
                end if
              end do
#ifdef OHHELP
              do ips = 1, 2
#endif
              do i = lionids(io), lionide(io)
                lclfli(i) = 0
              end do
#ifdef OHHELP
              end do
#endif
            end if
          end do
        end if
      end if
!...
      ilx = lopfeed / 10
      do i = 1, ilx
         select case( lopfeedty(i) )
         case( 1 )
           iohp0 = loxp0
           iovp0 = loyp0
           iohps = loxps
           iovps = loyps
           iohpe = loxpe
           iovpe = loype
           iopp0 = lozp0
           issh = lssx
           issv = lssy
           issp = lssz
         case( 2 )
           iohp0 = loyp0
           iovp0 = lozp0
           iohps = loyps
           iovps = lozps
           iohpe = loype
           iovpe = lozpe
           iopp0 = loxp0
           issh = lssy
           issv = lssz
           issp = lssx
         case( 3 )
           iohp0 = loxp0
           iovp0 = lozp0
           iohps = loxps
           iovps = lozps
           iohpe = loxpe
           iovpe = lozpe
           iopp0 = loyp0
           issh = lssx
           issv = lssz
           issp = lssy
         case default
           write(0,*) '### ERROR: invalid lopfeedty', i, lopfeedty(i)
           call s3ext_abort
         end select
         if( sopfeedpo(1,i) .le. sundef )then
           sopfeedpo(1,i) = iohps
         else
           sopfeedpo(1,i) = sopfeedpo(1,i) * slmic + iohp0
         end if
         if( sopfeedpo(2,i) .le. sundef )then
           sopfeedpo(2,i) = iovps
         else
           sopfeedpo(2,i) = sopfeedpo(2,i) * slmic + iovp0
         end if
         if( sopfeedpo(3,i) .le. sundef )then
           sopfeedpo(3,i) = iohpe
         else
           sopfeedpo(3,i) = sopfeedpo(3,i) * slmic + iohp0
         end if
         if( sopfeedpo(4,i) .le. sundef )then
           sopfeedpo(4,i) = iovpe
         else
           sopfeedpo(4,i) = sopfeedpo(4,i) * slmic + iovp0
         end if
         if( sopfeedpo(5,i) .le. sundef )then
           sopfeedpo(5,i) = iopp0
         else
           sopfeedpo(5,i) = sopfeedpo(5,i) * slmic + iopp0
         end if
!.
         if( sopfeedpo(5,i) .lt. 1 .or. sopfeedpo(5,i) .gt. issp ) then
           write(0,*) '### ERROR: sopfeedpo(5) is out of range', &
                     i, lopfeedty(i), sopfeedpo(5,i)
           call s3ext_abort
         end if
         if( sopfeedpo(1,i) .ge. sopfeedpo(3,i) ) then
           write(0,*) '### ERROR: He must be greater than Hs', &
                     i, lopfeedty(i), sopfeedpo(1,i), sopfeedpo(3,i)
           call s3ext_abort
         end if
         if( sopfeedpo(2,i) .ge. sopfeedpo(4,i) ) then
           write(0,*) '### ERROR: Ve must be greater than Vs', &
                     i, lopfeedty(i), sopfeedpo(2,i), sopfeedpo(4,i)
           call s3ext_abort
         end if
         if( sopfeedpo(1,i) .lt. 1 .or. sopfeedpo(1,i) .gt. issh ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfeedpo(1) is out of range', &
                     i, lopfeedty(i), sopfeedpo(1,i)
         end if
         if( sopfeedpo(2,i) .lt. 1 .or. sopfeedpo(2,i) .gt. issv ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfeedpo(2) is out of range', &
                     i, lopfeedty(i), sopfeedpo(2,i)
         end if
         if( sopfeedpo(3,i) .lt. 1 .or. sopfeedpo(3,i) .gt. issh ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfeedpo(3) is out of range', &
                     i, lopfeedty(i), sopfeedpo(3,i)
         end if
         if( sopfeedpo(4,i) .lt. 1 .or. sopfeedpo(4,i) .gt. issv ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfeedpo(4) is out of range', &
                     i, lopfeedty(i), sopfeedpo(4,i)
         end if
      end do
!...
      ilx = lopfied / 10
      do i = 1, ilx
         select case( lopfiedty(i) )
         case( 1 )
           iohp0 = loxp0
           iovp0 = loyp0
           iohps = loxps
           iovps = loyps
           iohpe = loxpe
           iovpe = loype
           iopp0 = lozp0
           issh = lssx
           issv = lssy
           issp = lssz
         case( 2 )
           iohp0 = loyp0
           iovp0 = lozp0
           iohps = loyps
           iovps = lozps
           iohpe = loype
           iovpe = lozpe
           iopp0 = loxp0
           issh = lssy
           issv = lssz
           issp = lssx
         case( 3 )
           iohp0 = loxp0
           iovp0 = lozp0
           iohps = loxps
           iovps = lozps
           iohpe = loxpe
           iovpe = lozpe
           iopp0 = loyp0
           issh = lssx
           issv = lssz
           issp = lssy
         case default
           write(0,*) '### ERROR: invalid lopfiedty', i, lopfiedty(i)
           call s3ext_abort
         end select
         if( sopfiedpo(1,i) .le. sundef )then
           sopfiedpo(1,i) = iohps
         else
           sopfiedpo(1,i) = sopfiedpo(1,i) * slmic + iohp0
         end if
         if( sopfiedpo(2,i) .le. sundef )then
           sopfiedpo(2,i) = iovps
         else
           sopfiedpo(2,i) = sopfiedpo(2,i) * slmic + iovp0
         end if
         if( sopfiedpo(3,i) .le. sundef )then
           sopfiedpo(3,i) = iohpe
         else
           sopfiedpo(3,i) = sopfiedpo(3,i) * slmic + iohp0
         end if
         if( sopfiedpo(4,i) .le. sundef )then
           sopfiedpo(4,i) = iovpe
         else
           sopfiedpo(4,i) = sopfiedpo(4,i) * slmic + iovp0
         end if
         if( sopfiedpo(5,i) .le. sundef )then
           sopfiedpo(5,i) = iopp0
         else
           sopfiedpo(5,i) = sopfiedpo(5,i) * slmic + iopp0
         end if
!.
         if( sopfiedpo(5,i) .lt. 1 .or. sopfiedpo(5,i) .gt. issp ) then
           write(0,*) '### ERROR: sopfiedpo(5) is out of range', &
                     i, lopfiedty(i), sopfiedpo(5,i)
           call s3ext_abort
         end if
         if( sopfiedpo(1,i) .ge. sopfiedpo(3,i) ) then
           write(0,*) '### ERROR: He must be greater than Hs', &
                     i, lopfiedty(i), sopfiedpo(1,i), sopfiedpo(3,i)
           call s3ext_abort
         end if
         if( sopfiedpo(2,i) .ge. sopfiedpo(4,i) ) then
           write(0,*) '### ERROR: Ve must be greater than Vs', &
                     i, lopfiedty(i), sopfiedpo(2,i), sopfiedpo(4,i)
           call s3ext_abort
         end if
         if( sopfiedpo(1,i) .lt. 1 .or. sopfiedpo(1,i) .gt. issh ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfiedpo(1) is out of range', &
                     i, lopfiedty(i), sopfiedpo(1,i)
         end if
         if( sopfiedpo(2,i) .lt. 1 .or. sopfiedpo(2,i) .gt. issv ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfiedpo(2) is out of range', &
                     i, lopfiedty(i), sopfiedpo(2,i)
         end if
         if( sopfiedpo(3,i) .lt. 1 .or. sopfiedpo(3,i) .gt. issh ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfiedpo(3) is out of range', &
                     i, lopfiedty(i), sopfiedpo(3,i)
         end if
         if( sopfiedpo(4,i) .lt. 1 .or. sopfiedpo(4,i) .gt. issv ) then
           if( lrank .le. 0 ) &
           write(0,*) '### WARNING: sopfiedpo(4) is out of range', &
                     i, lopfiedty(i), sopfiedpo(4,i)
         end if
      end do
!...  
      if( lagfl .gt. lagfx ) then
         write(0,*) '### ERROR: lagfl overflow :', lagfl, lagfx
         call s3ext_abort
      end if  
      if( lavpl .gt. lavpx ) then
         write(0,*) '### ERROR: lavpl overflow :', lavpl, lavpx
         call s3ext_abort
      end if  
      if( labol .gt. labox ) then
         write(0,*) '### ERROR: labol overflow :', labol, labox
         call s3ext_abort
      end if  
!..
      if( lagfl .ge. 1 ) then
         do i = 1, labol
            if( saboxm(i) .le. sundef ) then
               saboxm(i) = ( loxps - loxp0 ) * slmicinv
            end if  
            sawnxm(i) = saboxm(i) * slmic + loxp0 
            if( saboxx(i) .le. sundef ) then
               saboxx(i) = ( loxpe - loxp0 ) * slmicinv
            end if  
            sawnxx(i) = saboxx(i) * slmic + loxp0 
            sawnx0(i) = loxp0 
            if( saboym(i) .le. sundef ) then
               saboym(i) = ( loyps - loyp0 ) * slmicinv
            end if  
            sawnym(i) = saboym(i) * slmic + loyp0 
            if( saboyx(i) .le. sundef ) then
               saboyx(i) = ( loype - loyp0 ) * slmicinv
            end if
            sawnyx(i) = saboyx(i) * slmic + loyp0 
            sawny0(i) = loyp0 
            if( sabozm(i) .le. sundef ) then
               sabozm(i) = ( lozps - lozp0 ) * slmicinv
            end if
            sawnzm(i) = sabozm(i) * slmic + lozp0 
            if( sabozx(i) .le. sundef ) then
               sabozx(i) = ( lozpe - lozp0 ) * slmicinv
            end if
            sawnzx(i) = sabozx(i) * slmic + lozp0 
            sawnz0(i) = lozp0 
!
            if( lrank .le. 0 ) &
            write(6,*) '@@@ sabo[xyz][mx] = ', i, saboxm(i),saboxx(i), &
                       saboym(i), saboyx(i), sabozm(i), sabozx(i)
         end do
      end if
!....
      if( loeng .ge. 1 ) call o3eng ( 0 )
      if( lopee .ge. 1 ) call o3pee ( 0 )
      if( lopie .ge. 1 ) call o3pie ( 0 )
      if( lopem .ge. 1 ) call o3pem ( 0 )
      if( lopim .ge. 1 ) call o3pim ( 0 )
      if( lofde .ge. 1 ) call o3fde ( 0 )
      if( lofdi .ge. 1 ) call o3fdi ( 0 )
      if( lofdc .ge. 1 ) call o3fdc ( 0 )
      if( lofea .ge. 1 ) call o3fea ( 0 )
      if( lofer .ge. 1 ) call o3fer ( 0 )
      if( lofba .ge. 1 ) call o3fba ( 0 )
      if( lofbr .ge. 1 ) call o3fbr ( 0 )
      if( lofje .ge. 1 ) call o3fje ( 0 )
      if( lofji .ge. 1 ) call o3fji ( 0 )
      if( lofjt .ge. 1 ) call o3fjt ( 0 )
      if( lofte .ge. 1 ) call o3fte ( 0 )
      if( lofede .ge. 1 ) call o3fede ( 0 )
      if( lopfeed .ge. 1 ) call o3pfeed ( 0 )
      if( lofek .ge. 1 ) call o3fek ( 0 )
      if( lofew .ge. 1 ) call o3few ( 0 )
      if( lofedi .ge. 1 ) call o3fedi ( 0 )
      if( lopfied .ge. 1 ) call o3pfied ( 0 )
      if( lopeph .ge. 1 ) call o3peph ( 0 )
!....
      call fdebug ( 's3init', 1 )
!....
      return
      end
