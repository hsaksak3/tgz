!----------------------------------------------------------------------
! plot pidfp data (3D)
!
! file: FISCOF3_TIMEPARAM_FILE (default: ./time.param)
!       1: wtimen, wtimex
! wtimen : min time [fs] when the process is started.
! wtimex : max time [fs] when the process is stopped.
!
! coded by Sakagami,H. 12/06/06
! modified by Sakagami, H. 12/11/01 for time.param file
! modified by Sakagami, H. 14/05/19 for ENV and wtimen
! modified by Sakagami, H. 15/11/18 for equal division,
!             distribution correction, norm. in OMEGA with new ENV var.
! modified by Sakagami, H. 18/06/19 for multi locations
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: lisx = 8, ltx = 500, its = 6, itd = 1
      integer :: irx, irxp1, imx, imxp1, imxh, inx, inxp1, ihx, ihxx, ivx, ivxx, &
                 iis, ilsrty, i, ic,ir, im, in, ih, iv, it, itx, itn, &
                 il, ilx, id1, id2, id3, id4, id5, icol, icolc, icold, &
                 icidl, isned, iaxi, imxhh
      real*8 :: wintt, wotint, woaxip, wohps, wohpe, wovps, wovpe, wnepm1, &
                wmasr, wlramm, wlram, wgrid, wlpwr, &
                wnc, weight, wohwid, wovwid, wcoefn, wcoefw, wcoefj, &
                wp, wgam, wth, womg, wdomg, wdomg2, wtot, wnum, &
                wintmn, wintmx, whps, whpe, wvps, wvpe, wtimen, wtimex, &
                wtime(ltx), wtotal(ltx,lisx), wsum(ltx,lisx), &
                wetot(ltx,lisx), wetots(ltx,lisx), &
                wnumtot(ltx,lisx), wnumtots(ltx,lisx)
      real*8, dimension(lisx) :: wrang, waz, wam, wnpnc
      real*8, allocatable :: &
              weng(:,:), wengb(:,:), wvc(:,:), wmue(:), &
              wint(:,:,:,:), wflue(:,:,:,:), &
              wpidrmy(:,:,:,:,:), wdisrmy(:,:,:,:,:), wdisrny(:,:,:,:,:), &
              wpidrmyt(:,:,:,:,:), wdisrmyt(:,:,:,:,:), wdisrnyt(:,:,:,:,:), &
              wspec(:,:,:,:,:), wspecta(:,:,:,:), wspecti(:,:,:,:), &
              whwhm(:,:,:,:), whwhmt(:,:,:,:,:), work(:,:), &
              wxrm(:,:,:), wyrm(:,:,:), wxrn(:,:,:), wyrn(:,:,:), &
              wxea(:,:,:), wyea(:,:), wxhwhm(:,:), wyhwhm(:,:), &
              wang(:), wadis(:,:), waidis(:,:), wadisx(:,:), &
              wxadis(:,:), wyadis(:,:), wadist(:,:,:)
      character cbuff*80, cdum*3, cident*18, clabel*20, cfile*128, &
                crange*16, chpos*7, cvpos*7, caxi*12
!
! physical constant [MKSA], smevj:MeV->J
      real*8, parameter :: sme  = 9.1093897d-31, &
                           sc   = 2.99792458d08, &
                           smec = sme * sc, &
                           smecc= smec * sc, &
                           spi  = 3.1415926535897931d0, &
                           se   = 1.602176462d-19, &
                           seps0= 8.854187817d-12, &
                           smevj= 1.602176462d-13
! contour color
      real*8, parameter :: sh(4) = (/240.0d0, 240.0d0, 0.0d0, 0.0d0/), &
                           sl(4) = (/0.25d0, 0.5d0, 0.5d0, 0.9d0/), &
                           ss(4) = (/1.0d0, 1.0d0, 1.0d0, 1.0d0/)
      integer, parameter :: ndiv(3) = (/20, 90, 20/)
!....                                          * read time.param file *
      wtimen = -9.9d0
      wtimex = 9999999.9d0
      call getenv ( 'FISCOF3_TIMEPARAM_FILE', cfile ) 
      if( cfile(1:1) .ne. ' ' ) then
         open( 7,file=cfile,form='FORMATTED',status='OLD',err=999 )
      else
         open( 7,file='./time.param',form='FORMATTED',status='OLD',&
               err=9 ) 
      end if
      read( 7, * ) wtimen, wtimex
      close( 7 )
    9 continue
!..
      !i2d3d = 3
      !call getenv ( 'FISCOF3_NORMALIZE_OMEGA', cbuff )
      !if( cbuff(1:1) .eq. '3' ) i2d3d = 3
!....                                                  * read headers *
! ------ start 1/2 -------
! ident character             = v2r23        
! Equal Division              =      32 
! # of mesh for omega         =      16      
! # of mesh for momentum      =      50      
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of z   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for xy         =      1    2
!  or
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! observation position of zs  =      -1.500 [micron]
! observation position of ze  =       1.500 [micron]
! # of division for yz         =      1    2
!  or
! observation position of y   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! observation position of zs  =      -1.500 [micron]
! observation position of ze  =       1.500 [micron]
! # of division for xz         =      1    2
! # of particle/mesh at nc    =      10.000  
! mass ratio                  =    1836.000
! number of ion species       =       2       
! range(1)                    =       5.000   
! average Z(1)                =      30.000  
! average weight number(1)    =      60.000  
! density at center(1)        =       0.000   
! range(2)                    =       5.000   
! average Z(2)                =       1.000   
! average weight number(2)    =       1.000   
! density at center(2)        =       0.000   
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      71.017  
! Debye length/mesh size      =       0.500   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     111     
! laser pulse parameters      =       1.000   1000.000      0.000
      read(*,1100) cbuff(1:16)
      if( cbuff(14:14) .eq. '-' ) then
         ilx = 1
      else    
         read( cbuff(14:16), '(i1,a1,i1)' ) il, cdum(1:1), ilx
      end if  
      read(*,1000) cbuff(1:27), cdum, cident(1:16)
      cident(17:18) = ' '
      read(*,1001) cbuff(1:27), cdum, imx
      read(*,1001) cbuff(1:27), cdum, inx
      read(*,1001) cbuff(1:27), cdum, irx
      read(*,1002) cbuff(1:27), cdum, wintt
      read(*,1002) cbuff(1:27), cdum, wotint
      
      read(*,1002) cbuff(1:27), cdum, woaxip
      if( cbuff(25:25) .eq. 'z' ) then
         iaxi = 1
      else if( cbuff(25:25) .eq. 'x' ) then
         iaxi = 2
      else if( cbuff(25:25) .eq. 'y' ) then
         iaxi = 3
      else
         write(0,*) '### ERROR: position is not x, y or z', cbuff(25:25)
         stop
      end if
      read(*,1002) cbuff(1:27), cdum, wohps!horizontal
      read(*,1002) cbuff(1:27), cdum, wohpe
      read(*,1002) cbuff(1:27), cdum, wovps!vertical
      read(*,1002) cbuff(1:27), cdum, wovpe
      read(*,1001) cbuff(1:27), cdum, ihx,ivx
      
      read(*,1002) cbuff(1:27), cdum, wnepm1
      read(*,1002) cbuff(1:27), cdum, wmasr
      read(*,1001) cbuff(1:27), cdum, iis
      do i = 1, iis
         read(*,1003) cbuff(1:27), cdum, wrang(i)
         read(*,1002) cbuff(1:27), cdum, waz(i)
         read(*,1002) cbuff(1:27), cdum, wam(i)
         read(*,1002) cbuff(1:27), cdum, wnpnc(i)
      end do
      read(*,1002) cbuff(1:27), cdum, wlramm
      read(*,1002) cbuff(1:27), cdum, wlram
      read(*,1002) cbuff(1:27), cdum, wgrid
      read(*,1003) cbuff(1:27), cdum, wlpwr
      read(*,1001) cbuff(1:27), cdum, ilsrty
 1100 format(a16)
 1000 format(a27,a3,a16)
 1001 format(a27,a3,2i7)
 1002 format(a27,a3,f11.3)
 1003 format(a27,a3,e11.4)
      wnc    = (spi*2.d0*sc/(wlramm*1.d-6))**2 * seps0 * sme / (se**2)
      wintt  = wintt * 1.d-15
      wotint  = wotint * 1.d-15
      weight = wnc * (wlramm*1.d-6/wlram)/wnepm1
      wohwid = abs( wohpe - wohps ) / wlramm * wlram / ihx     
      wovwid = abs( wovpe - wovps ) / wlramm * wlram / ivx
      wcoefn = weight / wintt / wohwid / wovwid
      wcoefw = wcoefn*smevj
      wcoefj = wcoefw*wotint / ihx / ivx * 1.0d-12
      write(0,*) 'ident   = ', cident
      write(0,*) 'irx     = ', irx
      write(0,*) 'EqD imx = ', imx
      write(0,*) 'inx     = ', inx
      write(0,*) 'ih   = ', ihx!para
      write(0,*) 'iv   = ', ivx!perp
      write(0,*) 'nc #/m3 = ', wnc
      write(0,*) 'weigh   = ', weight
      write(0,*) 'integ-t = ', wintt, ' sec'
      if( iaxi .eq. 1 ) then
         write(0,*) 'obs. Zp = ', woaxip, ' micron'
         write(0,*) 'obs. Xp = ', wohps, '~', wohpe, ' micron'
         write(0,*) 'obs. Yp = ', wovps, '~', wovpe, ' micron'
      else if( iaxi .eq. 2 ) then
         write(0,*) 'obs. Xp = ', woaxip, ' micron'
         write(0,*) 'obs. Yp = ', wohps, '~', wohpe, ' micron'
         write(0,*) 'obs. Zp = ', wovps, '~', wovpe, ' micron'
      else if( iaxi .eq. 3 ) then
         write(0,*) 'obs. Yp = ', woaxip, ' micron'
         write(0,*) 'obs. Xp = ', wohps, '~', wohpe, ' micron'
         write(0,*) 'obs. Zp = ', wovps, '~', wovpe, ' micron'
      end if
      write(0,*) 'Omga NM = 3D'
      write(0,*) 'mass r. = ', wmasr
      write(0,*) '# ion   = ', iis
      do i = 1, iis
         write(0,*) 'delta-p = ', i, wrang(i), ' *mec'
         write(0,*) 'ave. m  = ', i, wam(i)
! set position characters
      write( crange, '(f5.1)' ) woaxip
      caxi(8:12) = adjustl( crange )
      if( iaxi .eq. 1 ) then
         caxi(1:7)  = 'Z pos.:'
         chpos(1:7) = 'X pos.:'!para
         cvpos(1:7) = 'Y pos.:'!perp
      else if( iaxi .eq. 2 ) then
         caxi(1:7)  = 'X pos.:'
         chpos(1:7) = 'Y pos.:'
         cvpos(1:7) = 'Z pos.:'
      else if( iaxi .eq. 3 ) then
         caxi(1:7)  = 'Y pos.:'
         chpos(1:7) = 'X pos.:'
         cvpos(1:7) = 'Z pos.:'
      end if
      end do
! initialize scalar
      irxp1 = irx + 1
      imxp1 = imx + 1
      imxh  = imx / 2
      imxhh = mod( imx, 2 )
      inxp1 = inx + 1
!  allocate array
      allocate ( &
         weng(irx,iis),wvc(irx,iis),wengb(irxp1,iis),wmue(imxp1), &
         wint(ltx,0:ihx,0:ivx,iis), wflue(ltx,0:ihx,0:ivx,iis), &
         wdisrmy(irxp1,imxp1,0:ihx,0:ivx,iis), &
         wpidrmy(irxp1,imxp1,0:ihx,0:ivx,iis), &
         wdisrny(irxp1,inxp1,0:ihx,0:ivx,iis), &
         wdisrmyt(irxp1,imxp1,0:ihx,0:ivx,iis), &
         wpidrmyt(irxp1,imxp1,0:ihx,0:ivx,iis), &
         wdisrnyt(irxp1,inxp1,0:ihx,0:ivx,iis), &
         wspec(irx,ltx,0:ihx,0:ivx,iis), &
         wspecta(irx,0:ihx,0:ivx,iis), wspecti(irx,0:ihx,0:ivx,iis), &
         whwhm(irx,0:ihx,0:ivx,iis), whwhmt(ltx,irx,0:ihx,0:ivx,iis), &
         work(imxh,2), &
         wxrm(irxp1,imxp1,iis), wyrm(irxp1,imxp1,iis), &
         wxrn(irxp1,inxp1,iis), wyrn(irxp1,inxp1,iis), &
         wxea(irxp1,imxp1,iis), wyea(irxp1,imxp1), &
         wang(imxh), wadis(imxh,iis), waidis(imxh,iis), &
         wadisx(ltx,iis), wadist(ltx,imxh,iis) )
! initialize
         wdomg2 = spi / ( (imx-2)*2 + 2 )
         wdomg  = wdomg2 * 2.0d0
         wmue(1) = -1.0d0
         do im = 2, imx
            wmue(im) = cos( spi - wdomg2 - wdomg * (im-2) )
         end do
         wmue(imxp1) = 1.0d0
! initialize array
      do i = 1, iis
         do ir = 1, irx
            wp   = ( dble(ir)-0.5d0 ) * wrang(i)
            wgam = sqrt( 1.d0 + wp**2 )
            weng(ir,i) = wmasr*wam(i)*smecc * ( wgam-1.d0 ) / smevj
            wvc(ir,i) = sqrt( 1.0d0 - 1.0d0 / ( 1.0d0 + wp**2 ) )
         end do
         do ir = 1, irxp1
            wp   = dble(ir-1) * wrang(i)
            wgam = sqrt( 1.d0 + wp**2 )
            wengb(ir,i) = wmasr*wam(i)*smecc * ( wgam - 1.d0 ) / smevj
         end do
      end do
      do im = 1, imxp1
         wth= acos(wmue(im))
         do ir = 1,irxp1
            do i = 1, iis
               wxrm(ir,im,i) = (ir-1)*wrang(i)*cos(wth) * wmasr*wam(i)
               wyrm(ir,im,i) = (ir-1)*wrang(i)*sin(wth) * wmasr*wam(i)
               wxea(ir,im,i) = wengb(ir,i)
            end do
            wyea(ir,im) = wth / spi * 180.d0
         end do
      end do
      
      wdomg  = spi*2.0d0 / inx
      wdomg2 = wdomg / 2.0d0
      do in = 1, inxp1
         womg= wdomg * (in-1) - wdomg2
         do ir = 1, irxp1
            do i = 1, iis
               wxrn(ir,in,i) = (ir-1)*wrang(i)*cos(womg) * wmasr*wam(i)
               wyrn(ir,in,i) = (ir-1)*wrang(i)*sin(womg) * wmasr*wam(i)
            end do
         end do
      end do
      do im = 1, imxh
         wang(imxh-im+1) = ( acos(wmue(imxh+im+imxhh)) + &
           acos(wmue(imxh+im+1+imxhh)) )/2.0d0 / acos( -1.0d0 ) * 180.d0
      end do
! zero setting
      itx = 0
      do i = 1, iis
         do it = 1, ltx
            wsum(it,i)  = 0.d0
         end do
         do iv = 0, ivx
         do ih = 0, ihx
            do it = 1, ltx
               wint(it,ih,iv,i)  = 0.d0
               wflue(it,ih,iv,i)  = 0.d0
            end do
         end do
         end do
         do iv = 0, ivx
         do ih = 0, ihx
            do ir = 1, irx
               wspecta(ir,ih,iv,i) = 0.d0
               wspecti(ir,ih,iv,i) = 0.d0
               do it = 1, ltx
                  wspec(ir,it,ih,iv,i) = 0.d0
               end do
            end do
         end do
         end do
         do it = 1, ltx
            wetot(it,i) = 0.d0
            wetots(it,i) = 0.d0
            wnumtot(it,i) = 0.d0
            wnumtots(it,i) = 0.d0
         end do
         do iv = 0, ivx
         do ih = 0, ihx
           do im = 1, imx
             do ir = 1, irx
               wpidrmy(ir,im,ih,iv,i) = 0.0d0
               wpidrmyt(ir,im,ih,iv,i) = 0.0d0
               wdisrmy(ir,im,ih,iv,i) = 0.0d0
               wdisrmyt(ir,im,ih,iv,i) = 0.0d0
             end do
           end do
         end do
         end do
         do iv = 0, ivx
         do ih = 0, ihx
           do in = 1, inx
             do ir = 1, irx
               wdisrny(ir,in,ih,iv,i) = 0.0d0
               wdisrnyt(ir,in,ih,iv,i) = 0.0d0
             end do
           end do
         end do
         end do
      end do
!....
      call fr_ginit
!.
      call fr_hlsset ( sh, sl, ss, ndiv, 3 )
!..
      icidl = index( cident//' ', ' ' ) - 1
      if( ilx .gt. 1 ) then
         cident(icidl+1:icidl+1) = '-'
         write( cident(icidl+2:icidl+2), '(i1)' ) il
         icidl = icidl + 2
      end if
      call fr_opencanvas( 1, 'pfied3plot1-'//cident(1:icidl), 10 )
      call fr_opencanvas( 2, 'pfied3plot2-'//cident(1:icidl), 10 )
      call fr_opencanvas( 3, 'pfied3plot3-'//cident(1:icidl), 10 )
      call fr_opencanvas( 4, 'pfied3plot4-'//cident(1:icidl), 10 )
!
! >>> Reading Main part of PIC data <<<-----------------------------
!
    1 continue
!                                              * skip until separator *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:20) .ne. '--------------------') go to 1
!                                            * next must be 'time = ' *
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:8) .ne. ' time = ') then
         write(0,*) '### ERROR: not time = ', cbuff
         stop
      end if
      itx = itx + 1
!$$$
      if( itx .gt. ltx ) then
         write(0,*) '### ERROR : itx .gt. ltx', itx, ltx
         stop
      end if
!$$$
      read( cbuff(9:20), '(f12.3)' ) wtime(itx)
      write(0,*) 'itx,time = ', itx, wtime(itx)
!.                       * check second data file and skip first data *
      if( itx .gt. 1 ) then
         if( abs( wtime(itx) - wtime(itx-1) ) .lt. 1.0d-3 ) then
            itx = itx - 1
            go to 1
         end if
      end if
!.                                                * skip until wtimen *
      if( abs(wtime(itx)-wtimen) .ge. 1.0d0 .and. &
             (wtime(itx)-wtimen) .lt. 0.0d0 ) then
         write(0,*) 'process was skipped by time param.', wtimen
         itx = itx - 1
         go to 1
      end if
!
      i = 1
!                                             * read until 'total = ' *
    2 continue
      read(*, '(a80)', end=90 ) cbuff
      if( cbuff(1:6) .eq. 'total(' ) then
         read( cbuff(7:7), '(i1)' ) id1
         if( id1 .ne. i ) then
            write(0,*) '### ERROR: # ion  = ', i, id1
         end if
         read( cbuff(12:23), '(f12.3)' ) wtotal(itx,i)
         write(0,*) 'total, sum = ', i, wtotal(itx,i), wsum(itx,i)
!...         
         call rmynrm( wdisrmy(1,1,0,0,i), wmue, irxp1, imxp1, ihx,ivx, 2 )
!.
         call rmynrm( wpidrmy(1,1,0,0,i), wmue, irxp1, imxp1, ihx,ivx, 2 )
!
         call adistcalc( wpidrmy(1,1,0,0,i), irxp1, imxp1, ihx, ivx, 2, &
                         wadis(1,i), waidis(1,i), imxh, wadisx(itx,i) )
         do im = 1, imxh
            wadist(itx,im,i) = wadis(im,i)
         end do
!
         call hwhmcalc( wpidrmy(1,1,0,0,i), wmue, whwhm(1,0,0,i), &
                        work, irxp1, imxp1, ihx, ivx, imxh )
         do iv = 0, ivx
         do ih = 0, ihx
           do ir = 1, irx
              whwhmt(itx,ir,ih,iv,i) = whwhm(ir,ih,iv,i)
           end do
         end do
         end do
!
         do iv = 0, ivx
         do ih = 0, ihx
           do im = 1, imx
             do ir = 1, irx
               wdisrmy(ir,im,ih,iv,i) = log10( wdisrmy(ir,im,ih,iv,i)+1.0d0 )
               wpidrmy(ir,im,ih,iv,i) = log10( wpidrmy(ir,im,ih,iv,i)+1.0d0 )
             end do
           end do
         end do
         end do
!.
         call rnynrm( wdisrny(1,1,0,0,i), irxp1, inxp1, ihx, ivx, 2 )
         do iv = 0, ivx
         do ih = 0, ihx
           do in = 1, inx
             do ir = 1, irx
               wdisrny(ir,in,ih,iv,i) = log10( wdisrny(ir,in,ih,iv,i)+1.0d0 )
             end do
           end do
         end do
         end do
!...
         call fr_canvas ( 1 )
!
         call ionlabel ( i, wam(i), waz(i), clabel )
         call rmycont( wdisrmy(1,1,0,0,i), wxrm(1,1,i), wyrm(1,1,i), &
                     irxp1, imxp1, ihx, ivx, wtime(itx), wohps, wohpe, wovps, wovpe, &
                     cident(1:icidl)//clabel, 'Instan. ', &
                     chpos, cvpos, caxi )
!
         call rnycont( wdisrny(1,1,0,0,i), wxrn(1,1,i), wyrn(1,1,i), &
                    irxp1, inxp1, ihx, ivx, wtime(itx), wohps, wohpe, wovps, wovpe, &
                    cident(1:icidl)//clabel, 'Instant. ', &
                     chpos, cvpos, caxi )
!...
         call fr_canvas ( 2 )
!
         call eaycont( wpidrmy(1,1,0,0,i), wxea(1,1,i), wyea, &
                irxp1, imxp1, ihx, ivx, wtime(itx), wohps, wohpe, wovps, wovpe, &
                cident(1:icidl)//clabel, 'Instantaneous ', &
                     chpos, cvpos, caxi )
!
         call adistgraph( wang, wadis(1,i), waidis(1,i), imxh, &
                          wtime(itx), wohps, wohpe, wovps, wovpe, &
                cident(1:icidl)//clabel, 'Instantaneous ', &
                     chpos, cvpos )
!
         call hwhmgraph( weng(1,i), whwhm(1,0,0,i), irx, ihx, ivx, &
                         wtime(itx), wohps, wohpe, wovps, wovpe, &
                         cident(1:icidl)//clabel, 'Instantaneous ', &
                     chpos, cvpos )
!...
         do iv = 0, ivx
         do ih = 0, ihx
           do im = 1, imx
             do ir = 1, irx
               wdisrmy(ir,im,ih,iv,i) = 0.0d0
               wpidrmy(ir,im,ih,iv,i) = 0.0d0
             end do
           end do
         end do
         end do
!.
         do iv = 0, ivx
         do ih = 0, ihx
           do in = 1, inx
             do ir = 1, irx
               wdisrny(ir,in,ih,iv,i) = 0.0d0
             end do
           end do
         end do
         end do
!..
         if( i .lt. iis ) then
            i = i + 1
            go to 2
         end if
!
         if( abs(wtime(itx)-wtimex) .le. 1.0d0 .or. &
                (wtime(itx)-wtimex) .gt. 0.0d0 ) then
            write(0,*) 'process was stopped by time.param.', wtimex
            go to 90
         end if
         go to 1
      end if
!...
      read( cbuff, '(5i4,f12.3)' ) id1,id2,id3,id4,id5,wnum
      id2 = imxp1 - id2

! ..forward-directed component 
      if( id2 .gt. imxh ) then 

! Intensity  [W/m2]
         wint(itx,id4,id5,i) = wint(itx,id4,id5,i) + wnum*weng(id1,i)*wcoefw 

! Spectrum   [num/m2/sec in id1-group]
         wspec(id1,itx,id4,id5,i) = wspec(id1,itx,id4,id5,i) + wnum * wcoefn

! Total      [num/m2/sec ]
         wsum(itx,i) = wsum(itx,i) + wnum * wcoefn

! Energy [J/m2/sec] & Number [#/m2/sec]
         wetot(itx,i) = wetot(itx,i) + wnum*weng(id1,i)*wcoefj
         wnumtot(itx,i) = wnumtot(itx,i) + wnum*wcoefn
      end if

! Momentum Ppara / Pperp
      wpidrmy(id1,id2,id4,id5,i) = wpidrmy(id1,id2,id4,id5,i) + wnum
      wpidrmyt(id1,id2,id4,id5,i) = wpidrmyt(id1,id2,id4,id5,i) + wnum

!..                              correction for cos(theta) V/C
      wnum = wnum / ( abs(wmue(id2)+wmue(id2+1))/2.0d0 ) / wvc(id1,i)

! Momentum distribution Ppara / Pperp
      wdisrmy(id1,id2,id4,id5,i) = wdisrmy(id1,id2,id4,id5,i) + wnum
      wdisrmyt(id1,id2,id4,id5,i) = wdisrmyt(id1,id2,id4,id5,i) + wnum

! Momentum distribution Ppara / Omega
      wdisrny(id1,id3,id4,id5,i) = wdisrny(id1,id3,id4,id5,i) + wnum
      wdisrnyt(id1,id3,id4,id5,i) = wdisrnyt(id1,id3,id4,id5,i) + wnum
!..
      goto 2

   90 continue
!...         
      write(0,*) 'reading data ',itx
!....
      call fr_canvas ( 1 )
!..
      do i = 1, iis
         call ionlabel ( i, wam(i), waz(i), clabel )
!
         call rmynrm( wdisrmyt(1,1,0,0,i), wmue, irxp1, imxp1, ihx, ivx, 2 )
         
         do iv = 0, ivx
         do ih = 0, ihx
           do im = 1, imx
             do ir = 1, irx
               wdisrmyt(ir,im,ih,iv,i) = log10(wdisrmyt(ir,im,ih,iv,i)+1.0d0)
             end do
           end do
         end do
         end do
!
         call rmycont( wdisrmyt(1,1,0,0,i), wxrm(1,1,i), wyrm(1,1,i), &
                       irxp1, imxp1, ihx, ivx, 1.0d30, wohps, wohpe, wovps, wovpe, &
                       cident(1:icidl)//clabel, 'Time-Integ. ', &
                     chpos, cvpos, caxi )
!..
         call rnynrm( wdisrnyt(1,1,0,0,i), irxp1, inxp1, ihx,ivx, 2 )
         do iv = 0, ivx
         do ih = 0, ihx
           do in = 1, inx
             do ir = 1, irx
               wdisrnyt(ir,in,ih,iv,i) = log10(wdisrnyt(ir,in,ih,iv,i)+1.0d0)
             end do
           end do
         end do
         end do
!
         call rnycont( wdisrnyt(1,1,0,0,i), wxrn(1,1,i), wyrn(1,1,i), &
                    irxp1, inxp1, ihx, ivx, 1.0d30, wohps, wohpe, wovps, wovpe, &
                    cident(1:icidl)//clabel, 'Time-Integ. ', &
                     chpos, cvpos, caxi )
      end do
!...
      call fr_canvas ( 2 )
!..
      do i = 1, iis
         call ionlabel ( i, wam(i), waz(i), clabel )
!
         call rmynrm( wpidrmyt(1,1,0,0,i), wmue, irxp1, imxp1, ihx,ivx, 2 )
         call adistcalc( wpidrmyt(1,1,0,0,i), irxp1, imxp1, ihx, ivx, 2, &
                         wadis(1,i), waidis(1,i), imxh, wnum )
         call hwhmcalc( wpidrmyt(1,1,0,0,i), wmue, whwhm(1,0,0,i), work, &
                        irxp1, imxp1, ihx, ivx, imxh )
         do iv = 0, ivx
         do ih = 0, ihx
           do im = 1, imx
             do ir = 1, irx
               wpidrmyt(ir,im,ih,iv,i) = log10(wpidrmyt(ir,im,ih,iv,i)+1.0d0)
             end do
           end do
         end do
         end do

         call eaycont( wpidrmyt(1,1,0,0,i), wxea(1,1,i), wyea, &
                irxp1, imxp1, ihx, ivx, 1.0d30, wohps, wohpe, wovps, wovpe, &
                cident(1:icidl)//clabel, 'Time-Integrated ', &
                     chpos, cvpos, caxi )
!
         call adistgraph( wang, wadis(1,i), waidis(1,i), imxh, &
                          1.0d30, wohps, wohpe, wovps, wovpe, &
                cident(1:icidl)//clabel, 'Time-Integrated ', &
                     chpos, cvpos )
!.
         call hwhmgraph( weng(1,i), whwhm(1,0,0,i), irx, ihx, ivx, &
                 1.0d30, wohps, wohpe, wovps, wovpe, &
                 cident(1:icidl)//clabel, 'Time-Integrated ', &
                     chpos, cvpos )

      end do
!.
      allocate( wxadis(itx,imxh), wyadis(itx,imxh) )
      do im = 1, imxh
         do it = 1, itx
            wxadis(it,im) = wtime(it)
            wyadis(it,im) = wang(im)
         end do
      end do
      do i = 1, iis
         call ionlabel ( i, wam(i), waz(i), clabel )
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, 90.0d0, 13 )
         call fr_xyname( 'Time[fs]', 'Angle[deg.]' )
         call fr_setcontour( 0.0d0, 1.0d0, 2 )
         call fr_sqrcontour( wxadis, wyadis, wadist(1:itx,1:imxh,i), &
                          itx, imxh, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 7, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 7, 1 )
         call fr_fpchars( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                             7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0, 15.0d0, &
                  'Normalized Angular Distribution', 7, 1, -1, 0, 0 )
!
         do im = 1, imxh
            do it = 1, itx
               wadist(it,im,i) = wadist(it,im,i) * wadisx(it,i)
            end do
         end do
         call fr_gclear
         call fr_aspect2d( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( wtime(1), wtime(itx), 0.0d0, 90.0d0, 13 )
         call fr_xyname( 'Time[fs]', 'Angle[deg.]' )
         call fr_sqrcontour( wxadis, wyadis, wadist(1:itx,1:imxh,i), &
                          itx, imxh, 1, -2, 0 )
         call fr_colorbar( 570, 115, 15, 200, 2 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 7, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 7, 1 )
         call fr_fpchars( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                             7, 1, -1, 0, 0 )
         call fr_fpchars( 200.0d0, 15.0d0, &
                  'Angular Distribution', 7, 1, -1, 0, 0 )
      end do
      deallocate( wxadis, wyadis )
!.
      allocate( wxhwhm(itx,irx), wyhwhm(itx,irx) )
      do i = 1, iis
         call ionlabel ( i, wam(i), waz(i), clabel )
         do ir = 1, irx
            do it = 1, itx
               wxhwhm(it,ir) = wtime(it)
               wyhwhm(it,ir) = weng(ir,i)
            end do
         end do
      ihxx = ihx
      ivxx = ivx
      if( ihx .eq. 1 ) ihxx = 0
      if( ivx .eq. 1 ) ivxx = 0
      
         do iv = 0, ivxx
         do ih = 0, ihxx
            call fr_gclear
            call fr_aspect2d( 1.0d0, 1.0d0, -1 )
            call fr_frame2d( wtime(1),wtime(itx),0.0d0,weng(irx,i),13 )
            call fr_xyname( 'Time[fs]', 'Energy[MeV]' )
            call fr_setcontour( 0.0d0, 90.0d0, 2 )
            call fr_sqrcontour(wxhwhm,wyhwhm,whwhmt(1:itx,1:irx,ih,iv,i), &
                               itx, irx, 1, -2, 0 )
            call fr_colorbar( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
         if( ih .eq. 0 ) then
            call yposchar( wohps, wohpe, 7, 1 )
         else
            whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
            whpe = wohps + ( wohpe-wohps ) / ihx *  ih
            call yposchar( whps, whpe, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
         if( iv .eq. 0 ) then
            call yposchar( wovps, wovpe, 7, 1 )
         else
            wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
            wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
            call yposchar( wvps, wvpe, 7, 1 )
         end if
            call fr_fpchars( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                             7, 1, -1, 0, 0 )
            call fr_fpchars( 220.0d0,15.0d0, 'HWHM[deg.]', 7,1,-1,0,0 )
         end do
         end do
      end do
      
      deallocate( wxhwhm, wyhwhm )
!.... convert unit
!.. intensity [W/m2] --> [W/cm2]
      do i = 1, iis
         do iv = 1, ivx
         do ih = 1, ihx
            do it = 1, itx
               wint(it,ih,iv,i) = wint(it,ih,iv,i) * 1.0d-4
               if( wint(it,ih,iv,i) .lt. 1.0d10) wint(it,ih,iv,i) = 1.0d10
               wint(it,0,0,i) = wint(it,0,0,i) + wint(it,ih,iv,i) / ihx/ ivx
            end do
         end do
         end do
      end do
!.. total beam fluence [J/cm2]
!..    changed to [J/micron2]
      do i = 1, iis
         do iv = 1, ivx
         do ih = 1, ihx
            wflue(1,ih,iv,i) = wint(1,ih,iv,i) * wotint * 1.0d-8
            do it = 2, itx
               wflue(it,ih,iv,i) = wflue(it-1,ih,iv,i) + &
                                wint(it,ih,iv,i) * wotint*1.0d-8
               wflue(it,0,0,i) = wflue(it,0,0,i) + wflue(it,ih,iv,i) / ihx/ ivx
            end do
         end do
         end do
      end do
!.. Energy [J/m2/sec] & Number [#/m2/sec]
!.. -> [J/micron2/fsec] & [#/micron2/fsec]
      do it = 1, itx
        do i = 1, lisx
          wetot(it,i) = wetot(it,i) * 1.0d3
          wnumtot(it,i) = wnumtot(it,i) * 1.0d-27
        end do
      end do
!.. total beam energy [J/micron2] & Number [#/micron2] for each range
      do i = 1, iis
         wetots(1,i) = wetot(1,i)
         wnumtots(1,i) = wnumtot(1,i)
         do it = 2, itx
            wetots(it,i) = wetots(it-1,i) + wetot(it,i)
            wnumtots(it,i) = wnumtots(it-1,i) + wnumtot(it,i)
         end do
      end do
!.. spectrum [number/m2/sec/J] --> [number/micron^2/fsec/J]
      do i = 1, iis
        do iv = 1, ivx
        do ih = 1, ihx
          do it = 1, itx
            do ir = 1, irx
              wspec(ir,it,ih,iv,i) = &
             wspec(ir,it,ih,iv,i)/smevj/(wengb(ir+1,i)-wengb(ir,i))*1.0d-27
              if( wspec(ir,it,ih,iv,i).lt.1.0d10) wspec(ir,it,ih,iv,i)=1.0d10
              wspec(ir,it,0,0,i) = wspec(ir,it,0,0,i)+wspec(ir,it,ih,iv,i)/ihx/ivx
            end do
          end do
        end do
        end do
      end do
!.. time-averaged/integrated spectrum
      do i = 1, iis
         do iv = 1, ivx
         do ih = 1, ihx
            do it = 2, itx
               do ir= 1, irx
                  wnum = 0.5d0*(wspec(ir,it,ih,iv,i)+wspec(ir,it-1,ih,iv,i))*&
                         ( wtime(it)-wtime(it-1) ) 
                  wspecta(ir,ih,iv,i) = wspecta(ir,ih,iv,i) + wnum / & 
                                ( wtime(itx)-wtime(1) )
                  wspecti(ir,ih,iv,i) = wspecti(ir,ih,iv,i) +  wnum
              end do
            end do
            do ir= 1, irx
               wspecta(ir,0,0,i) = wspecta(ir,0,0,i)+wspecta(ir,ih,iv,i)/ihx/ivx
               wspecti(ir,0,0,i) = wspecti(ir,0,0,i)+wspecti(ir,ih,iv,i)/ihx/ivx
            end do
         end do
         end do
      end do
!.... output text file
      do i = 1, iis
!...
      cdum='ix-'
      write( cdum(2:2), '(i1)' ) i
      call ionlabel ( i, wam(i), waz(i), clabel )
!..   intensity
      open( 7, file='intensity-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident(1:icidl)//clabel, &
                     'Intensity[W/cm^2] CenterPos.[micron]'
      cbuff ='(a,xxx(",",f10.2,"/",f10.2))'
      write(cbuff(4:6),'(i3)') ihx*ivx 
      write(7,cbuff) 'Time[fs],  Total', &
                 ((wohps+(wohpe-wohps)/ihx*(ih-0.5), &
                   wovps+(wovpe-wovps)/ivx*(iv-0.5),ih=1,ihx),iv=1,ivx)
      cbuff ='(f8.1,xxx(",",e12.4))'
      write(cbuff(7:9),'(i3)') ihx*ivx+1
      do it = 1, itx
         write(7,cbuff) wtime(it),wint(it,0,0,i),&
                      ((wint(it,ih,iv,i),ih=1,ihx),iv=1,ivx)
      end do
      close( 7 )
!..   beam fluence
      open( 7, file='fluence-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident(1:icidl)//clabel, &
                     'Fluence[J/micron^2] CenterPos.[micron]'
      cbuff ='(a,xxx(",",f10.2,"/",f10.2))'
      write(cbuff(4:6),'(i3)') ihx*ivx 
      write(7,cbuff) 'Time[fs],  Total', &
                 ((wohps+(wohpe-wohps)/ihx*(ih-0.5), &
                   wovps+(wovpe-wovps)/ivx*(iv-0.5),ih=1,ihx),iv=1,ivx)
      cbuff ='(f8.1,xxx(",",e12.4))'
      write(cbuff(7:9),'(i3)') ihx*ivx+1
      do it = 1, itx
         write(7,cbuff) wtime(it),wflue(it,0,0,i),&
                      ((wflue(it,ih,iv,i),ih=1,ihx),iv=1,ivx)
      end do 
      close( 7 )
!..   instantaneous beam energy
      open( 7, file='energy-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident(1:icidl)//clabel
      cbuff = '(a)' 
      write(7,cbuff) 'Time[fs],  Total'  
      cbuff = '(f8.1,",",e12.4)'
      do it = 1, itx
         write(7,cbuff) wtime(it), wetot(it,i)
      end do
      close( 7 )
!..   time integrated beam energy
      open( 7, file='intenergy-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident(1:icidl)//clabel
      cbuff = '(a)' 
      write(7,cbuff) 'Time[fs],  Total'  
      cbuff = '(f8.1,",",e12.4)'
      do it = 1, itx
         write(7,cbuff) wtime(it), wetots(it,i)
      end do
      close( 7 )
!..   instantaneous number
      open( 7, file='number-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident(1:icidl)//clabel
      cbuff = '(a)' 
      write(7,cbuff) 'Time[fs],  Total'  
      cbuff = '(f8.1,",",e12.4)'
      do it = 1, itx
         write(7,cbuff) wtime(it), wnumtot(it,i)
      end do
      close( 7 )
!..   time integrated number
      open( 7, file='intnumber-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident(1:icidl)//clabel
      cbuff = '(a)' 
      write(7,cbuff) 'Time[fs],  Total'  
      cbuff = '(f8.1,",",e12.4)'
      do it = 1, itx
         write(7,cbuff) wtime(it), wnumtots(it,i)
      end do
      close( 7 )
!..   spectrum
      open( 7, file='spectrum-'//cdum(1:3)//cident(1:icidl)// &
                                      '.txt', form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident(1:icidl)//clabel, &
                        'Number[a.u.] CenterPos.[micron]'
      cbuff ='(a,xxx(",",f10.2,"/",f10.2))'
      write(cbuff(4:6),'(i3)') ihx*ivx 
      write(7,cbuff) 'Energy[MeV],  Total', &
                 ((wohps+(wohpe-wohps)/ihx*(ih-0.5), &
                   wovps+(wovpe-wovps)/ivx*(iv-0.5),ih=1,ihx),iv=1,ivx)
      cbuff ='(f10.3,xxx(",",e12.4))'
      write(cbuff(8:10),'(i3)') ihx*ivx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir,i),wspecti(ir,0,0,i),&
                      ((wspecti(ir,ih,iv,i),ih=1,ihx),iv=1,ivx)
      end do
      close( 7 )
!..   time average spectrum
      open( 7, file='avespectrum-'//cdum(1:3)//cident(1:icidl)// &
                                       '.txt', form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident(1:icidl)//clabel, &
                        'Number[a.u.] CenterPos.[micron]'
      cbuff ='(a,xxx(",",f10.2,"/",f10.2))'
      write(cbuff(4:6),'(i3)') ihx*ivx 
      write(7,cbuff) 'Energy[MeV],  Total', &
                 ((wohps+(wohpe-wohps)/ihx*(ih-0.5), &
                   wovps+(wovpe-wovps)/ivx*(iv-0.5),ih=1,ihx),iv=1,ivx)
      cbuff ='(f10.3,xxx(",",e12.4))'
      write(cbuff(8:10),'(i3)') ihx*ivx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir,i),wspecta(ir,0,0,i), &
                      ((wspecta(ir,ih,iv,i),ih=1,ihx),iv=1,ivx)
      end do
      close( 7 )
!..   angle distribution
      open( 7, file='angdis-'//cdum(1:3)//cident(1:icidl)//&
                                       '.txt', form='FORMATTED' )
      cbuff = '("# ",a)'
      write(7,cbuff) cident(1:icidl)//clabel
      cbuff = '(a)' 
      write(7,cbuff) 'Angle[deg.],  f(theta),  F(theta)'
      cbuff = '(f7.2,2(",",e12.4))'
      do im = 1, imxh 
         write(7,cbuff) wang(im), wadis(im,i), waidis(im,i)
      end do
      close( 7 )
!..   hwhm
      open( 7, file='hwhm-'//cdum(1:3)//cident(1:icidl)// &
                                       '.txt', form='FORMATTED' )
      cbuff = '("# ",a,2x,a)'
      write(7,cbuff) cident(1:icidl)//clabel, 'HWHM[deg.] Time[fs]'
      cbuff = '(a,xxx(",",f8.1),",",2x,a)'
      write(cbuff(4:6),'(i3)') itx
      write(7,cbuff) 'Energy[MeV]', (wtime(it),it=1,itx),'Time-Integrated'
      cbuff = '(f10.3,xxx(",",f7.2))'
      write(cbuff(8:10),'(i3)') itx+1
      do ir = 1, irx
         write(7,cbuff) weng(ir,i), (whwhmt(it,ir,0,0,i),it=1,itx), &
                        whwhm(ir,0,0,i)
      end do
      close( 7 )
!...
      end do
!.... 
      call fr_canvas ( 3 )
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
!..
      do i = 1, iis
!.
      call ionlabel ( i, wam(i), waz(i), clabel )
!.
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iv = 1, ivx
      do ih = 1, ihx
         if( wtime(1) .eq. 0.0d0 ) &
            wint(1,ih,iv,i) = min(wint(1,ih,iv,i),wint(2,ih,iv,i))
         do it = 1, itx
            wint(it,ih,iv,i) = log10( wint(it,ih,iv,i) )
            wintmn = min( wintmn, wint(it,ih,iv,i) )
            wintmx = max( wintmx, wint(it,ih,iv,i) )
         end do
      end do
      end do
      if( wtime(1) .eq. 0.0d0 ) &
         wint(1,0,0,i) = min(wint(1,0,0,i),wint(2,0,0,i))
      do it = 1, itx
         wint(it,0,0,i) = log10( wint(it,0,0,i) )
         wintmn = min( wintmn, wint(it,0,0,i) )
         wintmx = max( wintmx, wint(it,0,0,i) )
      end do
!
      wintmn = int( wintmn )
      wintmx = int( wintmx ) + 1
!.
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Intensity[W/cm^2]' )
      call fr_graph2d( wtime(1), wint(1,0,0,i), itx, 2, 1 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!.
      if( ihx .gt. 1 .or. ivx .gt. 1 ) then
         ic=0
         do iv = 1, ivx
         do ih = 1, ihx
            ic=ic+1
            icol = mod( ic-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( wtime(1), wint(1,ih,iv,i), itx, icol, 1 )
            whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
            whpe = wohps + ( wohpe-wohps ) / ihx *  ih
            wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
            wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
            call fr_fpchars ( 480.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( whps, whpe, icol, 0 )
            call fr_fpchars ( 580.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wvps, wvpe, icol, 0 )
            it = it+1
            write( cdum, '(i3)' ) ih
            call fr_2dmove ( wtime(it), wint(it,ih,iv,i), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 )
         end do
         end do
!      
         call fr_canvas(4)
         do it=its,itx,itd
            cbuff = 'xxxxx.xx fsec'
            write( cbuff(1:8), '(f8.2)' ) wtime(it)
            call fr_gclear
            call fr_aspect3d ( 1.0d0, 1.0d0, 1.0d0, 1 )
            call fr_frame3d( wohps, wohpe, wovps, wovpe, &
                             wintmn, wintmx, 3 )
            call fr_xyzname( chpos,cvpos,'Intensity[W/cm^2]' )
            call fr_profile( wint(it,1:ihx,1:ivx,i), ihx, ivx, -2, 1 )
            call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                           7, 1, -1, 0, 0 )
            call fr_fpchars ( 5.0d0, 450.0d0, caxi, 7, 1, -1, 0, 0 )
            call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
         end do
      end if
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do iv = 0, ivx
      do ih = 0, ihx
         do it = 1, itx
            wintmn = min( wintmn, wflue(it,ih,iv,i) )
            wintmx = max( wintmx, wflue(it,ih,iv,i) )
         end do
      end do
      end do
!.
      call fr_canvas(3)
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Fluence[J/micron^2]' )
      call fr_graph2d( wtime(1), wflue(1,0,0,i), itx, 2, 1 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!..
      if( ihx .gt. 1 .or. ivx .gt. 1 ) then
         ic=0
         do iv = 1, ivx
         do ih = 1, ihx
            ic=ic+1
            icol = mod( ic-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( wtime(1), wflue(1,ih,iv,i), itx, icol, 1 )
            whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
            whpe = wohps + ( wohpe-wohps ) / ihx *  ih
            wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
            wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
            call fr_fpchars ( 480.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( whps, whpe, icol, 0 )
            call fr_fpchars ( 580.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wvps, wvpe, icol, 0 )
            it = itx / ihx * ih
            if(it .eq. 0)it=it+1
            write( cdum, '(i3)' ) ih
            call fr_2dmove ( wtime(it), wflue(it,ih,iv,i), 0 )
            call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 )
         end do
         end do
!
         call fr_canvas(4)
         do it=its,itx,itd
            cbuff = 'xxxxx.xx fsec'
            write( cbuff(1:8), '(f8.2)' ) wtime(it)
            call fr_gclear
            call fr_aspect3d ( 1.0d0, 1.0d0, 1.0d0, 1 )
            call fr_frame3d( wohps, wohpe, wovps, wovpe, &
                             wintmn, wintmx, 3 )
            call fr_xyzname(chpos,cvpos,'Fluence[J/micron^2]')
            call fr_profile( wflue(it,1:ihx,1:ivx,i), ihx, ivx, -2, 1 )
            call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                           7, 1, -1, 0, 0 )
            call fr_fpchars ( 5.0d0, 450.0d0, caxi, 7, 1, -1, 0, 0 )
            call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
         end do
      end if
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      if( wtime(1) .eq. 0.0d0 ) wetot(1,i) = min(wetot(1,i),wetot(2,i))
      do it = 1, itx
         wintmn = min( wintmn, wetot(it,i) )
         wintmx = max( wintmx, wetot(it,i) )
      end do
!.
      call fr_canvas(3)
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Energy[J/micron^2/fsec]' )
      call fr_graph2d( wtime(1), wetot(1,i), itx, 6, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do it = 1, itx
         wintmn = min( wintmn, wetots(it,i) )
         wintmx = max( wintmx, wetots(it,i) )
      end do
!.
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Time-Integrated Energy[J/micron^2]' )
      call fr_graph2d( wtime(1), wetots(1,i), itx, 6, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      if( wtime(1) .eq. 0.0d0 ) &
         wnumtot(1,i) = min(wnumtot(1,i),wnumtot(2,i))
      do it = 1, itx
         wintmn = min( wintmn, wnumtot(it,i) )
         wintmx = max( wintmx, wnumtot(it,i) )
      end do
!.
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Number[#/micron^2/fsec]' )
      call fr_graph2d( wtime(1), wnumtot(1,i), itx, 6, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!..
      wintmn = 1.0d30
      wintmx = -1.0d30
      do it = 1, itx
         wintmn = min( wintmn, wnumtots(it,i) )
         wintmx = max( wintmx, wnumtots(it,i) )
      end do
!.
      call fr_gclear
      call fr_frame2d( wtime(1), wtime(itx), wintmn, wintmx, 10 )
      call fr_xyname( 'Time[fs]', 'Time-Integrated &
                      Number[#/micron^2]' )
      call fr_graph2d( wtime(1), wnumtots(1,i), itx, 6, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
!..
      wintmx = 0.0d0
      do iv = 1, ivx
      do ih = 1, ihx
        do it = its, itx, itd
            do ir = 1, irx
               wspec(ir,it,ih,iv,i) = log10( wspec(ir,it,ih,iv,i) )
               wintmx = max( wintmx, wspec(ir,it,ih,iv,i) )
            end do
         end do
      end do
      end do
      do it = its, itx, itd
         do ir = 1, irx
            wspec(ir,it,0,0,i) = log10( wspec(ir,it,0,0,i) )
            wintmx = max( wintmx, wspec(ir,it,0,0,i) )
         end do
      end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
      icold = ( (itx-its) / itd + 1 - 1 ) / 6 + 1
!.
      icol  = 1
      icolc = 0
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( 0.0d0, weng(irx,i), wintmn, wintmx, 10 )
      call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
      do it = its, itx, itd
        call fr_graph2d( weng(1,i), wspec(1,it,0,0,i), irx, icol, 1 )
        write( cbuff(1:8), '(f8.2)' ) wtime(it)
        call fr_fpchars ( 400.0d0+icolc*60.0d0,10.0d0+icol*15.0d0, &
                          cbuff(1:8), icol, 1, -1, 0, 0 )
        icolc = icolc + 1
        if( icolc .ge. icold ) then
           icol = icol + 1
           icolc = 0
        end if
      end do
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 7, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 7, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                         7, 1, -1, 0, 0 )
      call fr_fpchars ( 220.0d0, 15.0d0, 'Instantaneous Spectrum', &
                         7, 1, -1, 0, 0 )
!
      if( ihx .gt. 1 .or. ivx .gt. 1 ) then
        do iv = 1, ivxx
        do ih = 1, ihxx
          icol  = 1
          icolc = 0
          call fr_gclear
          call fr_setaxis( 2 )
          call fr_frame2d( 0.0d0, weng(irx,i), wintmn, wintmx, 10 )
          call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
          do it = its, itx, itd
            call fr_graph2d( weng(1,i), wspec(1,it,ih,iv,i), irx, icol, 1 )
            write( cbuff(1:8), '(f8.2)' ) wtime(it)
            call fr_fpchars ( 400.0d0+icolc*60.0d0,10.0d0+icol*15.0d0, &
                              cbuff(1:8), icol, 1, -1, 0, 0 )
            icolc = icolc + 1
            if( icolc .ge. icold ) then
               icol = icol + 1
               icolc = 0
            end if
          end do
          call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
          call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
          whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
          whpe = wohps + ( wohpe-wohps ) / ihx *  ih
          call yposchar( whps, whpe, 7, 1 )
          call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
          wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
          wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
          call yposchar( wvps, wvpe, 7, 1 )
          call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                         7, 1, -1, 0, 0 )
          call fr_fpchars ( 220.0d0, 15.0d0, 'Instantaneous Spectrum', &
                         7, 1, -1, 0, 0 )
        end do
        end do
      end if
!..
      wintmx = 0.0d0
      do iv = 1, ivx
      do ih = 1, ihx
         do ir = 1, irx
            wspecta(ir,ih,iv,i) = log10( wspecta(ir,ih,iv,i) )
            wintmx = max( wintmx, wspecta(ir,ih,iv,i) )
         end do
      end do
      end do
         do ir = 1, irx
            wspecta(ir,0,0,i) = log10( wspecta(ir,0,0,i) )
            wintmx = max( wintmx, wspecta(ir,0,0,i) )
         end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
!.
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( 0.0d0, weng(irx,i), wintmn, wintmx, 10 )
      call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
      call fr_graph2d( weng(1,i), wspecta(1,0,0,i), irx, 2, 1 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 2, 1 )
!   
      if( ihx .gt. 1 .or. ivx .gt. 1 ) then
         ic=0
         do iv = 1, ivx
         do ih = 1, ihx
            ic=ic+1
            icol = mod( ic-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( weng(1,i), wspecta(1,ih,iv,i), irx, icol, 1 )
            whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
            whpe = wohps + ( wohpe-wohps ) / ihx *  ih
            wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
            wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
            call fr_fpchars ( 480.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( whps, whpe, icol, 0 )
            call fr_fpchars ( 580.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wvps, wvpe, icol, 0 )
            ir = irx / ihx * ih
            write( cdum, '(i3)' ) ih
            call fr_2dmove ( weng(ir,i), wspecta(ir,ih,iv,i), 0 )
            !call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 ) 
         end do
         end do
      end if
!      
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
      call fr_fpchars ( 220.0d0, 15.0d0, 'Time-Averaged Spectrum', &
                        7, 1, -1, 0, 0 )
!..
      wintmx = 0.0d0
      do iv = 1, ivx
      do ih = 1, ihx
         do ir = 1, irx
            wspecti(ir,ih,iv,i) = log10( wspecti(ir,ih,iv,i) )
            wintmx = max( wintmx, wspecti(ir,ih,iv,i) )
         end do
      end do
      end do
         do ir = 1, irx
            wspecti(ir,0,0,i) = log10( wspecti(ir,0,0,i) )
            wintmx = max( wintmx, wspecti(ir,0,0,i) )
         end do
      wintmx = int( wintmx ) + 1
      wintmn = wintmx - 6.0d0
!.
      call fr_gclear
      call fr_setaxis( 2 )
      call fr_frame2d( 0.0d0, weng(irx,i), wintmn, wintmx, 10 )
      call fr_xyname( 'Energy[MeV]', 'Number[a.u.]' )
      call fr_graph2d( weng(1,i), wspecti(1,0,0,i), irx, 2, 1 )
      call fr_fpchars( 5.0d0, 430.0d0, caxi, 7, 1, -1, 0, 0 )
      call fr_fpchars( 5.0d0, 450.0d0, chpos, 7, 1, -1, 0, 0 )
      call yposchar( wohps, wohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, cvpos, 7, 1, -1, 0, 0 )
      call yposchar( wovps, wovpe, 2, 1 )
      if( ihx .gt. 1 .or. ivx .gt. 1 ) then
   !   
         ic=0
         do iv = 1, ivx
         do ih = 1, ihx
            ic=ic+1
            icol = mod( ic-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( weng(1,i), wspecti(1,ih,iv,i), irx, icol, 1 )
            whps = wohps + ( wohpe-wohps ) / ihx * (ih-1)
            whpe = wohps + ( wohpe-wohps ) / ihx *  ih
            wvps = wovps + ( wovpe-wovps ) / ivx * (iv-1)
            wvpe = wovps + ( wovpe-wovps ) / ivx *  iv
            call fr_fpchars ( 480.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( whps, whpe, icol, 0 )
            call fr_fpchars ( 580.0d0, 490.0d0-ic*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( wvps, wvpe, icol, 0 )
            ir = irx / ihx * ih
            write( cdum, '(i3)' ) ih
            call fr_2dmove ( weng(ir,i), wspecti(ir,ih,iv,i), 0 )
            !call fr_fpchars ( 0.0d0, 0.0d0, cdum, icol, 0, 0, 0, 30 ) 
         end do
         end do
    !     
      end if
      call fr_fpchars ( 5.0d0, 15.0d0, cident(1:icidl)//clabel, &
                        7, 1, -1, 0, 0 )
      call fr_fpchars ( 220.0d0, 15.0d0, 'Time-Integrated Spectrum', &
                        7, 1, -1, 0, 0 )
!.
      end do
!....
      call fr_gend
!....
      stop
!....
  999 continue
      write(0,*) '### ERROR: time param file not found. file="', &
         trim(cfile), '"'
      stop
      end
!----------------------------------------------------------------------
      subroutine rmycont( rdat, rxp, ryp, krx1, kmx1, khx, kvx, &
                      rtime, rohps, rohpe, rovps, rovpe, eident, ecom, ehpos, evpos, eaxi )
!
      implicit none
      integer :: krx1, kmx1, khx, ih, ihxx, kvx, iv, ivxx
      real*8 :: rdat(krx1,kmx1,0:khx,0:kvx), rxp(krx1,kmx1), ryp(krx1,kmx1), &
                rtime, rohps, rohpe, rovps,rovpe,arx, ahps, ahpe,avps,avpe
      character :: cbuff*16, eident*(*), ecom*(*), ehpos*(*), evpos*(*), eaxi*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = sqrt( rxp(krx1,1)**2 + ryp(krx1,1)**2 )
      ihxx = khx
      ivxx = kvx
      if( khx .eq. 1 ) ihxx = 0
      if( kvx .eq. 1 ) ivxx = 0
      do iv = 0, ivxx
      do ih = 0, ihxx
         call fr_gclear
         call fr_aspect2d ( 2.0d0, 1.0d0, 1 )
         call fr_frame2d( -arx, arx, 0.0d0, arx ,13 )
         call fr_xyname( 'Ppara/m_ec', 'Pperp/m_ec' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,ih,iv), krx1,kmx1,1,-4,0 )
         call fr_colorbar ( 215, 440, 200, 15, 2 )
         call fr_fpchars( 5.0d0, 430.0d0, eaxi, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 450.0d0, ehpos, 7, 1, -1, 0, 0 )
         if( ih .eq. 0 ) then
            call yposchar( rohps, rohpe, 7, 1 )
         else
            ahps = rohps + ( rohpe-rohps ) / khx * (ih-1)
            ahpe = rohps + ( rohpe-rohps ) / khx *  ih
            call yposchar( ahps, ahpe, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 470.0d0, evpos, 7, 1, -1, 0, 0 )
         if( iv .eq. 0 ) then
            call yposchar( rovps, rovpe, 7, 1 )
         else
            avps = rovps + ( rovpe-rovps ) / kvx * (iv-1)
            avpe = rovps + ( rovpe-rovps ) / kvx *  iv
            call yposchar( avps, avpe, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 220.0d0,15.0d0, &
                        ecom//'Dist. Ppara vs. Pperp', 7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rnycont( rdat, rxp, ryp, krx1, knx1, khx, kvx, &
                      rtime, rohps, rohpe, rovps, rovpe, eident, ecom, ehpos, evpos, eaxi )
!
      implicit none
      integer :: krx1, knx1, khx, ih, ihxx, kvx, iv, ivxx
      real*8 :: rdat(krx1,knx1,0:khx,0:kvx), rxp(krx1,knx1), ryp(krx1,knx1), &
                rtime, rohps, rohpe, rovps,rovpe,arx, ahps, ahpe,avps,avpe
      character :: cbuff*16, eident*(*), ecom*(*), ehpos*(*), evpos*(*),eaxi*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = sqrt( rxp(krx1,1)**2 + ryp(krx1,1)**2 )
      ihxx = khx
      ivxx = kvx
      if( khx .eq. 1 ) ihxx = 0
      if( kvx .eq. 1 ) ivxx = 0
      do iv = 0, ivxx
      do ih = 0, ihxx
         call fr_gclear
         call fr_aspect2d ( 1.0d0, 1.0d0, 1 )
         call fr_frame2d( -arx, arx, -arx, arx ,13 )
         call fr_xyname( 'P/m_ec', 'P/m_ec' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,ih,iv), &
                          krx1, knx1, 1, -4, 0 )
         call fr_colorbar ( 495, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 430.0d0, eaxi, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 450.0d0, ehpos, 7, 1, -1, 0, 0 )
         if( ih .eq. 0 ) then
            call yposchar( rohps, rohpe, 7, 1 )
         else
            ahps = rohps + ( rohpe-rohps ) / khx * (ih-1)
            ahpe = rohps + ( rohpe-rohps ) / khx *  ih
            call yposchar( ahps, ahpe, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 470.0d0, evpos, 7, 1, -1, 0, 0 )
         if( iv .eq. 0 ) then
            call yposchar( rovps, rovpe, 7, 1 )
         else
            avps = rovps + ( rovpe-rovps ) / kvx * (iv-1)
            avpe = rovps + ( rovpe-rovps ) / kvx *  iv
            call yposchar( avps, avpe, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 220.0d0,15.0d0, &
                       ecom//'Dist. Ppara vs. Omega', 7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine eaycont( rdat, rxp, ryp, krx1, kmx1, khx, kvx, &
                     rtime, rohps, rohpe, rovps, rovpe, eident, ecom, ehpos, evpos, eaxi )
!
      implicit none
      integer :: krx1, kmx1, khx, ih, ihxx, kvx, iv, ivxx
      real*8 :: rdat(krx1,kmx1,0:khx,0:kvx), rxp(krx1,kmx1), ryp(krx1,kmx1), &
                rtime, rohps, rohpe, rovps, rovpe,arx, ahps, ahpe,avps,avpe
      character :: cbuff*16, eident*(*), ecom*(*), ehpos*(*), evpos*(*), eaxi*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
      arx = rxp(krx1,1)
      ihxx = khx
      ivxx = kvx
      if( khx .eq. 1 ) ihxx = 0
      if( kvx .eq. 1 ) ivxx = 0
      do ih = 0, ihxx
      do iv = 0, ivxx
         call fr_gclear
         call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
         call fr_frame2d( 0.0d0, arx, 0.0d0, 180.0d0 ,13 )
         call fr_xyname( 'Energy[MeV]', 'Angle[deg.]' )
         call fr_setcontour( 0.0d0, 0.0d0, 0 )
         call fr_sqrcontour( rxp, ryp, rdat(1,1,ih,iv), &
                          krx1, kmx1, 1, -4, 0 )
         call fr_colorbar ( 570, 115, 15, 200, 2 )
         call fr_fpchars( 5.0d0, 430.0d0, eaxi, 7, 1, -1, 0, 0 )
         call fr_fpchars( 5.0d0, 450.0d0, ehpos, 7, 1, -1, 0, 0 )
         if( ih .eq. 0 ) then
            call yposchar( rohps, rohpe, 7, 1 )
         else
            ahps = rohps + ( rohpe-rohps ) / khx * (ih-1)
            ahpe = rohps + ( rohpe-rohps ) / khx *  ih
            call yposchar( ahps, ahpe, 7, 1 )
         end if
         call fr_fpchars( 5.0d0, 470.0d0, evpos, 7, 1, -1, 0, 0 )
         if( iv .eq. 0 ) then
            call yposchar( rovps, rovpe, 7, 1 )
         else
            avps = rovps + ( rovpe-rovps ) / kvx * (iv-1)
            avpe = rovps + ( rovpe-rovps ) / kvx *  iv
            call yposchar( avps, avpe, 7, 1 )
         end if
         call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 220.0d0,15.0d0, ecom//'Angle vs. Energy', &
                              7, 1, -1, 0, 0 )
         call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
      end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine adistgraph( rang, radis, raidis, kmx, &
                      rtime, rohps, rohpe, rovps, rovpe, eident, ecom, ehpos, evpos )
!
      implicit none
      integer :: kmx
      real*8 :: rang(kmx), radis(kmx), raidis(kmx), rtime,rohps,rohpe,rovps,rovpe
      character :: cbuff*16, eident*(*), ecom*(*), ehpos*(*), evpos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( 0.0d0, 90.0d0, 0.0d0, 1.0d0, 10 )
      call fr_xyname( 'Angle[deg]', 'Distribution[a.u.]' )
      call fr_graph2d( rang, radis, kmx, 2, 1 )
      call fr_graph2d( rang, raidis, kmx, 4, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, ehpos, 7, 1, -1, 0, 0 )
      call yposchar( rohps, rohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, evpos, 7, 1, -1, 0, 0 )
      call yposchar( rovps, rovpe, 2, 1 )
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 200.0d0,15.0d0, ecom//'Angular Distribution', &
                              7, 1, -1, 0, 0 )
      call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine yposchar( rys, rye, kcol, kbx )
!
      implicit none
      integer :: istr, ichs, kcol, kbx
      real*8 :: rys, rye
      character :: cbuff*16, cstr*8
!....
      write( cstr, '(f5.1)' ) rys
      ichs = 1
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      ichs = ichs+istr
      cbuff(ichs:ichs+2) = ' ~ '
      ichs = ichs+3
      write( cstr, '(f5.1)' ) rye
      istr = len_trim( adjustl( cstr ) )
      cbuff(ichs:ichs+istr-1) = adjustl( cstr )
      call fr_fpchars ( 1.0d0, 0.0d0, cbuff(1:ichs+istr-1), &
                        kcol, kbx, -1, 0, 1 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine hwhmcalc( rdat, rmue, rhwhm, rwrk, krx1, kmx1, khx, kvx, &
                           kmxh )
!
      implicit none
      integer, parameter :: iman = 3
      real*8, parameter :: athres = 0.1d0
      integer :: krx1, kmx1, khx, kvx, kmxh, ih, iv, im,imx, ir,irx, ihxx, ivxx, i,inx
      real*8 :: rdat(krx1,kmx1,0:khx,0:kvx), rmue(krx1), &
                rhwhm(krx1-1,0:khx,0:kvx), rwrk(kmxh,2), anx, anx2, at1, at2
!....
      irx = krx1 - 1
      imx = kmx1 - 1
!....
      ihxx = khx
      ivxx = kvx
      if( khx .eq. 1 ) ihxx = 0
      if( kvx .eq. 1 ) ivxx = 0
      do iv = 0, ivxx
      do ih = 0, ihxx
        do ir = 1, irx
!..                                           * moving average *
          do im = 1, kmxh
            rwrk(im,1) = rdat(ir,im+kmxh,ih,iv)
          end do
          do i = 1, iman
            rwrk(1,2) = ( rwrk(1,1)+rwrk(2,1) ) / 2.0d0
            do im = 2, kmxh-1
              rwrk(im,2) = ( rwrk(im-1,1)+rwrk(im,1)+rwrk(im+1,1) ) &
                           / 3.0d0
            end do
            rwrk(kmxh,2) = ( rwrk(kmxh-1,1)+rwrk(kmxh,1) ) / 2.0d0
            do im = 1, kmxh
              rwrk(im,1) = rwrk(im,2)
            end do
          end do
!..                                               * find max *
          anx = 0.0d0
          inx = 0
          do im = kmxh, 1, -1
             if( rwrk(im,1) .gt. anx ) then
                anx = rwrk(im,1)
                inx = im
             end if
          end do
          if( anx .le. athres ) then
             rhwhm(ir,ih,iv) = -1.0d0
          else
!..                                               * find hwhm *
             anx2 = anx / 2.0d0
             rhwhm(ir,ih,iv) = 90.0d0
             do im = inx, 1, -1
                if( rwrk(im,1) .le. anx2 ) then
                   at1 = acos( rmue(im+kmxh)   )
                   at2 = acos( rmue(im+kmxh+1) )
                   rhwhm(ir,ih,iv) = ( at1 + ( at2 - at1 ) * &
                     ( anx2-rwrk(im,1) ) / ( rwrk(im+1,1)-rwrk(im,1) ) &
                     ) * 180.0d0 / acos( -1.0d0 )
                   exit
                end if
             end do
          end if
!..
        end do
      end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine hwhmgraph( reng, rhwhm, krx, khx, kvx, &
                      rtime, rohps, rohpe, rovps, rovpe, eident, ecom, ehpos, evpos )
!
      implicit none
      integer :: krx, khx, ih, ihxx, kvx, iv, ivxx, icol,i
      real*8 :: reng(krx),rhwhm(krx,0:khx,0:kvx),rtime,rohps,rohpe,ahps,ahpe,rovps,rovpe,avps,avpe
      character :: cbuff*16, eident*(*), ecom*(*), ehpos*(*), evpos*(*)
!....
      cbuff = 'xxxxx.xx fsec'
      write( cbuff(1:8), '(f8.2)' ) rtime
!..
      call fr_gclear
      call fr_aspect2d ( 1.0d0, 1.0d0, -1 )
      call fr_frame2d( 0.0d0, reng(krx), 0.0d0, 90.0d0, 10 )
      call fr_xyname( 'Energy[MeV]', 'HWHM[deg.]' )
      call fr_graph2d( reng, rhwhm(1,0,0), krx, 2, 1 )
      call fr_fpchars( 5.0d0, 450.0d0, ehpos, 7, 1, -1, 0, 0 )
      call yposchar( rohps, rohpe, 2, 1 )
      call fr_fpchars( 5.0d0, 470.0d0, evpos, 7, 1, -1, 0, 0 )
      call yposchar( rovps, rovpe, 2, 1 )
      i=0
      if( khx .gt. 1 .and. kvx .gt.1 ) then
         do iv = 1, kvx
         do ih = 1, khx
            i=i+1
            icol = mod( i-1, 5 ) + 1
            if( icol .eq. 2 ) icol = 6
            call fr_graph2d( reng, rhwhm(1,ih,iv), krx, icol, 1 )
            ahps = rohps + ( rohpe-rohps ) / khx * (ih-1)
            ahpe = rohps + ( rohpe-rohps ) / khx *  ih
            avps = rovps + ( rovpe-rovps ) / kvx * (iv-1)
            avpe = rovps + ( rovpe-rovps ) / kvx *  iv
            call fr_fpchars ( 480.0d0, 490.0d0-i*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( ahps, ahpe, icol, 0 )
            call fr_fpchars ( 580.0d0, 490.0d0-i*15.0d0, ' ', icol, &
                              1, -1, 0, 0 )
            call yposchar( avps, avpe, icol, 0 )
         end do
         end do
      end if
      call fr_fpchars ( 5.0d0, 15.0d0, eident, 7, 1, -1, 0, 0 )
      call fr_fpchars ( 220.0d0,15.0d0, ecom//'HWHM', &
                              7, 1, -1, 0, 0 )
      call fr_fpchars ( 500.0d0, 15.0d0, cbuff(1:13), 7,1,-1,0,0 )
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rmynrm( rdat, rmue, krx1, kmx1, khx, kvx, klcut )
!
      implicit none
      integer :: krx1, kmx1, khx, kvx, klcut, km, ih, iv, im, ir
      real*8 :: rdat(krx1,kmx1,0:khx,0:kvx), rmue(kmx1), area
!....
      do iv = 1, kvx
      do ih = 1, khx
        do im = 1, kmx1-1
          do ir = klcut, krx1-1
            if( km .eq. 2 ) then
               area = ( ir - 0.5d0 ) * &
                           ( acos(rmue(im))-acos(rmue(im+1)) )
            else
               area = 2.0d0 * acos( -1.0d0 ) * ( ir - 0.5d0 )**2 * &
                      sin( (acos(rmue(im))+acos(rmue(im+1)))/2.0d0 ) * &
                      ( acos(rmue(im))-acos(rmue(im+1)) )
            end if
            rdat(ir,im,ih,iv) = rdat(ir,im,ih,iv) / area
            rdat(ir,im,0,0) = rdat(ir,im,0,0) + rdat(ir,im,ih,iv)
          end do
          do ir = 1, klcut-1
            rdat(ir,im,ih,iv) = rdat(klcut,im,ih,iv)
            rdat(ir,im,0,0) = rdat(ir,im,0,0) + rdat(ir,im,ih,iv)
          end do
        end do
      end do
      end do
!..
      do im = 1, kmx1-1
        do ir = 1, krx1-1
          do iv = 1, kvx
            do ih = 1, khx
              rdat(ir,im,0,iv) = rdat(ir,im,0,iv) + rdat(ir,im,ih,iv)
            end do
          end do
          do ih = 1, khx
            do iv = 1, kvx
              rdat(ir,im,ih,0) = rdat(ir,im,ih,0) + rdat(ir,im,ih,iv)
            end do
          end do
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine rnynrm( rdat, krx1, knx1, khx, kvx, klcut )
!
      implicit none
      integer :: krx1, knx1, khx, kvx, klcut, ih, iv, in, ir
      real*8 :: rdat(krx1,knx1,0:khx,0:kvx), area
!....
      do iv = 1, kvx
      do ih = 1, khx
        do in = 1, knx1-1
          do ir = klcut, krx1-1
            area = 2.0d0 * ( ir - 0.5d0 )**2 * &
                   acos( -1.0d0 ) * 2.0d0 / ( knx1-1 )
            rdat(ir,in,ih,iv) = rdat(ir,in,ih,iv) / area
            rdat(ir,in,0,0) = rdat(ir,in,0,0) + rdat(ir,in,ih,iv)
          end do
          do ir = 1, klcut-1
            rdat(ir,in,ih,iv) = rdat(klcut,in,ih,iv)
            rdat(ir,in,0,0) = rdat(ir,in,0,0) + rdat(ir,in,ih,iv)
          end do
        end do
      end do
      end do
!..
      do in = 1, knx1-1
        do ir = 1, krx1-1
          do iv = 1, kvx
            do ih = 1, khx
              rdat(ir,in,0,iv) = rdat(ir,in,0,iv) + rdat(ir,in,ih,iv)
            end do
          end do
          do ih = 1, khx
            do iv = 1, kvx
              rdat(ir,in,ih,0) = rdat(ir,in,ih,0) + rdat(ir,in,ih,iv)
            end do
          end do
        end do
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine adistcalc( rdat, krx1, kmx1, khx, kvx, klcut, &
                            radis, raidis, kl, radisx )
!
      implicit none
      integer :: krx1, kmx1, khx, kvx, klcut, kl, im, ir
      real*8 :: rdat(krx1,kmx1,0:khx,0:kvx), radis(kl), raidis(kl), &
                radisx, wtmp, wtmp2
!....
      wtmp = 1.0d-10
      do im = 1, kl
         wtmp2 = 0.0d0
         do ir = klcut, krx1-1
            wtmp2 = wtmp2 + rdat(ir,im+kl,0,0)
         end do
         wtmp = max( wtmp, wtmp2 )
         radis(kl-im+1) = wtmp2
      end do
      do im = 1, kl
         radis(im) = radis(im) / wtmp
      end do
      radisx = wtmp
      raidis(1) = radis(1)
      do im = 2, kl
         raidis(im) = raidis(im-1) + radis(im)
      end do
      wtmp = max( 1.0d-10, raidis(kl) )
      do im = 1, kl
         raidis(im) = raidis(im) / wtmp
      end do
!....
      return
      end
!----------------------------------------------------------------------
      subroutine ionlabel( ki, ra, rz, elabel )
!
      implicit none
      integer :: ki, idig, ia, inext
      real*8 :: ra, rz
      character :: cform*8, elabel*(*)
!....
      elabel = '(#x,A=x,Z=x)'
      write( elabel(3:3), '(i1)' ) ki
!.
      idig = log10( ra ) + 1
      ia   = ra
      if( ra - ia .le. 1.0d-2 ) then
         cform = '(ix)'
         write( cform(3:3), '(i1)' ) idig
         write( elabel(7:6+idig), cform ) ia
         elabel(7+idig:9+idig) = ',Z='
         inext = 10+idig
      else
         cform = '(fx.1)'
         write( cform(3:3), '(i1)' ) idig+2
         write( elabel(7:8+idig), cform ) ra
         elabel(9+idig:11+idig) = ',Z='
         inext = 12+idig
      end if
!.
      idig = log10( rz ) + 1
      ia   = rz
      if( rz - ia .le. 1.0d-2 ) then
         cform = '(ix)'
         write( cform(3:3), '(i1)' ) idig
         write( elabel(inext:inext+idig-1), cform ) ia
         elabel(inext+idig:inext+idig) = ')'
      else
         cform = '(fx.1)'
         write( cform(3:3), '(i1)' ) idig+2
         write( elabel(inext:inext+idig+1), cform ) rz
         elabel(inext+idig+2:inext+idig+2) = ')'
      end if
!....
      return
      end
