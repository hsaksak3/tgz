c----------------------------------------------------------------------
c advance euler equations of gasdynamics with tvd scheme ( x/2 )
c                           /
      subroutine adv2dx ( rstep )
c
c   <arguments>
c     rstep : advance step
c
c   <remarks>
c     add eps to avoid zero pressure
c
c    coded by sakagami,h. ( isr ) 88/03/09
c modified by sakagami,h. ( isr ) 88/03/22 : kstep
c modified by sakagami,h. ( isr ) 88/04/13 : include file
c modified by sakagami,h. ( isr ) 91/04/25 : aeps
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
c....
      common /work/
     \  auu(lx1,ly), avv(lx1,ly), acc(lx1,ly), ahh(lx1,ly),
     \  alfa1(lx1,ly), alfa2(lx1,ly), alfa3(lx1,ly), alfa4(lx1,ly),
     \  abet1(lx1,ly), abet2(lx1,ly), abet3(lx1,ly), abet4(lx1,ly),
     \  anue1(lx1,ly), anue2(lx1,ly), anue3(lx1,ly), anue4(lx1,ly),
     \  aff1(lx1,ly), aff2(lx1,ly), aff3(lx1,ly), aff4(lx1,ly),
     \  ag1(lx1,ly), ag2(lx1,ly), ag3(lx1,ly), ag4(lx1,ly)
      data aeps / 1.0d-2 /
c....                     * set u^(j+1/2,k), v^(j+1/2,k), c^(j+1/2,k) *
      do 10 iy = 1, ly
      do 10 ix = 1, lx-1
         ah0 = ( de(ix  ,iy) + dp(ix  ,iy) ) / dr(ix  ,iy)
         ah1 = ( de(ix+1,iy) + dp(ix+1,iy) ) / dr(ix+1,iy)
c..
         auu(ix,iy) = ( sqrt( dr(ix  ,iy) ) * du(ix  ,iy) +
     \                  sqrt( dr(ix+1,iy) ) * du(ix+1,iy) )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         avv(ix,iy) = ( sqrt( dr(ix  ,iy) ) * dv(ix  ,iy) +
     \                  sqrt( dr(ix+1,iy) ) * dv(ix+1,iy) )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         ahh(ix,iy) = ( sqrt( dr(ix  ,iy) ) * ah0 +
     \                  sqrt( dr(ix+1,iy) ) * ah1 )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix+1,iy) ) )
         acc(ix,iy) = sqrt( ( dgam - 1.0d0 ) *
     \     ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) ) )
check    acc2       =       ( dgam - 1.0d0 ) *
check\     ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) )
check    if( acc2 .lt. 0.0d0 ) then
check       write(6,*) 'x cs lt 0 at ', ix, iy
check       write(6,*) 'r ', dr(ix,iy), dr(ix+1,iy), dr(ix,iy-1)
check       write(6,*) 'u ', du(ix,iy), du(ix+1,iy), du(ix,iy-1)
check       write(6,*) 'v ', dv(ix,iy), dv(ix+1,iy), dv(ix,iy-1)
check       write(6,*) 'e ', de(ix,iy), de(ix+1,iy), de(ix,iy-1)
check       write(6,*) 'p ', dp(ix,iy), dp(ix+1,iy), dp(ix,iy-1)
check       write(6,*) 'hh,uu,vv ', ahh(ix,iy), auu(ix,iy), avv(ix,iy)
check    end if
check    acc(ix,iy) = sqrt( acc2 )
   10 continue
c....                                          * set alfa(l)(j+1/2,k) *
      do 20 iy = 1, ly
      do 20 ix = 1, lx-1
         adr = dr(ix+1,iy) - dr(ix,iy)
         adm = dm(ix+1,iy) - dm(ix,iy)
         adn = dn(ix+1,iy) - dn(ix,iy)
         ade = de(ix+1,iy) - de(ix,iy)
c..
         if( acc(ix,iy)  .gt. dzero ) then
            ac1 = ( dgam - 1.0d0 ) *
     \         ( ade + 0.5d0 * adr * ( auu(ix,iy)**2 + avv(ix,iy)**2 )
     \     - ( adm * auu(ix,iy) + adn * avv(ix,iy) ) ) / acc(ix,iy)**2
            ac2 = ( adm - adr * auu(ix,iy) ) / acc(ix,iy)
c..
            alfa1(ix,iy) = 0.5d0 * ( ac1 - ac2 )
            alfa2(ix,iy) = adr - ac1
            alfa3(ix,iy) = adn - adr * avv(ix,iy)
            alfa4(ix,iy) = 0.5d0 * ( ac1 + ac2 )
         else
            alfa1(ix,iy) = 0.d0
            alfa2(ix,iy) = adr
            alfa3(ix,iy) = adn - adr * avv(ix,iy)
            alfa4(ix,iy) = 0.d0
         end if
   20 continue
c....                                               * nue(l)(j+1/2,k) *
      do 30 iy = 1, ly
      do 30 ix = 1, lx-1
         anue1(ix,iy) = auu(ix,iy) - acc(ix,iy)
         anue2(ix,iy) = auu(ix,iy)
         anue3(ix,iy) = auu(ix,iy)
         anue4(ix,iy) = auu(ix,iy) + acc(ix,iy)
   30 continue
c....                                                     * set ramda *
      if( dram .le. 0.0d0 ) then
         do 31 iy = 1, ly
         do 31 ix = 1, lx-1
            dram = max( dram,
     \         abs(auu(ix,iy))+acc(ix,iy), abs(avv(ix,iy))+acc(ix,iy) )
   31    continue
         dram = dmue / dram
      end if
c...
      ara2 = dram * rstep
c..
      do 32 iy = 1, ly
      do 32 ix = 1, lx-1
         anue1(ix,iy) = anue1(ix,iy) * ara2
         anue2(ix,iy) = anue2(ix,iy) * ara2
         anue3(ix,iy) = anue3(ix,iy) * ara2
         anue4(ix,iy) = anue4(ix,iy) * ara2
   32 continue
c....                                     * set g(l)(j+1/2,k),l=1,2,3 *
      do 40 iy = 1, ly
      do 40 ix = 2, lx-1
c..                                                           * l = 1 *
         if( alfa1(ix-1,iy) * alfa1(ix,iy) .gt. dzero2 ) then
            if( alfa1(ix,iy) .gt. 0.0d0 ) then
               ag1(ix,iy) = min( alfa1(ix-1,iy), alfa1(ix,iy) )
            else
               ag1(ix,iy) = max( alfa1(ix-1,iy), alfa1(ix,iy) )
            end if
         else
            ag1(ix,iy) = 0.0d0
         end if
c..                                                           * l = 2 *
         if( alfa2(ix-1,iy) * alfa2(ix,iy) .gt. dzero2 ) then
            if( alfa2(ix,iy) .gt. 0.0d0 ) then
               ag2(ix,iy) = min( alfa2(ix-1,iy), alfa2(ix,iy) )
            else
               ag2(ix,iy) = max( alfa2(ix-1,iy), alfa2(ix,iy) )
            end if
            aff2(ix,iy) = domga * abs( alfa2(ix,iy) - alfa2(ix-1,iy) )
     \                / ( abs( alfa2(ix,iy) ) + abs( alfa2(ix-1,iy) ) )
         else
            ag2(ix,iy)   = 0.0d0
            aff2(ix,iy) = 0.0d0
         end if
c..                                                           * l = 3 *
         if( alfa3(ix-1,iy) * alfa3(ix,iy) .gt. dzero2 ) then
            if( alfa3(ix,iy) .gt. 0.0d0 ) then
               ag3(ix,iy) = min( alfa3(ix-1,iy), alfa3(ix,iy) )
            else
               ag3(ix,iy) = max( alfa3(ix-1,iy), alfa3(ix,iy) )
            end if
            aff3(ix,iy) = domga * abs( alfa3(ix,iy) - alfa3(ix-1,iy) )
     \                / ( abs( alfa3(ix,iy) ) + abs( alfa3(ix-1,iy) ) )
         else
            ag3(ix,iy)   = 0.0d0
            aff3(ix,iy) = 0.0d0
         end if
c..                                                           * l = 4 *
         if( alfa4(ix-1,iy) * alfa4(ix,iy) .gt. dzero2 ) then
            if( alfa4(ix,iy) .gt. 0.0d0 ) then
               ag4(ix,iy) = min( alfa4(ix-1,iy), alfa4(ix,iy) )
            else
               ag4(ix,iy) = max( alfa4(ix-1,iy), alfa4(ix,iy) )
            end if
         else
            ag4(ix,iy) = 0.0d0
         end if
   40 continue
c....                       * set nue(l)(j+1/2,k) + gamma(l)(j+1/2,k) *
      do 50 iy = 1, ly
      do 50 ix = 2, lx-2
c.
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue1(ix,iy)**2 )
         abet1(ix,iy) = agg * ( ag1(ix+1,iy) + ag1(ix,iy) )
         if( abs( alfa1(ix,iy) ) .ge. dzero ) then
            anue1(ix,iy) = anue1(ix,iy) +
     \               agg * ( ag1(ix+1,iy) - ag1(ix,iy) ) / alfa1(ix,iy)
         end if
c.
         aq  = abs( anue2(ix,iy) )
         agg = 0.5d0 * ( aq - anue2(ix,iy)**2 )
     \                * ( 1.0d0 + max( aff2(ix+1,iy), aff2(ix,iy) ) )
         abet2(ix,iy) = agg * ( ag2(ix+1,iy) + ag2(ix,iy) )
         if( abs( alfa2(ix,iy) ) .ge. dzero ) then
            anue2(ix,iy) = anue2(ix,iy) +
     \               agg * ( ag2(ix+1,iy) - ag2(ix,iy) ) / alfa2(ix,iy)
         end if
c.
         aq  = abs( anue3(ix,iy) )
         agg = 0.5d0 * ( aq - anue3(ix,iy)**2 )
     \                * ( 1.0d0 + max( aff3(ix+1,iy), aff3(ix,iy) ) )
         abet3(ix,iy) = agg * ( ag3(ix+1,iy) + ag3(ix,iy) )
         if( abs( alfa3(ix,iy) ) .ge. dzero ) then
            anue3(ix,iy) = anue3(ix,iy) +
     \               agg * ( ag3(ix+1,iy) - ag3(ix,iy) ) / alfa3(ix,iy)
         end if
c.
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue4(ix,iy)**2 )
         abet4(ix,iy) = agg * ( ag4(ix+1,iy) + ag4(ix,iy) )
         if( abs( alfa4(ix,iy) ) .ge. dzero ) then
            anue4(ix,iy) = anue4(ix,iy) +
     \               agg * ( ag4(ix+1,iy) - ag4(ix,iy) ) / alfa4(ix,iy)
         end if
   50 continue
c....                                          * set beta(l)(j+1/2,k) *
      do 60 iy = 1, ly
      do 60 ix = 2, lx-2
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet1(ix,iy) = abet1(ix,iy) - aq * alfa1(ix,iy)
         aq = abs( anue2(ix,iy) )
         abet2(ix,iy) = abet2(ix,iy) - aq * alfa2(ix,iy)
         aq = abs( anue3(ix,iy) )
         abet3(ix,iy) = abet3(ix,iy) - aq * alfa3(ix,iy)
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet4(ix,iy) = abet4(ix,iy) - aq * alfa4(ix,iy)
   60 continue
c....                                  * set modified flux f(j+1/2,k) *
      do 70 iy = 1, ly
      do 70 ix = 2, lx-2
         aff1(ix,iy) = 0.5d0 * ( drfg(ix,iy) + drfg(ix+1,iy) +
     \          ( abet1(ix,iy) + abet2(ix,iy) + abet4(ix,iy) ) / ara2 )
         aff2(ix,iy) = 0.5d0 * ( dmfg(ix,iy) + dmfg(ix+1,iy) +
     \          ( abet1(ix,iy) * ( auu(ix,iy) - acc(ix,iy) ) +
     \            abet2(ix,iy) *   auu(ix,iy)                +
     \            abet4(ix,iy) * ( auu(ix,iy) + acc(ix,iy) ) ) / ara2 )
         aff3(ix,iy) = 0.5d0 * ( dnfg(ix,iy) + dnfg(ix+1,iy) +
     \    ( ( abet1(ix,iy)+abet2(ix,iy)+abet4(ix,iy) ) * avv(ix,iy) +
     \        abet3(ix,iy) ) / ara2 )
         aff4(ix,iy) = 0.5d0 * ( defg(ix,iy) + defg(ix+1,iy) +
     \ ( abet1(ix,iy) * ( ahh(ix,iy)-auu(ix,iy)*acc(ix,iy) ) +
     \   abet2(ix,iy) * 0.5d0 * ( auu(ix,iy)**2+avv(ix,iy)**2 ) +
     \   abet3(ix,iy) * avv(ix,iy)                              +
     \   abet4(ix,iy) * ( ahh(ix,iy)+auu(ix,iy)*acc(ix,iy) ) ) / ara2 )
   70 continue
c....                                                 * advance 1/2 x *
      do 80 iy = 1, ly
      do 80 ix = 3, lx-2
         dr(ix,iy) = dr(ix,iy) + ara2 * ( aff1(ix-1,iy) - aff1(ix,iy) )
         dm(ix,iy) = dm(ix,iy) + ara2 * ( aff2(ix-1,iy) - aff2(ix,iy) )
         dn(ix,iy) = dn(ix,iy) + ara2 * ( aff3(ix-1,iy) - aff3(ix,iy) )
         de(ix,iy) = de(ix,iy) + ara2 * ( aff4(ix-1,iy) - aff4(ix,iy) )
     \             + aeps
   80 continue
c....
      return
      end
