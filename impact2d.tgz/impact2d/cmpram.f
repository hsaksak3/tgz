c----------------------------------------------------------------------
c compute rambda
c
      subroutine cmpram
c
c   <arguments>
c     none
c
c   <remarks>
c     none
c
c    coded by sakagami,h. ( isr ) 91/06/05
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
c....                                                     * set ramda *
      dram = 0.0d0
      do 10 iy = 1, ly
      do 10 ix = 1, lx
         acc = sqrt( dgam * dp(ix,iy) / dr(ix,iy) )
         dram = max( dram, abs(du(ix,iy))+acc, abs(dv(ix,iy))+acc )
   10 continue
      dram = dmue / dram
c....
      return
      end
