c----------------------------------------------------------------------
c advance euler equations of gasdynamics with tvd scheme ( y )
c
      subroutine tvdady
c
c   <arguments>
c     none
c
c   <remarks>
c     add aeps to avoid zero pressure
c
c    coded by sakagami,h. ( isr ) 88/03/09
c modified by sakagami,h. ( isr ) 88/04/13 : include file
c modified by sakagami,h. ( isr ) 91/04/25 : aeps
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
c....
      common /work/
     \  auu(lx,ly1), avv(lx,ly1), acc(lx,ly1), ahh(lx,ly1),
     \  alfa1(lx,ly1), alfa2(lx,ly1), alfa3(lx,ly1), alfa4(lx,ly1),
     \  abet1(lx,ly1), abet2(lx,ly1), abet3(lx,ly1), abet4(lx,ly1),
     \  anue1(lx,ly1), anue2(lx,ly1), anue3(lx,ly1), anue4(lx,ly1),
     \  agg1(lx,ly1), agg2(lx,ly1), agg3(lx,ly1), agg4(lx,ly1),
     \  ag1(lx,ly1), ag2(lx,ly1), ag3(lx,ly1), ag4(lx,ly1)
      data aeps / 1.0d-2 /
c....                     * set u^(j,k+1/2), v^(j,k+1/2), c^(j,k+1/2) *
      do 10 iy = 1, ly-1
      do 10 ix = 1, lx
         ah0 = ( de(ix,iy  ) + dp(ix,iy  ) ) / dr(ix,iy)
         ah1 = ( de(ix,iy+1) + dp(ix,iy+1) ) / dr(ix,iy+1)
c..
         auu(ix,iy) = ( sqrt( dr(ix,iy  ) ) * du(ix,iy  ) +
     \                  sqrt( dr(ix,iy+1) ) * du(ix,iy+1) )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         avv(ix,iy) = ( sqrt( dr(ix,iy  ) ) * dv(ix,iy  ) +
     \                  sqrt( dr(ix,iy+1) ) * dv(ix,iy+1) )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         ahh(ix,iy) = ( sqrt( dr(ix,iy  ) ) * ah0 +
     \                  sqrt( dr(ix,iy+1) ) * ah1 )
     \                   / ( sqrt( dr(ix,iy) ) + sqrt( dr(ix,iy+1) ) )
         acc(ix,iy) = sqrt( ( dgam - 1.0d0 ) *
     \     ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) ) )
check    acc2       =       ( dgam - 1.0d0 ) *
check\     ( ahh(ix,iy) - 0.5d0 * ( auu(ix,iy)**2 + avv(ix,iy)**2 ) )
check    if( acc2 .lt. 0.0d0 ) then
check       write(6,*) 'y cs lt 0 at ', ix, iy, dr(ix,iy), dr(ix+1,iy)
check       write(6,*) ahh(ix,iy), auu(ix,iy), avv(ix,iy)
check    end if
check    acc(ix,iy) = sqrt( acc2 )
   10 continue
c....                                          * set alfa(l)(j,k+1/2) *
      do 20 iy = 1, ly-1
      do 20 ix = 1, lx
         adr = dr(ix,iy+1) - dr(ix,iy)
         adm = dm(ix,iy+1) - dm(ix,iy)
         adn = dn(ix,iy+1) - dn(ix,iy)
         ade = de(ix,iy+1) - de(ix,iy)
c..
         if( acc(ix,iy)  .gt. dzero ) then
            ac1 = ( dgam - 1.0d0 ) *
     \         ( ade + 0.5d0 * adr * ( auu(ix,iy)**2 + avv(ix,iy)**2 )
     \     - ( adm * auu(ix,iy) + adn * avv(ix,iy) ) ) / acc(ix,iy)**2
            ac2 = ( adn - adr * avv(ix,iy) ) / acc(ix,iy)
c..
            alfa1(ix,iy) = 0.5d0 * ( ac1 - ac2 )
            alfa2(ix,iy) = adr - ac1
            alfa3(ix,iy) = adm - adr * auu(ix,iy)
            alfa4(ix,iy) = 0.5d0 * ( ac1 + ac2 )
         else
            alfa1(ix,iy) = 0.d0
            alfa2(ix,iy) = adr
            alfa3(ix,iy) = adm - adr * auu(ix,iy)
            alfa4(ix,iy) = 0.d0
         end if
   20 continue
c....                                               * nue(l)(j,k+1/2) *
      do 30 iy = 1, ly-1
      do 30 ix = 1, lx
         anue1(ix,iy) = ( avv(ix,iy) - acc(ix,iy) ) * dram
         anue2(ix,iy) = ( avv(ix,iy)              ) * dram
         anue3(ix,iy) = ( avv(ix,iy)              ) * dram
         anue4(ix,iy) = ( avv(ix,iy) + acc(ix,iy) ) * dram
   30 continue
c....                                     * set g(l)(j,k+1/2),l=1,2,3 *
      do 40 iy = 2, ly-1
      do 40 ix = 1, lx
c..                                                           * l = 1 *
         if( alfa1(ix,iy-1) * alfa1(ix,iy) .gt. dzero2 ) then
            if( alfa1(ix,iy) .gt. 0.0d0 ) then
               ag1(ix,iy) = min( alfa1(ix,iy-1), alfa1(ix,iy) )
            else
               ag1(ix,iy) = max( alfa1(ix,iy-1), alfa1(ix,iy) )
            end if
         else
            ag1(ix,iy) = 0.0d0
         end if
c..                                                           * l = 2 *
         if( alfa2(ix,iy-1) * alfa2(ix,iy) .gt. dzero2 ) then
            if( alfa2(ix,iy) .gt. 0.0d0 ) then
               ag2(ix,iy) = min( alfa2(ix,iy-1), alfa2(ix,iy) )
            else
               ag2(ix,iy) = max( alfa2(ix,iy-1), alfa2(ix,iy) )
            end if
            agg2(ix,iy) = domga * abs( alfa2(ix,iy) - alfa2(ix,iy-1) )
     \                / ( abs( alfa2(ix,iy) ) + abs( alfa2(ix,iy-1) ) )
         else
            ag2(ix,iy)  = 0.0d0
            agg2(ix,iy) = 0.0d0
         end if
c..                                                           * l = 3 *
         if( alfa3(ix,iy-1) * alfa3(ix,iy) .gt. dzero2 ) then
            if( alfa3(ix,iy) .gt. 0.0d0 ) then
               ag3(ix,iy) = min( alfa3(ix,iy-1), alfa3(ix,iy) )
            else
               ag3(ix,iy) = max( alfa3(ix,iy-1), alfa3(ix,iy) )
            end if
            agg3(ix,iy) = domga * abs( alfa3(ix,iy) - alfa3(ix,iy-1) )
     \                / ( abs( alfa3(ix,iy) ) + abs( alfa3(ix,iy-1) ) )
         else
            ag3(ix,iy)  = 0.0d0
            agg3(ix,iy) = 0.0d0
         end if
c..                                                           * l = 4 *
         if( alfa4(ix,iy-1) * alfa4(ix,iy) .gt. dzero2 ) then
            if( alfa4(ix,iy) .gt. 0.0d0 ) then
               ag4(ix,iy) = min( alfa4(ix,iy-1), alfa4(ix,iy) )
            else
               ag4(ix,iy) = max( alfa4(ix,iy-1), alfa4(ix,iy) )
            end if
         else
            ag4(ix,iy) = 0.0d0
         end if
   40 continue
c....                       * set nue(l)(j,k+1/2) + gamma(l)(j,k+1/2) *
      do 50 iy = 2, ly-2
      do 50 ix = 1, lx
c.
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue1(ix,iy)**2 )
         abet1(ix,iy) = agg * ( ag1(ix,iy+1) + ag1(ix,iy) )
         if( abs( alfa1(ix,iy) ) .ge. dzero ) then
            anue1(ix,iy) = anue1(ix,iy) +
     \               agg * ( ag1(ix,iy+1) - ag1(ix,iy) ) / alfa1(ix,iy)
         end if
c.
         aq  = abs( anue2(ix,iy) )
         agg = 0.5d0 * ( aq - anue2(ix,iy)**2 )
     \                * ( 1.0d0 + max( agg2(ix,iy+1), agg2(ix,iy) ) )
         abet2(ix,iy) = agg * ( ag2(ix,iy+1) + ag2(ix,iy) )
         if( abs( alfa2(ix,iy) ) .ge. dzero ) then
            anue2(ix,iy) = anue2(ix,iy) +
     \               agg * ( ag2(ix,iy+1) - ag2(ix,iy) ) / alfa2(ix,iy)
         end if
c.
         aq  = abs( anue3(ix,iy) )
         agg = 0.5d0 * ( aq - anue3(ix,iy)**2 )
     \                * ( 1.0d0 + max( agg3(ix,iy+1), agg3(ix,iy) ) )
         abet3(ix,iy) = agg * ( ag3(ix,iy+1) + ag3(ix,iy) )
         if( abs( alfa3(ix,iy) ) .ge. dzero ) then
            anue3(ix,iy) = anue3(ix,iy) +
     \               agg * ( ag3(ix,iy+1) - ag3(ix,iy) ) / alfa3(ix,iy)
         end if
c.
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) /(2.0d0*deps)
         agg = 0.5d0 * ( aq - anue4(ix,iy)**2 )
         abet4(ix,iy) = agg * ( ag4(ix,iy+1) + ag4(ix,iy) )
         if( abs( alfa4(ix,iy) ) .ge. dzero ) then
            anue4(ix,iy) = anue4(ix,iy) +
     \               agg * ( ag4(ix,iy+1) - ag4(ix,iy) ) / alfa4(ix,iy)
         end if
   50 continue
c....                                          * set beta(l)(j,k+1/2) *
      do 60 iy = 2, ly-2
      do 60 ix = 1, lx
         aq = abs( anue1(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet1(ix,iy) = abet1(ix,iy) - aq * alfa1(ix,iy)
         aq = abs( anue2(ix,iy) )
         abet2(ix,iy) = abet2(ix,iy) - aq * alfa2(ix,iy)
         aq = abs( anue3(ix,iy) )
         abet3(ix,iy) = abet3(ix,iy) - aq * alfa3(ix,iy)
         aq = abs( anue4(ix,iy) )
         if( aq .lt. deps ) aq = ( aq*aq + deps*deps ) / ( 2.0d0*deps )
         abet4(ix,iy) = abet4(ix,iy) - aq * alfa4(ix,iy)
   60 continue
c....                                  * set modified flux g(j,k+1/2) *
      do 70 iy = 2, ly-2
      do 70 ix = 1, lx
         agg1(ix,iy) = 0.5d0 * ( drfg(ix,iy) + drfg(ix,iy+1) +
     \          ( abet1(ix,iy) + abet2(ix,iy) + abet4(ix,iy) ) / dram )
         agg2(ix,iy) = 0.5d0 * ( dmfg(ix,iy) + dmfg(ix,iy+1) +
     \    ( ( abet1(ix,iy)+abet2(ix,iy)+abet4(ix,iy) ) * auu(ix,iy) +
     \        abet3(ix,iy) ) / dram )
         agg3(ix,iy) = 0.5d0 * ( dnfg(ix,iy) + dnfg(ix,iy+1) +
     \          ( abet1(ix,iy) * ( avv(ix,iy) - acc(ix,iy) ) +
     \            abet2(ix,iy) *   avv(ix,iy)                +
     \            abet4(ix,iy) * ( avv(ix,iy) + acc(ix,iy) ) ) / dram )
         agg4(ix,iy) = 0.5d0 * ( defg(ix,iy) + defg(ix,iy+1) +
     \ ( abet1(ix,iy) * ( ahh(ix,iy)-avv(ix,iy)*acc(ix,iy) ) +
     \   abet2(ix,iy) * 0.5d0 * ( auu(ix,iy)**2+avv(ix,iy)**2 ) +
     \   abet3(ix,iy) * auu(ix,iy)                              +
     \   abet4(ix,iy) * ( ahh(ix,iy)+avv(ix,iy)*acc(ix,iy) ) ) / dram )
   70 continue
c....                                                     * advance y *
      do 80 iy = 3, ly-2
      do 80 ix = 1, lx
         dr(ix,iy) = dr(ix,iy) + dram * ( agg1(ix,iy-1) - agg1(ix,iy) )
         dm(ix,iy) = dm(ix,iy) + dram * ( agg2(ix,iy-1) - agg2(ix,iy) )
         dn(ix,iy) = dn(ix,iy) + dram * ( agg3(ix,iy-1) - agg3(ix,iy) )
         de(ix,iy) = de(ix,iy) + dram * ( agg4(ix,iy-1) - agg4(ix,iy) )
     \             + aeps
   80 continue
c....
      return
      end
