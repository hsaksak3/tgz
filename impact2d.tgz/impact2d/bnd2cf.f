c----------------------------------------------------------------------
c boundary condition
c
      subroutine bnd2cf
c
c   <arguments>
c     none
c
c   <remarks>
c     free boundary is set by (1,1) direction values.
c
c    coded by sakagami,h. ( isr ) 91/03/13
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
      dimension ix1(2), ix2(2), ix3(2), iy1(2), iy2(2), iy3(2)
      data ix1, ix2, ix3 / 2, lx1,   1, lx,   3, lx2 /
      data iy1, iy2, iy3 / 2, ly1,   1, ly,   3, ly2 /
c....
      do 10 iy = 1, 2
      do 10 ix = 1, 2
         dr(ix1(ix),iy1(iy)) = dr(ix3(ix),iy3(iy))
         dr(ix2(ix),iy2(iy)) = dr(ix3(ix),iy3(iy))
         dm(ix1(ix),iy1(iy)) = dm(ix3(ix),iy3(iy))
         dm(ix2(ix),iy2(iy)) = dm(ix3(ix),iy3(iy))
         dn(ix1(ix),iy1(iy)) = dn(ix3(ix),iy3(iy))
         dn(ix2(ix),iy2(iy)) = dn(ix3(ix),iy3(iy))
         de(ix1(ix),iy1(iy)) = de(ix3(ix),iy3(iy))
         de(ix2(ix),iy2(iy)) = de(ix3(ix),iy3(iy))
   10 continue
c....
      do 20 iy = 1, ly
      do 20 ix = 1, lx
c..
         if( ( ix .ge. 3 .and. ix .le. lx2 ) .and.
     \       ( iy .ge. 3 .and. iy .le. ly2 ) ) go to 20
c.
         if( ix .eq. iy ) go to 20
         if( ix .eq. ( ly - iy + 1 ) ) go to 20
c..
         arad = sqrt( ( ix - dxo )**2 + ( iy - dyo )**2 )
         add = arad / sqrt( 2.0d0 ) + dxo
         idd = add
         ad2 = add - idd
         ad1 = 1.0d0 - ad2
c..
         ar1 = dr(idd,idd)
         ar2 = dr(idd+1,idd+1)
         au1 = ( ( dm(idd,idd) + dn(idd,idd) ) / dr(idd,idd)
     \          ) / 2.0d0 * sqrt( 2.0d0 )
         au2 = ( ( dm(idd+1,idd+1)+dn(idd+1,idd+1) ) / dr(idd+1,idd+1)
     \          ) / 2.0d0 * sqrt( 2.0d0 )
         aruu1 = ar1 * au1 ** 2
         aruu2 = ar2 * au2 ** 2
         ae1 = de(idd,idd)
         ae2 = de(idd+1,idd+1)
c..
         dr(ix,iy) = ar1*ad1 + ar2*ad2
c.
         de(ix,iy) = ae1*ad1 + ae2*ad2
c.
         if( ix - dxo .eq. 0.0d0 .and. iy - dyo .eq. 0.0d0 ) then
            avel = 0.0
            athe = 0.0
         else
            auu = au1*ad1 + au2*ad2
            avel = sqrt( ( aruu1*ad1 + aruu2*ad2 ) / dr(ix,iy) )
            avel = sign( avel, auu )
            if( ix - dxo .eq. 0.0d0 .and. iy - dyo .eq. 0.0d0 ) then
               athe = 0.0d0
            else
               athe = atan2( iy - dyo, ix - dxo )
            end if
         end if
         dm(ix,iy) = avel * cos( athe ) * dr(ix,iy)
         dn(ix,iy) = avel * sin( athe ) * dr(ix,iy)
   20 continue
c....
      return
      end
