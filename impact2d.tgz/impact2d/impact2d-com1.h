      common /i2dcom1/
     \  dgam, dmue, dram, deps, dzero, dzero2, domga, dkapc, dflmt,
     \  dr(lx,ly), dp(lx,ly), de(lx,ly), dte(lx,ly),
     \  du(lx,ly), dm(lx,ly), dv(lx,ly), dn(lx,ly),
     \  drfg(lx,ly), dmfg(lx,ly), dnfg(lx,ly), defg(lx,ly),
     \  dmil(ly), dmir(ly), dnib(lx), dnit(lx), ddltx,
     \  dgrav, dgamp, dgk, dgo, dtime
