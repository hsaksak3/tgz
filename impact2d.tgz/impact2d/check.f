c----------------------------------------------------------------------
c check density
c
      subroutine check
c
c   <arguments>
c     none
c
c   <remarks>
c     none
c
c    coded by sakagami,h. ( isr ) 88/07/21
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
c....
      do 10 iy = 1, ly
      do 10 ix = 1, lx
         if( dr(ix,iy) .le. 0.0d0 ) then
            write(6,*) ' dr .lt. 0 ', ix, iy, dr(ix,iy)
            dr(ix,iy) = 1.0d-12
            dm(ix,iy) = 0.0d0
            dn(ix,iy) = 0.0d0
            de(ix,iy) = 0.0d0
         end if
         if( dp(ix,iy) .lt. 0.0d0 ) then
            write(6,*) ' dp .lt. 0 ', ix, iy, dp(ix,iy)
            dp(ix,iy) = 1.0d-12
            de(ix,iy) = dp(ix,iy) / ( dgam - 1.0d0 ) +
     \        0.5d0 * ( dm(ix,iy) * du(ix,iy) + dn(ix,iy) * dv(ix,iy) )
         end if
         if( de(ix,iy) .lt. 0.0d0 ) then
            write(6,*) ' de .lt. 0 ', ix, iy, de(ix,iy)
         end if
   10 continue
c....
      return
      end
