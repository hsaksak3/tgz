c----------------------------------------------------------------------
c main program of impact-2d for self-similar solution
c
c   <remarks>
c     none
c
c    coded by sakagami,h. ( isr ) 91/02/16
c modified by sakagami,h. ( isr ) 91/06/06 : time step control
c modified by sakagami,h. ( isr ) 92/01/21 : self-similar initial
c modified by sakagami,h. ( isr ) 92/02/04 : outer rho factor
c modified by sakagami,h. ( isr ) 92/03/13 : exp --> cos
c----------------------------------------------------------------------
      include "implicit.h"
      include "impact2d-param.h"
      include "impact2d-com1.h"
c....
      character*1 cname
c....
      namelist /param/ dgam, dmue, deps, domga, dflmt, astr, aint,
     \                 atot, ddltx, dgrav, atime0, athcnf,
     \                 imode, amp, aph, atfac, abndw,
     \                 af0, adf0, aorf
c....
      dgam = 5.0d0 / 3.0d0
      dmue = 0.95d0
      deps = 0.2d0
      domga = 2.0d0
      dflmt = 0.6d0
      dzero = 1.0d-6
      dzero2 = 1.0d-15
      dgrav  = 0.0d0
c..
      ddltx  = 1.0d0
c..
      athcnf = 1.0d0
c.
      aan = 1.0d0
      azn = 1.0d0
      acl = 10.0d0
c.
      adl = 0.095d0 * ( azn + 0.24d0 ) / ( 1.0d0 + 0.24d0 * azn )
c..
      astr   = 0.0d0
      aint   = 1.0d0
      atot   = 10.0d0
      atime0 = 0.0d0
c.
      imode = 0
      amp   = 0.0d0
      aph   = 0.0d0
      abndw = 1.0d0
      atfac = 1.0d0
c.
      arf = 15.0d0
      arp = 150.0d0
      arc = 25.0d0
      ars = 40.0d0
      atau = 0.25d0
      ap0 = 12500.0d0
      af0 = 2.0d0
      aorf = 0.01d0
      adf0 = 3.80468d0
      abeta = atau**2 * ap0 / ( arp * ars**2 ) * 100.0d0
      api2 = acos( -1.0d0 ) / 2.0d0
c..
      ioxs = 1
      ioxe = lx
      ioys = 1
      ioye = ly
      iodl = 1
      iocn = 0
c....
      read( 5, param )
      write( 6, param )
c....
      arff = arf / af0**2
      arpp = arp / af0**2
      ap00 = ap0 / af0**(2.0d0*dgam)
      aps   = ap0 * ( 1.0d0 - 1.0d0/(2.0d0*abeta) *
     \        ( 1.0d0 + ((arf/arp)-1.0d0)*(arc/ars)**2 ) )
      apsp0 = aps / ap0
c....
      adltt = 0.1d0 * ddltx
      atfac = 3.0d0 * amp
c.
      dkapc = adl * 3.29208d-4 / ( azn * acl * ddltx ) * athcnf
c...                                                    * initial set *
      do 10 iy = 1, ly
         ay = iy - dyo
         do 10 ix = 1, lx
            ax = ix - dxo
            arr = sqrt( ax**2 + ay**2 ) * ddltx / af0
            if( ax .eq. 0.0d0 .and. ay .eq. 0.0d0 ) then
               atheta = 0.0d0
            else
               atheta = atan2( ay, ax )
            end if
cexp        apert = amp * sin( imode * atheta + aph )
cexp \                  * exp( -abs( ( arr - arc ) * atfac * af0 ) )
            if( abs( arr - arc ) .le. atfac ) then
               arrr = ( arr - arc ) / atfac * acos( -1.0d0 )
               apert = amp * sin( imode * atheta + aph )
     \                     * ( cos( arrr ) + 1.0d0 ) / 2.0d0
               arr = arr + apert
            end if
c..
            if( arr .gt. arc + abndw ) then
               if( arr .gt. ars ) then
                  dr(ix,iy) = arff * aorf
                  dp(ix,iy) = ap00 * ( 1.0d0 - 1.0d0/(2.0d0*abeta) *
     \        ( 1.0d0 + ((arf/arp)-1.0d0)*(arc/ars)**2 ) )
               else
                  dr(ix,iy) = arpp
                  dp(ix,iy) = ap00 * ( 1.0d0 - 1.0d0/(2.0d0*abeta) *
     \    ( ((arr-abndw)/ars)**2 + ((arf/arp)-1.0d0)*(arc/ars)**2 ) )
               end if
            else if( arr .lt. arc - abndw ) then
               dr(ix,iy) = arff
               dp(ix,iy) = ap00 * ( 1.0d0 - 1.0d0/(2.0d0*abeta) *
     \                       (arf/arp) * ((arr+abndw)/ars)**2 )
            else
               afac =
     \          ( cos((1.0d0-(arr-arc)/abndw)*api2) + 1.0d0 ) / 2.0d0
               dr(ix,iy) = arff + ( arpp - arff ) * afac
               dp(ix,iy) = ap00 * ( 1.0d0 - 1.0d0/(2.0d0*abeta) *
     \                       (arf/arp) * (arc/ars)**2 )
            end if
c..
            avel = - arr * adf0 * 0.1d0
            if( arr .gt. ars ) avel = - ars * adf0 * 0.1d0
            du(ix,iy) = avel * cos( atheta )
            dv(ix,iy) = avel * sin( atheta )
   10 continue
c....
    1 continue
c....                                               * read parameters *
      read( 5, *, end=2 ) cname, ixn, ixx, iyn, iyx, aval
c..
      if( cname .eq. 'r' ) then
         if( abs( aval ) .le. dzero ) then
            read( 8 ) ( ( dr(ix,iy), ix=ixn,ixx ), iy=iyn,iyx )
         else
            do 20 iy = iyn, iyx
            do 20 ix = ixn, ixx
               dr(ix,iy) = aval
   20       continue
         end if
c..
      else if( cname .eq. 'u' ) then
         if( abs( aval ) .le. dzero ) then
            read( 8 ) ( ( du(ix,iy), ix=ixn,ixx ), iy=iyn,iyx )
         else
            do 21 iy = iyn, iyx
            do 21 ix = ixn, ixx
               du(ix,iy) = aval
   21       continue
         end if
c..
      else if( cname .eq. 'v' ) then
         if( abs( aval ) .le. dzero ) then
            read( 8 ) ( ( dv(ix,iy), ix=ixn,ixx ), iy=iyn,iyx )
         else
            do 22 iy = iyn, iyx
            do 22 ix = ixn, ixx
               dv(ix,iy) = aval
   22       continue
         end if
c..
      else if( cname .eq. 'p' ) then
         if( abs( aval ) .le. dzero ) then
            read( 8 ) ( ( dp(ix,iy), ix=ixn,ixx ), iy=iyn,iyx )
         else
            do 23 iy = iyn, iyx
            do 23 ix = ixn, ixx
               dp(ix,iy) = aval
   23       continue
         end if
c..
      else if( cname .eq. 'o' ) then
         ioxs = ixn
         ioxe = ixx
         ioys = iyn
         ioye = iyx
         iodl = aval + 0.1d0
      end if
c....
      go to 1
c....
    2 continue
c...                                                        * initial *
      do 30 iy = 1, ly
      do 30 ix = 1, lx
         dm(ix,iy) = du(ix,iy) * dr(ix,iy)
         dn(ix,iy) = dv(ix,iy) * dr(ix,iy)
         de(ix,iy) = dp(ix,iy) / ( dgam - 1.0d0 ) +
     \        0.5d0 * ( dm(ix,iy) * du(ix,iy) + dn(ix,iy) * dv(ix,iy) )
         dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy) * 0.5d0
   30 continue
c..
      do 31 iy = 1, ly
         dmil(iy) = dm(3   ,iy)
         dmir(iy) = dm(lx-2,iy)
   31 continue
      do 32 ix = 1, lx
         dnib(ix) = dn(ix,3   )
         dnit(ix) = dn(ix,ly-2)
   32 continue
c....
      atime = atime0
      atot  = atot - dzero
      if( astr - dzero .gt. atime0 ) then
         alapt = - ( astr - atime0 ) + aint
      else
         alapt = 0.0d0
      end if
      istep = 0
      iobs = 0
      ioxl = ( ioxe - ioxs ) / iodl + 1
      ioyl = ( ioye - ioys ) / iodl + 1
      amesh = ddltx * iodl
c....
      write(6,*) 'time = ', atime
      write(10) ioxl, ioyl, amesh
      write(11) ioxl, ioyl, amesh
      write(12) ioxl, ioyl, amesh
      write(13) ioxl, ioyl, amesh
c.
      write(10) atime,
     \          ( ( dr(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(11) atime,
     \          ( ( dp(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(12) atime,
     \          ( ( du(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(13) atime,
     \          ( ( dv(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      iocn = iocn + 1
c....
   90 continue
c..
      call cmpram
      alapt = alapt + dram * adltt
      if( alapt .gt. aint ) then
         dram = ( aint - ( alapt - dram * adltt ) ) / adltt
         iobs = 1
      end if
c...                                                    * advance x/2 *
      do 40 iy = 1, ly
      do 40 ix = 1, lx
         drfg(ix,iy) = dm(ix,iy)
         dmfg(ix,iy) = dm(ix,iy) * du(ix,iy) + dp(ix,iy)
         dnfg(ix,iy) = dm(ix,iy) * dv(ix,iy)
         defg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * du(ix,iy)
   40 continue
c..
      call adv2dx ( 0.5d0 )
      call bnd2cf
c\\\\
      call check
c\\\\
c..
      do 41 iy = 1, ly
      do 41 ix = 1, lx
         du(ix,iy) = dm(ix,iy) / dr(ix,iy)
         dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
         dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) -
     \        0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
         dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy) * 0.5d0
   41 continue
c...                                                      * advance y *
      do 50 iy = 1, ly
      do 50 ix = 1, lx
         drfg(ix,iy) = dn(ix,iy)
         dmfg(ix,iy) = dn(ix,iy) * du(ix,iy)
         dnfg(ix,iy) = dn(ix,iy) * dv(ix,iy) + dp(ix,iy)
         defg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * dv(ix,iy)
   50 continue
c..
      call tvdady
      call bnd2cf
c\\\\
      call check
c\\\\
c..
      do 51 iy = 1, ly
      do 51 ix = 1, lx
         du(ix,iy) = dm(ix,iy) / dr(ix,iy)
         dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
         dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) -
     \        0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
         dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy) * 0.5d0
   51 continue
c...
      atime = atime + dram * adltt
      istep = istep + 1
c....
   91 continue
      if( iobs .eq. 1 ) go to 92
c...
         call cmpram
         alapt = alapt + dram * adltt
         if( alapt .gt. aint ) then
            dram = ( aint - ( alapt - dram * adltt ) ) / adltt
            iobs = 1
         end if
c...                                                      * advance x *
         do 60 iy = 1, ly
         do 60 ix = 1, lx
            drfg(ix,iy) = dm(ix,iy)
            dmfg(ix,iy) = dm(ix,iy) * du(ix,iy) + dp(ix,iy)
            dnfg(ix,iy) = dm(ix,iy) * dv(ix,iy)
            defg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * du(ix,iy)
   60    continue
c..
         call adv2dx ( 1.0d0 )
         call bnd2cf
c\\\\
         call check
c\\\\
c..
         do 61 iy = 1, ly
         do 61 ix = 1, lx
            du(ix,iy) = dm(ix,iy) / dr(ix,iy)
            dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
            dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) -
     \        0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
            dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy)*0.5d0
   61    continue
c...                                                      * advance y *
         do 70 iy = 1, ly
         do 70 ix = 1, lx
            drfg(ix,iy) = dn(ix,iy)
            dmfg(ix,iy) = dn(ix,iy) * du(ix,iy)
            dnfg(ix,iy) = dn(ix,iy) * dv(ix,iy) + dp(ix,iy)
            defg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * dv(ix,iy)
   70    continue
c..
         call tvdady
         call bnd2cf
c\\\\
         call check
c\\\\
c..
         do 71 iy = 1, ly
         do 71 ix = 1, lx
            du(ix,iy) = dm(ix,iy) / dr(ix,iy)
            dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
            dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) -
     \        0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
            dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy)*0.5d0
   71    continue
c....
         atime = atime + dram * adltt
         istep = istep + 1
c....
      go to 91
c....
   92 continue
c...                                                    * advance x/2 *
      do 80 iy = 1, ly
      do 80 ix = 1, lx
         drfg(ix,iy) = dm(ix,iy)
         dmfg(ix,iy) = dm(ix,iy) * du(ix,iy) + dp(ix,iy)
         dnfg(ix,iy) = dm(ix,iy) * dv(ix,iy)
         defg(ix,iy) = ( de(ix,iy) + dp(ix,iy) ) * du(ix,iy)
   80 continue
c..
      call adv2dx ( 0.5d0 )
      call bnd2cf
c\\\\
      call check
c\\\\
c..
      do 81 iy = 1, ly
      do 81 ix = 1, lx
         du(ix,iy) = dm(ix,iy) / dr(ix,iy)
         dv(ix,iy) = dn(ix,iy) / dr(ix,iy)
         dp(ix,iy) = ( dgam - 1.0d0 ) * ( de(ix,iy) -
     \        0.5d0 * ( dm(ix,iy)*du(ix,iy) + dn(ix,iy)*dv(ix,iy) ) )
         dte(ix,iy) = 1.03642d0 * aan * dp(ix,iy) / dr(ix,iy) * 0.5d0
   81 continue
c....
      write(6,*) 'time = ', atime
      write(10) atime,
     \          ( ( dr(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(11) atime,
     \          ( ( dp(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(12) atime,
     \          ( ( du(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      write(13) atime,
     \          ( ( dv(ix,iy),ix=ioxs,ioxe,iodl ),iy=ioys,ioye,iodl )
      iocn = iocn + 1
c....
      alapt = 0.0d0
      iobs = 0
      if( atime .le. atot ) go to 90
c....
      write(6,*) 'total step        = ', istep
      write(6,*) 'output data count = ', iocn
      stop
      end
