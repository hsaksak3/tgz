implicit none
integer, parameter :: ltx = 2000
integer*8 :: ipid, ipids
integer :: i, itc, ips, itl
integer :: idata(3,ltx)
real*8 :: sx(ltx), sy(ltx), sz(ltx)
real*8 :: svx(ltx), svy(ltx), svz(ltx)
real*8 :: sux(ltx), suy(ltx), suz(ltx)
real*8 :: sfx(ltx), sfy(ltx), sfz(ltx)
character :: chead*5
!
itl = 0
idata(:,:) = -1
!
read(*,*) chead, ipids, itc, ips, i
write(*,*) 'pid =', ipids
itl = max( itl, itc )
idata(1,itc) = itc
idata(2,itc) = ips
idata(3,itc) = i
read(*,*) chead, sx(itc), sy(itc), sz(itc)
read(*,*) chead, svx(itc), svy(itc), svz(itc)
read(*,*) chead, sux(itc), suy(itc), suz(itc)
read(*,*) chead, sfx(itc), sfy(itc), sfz(itc)
!
1 continue
  read(*,*,end=9) chead, ipid, itc, ips, i
  if( ipid .ne. ipids ) then
     write(*,*) '### ERROR: pid =', ipids, ipid
     stop
  end if
  itl = max( itl, itc )
  idata(1,itc) = itc
  idata(2,itc) = ips
  idata(3,itc) = i
  read(*,*) chead, sx(itc), sy(itc), sz(itc)
  read(*,*) chead, svx(itc), svy(itc), svz(itc)
  read(*,*) chead, sux(itc), suy(itc), suz(itc)
  read(*,*) chead, sfx(itc), sfy(itc), sfz(itc)
  go to 1
9 continue
do i = 1, itl
  write(*,*) idata(1,i), idata(2,i), idata(3,i)
  write(*,*) sx(i), sy(i), sz(i)
  write(*,*) svx(i), svy(i), svz(i)
  write(*,*) sux(i), suy(i), suz(i)
  write(*,*) sfx(i), sfy(i), sfz(i)
end do
!
stop
end
