      use parameter, only:lionspx
      implicit none
      integer, parameter :: iun0 = 9
      integer :: i, ico, iunit, ixl, iyl, izl, ixyzl, ionl, &
                 ixps, iyps, ixpe, iype, izps, izpe, &
                 intx, inty, intz, ixn, iyn, izn, &
                 irank, icol, intt, idn, icnt
      real*8, allocatable :: awrk(:,:,:,:,:)
      real*8 :: wxps, wyps, wzps, wxpe, wype, wzpe, &
                wxmic, wx0, wymic, wy0, wzmic, wz0, &
                wts, wte, wtime, wteps=0.02d0, &
                aundef=-1.0d20, aundeff=-1.1d20, &
                aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, bident*16, clabel*20, &
                   cbifntp*64, cfrfntp*64, cfile*128, cttl(lionspx)*32
!.
      integer :: iun, ir, isize, ivoxel, &
                 ixas, ixae, ixal, iyas, iyae, iyal, izas, izae, izal
      integer :: idivx, idivy, idivz, ixals, iyals, izals, i0s
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:), &
                              izass(:), izaes(:), izans(:)
      real*8  :: wx0s, wy0s, wz0s
      real*8, allocatable :: afr1(:,:,:)
      character cidents*16, cidentd*16
!.
      real*8 :: slsrpw, wlsrpw=1.0d20, wamp
      real*8, allocatable :: feaAve(:),ax(:)
      integer :: ix,iy,iz,ifound
      integer, allocatable :: Num(:)
      character com*2, cform*23
!.
      namelist /param/ ckind, cbifntp, cfrfntp, cident, &
         irank, wts, wte, intt, &
         wxps, wxpe, wyps, wype, wzps, wzpe, intx, inty, intz, &
         slsrpw
!....
      ckind    = ' '
      cbifntp = 'fort.%%.###'
      cfrfntp = '&K-&I-%%.txt'
      cident  = ' '
      irank   = -1
      wts     = 0.0
      wte     = 9999.0
      intt    = 1
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      wzps    = aundeff
      wzpe    = aundeff
      intx    = 1
      inty    = 1
      intz    = 1
      slsrpw  = 1.0d20
      com=','
      cform='(f6.2,a1,i12,a1,es12.5)'
!..
      read(*,param)
      write(*,param)
!....
      select case( ckind )
      case( 'fea' )
         iun = 27
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fea'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!..
      i0s = 0
      ivoxel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      call fntpcnv ( cbifntp, ir-1, iun, cident, ckind, cfile )
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      select case( ckind(1:1) )
      case( 'f' ) 
         if( idn .ne. 0 ) then
            read(iunit) chead, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        irank, idivx, idivy, idivz, &
                        ixal, ixas, ixae, iyal, iyas, iyae, izal, izas, izae
            write(*,*) chead, ' ', bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        irank, idivx, idivy, idivz, &
                        ixal, ixas, ixae, iyal, iyas, iyae, izal, izas, izae
         else
            read(iunit) chead, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        idn, (aionam(i),aionaz(i),i=1,idn), &
                        irank, idivx, idivy, idivz, &
                        ixal, ixas, ixae, iyal, iyas, iyae, izal, izas, izae
            write(*,*) chead, bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       idn, (aionam(i),aionaz(i),i=1,idn), &
                        irank, idivx, idivy, idivz, &
                        ixal, ixas, ixae, iyal, iyas, iyae, izal, izas, izae
         end if
      end select
!
      if( ixyzl .ne. -1 ) then
        if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) .or. izl.ne.(izae-izas+1) ) then
           write(0,*) 'ERROR: data size mismatch', &
                      ixas,ixae,iyas,iyae,izas,izae
           stop
         end if
      end if
!.
         if( ir-1 .eq. 0 ) then
            isize = idivx * idivy * idivz
            ixals = ixal
            iyals = iyal
            izals = izal
            cidents = cidentd
            allocate( ixass(isize), ixaes(isize), ixans(isize), &
                      iyass(isize), iyaes(isize), iyans(isize), &
                      izass(isize), izaes(isize), izans(isize) )
         else if( ir .le. isize ) then
            if( cidentd .ne. cidents ) then
               write(0,*) 'ERROR: cident mismatch',cidents, cidentd
               stop
            end if
            if( ixal.ne.ixals .or. iyal.ne.iyals .or. izal.ne.izals) then
               write(0,*) 'ERROR: total size mismatch', &
                          ixal,ixals,iyal,iyals,izal,izals
               stop
            end if
         end if
!..
         if( i0s .eq. 0 .and. ixyzl .ne. -1 ) then
            wx0s = wx0
            wy0s = wy0
            wz0s = wz0
            i0s = 1
         end if
         ixass(ir) = ixas
         ixaes(ir) = ixae
         ixans(ir) = ixae - ixas + 1
         iyass(ir) = iyas
         iyaes(ir) = iyae
         iyans(ir) = iyae - iyas + 1
         izass(ir) = izas
         izaes(ir) = izae
         izans(ir) = izae - izas + 1
!..
         ivoxel = ivoxel + ixans(ir)*iyans(ir)*izans(ir)
      
!..
      if( ir .eq. isize ) exit
!..
      end do
!...
      if( ivoxel .ne. ixal*iyal*izal ) then
         write(0,*) '### ERROR: total #voxel mismatch', &
                       ivoxel,ixal,iyal,izal
         stop
      end if
!...      
      select case( ckind(1:1) )
!..
      case( 'f' ) 
      if( wxps .le. aundef ) then
         ixps = 1
      else
         ixps = ( wxps + wx0s ) / wxmic
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: invalid xps', wxps, ixps
            write(0,*) '###        : ixps is assumed as 1'
            ixps = 1
         end if
      end if
      if( wxpe .le. aundef ) then
         ixpe = ixl
      else
         ixpe = ( wxpe + wx0s ) / wxmic
         if( ixpe .gt. ixl ) then
            write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
            write(0,*) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
      end if
      if( ixps .gt. ixpe ) then
         write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
         stop
      end if
      if( wyps .le. aundef ) then
         iyps = 1
      else
         iyps = ( wyps + wy0s ) / wymic
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: invalid yps', wyps, iyps
            write(0,*) '###        : iyps is assumed as 1'
            iyps = 1
         end if
      end if
      if( wype .le. aundef ) then
         iype = iyl
      else
         iype = ( wype + wy0s ) / wymic
         if( iype .gt. iyl ) then
            write(0,*) '### WARNING: invalid ype', wype, iype
            write(0,*) '###        : iype is assumed as', iyl
            iype = iyl
         end if
      end if
      if( iyps .gt. iype ) then
         write(0,*) '### ERROR: yps gt ype', wyps, wype
         stop
      end if
      if( wzps .le. aundef ) then
         izps = 1
      else
         izps = ( wzps + wz0s ) / wzmic
         if( izps .lt. 1 ) then
            write(0,*) '### WARNING: invalid zps', wzps, izps
            write(0,*) '###        : izps is assumed as 1'
            izps = 1
         end if
      end if
      if( wzpe .le. aundef ) then
         izpe = izl
      else
         izpe = ( wzpe + wz0s ) / wzmic
         if( izpe .gt. izl ) then
            write(0,*) '### WARNING: invalid zpe', wzpe, izpe
            write(0,*) '###        : izpe is assumed as', izl
            izpe = izl
         end if
      end if
      if( izps .gt. izpe ) then
         write(0,*) '### ERROR: zps gt zpe', wzps, wzpe
         stop
      end if
!.
      ixn  = ( ixpe - ixps ) / intx + 1
      if( ixn .lt. 2 ) then
         write(0,*) '### ERROR: invalid x interval', &
	               ixps,ixpe,intx
         stop
      end if
      iyn  = ( iype - iyps ) / inty + 1
      if( iyn .lt. 2 ) then
         write(0,*) '### ERROR: invalid y interval', &
                       iyps,iype,inty
         stop
      end if
      izn  = ( izpe - izps ) / intz + 1
      if( izn .lt. 2 ) then
         write(0,*) '### ERROR: invalid z interval', &
                       izps,izpe,intz
         stop
      end if
!..
      wxps = ( ixps-1 ) * wxmic - wx0s
      wyps = ( iyps-1 ) * wymic - wy0s
      wzps = ( izps-1 ) * wzmic - wz0s
      wxpe = wxps + wxmic * intx * ( ixn - 1 )
      wype = wyps + wymic * inty * ( iyn - 1 )
      wzpe = wzps + wzmic * intz * ( izn - 1 )
      write(*,*) '----- ixps, ixpe, wxps, wxpe = ', ixps,ixpe,wxps,wxpe
      write(*,*) '----- iyps, iype, wyps, wype = ', iyps,iype,wyps,wype
      write(*,*) '----- izps, izpe, wzps, wzpe = ', izps,izpe,wzps,wzpe
      write(*,*) '----- ixn, iyn, izn = ', ixn, iyn, izn
!.
      if( ico .eq. 1 ) then
         allocate( afr1(ixal,iyal,izal) )
      !else
      !   allocate( afr1(ixal,iyal,izal), afr2(ixal,iyal,izal), &
      !             afr3(ixal,iyal,izal) )
      end if
!..
      end select
!...
      write(*,*) '----- header: ', chead, ', ident: ', bident
      if( cident .eq. ' ' ) then
         cident = bident
      else
         write(*,*) '----- used ident: ', cident
      end if
!.
!....
      wamp = slsrpw/wlsrpw
      allocate( Num(ixal), feaAve(ixal),ax(ixal) )
      do ix=1,ixal
         ax(ix)= wxmic*(ix-1)-wx0s
      end do
      icnt = 0
    1 continue
         do ir = 1, isize
!..
         iunit = iun0 + ir
!.
         select case( ckind(1:1) )
!.
         case( 'f' )
         do i = 1, idn
            if( ico .eq. 1 ) then
               if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 .and. izans(ir) .gt. 0 ) then
                  allocate( awrk( ico, ixans(ir),iyans(ir),izans(ir),idn ) )
                  read(iunit, end=99) wtime, awrk
                  afr1(ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),izass(ir):izaes(ir)) = &
                                                             awrk(1,:,:,:,i)
                  deallocate( awrk )
               end if
            end if
         end do
!.
         end select
!..
         end do
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!.
         write(*,*) '----- time = ', wtime
!...
         call fntpcnv ( cfrfntp, irank, icnt, cident, 'Frntpos', cfile ) 

Num(:)=0
feaAve(:)=0.0d0
do iz = 1, izal
   do iy = 1, iyal
      ifound = 0
      do ix = ixal, 2, -1
         if( afr1(ix,iy,iz) .ge. wamp )then
            Num(ix) = Num(ix)+1
            ifound = 1
            exit
         end if
      end do
      if( ifound .eq. 0 )Num(1) = Num(1)+1
   end do 
end do
do ix = 1, ixal
   do iz = 1, izal
      do iy = 1, iyal
         feaAve(ix)=feaAve(ix)+afr1(ix,iy,iz)
      end do
   end do
   feaAve(ix)=feaAve(ix)/(iyal*izal)
end do
open(7,file=cfile,form='FORMATTED')
write(7,*)cident, ',', wtime
write(7,*)'xpos[mic], distribution, feaAve[/1.0d20]'
do ix=1,ixal
   write(7,cform)ax(ix),com,Num(ix),com,feaAve(ix)
end do
close(7)
!
icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
