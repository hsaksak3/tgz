!----------------------------------------------------------------------
! binoh3plot: plot binary files of OhHelp version with Frames
!
! namelist param
!   ckind  : observation kind
!   ioflag : observation flag
!          : see ~/doc/observation file for details
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ../doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   cfrfntp: file name template for Frames file
!          : default is '&K-&I'
!   soxcrs : x coordinate of cross sections (default is center)
!   soycrs : y coordinate of cross sections (default is center)
!   sozcrs : z coordinate of cross sections (default is center)
!   soisov : isosurface electron density (1/Ncr) (default is 1)
!          : When ion, values are divided by each ion average Z.
! loslnu(1): number of x slices (YZ plane) (default is 1)
!          : if 0, not draw
! loslnu(2): number of y slices (XZ plane) (default is 1)
!          : if 0, not draw
! loslnu(3): number of z slices (XY plane) (default is 1)
!          : if 0, not draw
! sosltd(1): x coordinate of base slice (default is center)
! sosltd(2): y coordinate of base slice (default is center)
! sosltd(3): z coordinate of base slice (default is center)
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   wzps   : start z position (default is for all data)
!   wzpe   : end z position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!   intz   : data interval for z (default is 1)
!
!----------------------------------------------------------------------
      use parameter, only:lionspx, locrsx, loisox, &
                          lopemx, lopeex, lopimx, lopiex, lopephx
      implicit none
      integer, parameter :: iun0 = 9
      integer :: i, is, ico, idn, iunit, ixl, iyl, izl, ixyzl, intt, &
                 ixps, iyps, izps, ixpe, iype, izpe, intx, inty, intz, &
                 ioflag, ifrm, ilog, i3d, iso, icrxy, icryz, icrxz, &
                 irank, ixn, iyn, izn, il, icol, loslnu(3), ion
      real*8, allocatable :: awrk(:,:,:,:,:), &
                             afr1(:,:,:), afr2(:,:,:), afr3(:,:,:), &
                             wfct(:,:), wpos(:,:)
      real*8 :: soxcrs(locrsx), soycrs(locrsx), sozcrs(locrsx), &
                soisov(loisox), sosltd(3), woisov(loisox)
      real*8 :: wxps, wyps, wzps, wxpe, wype, wzpe, &
                wxmic, wx0, wymic, wy0, wzmic, wz0, &
                wts, wte, wtime, wteps=0.02d0, &
                aundef=-1.0d20, aundeff=-1.1d20, &
                aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, clabel*20, &
                   cbifntp*64, cfrfntp*64, cfile*128, cttl(lionspx)*32
!
      integer :: iun, ir, isize, ivoxel, &
                 ixas, ixae, ixal, iyas, iyae, iyal, izas, izae, izal
      integer :: idivx, idivy, idivz, ixals, iyals, izals, i0s
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:), &
                              izass(:), izaes(:), izans(:)
      real*8  :: wx0s, wy0s, wz0s
      real*8, allocatable :: gwrk(:,:,:,:,:)
      character cidents*16
!.
      namelist /param/ ckind, ioflag, cbifntp, cidentb, cfrfntp, &
         soxcrs, soycrs, sozcrs, soisov, loslnu, sosltd, &
         wts, wte, intt, &
         wxps, wxpe, wyps, wype, wzps, wzpe, intx, inty, intz
!....
      ckind   = ' '
      ioflag  = 111005
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cfrfntp = '&K-&I'
      do i = 1, loisox
         soisov(i) = 1.0d0
      end do  
      do i = 1, locrsx
         sozcrs(i) = aundeff 
         soxcrs(i) = aundeff 
         soycrs(i) = aundeff 
      end do  
      do i = 1, 3
         loslnu(i) = 1
         sosltd(i) = aundeff 
      end do  
      wts     = 0.0
      wte     = 999999.0
      intt    = 1
      wxps    = -1000.0
      wyps    = -1000.0
      wzps    = -1000.0
      wxpe    = 1000.0
      wype    = 1000.0
      wzpe    = 1000.0
      intx    = 1
      inty    = 1
      intz    = 1
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'pee' )
         iun = 20
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'pee'
      case( 'pie' )
         iun = 21
         ico = 1
         idn = 0
         ion = 1
         icol = 2
         cttl(1) = 'pie'
      case( 'pem' )
         iun = 22
         ico = 1
         idn = 1
         icol = 3
         cttl(1) = 'pem'
      case( 'pim' )
         iun = 23
         ico = 1
         idn = 0
         ion = 1
         icol = 4
         cttl(1) = 'pim'
      case( 'peph' )
         iun = 40
         ico = 3
         idn = 1
         icol = 3
         cttl(1) = 'peph'
      case( 'fde' )
         iun = 24
         ico = 1
         idn = 1
         icol = 3
         cttl(1) = 'fde'
      case( 'fdi' )
         iun = 25
         ico = 1
         idn = 0
         ion = 1
         icol = 3
         cttl(1) = 'fdi'
      case( 'fdc' )
         iun = 26
         ico = 1
         idn = 1
         icol = 2
         cttl(1) = 'fdc'
      case( 'fea' )
         iun = 27
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fea'
      case( 'fer' )
         iun = 28
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fe*r'
      case( 'fba' )
         iun = 29
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fba[MG]'
      case( 'fbr' )
         iun = 30
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fb*r[MG]'
      case( 'fje' )
         iun = 31
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fj*e'
      case( 'fji' )
         iun = 32
         ico = 3
         idn = 0
         ion = 1
         icol = 2
         cttl(1) = 'fj*i'
      case( 'fjt' )
         iun = 33
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fj*t'
      case( 'fte' )
         iun = 34
         ico = 1
         idn = 2
         icol = 1
         cttl(1) = 'fte[MeV]'
         cttl(2) = 'fpe[Gbar]'
      case( 'fede' )
         iun = 36
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fede'
      case( 'fedi' )
         iun = 37
         ico = 1
         idn = 0
         ion = 1
         icol = 1
         cttl(1) = 'fedi'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!....
      select case( ckind(1:1) )
      case( 'p' ) 
         ifrm  = mod( ioflag, 10 )
         ilog  = mod( ioflag/10, 10 )
         izl = max( lopemx, lopeex, lopimx, lopiex, lopephx )
         if( ckind(3:4) .eq. 'ph' ) then
            allocate( wpos(12,izl) )
         else
            allocate( wfct(izl,lionspx), wpos(6,izl) )
         end if
      case( 'f' ) 
         ifrm  = mod( ioflag, 10 )
         ilog  = mod( ioflag/10, 10 )
         i3d   = mod( ioflag/100, 10 )
         if( ckind .eq. 'fde' .or. ckind .eq. 'fdi' ) then
            iso = i3d / 2 
            i3d = mod( i3d, 2 )
         else
            iso = 0
         end if
         icrxy = mod( ioflag/1000, 10 )
         icryz = mod( ioflag/10000, 10 )
         icrxz = mod( ioflag/100000, 10 )
!
         if( iso+i3d+icrxy+icryz+icrxz .eq. 0 ) then
            write(0,*) '### ERROR: no plot', ioflag,  & 
                             iso, i3d, icrxy, icryz, icrxz
            stop
         end if
         if( iso .gt. loisox ) then
            write(0,*) '### ERROR: iso is greater than loisox.', ioflag
            stop
         end if
      end select
!..
      i0s = 0
      ivoxel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, ckind, cfile ) 
      end if
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      select case( ckind(1:1) )
      case( 'p' ) 
         if( ckind(3:4) .eq. 'ph' ) then
            read(iunit) chead, cident, ixl, iyl, izl, &
                        ( wpos(:,i),i=1,izl ), &
                        irank, idivx, idivy, idivz
            write(*,*) chead, ' ', cident, ixl, iyl, izl, &
                       ( wpos(:,i),i=1,izl ), &
                       irank, idivx, idivy, idivz
         else
            if( ion .eq. 0 ) then
               read(iunit) chead, cident, ixl, iyl, &
                           ( wfct(i,1),wpos(:,i),i=1,iyl ), &
                           irank, idivx, idivy, idivz
               write(*,*) chead, ' ', cident, ixl, iyl, &
                          ( wfct(i,1),wpos(:,i),i=1,iyl ), &
                          irank, idivx, idivy, idivz
            else
               read(iunit) chead, cident, ixl, iyl, idn, &
                           ( (aionam(is),aionaz(is),is=1,idn), &
                             wfct(i,1:idn),wpos(:,i),i=1,iyl ), &
                           irank, idivx, idivy, idivz
               write(*,*) chead, ' ', cident, ixl, iyl, idn, &
                          ( (aionam(is),aionaz(is),is=1,idn), &
                            wfct(i,1:idn),wpos(:,i),i=1,iyl ), &
                          irank, idivx, idivy, idivz
            end if
         end if
!
         if( ir-1 .eq. 0 ) then
            isize = idivx * idivy * idivz 
            cidents = cident
            if( ckind(3:4) .eq. 'ph' ) then
               allocate( awrk(ixl,iyl,izl,3,idn), &
                         gwrk(ixl,iyl,izl,3,idn) )
            else if( ckind(3:3) .eq. 'e' ) then
               allocate( awrk(ixl,iyl,idn,1,1), &
                         gwrk(ixl,iyl,idn,1,1) )
            else
               allocate( awrk(ixl,ixl,ixl,iyl,idn), afr1(ixl,ixl+1,1), &
                         gwrk(ixl,ixl,ixl,iyl,idn) )
            end if
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch',cidents, cident
               stop
            end if
         end if
!..
      case( 'f' ) 
         if( ion .eq. 0 ) then
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        irank, idivx, idivy, idivz, &
                        ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       irank, idivx, idivy, idivz, &
                       ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae

         else
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        idn, (aionam(i),aionaz(i),i=1,idn), &
                        irank, idivx, idivy, idivz, &
                        ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       idn, (aionam(i),aionaz(i),i=1,idn), &
                       irank, idivx, idivy, idivz, &
                       ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
         end if
!
         if( ixyzl .ne. -1 ) then
            if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) .or. &
                izl.ne.(izae-izas+1) ) then
              write(0,*) 'ERROR: data size mismatch', &
                         ixas,ixae,iyas,iyae,izas,izae
              stop
            end if
         end if
!.
         if( ir-1 .eq. 0 ) then
!.                              * check instantaneous flag for fer/fbr *
            if( chead(1:3) .eq. 'feR' ) then
               idn = 2
               cttl(2) = 'fe*r(inst.)'
            else if( chead(1:3) .eq. 'fbR' ) then
               idn = 2
               cttl(2) = 'fb*r(inst.)[MG]'
            end if
!
            isize = idivx * idivy * idivz
            ixals = ixal
            iyals = iyal
            izals = izal
            cidents = cident
            allocate( ixass(isize), ixaes(isize), ixans(isize), &
                      iyass(isize), iyaes(isize), iyans(isize), &
                      izass(isize), izaes(isize), izans(isize) )
            allocate( gwrk(ico,ixal,iyal,izal,idn) )
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch ', cidents, cident
               stop
            end if
            if( ixal.ne.ixals.or.iyal.ne.iyals.or.izal.ne.izals) then
               write(0,*) '### ERROR: total size mismatch', &
                          ixal,ixals,iyal,iyals,izal,izals
               stop
            end if
         end if
!..
         if( i0s .eq. 0 .and. ixyzl .ne. -1 ) then
            wx0s = wx0
            wy0s = wy0
            wz0s = wz0
            i0s = 1
         end if
         ixass(ir) = ixas
         ixaes(ir) = ixae
         ixans(ir) = ixae - ixas + 1
         iyass(ir) = iyas
         iyaes(ir) = iyae
         iyans(ir) = iyae - iyas + 1
         izass(ir) = izas
         izaes(ir) = izae
         izans(ir) = izae - izas + 1
!..
         ivoxel = ivoxel + ixans(ir)*iyans(ir)*izans(ir)
      end select
!..
      if( ir .eq. isize ) exit
!..
      end do
!....
      select case( ckind(1:1) )
      case( 'p' ) 
!..
      case( 'f' ) 
        if( ivoxel .ne. ixal*iyal*izal ) then
           write(0,*) '### ERROR: total #voxel mismatch', &
                         ivoxel,ixal,iyal,izal
           stop
        end if
!.
        ixps = ( wxps + wx0s ) / wxmic 
        if( ixps .lt. 1 ) then
           write( 0, * ) '### WARNING: invalid xps', wxps, ixps
           write( 0, * ) '###        : ixps is assumed as 1'
           ixps = 1
        end if
        ixpe = ( wxpe + wx0s ) / wxmic 
        if( ixpe .gt. ixal ) then
           write( 0, * ) '### WARNING: invalid xpe', wxpe, ixpe
           write( 0, * ) '###        : ixpe is assumed as', ixal
           ixpe = ixal
        end if
        if( ixps .gt. ixpe ) then
           write( 0, * ) '### ERROR: xps gt xpe', wxps, wxpe
           stop
        end if
        iyps = ( wyps + wy0s ) / wymic 
        if( iyps .lt. 1 ) then
           write( 0, * ) '### WARNING: invalid yps', wyps, iyps
           write( 0, * ) '###        : iyps is assumed as 1'
           iyps = 1
        end if
        iype = ( wype + wy0s ) / wymic 
        if( iype .gt. iyal ) then
           write( 0, * ) '### WARNING: invalid ype', wype, iype
           write( 0, * ) '###        : iype is assumed as', iyal
           iype = iyal
        end if
        if( iyps .gt. iype ) then
           write( 0, * ) '### ERROR: yps gt ype', wyps, wype
           stop
        end if
        izps = ( wzps + wz0s ) / wymic 
        if( izps .lt. 1 ) then
           write( 0, * ) '### WARNING: invalid zps', wzps, izps
           write( 0, * ) '###        : izps is assumed as 1'
           izps = 1
        end if
        izpe = ( wzpe + wz0s ) / wymic 
        if( izpe .gt. izal ) then
           write( 0, * ) '### WARNING: invalid zpe', wzpe, izpe
           write( 0, * ) '###        : izpe is assumed as', izal
           izpe = izal
        end if
        if( izps .gt. izpe ) then
           write( 0, * ) '### ERROR: zps gt zpe', wzps, wzpe
           stop
        end if
!.
        ixn  = ( ixpe - ixps ) / intx + 1
        if( ixn .lt. 1 ) then
           write(0,*) '### ERROR: invalid x interval', &
	                 ixps,ixpe,intx
           stop
        end if
        iyn  = ( iype - iyps ) / inty + 1
        if( iyn .lt. 1 ) then
           write(0,*) '### ERROR: invalid y interval', &
                         iyps,iype,inty
           stop
        end if
        izn  = ( izpe - izps ) / intz + 1
        if( izn .lt. 1 ) then
           write(0,*) '### ERROR: invalid z interval', &
                         izps,izpe,intz
           stop
        end if
!..
        wxps = ( ixps-1 ) * wxmic - wx0s
        wyps = ( iyps-1 ) * wymic - wy0s
        wzps = ( izps-1 ) * wzmic - wz0s
        wxpe = wxps + wxmic * intx * ( ixn - 1 )
        wype = wyps + wymic * inty * ( iyn - 1 )
        wzpe = wzps + wzmic * intz * ( izn - 1 )
        write(*,*) '----- ixps, ixpe, wxps, wxpe = ',ixps,ixpe,wxps,wxpe
        write(*,*) '----- iyps, iype, wyps, wype = ',iyps,iype,wyps,wype
        write(*,*) '----- izps, izpe, wzps, wzpe = ',izps,izpe,wzps,wzpe
        write(*,*) '----- ixn, iyn, izn = ', ixn, iyn, izn
!..
        do i = 1, locrsx
           if( soxcrs(i) .le. aundef ) soxcrs(i) = ( wxpe+wxps ) / 2.0d0
           if( soycrs(i) .le. aundef ) soycrs(i) = ( wype+wyps ) / 2.0d0
           if( sozcrs(i) .le. aundef ) sozcrs(i) = ( wzpe+wzps ) / 2.0d0
        end do
        if( sosltd(1) .le. aundef ) sosltd(1) = ( wxpe+wxps ) / 2.0d0
        if( sosltd(2) .le. aundef ) sosltd(2) = ( wype+wyps ) / 2.0d0
        if( sosltd(3) .le. aundef ) sosltd(3) = ( wzpe+wzps ) / 2.0d0
!.
        if( ico .eq. 1 ) then
           allocate( afr1(ixn,iyn,izn) )
        else
           allocate( afr1(ixn,iyn,izn), afr2(ixn,iyn,izn), &
                     afr3(ixn,iyn,izn) )
        end if
!..
      end select
!...
      write(*,*) '----- header: ', chead, ', ident: ', cident
!..
      if( ion .eq. 1 ) then
         do i = 2, idn
            cttl(i) = cttl(1)
         end do
         il = len_trim( cttl(1) )
         do i = 1, idn
            call o3ionlabel( i, aionam(i), aionaz(i), cttl(i)(il+1:) )
         end do
      end if
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cfrfntp, -1, 1, cident, &
                                        'fE'//ckind(4:4), cfile ) 
      else    
         call fntpcnv ( cfrfntp, -1, 1, cident, ckind, cfile ) 
      end if  
!....
      call frames_init
      call frames_file ( cfile, 1, ifrm )
!...
    1 continue
!..
         do ir = 1, isize
!
         iunit = iun0 + ir
!.
         select case( ckind(1:1) )
         case( 'p' ) 
           if( ir .eq. 1 ) gwrk(:,:,:,:,:) = 0.0d0
           read(iunit, end=99) wtime, awrk
           gwrk(:,:,:,:,:) = gwrk(:,:,:,:,:) + awrk(:,:,:,:,:)
         case( 'f' ) 
           if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 .and. & 
               izans(ir) .gt. 0 ) then
             allocate( awrk(ico,ixans(ir),iyans(ir),izans(ir),idn) )
             read(iunit, end=99) wtime, awrk
             gwrk(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),&
                    izass(ir):izaes(ir),:) = awrk(:,:,:,:,:)
             deallocate( awrk )
           end if
         end select
!..
         end do
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!.
         write(*,*) '----- time = ', wtime
!...
         select case( ckind(1:1) )
         case( 'p' ) 
         do is = 1, idn
           if( ckind(3:4) .eq. 'ph' ) then
             do i = 1, izl
               call o3pdrawph ( cident, wtime, 1.0d-12, 5, &
                         1, ilog, icol, gwrk(1,1,i,1,1), ixl, iyl, &
                         wpos(1,i), wpos(2,i), wpos(3,i), &
                         wpos(4,i), wpos(5,i), wpos(6,i), &
                         wpos(7,i), wpos(8,i), &
                         'x[micron]', 'Ux/c', 'peph' )
               call o3pdrawph ( cident, wtime, 1.0d-12, 5, &
                         1, ilog, icol, gwrk(1,1,i,2,1), ixl, iyl, &
                         wpos(1,i), wpos(2,i), wpos(3,i), &
                         wpos(4,i), wpos(5,i), wpos(6,i), &
                         wpos(9,i), wpos(10,i), &
                         'x[micron]', 'Uy/c', 'peph' )
               call o3pdrawph ( cident, wtime, 1.0d-12, 5, &
                         1, ilog, icol, gwrk(1,1,i,3,1), ixl, iyl, &
                         wpos(1,i), wpos(2,i), wpos(3,i), &
                         wpos(4,i), wpos(5,i), wpos(6,i), &
                         wpos(11,i), wpos(12,i), &
                         'x[micron]', 'Uz/c', 'peph' )
             end do
           else if( ckind(3:3) .eq. 'e' ) then
               do i = 1, iyl
                  call o3pdraw1 ( cident, wtime, 1.0d-12, 5, &
                     1, ilog, gwrk(1,i,is,1,1), ixl, wfct(i,is), &
                     wpos(1,i), wpos(2,i), wpos(3,i), &
                     wpos(4,i), wpos(5,i), wpos(6,i), &
                     'MeV', 'number[a.u.]', cttl(is) ) 
               end do
           else
               do i = 1, iyl
                  call o3pdraw6 ( cident, wtime, 1.0d-12, 5, 1, ilog, &
                     gwrk(1,1,1,i,is), afr1(1,1,1), afr1(1,2,1), &
                     ixl, wfct(i,is), &
                     wpos(1,i), wpos(2,i), wpos(3,i), &
                     wpos(4,i), wpos(5,i), wpos(6,i), &
                     'Px/mc', 'Py/mc', 'Pz/mc', 'number[a.u.]', &
                     cttl(is) ) 
               end do
           end if
         end do
!..
         case( 'f' ) 
         do i = 1, idn
            if( ico .eq. 1 ) then
               do is = 1, iso
                  if( ckind .eq. 'fde' ) then
                     woisov(is) = soisov(is)
                  else
                     woisov(is) = soisov(is) / aionaz(i)
                  end if
                  if( ilog .ge. 1 ) woisov(is) = log10( woisov(is) )
               end do
               afr1(:,:,:) = &
                  gwrk(1,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,i)
               call o3fdraw1 ( cident, wtime, 1.0d-12, 5, &
                 1, ilog, i3d, iso, icol, & 
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, woisov, &
                 afr1, ixn, iyn, izn, sosltd, loslnu, &
                 wxmic*intx, wx0s, wymic*inty, wy0s, wzmic*intz, wz0s, &
                 cttl(i) ) 

            else
               afr1(:,:,:) = &
                  gwrk(1,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,i)
               afr2(:,:,:) = &
                  gwrk(2,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,i)
               afr3(:,:,:) = &
                  gwrk(3,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,i)
               call o3fdraw3 ( cident, wtime, 1, i3d, icol, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 afr1,afr2,afr3, ixn,iyn,izn, sosltd, loslnu, &
                 wxmic*intx, wx0s, wymic*inty, wy0s, wzmic*intz, wz0s, &
                 cttl(i)(1:2)//'x'//cttl(i)(4:), &
                 cttl(i)(1:2)//'y'//cttl(i)(4:), &
                 cttl(i)(1:2)//'z'//cttl(i)(4:) )
            end if
         end do
!..
         end select
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
      call frames_term
!....
      stop
      end
