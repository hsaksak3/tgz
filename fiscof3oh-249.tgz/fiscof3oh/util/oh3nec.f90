!----------------------------------------------------------------------
! convert binary file to VTK file
!
! namelist param
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cvtfntp: file name template for VTK file
!          : default is '&K-&I-%%.###.vtk'
!          : &I is replaced by identification character in binary file
!          : &K is replaced by header in binary file
!          : ## is replaced by irank (MPI rank number)
!          : %% is replaced by file sequence number, not unit#
!   cident : identification character which is used in cbifntp
!          : (default is ' ')
!   ctype  : file data type ASCII or BINARY (default)
!   irank  : MPI rank number (default is -1)
!          : should be -1 if nonparallel run
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   wzps   : start z position (default is for all data)
!   wzpe   : end z position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!   intz   : data interval for z (default is 1)
!   ismoi  : smoothing iteration number (default is 0, no smoothing)
!   asmow  : smoothing weight of center (default is 6)
!      new(i,j,k) = (sum(old(i+-1,j+-1,k+-1)+asmow*old(i,j,k))/(6+asmow)
!
!  VTK binary data must be "BIG_ENDIAN", and convert='BIG_ENDIAN' in 
! OPEN statement is used in this program, assuming "gfortran".
!  But it's not standard, and you should modify it to fit your 
! environments. You can use environment variable or compiler option,
! such as "setenv GFORTRAN_CONVERT_UNIT big_endian:7" or 
! "-fconvert=big-endian" for gfortran.
! note: take care of "_" or "-" between "big" and "endian".
!
!----------------------------------------------------------------------
      use parameter, only:lionspx
      implicit none
      integer :: i, il, ico, idn, iunit, ixl, iyl, izl, ixyzl, intt, &
                 ixps, iyps, izps, ixpe, iype, izpe, intx, inty, intz, &
                 irank, ixn, iyn, izn, icnt, ismoi
      real*4, allocatable :: wwrk(:,:,:,:,:), wwrk1(:,:,:)
      real*8, allocatable :: awrk1(:,:,:,:,:), awrk2(:,:,:,:,:), awrk3(:,:,:,:,:)
      real*8  :: wxps, wyps, wzps, wxpe, wype, wzpe, &
                 wxmic, wx0, wymic, wy0, wzmic, wz0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aundef=-1.0d20, aundeff=-1.1d20, asmow, &
                 aionam(lionspx), aionaz(lionspx)
      character :: chead*4, cident*16, bident*16, &
                 cbifntp*64, cvtfntp*64, cfile*128, ctype*6, cbuff*80, &
                 ctitle(lionspx)*32
!.
      real*8, allocatable :: alpha(:,:,:),gamma(:,:,:), &
                             beta1(:,:,:),beta2(:,:,:),beta3(:,:,:), &
                             nec(:,:,:), neca(:,:,:)
      integer :: ix,iy,iz,ico1,ico2,ico3,iun1,iun2,iun3
      character :: com*2, cform*23, ckind1*4, ckind2*4, ckind3*4,&
                chead1*4, chead2*4, chead3*4, &
                cfile1*128, cfile2*128, cfile3*128
!.
      namelist /param/ cbifntp, cvtfntp, ctype, irank, &
                   wts, wte, intt, wxps, wxpe, wyps, wype, wzps, wzpe, &
                   intx, inty, intz, ismoi, asmow
!....
      cbifntp = 'fort.%%.###'
      cvtfntp = '&K-&I-%%.###.vtk'
      cident  = ' '
      ctype   = 'BINARY'
      irank   = -1
      wts     = 0.0d0
      wte     = 9999.0d0
      intt    = 1
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      wzps    = aundeff
      wzpe    = aundeff
      intx    = 1
      inty    = 1
      intz    = 1
      ismoi   = 0
      asmow   = 6.0d0
!..
      read(*,param)
      write(*,param)
!....
     ctitle(1) = 'Electron_CrDensity'
     idn = 1
     ckind1 = 'fde'
     iun1  = 24
     ico1   = 1
     ckind2 = 'fea'
     iun2  = 27
     ico2  = 1
     ckind3 = 'fje'
     iun3  = 31
     ico3  = 3
     chead = 'fdee'
!....
      call fntpcnv ( cbifntp, irank, iun1, cident, ckind1, cfile1 )
      open( iun1, file=cfile1, form='UNFORMATTED', status='OLD' )
      call fntpcnv ( cbifntp, irank, iun2, cident, ckind2, cfile2 )
      open( iun2, file=cfile2, form='UNFORMATTED', status='OLD' )
      call fntpcnv ( cbifntp, irank, iun3, cident, ckind3, cfile3 )
      open( iun3, file=cfile3, form='UNFORMATTED', status='OLD' )
!....
            read(iun1)  chead1, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0
            write(*,*) chead1, ' ', bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0
            read(iun2)  chead2, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0
            write(*,*) chead2, ' ', bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0
            read(iun3)  chead3, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0
            write(*,*) chead3, ' ', bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0
!.
      if( wxps .le. aundef ) then
         ixps = 1
      else
         ixps = ( wxps + wx0 ) / wxmic
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: invalid xps', wxps, ixps
            write(0,*) '###        : ixps is assumed as 1'
            ixps = 1
         end if
      end if
      if( wxpe .le. aundef ) then
         ixpe = ixl
      else
         ixpe = ( wxpe + wx0 ) / wxmic
         if( ixpe .gt. ixl ) then
            write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
            write(0,*) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
      end if
      if( ixps .gt. ixpe ) then
         write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
         stop
      end if
      if( wyps .le. aundef ) then
         iyps = 1
      else
         iyps = ( wyps + wy0 ) / wymic
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: invalid yps', wyps, iyps
            write(0,*) '###        : iyps is assumed as 1'
            iyps = 1
         end if
      end if
      if( wype .le. aundef ) then
         iype = iyl
      else
         iype = ( wype + wy0 ) / wymic
         if( iype .gt. iyl ) then
            write(0,*) '### WARNING: invalid ype', wype, iype
            write(0,*) '###        : iype is assumed as', iyl
            iype = iyl
         end if
      end if
      if( iyps .gt. iype ) then
         write(0,*) '### ERROR: yps gt ype', wyps, wype
         stop
      end if
      if( wzps .le. aundef ) then
         izps = 1
      else
         izps = ( wzps + wz0 ) / wzmic
         if( izps .lt. 1 ) then
            write(0,*) '### WARNING: invalid zps', wzps, izps
            write(0,*) '###        : izps is assumed as 1'
            izps = 1
         end if
      end if
      if( wzpe .le. aundef ) then
         izpe = izl
      else
         izpe = ( wzpe + wz0 ) / wzmic
         if( izpe .gt. izl ) then
            write(0,*) '### WARNING: invalid zpe', wzpe, izpe
            write(0,*) '###        : izpe is assumed as', izl
            izpe = izl
         end if
      end if
      if( izps .gt. izpe ) then
         write(0,*) '### ERROR: zps gt zpe', wzps, wzpe
         stop
      end if
!.
      ixn  = ( ixpe - ixps ) / intx + 1
      if( ixn .lt. 2 ) then
         write(0,*) '### ERROR: invalid x interval', &
	               ixps,ixpe,intx
         stop
      end if
      iyn  = ( iype - iyps ) / inty + 1
      if( iyn .lt. 2 ) then
         write(0,*) '### ERROR: invalid y interval', &
                       iyps,iype,inty
         stop
      end if
      izn  = ( izpe - izps ) / intz + 1
      if( izn .lt. 2 ) then
         write(0,*) '### ERROR: invalid z interval', &
                       izps,izpe,intz
         stop
      end if
!..
      wxps = ( ixps-1 ) * wxmic - wx0
      wyps = ( iyps-1 ) * wymic - wy0
      wzps = ( izps-1 ) * wzmic - wz0
      wxpe = wxps + wxmic * intx * ( ixn - 1 )
      wype = wyps + wymic * inty * ( iyn - 1 )
      wzpe = wzps + wzmic * intz * ( izn - 1 )
      write(*,*) '----- ixps, ixpe, wxps, wxpe = ', ixps,ixpe,wxps,wxpe
      write(*,*) '----- iyps, iype, wyps, wype = ', iyps,iype,wyps,wype
      write(*,*) '----- izps, izpe, wzps, wzpe = ', izps,izpe,wzps,wzpe
      write(*,*) '----- ixn, iyn, izn = ', ixn, iyn, izn
      write(*,*) '----- header: ', chead, ', ident: ', bident
!....
      allocate( awrk1(ico1,ixl,iyl,izl,idn),  awrk2(ico2,ixl,iyl,izl,idn), &
                awrk3(ico3,ixl,iyl,izl,idn) )
      allocate( alpha(ixn,iyn,izn), gamma(ixn,iyn,izn), &
                beta1(ixn,iyn,izn), beta2(ixn,iyn,izn), beta3(ixn,iyn,izn), &
                nec(ixn,iyn,izn), neca(ixn,iyn,izn) )
      if( ctype(1:1) .ne. 'A' .and. ctype(1:1) .ne. 'a' ) then
         allocate( wwrk(ico1,ixn,iyn,izn,idn) )
         allocate( wwrk1(ixn,iyn,izn) )
      end if
      icnt = 0
    1 continue
         read(iun1, end=99) wtime, awrk1
         read(iun2, end=99) wtime, awrk2
         read(iun3, end=99) wtime, awrk3
!.
do iz = 1, izn
   do iy = 1, iyn
      do ix = 1, ixn
alpha(ix,iy,iz) = 8.9d0 * sqrt( awrk2(1,ix,iy,iz,1) )
gamma(ix,iy,iz) = sqrt( 1.0d0 + 0.5d0 * alpha(ix,iy,iz)**2 )
      
if( awrk1(1,ix,iy,iz,1) .ne. 0.0d0)then
beta1(ix,iy,iz) = - awrk3(1,ix,iy,iz,1) / awrk1(1,ix,iy,iz,1)

beta2(ix,iy,iz) = 1.0d0 - awrk1(1,ix,iy,iz,1) / gamma(ix,iy,iz) 
if( beta2(ix,iy,iz) .le. 0.0d0 )then
beta2(ix,iy,iz) = 0.0d0
!nec(ix,iy,iz) = 1.0d0
cycle
end if

beta3(ix,iy,iz) = 1.0d0 - beta1(ix,iy,iz) * sqrt( beta2(ix,iy,iz) )
nec(ix,iy,iz) = sqrt( 1.0d0 + &
              0.5d0 * ( beta3(ix,iy,iz) * alpha(ix,iy,iz) / ( 1.0d0 + beta1(ix,iy,iz) ) )**2 ) * &
              beta3(ix,iy,iz)**2 / ( 1.0d0 - beta1(ix,iy,iz)**2 )
neca(ix,iy,iz) = awrk1(1,ix,iy,iz,1) / nec(ix,iy,iz)
else
beta1(ix,iy,iz) = 0.0d0
!nec(ix,iy,iz) = awrk1(1,ix,iy,iz,1)
end if
      end do
   end do
end do
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- time = ', wtime
!.
         call fntpcnv ( cvtfntp, irank, icnt, bident, chead, cfile )
!.
            open(7, file=cfile, access='STREAM', form='UNFORMATTED', &
                    convert='BIG_ENDIAN' )
            write(cbuff,'(a)') '# vtk DataFile Version 3.0'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(f8.2)') wtime 
            write(7) &
             trim(bident)//',time='//trim(adjustl(cbuff))//new_line('A')
            write(cbuff,'(a)') 'BINARY' 
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a)') 'DATASET STRUCTURED_POINTS'
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, izn
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, wzps
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,3e12.4)') 'SPACING', &
                                       intx*wxmic,inty*wymic,intz*wzmic
            write(7) trim(cbuff)//new_line('A')
            write(cbuff,'(a,1x,i9)') 'POINT_DATA', ixn*iyn*izn
            write(7) trim(cbuff)//new_line('A')
     !       wwrk(:,:,:,:,:) = &
     !          awrk1(:,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,:)
            wwrk1(:,:,:) = neca(ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz)
            do i = 1, idn
                  write(cbuff,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                  write(7) trim(cbuff)//new_line('A')
                  write(cbuff,'(a)') 'LOOKUP_TABLE default'
                  write(7) trim(cbuff)//new_line('A')
                write(7) wwrk1(:,:,:)
            end do
            close(7)
!.
         icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iun1, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
