!----------------------------------------------------------------------
! pfeedoh3file: convert pfeed files written by OhHelp version to single file (3D)
!
! namelist param
!   cfpfntpe: file name template for pfeed file
!   cident  : identification character for template
!   iloc    : location number (should be -1 if total number is 1)
!   wopfeedm: minimum number of particles for output (default is 1)
!
!----------------------------------------------------------------------
      implicit none
      integer, parameter :: iun0 = 9
      integer :: ira, isize, iloc, iun, itmp, itmp2, irx, imx, inx, ihx, ivx, &
                 id1, id2, id3, id4, id5, iend
      integer, allocatable :: itx(:)
      real*8  :: wopfeedm, wtmp, wnpnc, wtime, wtotal, wnum, wn, wnp
      real*8, allocatable :: wpfeed(:,:,:,:,:)
      character :: cfpfntpe*64, cbuff*80, cident*16, cfile*128, &
                   cidents*16
!.
      namelist /param/ cfpfntpe, cident, iloc, wopfeedm
!....
      cfpfntpe = '&K-&I-%-###.dat'
      cident   = 'xxx'
      iloc     = -1
      wopfeedm = 1.0d0
!..
      read(*,param)
      write(0,param)
!....                                              * search all files *
      do ira = 1, 999999
        iun = iun0 + ira
        call fntpcnv ( cfpfntpe, ira-1, iloc, cident, 'pfeed', cfile )
        open( iun, file=cfile, form='FORMATTED', status='OLD', err=1 )
      end do
    1 continue
      isize = iun - 1 - iun0
      if( isize .eq. 0 ) &
        open( iun, file=cfile, form='FORMATTED', status='OLD' )
      write(0,*) 'isize = ', isize
      call fntpcnv ( cfpfntpe, -1, iloc, cident, 'pfeed', cfile )
      open( 7, file=cfile, form='FORMATTED' )
!....                                                       * headers *
! ------ start 1/2 -------
! ident character             = i20tmpulse       
! Equal Division              =      32      
! # of mesh for omega         =      16      
! # of mesh for momentum      =     100     
! range                       =       0.200   
! integration time            =       3.523 [fsec]
! observation interval        =       5.000 [fsec]
! observation position of z   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! # of division for xy         =      1    2
!  or
! observation position of x   =       5.500 [micron]
! observation position of ys  =      -1.500 [micron]
! observation position of ye  =       1.500 [micron]
! observation position of zs  =      -1.500 [micron]
! observation position of ze  =       1.500 [micron]
! # of division for yz         =      1    2
!  or
! observation position of y   =       5.500 [micron]
! observation position of xs  =      -1.500 [micron]
! observation position of xe  =       1.500 [micron]
! observation position of zs  =      -1.500 [micron]
! observation position of ze  =       1.500 [micron]
! # of division for xz         =      1    2
! # of particle/mesh at nc    =      25.000  
! density at center           =      19.897  
! laser wavelength            =       1.060 [micron]
! laser wavelength/mesh size  =      50.217  
! Debye length/mesh size      =       0.250   
! laser peak intensity        =  0.1000E+21 [W/cm^2-micron^2]
! laser pulse shape (TYPE)    =     112     
! laser pulse parameters      =       5.000   1000.000      5.000
!..                              * read headers and check consistency *
      wnpnc = 0.0d0
      do ira = 1, isize
        iun = iun0 + ira
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            cidents = cbuff(31:46)
          else
            if( cbuff(31:46) .ne. cidents ) then
              write(0,*) '### ERROR: cident mismatch', &
                 ira, cbuff(31:46),' ', cidents
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a46)') cbuff
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') imx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. imx ) then
              write(0,*) '### ERROR: imx mismatch', ira, itmp, imx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') inx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. inx ) then
              write(0,*) '### ERROR: inx mismatch', ira, itmp, inx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:37),'(i7)') irx
          else
            read(cbuff(31:37),'(i7)') itmp
            if( itmp .ne. irx ) then
              write(0,*) '### ERROR: irx mismatch', ira, itmp, irx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. 1 ) then
            read(cbuff(31:44),'(2i7)') ihx, ivx
          else
            read(cbuff(31:44),'(2i7)') itmp, itmp2
            if( itmp .ne. ihx .or. itmp2 .ne. ivx ) then
              write(0,*) '### ERROR: ihx, ivx mismatch', ira, itmp, ihx, itmp2, ivx
              stop
            end if
          end if
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          read(cbuff(31:41),'(f11.3)') wtmp
          wnpnc = max( wnpnc, wtmp )
          if( ira .eq. isize ) then
            write(cbuff(31:41),'(f11.3)') wnpnc
            write(7,'(a)') trim(cbuff)
          end if
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
        read(iun,'(a80)') cbuff
          if( ira .eq. isize ) write(7,'(a)') trim(cbuff)
      end do
!..
      allocate ( wpfeed(irx,imx,inx,ihx,ivx), itx(isize) )
      itx(:) = 0
      iend = 0
!....
    2 continue
      wpfeed(:,:,:,:,:) = 0.0d0
      wnp = 0.0d0
!...
      do ira = 1, isize
        iun = ira + iun0
!                                              * skip until separator *
    3   continue
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:20) .ne. '--------------------') go to 3
!                                            * next must be 'time = ' *
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:8) .ne. ' time = ') then
           write(0,*) '### ERROR: not time = ', cbuff
           stop
        end if
        itx(ira) = itx(ira) + 1
        read( cbuff(9:20), '(f12.3)' ) wtime
        write(0,*) 'irank,itx,time = ', ira-1, itx(ira), wtime
!                                             * read until 'total = ' *
    4   continue
        read(iun, '(a80)', end=9 ) cbuff
        if( cbuff(1:8) .eq. 'total = ') then
           read( cbuff(9:20), '(f12.3)' ) wtotal
           write(0,*) 'irank, partial total = ', ira-1, wtotal
           wnp = wnp + wtotal
           cycle
        end if
!.         
        read( cbuff(1:32), '(5i4,f12.3)' ) id1,id2,id3,id4,id5,wnum
        wpfeed(id1,id2,id3,id4,id5) = wpfeed(id1,id2,id3,id4,id5) + wnum
        goto 4
!.
    9   continue
        iend = iend + 1
      end do
!...
      if( iend .ge. isize ) then
         write(7,'(a)') trim(cbuff)
         go to 99
      end if
!...
      write(7,'(a)') '------------------------'
      write(7,'(a8,f12.3)') ' time = ', wtime
      wn = 0.0d0
      do id5 = 1, ivx
      do id4 = 1, ihx
        do id3 = 1, inx
          do id2 = 1, imx
            do id1 = 1, irx
              if( wpfeed(id1,id2,id3,id4,id5) .ge. wopfeedm ) then
                wn = wn + wpfeed(id1,id2,id3,id4,id5)
                write(7,'(5i4,f12.3)') id1,id2,id3,id4,id5, &
                                          wpfeed(id1,id2,id3,id4,id5)
              end if
            end do
          end do
        end do
      end do
      end do
      write(7,'(a8,f12.3)') 'total = ', wn
      write(0,*) 'total = ', wn, wnp
!...         
      go to 2
!...         
   99 continue
      write(0,*) 'reading data ',itx(:)
!....
      stop
      end
