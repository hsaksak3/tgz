implicit none
integer :: iy, iz
integer :: lblxl1, iys1,iye1,izs1,ize1, lstcur1, ips1
integer :: lblxl2, iys2,iye2,izs2,ize2, lstcur2, ips2
real*8, allocatable :: sdat1(:,:), sdat2(:,:)
character*128 :: cfn1, cfn2
!
write(*,*) 'enter file name1'
read(*,'(a)') cfn1
write(*,*) 'enter file name2'
read(*,'(a)') cfn2
!
open( 81, file=cfn1, form='UNFORMATTED', status='OLD' )
open( 82, file=cfn2, form='UNFORMATTED', status='OLD' )
!
read(81) lblxl1, iys1,iye1,izs1,ize1
write(*,*) lblxl1, iys1,iye1,izs1,ize1
read(82) lblxl2, iys2,iye2,izs2,ize2
write(*,*) lblxl2, iys2,iye2,izs2,ize2
!
allocate( sdat1(iys1:iye1,izs1:ize1), sdat2(iys1:iye1,izs1:ize1) )
!
1 continue
  read(81,end=9) lstcur1, ips1, sdat1
  read(82,end=9) lstcur2, ips2, sdat2
  write(*,*) lstcur1, ips1, lstcur2, ips2, maxval( sdat1(:,:) - sdat2(:,:) )
! write(*,*) '@@@', lstcur1, ips1, lstcur2, ips2
! do iz = izs1, ize1
!   do iy = iys1, iye1
!     if( sdat1(iy,iz) .ne. sdat2(iy,iz) ) then
!       write(*,*) iy, iz, sdat1(iy,iz), sdat2(iy,iz)
!     end if
!   end do
! end do
  go to 1
9 continue
!
stop
end
