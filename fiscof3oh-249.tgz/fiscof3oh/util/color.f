c--------------------------------------------------------------------
      call igdfx_init
c....
      ihuen = 12
      ilign = 20
c.
      whs = 0.0
c     whe = 330.0 
      whe = 310.0 
      wls = 0.25
      wle = 0.75
      ws  = 1.0
      weps = 0.01
c....
      call igdfx_opngif ( 1, 640, 640 )
c....
      call igdfx_defvwp ( 1, 0.0, 1.0, 0.0, 1.0 )
      call igdfx_defwin ( 1, 0.0, 1.0, 0.0, 1.0 )
      call igdfx_deftrf ( 1, 1, 1 )
c...
      do ih = 1, ihuen
         wh = whs + ( whe - whs ) * ( ih-1 ) / ( ihuen-1 )
         if( ih .eq. 3 ) wh = wh - 10.0
         if( ih .eq. 4 ) wh = wh - 20.0
         if( ih .eq. 5 ) wh = wh - 30.0
         do il = 1, ilign
            wl = wls + ( wle - wls ) * ( il-1 ) / ( ilign-1 )
            ic = 10 + ( ih-1 ) * ilign + ( il-1 )
            call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
            call igdfx_defcol ( ic, ir, ig, ib )
         end do
      end do  
c...
      call igdfx_sellcl ( 2 )
      do ih = 1, ihuen
         wxs = real(ih-1)/ihuen + weps
         wxe = real(ih)/ihuen - weps
         do il = 1, ilign
            wys = real(il-1)/ilign + weps
            wye = real(il)/ilign - weps
            ic = 10 + ( ih-1 ) * ilign + ( il-1 )
            call igdfx_selfcl ( ic )
            call igdfx_drwrec ( wxs, wys, wxe, wye, 11 )
         end do
      end do
c...
      call igdfx_clsgif ( 1, 'color.gif$ ', 2 )
c....
      call igdfx_term
c....
      stop
      end
