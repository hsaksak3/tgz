!----------------------------------------------------------------------
! plot binary file with Frames
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cfrfntp: file name template for Frames file
!          : default is '&K-&I-###'
!   cident : identification character (default is ' ')
!          : if ' ', cident in data is used for cfrfntp
!   irank  : MPI rank number (default is -1)
!          : should be -1 if nonparallel run
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   wzps   : start z position (default is for all data)
!   wzpe   : end z position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!   intz   : data interval for z (default is 1)
!
!----------------------------------------------------------------------
      use parameter, only:lionspx
      implicit none
      integer :: i, is, ico, idn, iunit, ixl, iyl, izl, ixyzl, intt, &
                 ixps, iyps, izps, ixpe, iype, izpe, intx, inty, intz, &
                 irank, ixn, iyn, izn, il, icol, icnt
      real*8, allocatable :: awrk(:,:,:,:,:), &
                             afr1(:,:,:), afr2(:,:,:), afr3(:,:,:), &
                             wfct(:,:), wpos(:,:)
      real*8 :: wxps, wyps, wzps, wxpe, wype, wzpe, &
                wxmic, wx0, wymic, wy0, wzmic, wz0, &
                wts, wte, wtime, wteps=0.02d0, &
                aundef=-1.0d20, aundeff=-1.1d20, &
                aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, bident*16, clabel*20, &
                   cbifntp*64, cfrfntp*64, cfile*128, cttl(lionspx)*32
!.
      real*8 :: slsrpw, wlsrpw=1.0d20, wamp
      real*8, allocatable :: feaAve(:),ax(:)
      integer :: ix,iy,iz,ifound
      integer, allocatable :: Num(:)
      character com*2, cform*23
!.
!.
      namelist /param/ ckind, cbifntp, cfrfntp, cident, &
         irank, wts, wte, intt, &
         wxps, wxpe, wyps, wype, wzps, wzpe, intx, inty, intz, slsrpw
!....
      ckind    = ' '
      cbifntp = 'fort.%%.###'
      cfrfntp = '&K-&I-%%.txt'
      irank   = -1
      wts     = 0.0
      wte     = 9999.0
      intt    = 1
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      wzps    = aundeff
      wzpe    = aundeff
      intx    = 1
      inty    = 1
      intz    = 1
      slsrpw  = 1.0d20
      com=','
      cform='(f6.2,a1,i12,a1,es12.5)'
!..
      read(*,param)
      write(*,param)
!....
      select case( ckind )
      case( 'fea' )
         iunit = 27
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fea'
      case( 'fer' )
         iunit = 28
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fe*r'
      case( 'fba' )
         iunit = 29
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fba[MG]'
      case( 'fbr' )
         iunit = 30
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fb*r[MG]'
      case( 'fje' )
         iunit = 31
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fj*e'
      case( 'fji' )
         iunit = 32
         ico = 3
         idn = 0
         icol = 2
         cttl(1) = 'fj*i'
      case( 'fjt' )
         iunit = 33
         ico = 3
         idn = 1
         icol = 2
         cttl(1) = 'fj*t'
      case( 'fte' )
         iunit = 34
         ico = 1
         idn = 2
         icol = 1
         cttl(1) = 'fte[MeV]'
         cttl(2) = 'fpe[Gbar]'
      case( 'fede' )
         iunit = 36
         ico = 1
         idn = 1
         icol = 1
         cttl(1) = 'fede'
      case( 'fedi' )
         iunit = 37
         ico = 1
         idn = 0
         icol = 1
         cttl(1) = 'fedi'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!..
      call fntpcnv ( cbifntp, irank, iunit, cident, ckind, cfile )
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      select case( ckind(1:1) )
      case( 'p' ) 
         if( idn .ne. 0 ) then
            read(iunit) chead, bident, ixl, iyl, &
                        ( wfct(i,1),wpos(:,i),i=1,iyl )
            write(*,*) chead, ' ', bident, ixl, iyl, &
                       ( wfct(i,1),wpos(:,i),i=1,iyl )
         else
            read(iunit) chead, bident, ixl, iyl, idn, &
                        ( (aionam(is),aionaz(is),is=1,idn), &
                          wfct(i,1:idn),wpos(:,i),i=1,iyl )
            write(*,*) chead, ' ', bident, ixl, iyl, idn, &
                       ( (aionam(is),aionaz(is),is=1,idn), &
                         wfct(i,1:idn),wpos(:,i),i=1,iyl )
         end if
      case( 'f' ) 
         if( idn .ne. 0 ) then
            read(iunit) chead, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0
            write(*,*) chead, ' ', bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0
         else
            read(iunit) chead, bident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        idn, (aionam(i),aionaz(i),i=1,idn)
            write(*,*) chead, bident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       idn, (aionam(i),aionaz(i),i=1,idn)
         end if
      end select
!...
      select case( ckind(1:1) )
      case( 'p' ) 
         if( ico .eq. 1 ) then
            allocate( awrk(ixl,iyl,idn,1,1) )
         else
            allocate( awrk(ixl,3+ixl*3,iyl,idn,1) )
         end if
!..
      case( 'f' ) 
      if( wxps .le. aundef ) then
         ixps = 1
      else
         ixps = ( wxps + wx0 ) / wxmic
         if( ixps .lt. 1 ) then
            write(0,*) '### WARNING: invalid xps', wxps, ixps
            write(0,*) '###        : ixps is assumed as 1'
            ixps = 1
         end if
      end if
      if( wxpe .le. aundef ) then
         ixpe = ixl
      else
         ixpe = ( wxpe + wx0 ) / wxmic
         if( ixpe .gt. ixl ) then
            write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
            write(0,*) '###        : ixpe is assumed as', ixl
            ixpe = ixl
         end if
      end if
      if( ixps .gt. ixpe ) then
         write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
         stop
      end if
      if( wyps .le. aundef ) then
         iyps = 1
      else
         iyps = ( wyps + wy0 ) / wymic
         if( iyps .lt. 1 ) then
            write(0,*) '### WARNING: invalid yps', wyps, iyps
            write(0,*) '###        : iyps is assumed as 1'
            iyps = 1
         end if
      end if
      if( wype .le. aundef ) then
         iype = iyl
      else
         iype = ( wype + wy0 ) / wymic
         if( iype .gt. iyl ) then
            write(0,*) '### WARNING: invalid ype', wype, iype
            write(0,*) '###        : iype is assumed as', iyl
            iype = iyl
         end if
      end if
      if( iyps .gt. iype ) then
         write(0,*) '### ERROR: yps gt ype', wyps, wype
         stop
      end if
      if( wzps .le. aundef ) then
         izps = 1
      else
         izps = ( wzps + wz0 ) / wzmic
         if( izps .lt. 1 ) then
            write(0,*) '### WARNING: invalid zps', wzps, izps
            write(0,*) '###        : izps is assumed as 1'
            izps = 1
         end if
      end if
      if( wzpe .le. aundef ) then
         izpe = izl
      else
         izpe = ( wzpe + wz0 ) / wzmic
         if( izpe .gt. izl ) then
            write(0,*) '### WARNING: invalid zpe', wzpe, izpe
            write(0,*) '###        : izpe is assumed as', izl
            izpe = izl
         end if
      end if
      if( izps .gt. izpe ) then
         write(0,*) '### ERROR: zps gt zpe', wzps, wzpe
         stop
      end if
!.
      ixn  = ( ixpe - ixps ) / intx + 1
      if( ixn .lt. 2 ) then
         write(0,*) '### ERROR: invalid x interval', &
	               ixps,ixpe,intx
         stop
      end if
      iyn  = ( iype - iyps ) / inty + 1
      if( iyn .lt. 2 ) then
         write(0,*) '### ERROR: invalid y interval', &
                       iyps,iype,inty
         stop
      end if
      izn  = ( izpe - izps ) / intz + 1
      if( izn .lt. 2 ) then
         write(0,*) '### ERROR: invalid z interval', &
                       izps,izpe,intz
         stop
      end if
!..
      wxps = ( ixps-1 ) * wxmic - wx0
      wyps = ( iyps-1 ) * wymic - wy0
      wzps = ( izps-1 ) * wzmic - wz0
      wxpe = wxps + wxmic * intx * ( ixn - 1 )
      wype = wyps + wymic * inty * ( iyn - 1 )
      wzpe = wzps + wzmic * intz * ( izn - 1 )
      write(*,*) '----- ixps, ixpe, wxps, wxpe = ', ixps,ixpe,wxps,wxpe
      write(*,*) '----- iyps, iype, wyps, wype = ', iyps,iype,wyps,wype
      write(*,*) '----- izps, izpe, wzps, wzpe = ', izps,izpe,wzps,wzpe
      write(*,*) '----- ixn, iyn, izn = ', ixn, iyn, izn
!.
      allocate( awrk(ico,ixl,iyl,izl,idn) )
      if( ico .eq. 1 ) then
         allocate( afr1(ixn,iyn,izn) )
      else
         allocate( afr1(ixn,iyn,izn), afr2(ixn,iyn,izn), &
                   afr3(ixn,iyn,izn) )
      end if
!..
      end select
!...
      write(*,*) '----- header: ', chead, ', ident: ', bident
      if( cident .eq. ' ' ) then
         cident = bident
      else
         write(*,*) '----- used ident: ', cident
      end if
!..
!...
wamp = slsrpw/wlsrpw
allocate( Num(ixn), feaAve(ixn),ax(ixn) )
do ix=1,ixn
   ax(ix)= wxmic*(ix-1)-wx0
end do
!...
icnt = 0
    1 continue
         read(iunit, end=99) wtime, afr1
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!.
         write(*,*) '----- time = ', wtime
!...
         call fntpcnv ( cfrfntp, irank, icnt, cident, 'Frntpos', cfile ) 
!.
Num(:)=0
feaAve(:)=0.0d0

do iz = 1, izn
   do iy = 1, iyn
      ifound = 0
      do ix = ixn, 2, -1
         if( afr1(ix,iy,iz) .ge. wamp )then
            Num(ix) = Num(ix)+1
            ifound = 1
            exit
         end if
      end do
      if( ifound .eq. 0 )Num(1) = Num(1)+1
   end do 
end do
do ix = 1, ixn
   do iz = 1, izn
      do iy = 1, iyn
         feaAve(ix)=feaAve(ix)+afr1(ix,iy,iz)
      end do
   end do
   feaAve(ix)=feaAve(ix)/(iyn*izn)
end do
open(7,file=cfile,form='FORMATTED')
write(7,*)cident, ',', wtime
write(7,*)'xpos[mic], distribution, feaAve[/1.0d20]'
do ix=1,ixn
   write(7,cform)ax(ix),com,Num(ix),com,feaAve(ix)
end do
close(7)
!.
icnt = icnt + 1
!.
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
