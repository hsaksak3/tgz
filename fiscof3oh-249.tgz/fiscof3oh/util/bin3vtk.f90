!----------------------------------------------------------------------
! bin3vtk: convert binary file to VTK file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   cvtfntp: file name template for VTK file
!          : default is '&K-&I-%%.###.vtk'
!          : &I is replaced by identification character in binary file
!          : &K is replaced by header in binary file
!          : ## is replaced by irank (MPI rank number)
!          : %% is replaced by file sequence number, not unit#
!   ctype  : file data type ASCII or BINARY (default)
!   irank  : MPI rank number (default is -1)
!          : should be -1 if nonparallel run
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!   intt   : time interval (default is 1)
!   iseq   : initial sequence number of VTK file (default is 0)
!   wxps   : start x position (default is for all data)
!   wxpe   : end x position (default is for all data)
!   wyps   : start y position (default is for all data)
!   wype   : end y position (default is for all data)
!   wzps   : start z position (default is for all data)
!   wzpe   : end z position (default is for all data)
!   intx   : data interval for x (default is 1)
!   inty   : data interval for y (default is 1)
!   intz   : data interval for z (default is 1)
!   ismoi  : smoothing iteration number (default is 0, no smoothing)
!   asmow  : smoothing weight of center (default is 6)
!      new(i,j,k) = (sum(old(i+-1,j+-1,k+-1)+asmow*old(i,j,k))/(6+asmow)
!
!  VTK binary data must be "BIG_ENDIAN", and convert='BIG_ENDIAN' in 
! OPEN statement is used in this program, assuming "gfortran".
!  But it's not standard, and you should modify it to fit your 
! environments. You can use environment variable or compiler option,
! such as "setenv GFORTRAN_CONVERT_UNIT big_endian:7" or 
! "-fconvert=big-endian" for gfortran.
! note: take care of "_" or "-" between "big" and "endian".
!
!----------------------------------------------------------------------
      use parameter, only:lionspx, lopemx, lopimx
      implicit none
      integer :: i, il, ico, idn, iunit, ixl, iyl, izl, ixyzl, intt, &
                 ixps, iyps, izps, ixpe, iype, izpe, intx, inty, intz, &
                 irank, ixn, iyn, izn, icnt, ismoi, ion, iseq
      real*4, allocatable :: wwrk(:,:,:,:,:)
      real*8, allocatable :: awrk(:,:,:,:,:), awr2(:,:,:,:,:), &
                             wfct(:,:), wpos(:,:)
      real*8  :: wxps, wyps, wzps, wxpe, wype, wzpe, &
                 wxmic, wx0, wymic, wy0, wzmic, wz0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aundef=-1.0d20, aundeff=-1.1d20, asmow, &
                 aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, crange*48, &
                 cbifntp*64, cvtfntp*64, cfile*128, ctype*6, cbuff*80, &
                 ctitle(lionspx)*32, cheadx*12
!.
      namelist /param/ ckind, cbifntp, cidentb, cvtfntp, ctype, irank, &
                   wts, wte, intt, iseq, wxps, wxpe, wyps, wype, wzps, &
                   wzpe, intx, inty, intz, ismoi, asmow
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      cvtfntp = '&K-&I-%%.###.vtk'
      ctype   = 'BINARY'
      irank   = -1
      wts     = 0.0d0
      wte     = 9999.0d0
      intt    = 1
      iseq    = 0
      wxps    = aundeff
      wxpe    = aundeff
      wyps    = aundeff
      wype    = aundeff
      wzps    = aundeff
      wzpe    = aundeff
      intx    = 1
      inty    = 1
      intz    = 1
      ismoi   = 0
      asmow   = 6.0d0
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'pem' ) 
         iunit = 22
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Momentum' 
      case( 'pim' ) 
         iunit = 23
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Momentum' 
      case( 'fde' )
         iunit = 24
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Density'
      case( 'fdi' )
         iunit = 25
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Density'
      case( 'fdc' )
         iunit = 26
         ico = 1
         idn = 1
         ctitle(1) = 'Charge_Density'
      case( 'fea' )
         iunit = 27
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Electric_Field'
      case( 'fer' )
         iunit = 28
         ico = 3
         idn = 1
         ctitle(1) = 'Electric_Field'
      case( 'fba' )
         iunit = 29
         ico = 1
         idn = 1
         ctitle(1) = 'Amp._of_Magnetic_Field'
      case( 'fbr' )
         iunit = 30
         ico = 3
         idn = 1
         ctitle(1) = 'Magnetic_Field'
      case( 'fje' )
         iunit = 31
         ico = 3
         idn = 1
         ctitle(1) = 'Electron_Current'
      case( 'fji' )
         iunit = 32
         ico = 3
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Current'
      case( 'fjt' )
         iunit = 33
         ico = 3
         idn = 1
         ctitle(1) = 'Total_Current'
      case( 'fte' )
         iunit = 34
         ico = 1
         idn = 2
         ctitle(1) = 'Electron_Temperature'
         ctitle(2) = 'Electron_Pressure'
      case( 'fede' )
         iunit = 36
         ico = 1
         idn = 1
         ctitle(1) = 'Electron_Energy_Density'
      case( 'fedi' )
         iunit = 37
         ico = 1
         idn = 0
         ion = 1
         ctitle(1) = 'Ion_Energy_Density'
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!....
      if( ckind(1:1) .eq. 'p' ) then
         izl = max( lopemx, lopimx )
         allocate( wfct(izl,lionspx), wpos(6,izl) )
         if( ismoi .ge. 1 ) then
            write(0,*) '### WARNING: invalid ismoi', ismoi
            write(0,*) '###        : ismoi reset to 0'
            ismoi = 0
         end if
      end if
!....
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, irank, iunit, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else
         call fntpcnv ( cbifntp, irank, iunit, cidentb, ckind, cfile )
      end if
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!....
      select case( ckind(1:1) )
      case( 'p' )
         if( ion .eq. 0 ) then
            read(iunit) chead, cident, ixl, iyl, &
                        ( wfct(i,1),wpos(:,i),i=1,iyl )
            write(*,*) chead, ' ', cident, ixl, iyl, &
                       ( wfct(i,1),wpos(:,i),i=1,iyl )
         else
            read(iunit) chead, cident, ixl, iyl, idn, &
                        ( (aionam(i),aionaz(i),i=1,idn), &
                          wfct(il,1:idn),wpos(:,il),il=1,iyl )
            write(*,*) chead, ' ', cident, ixl, iyl, idn, &
                       ( (aionam(i),aionaz(i),i=1,idn), &
                         wfct(il,1:idn),wpos(:,il),il=1,iyl )
         end if
      case( 'f' )
         if( ion .eq. 0 ) then
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0
         else
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        idn, (aionam(i),aionaz(i),i=1,idn)
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       idn, (aionam(i),aionaz(i),i=1,idn)
         end if
      end select
!...
      select case( ckind(1:1) )
      case( 'p' )
        allocate( awrk(ixl,ixl,ixl,iyl,idn) )
        if( ctype(1:1) .ne. 'A' .and. ctype(1:1) .ne. 'a' ) then
           allocate( wwrk(ixl,ixl,ixl,1,1) )
        end if
      case( 'f' )
!.                              * check instantaneous flag for fer/fbr *
        if( chead(1:3) .eq. 'feR' ) then
           idn = 2
           ctitle(2) = 'Electric_Field(inst.)'
        else if( chead(1:3) .eq. 'fbR' ) then
           idn = 2
           ctitle(2) = 'Magnetic_Field(inst.)'
        end if
!
        if( wxps .le. aundef ) then
           ixps = 1
        else
           ixps = ( wxps + wx0 ) / wxmic
           if( ixps .lt. 1 ) then
              write(0,*) '### WARNING: invalid xps', wxps, ixps
              write(0,*) '###        : ixps is assumed as 1'
              ixps = 1
           end if
        end if
        if( wxpe .le. aundef ) then
           ixpe = ixl
        else
           ixpe = ( wxpe + wx0 ) / wxmic
           if( ixpe .gt. ixl ) then
              write(0,*) '### WARNING: invalid xpe', wxpe, ixpe
              write(0,*) '###        : ixpe is assumed as', ixl
              ixpe = ixl
           end if
        end if
        if( ixps .gt. ixpe ) then
           write(0,*) '### ERROR: xps gt xpe', wxps, wxpe
           stop
        end if
        if( wyps .le. aundef ) then
           iyps = 1
        else
           iyps = ( wyps + wy0 ) / wymic
           if( iyps .lt. 1 ) then
              write(0,*) '### WARNING: invalid yps', wyps, iyps
              write(0,*) '###        : iyps is assumed as 1'
              iyps = 1
           end if
        end if
        if( wype .le. aundef ) then
           iype = iyl
        else
           iype = ( wype + wy0 ) / wymic
           if( iype .gt. iyl ) then
              write(0,*) '### WARNING: invalid ype', wype, iype
              write(0,*) '###        : iype is assumed as', iyl
              iype = iyl
           end if
        end if
        if( iyps .gt. iype ) then
           write(0,*) '### ERROR: yps gt ype', wyps, wype
           stop
        end if
        if( wzps .le. aundef ) then
           izps = 1
        else
           izps = ( wzps + wz0 ) / wzmic
           if( izps .lt. 1 ) then
              write(0,*) '### WARNING: invalid zps', wzps, izps
              write(0,*) '###        : izps is assumed as 1'
              izps = 1
           end if
        end if
        if( wzpe .le. aundef ) then
           izpe = izl
        else
           izpe = ( wzpe + wz0 ) / wzmic
           if( izpe .gt. izl ) then
              write(0,*) '### WARNING: invalid zpe', wzpe, izpe
              write(0,*) '###        : izpe is assumed as', izl
              izpe = izl
           end if
        end if
        if( izps .gt. izpe ) then
           write(0,*) '### ERROR: zps gt zpe', wzps, wzpe
           stop
        end if
!.
        ixn  = ( ixpe - ixps ) / intx + 1
        if( ixn .lt. 2 ) then
           write(0,*) '### ERROR: invalid x interval', &
	                 ixps,ixpe,intx
           stop
        end if
        iyn  = ( iype - iyps ) / inty + 1
        if( iyn .lt. 2 ) then
           write(0,*) '### ERROR: invalid y interval', &
                         iyps,iype,inty
           stop
        end if
        izn  = ( izpe - izps ) / intz + 1
        if( izn .lt. 2 ) then
           write(0,*) '### ERROR: invalid z interval', &
                         izps,izpe,intz
           stop
        end if
!..
        wxps = ( ixps-1 ) * wxmic - wx0
        wyps = ( iyps-1 ) * wymic - wy0
        wzps = ( izps-1 ) * wzmic - wz0
        wxpe = wxps + wxmic * intx * ( ixn - 1 )
        wype = wyps + wymic * inty * ( iyn - 1 )
        wzpe = wzps + wzmic * intz * ( izn - 1 )
        write(*,*) '----- ixps, ixpe, wxps, wxpe = ',ixps,ixpe,wxps,wxpe
        write(*,*) '----- iyps, iype, wyps, wype = ',iyps,iype,wyps,wype
        write(*,*) '----- izps, izpe, wzps, wzpe = ',izps,izpe,wzps,wzpe
        write(*,*) '----- ixn, iyn, izn = ', ixn, iyn, izn
        allocate( awrk(ico,ixl,iyl,izl,idn) )
        if( ismoi .ge. 1 ) allocate( awr2(ico,ixl,iyl,izl,idn) )
        if( ctype(1:1) .ne. 'A' .and. ctype(1:1) .ne. 'a' ) then
           allocate( wwrk(ico,ixn,iyn,izn,idn) )
        end if
      end select
!....
      write(*,*) '----- header: ', chead, ', ident: ', cident
!..
      if( ion .eq. 1 ) then
         do i = 2, idn
            ctitle(i) = ctitle(1)
         end do
         il = len_trim( ctitle(1) )
         do i = 1, idn
            call o3ionlabel( i, aionam(i), aionaz(i), ctitle(i)(il+1:) )
         end do
      end if
      crange = 'range(-xx.x,-xx.x,-xx.x)(-xx.x,-xx.x,-xx.x)'
!..
      icnt = iseq
!
    1 continue
         read(iunit, end=99) wtime, awrk
!..
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- seq#, time = ', icnt, wtime
!.                                                         * smoothing *
         do i = 1, ismoi
            awr2(:,2:ixl-1,2:iyl-1,2:izl-1,:) = &
               ( awrk(:,1:ixl-2,2:iyl-1,2:izl-1,:) + &
                 awrk(:,3:ixl  ,2:iyl-1,2:izl-1,:) + &
                 awrk(:,2:ixl-1,1:iyl-2,2:izl-1,:) + &
                 awrk(:,2:ixl-1,3:iyl  ,2:izl-1,:) + &
                 awrk(:,2:ixl-1,2:iyl-1,1:izl-2,:) + &
                 awrk(:,2:ixl-1,2:iyl-1,3:izl  ,:) + &
                 asmow * awrk(:,2:ixl-1,2:iyl-1,2:izl-1,:) )  / &
               ( asmow + 6.0d0 )
            awrk(:,2:ixl-1,2:iyl-1,2:izl-1,:) = &
                 awr2(:,2:ixl-1,2:iyl-1,2:izl-1,:)
         end do
!..
         select case( ckind(1:1) )
         case( 'p' )
           cheadx = chead
           if( idn .gt. 1 ) then
             izn = index( cheadx, ' ' )
             cheadx(izn:izn+2) = '-i#'
           end if
           if( iyl .gt. 1 ) then
             izl = index( cheadx, ' ' )
             cheadx(izl:izl+4) = '-loc#'
           end if
           do i = 1, idn
             if( idn .gt. 1 ) then
               write( cheadx(izn+2:izn+2), '(i1)' ) i
             end if
             do il = 1, iyl
               if( iyl .gt. 1 ) then
                 write( cheadx(izl+4:izl+4), '(i1)' ) il
               end if
               call fntpcnv ( cvtfntp, irank, icnt, cident, &
                              trim(cheadx), cfile )
!
               wxps = - ( ixl-1 ) / ( 2.0d0 * wfct(il,i) )
               wyps = 1.0d0 / wfct(il,i)
               write( crange(7:11),  '(f5.1)' ) wpos(1,il)
               write( crange(13:17), '(f5.1)' ) wpos(2,il)
               write( crange(19:23), '(f5.1)' ) wpos(3,il)
               write( crange(26:30), '(f5.1)' ) wpos(4,il)
               write( crange(32:36), '(f5.1)' ) wpos(5,il)
               write( crange(38:42), '(f5.1)' ) wpos(6,il)
!
               select case( ctype(1:1) )
               case( 'a', 'A' )
                 open(7, file=cfile, form='FORMATTED' )
                 write(7,'(a)') '# vtk DataFile Version 3.0'
                 write(cbuff,'(f8.2)') wtime 
                 write(7,'(a)') &
      trim(cident)//',time='//trim(adjustl(cbuff))//','//trim(crange)
                 write(7,'(a)') 'ASCII' 
                 write(7,'(a)') 'DATASET STRUCTURED_POINTS'
                 write(7,'(a,1x,3i5)') 'DIMENSIONS', ixl, ixl, ixl
                 write(7,'(a,1x,3e12.4)') 'ORIGIN', wxps, wxps, wxps
                 write(7,'(a,1x,3e12.4)') 'SPACING', wyps, wyps, wyps
                 write(7,'(a,1x,i9)') 'POINT_DATA', ixl*ixl*ixl
                 write(7,'(a,1x,a,1x,a)') 'SCALARS', &
                                               trim(ctitle(i)), 'float'
                 write(7,'(a)') 'LOOKUP_TABLE default'
                 write(7, '(6e12.4)' ) awrk(:,:,:,il,i)
                 close(7)
               case default
                 open(7, file=cfile, access='STREAM', &
                      form='UNFORMATTED', convert='BIG_ENDIAN' )
                 write(cbuff,'(a)') '# vtk DataFile Version 3.0'
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(f8.2)') wtime 
                 write(7) &
      trim(cident)//',time='//trim(adjustl(cbuff))//','//trim(crange)//&
      new_line('A')
                 write(cbuff,'(a)') 'BINARY' 
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a)') 'DATASET STRUCTURED_POINTS'
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a,1x,3i5)') 'DIMENSIONS', ixl, ixl, ixl
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a,1x,3e12.4)') 'ORIGIN', wxps, wxps, wxps
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a,1x,3e12.4)') 'SPACING', wyps,wyps,wyps
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a,1x,i9)') 'POINT_DATA', ixl*ixl*ixl
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a,1x,a,1x,a)') 'SCALARS', &
                                               trim(ctitle(i)), 'float'
                 write(7) trim(cbuff)//new_line('A')
                 write(cbuff,'(a)') 'LOOKUP_TABLE default'
                 write(7) trim(cbuff)//new_line('A')
                 wwrk(:,:,:,1,1) = awrk(:,:,:,il,i)
                 write(7) wwrk(:,:,:,1,1)
                 close(7)
               end select
             end do
           end do
!..
         case( 'f' )
           call fntpcnv ( cvtfntp, irank, icnt, cident, chead, cfile )
!.
           select case( ctype(1:1) )
           case( 'a', 'A' )
             open(7, file=cfile, form='FORMATTED' )
             write(7,'(a)') '# vtk DataFile Version 3.0'
             write(cbuff,'(f8.2)') wtime 
             write(7,'(a)') trim(cident)//',time='//trim(adjustl(cbuff))
             write(7,'(a)') 'ASCII' 
             write(7,'(a)') 'DATASET STRUCTURED_POINTS'
             write(7,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, izn
             write(7,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, wzps
             write(7,'(a,1x,3e12.4)') 'SPACING', &
                                        intx*wxmic,inty*wymic,intz*wzmic
             write(7,'(a,1x,i9)') 'POINT_DATA', ixn*iyn*izn
             do i = 1, idn
                if( ico .eq. 1 ) then
                   write(7,'(a,1x,a,1x,a)') 'SCALARS', &
                                                 trim(ctitle(i)), 'float'
                   write(7,'(a)') 'LOOKUP_TABLE default'
                else
                   write(7,'(a,1x,a,1x,a)') 'VECTORS', &
                                                 trim(ctitle(i)), 'float'
                end if
                write(7, '(6e12.4)' ) &
                   awrk(:,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,i)
             end do
             close(7)
           case default
             open(7, file=cfile, access='STREAM', form='UNFORMATTED', &
                     convert='BIG_ENDIAN' )
             write(cbuff,'(a)') '# vtk DataFile Version 3.0'
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(f8.2)') wtime 
             write(7) &
              trim(cident)//',time='//trim(adjustl(cbuff))//new_line('A')
             write(cbuff,'(a)') 'BINARY' 
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(a)') 'DATASET STRUCTURED_POINTS'
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(a,1x,3i5)') 'DIMENSIONS', ixn, iyn, izn
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(a,1x,3e12.4)') 'ORIGIN', wxps, wyps, wzps
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(a,1x,3e12.4)') 'SPACING', &
                                        intx*wxmic,inty*wymic,intz*wzmic
             write(7) trim(cbuff)//new_line('A')
             write(cbuff,'(a,1x,i9)') 'POINT_DATA', ixn*iyn*izn
             write(7) trim(cbuff)//new_line('A')
             wwrk(:,:,:,:,:) = &
                awrk(:,ixps:ixpe:intx,iyps:iype:inty,izps:izpe:intz,:)
             do i = 1, idn
                if( ico .eq. 1 ) then
                   write(cbuff,'(a,1x,a,1x,a)') 'SCALARS', &
                                                trim(ctitle(i)), 'float'
                   write(7) trim(cbuff)//new_line('A')
                   write(cbuff,'(a)') 'LOOKUP_TABLE default'
                   write(7) trim(cbuff)//new_line('A')
                else
                   write(cbuff,'(a,1x,a,1x,a)') 'VECTORS', &
                                                trim(ctitle(i)), 'float'
                   write(7) trim(cbuff)//new_line('A')
                end if
                write(7) wwrk(:,:,:,:,i)
             end do
             close(7)
           end select
         end select
!.
         icnt = icnt + 1
!...
         do i = 1, intt-1
            read(iunit, end=99) wtime
            write(*,*) '... skipping', wtime
         end do
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
