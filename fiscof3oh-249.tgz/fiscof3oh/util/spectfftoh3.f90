!---------------------------------------------------------------------
! plot spectrum for Omega (OhHelp version)
!
      implicit none
      integer, parameter :: ldata = 100000, lspect = 16384*4, iun0 = 9
      integer, parameter :: lsp2 = lspect/2
      integer :: iffts3(15), i, ii, iii, is, ip, ids, iflag, idl, &
                 ist, ilen, ilen2, iofewl, iwmax 
      integer :: ir, irank, idivx, idivy, idivz, isize, iposs, ipose, iunit
      integer, allocatable :: iposl(:)
      real*8  :: data(3,ldata,5), spect(lspect) , wffts1(lspect), &
                 wffts2(lspect), awx(0:lsp2), amp(0:lsp2,0:3), &
		 wofewxp(5), wofewyp(5), wofewzp(5), &
		 wstcur, wdelt, wdt, wtime, awmax, ampmx
      real*8  :: wofewxps(5), wofewyps(5), wofewzps(5)
      character chead*4, cident*16, ctime*12, ctitle*31
      character cbifntp*64, cfile*128
!....
      cbifntp = 'fort.%%.###'
!....
      iposs = 1
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      call fntpcnv ( cbifntp,ir-1,32, 'spectfftoh', 'few', cfile ) 
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )

      read(iunit) chead, cident, wdelt, iofewl, &
               (wofewxp(i), wofewyp(i), wofewzp(i), i=1,iofewl), irank,idivx,idivy,idivz
      write(0,*) chead, ' ', cident, wdelt, iofewl, &
               (wofewxp(i), wofewyp(i), wofewzp(i), i=1,iofewl), irank,idivx,idivy,idivz
!
      if( ir-1 .eq. 0 ) then
         isize = idivx * idivy * idivz
         allocate( iposl(isize) )
      end if
!
      iposl(ir) = iofewl
      if( iofewl .gt. 0 ) then
         do i = 1, iofewl
            wofewxps(i+iposs-1) = wofewxp(i)
            wofewyps(i+iposs-1) = wofewyp(i)
            wofewzps(i+iposs-1) = wofewzp(i)
         end do
         iposs = iposs + iofewl
      end if
!
      if( ir .eq. isize ) exit
!
      end do
!...
      iposs = 1
      do ir = 1, isize
!.
      if( iposl(ir) .gt. 0 ) then
!
      iunit = iun0 + ir
      ipose = iposs + iposl(ir) - 1
      ids = 0
    1 continue
         read(iunit,end=2)  wstcur, iflag, idl, &
        ( ( ( data(iii,ids+ii,i),iii=1,3),ii=1,idl),i=iposs,ipose)
         write(*,*) 'wstcur, iflag, idl = ', wstcur, iflag, idl
         ids = ids + idl
      go to 1
    2 continue
      iposs = ipose + 1
!
      end if
!
      end do
!..
      wdt = wstcur / ids
      write(*,*) 'ids, wdt = ', ids, wdt
!..
      write(0,*) 'enter ist, ilen, awmax'
      read(*,*) ist, ilen, awmax
!.
      ist = ist - 1
      ilen2 = ilen / 2
      wtime = ( ist + ilen2 ) * wdt
      ctime = 'xxxx.xx fsec'
      write( ctime(1:7), '(f7.2)' ) wtime
!..
      call rffti ( ilen, wffts2, iffts3 )
!....
      call fr_ginit 
      call fr_opencanvas( 1, 'spectfftoh-'//cident, 10 )
      chead = 'xyz'
!...
      do ip = 1, ipose
!
	 do is = 0, ilen2
            amp(is,0) = 0.0d0
	 end do
         do is = 1, 3
            do i = 1, ilen
               spect(i) = data(is,ist+i,ip)
            end do
            call rfftf ( ilen, spect, wffts1, wffts2, iffts3 )
            amp(0,0) = amp(0,0) + spect(1)**2
            amp(0,is) = spect(1)**2
            do i = 1, ilen2-1
               amp(i,0) = amp(i,0) + spect(i*2)**2 + spect(i*2+1)**2
               amp(i,is) = spect(i*2)**2 + spect(i*2+1)**2
            end do
            amp(ilen2,0) = amp(ilen2,0) + spect(ilen)**2
            amp(ilen2,is) = spect(ilen)**2
         end do
!..
         ampmx = 0.0d0
         do i = 0, ilen2
            ampmx = max( ampmx, amp(i,0) )
            awx(i)  = wdelt / ilen * i
            if( awx(i) .gt. awmax ) then
               iwmax = i-1
               go to 20
            end if
         end do
         awmax = awx(ilen2)
         iwmax = ilen2
   20    continue
!....
         do is = 0, 3
            do i = 0, iwmax
               amp(i,is) = log10(max(sqrt(amp(i,is)/ampmx),1.0d-4))
            end do
         end do
	 ctitle = 'position (-xx.xx,-xx.xx,-xx.xx)'
	 write( ctitle(11:16), '(f6.2)' ) wofewxps(ip)
	 write( ctitle(18:23), '(f6.2)' ) wofewyps(ip)
	 write( ctitle(25:30), '(f6.2)' ) wofewzps(ip)
!....
         call fr_gclear
         call fr_frame2d ( 0.0d0, awmax, -4.0d0, 0.0d0, 11 )
         call fr_logaxis ( 2 )
         call fr_graph2d ( awx(0), amp(0,0), iwmax+1, 2, 1 )
         call fr_fpchars ( 50.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 150.0d0, 15.0d0, ctitle, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
         call fr_xyname ( 'omega[W/W-L]', 'spectrum[a.u.]' )
!...
         call fr_gclear
         call fr_frame2d ( 0.0d0, awmax, -4.0d0, 0.0d0, 11 )
         call fr_logaxis ( 2 )
	 do is = 1, 3
            call fr_graph2d ( awx(0), amp(0,is), iwmax+1, 2+is, 1 )
            call fr_fpchars ( 580.0d0, 5.0d0+12.0d0*is, chead(is:is), &
	                      2+is, 1, -1, 0, 0 )
	 end do
         call fr_fpchars ( 50.0d0, 15.0d0, cident, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 150.0d0, 15.0d0, ctitle, 7, 1, -1, 0, 0 )
         call fr_fpchars ( 400.0d0, 15.0d0, ctime, 7, 1, -1, 0, 0 )
         call fr_xyname ( 'omega[W/W-L]', 'spectrum[a.u.]' )
!...
      end do
!....
      call fr_gend
!....
      stop
      end
