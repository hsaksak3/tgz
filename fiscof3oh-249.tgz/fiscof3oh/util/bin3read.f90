implicit none
character :: chead*4, cident*16
real*8 :: soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, sstcur
real*8, allocatable :: weaa(:)
integer :: i, loxyzpl, loxpl, loypl, lozpl, icnt
!
read(22) chead, cident, loxyzpl, loxpl, loypl, lozpl,  &
     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
!
write(*,*) '"',chead,'" "', cident,'"', loxyzpl, loxpl, loypl, lozpl,  &
     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
!
allocate( weaa(loxyzpl) )
icnt = 0
1 continue
read(22,end=999) sstcur, ( weaa(i),i=1,loxyzpl )
!
icnt = icnt + 1
write(*,*) sstcur, weaa(1), weaa(2)
go to 1
!
999 continue
write(*,*) 'icnt =', icnt
stop
end
