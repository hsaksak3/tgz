!----------------------------------------------------------------------
! binoh3bin: convert binary files of OhHelp version to single binary file
!
! namelist param
!   ckind  : observation kind
!   cbifntp: file name template for binary file
!          : default is 'fort.%%.###'
!          : should be same as bbifntp in fiscof3 input data
!          : see ~/doc/fn_template file for details
!   cidentb: identification character for cbifntp
!   wts    : start time (default is 0.0)
!   wte    : end time (default is 9999.0)
!----------------------------------------------------------------------
      use parameter, only:lionspx, lopemx, lopimx
      implicit none
      integer, parameter :: iun0 = 9
      integer :: i, il, ico, idn, iunit, ixl, iyl, izl, ixyzl, &
                 irank, ion
      real*8, allocatable :: awrk(:,:,:,:,:), wfct(:,:), wpos(:,:)
      real*8  :: wxmic, wx0, wymic, wy0, wzmic, wz0, &
                 wts, wte, wtime, wteps=0.02d0, &
                 aionam(lionspx), aionaz(lionspx)
      character :: ckind*4, chead*4, cident*16, cidentb*16, &
                   cbifntp*64, cfile*128, cbuff*80
!
      integer :: iun, ir, isize, ivoxel, &
                 ixas, ixae, ixal, iyas, iyae, iyal, izas, izae, izal
      integer :: idivx, idivy, idivz, ixals, iyals, izals, i0s
      integer, allocatable :: ixass(:), ixaes(:), ixans(:), &
                              iyass(:), iyaes(:), iyans(:), &
                              izass(:), izaes(:), izans(:)
      real*8  :: wx0s, wy0s, wz0s
      real*8, allocatable :: gwrk(:,:,:,:,:)
      character cidents*16
!.
      namelist /param/ ckind, cbifntp, cidentb, wts, wte
!....
      ckind   = ' '
      cbifntp = 'fort.%%.###'
      cidentb = ' '
      wts     = 0.0d0
      wte     = 9999.0d0
!..
      read(*,param)
      write(*,param)
!....
      ion = 0
      select case( ckind )
      case( 'pem' ) 
         iun = 22
         ico = 1
         idn = 1
      case( 'pim' ) 
         iun = 23
         ico = 1
         idn = 0
         ion = 1
      case( 'fde' )
         iun = 24
         ico = 1
         idn = 1
      case( 'fdi' )
         iun = 25
         ico = 1
         idn = 0
         ion = 1
      case( 'fdc' )
         iun = 26
         ico = 1
         idn = 1
      case( 'fea' )
         iun = 27
         ico = 1
         idn = 1
      case( 'fer' )
         iun = 28
         ico = 3
         idn = 1
      case( 'fba' )
         iun = 29
         ico = 1
         idn = 1
      case( 'fbr' )
         iun = 30
         ico = 3
         idn = 1
      case( 'fje' )
         iun = 31
         ico = 3
         idn = 1
      case( 'fji' )
         iun = 32
         ico = 3
         idn = 0
         ion = 1
      case( 'fjt' )
         iun = 33
         ico = 3
         idn = 1
      case( 'fte' )
         iun = 34
         ico = 1
         idn = 2
      case( 'fede' )
         iun = 36
         ico = 1
         idn = 1
      case( 'fedi' )
         iun = 37
         ico = 1
         idn = 0
         ion = 1
      case default
         write(0,*) '### ERROR: invalid obs. kind ', ckind
         stop
      end select
!....
      if( ckind(1:1) .eq. 'p' ) then
         izl = max( lopemx, lopimx )
         allocate( wfct(izl,lionspx), wpos(6,izl) )
      end if
!..
      i0s = 0
      ivoxel = 0
!....
      do ir = 1, 999999
!..
      iunit = iun0 + ir
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, &
                                        'fE'//ckind(4:4), cfile ) 
      else
         call fntpcnv ( cbifntp, ir-1, iun, cidentb, ckind, cfile )
      end if
      open( iunit, file=cfile, form='UNFORMATTED', status='OLD' )
!..
      select case( ckind(1:1) )
      case( 'p' )
         if( ion .eq. 0 ) then
            read(iunit) chead, cident, ixl, iyl, &
                        ( wfct(i,1),wpos(:,i),i=1,iyl ), &
                        irank, idivx, idivy, idivz
            write(*,*) chead, ' ', cident, ixl, iyl, &
                       ( wfct(i,1),wpos(:,i),i=1,iyl ), &
                       irank, idivx, idivy, idivz
         else
            read(iunit) chead, cident, ixl, iyl, idn, &
                        ( (aionam(i),aionaz(i),i=1,idn), &
                          wfct(il,1:idn),wpos(:,il),il=1,iyl ), &
                        irank, idivx, idivy, idivz
            write(*,*) chead, ' ', cident, ixl, iyl, idn, &
                       ( (aionam(i),aionaz(i),i=1,idn), &
                         wfct(il,1:idn),wpos(:,il),il=1,iyl ), &
                       irank, idivx, idivy, idivz
         end if
!
         if( ir-1 .eq. 0 ) then
            isize = idivx * idivy * idivz
            cidents = cident
            if( ckind(3:3) .eq. 'e' ) then
               allocate( awrk(ixl,iyl,idn,1,1), &
                         gwrk(ixl,iyl,idn,1,1) )
            else
               allocate( awrk(ixl,ixl,ixl,iyl,idn), &
                         gwrk(ixl,ixl,ixl,iyl,idn) )
            end if
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch', cidents, cident
               stop
            end if
         end if
!.
      case( 'f' )
         if( ion .eq. 0 ) then
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        irank, idivx, idivy, idivz, &
                        ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       irank, idivx, idivy, idivz, &
                       ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
         else
            read(iunit) chead, cident, ixyzl, ixl, iyl, izl, &
                        wxmic, wx0, wymic, wy0, wzmic, wz0, &
                        idn, (aionam(i),aionaz(i),i=1,idn), &
                        irank, idivx, idivy, idivz, &
                        ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
            write(*,*) chead, ' ', cident, ixyzl, ixl, iyl, izl, &
                       wxmic, wx0, wymic, wy0, wzmic, wz0, &
                       idn, (aionam(i),aionaz(i),i=1,idn), &
                       irank, idivx, idivy, idivz, &
                       ixal,ixas,ixae, iyal,iyas,iyae, izal,izas,izae
         end if
!..
         if( ixyzl .ne. -1 ) then
            if( ixl.ne.(ixae-ixas+1) .or. iyl.ne.(iyae-iyas+1) .or. &
                izl.ne.(izae-izas+1) ) then
              write(0,*) '### ERROR: data size mismatch', &
                         ixas,ixae,iyas,iyae,izas,izae
              stop
            end if
         end if
!..
         if( ir-1 .eq. 0 ) then
!.                              * check instantaneous flag for fer/fbr *
            if( chead(3:3) .eq. 'R' ) idn = 2
!
            isize = idivx * idivy * idivz
            ixals = ixal
            iyals = iyal
            izals = izal
            cidents = cident
            allocate( ixass(isize), ixaes(isize), ixans(isize), &
                      iyass(isize), iyaes(isize), iyans(isize), &
                      izass(isize), izaes(isize), izans(isize) )
            allocate( gwrk(ico,ixal,iyal,izal,idn) )
!.
         else if( ir .le. isize ) then
            if( cident .ne. cidents ) then
               write(0,*) '### ERROR: cident mismatch ',cident,cidents 
               stop
            end if
            if( ixal.ne.ixals.or.iyal.ne.iyals.or.izal.ne.izals ) then
               write(0,*) '### ERROR: total size mismatch', &
                          ixal,ixals,iyal,iyals,izal,izals
               stop
            end if
         end if  
!..
         if( i0s .eq. 0 .and. ixyzl .ne. -1 ) then
            wx0s = wx0
            wy0s = wy0
            wz0s = wz0
            i0s = 1
         end if  
!..
         ixass(ir) = ixas
         ixaes(ir) = ixae
         ixans(ir) = ixae - ixas + 1
         iyass(ir) = iyas
         iyaes(ir) = iyae
         iyans(ir) = iyae - iyas + 1
         izass(ir) = izas
         izaes(ir) = izae
         izans(ir) = izae - izas + 1
!
         ivoxel = ivoxel + ixans(ir)*iyans(ir)*izans(ir)
      end select
!..
      if( ir .eq. isize ) exit
!..
      end do
!....
      select case( ckind(1:1) )
      case( 'p' )
!..
      case( 'f' )
         if( ivoxel .ne. ixal*iyal*izal ) then
            write(0,*) '### ERROR: total #voxel mismatch', &
                          ivoxel,ixal,iyal,izal
            stop
         end if
      end select
!.
      write(*,*) '----- header: ', chead, ', ident: ', cident
!....
      if( ckind .eq. 'fede'  .or. ckind .eq. 'fedi' ) then
         call fntpcnv ( cbifntp, -1, iun, cident, &
                                        'fE'//ckind(4:4), cfile ) 
      else
         call fntpcnv ( cbifntp, -1, iun, cident, ckind, cfile )
      end if
      open( iun0, file=cfile, form='UNFORMATTED' )
!..
      chead(4:4)='4'
!
      select case( ckind(1:1) )
      case( 'p' )
         if( ion .eq. 0 ) then
            write(iun0) chead, cident, ixl, iyl, &
                       ( wfct(i,1),wpos(:,i),i=1,iyl )
         else
            write(iun0) chead, cident, ixl, iyl, idn, &
                       ( (aionam(i),aionaz(i),i=1,idn), &
                         wfct(il,1:idn),wpos(:,il),il=1,iyl )
         end if
!.
      case( 'f' )
         if( ion .eq. 0 ) then
            write(iun0) chead, cident, ivoxel, ixal, iyal, izal, &
                        wxmic, wx0s, wymic, wy0s, wzmic, wz0s
         else
            write(iun0) chead, cident, ivoxel, ixal, iyal, izal, &
                        wxmic, wx0s, wymic, wy0s, wzmic, wz0s, &
                        idn, (aionam(i),aionaz(i),i=1,idn)
         end if
      end select
!...
    1 continue
!..
         do ir = 1, isize
!..
         iunit = iun0 + ir
!..
         select case( ckind(1:1) )
         case( 'p' )
           if( ir .eq. 1 ) gwrk(:,:,:,:,:) = 0.0d0
           read(iunit, end=99) wtime, awrk
           gwrk(:,:,:,:,:) = gwrk(:,:,:,:,:) + awrk(:,:,:,:,:)
         case( 'f' )
           if( ixans(ir) .gt. 0 .and. iyans(ir) .gt. 0 .and. &
               izans(ir) .gt. 0 ) then
              allocate( awrk(ico,ixans(ir),iyans(ir),izans(ir),idn) )
              read(iunit, end=99) wtime, awrk
              gwrk(:,ixass(ir):ixaes(ir),iyass(ir):iyaes(ir),&
                     izass(ir):izaes(ir),:) = awrk(:,:,:,:,:)
              deallocate( awrk )
           end if
         end select
!.
         end do
!...
         if( wtime .lt. wts-wteps ) then
            write(*,*) '... skipping before wts', wts, wtime
	    go to 1
         end if
!.
         if( wtime .gt. wte+wteps ) then
            write(*,*) '----- end after wte', wte, wtime
            go to 2
         end if
!..
         write(*,*) '----- time = ', wtime
!.
         write(iun0) wtime, gwrk(:,:,:,:,:)
      go to 1
!...
   99 continue
      write(*,*) '----- end by EOF'
!...
    2 continue
!....
      stop
      end
