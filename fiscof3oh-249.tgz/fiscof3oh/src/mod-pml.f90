!----------------------------------------------------------------------
! pml
!
module pml
      integer :: lblsgxl, lblsgxu, lblsgyl, lblsgyu, lblsgzl, lblsgzu
      real*8  :: sblsgxl, sblsgxu, sblsgyl, sblsgyu, sblsgzl, sblsgzu
      real*8, allocatable, save :: &
                 scaxli(:), scaxlh(:), scaxui(:), scaxuh(:), &
                 scayli(:), scaylh(:), scayui(:), scayuh(:), &
                 scazli(:), scazlh(:), scazui(:), scazuh(:), &
                 scbbxlh(:), scbbxuh(:), scbbylh(:), scbbyuh(:), &
                 scbbzlh(:), scbbzuh(:), &
                 scbexli(:), scbexui(:), scbeyli(:), scbeyui(:), &
                 scbezli(:), scbezui(:)
#ifndef OHHELP
      real*8, allocatable, save :: &
         sbxyyl(:,:,:), sbxyyu(:,:,:), sbxyzl(:,:,:), sbxyzu(:,:,:), &
         sbxzyl(:,:,:), sbxzyu(:,:,:), sbxzzl(:,:,:), sbxzzu(:,:,:), &
         sbyxxl(:,:,:), sbyxxu(:,:,:), sbyxzl(:,:,:), sbyxzu(:,:,:), &
         sbyzxl(:,:,:), sbyzxu(:,:,:), sbyzzl(:,:,:), sbyzzu(:,:,:), &
         sbzxxl(:,:,:), sbzxxu(:,:,:), sbzxyl(:,:,:), sbzxyu(:,:,:), &
         sbzyxl(:,:,:), sbzyxu(:,:,:), sbzyyl(:,:,:), sbzyyu(:,:,:), &
         sexyyl(:,:,:), sexyyu(:,:,:), sexyzl(:,:,:), sexyzu(:,:,:), &
         sexzyl(:,:,:), sexzyu(:,:,:), sexzzl(:,:,:), sexzzu(:,:,:), &
         seyxxl(:,:,:), seyxxu(:,:,:), seyxzl(:,:,:), seyxzu(:,:,:), &
         seyzxl(:,:,:), seyzxu(:,:,:), seyzzl(:,:,:), seyzzu(:,:,:), &
         sezxxl(:,:,:), sezxxu(:,:,:), sezxyl(:,:,:), sezxyu(:,:,:), &
         sezyxl(:,:,:), sezyxu(:,:,:), sezyyl(:,:,:), sezyyu(:,:,:)
#else
      real*8, allocatable, save :: &
         oh_sebpmlxl(:,:,:,:,:), oh_sebpmlxu(:,:,:,:,:), &
         oh_sebpmlyl(:,:,:,:,:), oh_sebpmlyu(:,:,:,:,:), &
         oh_sebpmlzl(:,:,:,:,:), oh_sebpmlzu(:,:,:,:,:)
#endif
end module pml
