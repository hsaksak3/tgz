!-----------------------------------------------------------------------
! Advance 3D Field Electric 
!
      subroutine a3fe
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'a3fe', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iy)
   do iz = lsszlm1, lsszup1
     do iy = lssylm1, lssyup1
       do ix = lssxl, lssxup1
         sex(ix,iy,iz) = sex(ix,iy,iz) + &
                       ( sbz(ix,iy+1,iz) - sbz(ix,iy,iz) - &
                         sby(ix,iy,iz+1) + sby(ix,iy,iz) ) * scb1 + &
                         sjxt(ix,iy,iz) * scj1
       end do
     end do
   enddo
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iy)
   do iz = lsszlm1, lsszup1
     do iy = lssyl, lssyup1
       do ix = lssxlm1, lssxup1
         sey(ix,iy,iz) = sey(ix,iy,iz) + &
                       ( sbx(ix,iy,iz+1) - sbx(ix,iy,iz) - &
                         sbz(ix+1,iy,iz) + sbz(ix,iy,iz) ) * scb1 + &
                         sjyt(ix,iy,iz) * scj1
       end do
     end do
   enddo
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iy)
   do iz = lsszl, lsszup1
     do iy = lssylm1, lssyup1
       do ix = lssxlm1, lssxup1
         sez(ix,iy,iz) = sez(ix,iy,iz) + &
                       ( sby(ix+1,iy,iz) - sby(ix,iy,iz) - &
                         sbx(ix,iy+1,iz) + sbx(ix,iy,iz) ) * scb1 + &
                         sjzt(ix,iy,iz) * scj1
       end do
     end do
   enddo
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'a3fe', 1 )
!....
      return
      end
