c--------------------------------------------------------------------
c   qssortp
c
c        1. purpose   sorting
c
c--------------------------------------------------------------------
      subroutine qssortp( ran, particle1, n1 )
c....
      use ptcltype
      include "real8.h"
c....
      real*8 :: ran(n1)
      type(ty1_particle) :: particle1(n1), at1
      integer, allocatable :: is(:)
      save
c....
      isl = n1/2
      allocate( is(isl) )
c....
      l=1
      m=n1
      n=0
    1 i=l
      j=m
      k=(i+j+1)/2
      c=ran(k)
    2 if(j.lt.l)                    goto 3
      if(ran(j).lt.c)               goto 3
      j=j-1
                                    goto 2
    3 if(ran(i).ge.c.or.i.gt.m)     goto 4
      i=i+1
                                    goto 3
    4 if(i.ge.j)                    goto 5
      t=ran(i)
      ran(i)=ran(j)
      ran(j)=t
      at1=particle1(i)
      particle1(i)=particle1(j)
      particle1(j)=at1
      i=i+1
      j=j-1
      if(i.le.j)                    goto 2
    5 if(i-l-1)                     6,7,9
    6 t=ran(i)
      ran(i)=c
      ran(k)=t
      at1=particle1(i)
      particle1(i)=particle1(k)
      particle1(k)=at1
    7 l=l+1
    8 if(l.ne.m)                    goto 1
      if(n.eq.0) then
         deallocate( is )
         return
      end if
      l=l+1
      m=is(n)
      n=n-1
                                    goto 8
    9 n=n+1
      if( n .gt. isl ) then
         write(*,*) '### ERROR: qssortp overflow stack ', isl
         stop
      end if
      is(n)=m
      m=i-1
                                    goto 1
c....
      end
