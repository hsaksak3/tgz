!-----------------------------------------------------------------------
! Compute 3D Field current(J) Electron with Current Conservation
!
      subroutine c3fjecc
!
!   <arguments>
!     none
!
!   <remarks>
!     lccsch : current conservation scheme
!            : = 0 : Esirkepov's scheme
!            : = 1 : 1st order ZigZag scheme
!            : = 3 : 3rd order ZigZag scheme and 2nd order interpolation
!
!    coded by Sakagami,H. (NIFS) 20/11/06
!-----------------------------------------------------------------------
#include "spdat.macro"
#include "interpolate.macro"
#include "vector.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
#include "pindexoh.macro"
#endif
      use constant
      include "implicit.h"
!....
      call fdebug ('c3fjecc', 0 )
!....
      select case( lccsch )
      case( 0 )
        call c3fjecc_esirkepov
#ifndef VECTOR
#ifndef OHHELP
      case( 1 )
        call c3fjecc_zigzag1
#endif
#endif
      case( 3 )
        call c3fjecc_zigzag32
      case default
        write(0,*) '### ERROR: invalid lccsch', lccsch
        call s3ext_abort
      end select
!....
      call fdebug ( 'c3fjecc', 1 )
!....
      return
      end
!-----------------------------------------------------------------------
! Compute 3D Field current(J) Electron with Current Conservation
! by Esirkepov's scheme
!
      subroutine c3fjecc_esirkepov
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
! original by Hata,M. (Nagoya Univ.) 09/11/06
!    coded by Sakagami,H. (NIFS) 20/11/06
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, iz, ixo, iyo, izo, ixn, iyn, izn, &
                 ixd, iyd, izd, ixx, iyy, izz
      real*8  :: wxd, wyd, wzd
      real*8  :: wdffx(6), wdffy(6), wdffz(6), &
                 wdjx(6,6,6), wdjy(6,6,6), wdjz(6,6,6)
#ifndef VECTOR
      real*8  :: wffxo(6), wffxn(6), wjjx(6,6,6), &
                 wffyo(6), wffyn(6), wjjy(6,6,6), &
                 wffzo(6), wffzn(6), wjjz(6,6,6)
#else
      real*8, allocatable :: &
                 vwffxo(:,:), vwffxn(:,:), vwjjx(:,:,:,:), &
                 vwffyo(:,:), vwffyn(:,:), vwjjy(:,:,:,:), &
                 vwffzo(:,:), vwffzn(:,:), vwjjz(:,:,:,:)
      integer :: iv, iv2 
#endif
#ifdef OHHELP
      integer :: ips
#endif
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:,:), wjye(:,:,:), wjze(:,:,:)
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
#ifndef OHHELP
      if( lnoe .gt. 0 ) then
#else
      if( oh_glnoe .gt. 0 ) then
#endif
!....
      if ( .not. allocated(wjxe) ) then
#ifndef OHHELP
        allocate( &
          wjxe(lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2), &
          wjye(lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2), &
          wjze(lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3) )
#else
        allocate( &
          wjxe(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
               oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
               oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), &
          wjye(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
               oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
               oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), & 
          wjze(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
               oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
               oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)) )
#endif
      end if
!.
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
      oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
#endif
#ifndef VECTOR
!$OMP PARALLEL PRIVATE(ixo,ixn,ixd,wxd,wffxo,wffxn, &
!$OMP                  iyo,iyn,iyd,wyd,wffyo,wffyn, &
!$OMP                  izo,izn,izd,wzd,wffzo,wffzn, &
!$OMP                  ix,iy,iz,ixx,iyy,izz,wjjx,wjjy,wjjz, &
!$OMP                  wdffx,wdffy,wdffz,wdjx,wdjy,wdjz)
#else
!$OMP PARALLEL PRIVATE(ixo,ixn,ixd,wxd,vwffxo,vwffxn, &
!$OMP                  iyo,iyn,iyd,wyd,vwffyo,vwffyn, &
!$OMP                  izo,izn,izd,wzd,vwffzo,vwffzn, &
!$OMP                  ix,iy,iz,ixx,iyy,izz,vwjjx,vwjjy,vwjjz, &
!$OMP                  wdffx,wdffy,wdffz,wdjx,wdjy,wdjz,i,iv)
#endif
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            wjxe(ix,iy,iz) = s0o1
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            wjye(ix,iy,iz) = s0o1
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            wjze(ix,iy,iz) = s0o1
          end do
        end do
      end do
!....
#ifdef VECTOR
      if ( .not. allocated(vwffxo) ) then
        allocate( vwffxo(lvlen,6),vwffxn(lvlen,6),vwjjx(lvlen,6,6,6), &
                  vwffyo(lvlen,6),vwffyn(lvlen,6),vwjjy(lvlen,6,6,6), &
                  vwffzo(lvlen,6),vwffzn(lvlen,6),vwjjz(lvlen,6,6,6) )
      end if
      do iv = 1, lvlen
#endif
      _fxo(1) = s0o1
      _fxo(6) = s0o1
      _fyo(1) = s0o1
      _fyo(6) = s0o1
      _fzo(1) = s0o1
      _fzo(6) = s0o1
#ifdef VECTOR
      end do
#endif
!..
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye,wjze)
#ifndef VECTOR
      do i = lnoes, lnoee
#else
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
         _fxn(1) = s0o1
         _fxn(2) = s0o1
         _fxn(5) = s0o1
         _fxn(6) = s0o1
         _fyn(1) = s0o1
         _fyn(2) = s0o1
         _fyn(5) = s0o1
         _fyn(6) = s0o1
         _fzn(1) = s0o1
         _fzn(2) = s0o1
         _fzn(5) = s0o1
         _fzn(6) = s0o1
!..
#define _sx sxeo(i) 
#define _ixo ixo
#include "interpolate_defjxo.h"
#include "interpolate_xi.h"
!
#define _sy syeo(i) 
#define _iyo iyo
#include "interpolate_defjyo.h"
#include "interpolate_yi.h"
!
#define _sz szeo(i) 
#define _izo izo
#include "interpolate_defjzo.h"
#include "interpolate_zi.h"
!.
#undef _sx
#define _sx sxe(i)
#include "interpolate_defjxn.h"
#define _ixd ixd
#include "interpolate_xi.h"
!.
#undef _sy
#define _sy sye(i)
#include "interpolate_defjyn.h"
#define _iyd iyd
#include "interpolate_yi.h"
!.
#undef _sz
#define _sz sze(i)
#include "interpolate_defjzn.h"
#define _izd izd
#include "interpolate_zi.h"
#ifdef VECTOR
      end do
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
!..
!NEC$ UNROLL_COMPLETELY
         do ix = 1, 6
           wdffx(ix) = _fxn(ix) - _fxo(ix)
           wdffy(ix) = _fyn(ix) - _fyo(ix)
           wdffz(ix) = _fzn(ix) - _fzo(ix)
         end do
!..
!NEC$ UNROLL_COMPLETELY
         do iz = 1, 6
!NEC$ UNROLL_COMPLETELY
           do iy = 1, 6
!NEC$ UNROLL_COMPLETELY
             do ix = 1, 6
               wdjx(ix,iy,iz) = spfe(i) * wdffx(ix) * &
                 ( _fyo(iy)*_fzo(iz) + s1o2*wdffy(iy)*_fzo(iz) + &
                   s1o2*wdffz(iz)*_fyo(iy) + s1o3*wdffy(iy)*wdffz(iz) )
               wdjy(ix,iy,iz) = spfe(i) * wdffy(iy) * &
                 ( _fxo(ix)*_fzo(iz) + s1o2*wdffx(ix)*_fzo(iz) + &
                   s1o2*wdffz(iz)*_fxo(ix) + s1o3*wdffx(ix)*wdffz(iz) )
               wdjz(ix,iy,iz) = spfe(i) * wdffz(iz) * &
                 ( _fxo(ix)*_fyo(iy) + s1o2*wdffx(ix)*_fyo(iy) + &
                   s1o2*wdffy(iy)*_fxo(ix) + s1o3*wdffx(ix)*wdffy(iy) )
             end do
           end do
         end do
!..
!NEC$ UNROLL_COMPLETELY
         do iz = 1, 6
!NEC$ UNROLL_COMPLETELY
           do iy = 1, 6
             _fjx(1,iy,iz) = wdjx(1,iy,iz)
             _fjy(iy,1,iz) = wdjy(iy,1,iz)
             _fjz(iy,iz,1) = wdjz(iy,iz,1)
!NEC$ UNROLL_COMPLETELY
             do ix = 1, 5
               _fjx(ix+1,iy,iz) = _fjx(ix,iy,iz) + wdjx(ix+1,iy,iz)
               _fjy(iy,ix+1,iz) = _fjy(iy,ix,iz) + wdjy(iy,ix+1,iz)
               _fjz(iy,iz,ix+1) = _fjz(iy,iz,ix) + wdjz(iy,iz,ix+1)
             end do
           end do
         end do
#ifdef VECTOR
      end do
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
         _ixo = sxeo(i)
         _iyo = syeo(i)
         _izo = szeo(i)
#endif
!..
#ifdef OHHELP
         _ixo = _ixo - oh_ixs
         _iyo = _iyo - oh_iys
         _izo = _izo - oh_izs
#endif
         do iz = 1, 6
          izz = iz + _izo - 3
          do iy = 1, 6
           iyy = iy + _iyo - 3
           do ix = 1, 6
            ixx = ix + _ixo - 3
            wjxe(ixx+1,iyy,izz) = wjxe(ixx+1,iyy,izz) + _fjx(ix,iy,iz)
            wjye(ixx,iyy+1,izz) = wjye(ixx,iyy+1,izz) + _fjy(ix,iy,iz)
            wjze(ixx,iyy,izz+1) = wjze(ixx,iyy,izz+1) + _fjz(ix,iy,iz)
           end do
          end do
         end do
#ifdef VECTOR
      end do
#endif
      end do
!...
#include "periodic_boundary_je.h"
!...
#include "assign_je.h"
!...
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
      end if
!....
      return
      end
#ifndef VECTOR
#ifndef OHHELP
!-----------------------------------------------------------------------
! Compute 3D Field current(J) Electron with Current Conservation
! by 1st order ZigZag scheme
!
      subroutine c3fjecc_zigzag1
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/19
!----------------------------------------------------------------------
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, iz, &
                 ixi1, ixh1, iyi1, iyh1, izi1, izh1, &
                 ixi2, ixh2, iyi2, iyh2, izi2, izh2
      real*8  :: wmin, wmax, wxr, wyr, wzr, wfx1, wfx2, wfy1, wfy2, &
                 wfz1, wfz2, wdxi1, wdxi2, wdyi1, wdyi2, wdzi1, wdzi2, &
                 wx1i, wx2i, wy1i, wy2i, wz1i, wz2i
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:,:), wjye(:,:,:), wjze(:,:,:)
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
      if( lnoe .gt. 0 ) then
!....
      if( .not. allocated(wjxe) ) then
        allocate( &
          wjxe(lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2), &
          wjye(lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2), &
          wjze(lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3) )
      end if
!.
!$OMP PARALLEL PRIVATE(ix,ixi1,ixh1,iyi1,iyh1,izi1,izh1, &
!$OMP                  iy,ixi2,ixh2,iyi2,iyh2,izi2,izh2, &
!$OMP                  wmin,wmax,wxr,wyr,wzr,wfx1,wfx2,wfy1,wfy2, &
!$OMP                  wfz1,wfz2,wdxi1,wdxi2,wdyi1,wdyi2,wdzi1,wdzi2, &
!$OMP                  wx1i,wx2i,wy1i,wy2i,wz1i,wz2i)
!
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            wjxe(ix,iy,iz) = s0o1
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            wjye(ix,iy,iz) = s0o1
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            wjze(ix,iy,iz) = s0o1
          end do
        end do
      end do
!....
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye,wjze)
      do i = lnoes, lnoee
         ixi1 = sxeo(i)
         ixh1 = ixi1 + 1
         iyi1 = syeo(i)
         iyh1 = iyi1 + 1
         izi1 = szeo(i)
         izh1 = izi1 + 1
         ixi2 = sxe(i)
         ixh2 = ixi2 + 1
         iyi2 = sye(i)
         iyh2 = iyi2 + 1
         izi2 = sze(i)
         izh2 = izi2 + 1
!.
         wmin = min(ixi1, ixi2) + 1
         wmax = max(ixi1, ixi2)
         wxr = min( wmin, max( wmax, (sxeo(i)+sxe(i))*s1o2 ) )
         wmin = min(iyi1, iyi2) + 1
         wmax = max(iyi1, iyi2)
         wyr = min( wmin, max( wmax, (syeo(i)+sye(i))*s1o2 ) )
         wmin = min(izi1, izi2) + 1
         wmax = max(izi1, izi2)
         wzr = min( wmin, max( wmax, (szeo(i)+sze(i))*s1o2 ) )
!.
         wfx1 = ( sxeo(i) - wxr ) * spfe(i)
         wfx2 = ( wxr - sxe(i)  ) * spfe(i)
         wfy1 = ( syeo(i) - wyr ) * spfe(i)
         wfy2 = ( wyr - sye(i)  ) * spfe(i)
         wfz1 = ( szeo(i) - wzr ) * spfe(i)
         wfz2 = ( wzr - sze(i)  ) * spfe(i)
!.
         wdxi1 = (sxeo(i)+wxr)*s1o2 - ixi1
         wdxi2 = (sxe(i) +wxr)*s1o2 - ixi2
         wdyi1 = (syeo(i)+wyr)*s1o2 - iyi1
         wdyi2 = (sye(i) +wyr)*s1o2 - iyi2
         wdzi1 = (szeo(i)+wzr)*s1o2 - izi1
         wdzi2 = (sze(i) +wzr)*s1o2 - izi2
!..
         wx1i = s1o1 - wdxi1
         wx2i = wdxi1
         wy1i = s1o1 - wdyi1
         wy2i = wdyi1
         wz1i = s1o1 - wdzi1
         wz2i = wdzi1
!.
         wjxe(ixh1,iyi1  ,izi1  ) = wjxe(ixh1,iyi1  ,izi1  ) + &
                                     wfx1 * wy1i * wz1i
         wjxe(ixh1,iyi1+1,izi1  ) = wjxe(ixh1,iyi1+1,izi1  ) + &
                                     wfx1 * wy2i * wz1i
         wjxe(ixh1,iyi1  ,izi1+1) = wjxe(ixh1,iyi1  ,izi1+1) + &
                                     wfx1 * wy1i * wz2i
         wjxe(ixh1,iyi1+1,izi1+1) = wjxe(ixh1,iyi1+1,izi1+1) + &
                                     wfx1 * wy2i * wz2i
!
         wjye(ixi1  ,iyh1,izi1  ) = wjye(ixi1  ,iyh1,izi1  ) + &
                                     wfy1 * wx1i * wz1i
         wjye(ixi1+1,iyh1,izi1  ) = wjye(ixi1+1,iyh1,izi1  ) + &
                                     wfy1 * wx2i * wz1i
         wjye(ixi1  ,iyh1,izi1+1) = wjye(ixi1  ,iyh1,izi1+1) + &
                                     wfy1 * wx1i * wz2i
         wjye(ixi1+1,iyh1,izi1+1) = wjye(ixi1+1,iyh1,izi1+1) + &
                                     wfy1 * wx2i * wz2i
!
         wjze(ixi1  ,iyi1  ,izh1) = wjze(ixi1  ,iyi1,  izh1) + &
                                     wfz1 * wx1i * wy1i
         wjze(ixi1+1,iyi1  ,izh1) = wjze(ixi1+1,iyi1  ,izh1) + &
                                     wfz1 * wx2i * wy1i
         wjze(ixi1  ,iyi1+1,izh1) = wjze(ixi1  ,iyi1+1,izh1) + &
                                     wfz1 * wx1i * wy2i
         wjze(ixi1+1,iyi1+1,izh1) = wjze(ixi1+1,iyi1+1,izh1) + &
                                     wfz1 * wx2i * wy2i
!..
         wx1i = s1o1 - wdxi2
         wx2i = wdxi2
         wy1i = s1o1 - wdyi2
         wy2i = wdyi2
         wz1i = s1o1 - wdzi2
         wz2i = wdzi2
!.
         wjxe(ixh2,iyi2  ,izi2  ) = wjxe(ixh2,iyi2  ,izi2  ) + &
                                     wfx2 * wy1i * wz1i
         wjxe(ixh2,iyi2+1,izi2  ) = wjxe(ixh2,iyi2+1,izi2  ) + &
                                     wfx2 * wy2i * wz1i
         wjxe(ixh2,iyi2  ,izi2+1) = wjxe(ixh2,iyi2  ,izi2+1) + &
                                     wfx2 * wy1i * wz2i
         wjxe(ixh2,iyi2+1,izi2+1) = wjxe(ixh2,iyi2+1,izi2+1) + &
                                     wfx2 * wy2i * wz2i
!
         wjye(ixi2  ,iyh2,izi2  ) = wjye(ixi2  ,iyh2,izi2  ) + &
                                     wfy2 * wx1i * wz1i
         wjye(ixi2+1,iyh2,izi2  ) = wjye(ixi2+1,iyh2,izi2  ) + &
                                     wfy2 * wx2i * wz1i
         wjye(ixi2  ,iyh2,izi2+1) = wjye(ixi2  ,iyh2,izi2+1) + &
                                     wfy2 * wx1i * wz2i
         wjye(ixi2+1,iyh2,izi2+1) = wjye(ixi2+1,iyh2,izi2+1) + &
                                     wfy2 * wx2i * wz2i
!
         wjze(ixi2  ,iyi2  ,izh2) = wjze(ixi2  ,iyi2,  izh2) + &
                                     wfz2 * wx1i * wy1i
         wjze(ixi2+1,iyi2  ,izh2) = wjze(ixi2+1,iyi2  ,izh2) + &
                                     wfz2 * wx2i * wy1i
         wjze(ixi2  ,iyi2+1,izh2) = wjze(ixi2  ,iyi2+1,izh2) + &
                                     wfz2 * wx1i * wy2i
         wjze(ixi2+1,iyi2+1,izh2) = wjze(ixi2+1,iyi2+1,izh2) + &
                                     wfz2 * wx2i * wy2i
!..
      end do
!...
#include "periodic_boundary_je.h"
!...
#include "assign_je.h"
!...
!$OMP END PARALLEL
!....
      end if
!....
      return
      end
#endif
#endif
!-----------------------------------------------------------------------
! Compute 3D Field current(J) Electron with Current Conservation
! by 3rd order ZigZag scheme and 2nd order interpolation
!
      subroutine c3fjecc_zigzag32
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/20
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: i, ix, iy, iz, &
                 ixi1, ixh1, iyi1, iyh1, izi1, izh1, &
                 ixi2, ixh2, iyi2, iyh2, izi2, izh2
      real*8  :: wmin, wmax, wxr, wyr, wzr, wfx1, wfx2, wfy1, wfy2, &
                 wfz1, wfz2, wdd, wx1i, wx2i, wx3i, wx4i, &
                 wy1i, wy2i, wy3i, wy4i, wz1i, wz2i, wz3i, wz4i
#ifdef VECTOR
      real*8, allocatable :: vwjx(:,:,:,:), vwjy(:,:,:,:), vwjz(:,:,:,:)
      integer :: iv, iv2
#endif
#ifdef OHHELP
      integer :: ips
#endif
!....
! Following array must be allocatable array due to the
! limitaion of gfortran OpenMP execution.
! If static with large size, segmantation fault occurs.
!....
      real*8, allocatable :: wjxe(:,:,:), wjye(:,:,:), wjze(:,:,:)
      save
!....
! Avoid OpenMP reduction fault with ifort when lnoe = 0
!....
#ifndef OHHELP
      if( lnoe .gt. 0 ) then
#else
      if( oh_glnoe .gt. 0 ) then
#endif
!....
      if( .not. allocated(wjxe) ) then
#ifndef OHHELP
        allocate( &
          wjxe(lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2), &
          wjye(lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2), &
          wjze(lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3) )
#else
        allocate( &
          wjxe(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), &
          wjye(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), & 
          wjze(oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)) )
#endif
      end if
#ifdef VECTOR
#ifndef OHHELP
      allocate( &
          vwjx(lvlen,lssxlm2:lssxup3,lssylm2:lssyup2,lsszlm2:lsszup2), &
          vwjy(lvlen,lssxlm2:lssxup2,lssylm2:lssyup3,lsszlm2:lsszup2), &
          vwjz(lvlen,lssxlm2:lssxup2,lssylm2:lssyup2,lsszlm2:lsszup3) )
#else
      allocate( &
          vwjx(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                     oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                     oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), &
          vwjy(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                     oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                     oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)), & 
          vwjz(lvlen,oh_alosizes(1,1,FJT):oh_alosizes(2,1,FJT),  &
                     oh_alosizes(1,2,FJT):oh_alosizes(2,2,FJT),  &
                     oh_alosizes(1,3,FJT):oh_alosizes(2,3,FJT)) )
#endif
#endif
!..
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
      oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL PRIVATE(ix,ixi1,ixh1,iyi1,iyh1,izi1,izh1, &
!$OMP                  iy,ixi2,ixh2,iyi2,iyh2,izi2,izh2, &
!$OMP                  wmin,wmax,wxr,wyr,wzr,wfx1,wfx2,wfy1,wfy2, &
!$OMP                  wfz1,wfz2,wdd,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  wy1i,wy2i,wy3i,wy4i,wz1i,wz2i,wz3i,wz4i)
!
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            wjxe(ix,iy,iz) = s0o1
#ifdef VECTOR
            vwjx(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            wjye(ix,iy,iz) = s0o1
#ifdef VECTOR
            vwjy(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            wjze(ix,iy,iz) = s0o1
#ifdef VECTOR
            vwjz(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!....
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:wjxe,wjye,wjze)
      do i = lnoes, lnoee
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vwjx,vwjy,vwjz)
      do iv2 = lnoes, lnoee, lvlen
!NEC$ IVDEP
      do iv = 1, min(lnoee-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
         ixi1 = sxeo(i)
         ixh1 = ixi1 + 1
         iyi1 = syeo(i)
         iyh1 = iyi1 + 1
         izi1 = szeo(i)
         izh1 = izi1 + 1
         ixi2 = sxe(i)
         ixh2 = ixi2 + 1
         iyi2 = sye(i)
         iyh2 = iyi2 + 1
         izi2 = sze(i)
         izh2 = izi2 + 1
!.
         wmin = min(ixi1, ixi2) + 1
         wmax = max(ixi1, ixi2)
         wxr = min( wmin, max( wmax, (sxeo(i)+sxe(i))*s1o2 ) )
         wmin = min(iyi1, iyi2) + 1
         wmax = max(iyi1, iyi2)
         wyr = min( wmin, max( wmax, (syeo(i)+sye(i))*s1o2 ) )
         wmin = min(izi1, izi2) + 1
         wmax = max(izi1, izi2)
         wzr = min( wmin, max( wmax, (szeo(i)+sze(i))*s1o2 ) )
!.
         wfx1 = ( sxeo(i) - wxr ) * spfe(i)
         wfx2 = ( wxr - sxe(i)  ) * spfe(i)
         wfy1 = ( syeo(i) - wyr ) * spfe(i)
         wfy2 = ( wyr - sye(i)  ) * spfe(i)
         wfz1 = ( szeo(i) - wzr ) * spfe(i)
         wfz2 = ( wzr - sze(i)  ) * spfe(i)
#define _ZIGZAG32
#undef _ixd
#undef _iyd
#undef _izd
!..
#undef _sx
#undef _sy
#undef _sz
#define _sx (sxeo(i)+wxr)*s1o2
#define _sy (syeo(i)+wyr)*s1o2
#define _sz (szeo(i)+wzr)*s1o2
!.
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi1
#define _iy iyi1
#define _iz izi1
#include "interpolate2_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixh1
#define _iy iyi1
#define _iz izi1
#ifdef OHHELP
        ixh1 = ixh1 - oh_ixs
        iyi1 = iyi1 - oh_iys
        izi1 = izi1 - oh_izs
#endif
#define _sv _wjxe
#define _ss wfx1
#define _X2
#include "assign2_vs.h"
#undef _X2
#ifdef OHHELP
        ixh1 = ixh1 + oh_ixs
        iyi1 = iyi1 + oh_iys
        izi1 = izi1 + oh_izs
#endif
!.
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#undef _ix
#undef _iy
#define _ix ixi1
#define _iy iyi1
#include "interpolate_xi.h"
#include "interpolate2_yi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi1
#define _iy iyh1
#define _iz izi1
#ifdef OHHELP
        ixi1 = ixi1 - oh_ixs
        iyh1 = iyh1 - oh_iys
        izi1 = izi1 - oh_izs
#endif
#undef _sv
#undef _ss
#define _sv _wjye
#define _ss wfy1
#define _Y2
#include "assign2_vs.h"
#undef _Y2
#ifdef OHHELP
        ixi1 = ixi1 + oh_ixs
        iyh1 = iyh1 + oh_iys
        izi1 = izi1 + oh_izs
#endif
!.
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _iy
#undef _iz
#define _iy iyi1
#define _iz izi1
#include "interpolate_yi.h"
#include "interpolate2_zi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi1
#define _iy iyi1
#define _iz izh1
#ifdef OHHELP
        ixi1 = ixi1 - oh_ixs
        iyi1 = iyi1 - oh_iys
        izh1 = izh1 - oh_izs
#endif
#undef _sv
#undef _ss
#define _sv _wjze
#define _ss wfz1
#define _Z2
#include "assign2_vs.h"
#undef _Z2
!..
#undef _sx
#undef _sy
#undef _sz
#define _sx (sxe(i)+wxr)*s1o2
#define _sy (sye(i)+wyr)*s1o2
#define _sz (sze(i)+wzr)*s1o2
!.
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi2
#define _iy iyi2
#define _iz izi2
#include "interpolate2_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixh2
#define _iy iyi2
#define _iz izi2
#ifdef OHHELP
        ixh2 = ixh2 - oh_ixs
        iyi2 = iyi2 - oh_iys
        izi2 = izi2 - oh_izs
#endif
#undef _sv
#undef _ss
#define _sv _wjxe
#define _ss wfx2
#define _X2
#include "assign2_vs.h"
#undef _X2
#ifdef OHHELP
        ixh2 = ixh2 + oh_ixs
        iyi2 = iyi2 + oh_iys
        izi2 = izi2 + oh_izs
#endif
!.
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#undef _ix
#undef _iy
#define _ix ixi2
#define _iy iyi2
#include "interpolate_xi.h"
#include "interpolate2_yi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi2
#define _iy iyh2
#define _iz izi2
#ifdef OHHELP
        ixi2 = ixi2 - oh_ixs
        iyh2 = iyh2 - oh_iys
        izi2 = izi2 - oh_izs
#endif
#undef _sv
#undef _ss
#define _sv _wjye
#define _ss wfy2
#define _Y2
#include "assign2_vs.h"
#undef _Y2
#ifdef OHHELP
        ixi2 = ixi2 + oh_ixs
        iyh2 = iyh2 + oh_iys
        izi2 = izi2 + oh_izs
#endif
!.
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _iy
#undef _iz
#define _iy iyi2
#define _iz izi2
#include "interpolate_yi.h"
#include "interpolate2_zi.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#undef _ix
#undef _iy
#undef _iz
#define _ix ixi2
#define _iy iyi2
#define _iz izh2
#ifdef OHHELP
        ixi2 = ixi2 - oh_ixs
        iyi2 = iyi2 - oh_iys
        izh2 = izh2 - oh_izs
#endif
#undef _sv
#undef _ss
#define _sv _wjze
#define _ss wfz2
#define _Z2
#include "assign2_vs.h"
#undef _Z2
#ifdef VECTOR
      end do
#endif
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            do iv = 1, lvlen
              wjxe(ix,iy,iz) = wjxe(ix,iy,iz) + vwjx(iv,ix,iy,iz)
            end do
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            do iv = 1, lvlen
              wjye(ix,iy,iz) = wjye(ix,iy,iz) + vwjy(iv,ix,iy,iz)
            end do
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            do iv = 1, lvlen
              wjze(ix,iy,iz) = wjze(ix,iy,iz) + vwjz(iv,ix,iy,iz)
            end do
          end do
        end do
      end do
#endif
!...
#include "periodic_boundary_je.h"
!...
#include "assign_je.h"
!...
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
#ifdef VECTOR
      deallocate( vwjx, vwjy, vwjz )
#endif
      end if
!....
      return
      end
