!----------------------------------------------------------------------
! Compute 3D Field LaSeR
!
      subroutine c3flsr
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/17
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use laserprf
      include "implicit.h"
      integer :: i, ipolm, iy, iz, id, ip1, ip2, ip3, iyy, izz
      real*8  ::  wamp, wlt, wlth
      real*8, allocatable  ::  wlsr(:,:,:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c3flsr', 0 )
!....
      if( .not. allocated(wlsr) ) allocate( wlsr(6,0:lssyp1,0:lsszp1) )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
      oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
      oh_ixe = oh_sdoms(2,1,oh_sdid(ips)+1) - 1
      oh_iye = oh_sdoms(2,2,oh_sdid(ips)+1) - 1
      oh_ize = oh_sdoms(2,3,oh_sdid(ips)+1) - 1
#endif
      if( llsrty .lt. 0 ) then
         ip1 = llinx
         iyy = lliny
         izz = llinz
#ifdef OHHELP
         if( ip1 .le. oh_ixs .or. ip1 .gt. oh_ixe ) cycle 
         if( iyy .le. oh_iys .or. iyy .gt. oh_iye ) cycle 
         if( izz .le. oh_izs .or. izz .gt. oh_ize ) cycle 
         ip1 = ip1 - oh_ixs + 1
         iyy = iyy - oh_iys + 1
         izz = izz - oh_izs + 1
#endif
         if( llsrty .eq. -1 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy,izz) = sbz(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlth )
         else if( llsrty .eq. -2 ) then
            wlt = lltcur
            if( wlt*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 )
            else
               wamp = s0o1
            end if
            sez(ip1,iyy,izz) = sez(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         else if( llsrty .eq. -3 ) then
            wlth = lltcur + s1o2
            if( wlth*sdtfs .le. slsrwd ) then
               wamp = sqrt( slpwr / 1.368165d18 ) / scfl
            else
               wamp = s0o1
            end if
            sbz(ip1,iyy,izz) = sbz(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlth )
            wamp = wamp * scfl
            wlt = lltcur
            sez(ip1,iyy,izz) = sez(ip1,iyy,izz) +  &
                                        wamp * sin( slomg*sdelt*wlt )
         end if
      else
         do i = 1, llsrbn
            if( lbemix(i) .ge. 0 ) then
               ip1 = lbemix(i)
               ip2 = lbemix(i)
               ip3 = lbemix(i) - 1
            else
               ip1 = lssx + lbemix(i)
               ip2 = lssx + lbemix(i) + 1
               ip3 = lssx + lbemix(i) + 1
            end if
#ifdef OHHELP
            if( ip1 .le. oh_ixs .or. ip1 .gt. oh_ixe ) cycle 
            if( ip3 .le. oh_ixs .or. ip3 .gt. oh_ixe ) then 
               write(0,*) &
                 '### ERROR: ip1 & ip3 must be in same subdomain', &
                 i,ip1,ip3
               call s3ext_abort
            end if
            ip1 = ip1 - oh_ixs + 1
            ip2 = ip2 - oh_ixs + 1
            ip3 = ip3 - oh_ixs + 1
#endif
!..
            call c3flcom ( i, wlsr, 6, lssyp1+1, lsszp1+1 )
!..
            ipolm = lbemty(i) / 100
!.                                                   * TM, CP *
            if( ipolm .ne. 2 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,iyy,izz)
              do iz = lsszlm1, lsszup1
                 izz = iz
#ifdef OHHELP
                 izz = izz + oh_izs
#endif
                 do iy = lssyl, lssyup1
                    iyy = iy
#ifdef OHHELP
                    iyy = iyy + oh_iys
#endif
                    sey(ip1,iy,iz) = sey(ip1,iy,iz) + wlsr(1,iyy,izz)
                    sbz(ip2,iy,iz) = sbz(ip2,iy,iz) + wlsr(2,iyy,izz)
                    sey(ip3,iy,iz) = sey(ip3,iy,iz) + wlsr(3,iyy,izz)
                 end do
              end do
            end if
!.                                                   * TE, CP *
            if( ipolm .ne. 1 ) then
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,iyy,izz)
              do iz = lsszl, lsszup1
                 izz = iz
#ifdef OHHELP
                 izz = izz + oh_izs
#endif
                 do iy = lssylm1, lssyup1
                    iyy = iy
#ifdef OHHELP
                    iyy = iyy + oh_iys
#endif
                    sez(ip1,iy,iz) = sez(ip1,iy,iz) + wlsr(4,iyy,izz)
                    sby(ip2,iy,iz) = sby(ip2,iy,iz) + wlsr(5,iyy,izz)
                    sez(ip3,iy,iz) = sez(ip3,iy,iz) + wlsr(6,iyy,izz)
                 end do
              end do
            end if
         end do
      end if
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c3flsr', 1 )
!....
      return
      end
