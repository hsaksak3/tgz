!----------------------------------------------------------------------
! Observe 3D Field Temperature Electron (+pressure)
!                          /
      subroutine o3fte ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output & clear
!                  2 = add & outpur & clear
!                  3 = add
!
!   <remarks>
!     This program also output 3D pressure profile.
!
!    coded by Sakagami,H. (NIFS) 20/12/21
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 34, ifn = 15 
      integer :: kflag, i, iofte, ilog, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iwtea
      real*8  :: wgam, weps=1.0d-10
      real*8, allocatable :: wde(:,:,:), wte(:,:,:), wpe(:,:,:)
#ifdef OHHELP
      real*8, allocatable :: oh_wtede(:,:,:,:,:)
      integer :: ips, ixx, iyy, izz
#endif
      save
!....
      call fdebug ( 'o3fte', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         iwtea = iwtea + 1
#ifndef OHHELP
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wte,wde), &
!$OMP          PRIVATE(ix,iy,iz,wgam)
         do i = lnoes, lnoee
            ix = sxe(i) + s1o2
            iy = sye(i) + s1o2
            iz = sze(i) + s1o2
!
            if( ix .lt. loxps .or. ix .gt. loxpe ) cycle 
            if( iy .lt. loyps .or. iy .gt. loype ) cycle 
            if( iz .lt. lozps .or. iz .gt. lozpe ) cycle 
            if( mod(ix-loxps,loxpi) .ne. 0 ) cycle 
            if( mod(iy-loyps,loypi) .ne. 0 ) cycle 
            if( mod(iz-lozps,lozpi) .ne. 0 ) cycle 
!
            ix = ( ix - loxps ) / loxpi + 1
            iy = ( iy - loyps ) / loypi + 1
            iz = ( iz - lozps ) / lozpi + 1
            wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
            wte(ix,iy,iz) = wte(ix,iy,iz) + wgam * spfe(i)
            wde(ix,iy,iz) = wde(ix,iy,iz) + spfe(i)
         end do
#else
         oh_wtede(:,:,:,:,:) = s0o1
!.
         do ips = 1, 2
            if( oh_lnoe(ips) .le. 0 ) cycle 
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
            oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wtede), &
!$OMP          PRIVATE(ix,iy,iz,wgam)
            do i = oh_lnoes(ips), oh_lnoee(ips)
               ix = sxe(i) - oh_ixs
               iy = sye(i) - oh_iys
               iz = sze(i) - oh_izs
               wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
               oh_wtede(1,ix,iy,iz,ips) = oh_wtede(1,ix,iy,iz,ips) + &
                                          wgam * spfe(i)
               oh_wtede(2,ix,iy,iz,ips) = oh_wtede(2,ix,iy,iz,ips) + &
                                          spfe(i)
            end do
         end do
!.
         call oh3_reduce_field &
                       ( oh_wtede(1,1,1,1,1), oh_wtede(1,1,1,1,2), OTE )
!..
         if( loxyzpl .gt. 0 ) then
           do iz = lozps, lozpe, lozpi
             izz = ( iz - lozps ) / lozpi + 1
             do iy = loyps, loype, loypi
               iyy = ( iy - loyps ) / loypi + 1
               do ix = loxps, loxpe, loxpi
                 ixx = ( ix - loxps ) / loxpi + 1
                 wte(ixx,iyy,izz) = wte(ixx,iyy,izz) + &
                                    oh_wtede(1,ix,iy,iz,1)
                 wde(ixx,iyy,izz) = wde(ixx,iyy,izz) + &
                                    oh_wtede(2,ix,iy,iz,1)
               end do
             end do
           end do
         end if
#endif      
      end if
!....
      if( kflag .le. 2 ) then
        if( kflag .ge. 1 )then
         if( loxyzpl .gt. 0 ) then
           do iz = 1, lozpl
             do iy = 1, loypl
               do ix = 1, loxpl
                 if ( wde(ix,iy,iz) .gt. weps ) then
                   wte(ix,iy,iz) = &
                     (wte(ix,iy,iz)/wde(ix,iy,iz)-s1o1) * s2o3 * scoft
                 else
                   wte(ix,iy,iz) = s0o1
                 end if
                 wpe(ix,iy,iz) = wde(ix,iy,iz) / ( iwtea * snepm1 ) * &
                                 wte(ix,iy,iz) * scofp
               end do
             end do
           end do
           if( iofte .le. 4 ) then
             write(iun) sstcur, wte(:,:,:), wpe(:,:,:)
             flush(iun)
           end if
           if( iofte .ge. 2 ) then
              call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, ilog, i3d, 0, 1, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wte, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fte[MeV]' )
!..
              call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, ilog, i3d, 0, 1, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wpe, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fpe[Gbar]' )
           end if
         end if
        else
!....
           iofte = mod( lofte, 10 )
           ilog  = mod( lofte/10, 10 )
           i3d   = mod( lofte/100, 10 )
           icrxy = mod( lofte/1000, 10 )
           icryz = mod( lofte/10000, 10 )
           icrxz = mod( lofte/100000, 10 )
!.
           if( iofte .ge. 2 ) then
             if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
               write(0,*) '### ERROR: no plot for fte', & 
                           i3d, icrxy, icryz, icrxz
               call s3ext_abort
             end if
           end if
!...
           if( loxyzpl .gt. 0 ) then
             if( .not. allocated(wte) ) &
               allocate( wde(loxpl,loypl,lozpl),wte(loxpl,loypl,lozpl),&
                         wpe(loxpl,loypl,lozpl) )
           end if
#ifdef OHHELP
            if( .not. allocated(oh_wtede) ) allocate( &
              oh_wtede(2,oh_alosizes(1,1,OTE):oh_alosizes(2,1,OTE), &
                         oh_alosizes(1,2,OTE):oh_alosizes(2,2,OTE), &
                         oh_alosizes(1,3,OTE):oh_alosizes(2,3,OTE), 2) )
#endif
!...
           if( iofte .le. 4 ) then
             call fntpcnv ( bbifntp, lrank,iun, bident,'fte', bfile )
             open(iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
             write(iun) 'fte4', bident, loxyzpl, loxpl, loypl, lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
             write(iun) 'fte5', bident, loxyzpl, loxpl, loypl, lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                          lrank, ldivx, ldivy, ldivz, &
                                        oh_loxal, oh_loxas, oh_loxae, &
                                        oh_loyal, oh_loyas, oh_loyae, &
                                        oh_lozal, oh_lozas, oh_lozae
#endif
             flush(iun)
           end if
           if(iofte .ge. 2 ) then
             call fntpcnv ( bfrfntp, lrank,ifn, bident,'fte', bfile )
             call frames_file ( bfile, ifn, iofte )
           end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwtea = 0
            wde(:,:,:) = s0o1
            wte(:,:,:) = s0o1
         end if
      end if
!....
      call fdebug ( 'o3fte', 1 )
!....
      return
      end
