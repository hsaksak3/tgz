!----------------------------------------------------------------------
      subroutine o3ionlabel( ki, ra, rz, elabel )
!
      implicit none
      integer :: ki, idig, ia, inext
      real*8 :: ra, rz
      character :: cform*8, elabel*(*)
!....
      elabel = '(#x,A=x,Z=x)'
      write( elabel(3:3), '(i1)' ) ki
!.
      idig = log10( ra ) + 1
      ia   = ra
      if( ra - ia .le. 1.0d-2 ) then
         cform = '(ix)'
         write( cform(3:3), '(i1)' ) idig
         write( elabel(7:6+idig), cform ) ia
         elabel(7+idig:9+idig) = ',Z='
         inext = 10+idig
      else
         cform = '(fx.1)'
         write( cform(3:3), '(i1)' ) idig+2
         write( elabel(7:8+idig), cform ) ra
         elabel(9+idig:11+idig) = ',Z='
         inext = 12+idig
      end if
!.
      idig = log10( rz ) + 1
      ia   = rz
      if( rz - ia .le. 1.0d-2 ) then
         cform = '(ix)'
         write( cform(3:3), '(i1)' ) idig
         write( elabel(inext:inext+idig-1), cform ) ia
         elabel(inext+idig:inext+idig) = ')'
      else
         cform = '(fx.1)'
         write( cform(3:3), '(i1)' ) idig+2
         write( elabel(inext:inext+idig+1), cform ) rz
         elabel(inext+idig+2:inext+idig+2) = ')'
      end if
!....
      return
      end
