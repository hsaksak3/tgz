c--------------------------------------------------------------------
c   qssorti
c
c        1. purpose   sorting
c
c--------------------------------------------------------------------
      subroutine qssorti(ran,iz,n1)
c....
      include "real8.h"
      parameter( isl = 200 )
c....
      dimension ran(n1),iz(n1)
      dimension is(isl)
      save
c....
      l=1
      m=n1
      n=0
    1 i=l
      j=m
      k=(i+j+1)/2
      c=ran(k)
    2 if(j.lt.l)                    goto 3
      if(ran(j).lt.c)               goto 3
      j=j-1
                                    goto 2
    3 if(ran(i).ge.c.or.i.gt.m)     goto 4
      i=i+1
                                    goto 3
    4 if(i.ge.j)                    goto 5
      t=ran(i)
      ran(i)=ran(j)
      ran(j)=t
      it=iz(i)
      iz(i)=iz(j)
      iz(j)=it
      i=i+1
      j=j-1
      if(i.le.j)                    goto 2
    5 if(i-l-1)                     6,7,9
    6 t=ran(i)
      ran(i)=c
      ran(k)=t
      it=iz(i)
      iz(i)=iz(k)
      iz(k)=it
    7 l=l+1
    8 if(l.ne.m)                     goto 1
      if(n.eq.0)                     return
      l=l+1
      m=is(n)
      n=n-1
                                     goto 8
    9 n=n+1
      if( n .gt. isl ) then
         write(*,*) '### ERROR: qssorti overflow stack ', isl
         stop
      end if
      is(n)=m
      m=i-1
                                     goto 1
c....
      end
