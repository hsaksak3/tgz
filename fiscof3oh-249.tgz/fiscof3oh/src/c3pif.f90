!-----------------------------------------------------------------------
! Compute 3D Particle Ion Force
!
      subroutine c3pif
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/12
!----------------------------------------------------------------------
#include "interpolate.macro"
#include "spdat.macro"
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ixi, ixh, iyi, iyh, izi, izh
      real*8  :: wx1i,wx2i,wx3i,wx4i,wx1h,wx2h,wx3h,wx4h, &
                 wy1i,wy2i,wy3i,wy4i,wy1h,wy2h,wy3h,wy4h, &
                 wz1i,wz2i,wz3i,wz4i,wz1h,wz2h,wz3h,wz4h, &
                 wdd,wex,wbx,wez,wbz,wey,wby, &
                 wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c3pif', 0 )
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
#else
      if( oh_glnoi .gt. 0 ) then
#endif
!...
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
      oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
      oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
      oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
#endif
!$OMP PARALLEL PRIVATE(ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                  ixh,wx1h,wx2h,wx3h,wx4h, &
!$OMP                  iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                  iyh,wy1h,wy2h,wy3h,wy4h, &
!$OMP                  izi,wz1i,wz2i,wz3i,wz4i, &
!$OMP                  izh,wz1h,wz2h,wz3h,wz4h, &
!$OMP                  io,wdd,wex,wbx,wez,wbz,wey,wby, &
!$OMP                  wax,way,waz,wtf,wcx,wcy,wcz,wc2,wac)
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC)
      do i = lionids(io), lionide(io)
#define _sx sxi(i)
#define _sy syi(i)
#define _sz szi(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_xi.h"
#include "interpolate_defxh.h"
#include "interpolate_xh.h"
#include "interpolate_defyi.h"
#include "interpolate_yi.h"
#include "interpolate_defyh.h"
#include "interpolate_yh.h"
#include "interpolate_defzi.h"
#include "interpolate_zi.h"
#include "interpolate_defzh.h"
#include "interpolate_zh.h"
#ifdef OHHELP
         ixi = ixi - oh_ixs
         ixh = ixh - oh_ixs
         iyi = iyi - oh_iys
         iyh = iyh - oh_iys
         izi = izi - oh_izs
         izh = izh - oh_izs
#endif
!..
#include "interpolate_defxh.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _wv wex
#define _sv sex
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyh.h"
#include "interpolate_defzi.h"
#define _wv wey 
#define _sv sey 
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzh.h"
#define _wv wez 
#define _sv sez 
#include "interpolate_v.h"
!
#include "interpolate_defxi.h"
#include "interpolate_defyh.h"
#include "interpolate_defzh.h"
#define _wv wbx 
#define _sv sbx 
#include "interpolate_v.h"
         wbx = wbx + sextbx
!
#include "interpolate_defxh.h"
#include "interpolate_defyi.h"
#include "interpolate_defzh.h"
#define _wv wby
#define _sv sby
#include "interpolate_v.h"
         wby = wby + sextby
!
#include "interpolate_defxh.h"
#include "interpolate_defyh.h"
#include "interpolate_defzi.h"
#define _wv wbz
#define _sv sbz
#include "interpolate_v.h"
         wbz = wbz + sextbz
!..
         wax = suxi(i) + wex * sionqm(io) * s1o2
         way = suyi(i) + wey * sionqm(io) * s1o2
         waz = suzi(i) + wez * sionqm(io) * s1o2
         wtf = s1o2/sqrt(s1o1+(wax**2+way**2+waz**2)*scg1) * sionqm(io)
         wcx = wbx * wtf
         wcy = wby * wtf
         wcz = wbz * wtf
         wc2 = wcx**2 + wcy**2 + wcz**2
         wac = wax * wcx + way * wcy + waz * wcz
!.
         sfxi(i) = ( ( wax + way * wcz - waz * wcy + wac * wcx ) / &
                  ( s1o1 + wc2 ) - suxi(i) ) * s2o1
         sfyi(i) = ( ( way + waz * wcx - wax * wcz + wac * wcy ) / &
                  ( s1o1 + wc2 ) - suyi(i) ) * s2o1
         sfzi(i) = ( ( waz + wax * wcy - way * wcx + wac * wcz ) / &
                  ( s1o1 + wc2 ) - suzi(i) ) * s2o1
      end do
!...
      end do
!...
!$OMP END PARALLEL
!....
#ifdef OHHELP
      end do
#endif
      end if
!....
      call fdebug ( 'c3pif', 1 )
!....
      return
      end
