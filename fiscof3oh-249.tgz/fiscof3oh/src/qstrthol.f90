!-------------------------------------------------------------------
! QSTaRT for HOLlow
!                            /    /   /   /
      subroutine qstrthol ( khf, rx, ry, rz, kho )
!                                             /
!   <arguments>
!     khf : i  : hole flag (=0:all holes,>0:#hole only)
!     rx  : i  : x  real position
!     ry  : i  : y  real position
!     rz  : i  : z  real position
!     kho :  o : inside result ( >0 : inside # of hole)
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 11/05/16
!----------------------------------------------------------------------
      use profile
      use constant
      include "implicit.h"
      integer :: khf, kho, i, is, ie
      real*8  :: rx, ry, rz, ar, ax, ay, az, at
      save
!....
      kho = 0
      if( khf .eq. 0 ) then
        is = 1
        ie = lpphl
      else
        is = khf
        ie = khf
      end if
!....
      do i = is, ie
        select case( lpphty(i) )
        case( 1 )
          if( spphbo(1,i) .le. rx .and. spphbo(4,i) .ge. rx .and. &
              spphbo(2,i) .le. ry .and. spphbo(5,i) .ge. ry .and. &
              spphbo(3,i) .le. rz .and. spphbo(6,i) .ge. rz ) then
            kho = i
          endif
        case( 2 )
          ar = sqrt( (rx-spphbo(1,i))**2 + (ry-spphbo(2,i))**2 + &
                     (rz-spphbo(3,i))**2 )
          if( ar .ge. spphbo(4,i) .and. ar .le. spphbo(5,i) ) then
            kho = i
          end if
        case( 3 )
          ax = rx - spphbo(1,i)
          ay = ry - spphbo(2,i)
          az = rz - spphbo(3,i)
          at = ax*spphav(1,i) + ay*spphav(2,i) + az*spphav(3,i)
          if( at .ge. spphbo(4,i) .and. at .le. spphbo(5,i) ) then
            ax = spphbo(1,i) + at * spphav(1,i)
            ay = spphbo(2,i) + at * spphav(2,i)
            az = spphbo(3,i) + at * spphav(3,i)
            ar = sqrt( (rx-ax)**2 + (ry-ay)**2 + (rz-az)**2 )
            if( atan2(ar,at) .le. spphbo(6,i) ) then
              kho = i
            end if
          end if
        case( 4 )
          ax = rx - spphbo(1,i)
          ay = ry - spphbo(2,i)
          az = rz - spphbo(3,i)
          at = ax*spphav(1,i) + ay*spphav(2,i) + az*spphav(3,i)
          if( at .ge. spphbo(4,i) .and. at .le. spphbo(5,i) ) then
            ax = spphbo(1,i) + at * spphav(1,i)
            ay = spphbo(2,i) + at * spphav(2,i)
            az = spphbo(3,i) + at * spphav(3,i)
            ar = sqrt( (rx-ax)**2 + (ry-ay)**2 + (rz-az)**2 )
            if( ar .le. spphbo(6,i) ) then
              kho = i
            end if
          end if
        case( 5, 6, 7 )
          if( int(spphav(1,i)) .eq. 1 ) then
            ax = rx - spphbo(4,i)
            ar = - ax / ( spphbo(4,i) - spphbo(1,i) )
          else
            ax = rx - spphbo(1,i)
            ar = ax / ( spphbo(4,i) - spphbo(1,i) )
          end if
          ay = ry - ( spphbo(2,i) + spphbo(5,i) ) * s1o2
          az = rz - ( spphbo(3,i) + spphbo(6,i) ) * s1o2
!
          if( lpphty(i) .eq. 5 .or. lpphty(i) .eq. 7 ) then
            if( abs(ay) .le. &
               ( (spphbo(5,i)-spphbo(2,i))*s1o2 ) * ar .and. & 
                abs(az) .le. &
               ( (spphbo(6,i)-spphbo(3,i))*s1o2 ) * ar ) then
              kho = i
            end if
            if( lpphty(i) .eq. 7 ) then
              if( abs(ax) .lt. spphav(2,i) ) kho = 0
            end if
          else
            if( int(spphav(2,i)) .eq. 2 ) then
              if( abs(az) .le. &
                  ((spphbo(6,i)-spphbo(3,i))*s1o2) * ar ) then
                kho = i
              end if
            else
              if( abs(ay) .le. &
                  ((spphbo(5,i)-spphbo(2,i))*s1o2) * ar ) then
                kho = i
              end if
            end if
          end if
        end select
      end do
!...
      return
      end
