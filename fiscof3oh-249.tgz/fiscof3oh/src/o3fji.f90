!----------------------------------------------------------------------
! Observe 3D Field Current Ion
!                          /
      subroutine o3fji ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/12/03
!----------------------------------------------------------------------
#include "sfield.macro"
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 32, ifn = 13
      integer :: kflag, i, io, iofji, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iwjia
      real*8, allocatable :: wjxa(:,:), wjya(:,:), wjza(:,:)
      character*20 clabel
#ifdef OHHELP
      integer :: ips
      real*8, allocatable :: oh_wfji(:,:,:,:,:,:)
#endif
      save
!....
      call fdebug ( 'o3fji', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         iwjia = iwjia + 1
#ifndef OHHELP
         do io = 1, lionspl
           ixyz = 0
           do iz = lozps, lozpe, lozpi
            do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wjxa(ixyz,io) = wjxa(ixyz,io) + &
                       ( sjxi(ix,iy,iz,io) + sjxi(ix+1,iy,iz,io) )*s1o2
               wjya(ixyz,io) = wjya(ixyz,io) + &
                       ( sjyi(ix,iy,iz,io) + sjyi(ix,iy+1,iz,io) )*s1o2
               wjza(ixyz,io) = wjza(ixyz,io) + &
                       ( sjzi(ix,iy,iz,io) + sjzi(ix,iy,iz+1,io) )*s1o2
             end do
            end do
           end do
         end do
#else
         if( oh_pivflag .ne. 0 ) then
           call c3piv
           oh_pivflag = 0
         end if
         oh_wfji(:,:,:,:,:,:) = s0o1
!.
         do ips = 1, 2
            if( oh_lnoi(ips) .le. 0 ) cycle 
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
            oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
            do io = 1, lionspl
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wfji), &
!$OMP          PRIVATE(ix,iy,iz)
              do i = oh_lionids(io,ips), oh_lionide(io,ips)
                ix = sxe(i) - oh_ixs
                iy = sye(i) - oh_iys
                iz = sze(i) - oh_izs
                oh_wfji(1,io,ix,iy,iz,ips) = &
                         oh_wfji(1,io,ix,iy,iz,ips) + svxi(i) * spfi(i)
                oh_wfji(2,io,ix,iy,iz,ips) = &
                         oh_wfji(2,io,ix,iy,iz,ips) + svyi(i) * spfi(i)
                oh_wfji(3,io,ix,iy,iz,ips) = &
                         oh_wfji(3,io,ix,iy,iz,ips) + svzi(i) * spfi(i)
              end do
            end do
         end do
!.
         call oh3_reduce_field &
                    ( oh_wfji(1,1,1,1,1,1), oh_wfji(1,1,1,1,1,2), OJI )
!..
         if( loxyzpl .gt. 0 ) then
           do io = 1, lionspl
             ixyz = 0
             do iz = lozps, lozpe, lozpi
               do iy = loyps, loype, loypi
                 do ix = loxps, loxpe, loxpi
                   ixyz = ixyz + 1
                   wjxa(ixyz,io) = wjxa(ixyz,io) + &
                                  oh_wfji(1,io,ix,iy,iz,1) * sionaz(io)
                   wjya(ixyz,io) = wjya(ixyz,io) + &
                                  oh_wfji(2,io,ix,iy,iz,1) * sionaz(io)
                   wjza(ixyz,io) = wjza(ixyz,io) + &
                                  oh_wfji(3,io,ix,iy,iz,1) * sionaz(io)
                 end do
               end do
             end do
           end do
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
        if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do io = 1, lionspl
              do i = 1, loxyzpl
                wjxa(i,io) = wjxa(i,io) /  ( iwjia * snepm1 * scfl )
                wjya(i,io) = wjya(i,io) /  ( iwjia * snepm1 * scfl )
                wjza(i,io) = wjza(i,io) /  ( iwjia * snepm1 * scfl )
              end do
            end do
            if( iofji .le. 4 ) then
              write(iun) sstcur, &
           ((wjxa(i,io),wjya(i,io),wjza(i,io),i=1,loxyzpl),io=1,lionspl)
              flush(iun)
            end if
            if( iofji .ge. 2 ) then
              do io = 1, lionspl
                call o3ionlabel ( io, sionam(io), sionaz(io), clabel )
                call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wjxa(1,io), wjya(1,io), wjza(1,io), &
                 loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fjxi'//clabel, 'fjyi'//clabel, 'fjzi'//clabel )
              end do
            end if
          end if
!....
        else
           iofji = mod( lofji, 10 )
           i3d   = mod( lofji/100, 10 )
           icrxy = mod( lofji/1000, 10 )
           icryz = mod( lofji/10000, 10 )
           icrxz = mod( lofji/100000, 10 )
!.
           if( iofji .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fji', & 
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
           end if
!....
           if( loxyzpl .gt. 0 ) then
              if( .not. allocated(wjxa) ) &
                allocate( wjxa(loxyzpl,lionspl), wjya(loxyzpl,lionspl),&
                          wjza(loxyzpl,lionspl) )
           end if
#ifdef OHHELP
            if( .not. allocated(oh_wfji) ) allocate( &
        oh_wfji(3,lionspl,oh_alosizes(1,1,OJI):oh_alosizes(2,1,OJI), &
                          oh_alosizes(1,2,OJI):oh_alosizes(2,2,OJI), &
                          oh_alosizes(1,3,OJI):oh_alosizes(2,3,OJI),2) )
#endif
!....
           if( iofji .le. 4 ) then
              call fntpcnv ( bbifntp, lrank,iun, bident,'fji', bfile )
              open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
              write(iun) 'fji4', bident, loxyzpl, loxpl,loypl,lozpl, &
                     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                      lionspl, (sionam(io),sionaz(io),io=1,lionspl)
#else
              write(iun) 'fji5', bident, loxyzpl, loxpl,loypl,lozpl, &
                     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                      lionspl, (sionam(io),sionaz(io),io=1,lionspl), &
                                         lrank, ldivx, ldivy, ldivz, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae, &
                                       oh_lozal, oh_lozas, oh_lozae
#endif
              flush(iun)
           end if
           if( iofji .ge. 2 ) then
              call fntpcnv ( bfrfntp, lrank,ifn, bident,'fji', bfile )
              call frames_file ( bfile, ifn, iofji )
           end if
        end if
        if( loxyzpl .gt. 0 ) then
          iwjia = 0
          do io = 1, lionspl
            do i = 1, loxyzpl
              wjxa(i,io) = s0o1
              wjya(i,io) = s0o1
              wjza(i,io) = s0o1
            end do
          end do
        end if
      end if
!....
      call fdebug ( 'o3fji', 1 )
!....
      return
      end
