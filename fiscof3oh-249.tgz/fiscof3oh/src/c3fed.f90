!----------------------------------------------------------------------
! Compute 3D Field Electric Differenctial
!
      subroutine c3fed
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/15
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use field
      include "implicit.h"
      integer :: ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c3fed', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix,iy)
   do iz = lsszl, lsszup1
      do iy = lssyl, lssyup1
         do ix = lssxl, lssxup1
!..                                                            
            sdezydyz(ix,iy,iz) = ( sey(ix,iy,iz) - sey(ix,iy,iz-1) + &
                        sez(ix,iy-1,iz) - sez(ix,iy,iz) ) * s1o2
            sdexzdzx(ix,iy,iz) = ( sez(ix,iy,iz) - sez(ix-1,iy,iz) + &
                        sex(ix,iy,iz-1) - sex(ix,iy,iz) ) * s1o2
            sdeyxdxy(ix,iy,iz) = ( sex(ix,iy,iz) - sex(ix,iy-1,iz) + &
                        sey(ix-1,iy,iz) - sey(ix,iy,iz) ) * s1o2

         end do
      end do
   end do
!..                                                       
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy)
   do iz = lsszl, lsszup1
      do iy = lssyl, lssyup1
         sdezydyz(lssxlm1,iy,iz) = &
                  ( sey(lssxlm1,iy,iz) - sey(lssxlm1,iy,iz-1) + &
                    sez(lssxlm1,iy-1,iz) - sez(lssxlm1,iy,iz) ) * s1o2
      end do
   end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
   do iz = lsszl, lsszup1
      do ix = lssxl, lssxup1
         sdexzdzx(ix,lssylm1,iz) = &
                  ( sez(ix,lssylm1,iz) - sez(ix-1,lssylm1,iz) + &
                    sex(ix,lssylm1,iz-1) - sex(ix,lssylm1,iz) ) * s1o2
      end do
   end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(ix)
   do iy = lssyl, lssyup1
      do ix = lssxl, lssxup1
         sdeyxdxy(ix,iy,lsszlm1) = &
                  ( sex(ix,iy,lsszlm1) - sex(ix,iy-1,lsszlm1) + &
                    sey(ix-1,iy,lsszlm1) - sey(ix,iy,lsszlm1) ) * s1o2

      end do
   end do
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c3fed', 1 )
!....
      return
      end
