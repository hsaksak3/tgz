      subroutine frames_init
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_init is here. @@@'
      return
      end
      subroutine frames_term
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_term is here. @@@'
      return
      end
      subroutine frames_file
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_file  is here. @@@'
      return
      end
      subroutine frames_body31
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body31 is here. @@@'
      return
      end
      subroutine frames_body32
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body32 is here. @@@'
      return
      end
      subroutine frames_body33
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body33 is here. @@@'
      return
      end
      subroutine frames_body34
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body34 is here. @@@'
      return
      end
      subroutine frames_body22
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body22 is here. @@@'
      return
      end
      subroutine frames_body24
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body24 is here. @@@'
      return
      end
      subroutine frames_body27
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body27 is here. @@@'
      return
      end
      subroutine frames_body28
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ frames_body28 is here. @@@'
      return
      end
!--------------------------------------------------
      subroutine fr_canvas 
      return
      end
      subroutine fr_gclear
      return
      end
      subroutine fr_project
      return
      end
      subroutine fr_angle3d
      return
      end
      subroutine fr_aspect3d
      return
      end
      subroutine fr_xyzname
      return
      end
      subroutine fr_frame3d
      return
      end
      subroutine fr_isosurface
      return
      end
      subroutine fr_fpchars
      return
      end
