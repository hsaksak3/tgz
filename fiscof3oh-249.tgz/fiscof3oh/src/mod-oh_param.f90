!----------------------------------------------------------------------
! OhHelp PARAMeters
!
module oh_param
#ifdef OHHELP
      use parameter
      type oh_comm
        sequence
        integer :: prime, sec, rank, root, black
      end type oh_comm
!...  parameters for ohhelp library
      integer, parameter :: FDE=1,FDI=2,FE=3,FB=4,FJT=5,OJE=6,OJI=7,OTE=8
      integer, parameter :: oh_num_field=8
      integer*8 :: oh_pcnt=0, oh_blkcyc=240, oh_lsize, oh_cyc
      integer :: oh_rank
      integer :: oh_sdid(2)
      integer :: oh_nn
      integer :: oh_nspec
      integer :: oh_pbase(3)
      integer :: oh_nbor(3,3,3)
      integer :: oh_bcond(2,3)
      integer :: oh_pcoord(3)
      integer :: oh_nbound
      integer, allocatable :: oh_nphgram(:,:,:)
      integer, allocatable :: oh_totalp(:,:)
      integer, allocatable :: oh_sdoms(:,:,:)
      integer, allocatable :: oh_bounds(:,:,:)
      type(oh_comm) :: oh_mycomm
      integer :: oh_ftypes(7,oh_num_field+1)
      integer :: oh_cfields(oh_num_field+1)
      integer :: oh_ctypes(3,2,2,oh_num_field)
      integer :: oh_fsizes(2,3,oh_num_field)
      integer :: oh_alosizes(2,3,oh_num_field)
      integer :: oh_scoord(2,3)
      integer :: oh_currmode
!...  parameters for main loop with ohhelp
      integer :: oh_lssxl(2),oh_lssxlp1(2),oh_lssxlp2(2),oh_lssxlp3(2),&
                 oh_lssxlm1(2),oh_lssxlm2(2)
      integer :: oh_lssxu(2),oh_lssxup1(2),oh_lssxup2(2),oh_lssxup3(2),&
                 oh_lssxum1(2),oh_lssxum2(2)
      integer :: oh_lssyl(2),oh_lssylp1(2),oh_lssylp2(2),oh_lssylp3(2),&
                 oh_lssylm1(2),oh_lssylm2(2)
      integer :: oh_lssyu(2),oh_lssyup1(2),oh_lssyup2(2),oh_lssyup3(2),&
                 oh_lssyum1(2),oh_lssyum2(2)
      integer :: oh_lsszl(2),oh_lsszlp1(2),oh_lsszlp2(2),oh_lsszlp3(2),&
                 oh_lsszlm1(2),oh_lsszlm2(2)
      integer :: oh_lsszu(2),oh_lsszup1(2),oh_lsszup2(2),oh_lsszup3(2),&
                 oh_lsszum1(2),oh_lsszum2(2)
      
      integer :: oh_lblxu(2), oh_lblxup1(2), oh_lblxl(2), oh_lblxlm1(2)
      integer :: oh_lblyu(2), oh_lblyup1(2), oh_lblyl(2), oh_lblylm1(2)
      integer :: oh_lblzu(2), oh_lblzup1(2), oh_lblzl(2), oh_lblzlm1(2)

      integer :: oh_lexlf(2),oh_lexuf(2),oh_leylf(2),oh_leyuf(2),oh_lezlf(2),oh_lezuf(2)
      integer :: oh_lexlpe(2),oh_lexupe(2),oh_leylpe(2),oh_leyupe(2),oh_lezlpe(2),oh_lezupe(2)
      integer :: oh_lexlpi(2),oh_lexupi(2),oh_leylpi(2),oh_leyupi(2),oh_lezlpi(2),oh_lezupi(2)

      integer :: oh_lnoe(2), oh_lnoes(2), oh_lnoee(2)
      integer :: oh_lnoi(2), oh_lnois(2), oh_lnoie(2)
      integer :: oh_lionids(lionspx,2), oh_lionide(lionspx,2), &
                 oh_lionidl(lionspx,2)
      integer :: oh_glnoe, oh_glnoi, oh_ixs, oh_iys, oh_izs, oh_ixe, oh_iye, oh_ize
!... parameters for observe
      integer :: oh_loxps, oh_loxpe, oh_loxpi, oh_loxpl, oh_loxyzpl
      integer :: oh_loyps, oh_loype, oh_loypi, oh_loypl
      integer :: oh_lozps, oh_lozpe, oh_lozpi, oh_lozpl
      real*8  :: oh_soxp0m, oh_soyp0m, oh_sozp0m
      integer :: oh_loxas, oh_loxae, oh_loxal
      integer :: oh_loyas, oh_loyae, oh_loyal
      integer :: oh_lozas, oh_lozae, oh_lozal
      integer :: oh_pevflag, oh_pivflag
!... parameters for pml
      integer :: oh_lebpmlxl, oh_lebpmlxu, &
                 oh_lebpmlyl, oh_lebpmlyu, &
                 oh_lebpmlzl, oh_lebpmlzu
#endif
end module
