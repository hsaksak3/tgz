!----------------------------------------------------------------------
! Compute 3D Field Laser COMponents
!                           /          /   /
      subroutine c3flcom ( kbn, fcom, kx, ky ,kz )
!                                /
!   <arguments>
!     kbn  : beam # ( 1 <= kbn <= llsrbn )
!     fcom : laser componetns
!     kx   : x size of fcom
!     ky   : y size of fcom
!     kz   : z size of fcom
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/08/17
!----------------------------------------------------------------------
      use constant
      use profile
      use constant
      use laserprf
      include "implicit.h"
      integer :: kbn, kx, ky, kz, init=0, ipolm, itrns, i, iy, iz
      real*8  :: fcom(kx,ky,kz), wx1, wx2, wx3, wy, wz, wpht, wphmxx, &
                 wphmx, wtdlx, wamp, wat, wt, wlt, wsign
      real*8, allocatable :: wph(:), wphcp(:), wphdl(:,:,:,:), &
                             wleatm(:), wlbatm(:), wleate(:), wlbate(:)
#ifdef VECTOR
      real*8, allocatable :: vwt(:,:,:), vwamp(:,:,:), &
                             vwy(:), vwz(:), vwat(:,:,:)
#endif
      save
!....
      call fdebug ( 'c3flcom', 0 )
!....
      if( init .eq. 0 ) then
         allocate( wph(llsrbn),wphcp(llsrbn),wphdl(3,ky,kz,llsrbn), &
                   wleatm(llsrbn), wlbatm(llsrbn), &
                   wleate(llsrbn), wlbate(llsrbn) )
#ifdef VECTOR
         allocate( vwt(ky,kz,3), vwamp(ky,kz,3), &
                   vwy(ky), vwz(kz), vwat(ky,kz,3) )
#endif
         wtdlx = sundef
         do i = 1, llsrbn
           ipolm = lbemty(i) / 100
           wleatm(i) = slinea(i) / s4o1
           wlbatm(i) = slinba(i) / s2o1
           wleate(i) = slinea(i) / s4o1
           wlbate(i) = slinba(i) / s2o1
           wph(i) = sbemph(i) * sd2r
           if( ipolm .eq. 3 ) then
              wphcp(i) = - 90.0d0 * sd2r
           else if( ipolm .eq. 4 ) then
              wphcp(i) =   90.0d0 * sd2r
           else
              wphcp(i) = s0o1
           end if
!..
           if( lbemix(i) .ge. 0 ) then
              wx1 = (lbemix(i)-lxp0)*slmicinv
           else
              wx1 = (lssx+lbemix(i)-lxp0)*slmicinv
           end if
!.
           wy = (1-lyp0)*slmicinv
           wz = (1-lzp0)*slmicinv
           call c3flphs ( wx1, wy, wz, i, wpht )
           wphmx = wpht
           wz = (kz-lzp0)*slmicinv
           call c3flphs ( wx1, wy, wz, i, wpht )
           wphmx = max( wphmx, wpht )
!..
           wy = (ky-lyp0)*slmicinv
           wz = (1-lzp0)*slmicinv
           call c3flphs ( wx1, wy, wz, i, wpht )
           wphmxx = wpht
           wz = (kz-lzp0)*slmicinv
           call c3flphs ( wx1, wy, wz, i, wpht )
           wphmxx = max( wphmxx, wpht )
           wphmx = max( wphmx, wphmxx )
           wtdlx = max( wtdlx, wphmx/(sbemomg(i)*sdelt) )
         end do
         do i = 1, llsrbn
            do iz = 1, kz
               wz = (iz-lzp0)*slmicinv
               do iy = 1, ky
                  wy = (iy-lyp0)*slmicinv
!.
                  if( lbemix(i) .ge. 0 ) then
                     wx1 = (lbemix(i)-lxp0)*slmicinv
                  else
                     wx1 = (lssx+lbemix(i)-lxp0)*slmicinv
                  end if
                  call c3flphs( wx1, wy, wz, i, wpht )
                  wphdl(1,iy,iz,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
!.
                  if( lbemix(i) .ge. 0 ) then
                     wx1 = (lbemix(i)-s1o2-lxp0)*slmicinv
                  else
                     wx1 = (lssx+lbemix(i)+s1o2-lxp0)*slmicinv
                  end if
                  call c3flphs( wx1, wy, wz, i, wpht )
                  wphdl(2,iy,iz,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
!.
                  if( lbemix(i) .ge. 0 ) then
                     wx1 = (lbemix(i)-1-lxp0)*slmicinv
                  else
                     wx1 = (lssx+lbemix(i)+1-lxp0)*slmicinv
                  end if
                  call c3flphs( wx1, wy, wz, i, wpht )
                  wphdl(3,iy,iz,i) = wpht / ( sbemomg(i) * sdelt ) - wtdlx
               end do
            end do
         end do
!..
         init = 1
      end if
!....
      itrns = mod( lbemty(kbn)/10, 10 )
      ipolm = lbemty(kbn) / 100
      if( lbemix(kbn) .ge. 0 ) then
         wsign = s1o1
      else
         wsign = -s1o1
      end if
!...                                                       * TM, CP *
      if( ipolm .ne. 2 ) then
         if( itrns .eq. 1 ) then
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,wt,wlt,wamp)
           do iz = 1, kz
             do iy = 1, ky
               wt  = lltcur + wphdl(1,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(1,iy,iz) = wamp * wleatm(kbn) * sin( wlt+wph(kbn) )
!
               wt  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(2,iy,iz) = wsign * &
                               wamp * wlbatm(kbn) * sin( wlt+wph(kbn) )
!.
               wt  = lltcur + wphdl(3,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(3,iy,iz) = wamp * wleatm(kbn) * sin( wlt+wph(kbn) )
             end do
           end do
#else
!$OMP PARALLEL PRIVATE(iy)
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               vwt(iy,iz,1)  = lltcur + wphdl(1,iy,iz,kbn)
               vwt(iy,iz,2)  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               vwt(iy,iz,3)  = lltcur + wphdl(3,iy,iz,kbn)
             end do
           end do
!
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               call c3flamp ( kbn, vwt(iy,iz,1), vwamp(iy,iz,1) )
               call c3flamp ( kbn, vwt(iy,iz,2), vwamp(iy,iz,2) )
               call c3flamp ( kbn, vwt(iy,iz,3), vwamp(iy,iz,3) )
             end do
           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
           do iz = 1, kz
             do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,1)
               fcom(1,iy,iz) = vwamp(iy,iz,1) * &
                               wleatm(kbn) * sin( wlt+wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,2)
               fcom(2,iy,iz) = wsign * vwamp(iy,iz,2) * &
                               wlbatm(kbn) * sin( wlt+wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,3)
               fcom(3,iy,iz) = vwamp(iy,iz,3) * &
                               wleatm(kbn) * sin( wlt+wph(kbn) )
             end do
           end do
!$OMP END PARALLEL
#endif
         else
!..
! Cutting the field at sbemmn level causes noise fields
! even if slstmn is 0.005, so calculations are extended
! upto the boundary.
! I'm not sure the factor of sqrt( cos(sbemanr(kbn)) ) for oblique
! laser, but it works.
           if( lbemix(kbn) .ge. 0 ) then
             wx1 = (lbemix(kbn)-lxp0)*slmicinv
             wx2 = (lbemix(kbn)-s1o2-lxp0)*slmicinv
             wx3 = (lbemix(kbn)-1-lxp0)*slmicinv
           else
             wx1 = (lssx+lbemix(kbn)-lxp0)*slmicinv
             wx2 = (lssx+lbemix(kbn)+s1o2-lxp0)*slmicinv
             wx3 = (lssx+lbemix(kbn)+1-lxp0)*slmicinv
           end if
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wz,iy,wy,wat,wt,wlt,wamp)
           do iz = 1, kz
             wz = (iz-lzp0)*slmicinv
             do iy = 1, ky
               wy = (iy-lyp0)*slmicinv
!.
               call c3fltra( wx1, wy, wz, kbn, wat )
               wt  = lltcur + wphdl(1,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(1,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * &
                      wamp * wat * wleatm(kbn) * sin( wlt + wph(kbn) )
!.
               call c3fltra( wx2, wy, wz, kbn, wat )
               wt  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(2,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * &
              wsign * wamp * wat * wlbatm(kbn) * sin( wlt + wph(kbn) )
!.
               call c3fltra( wx3, wy, wz, kbn, wat )
               wt  = lltcur + wphdl(3,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(3,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * &
                      wamp * wat * wleatm(kbn) * sin( wlt + wph(kbn) )
             end do
           end do
#else
!$OMP PARALLEL PRIVATE(iy)
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             vwz(iz) = (iz-lzp0)*slmicinv
             do iy = 1, ky
               vwt(iy,iz,1) = lltcur + wphdl(1,iy,iz,kbn)
               vwt(iy,iz,2) = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               vwt(iy,iz,3) = lltcur + wphdl(3,iy,iz,kbn)
             end do
           end do
           do iy = 1, ky
             vwy(iy) = (iy-lyp0)*slmicinv
           end do
!.
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               call c3fltra( wx1, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,1) )
               call c3flamp( kbn, vwt(iy,iz,1), vwamp(iy,iz,1) )
               call c3fltra( wx2, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,2) )
               call c3flamp( kbn, vwt(iy,iz,2), vwamp(iy,iz,2) )
               call c3fltra( wx3, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,3) )
               call c3flamp( kbn, vwt(iy,iz,3), vwamp(iy,iz,3) )
             end do
           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
           do iz = 1, kz
             do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,1)
               fcom(1,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * &
    vwamp(iy,iz,1) * vwat(iy,iz,1) * wleatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,2)
               fcom(2,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * wsign * &
    vwamp(iy,iz,2) * vwat(iy,iz,2) * wlbatm(kbn) * sin( wlt + wph(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,3)
               fcom(3,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * &
    vwamp(iy,iz,3) * vwat(iy,iz,3) * wleatm(kbn) * sin( wlt + wph(kbn) )
             end do
           end do
!$OMP END PARALLEL
#endif
         end if
      endif
!...                                                         * TE, CP *
      if( ipolm .ne. 1 ) then
         if( itrns .eq. 1 ) then
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy,wt,wlt,wamp)
           do iz = 1, kz
             do iy = 1, ky
               wt  = lltcur + wphdl(1,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(4,iy,iz) = wsign * wamp * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
!  
               wt  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(5,iy,iz) = - wamp * &
                           wlbate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
!.
               wt  = lltcur + wphdl(3,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(6,iy,iz) = wsign * wamp * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
             end do
           end do
#else
!$OMP PARALLEL PRIVATE(iy)
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               vwt(iy,iz,1)  = lltcur + wphdl(1,iy,iz,kbn)
               vwt(iy,iz,2)  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               vwt(iy,iz,3)  = lltcur + wphdl(3,iy,iz,kbn)
             end do
           end do
!
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               call c3flamp ( kbn, vwt(iy,iz,1), vwamp(iy,iz,1) )
               call c3flamp ( kbn, vwt(iy,iz,2), vwamp(iy,iz,2) )
               call c3flamp ( kbn, vwt(iy,iz,3), vwamp(iy,iz,3) )
             end do
           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
           do iz = 1, kz
             do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,1)
               fcom(4,iy,iz) = wsign * vwamp(iy,iz,1) * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,2)
               fcom(5,iy,iz) = - vwamp(iy,iz,2) * &
                           wlbate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,3)
               fcom(6,iy,iz) = wsign * vwamp(iy,iz,3) * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
             end do
           end do
!$OMP END PARALLEL
#endif
!..
         else
! Cutting the field at sbemmn level causes noise fields
! even if slstmn is 0.005, so calculations are extended
! upto the boundary.
! I'm not sure the factor of sqrt( cos(sbemanr(kbn)) ) for oblique
! laser, but it works.
           if( lbemix(kbn) .ge. 0 ) then
             wx1 = (lbemix(kbn)-lxp0)*slmicinv
             wx2 = (lbemix(kbn)-s1o2-lxp0)*slmicinv
             wx3 = (lbemix(kbn)-1-lxp0)*slmicinv
           else
             wx1 = (lssx+lbemix(kbn)-lxp0)*slmicinv
             wx2 = (lssx+lbemix(kbn)+s1o2-lxp0)*slmicinv
             wx3 = (lssx+lbemix(kbn)+1-lxp0)*slmicinv
           end if
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wz,iy,wy,wat,wt,wlt,wamp)
           do iz = 1, kz
             wz = (iz-lzp0)*slmicinv
             do iy = 1, ky
               wy = (iy-lyp0)*slmicinv
!.
               call c3fltra( wx1, wy, wz, kbn, wat )
               wt  = lltcur + wphdl(1,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(4,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * wsign * &
                           wamp * wat * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
!.
               call c3fltra( wx2, wy, wz, kbn, wat )
               wt  = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(5,iy,iz) = - sqrt( cos(sbemanr(kbn)) ) * &
                           wamp * wat * &
                           wlbate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
!.
               call c3fltra( wx3, wy, wz, kbn, wat )
               wt  = lltcur + wphdl(3,iy,iz,kbn)
               call c3flamp ( kbn, wt, wamp )
               wlt = sbemomg(kbn) * sdelt * wt
               fcom(6,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * wsign * &
                           wamp * wat * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
             end do
           end do
#else
!$OMP PARALLEL PRIVATE(iy)
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             vwz(iz) = (iz-lzp0)*slmicinv
             do iy = 1, ky
               vwt(iy,iz,1) = lltcur + wphdl(1,iy,iz,kbn)
               vwt(iy,iz,2) = lltcur - s1o2 + wphdl(2,iy,iz,kbn)
               vwt(iy,iz,3) = lltcur + wphdl(3,iy,iz,kbn)
             end do
           end do
           do iy = 1, ky
             vwy(iy) = (iy-lyp0)*slmicinv
           end do
!.
!$OMP DO SCHEDULE(STATIC)
           do iz = 1, kz
             do iy = 1, ky
               call c3fltra( wx1, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,1) )
               call c3flamp( kbn, vwt(iy,iz,1), vwamp(iy,iz,1) )
               call c3fltra( wx2, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,2) )
               call c3flamp( kbn, vwt(iy,iz,2), vwamp(iy,iz,2) )
               call c3fltra( wx3, vwy(iy), vwz(iz), &
                             kbn, vwat(iy,iz,3) )
               call c3flamp( kbn, vwt(iy,iz,3), vwamp(iy,iz,3) )
             end do
           end do
!.
!$OMP DO SCHEDULE(STATIC) PRIVATE(wlt)
           do iz = 1, kz
             do iy = 1, ky
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,1)
               fcom(4,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * wsign * &
                           vwamp(iy,iz,1) * vwat(iy,iz,1) * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,2)
               fcom(5,iy,iz) = - sqrt( cos(sbemanr(kbn)) ) * &
                           vwamp(iy,iz,2) * vwat(iy,iz,2) * &
                           wlbate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
               wlt = sbemomg(kbn) * sdelt * vwt(iy,iz,3)
               fcom(6,iy,iz) = sqrt( cos(sbemanr(kbn)) ) * wsign * &
                           vwamp(iy,iz,3) * vwat(iy,iz,3) * &
                           wleate(kbn) * sin( wlt+wph(kbn)+wphcp(kbn) )
             end do
           end do
!$OMP END PARALLEL
#endif
         end if
      endif
!....
      call fdebug ( 'c3flcom', 1 )
!....
      return
      end
