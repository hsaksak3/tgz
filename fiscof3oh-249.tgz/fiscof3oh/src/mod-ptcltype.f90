module ptcltype
!
!  type ty1_particle must be consistent with struct S_particle 
! in ohhelp/oh_part.h.
!
#ifdef OHHELP
#include "../ohhelp/oh_config.h"
#endif
      type ty1_particle
         sequence
         real*8  :: x, y, z, ux, uy, uz, uu, pf
#ifdef OHHELP
         integer*8 :: pid
#ifdef OH_BIG_SPACE
         integer*8 :: nid
#else
         integer :: nid
#endif
#else
         integer :: nid
#endif
         integer :: clfl
#ifdef OHHELP
         integer :: spec
#ifndef OH_BIG_SPACE
         integer :: padding
#endif
#endif
      end type ty1_particle
      type ty2_particle
         sequence
         real*8  :: xo, yo, zo, vx, vy, vz, fx, fy, fz
      end type ty2_particle
end module ptcltype
