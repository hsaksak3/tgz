!-----------------------------------------------------------------------
! Compute 3D Field Density Ion
!
      subroutine c3fdi
!
!   <arguments>
!     none
!
!   <remarks>
!     care the boundary only for periodic condition.
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#include "interpolate.macro"
#include "vector.macro"
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use control
      use particle
      use field
      include "implicit.h"
      integer :: io, i, ix, iy, iz, ixi, iyi, izi
      real*8  :: wdd,wx1i,wx2i,wx3i,wx4i, &
                 wy1i,wy2i,wy3i,wy4i,wz1i,wz2i,wz3i,wz4i
#ifndef OHHELP
      real*8, allocatable :: wdi(:,:,:)
#else
      real*8, allocatable :: oh_wdi(:,:,:,:,:)
      integer :: ips
#endif
#ifdef VECTOR
      real*8, allocatable :: vsd(:,:,:,:)
      integer :: iv, iv2 
#endif
      save
!....
      call fdebug ('c3fdi', 0 )
!....
#ifndef OHHELP
      if( lnoi .gt. 0 ) then
!....
      if( .not. allocated(wdi) ) &
        allocate( wdi(lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1) )
#ifdef VECTOR
      allocate( &
         vsd(lvlen,lssxlm1:lssxup1,lssylm1:lssyup1,lsszlm1:lsszup1) )
#endif
!....
!$OMP PARALLEL PRIVATE(io,ixi,wx1i,wx2i,wx3i,wx4i, &
!$OMP                     iyi,wy1i,wy2i,wy3i,wy4i, &
!$OMP                     izi,wz1i,wz2i,wz3i,wz4i,wdd)
!...
      do io = 1, lionspl
!...
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            wdi(ix,iy,iz) = s0o1
#ifdef VECTOR
            vsd(:,ix,iy,iz) = s0o1
#endif
          end do
        end do
      end do
!..
#ifndef VECTOR
!$OMP DO SCHEDULE(STATIC), REDUCTION(+:wdi)
      do i = lionids(io), lionide(io)
#else
!$OMP DO SCHEDULE(STATIC) PRIVATE(iv,i) REDUCTION(+:vsd)
      do iv2 = lionids(io), lionide(io), lvlen
!NEC$ IVDEP
      do iv = 1, min(lionide(io)-iv2+1, lvlen)
         i = iv + iv2 - 1
#endif
#define _sx sxi(i)
#define _sy syi(i)
#define _sz szi(i)
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#include "interpolate_xi.h"
#include "interpolate_yi.h"
#include "interpolate_zi.h"
!..
#include "interpolate_defxi.h"
#include "interpolate_defyi.h"
#include "interpolate_defzi.h"
#define _sv _wdi
#define _ss spfi(i)
#include "assign_vs.h"
#ifdef VECTOR
      end do
#endif
      end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            do iv = 1, lvlen
              wdi(ix,iy,iz) = wdi(ix,iy,iz) + vsd(iv,ix,iy,iz)
            end do
          end do
        end do
      end do
#endif
!...
      if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            wdi(lssxlm1,iy,iz) = wdi(lssxlm1,iy,iz) + wdi(lssxum1,iy,iz)
            wdi(lssxl  ,iy,iz) = wdi(lssxl  ,iy,iz) + wdi(lssxu  ,iy,iz)
            wdi(lssxlp1,iy,iz) = wdi(lssxlp1,iy,iz) + wdi(lssxup1,iy,iz)
          end do
        end do
      end if
      if( lexupi .eq. 1 ) then
        if( lexlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              wdi(lssxum1,iy,iz) = wdi(lssxlm1,iy,iz)
              wdi(lssxu  ,iy,iz) = wdi(lssxl  ,iy,iz)
              wdi(lssxup1,iy,iz) = wdi(lssxlp1,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy)
          do iz = lsszlm1, lsszup1
            do iy = lssylm1, lssyup1
              wdi(lssxum1,iy,iz) = wdi(lssxlm1,iy,iz)+wdi(lssxum1,iy,iz)
              wdi(lssxu  ,iy,iz) = wdi(lssxl  ,iy,iz)+wdi(lssxu  ,iy,iz)
              wdi(lssxup1,iy,iz) = wdi(lssxlp1,iy,iz)+wdi(lssxup1,iy,iz)
            end do
          end do
        end if
      end if
!.
      if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            wdi(ix,lssylm1,iz) = wdi(ix,lssylm1,iz) + wdi(ix,lssyum1,iz)
            wdi(ix,lssyl  ,iz) = wdi(ix,lssyl  ,iz) + wdi(ix,lssyu  ,iz)
            wdi(ix,lssylp1,iz) = wdi(ix,lssylp1,iz) + wdi(ix,lssyup1,iz)
          end do
        end do
      end if
      if( leyupi .eq. 1 ) then
        if( leylpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              wdi(ix,lssyum1,iz) = wdi(ix,lssylm1,iz)
              wdi(ix,lssyu  ,iz) = wdi(ix,lssyl  ,iz)
              wdi(ix,lssyup1,iz) = wdi(ix,lssylp1,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iz = lsszlm1, lsszup1
            do ix = lssxlm1, lssxup1
              wdi(ix,lssyum1,iz) = wdi(ix,lssylm1,iz)+wdi(ix,lssyum1,iz)
              wdi(ix,lssyu  ,iz) = wdi(ix,lssyl  ,iz)+wdi(ix,lssyu  ,iz)
              wdi(ix,lssyup1,iz) = wdi(ix,lssylp1,iz)+wdi(ix,lssyup1,iz)
            end do
          end do
        end if
      end if
!.
      if( lezlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            wdi(ix,iy,lsszlm1) = wdi(ix,iy,lsszlm1) + wdi(ix,iy,lsszum1)
            wdi(ix,iy,lsszl  ) = wdi(ix,iy,lsszl  ) + wdi(ix,iy,lsszu  )
            wdi(ix,iy,lsszlp1) = wdi(ix,iy,lsszlp1) + wdi(ix,iy,lsszup1)
          end do
        end do
      end if
      if( lezupi .eq. 1 ) then
        if( lezlpi .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              wdi(ix,iy,lsszum1) = wdi(ix,iy,lsszlm1)
              wdi(ix,iy,lsszu  ) = wdi(ix,iy,lsszl  )
              wdi(ix,iy,lsszup1) = wdi(ix,iy,lsszlp1)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC), PRIVATE(ix)
          do iy = lssylm1, lssyup1
            do ix = lssxlm1, lssxup1
              wdi(ix,iy,lsszum1) = wdi(ix,iy,lsszlm1)+wdi(ix,iy,lsszum1)
              wdi(ix,iy,lsszu  ) = wdi(ix,iy,lsszl  )+wdi(ix,iy,lsszu  )
              wdi(ix,iy,lsszup1) = wdi(ix,iy,lsszlp1)+wdi(ix,iy,lsszup1)
            end do
          end do
        end if
      end if
!..
!$OMP DO SCHEDULE(STATIC), PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sdi(ix,iy,iz,io) = wdi(ix,iy,iz)
          end do
        end do
      end do
!...
      end do
!$OMP END PARALLEL
#else
      if( oh_glnoi .gt. 0 ) then
!....
      if( .not. allocated(oh_wdi) ) &
         allocate( oh_wdi(lionspl,&
                   oh_alosizes(1,1,FDI):oh_alosizes(2,1,FDI), &
                   oh_alosizes(1,2,FDI):oh_alosizes(2,2,FDI), &
                   oh_alosizes(1,3,FDI):oh_alosizes(2,3,FDI),2) )
#ifdef VECTOR
      allocate( &
         vsd(lvlen,oh_alosizes(1,1,FDI):oh_alosizes(2,1,FDI), &
                   oh_alosizes(1,2,FDI):oh_alosizes(2,2,FDI), &
                   oh_alosizes(1,3,FDI):oh_alosizes(2,3,FDI)) )
#endif
!....
      oh_wdi(:,:,:,:,:) = s0o1
!....
      do ips = 1,2
        if(oh_lnoi(ips) .le. 0 ) cycle
        oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
        oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
        oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
        do io = 1, lionspl
#ifndef VECTOR
!$OMP PARALLEL DO SCHEDULE(STATIC) REDUCTION(+:oh_wdi) &
!$OMP          PRIVATE(ixi,iyi,izi)
          do i = oh_lionids(io,ips), oh_lionide(io,ips)
#else
         vsd(:,:,:,:) = s0o1
!$OMP PARALLEL PRIVATE(iv,i,ixi,iyi,izi,iy,ix)
!$OMP DO SCHEDULE(STATIC) REDUCTION(+:vsd)
          do iv2 = oh_lionids(io,ips), oh_lionide(io,ips), lvlen
!NEC$ IVDEP
          do iv = 1, min(oh_lionide(io,ips)-iv2+1, lvlen)
            i = iv + iv2 - 1 
#endif
            ixi = sxi(i) - oh_ixs
            iyi = syi(i) - oh_iys
            izi = szi(i) - oh_izs
#ifndef VECTOR
            oh_wdi(io,ixi,iyi,izi,ips) = &
                                   oh_wdi(io,ixi,iyi,izi,ips) + spfi(i)
#else
            vsd(iv,ixi,iyi,izi) = vsd(iv,ixi,iyi,izi) + spfi(i)
          end do
#endif
          end do
#ifdef VECTOR
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix,iv)
          do iz = oh_alosizes(1,3,FDI), oh_alosizes(2,3,FDI)
            do iy = oh_alosizes(1,2,FDI), oh_alosizes(2,2,FDI)
              do ix = oh_alosizes(1,1,FDI), oh_alosizes(2,1,FDI)
                do iv = 1, lvlen
                  oh_wdi(io,ix,iy,iz,ips) = &
                             oh_wdi(io,ix,iy,iz,ips) + vsd(iv,ix,iy,iz)
                end do
              end do
            end do
          end do
!$OMP END PARALLEL
#endif
        end do
      end do
!.
      call oh3_reduce_field ( oh_wdi(1,1,1,1,1),oh_wdi(1,1,1,1,2),FDI )
!.
      do io = 1, lionspl
        do iz = oh_alosizes(1,3,FDI), oh_alosizes(2,3,FDI)
          do iy = oh_alosizes(1,2,FDI), oh_alosizes(2,2,FDI)
            do ix = oh_alosizes(1,1,FDI), oh_alosizes(2,1,FDI)
              sdi(ix,iy,iz,io) = oh_wdi(io,ix,iy,iz,1)
            end do
          end do
        end do
      end do
!..
#endif
      lcfdi = 1
#ifdef VECTOR
      deallocate( vsd )
#endif
!....
      end if
!....
      call fdebug ( 'c3fdi', 1 )
!....
      return
      end
