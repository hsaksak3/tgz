!----------------------------------------------------------------------
! Set 3D EXTernal system TERMinate
!
      subroutine s3ext_term
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!----------------------------------------------------------------------
#ifdef OHHELP
       include "implicit.h"
       integer :: impierr
#endif
!....
      call fdebug ( 's3ext_term', 0 )
!....
      call frames_term
!..
      call gdfxs_term
!....
#ifdef OHHELP
       call MPI_FINALIZE ( impierr )
       if( impierr .ne. 0 ) &
          write(0,*) '### ERROR: MPI_FINALIZE, impierr =', impierr
#endif
!....
      call fdebug ( 's3ext_term', 1 )
!....
      return
      end
