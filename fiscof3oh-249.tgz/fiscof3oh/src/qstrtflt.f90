!-------------------------------------------------------------------
! QSTaRT FLaT profile
!
      subroutine qstrtflt ( ksch, kxm, fn, fnpm1, knpme, &
                            fpdat1, kcnt, kcntx, kpc )
!
!   <arguments>
!     ksch : i  : particle position scheme
!     kxm  : i  : x mesh number
!     fn    : i  : number density
!     fnpm1 : i  : number of particle per mesh at profile = 1
!     knpme : i  : effective number of particle per mesh
!     fpdat1:  o : structure of particle data type 1
!     kcnt  : io : counter for structure
!     kcntx : i  : size of structure
!     kp    : i  : index of profile
!     kpc   : i  : if kpc = -1 then particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 05/12/07
! modified by Sakagami,H. ( NIFS ) 08/02/05 : bug fix for inpm < 1
!-------------------------------------------------------------------
      use ptcltype
#ifdef OHHELP
      use oh_param
#endif
      include "implicit.h"
      type(ty1_particle) :: fpdat1(kcntx)
      integer :: ksch, kxm, knpme, kcnt, kcntx, kpc, &
                 inpme, inpm, icnt, i
      real*8  :: fn, fnpm1, anpm1, apf, adl, ax
      save
!....
      call fdebug ( 'qstrtflt', 0 )
!....
      anpm1 = fnpm1 / 2.0d0
      inpme = knpme / 2.0d0
      inpm  = anpm1 * fn
      if( inpm .gt. inpme ) inpm = inpme
      if( inpm .lt. 1 ) inpm = 1
!----
      if( kpc .ne. -1 ) then
!+++
      if( kcnt+inpm*2 .gt. kcntx ) then
         write(0,*) '### ERROR: overflow in qstrtflt', kcntx
         call s3ext_abort
      end if
!+++
      end if
!....
      apf = ( anpm1*fn ) / inpm
      if( ksch .eq. 2 ) inpm = inpm * 2
      adl = 1.0d0 / inpm
!..
      icnt = kcnt
      do i = 1, inpm
         ax = (i-0.5d0)*adl + kxm
#ifdef OHHELP
         oh_pcnt = oh_pcnt + 2
         oh_cyc  = ( oh_pcnt - 1 ) / oh_blkcyc
         oh_rank = mod( oh_cyc, oh_lsize )
         if( oh_rank .ne. lrank ) cycle 
#endif
         kcnt = kcnt + 1
!----
         if( kpc .ne. -1 )then      
            fpdat1(kcnt)%x  = ax
            fpdat1(kcnt)%pf = apf
#ifdef OHHELP
            fpdat1(kcnt)%pid = oh_pcnt - 1
#endif
         endif 
!----
!.         
        if( ksch .ne. 2 ) then
          kcnt = kcnt + 1
!----
          if( kpc .ne. -1 ) then
            fpdat1(kcnt)%x  = ax
            fpdat1(kcnt)%pf = apf
#ifdef OHHELP
            fpdat1(kcnt)%pid = oh_pcnt
#endif
          end if
!----
        end if
      end do
     
!....
      call fdebug ( 'qstrtflt', 1 )
!....
      return
      end
