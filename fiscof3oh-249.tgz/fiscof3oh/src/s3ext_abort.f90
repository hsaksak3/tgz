!----------------------------------------------------------------------
! Set 3D EXTernal system ABORT
!
      subroutine s3ext_abort
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 14/05/01
!----------------------------------------------------------------------
#ifdef OHHELP
      use parameter
      include "implicit.h"
      include "mpif.h"
      integer :: impierr
#endif
!....
      flush(6)
!....
#ifdef OHHELP
      write(0,*) '### ABORT: called by lrank =', lrank
      flush(0)
      call MPI_ABORT ( MPI_COMM_WORLD, lrank, impierr )
      if( impierr .ne. 0 ) &
         write(0,*) '### ERROR: MPI_ABORT, impierr =', impierr
      flush(0)
#endif
!....
      stop 99999
!....
      end
