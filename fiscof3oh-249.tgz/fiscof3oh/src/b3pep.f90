!-----------------------------------------------------------------------
! Boundary condition 3D Particle Electron Position
!                          /
      subroutine b3pep ( kmode )
!
!   <arguments>
!     kmode : mode = 1 : for periodic condition
!                  = 2 : for perfect reflection
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/11
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use ieee_arithmetic
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, ii, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!perio weps is needed. Run following program !!
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx
!peri stop
!peri end
!perio weps problem was solved by ieee_set_rounding_mode(ieee_down)
!peri Run following program !!
!peri use :: ieee_arithmetic
!peri call ieee_set_rounding_mode(ieee_down)
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx 
!peri stop
!peri end
!....
      call fdebug( 'b3pep', 0 )
!....
      call ieee_set_rounding_mode(ieee_down)
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ii)
      do i = lnoes, lnoee
        if( lexlpe .eq. kmode ) then
          ii = sxe(i)
          if( ii .lt. 1 ) then
            select case( lexlpe )
            case( 1 )
               sxe(i) = sxe(i) + lssxm1
            case( 2 )
               sxe(i) = s2o1 - sxe(i)
               svxe(i) = - svxe(i)
               suxe(i) = - suxe(i)
            end select
          end if
        end if
!.
        if( lexupe .eq. kmode ) then
          ii = sxe(i)
          if ( ii .gt. lssxm1 ) then
            select case( lexupe )
            case( 1 )
               sxe(i) = sxe(i) - lssxm1
            case( 2 )
               sxe(i) = s2o1 * lssx - sxe(i)
               svxe(i) = - svxe(i)
               suxe(i) = - suxe(i)
            end select
          end if
        end if
!..
        if( leylpe .eq. kmode ) then
          ii = sye(i)
          if( ii .lt. 1 ) then
            select case( leylpe )
            case( 1 )
               sye(i) = sye(i) + lssym1
            case( 2 )
               sye(i) = s2o1 - sye(i)
               svye(i) = - svye(i)
               suye(i) = - suye(i)
            end select
          end if
        end if
!.
        if( leyupe .eq. kmode ) then
          ii = sye(i)
          if ( ii .gt. lssym1 ) then
            select case( leyupe )
            case( 1 )
               sye(i) = sye(i) - lssym1
            case( 2 )
               sye(i) = s2o1 * lssy - sye(i)
               svye(i) = - svye(i)
               suye(i) = - suye(i)
            end select
          end if
        end if
!..
        if( lezlpe .eq. kmode ) then
          ii = sze(i)
          if( ii .lt. 1 ) then
            select case( lezlpe )
            case( 1 )
               sze(i) = sze(i) + lsszm1
            case( 2 )
               sze(i) = s2o1 - sze(i)
               svze(i) = - svze(i)
               suze(i) = - suze(i)
            end select
          end if
        end if
!.
        if( lezupe .eq. kmode ) then
          ii = sze(i)
          if ( ii .gt. lsszm1 ) then
            select case( lezupe )
            case( 1 )
               sze(i) = sze(i) - lsszm1
            case( 2 )
               sze(i) = s2o1 * lssz - sze(i)
               svze(i) = - svze(i)
               suze(i) = - suze(i)
            end select
          end if
        end if
      end do
#ifdef OHHELP
      if( kmode .eq. 1 ) call s3ext_param( 1, ips )
      end do
#endif
!....
      call ieee_set_rounding_mode(default_round_type)
!....
      call fdebug( 'b3pep', 1 )
!....
      return
      end
