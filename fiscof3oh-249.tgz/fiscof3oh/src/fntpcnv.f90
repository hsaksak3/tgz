!----------------------------------------------------------------------
! File Name TemPlate CoNVersion
!                            /      /      /      /      /
      subroutine fntpcnv ( efntp, krank, kunit, eiden, ekey, efile )
!                                                              /
!   <arguments>
!     efntp : file name template
!     krank : MPI rank number
!     kunit : Fortran / Frames unit# or animation#
!     eiden : identification character
!     ekey  : observation key
!     efile : converted file name
!
!   <remarks>
!     special characters in file name template will be replaced as
!    follows.
!
!  &I  : identification character
!      : If eiden is blank, &I is omitted with preceding special
!      : character.
!  &K  : observation key
!      : If ekey is blank, &K is omitted with preceding special
!      : character.
!  ### : MPI rank number with specified number of digits ( here 3 )
!      : If rank is -1, such as nonparallel run, ### is omitted with
!      : preceding special character.
!   %% : Fortran / Frames unit# or animation# with specified number of
!      : digits ( here 2 )
!      : If unit# is -1, such as no unit# case, %% is omitted with
!      : preceding special character.
!
!      : * Special characters are "-", ".", "_" and ":".
!
!    coded by Sakagami,H. (NIFS) 14/04/24
!----------------------------------------------------------------------
      include "implicit.h"
      character(*) :: efntp, eiden, ekey, efile
      character(4) :: csp = '-._:'
      character(6) :: cform = '(ix.x)'
      integer :: krank, kunit, is, ie, il, ic, ib
      save
!....
      efile = efntp
!....
      is = index( efile, '&I' )
      if( is .gt. 0 ) then
         ie = len_trim( efile )
         il = len_trim( eiden )
         if( il .eq. 0 ) then
            if( is .eq. 1 ) then
               ic = 0
            else
               ic = scan( efile(is-1:is-1), csp )
            end if
            efile(is-ic:ie) = efile(is+2:ie)
         else
            if( il .eq. 1 ) then
               efile(is+1:ie) = efile(is+2:ie)
            else if( il .gt. 2 ) then
               efile(is+il:ie+il-2) = efile(is+2:ie)
            end if
            efile(is:is+il-1) = eiden(1:il)
         end if
      end if
!..
      is = index( efile, '&K' )
      if( is .gt. 0 ) then
         ie = len_trim( efile )
         il = len_trim( ekey )
         if( il .eq. 0 ) then
            if( is .eq. 1 ) then
               ic = 0
            else
               ic = scan( efile(is-1:is-1), csp )
            end if
            efile(is-ic:ie) = efile(is+2:ie)
         else
            if( il .eq. 1 ) then
               efile(is+1:ie) = efile(is+2:ie)
            else if( il .gt. 2 ) then
               efile(is+il:ie+il-2) = efile(is+2:ie)
            end if
            efile(is:is+il-1) = ekey(1:il)
         end if
      end if
!..
      is = index( efile, '#' )
      if( is .gt. 0 ) then
         ib = index( efile, '#', .TRUE. )
         ie = len_trim( efile )
         if( krank .lt. 0 ) then
            if( is .eq. 1 ) then
               ic = 0
            else
               ic = scan( efile(is-1:is-1), csp )
            end if
            efile(is-ic:ie) = efile(ib+1:ie)
         else
            ic = ib - is + 1
            il =log10( real(krank) + 0.1 ) + 1.0
            if( il .gt. ic ) then
               efile(ib+il-ic+1:ie+il-ic) = efile(ib+1:ie)
               ic = il
               ib = is + ic - 1
            end if
            write( cform(3:3), '(i1)' ) ic
            cform(5:5) = cform(3:3)
            write( efile(is:ib), cform ) krank
         end if
      end if
!..
      is = index( efile, '%' )
      if( is .gt. 0 ) then
         ib = index( efile, '%', .TRUE. )
         ie = len_trim( efile )
         if( kunit .lt. 0 ) then
            if( is .eq. 1 ) then
               ic = 0
            else
               ic = scan( efile(is-1:is-1), csp )
            end if
            efile(is-ic:ie) = efile(ib+1:ie)
         else
            ic = ib - is + 1
            il =log10( real(kunit) + 0.1 ) + 1.0
            if( il .gt. ic ) then
               efile(ib+il-ic+1:ie+il-ic) = efile(ib+1:ie)
               ic = il
               ib = is + ic - 1
            end if
            write( cform(3:3), '(i1)' ) ic
            cform(5:5) = cform(3:3)
            write( efile(is:ib), cform ) kunit
         end if
      end if
!....
      return
      end
