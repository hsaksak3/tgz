!-------------------------------------------------------------------
! Set 3D Quiet STaRt
!                          /
      subroutine s3qstr ( kpc )
!
!   <arguments>
!     kpc : =-1 -> particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/07/14
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use profile
      use constant
      use particle
      include "implicit.h"
      integer :: kpc
      integer :: i, io, ip, inoe,inoe0, inoi,inoi0, iionids, &
                 iwsh, isty, idir, iflg
      real*8  :: av, wfd, wfp, &
                 wute, wuti, wvte, wvti, wxs, wxe, wys, wye, wzs, wze
#ifndef OHHELP
      real*8  :: apfes(lpppx), acrct, anetc, apfis
#else
      include "mpif.h"
      integer :: ips=1, ierr
#endif
      save
!....
      call fdebug ( 's3qstr', 0 )
!++++
      if( smasr .gt. 1.0d-29 ) then
         do ip = 1, lpppl
            if( lpppis(ip) .lt. 1 .or. lpppis(ip) .gt. lionspl ) then
               write(0,*) '### ERROR: ion was not specified',  &
                           ip, lpppis(ip)
               call s3ext_abort
            end if
         end do
      end if
!..
      do ip = 1, lpppl
        iwsh = mod( lpppty(ip), 10 )
        isty = mod( lpppty(ip)/10, 10 )
        idir = mod( lpppty(ip)/100, 10 )
!.
        select case( iwsh )
        case( 1, 5, 6, 7 )
          if( spppbo(1,ip) .ge. spppbo(4,ip) ) then
            write(0,*) '### ERROR: Xe must be greater than Xs', ip 
            call s3ext_abort
          else if( spppbo(2,ip) .ge. spppbo(5,ip) ) then
            write(0,*) '### ERROR: Ye must be greater than Ys', ip 
            call s3ext_abort
          else if( spppbo(3,ip) .ge. spppbo(6,ip) ) then
            write(0,*) '### ERROR: Ze must be greater than Zs', ip 
            call s3ext_abort
          end if
          select case( iwsh )
          case( 1 )
            if( isty .gt. 4 ) then
              write(0,*) '### ERROR: invalid scale type',ip,lpppty(ip)
              call s3ext_abort
            end if
            if( isty .eq. 4 ) then
              if( sppprs(ip) .ge. spppre(ip) ) then
                write(0,*) '### ERROR: invalid radius',ip
                call s3ext_abort
              end if
            end if
            if( idir .gt. 4 ) then
              write(0,*) '### ERROR: invalid scale direction', &
                         ip,lpppty(ip)
              call s3ext_abort
            end if
          case( 5, 6, 7 )
            if( isty .ne. 1 ) then
              write(0,*) '### ERROR: invalid scale type',ip,lpppty(ip)
              call s3ext_abort
            end if
            iflg = int(spppro(1,ip))
            if( iflg .ne. 1 .and. iflg .ne. 2 ) then
              write(0,*) '### ERROR: invalid base',ip,lpppty(ip),iflg
              call s3ext_abort
            end if
            if( iwsh .eq. 6 ) then
              iflg = int(spppro(2,ip))
              if( iflg .ne. 2 .and. iflg .ne. 3 ) then
                write(0,*) '### ERROR: invalid dir.',ip,lpppty(ip),iflg
                call s3ext_abort
              end if
            else if( iwsh .eq. 7 ) then
              if( spppro(2,ip) .le. 0.0d0 .or. &
                  spppro(2,ip) .ge. spppbo(4,ip)-spppbo(1,ip) ) then
                write(0,*) '### ERROR: invalid len.', &
                           ip,lpppty(ip),spppro(2,ip)
                call s3ext_abort
              end if
            end if
          end select
        case( 3 )
          if( spppbo(4,ip) .ge. spppbo(5,ip) ) then
            write(0,*) '### ERROR: invalid distance',ip
            call s3ext_abort
          end if
          av = spppro(1,ip)**2 + spppro(2,ip)**2 + spppro(3,ip)**2
          if( av .lt. 1.0d-10 ) then
            write(0,*) '### ERROR: invalid axis vector',ip
            call s3ext_abort
          end if
          if( isty .ne. 1 ) then
            write(0,*) '### ERROR: invalid scale type',ip,lpppty(ip)
            call s3ext_abort
          end if
          av = sqrt( av )
          spppro(1,ip) = spppro(1,ip) / av
          spppro(2,ip) = spppro(2,ip) / av
          spppro(3,ip) = spppro(3,ip) / av
          spppbo(6,ip) = spppbo(6,ip) * sd2r
        case default
          write(0,*) '### ERROR: invalid whole shape',ip,lpppty(ip)
          call s3ext_abort
        end select
!
        if( lppphf(ip) .eq. 0 ) then
          if( lpphl .le. 0 ) then
            write(0,*) '### ERROR: no hole data',ip,lppphf(ip),lpphl
            call s3ext_abort
          end if
        else if( lppphf(ip) .gt. 0 ) then
          if( lppphf(ip) .gt. lpphl ) then
            write(0,*) '### ERROR: no specified hole', &
                       ip,lppphf(ip),lpphl
            call s3ext_abort
          end if
        end if
      end do
!..
      do ip = 1, lpphl
        iwsh = mod( lpphty(ip), 10 )
!.
        select case( iwsh )
        case( 1, 5, 6, 7 )
          if( spphbo(1,ip) .ge. spphbo(4,ip) ) then
            write(0,*) '### ERROR: hole Xe must be greater than Xs', ip 
            call s3ext_abort
          else if( spphbo(2,ip) .ge. spphbo(5,ip) ) then
            write(0,*) '### ERROR: hole Ye must be greater than Ys', ip 
            call s3ext_abort
          else if( spphbo(3,ip) .ge. spphbo(6,ip) ) then
            write(0,*) '### ERROR: hole Ze must be greater than Zs', ip 
            call s3ext_abort
          end if
          if( iwsh .ne. 1 ) then
            iflg = int(spphav(1,ip))
            if( iflg .ne. 1 .and. iflg .ne. 2 ) then
              write(0,*) '### ERROR: invalid base',ip,lpphty(ip),iflg
              call s3ext_abort
            end if
            if( iwsh .eq. 6 ) then
              iflg = int(spphav(2,ip))
              if( iflg .ne. 2 .and. iflg .ne. 3 ) then
                write(0,*) '### ERROR: invalid dir.',ip,lpphty(ip),iflg
                call s3ext_abort
              end if
            else if( iwsh .eq. 7 ) then
              if( spphav(2,ip) .le. 0.0d0 .or. &
                  spphav(2,ip) .ge. spphbo(4,ip)-spphbo(1,ip) ) then
                write(0,*) '### ERROR: invalid len.', &
                           ip,lpphty(ip),spphav(2,ip)
                call s3ext_abort
              end if
            end if
          end if
        case( 2 )
          if( spphbo(4,ip) .ge. spphbo(5,ip) ) then
            write(0,*) '### ERROR: hole invalid radius',ip
            call s3ext_abort
          end if
        case( 3 )
          if( spphbo(4,ip) .ge. spphbo(5,ip) ) then
            write(0,*) '### ERROR: hole invalid distance',ip
            call s3ext_abort
          end if
          av = spphav(1,ip)**2 + spphav(2,ip)**2 + spphav(3,ip)**2
          if( av .lt. 1.0d-10 ) then
            write(0,*) '### ERROR: hole invalid axis vector',ip
            call s3ext_abort
          end if
          av = sqrt( av )
          spphav(1,ip) = spphav(1,ip) / av
          spphav(2,ip) = spphav(2,ip) / av
          spphav(3,ip) = spphav(3,ip) / av
          spphbo(6,ip) = spphbo(6,ip) * sd2r
        case( 4 )
          if( spphbo(4,ip) .ge. spphbo(5,ip) ) then
            write(0,*) '### ERROR: hole invalid distance',ip
            call s3ext_abort
          end if
          av = spphav(1,ip)**2 + spphav(2,ip)**2 + spphav(3,ip)**2
          if( av .lt. 1.0d-10 ) then
            write(0,*) '### ERROR: hole invalid axis vector',ip
            call s3ext_abort
          end if
          av = sqrt( av )
          spphav(1,ip) = spphav(1,ip) / av
          spphav(2,ip) = spphav(2,ip) / av
          spphav(3,ip) = spphav(3,ip) / av
        case default
          write(0,*) '### ERROR: hole invalid whole shape',ip,lpphty(ip)
          call s3ext_abort
        end select  
      end do
!++++
!....
      inoe = 0
!....
      do ip = 1, lpppl
!..
         if( lrank .le. 0 ) &
         write(6,*) 's3qstr(e)', ip, lpppty(ip)
         inoe0 = inoe
!..
         call qstrtpos ( ip, lnepme, s1o1,s1o1, spdat1,inoe,lnoex, &
                            kpc )
!----
      if( kpc .ne. -1 ) then
#ifndef OHHELP
         apfes(ip) = s0o1
         do i = inoe0+1, inoe
            apfes(ip) = apfes(ip) + spfe(i)
         end do
#endif
!.
         wvte = svte * sqrt( spppte(ip) )
         wute = wvte / sqrt( s1o1 - ( s3o1 * wvte**2 ) * scg1 )
         call qstrtvel ( wute, spdat1, inoe0, inoe, lnoex )
!.
         do i = inoe0+1, inoe
            suxe(i) = suxe(i) + spppudxe(ip)
            suye(i) = suye(i) + spppudye(ip)
            suze(i) = suze(i) + spppudze(ip)
         end do
      end if
!----
      end do
!..
      lnoe = inoe
      lnoes = 1
      lnoee = lnoes + lnoe - 1
      inoi = inoe
!....
      if( smasr .gt. 1.0d-29 ) then
         do io = 1, lionspl
         iionids = inoi + 1
!...
         do ip = 1, lpppl
         if( lpppis(ip) .eq. io ) then
!...
            if( lrank .le. 0 ) &
            write(6,*) 's3qstr(i)', ip, lpppty(ip)
!...
            inoi0 = inoi
!..
            wfd = s1o1 / ( sionaz(io) * sionaf(io) )
            wfp = sionaf(io)
            call qstrtpos ( ip,lnipme(io),wfd,wfp, spdat1,inoi,lnox,&
                            kpc )
!----
      if( kpc .ne. -1 ) then
!..
#ifndef OHHELP
            apfis = s0o1
            do i = inoi0+1, inoi
               apfis = apfis + spfi(i)
            end do
            anetc = apfis * sionaz(io) - apfes(ip)
            acrct = - anetc / sionaz(io) / dble(inoi-inoi0)
            do i = inoi0+1, inoi
               spfi(i) = spfi(i) + acrct
            end do
#endif
!..
            wvti = svti(io) * sqrt( spppti(ip) )
            wuti = wvti / sqrt( s1o1 - ( s3o1 * wvti**2 ) * scg1 )
            call qstrtvel ( wuti, spdat1, inoi0, inoi, lnox )
!.
            do i = inoi0+1, inoi
               suxi(i) = suxi(i) + spppudxi(ip)
               suyi(i) = suyi(i) + spppudyi(ip)
               suzi(i) = suzi(i) + spppudzi(ip)
            end do
      end if
!----
         end if
!..
         end do
!..
         lionids(io) = iionids
         lionide(io) = inoi
         lionidl(io) = lionide(io)-lionids(io)+1
!++++
#ifndef OHHELP
         if( lionidl(io) .lt. 1 ) then
            write(0,*) '### ERROR: specified ion was not used.', io
            call s3ext_abort
         end if
#endif
!++++
         end do
!..
         lnois = lionids(1)
         lnoie = lionide(lionspl)
         lnoi  = lnoie - lnois + 1
!...
      else
         lnoi  = 0
         lnois = 0
         lnoie = -1
         lionspl = 0
      end if
!....
!----
      if( kpc .ne. -1 ) then
!----
      wxs =  1.0d30
      wys =  1.0d30
      wzs =  1.0d30
      wxe = -1.0d30
      wye = -1.0d30
      wze = -1.0d30
      do i = lnoes, lnoee
         wxs = min( wxs, sxe(i) )
         wxe = max( wxe, sxe(i) )
         wys = min( wys, sye(i) )
         wye = max( wye, sye(i) )
         wzs = min( wzs, sze(i) )
         wze = max( wze, sze(i) )
         suue(i) = sqrt( suxe(i)**2 + suye(i)**2 + suze(i)**2 )
      end do
!.
      do i = lnois, lnoie
         suui(i) = sqrt( suxi(i)**2 + suyi(i)**2 + suzi(i)**2 )
      end do
!..
#ifdef OHHELP
      call MPI_ALLREDUCE( MPI_IN_PLACE, wxe, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MAX, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wye, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MAX, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wze, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MAX, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wxs, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MIN, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wys, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MIN, MPI_COMM_WORLD, ierr )
      call MPI_ALLREDUCE( MPI_IN_PLACE, wzs, 1, MPI_DOUBLE_PRECISION, &
                             MPI_MIN, MPI_COMM_WORLD, ierr )
#endif
      lxps = wxs - 1
      lxpe = wxe + 2
      lyps = wys - 1
      lype = wye + 2
      lzps = wzs - 1
      lzpe = wze + 2
!----
      end if
!----
!....
      call fdebug ( 's3qstr', 1 )
!....
      return
      end
