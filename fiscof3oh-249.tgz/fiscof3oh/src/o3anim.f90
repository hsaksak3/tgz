!----------------------------------------------------------------------
! Observe 3D ANIMation
!
      subroutine o3anim
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/03/04
!----------------------------------------------------------------------
      use animation
      use constant
      use particle
      use observe
      include "implicit.h"
      integer :: it, int
      save
!....
      call gdfxs_bodys
!....
      if( lapepxyl .ge. 1 ) then
         do it = 1, lapepxyl
            int = max( lapepxy(it) / 1000, 1 )
            call gdfxs_body31 ( lapepxygt(it), spdat1, lnoe, int, 1, &
                                'pepxy' )
         end do
      end if
!..
      if( lapepyzl .ge. 1 ) then
         do it = 1, lapepyzl
            int = max( lapepyz(it) / 1000, 1 )
            call gdfxs_body31 ( lapepyzgt(it), spdat1, lnoe, int, 2, &
                                'pepyz' )
         end do
      end if
!..
      if( lapepxzl .ge. 1 ) then
         do it = 1, lapepxzl
            int = max( lapepxz(it) / 1000, 1 )
            call gdfxs_body31 ( lapepxzgt(it), spdat1, lnoe, int, 3, &
                                'pepxz' )
         end do
      end if
!....
      call gdfxs_bodye
!....
      return
      end
