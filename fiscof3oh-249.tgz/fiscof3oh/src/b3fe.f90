!-----------------------------------------------------------------------
! Boundary condition 3D Field Electric 
!
      subroutine b3fe
!
!   <arguments>
!     none
!
!   <remarks>
!     Fields values are just needed for references by particles.
!
!    coded by Sakagami,H. (NIFS) 20/09/11
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
      use oh_param
#endif
      use constant
      use control
      use field
      include "implicit.h"
      integer :: ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'b3fe', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
      select case( lexlf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            sex(lssxlm1,iy,iz) = sex(lssxum1,iy,iz)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlxl
#else
        call b3fe_pmlxl ( ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid lexlf =',lexlf
        call s3ext_abort
      end select
!..
      select case( lexuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(iy)
        do iz = lsszlm1, lsszup1
          do iy = lssylm1, lssyup1
            sex(lssxup2,iy,iz) = sex(lssxlp2,iy,iz)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlxu
#else
        call b3fe_pmlxu ( ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid lexuf =',lexuf
        call s3ext_abort
      end select
!...
      select case( leylf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            sey(ix,lssylm1,iz) = sey(ix,lssyum1,iz)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlyl ( lexlf, lexuf )
#else
        call b3fe_pmlyl ( lexlf, lexuf, ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid leylf =',leylf
      end select
!..
      select case( leyuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
        do iz = lsszlm1, lsszup1
          do ix = lssxlm1, lssxup1
            sey(ix,lssyup2,iz) = sey(ix,lssylp2,iz)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlyu ( lexlf, lexuf )
#else
        call b3fe_pmlyu ( lexlf, lexuf, ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid leyuf =',leyuf
      end select
!...
      select case( lezlf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sez(ix,iy,lsszlm1) = sez(ix,iy,lsszum1)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlzl ( lexlf, lexuf, leylf, leyuf )
#else
        call b3fe_pmlzl ( lexlf, lexuf, leylf, leyuf, ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid lezlf =',lezlf
      end select
!..
      select case( lezuf )
      case( 0 )
      case( 1 )
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ix)
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1
            sez(ix,iy,lsszup2) = sez(ix,iy,lsszlp2)
          end do
        end do
      case( 4 )
#ifndef OHHELP
        call b3fe_pmlzu ( lexlf, lexuf, leylf, leyuf )
#else
        call b3fe_pmlzu ( lexlf, lexuf, leylf, leyuf, ips )
#endif
      case default 
        write(0,*) '### ERROR: invalid lezuf =',lezuf
      end select
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'b3fe', 1 )
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
      subroutine b3fe_pmlxl
#else
!                              /
      subroutine b3fe_pmlxl ( ips )
!
!   <arguments>
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lblzu
        do iy = lblyl, lblyu
          do ix = lblxlm1, lssxlm2
            seyxxl(ix,iy,iz) = scaxli(ix) * seyxxl(ix,iy,iz) - &
                      scbexli(ix) * ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lblyl, lblyu 
          do ix = lblxlm1, lssxlm2 
            seyzxl(ix,iy,iz) = seyzxl(ix,iy,iz) + &
                               ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) ) * scb1
            sey(ix,iy,iz)  = seyzxl(ix,iy,iz) + seyxxl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblylm1, lblyu
          do ix = lblxlm1, lssxlm2
            sezxxl(ix,iy,iz) = scaxli(ix) * sezxxl(ix,iy,iz) + &
                      scbexli(ix) * ( sby(ix+1,iy,iz)-sby(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssylm1, lssyup1 
          do ix = lblxlm1, lssxlm2
            sezyxl(ix,iy,iz) = sezyxl(ix,iy,iz) - &
                               ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) ) * scb1
            sez(ix,iy,iz)  = sezyxl(ix,iy,iz) + sezxxl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1 
          do ix = lblxl, lssxlm1 
            sex(ix,iy,iz) = sex(ix,iy,iz) + &
                           ( ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) ) - &
                             ( sby(ix,iy,iz+1)-sby(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
      subroutine b3fe_pmlxu
#else
!                              /
      subroutine b3fe_pmlxu ( ips )
!
!   <arguments>
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lblzu
        do iy = lblyl, lblyu
          do ix = lssxup2, lblxu
            seyxxu(ix,iy,iz) = scaxui(ix) * seyxxu(ix,iy,iz) - &
                      scbexui(ix) * ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lblyl, lblyu 
          do ix = lssxup2, lblxu
            seyzxu(ix,iy,iz) = seyzxu(ix,iy,iz) + &
                               ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) ) * scb1
            sey(ix,iy,iz)  = seyzxu(ix,iy,iz) + seyxxu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblylm1, lblyu
          do ix = lssxup2, lblxu
            sezxxu(ix,iy,iz) = scaxui(ix) * sezxxu(ix,iy,iz) + &
                      scbexui(ix) * ( sby(ix+1,iy,iz)-sby(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssylm1, lssyup1 
          do ix = lssxup2, lblxu
            sezyxu(ix,iy,iz) = sezyxu(ix,iy,iz) - &
                               ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) ) * scb1
            sez(ix,iy,iz)  = sezyxu(ix,iy,iz) + sezxxu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssylm1, lssyup1 
          do ix = lssxup2, lblxu
            sex(ix,iy,iz) = sex(ix,iy,iz) + &
                           ( ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) ) - &
                             ( sby(ix,iy,iz+1)-sby(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
!                               /      /
      subroutine b3fe_pmlyl ( kexlf, kexuf )
#else
!                               /      /     /
      subroutine b3fe_pmlyl ( kexlf, kexuf, ips )
#endif
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
#ifdef OHHELP
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer ::  kexlf, kexuf, ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lblzu
        do iy = lblylm1, lssylm2
          do ix = lblxl, lblxu
            sexyyl(ix,iy,iz) = scayli(iy) * sexyyl(ix,iy,iz) + &
                      scbeyli(iy) * ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lblylm1, lssylm2 
          do ix = lblxl, lblxu 
            sexzyl(ix,iy,iz) = sexzyl(ix,iy,iz) - &
                               ( sby(ix,iy,iz+1)-sby(ix,iy,iz) ) * scb1
            sex(ix,iy,iz)  = sexzyl(ix,iy,iz) + sexyyl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblylm1, lssylm2
          do ix = lblxlm1, lblxu
            sezyyl(ix,iy,iz) = scayli(iy) * sezyyl(ix,iy,iz) - &
                      scbeyli(iy) * ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lblylm1, lssylm2
          do ix = lssxlm1, lssxup1 
            sezxyl(ix,iy,iz) = sezxyl(ix,iy,iz) + &
                               ( sby(ix+1,iy,iz)-sby(ix,iy,iz) ) * scb1
            sez(ix,iy,iz)  = sezxyl(ix,iy,iz) + sezyyl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lblyl, lssylm1 
          do ix = lssxlm1, lssxup1 
            sey(ix,iy,iz) = sey(ix,iy,iz) + &
                           ( ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) ) - &
                             ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lblylm1, lssylm2
            do ix = lblxlm1, lssxlm2
              sez(ix,iy,iz) = sezxxl(ix,iy,iz) + sezyyl(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lblylm1, lssylm2
            do ix = lssxup2, lblxu
              sez(ix,iy,iz) = sezxxu(ix,iy,iz) + sezyyl(ix,iy,iz)
            end do
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
!                               /      /
      subroutine b3fe_pmlyu ( kexlf, kexuf )
#else
!                               /      /     /
      subroutine b3fe_pmlyu ( kexlf, kexuf, ips )
#endif
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
#ifdef OHHELP
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer ::  kexlf, kexuf, ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lblzu
        do iy = lssyup2, lblyu
          do ix = lblxl, lblxu
            sexyyu(ix,iy,iz) = scayui(iy) * sexyyu(ix,iy,iz) + &
                      scbeyui(iy) * ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssyup2, lblyu
          do ix = lblxl, lblxu 
            sexzyu(ix,iy,iz) = sexzyu(ix,iy,iz) - &
                               ( sby(ix,iy,iz+1)-sby(ix,iy,iz) ) * scb1
            sex(ix,iy,iz)  = sexzyu(ix,iy,iz) + sexyyu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyup2, lblyu
          do ix = lblxlm1, lblxu
            sezyyu(ix,iy,iz) = scayui(iy) * sezyyu(ix,iy,iz) - &
                      scbeyui(iy) * ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lblzu
        do iy = lssyup2, lblyu
          do ix = lssxlm1, lssxup1 
            sezxyu(ix,iy,iz) = sezxyu(ix,iy,iz) + &
                               ( sby(ix+1,iy,iz)-sby(ix,iy,iz) ) * scb1
            sez(ix,iy,iz)  = sezxyu(ix,iy,iz) + sezyyu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszlm1, lsszup1
        do iy = lssyup2, lblyu
          do ix = lssxlm1, lssxup1 
            sey(ix,iy,iz) = sey(ix,iy,iz) + &
                           ( ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) ) - &
                             ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lssyup2, lblyu
            do ix = lblxlm1, lssxlm2
              sez(ix,iy,iz) = sezxxl(ix,iy,iz) + sezyyu(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzl, lblzu
          do iy = lssyup2, lblyu
            do ix = lssxup2, lblxu
              sez(ix,iy,iz) = sezxxu(ix,iy,iz) + sezyyu(ix,iy,iz)
            end do
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
!                               /      /      /      /
      subroutine b3fe_pmlzl ( kexlf, kexuf, keylf, keyuf )
#else
!                               /      /      /      /     /
      subroutine b3fe_pmlzl ( kexlf, kexuf, keylf, keyuf, ips )
#endif
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!     keylf :  = 4 : PML in y low direction
!           : != 4 : ignore
!     keyuf :  = 4 : PML in y upper direction
!           : != 4 : ignore
#ifdef OHHELP
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, keylf, keyuf, ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lsszlm2
        do iy = lblylm1, lblyu
          do ix = lblxl, lblxu
            sexzzl(ix,iy,iz) = scazli(iz) * sexzzl(ix,iy,iz) - &
                      scbezli(iz) * ( sby(ix,iy,iz+1)-sby(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lsszlm2 
        do iy = lssylm1, lssyup1
          do ix = lblxl, lblxu 
            sexyzl(ix,iy,iz) = sexyzl(ix,iy,iz) + &
                               ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) ) * scb1
            sex(ix,iy,iz)  = sexyzl(ix,iy,iz) + sexzzl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lsszlm2
        do iy = lblyl, lblyu
          do ix = lblxlm1, lblxu
            seyzzl(ix,iy,iz) = scazli(iz) * seyzzl(ix,iy,iz) + &
                      scbezli(iz) * ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzlm1, lsszlm2
        do iy = lblyl, lblyu
          do ix = lssxlm1, lssxup1 
            seyxzl(ix,iy,iz) = seyxzl(ix,iy,iz) - &
                               ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) ) * scb1
            sey(ix,iy,iz)  = seyxzl(ix,iy,iz) + seyzzl(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lblzl, lsszlm1 
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1 
            sez(ix,iy,iz) = sez(ix,iy,iz) + &
                           ( ( sby(ix+1,iy,iz)-sby(ix,iy,iz) ) - &
                             ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzlm1, lsszlm2
          do iy = lblyl, lblyu
            do ix = lblxlm1, lssxlm2
              sey(ix,iy,iz) = seyxxl(ix,iy,iz) + seyzzl(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzlm1, lsszlm2
          do iy = lblyl, lblyu
            do ix = lssxup2, lblxu
              sey(ix,iy,iz) = seyxxu(ix,iy,iz) + seyzzl(ix,iy,iz)
            end do
          end do
        end do
      end if
!...
      if( keylf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzlm1, lsszlm2
          do iy = lblylm1, lssylm2
            do ix = lblxl, lblxu
              sex(ix,iy,iz) = sexyyl(ix,iy,iz) + sexzzl(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( keyuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lblzlm1, lsszlm2
          do iy = lssyup2, lblyu
            do ix = lblxl, lblxu
              sex(ix,iy,iz) = sexyyu(ix,iy,iz) + sexzzl(ix,iy,iz)
            end do
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
!-----------------------------------------------------------------------
#ifndef OHHELP
!                               /      /      /      /
      subroutine b3fe_pmlzu ( kexlf, kexuf, keylf, keyuf )
#else
!                               /      /      /      /     /
      subroutine b3fe_pmlzu ( kexlf, kexuf, keylf, keyuf, ips )
#endif
!
!   <arguments>
!     kexlf :  = 4 : PML in x low direction
!           : != 4 : ignore
!     kexuf :  = 4 : PML in x upper direction
!           : != 4 : ignore
!     keylf :  = 4 : PML in y low direction
!           : != 4 : ignore
!     keyuf :  = 4 : PML in y upper direction
!           : != 4 : ignore
#ifdef OHHELP
!     ips   : = 1 (primary) or 2 (secondary)
#endif
!
!    coded by Sakagami,H. (NIFS) 20/09/14
!----------------------------------------------------------------------
#ifdef OHHELP
      use oh_param
#endif
      use constant
      use field
      use pml
      include "implicit.h"
      integer :: kexlf, kexuf, keylf, keyuf, ix, iy, iz
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!$OMP PARALLEL
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lblylm1, lblyu
          do ix = lblxl, lblxu
            sexzzu(ix,iy,iz) = scazui(iz) * sexzzu(ix,iy,iz) - &
                      scbezui(iz) * ( sby(ix,iy,iz+1)-sby(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lssylm1, lssyup1
          do ix = lblxl, lblxu 
            sexyzu(ix,iy,iz) = sexyzu(ix,iy,iz) + &
                               ( sbz(ix,iy+1,iz)-sbz(ix,iy,iz) ) * scb1
            sex(ix,iy,iz)  = sexyzu(ix,iy,iz) + sexzzu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lblyl, lblyu
          do ix = lblxlm1, lblxu
            seyzzu(ix,iy,iz) = scazui(iz) * seyzzu(ix,iy,iz) + &
                      scbezui(iz) * ( sbx(ix,iy,iz+1)-sbx(ix,iy,iz) )
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lblyl, lblyu
          do ix = lssxlm1, lssxup1 
            seyxzu(ix,iy,iz) = seyxzu(ix,iy,iz) - &
                               ( sbz(ix+1,iy,iz)-sbz(ix,iy,iz) ) * scb1
            sey(ix,iy,iz)  = seyxzu(ix,iy,iz) + seyzzu(ix,iy,iz)
          end do
        end do
      end do
!..
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
      do iz = lsszup2, lblzu
        do iy = lssylm1, lssyup1
          do ix = lssxlm1, lssxup1 
            sez(ix,iy,iz) = sez(ix,iy,iz) + &
                           ( ( sby(ix+1,iy,iz)-sby(ix,iy,iz) ) - &
                             ( sbx(ix,iy+1,iz)-sbx(ix,iy,iz) ) ) * scb1
          end do
        end do
      end do
!...
      if( kexlf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblyl, lblyu
            do ix = lblxlm1, lssxlm2
              sey(ix,iy,iz) = seyxxl(ix,iy,iz) + seyzzu(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( kexuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblyl, lblyu
            do ix = lssxup2, lblxu
              sey(ix,iy,iz) = seyxxu(ix,iy,iz) + seyzzu(ix,iy,iz)
            end do
          end do
        end do
      end if
!...
      if( keylf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lblylm1, lssylm2
            do ix = lblxl, lblxu
              sex(ix,iy,iz) = sexyyl(ix,iy,iz) + sexzzu(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      if( keyuf .eq. 4 ) then
!$OMP DO SCHEDULE(STATIC) PRIVATE(iy,ix)
        do iz = lsszup2, lblzu
          do iy = lssyup2, lblyu
            do ix = lblxl, lblxu
              sex(ix,iy,iz) = sexyyu(ix,iy,iz) + sexzzu(ix,iy,iz)
            end do
          end do
        end do
      end if
!$OMP END PARALLEL
!....
      return
      end
