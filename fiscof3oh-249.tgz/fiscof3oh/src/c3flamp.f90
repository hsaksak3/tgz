!----------------------------------------------------------------------
! Compute 3D Field Laser AMPlitude in time
!                           /     /
      subroutine c3flamp ( kbn, fstep, famp )
!                                       /
!   <arguments>
!     kbn   : beam # ( 1 <= kbn <= llsrbn )
!     fstep : time step
!     famp  : normalized amplitude
!
!   <remarks>
!     -------------------------------------------------
!     type    pulse            sbemle  sbemwd  sbemtr
!     -------------------------------------------------
!     1       linear + flat    rampup  length  rampdown
!     2       gaussian + flat  HWHM    length  HWHM
!     3       gaussian         -       FWHM    -
!     4       supergaussian    alpha   FWHM    -
!
!     sbemmn : start(end) minimum amp. / maximum amp.
!     -------------------------------------------------
!     *unit is [fs]
!
!    coded by Sakagami,H. ( NIFS ) 10/08/17
!----------------------------------------------------------------------
      use constant
      use laserprf
      include "implicit.h"
      integer :: init=0, i, itype, kbn
      real*8  :: fstep, famp, wtdtr, wt2(llsrbx), wlsrwd(llsrbx), &
                 wtdle(llsrbx), wtd(llsrbx), wtend(llsrbx), wtime
!     save  comment for thread safe
      save :: init, wt2, wlsrwd, wtdle, wtd, wtend
!....
      if( init .eq. 0 ) then
!$OMP SINGLE
         do i = 1, llsrbn
            itype = mod( lbemty(i), 10 )
            if( itype .eq. 1 ) then
               wt2(i) = sbemle(i) + sbemwd(i)
            else if( itype .eq. 2 ) then
               wtdle(i) = sqrt( - log(sbemmn(i))/log(s2o1) ) * sbemle(i)
               wtdtr = sqrt( - log(sbemmn(i))/log(s2o1) ) * sbemtr(i)
               wt2(i) = wtdle(i) + sbemwd(i)
            else if( itype .ge. 3 ) then
               wlsrwd(i) = sbemwd(i) * s1o2
               if( itype .eq. 3 ) then
                  wtd(i) = sqrt( - log(sbemmn(i))/log(s2o1) ) * &
                           wlsrwd(i)
               else
                  wtd(i) = ( -log(sbemmn(i))/log(s2o1) )** &
                           ( s1o1/sbemle(i) ) * wlsrwd(i)
               end if
            end if
            if( itype .eq. 1 ) then
               wtend(i) = sbemle(i) + sbemwd(i) + sbemtr(i)
            else if( itype .eq. 2 ) then
               wtend(i) = wtdle(i) + sbemwd(i) + wtdtr
            else if( itype .ge. 3 ) then
               wtend(i) = wtd(i) * s2o1
            end if
         end do
!$OMP END SINGLE
         init = 1
!$OMP BARRIER
      end if
!....
      wtime = fstep * sdtfs - sbemdl(kbn)
!....
      itype = mod( lbemty(kbn), 10 )
      famp = s0o1
!..
      if( wtime .gt. s0o1 .and. wtime .le. wtend(kbn) ) then
         if( itype .eq. 1 ) then
            if( wtime .lt. sbemle(kbn) ) then
               famp = sqrt( (s1o1-sbemmn(kbn))/sbemle(kbn)*wtime + &
                            sbemmn(kbn) )
            else if( wtime .gt. wt2(kbn) ) then
               famp = sqrt( (sbemmn(kbn)-s1o1)/sbemtr(kbn)* &
                            (wtime-wt2(kbn))+s1o1 )
            else
               famp = s1o1
            end if
         else if( itype .eq. 2 ) then
            if( wtime .lt. wtdle(kbn) ) then
               famp = sqrt( exp(-log(s2o1)*((wtime-wtdle(kbn))/ &
                            sbemle(kbn))**2) )
            else if( wtime .gt. wt2(kbn) ) then
               famp = sqrt( exp(-log(s2o1)*((wtime-wt2(kbn))/ &
                            sbemtr(kbn))**2) )
            else
               famp = s1o1
            end if
         else if( itype .eq. 3 ) then
            famp = sqrt( exp(-log(s2o1)*((wtime-wtd(kbn))/ &
                         wlsrwd(kbn))**2) )
         else if( itype .eq. 4 ) then
            famp = sqrt( exp(-log(s2o1)*(abs(wtime-wtd(kbn))/ &
                         wlsrwd(kbn))**sbemle(kbn)) )
         end if
      end if
!....
      return
      end
!----------------------------------------------------------------------
! Compute 3D Field Laser Phase
!                           /   /   /   /
      subroutine c3flphs ( fx, fy, fz, kbn, fph )
!                                            /
!   <arguments>
!     fx   : x of given point (micron)
!     fy   : y of given point (micron)
!     fz   : z of given point (micron)
!     kbn  : beam # ( 1 <= kbn <= llsrbn )
!     fph  : phase
!
!   <remarks>
!     none
!
!   coded by Sakagami,H. (NIFS) 12/07/24
!----------------------------------------------------------------------
      use constant
      use laserprf
      include "implicit.h"
      integer :: kbn, itrns
      real*8  :: fx, fy, fz, fph, wx, wy, wtt, wll, wz,wr,wrr,wbw0,wzz,wcr
      save
!....
      itrns = mod( lbemty(kbn)/10, 10 )
!...
      wx = fx - sbemxf(kbn)
      wy = fy - sbemyf(kbn)
      wz = fz - sbemzf(kbn)
!...
      if( itrns .le. 3 ) then
         wtt = - wx * cos(sbemanr(kbn)) + wy * sin(sbemanr(kbn))
         !wtt = wx * sin(sbemanr(kbn)) + wy * cos(sbemanr(kbn))
         !wll = sqrt( ( wx - wtt * sin(sbemanr(kbn)) )**2 + &
         !            ( wy - wtt * cos(sbemanr(kbn)) )**2 )
         fph = s2pi / sbemwl(kbn) * wtt
      else if( itrns .eq. 4 ) then
         wll  =  wx*cos(sbemanr(kbn)) - wy*sin(sbemanr(kbn))
         wr = sqrt( (wx - wll * cos(sbemanr(kbn)))**2 + &
                    (wy + wll * sin(sbemanr(kbn)))**2 + wz**2 )
         wbw0 = s2o1 * sbemwl(kbn) * sbemfi(kbn) / spi
         wrr = spi * wbw0**2 / sbemwl(kbn)
         wzz = wll / wrr
         wcr = wll * ( s1o1 + s1o1 / wzz**2 )
         fph = atan( wzz )      - s2pi/sbemwl(kbn) * &
                             ( wll+wr**2/(s2o1*wcr) )
!2d      fph = atan( wzz )/s2o1 - s2pi/sbemwl(kbn) * &
!                            ( wll+wr**2/(s2o1*wcr) )
      else
         fph = s0o1
      end if
!....
      return
      end
!----------------------------------------------------------------------
! Compute 3D Field Laser TRansvers Amplitude
!                           /   /   /   /
      subroutine c3fltra ( fx, fy, fz, kbn, famp )
!                                            /
!   <arguments>
!     fx   : x of given point (micron)
!     fy   : y of given point (micron)
!     fz   : z of given point (micron)
!     kbn  : beam # ( 1 <= kbn <= llsrbn )
!     famp : amplitude
!
!   <remarks>
!     none
!
!   coded by Sakagami,H. (NIFS) 12/07/24
!----------------------------------------------------------------------
      use constant
      use laserprf
      include "implicit.h"
      integer :: kbn, itrns
      real*8  :: fx, fy, fz, famp, wx, wy, wtt, wll, wz, wr, wrr, wzz, wbw0, wbw
!     save  comment for thread safe
!....
      itrns = mod( lbemty(kbn)/10, 10 )
!..
      wx = fx - sbemxf(kbn)
      wy = fy - sbemyf(kbn)
      wz = fz - sbemzf(kbn)
!..
      if( itrns .eq. 1 ) then
         famp = s1o1
      else if( itrns .eq. 2 ) then
         wtt = - wx * cos(sbemanr(kbn)) + wy * sin(sbemanr(kbn))
         wr = sqrt( (wx + wtt * cos(sbemanr(kbn)))**2 + &
                    (wy - wtt * sin(sbemanr(kbn)))**2 + wz**2 )
         famp = sqrt( exp(-log(s2o1)*(s2o1*wr/sbemfi(kbn))**2) )
      else if( itrns .eq. 3 ) then
         !wtt = abs( wx * sin(sbemanr(kbn)) + wy * cos(sbemanr(kbn)) )
         wtt = - wx * cos(sbemanr(kbn)) + wy * sin(sbemanr(kbn))
         wr = sqrt( (wx + wtt * cos(sbemanr(kbn)))**2 + &
                    (wy - wtt * sin(sbemanr(kbn)))**2 + wz**2 )
         famp = sqrt(  &
                   exp(-log(s2o1)*(s2o1*wr/sbemfi(kbn))**sbemal(kbn)) )
      else if( itrns .eq. 4 ) then
         wll = wx*cos(sbemanr(kbn)) - wy*sin(sbemanr(kbn)) 
         wr = sqrt( (wx - wll * cos(sbemanr(kbn)))**2 + &
                    (wy + wll * sin(sbemanr(kbn)))**2 + wz**2 )
         wbw0 = s2o1 * sbemwl(kbn) * sbemfi(kbn) / spi
         wrr = spi * wbw0**2 / sbemwl(kbn)
         wzz = wll / wrr
         wbw = wbw0 * sqrt( s1o1 + wzz**2 )
         famp =       wbw0/wbw   * exp( - wr**2 / wbw**2 )
!2d      famp = sqrt( wbw0/wbw ) * exp( - wr**2 / wbw**2 )
      else
         famp = s0o1
      end if
!....
      return
      end
