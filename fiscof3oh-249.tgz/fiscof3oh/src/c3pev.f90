!-----------------------------------------------------------------------
! Compute 3D Particle Electron Velocity
!
      subroutine c3pev
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/10
!-----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use constant
      use particle
#ifdef DEBUGXY
      use observe
#endif
      include "implicit.h"
      integer :: i
      real*8  :: wtmp
#ifdef OHHELP
      integer :: ips
#endif
#ifdef DEBUGX
      real*8 :: wee
#endif
#ifdef DEBUGY
      integer*8 :: ipn, ipid(5) = &
                   (/ 5582271, 2634193, 3863223, 1505997, 6062627 /)
#endif

      save
!....
      call fdebug ( 'c3pev', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(wtmp)
      do i = lnoes, lnoee
         wtmp = s1o1 / sqrt( s1o1 + suue(i)**2 * scg1 )
         svxe(i) = suxe(i) * wtmp
         svye(i) = suye(i) * wtmp
         svze(i) = suze(i) * wtmp
      end do
#ifdef DEBUGY
      do i = lnoes, lnoee
        do ipn = 1, 5
          if( spdat1(i)%pid .eq. ipid(ipn) ) then
            write(6,*) '##WEE1', spdat1(i)%pid, lstcur, ips, i
            write(6,*) '##WEE2', sxe(i), sye(i), sze(i)
            write(6,*) '##WEE3', svxe(i), svye(i), svze(i) 
            write(6,*) '##WEE4', suxe(i), suye(i), suze(i) 
            write(6,*) '##WEE5', sfxe(i), sfye(i), sfze(i) 
          end if
        end do
      end do
#endif
#ifdef DEBUGX
      do i = lnoes, lnoee
         wee = sqrt( s1o1+suue(i)**2*scg1 ) - s1o1
         if( wee .gt. 1.0d4 ) then
            write(6,*) '##WEE1', wee, spdat1(i)%pid, lstcur, ips, i
            write(6,*) '##WEE2', sxe(i), sye(i), sze(i)
            write(6,*) '##WEE3', svxe(i), svye(i), svze(i) 
            write(6,*) '##WEE4', suxe(i), suye(i), suze(i) 
            write(6,*) '##WEE5', sfxe(i), sfye(i), sfze(i) 
         end if
      end do
#endif
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c3pev', 1 )
!....
      return
      end
