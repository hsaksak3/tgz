!----------------------------------------------------------------------
! Set 3D RELOCation particles
!                            /       /
      subroutine s3reloc ( kstcur, kmode )
!
!   <arguments>
!     kstcur: current time step
!     kmode : 1 = relocate electrons
!           : 2 = relocate electrons and ions
!           : 3 = relocate ions
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 22/11/1
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      include "implicit.h"
      integer :: kstcur, kmode, i, io, is
      real*8  :: fgetwtod, astr
      real*8, allocatable :: aloc(:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 's3reloc', 0 )
!....
      astr = fgetwtod()
!....
      if( kmode .le. 2 ) then
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoe(ips) .le. 0 ) cycle 
#endif
         if( lnoe .gt. 0 ) then
            allocate( aloc(lnoe) )
!..
            do i = lnoes, lnoee
               is = i - lnoes + 1
               aloc(is) = floor(sxe(i)) + floor(sye(i)) * lssx + &
                          floor(sze(i)) * ( lssx*lssy )
            end do
!..
            call qssortp( aloc, spdat1(lnoes:lnoee), lnoe )
!..
            deallocate( aloc )
         end if
#ifdef OHHELP
      end do  
#endif
      end if
!....
      if( kmode .ge. 2 ) then
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
!..
         do io = 1, lionspl
            if( lionidl(io) .gt. 0 ) then
               allocate( aloc(lionidl(io)) )
!..
               do i = lionids(io), lionide(io)
                  is = i - lionids(io) + 1
                  aloc(is) = floor(sxi(i)) + floor(syi(i)) * lssx + &
                             floor(szi(i)) * ( lssx*lssy )
               end do
!..
               call qssortp( aloc, spdat1(lionids(io):lionide(io)), &
                             lionidl(io) )
!..
               deallocate( aloc )
            end if
         end do
!..
#ifdef OHHELP
      end do  
#endif
      end if
!....
      write(0,*) '@@@ s3reloc at ', kstcur, ': mode =',kmode, &
                 ', elapse(s) =', fgetwtod()-astr, lrank
!....
      call fdebug ( 's3reloc', 1 )
!....
      return
      end
