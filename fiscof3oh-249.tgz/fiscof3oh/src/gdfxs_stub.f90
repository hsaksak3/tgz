      subroutine gdfxs_init
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_init is here. @@@'
      return
      end
      subroutine gdfxs_term
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_term is here. @@@'
      return
      end
      subroutine gdfxs_bodys
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_bodys is here. @@@'
      return
      end
      subroutine gdfxs_body31
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_body31 is here. @@@'
      return
      end
      subroutine gdfxs_bodye
      use parameter
      if( lrank .le. 0 ) &
      write(0,*) '@@@ gdfxs_bodye is here. @@@'
      return
      end
