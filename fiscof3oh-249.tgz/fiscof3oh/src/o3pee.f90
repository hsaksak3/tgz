!----------------------------------------------------------------------
! Observe 3D Particle Electron Energy (MeV)
!                          /
      subroutine o3pee ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     This routine does not average the value, so always alloc/dealloc
!    arrays to save the memory. 
!
!    coded by Sakagami,H. (NIFS) 20/11/25
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use profile
      use observe
      include "implicit.h"
      integer, parameter :: iun = 20, ifn = 1
      integer, parameter :: lpex = 201
      integer :: kflag, i, io, ig, iopee, ilog, iopeel
      real*8  :: wgam, &
                 wopeexps(lopeex), wopeexpe(lopeex), &
                 wopeeyps(lopeex), wopeeype(lopeex), &
                 wopeezps(lopeex), wopeezpe(lopeex)
      real*8, allocatable :: apeen(:,:)
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'o3pee', 0 )
!....
      if( kflag .ge. 1 ) then
!..
         allocate( apeen(lpex,iopeel) )
!..
         do io = 1, iopeel
            do i = 1, lpex
               apeen(i,io) = s0o1
            end do
         end do
!.
#ifdef OHHELP
         do ips = 1, 2
         if( oh_lnoe(ips) .le. 0 ) cycle
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:apeen), &
!$OMP             PRIVATE(io,ig,wgam)
         do i = lnoes, lnoee
          do io = 1, iopeel
            if( sxe(i).lt.sopeexps(io).or.sxe(i).gt.sopeexpe(io) ) cycle
            if( sye(i).lt.sopeeyps(io).or.sye(i).gt.sopeeype(io) ) cycle
            if( sze(i).lt.sopeezps(io).or.sze(i).gt.sopeezpe(io) ) cycle
!
            wgam = sqrt( s1o1 + suue(i)**2 * scg1 )
            ig = ( wgam - s1o1 ) * scoft * sopeefct(io) + s1o1
            ig = min( ig, lpex )
            apeen(ig,io) = apeen(ig,io) + spfe(i)
          end do
         end do
#ifdef OHHELP
         end do
#endif
!.
         if( iopee .le. 4 ) then
            write(iun) sstcur, ((apeen(i,io),i=1,lpex),io=1,iopeel)
            flush(iun)
         end if
!.
         if( iopee .ge. 2 ) then
            do io = 1, iopeel
               call o3pdraw1 ( bident, sstcur, sminlog, lminlog, &
                  ifn, ilog, apeen(1,io), lpex, sopeefct(io), &
                  wopeexps(io), wopeeyps(io), wopeezps(io), &
                  wopeexpe(io), wopeeype(io), wopeezpe(io), &
                  'MeV', 'number[a.u.]', 'pee' )
            end do
         end if
!..
         deallocate( apeen )
!....
      else
         iopee  = mod( lopee, 10 )
         ilog   = mod( lopee/10, 10 )
         iopeel = mod( lopee/100, 10 )
!..
         do io = 1, iopeel
            if( sopeexps(io) .le. sundef ) then
               sopeexps(io) = lxps
            else
               sopeexps(io) = sopeexps(io) * slmic + loxp0
            end if
            if( sopeexpe(io) .le. sundef ) then
               sopeexpe(io) = lxpe
            else
               sopeexpe(io) = sopeexpe(io) * slmic + loxp0
            end if
            if( sopeeyps(io) .le. sundef ) then
               sopeeyps(io) = lyps
            else
               sopeeyps(io) = sopeeyps(io) * slmic + loyp0
            end if
            if( sopeeype(io) .le. sundef ) then
               sopeeype(io) = lype
            else
               sopeeype(io) = sopeeype(io) * slmic + loyp0
            end if
            if( sopeezps(io) .le. sundef ) then
               sopeezps(io) = lzps
            else
               sopeezps(io) = sopeezps(io) * slmic + lozp0
            end if
            if( sopeezpe(io) .le. sundef ) then
               sopeezpe(io) = lzpe
            else
               sopeezpe(io) = sopeezpe(io) * slmic + lozp0
            end if
            wopeexps(io) = ( sopeexps(io) - loxp0 ) * slmicinv
            wopeexpe(io) = ( sopeexpe(io) - loxp0 ) * slmicinv
            wopeeyps(io) = ( sopeeyps(io) - loyp0 ) * slmicinv
            wopeeype(io) = ( sopeeype(io) - loyp0 ) * slmicinv
            wopeezps(io) = ( sopeezps(io) - lozp0 ) * slmicinv
            wopeezpe(io) = ( sopeezpe(io) - lozp0 ) * slmicinv
            if( lrank .le. 0 ) &
            write(6,*) 'wopee[xyz]p[se] = ', io, &
                wopeexps(io), wopeeyps(io), wopeezps(io), &
                wopeexpe(io), wopeeype(io), wopeezpe(io)
         end do
         if( iopee .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'pee', bfile )
            open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
            write(iun) 'pee4', bident, lpex, iopeel, (sopeefct(io), &
               wopeexps(io),wopeeyps(io),wopeezps(io), &
               wopeexpe(io),wopeeype(io),wopeezpe(io),io=1,iopeel)
#else
            write(iun) 'pee5', bident, lpex, iopeel, (sopeefct(io), &
               wopeexps(io),wopeeyps(io),wopeezps(io), &
               wopeexpe(io),wopeeype(io),wopeezpe(io),io=1,iopeel), &
               lrank, ldivx, ldivy, ldivz
#endif
            flush(iun)
         end if
         if( iopee .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'pee', bfile )
            call frames_file ( bfile, ifn, iopee )
         end if
!....
      end if
!....
      call fdebug ( 'o3pee', 1 )
!....
      return
      end
