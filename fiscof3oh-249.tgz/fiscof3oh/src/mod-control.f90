!----------------------------------------------------------------------
! control
!
module control
      use parameter
      integer :: &
         lresti, lresto, &
         lbxluf, lbxlupe, lbxlupi, &
         lbyluf, lbylupe, lbylupi, &
         lbzluf, lbzlupe, lbzlupi, &
         lexlf, lexlpe, lexlpi, lexuf, lexupe, lexupi, &
         leylf, leylpe, leylpi, leyuf, leyupe, leyupi, &
         lezlf, lezlpe, lezlpi, lezuf, lezupe, lezupi, &		
         lclflge, lclflgia, lclflgi(lionspx)
      real*8 :: &
         sextbx, sextby, sextbz, &
         sclboe(6,lclflgex), sclboi(6,lclflgix,lionspx), &
         scluure(lclflgex), scluule(lclflgex), &
         scluu0e(lclflgex), sclfcte(lclflgex), &
         scluuri(lclflgix,lionspx), scluuli(lclflgix,lionspx), &
         scluu0i(lclflgix,lionspx), sclfcti(lclflgix,lionspx)
      character :: brestfntp*64
end module control
