!-------------------------------------------------------------------
! QSTaRT for POSition
!
      subroutine qstrtpos ( kp, knpme,ffd,ffp, fpdat1, kno, knox,&
                            kpc )
!
!   <arguments>
!     kp    : i  : index of profile
!     knpme : i  : effective number of particle per mesh
!     ffd   : i  : factor for density
!     ffp   : i  : factor for particle factor
!     fpdat1: io : structure of particle data type 1
!     kno   : io : index of structure
!     knox  : i  : size of structure
!     kpc   : i  : if kpc = -1 then particle number count mode
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/07/18
!----------------------------------------------------------------------
      use parameter
      use ptcltype
      use profile
      use constant
      include "implicit.h"
      type(ty1_particle) :: fpdat1(knox)
      integer, parameter :: lqn = 100
      integer :: kpc
      integer :: kp, knpme, kno, knox, iwsh,isty,idir,iho, i,is,inpm, &
                 ix,ixps,ixpe, iy,iyps,iype, iz,izps,izpe, ind,ino0,ixx
      real*8  :: ffd, ffp, wran(lqn), wy(lqn), wz(lqn), &
                 axp, ayp, azp, axp0, ayp0, azp0, aden, &
                 asc, ar, ar0, ax, ay, az, awid(3), apppnx, apppnm
      save
!....
      call fdebug ( 'qstrtpos', 0 )
!....
      iwsh = mod( lpppty(kp), 10 )
      isty = mod( lpppty(kp)/10, 10 )
      idir = mod( lpppty(kp)/100, 10 )
!....
      select case( iwsh )
      case( 1, 5, 6, 7 )
        ixps = spppbo(1,kp) * slmic + lxp0
        ixpe = spppbo(4,kp) * slmic + lxp0 
        iyps = spppbo(2,kp) * slmic + lyp0
        iype = spppbo(5,kp) * slmic + lyp0 
        izps = spppbo(3,kp) * slmic + lzp0
        izpe = spppbo(6,kp) * slmic + lzp0 
      case( 3 )
        if( abs(spppro(3,kp)) .le. abs(spppro(2,kp)) ) then
          ax =  spppro(2,kp) / sqrt( spppro(1,kp)**2+spppro(2,kp)**2 )
          ay = -spppro(1,kp) / sqrt( spppro(1,kp)**2+spppro(2,kp)**2 )
          az = spppro(1,kp)*ay - spppro(2,kp)*ax
        else
          ax = -spppro(3,kp) / sqrt( spppro(1,kp)**2+spppro(3,kp)**2 )
          az =  spppro(1,kp) / sqrt( spppro(1,kp)**2+spppro(3,kp)**2 )
          ay = spppro(3,kp)*ax - spppro(1,kp)*az
        end if
        ax = abs( ax )
        ay = abs( ay )
        az = abs( az )
        ar0  = spppbo(4,kp) * tan( spppbo(6,kp) )
        ar   = spppbo(5,kp) * tan( spppbo(6,kp) )
        axp0 = spppbo(1,kp) + spppbo(4,kp) * spppro(1,kp) - ar0 * ax
        axp  = spppbo(1,kp) + spppbo(5,kp) * spppro(1,kp) - ar  * ax
        ayp0 = spppbo(2,kp) + spppbo(4,kp) * spppro(2,kp) - ar0 * ay
        ayp  = spppbo(2,kp) + spppbo(5,kp) * spppro(2,kp) - ar  * ay
        azp0 = spppbo(3,kp) + spppbo(4,kp) * spppro(3,kp) - ar0 * az
        azp  = spppbo(3,kp) + spppbo(5,kp) * spppro(3,kp) - ar  * az
        ixps = min( axp0, axp ) * slmic + lxp0
        iyps = min( ayp0, ayp ) * slmic + lyp0
        izps = min( azp0, azp ) * slmic + lzp0
        axp0 = spppbo(1,kp) + spppbo(4,kp) * spppro(1,kp) + ar0 * ax
        axp  = spppbo(1,kp) + spppbo(5,kp) * spppro(1,kp) + ar  * ax
        ayp0 = spppbo(2,kp) + spppbo(4,kp) * spppro(2,kp) + ar0 * ay
        ayp  = spppbo(2,kp) + spppbo(5,kp) * spppro(2,kp) + ar  * ay
        azp0 = spppbo(3,kp) + spppbo(4,kp) * spppro(3,kp) + ar0 * az
        azp  = spppbo(3,kp) + spppbo(5,kp) * spppro(3,kp) + ar  * az
        ixpe = max( axp0, axp ) * slmic + lxp0
        iype = max( ayp0, ayp ) * slmic + lyp0
        izpe = max( azp0, azp ) * slmic + lzp0
      end select
!..
      if( ixps .lt. 1 ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: x position less than 1.',kp,ixps
         ixps = 1
      end if
      if( ixpe .gt. lssx ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: x position greater than',lssx,'.',&
                   kp,ixpe
         ixpe = lssx
      end if
!.
      if( iyps .lt. 1 ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: y position less than 1.',kp,iyps
         iyps = 1
      end if
      if( iype .gt. lssy ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: y position greater than',lssy,'.',&
                   kp,iype
         iype = lssy
      end if
!.
      if( izps .lt. 1 ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: z position less than 1.',kp,izps
         izps = 1
      end if
      if( izpe .gt. lssz ) then
         if( lrank .le. 0 ) &
         write(0,*) '### WARNING: z position greater than',lssz,'.',&
                   kp,izpe
         izpe = lssz
      end if
!..
      apppnx = max( spppns(kp), spppne(kp) )
      apppnm = min( spppns(kp), spppne(kp) )
      if( isty .eq. 1 ) apppnm = apppnx
      if( spppns(kp) .ge. spppne(kp) ) then
         ind = 1
      else
         ind = -1
      end if
!...
      select case( iwsh )
      case( 1 )
        if( idir .ge. 1 .and. idir .le. 3 ) then
          if( spppsc(kp) .gt. s0o1 ) then
            asc = spppsc(kp)
          else
            awid(1) = spppbo(4,kp) - spppbo(1,kp)
            awid(2) = spppbo(5,kp) - spppbo(2,kp)
            awid(3) = spppbo(6,kp) - spppbo(3,kp) 
            if( isty .eq. 2 ) then
               asc = awid(idir) / ( s1o1 - apppnm / apppnx )
            else if( isty .eq. 3 ) then
               asc = - awid(idir) / log( apppnm / apppnx )
            end if
          end if
          if( ind .gt. 0 ) then
            asc = - asc
          end if
          if( ind .gt. 0 ) then
            axp0 = spppbo(1,kp)
            ayp0 = spppbo(2,kp)
            azp0 = spppbo(3,kp)
          else
            axp0 = spppbo(4,kp)
            ayp0 = spppbo(5,kp)
            azp0 = spppbo(6,kp)
          end if
!...
        else if( idir .eq. 4 ) then
          if( spppsc(kp) .gt. s0o1 ) then
            if( isty .eq. 4 ) then
               asc = spppsc(kp)**2 / log( s2o1 )
            else
               asc = spppsc(kp)
            end if
          else
            awid(1) = spppre(kp) - sppprs(kp)
            if( isty .eq. 2 ) then
               asc = awid(1) / ( s1o1 - apppnm / apppnx )
            else if( isty .eq. 3 ) then
               asc = - awid(1) / log( apppnm / apppnx )
            else if( isty .eq. 4 ) then
               asc = - awid(1)**2 / log( apppnm / apppnx )
            end if
          end if
          if( ind .gt. 0 ) then
            asc = - asc
          end if
          axp0 = spppro(1,kp)
          ayp0 = spppro(2,kp)
          azp0 = spppro(3,kp)
          if( ind .gt. 0 ) then
            ar0 = sppprs(kp)
          else
            ar0 = spppre(kp)
          end if
        end if
      end select
!....
      do iz = izps, izpe-1
         do iy = iyps, iype-1
            do ix = ixps, ixpe-1
!.
               axp = ( ix + s1o2 - lxp0 ) * slmicinv
               ayp = ( iy + s1o2 - lyp0 ) * slmicinv
               azp = ( iz + s1o2 - lzp0 ) * slmicinv

               if( lppphf(kp) .ne. -1 ) then
                  call qstrthol( lppphf(kp), axp, ayp, azp, iho )
                  if( iho .ne. 0 ) cycle
               end if
!.
               ino0 = kno
!...
               select case( iwsh )
               case( 1 )
                if( idir .le. 3 ) then 
                  if( isty .eq. 1 ) then
                     aden = spppns(kp)
                  else if( isty .eq. 2 ) then
                     if( idir .eq. 1 ) then
                        aden = apppnx * ( s1o1 + ( axp - axp0 ) / asc )
                     else if( idir .eq. 2 ) then
                        aden = apppnx * ( s1o1 + ( ayp - ayp0 ) / asc )
                     else if( idir .eq. 3 ) then
                        aden = apppnx * ( s1o1 + ( azp - azp0 ) / asc )
                     end if
                  else if( isty .eq. 3 ) then
                     if( idir .eq. 1 ) then 
                        aden = apppnx * exp( ( axp - axp0 ) / asc )
                     else if( idir .eq. 2 ) then
                        aden = apppnx * exp( ( ayp - ayp0 ) / asc )
                     else if( idir .eq. 3 ) then
                        aden = apppnx * exp( ( azp - azp0 ) / asc )
                     end if
                  else
                     write(0,*) '### ERROR: invalid lpppty.#2', &
                                kp, lpppty(kp)
                     call s3ext_abort
                  end if
!...
                else if( idir .eq. 4 ) then
                  ar = sqrt( ( axp - axp0 )**2 + ( ayp - ayp0 )**2 + &
                             ( azp - azp0 )**2 )
                  if( ar.ge.sppprs(kp) .and. ar.le.spppre(kp) ) then
                     ar = ar - ar0
                     if( isty .eq. 1 ) then              
                        aden = spppns(kp)
                     else if( isty .eq. 2 ) then
                        aden = apppnx * ( 1 + ar / asc )
                     else if( isty .eq. 3 ) then
                        aden = apppnx * exp( ar / asc )
                     else if( isty .eq. 4 ) then
                        aden = apppnx * exp( ind * ar**2 / asc )
                     else 
                        write(0,*) '### ERROR: invalid lpppty.#3', &
                                kp, lpppty(kp)
                        call s3ext_abort
                     end if
!..
                  else 
                     aden = 0.0d0
                  end if
                end if
               case( 3 )
                aden = 0.0d0
                ax = axp - spppbo(1,kp)
                ay = ayp - spppbo(2,kp)
                az = azp - spppbo(3,kp)
                ar0 = ax*spppro(1,kp) + ay*spppro(2,kp) + &
                      az*spppro(3,kp)
                if( ar0 .ge. spphbo(4,kp) .and. &
                    ar0 .le. spphbo(5,kp) ) then
                  ax = spppbo(1,kp) + ar0 * spppro(1,kp)
                  ay = spppbo(2,kp) + ar0 * spppro(2,kp)
                  az = spppbo(3,kp) + ar0 * spppro(3,kp)
                  ar = sqrt( (ax-axp)**2 + (ay-ayp)**2 + (az-azp)**2 )
                  if( atan2(ar,ar0) .le. spppbo(6,kp) ) then
                    aden = spppns(kp)
                  end if
                end if
               case( 5, 6, 7 )
                aden = 0.0d0
                if( int(spppro(1,kp)) .eq. 1 ) then
                  ax = axp - spppbo(4,kp)
                  ar0 = - ax / ( spppbo(4,kp) - spppbo(1,kp) )
                else
                  ax = axp - spppbo(1,kp)
                  ar0 = ax / ( spppbo(4,kp) - spppbo(1,kp) )
                end if
                ay = ayp - ( spppbo(2,kp) + spppbo(5,kp) ) * s1o2
                az = azp - ( spppbo(3,kp) + spppbo(6,kp) ) * s1o2
!
                if( iwsh .eq. 5 .or. iwsh .eq. 7 ) then
                  if( abs(ay) .le. &
                     ( (spppbo(5,kp)-spppbo(2,kp))*s1o2 ) * ar0 .and. &
                      abs(az) .le. &
                     ( (spppbo(6,kp)-spppbo(3,kp))*s1o2 ) * ar0 ) then
                    aden = spppns(kp)
                  end if
                  if( iwsh .eq. 7 ) then
                    if( abs(ax) .lt. spppro(2,kp) ) aden = 0.0d0
                  end if
                else
                  if( int(spppro(2,kp)) .eq. 2 ) then
                    if( abs(az) .le. &
                        ((spppbo(6,kp)-spppbo(3,kp))*s1o2) * ar0) then
                      aden = spppns(kp)
                    end if
                  else
                    if( abs(ay) .le. &
                        ((spppbo(5,kp)-spppbo(2,kp))*s1o2) * ar0) then
                      aden = spppns(kp)
                    end if
                  end if
                end if
               end select
!...
               if( aden .lt. apppnm ) cycle
!....
               call qstrtflt( lppsch, ix, aden*ffd, snepm1, knpme, &
                              fpdat1, kno, knox, kpc )
!----
               if( kpc .ne. -1 .and. kno .ne. ino0 ) then
                  if( lppsch .eq. 0 ) then
                     inpm = ( kno - ino0 ) / 2
                  else
                     inpm = kno - ino0
                  end if
!++++
                  if( inpm .gt. lqn ) then
                    write(0,*) '### ERROR: table overflow at qstrtpos'
                    call s3ext_abort
                  end if
!++++
                  ixx = fpdat1(ino0+1)%x
!++++
                  if( ixx .ne. floor(fpdat1(kno)%x) ) then
                    write(0,*) '### ERROR: ix mismatch at qstrtpos',ino0, kno
                    call s3ext_abort
                  end if
!++++
                  if( lppsch .eq. 0 ) then
                    do i = 1, inpm
                      is = ino0 + i * 2
                      wy(i) = iy + ( fpdat1(is)%x - ixx )
                      wz(i) = iz + ( fpdat1(is)%x - ixx )
                    end do
                  else
                    do i = 1, inpm
                      is = ino0 + i
                      wy(i) = iy + ( fpdat1(is)%x - ixx )
                      wz(i) = iz + ( fpdat1(is)%x - ixx )
                    end do
                  end if
                  if( inpm .ge. 2 ) then
                    call mt_drand3 ( wran, inpm )
                    call qssortr ( wran, wy, inpm )
                    call mt_drand3 ( wran, inpm )
                    call qssortr ( wran, wz, inpm )
                  end if
                  if( lppsch .eq. 0 ) then
                    do i = 1, inpm
                      is = ino0 + i * 2
                      fpdat1(is-1)%y = wy(i)
                      fpdat1(is  )%y = wy(i)
                      fpdat1(is-1)%z = wz(i)
                      fpdat1(is  )%z = wz(i)
                    end do
                  else
                    do i = 1, inpm
                      is = ino0 + i
                      fpdat1(is  )%y = wy(i)
                      fpdat1(is  )%z = wz(i)
                    end do
                  end if
                  do i = ino0+1, kno
                    fpdat1(i)%pf = fpdat1(i)%pf * ffp
                  end do
               end if
!----
            end do 
         end do
      end do
!....
      call fdebug ( 'qstrtpos', 1 )
!....
      return
      end
