!-----------------------------------------------------------------------
! Compute 3D Field current(J) Total
!
      subroutine c3fjt
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/11
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "findexoh.macro"
#include "pindexoh.macro"
      use oh_param
#endif
      use parameter
      use field
      use particle
      use constant
      include "implicit.h"
      integer :: ix, iy, iz, io
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
      call fdebug ( 'c3fjt', 0 )
!....
#ifdef OHHELP
      do ips = 1, 2
      oh_sjxyzt(:,:,:,:,ips) = s0o1
      if( oh_sdid(ips) .lt. 0 ) cycle 
#endif
!$OMP PARALLEL PRIVATE(ix,iy,io)
      if( lnoe .gt. 0 ) then
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              sjxt(ix,iy,iz) = sjxe(ix,iy,iz)
            end do
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              sjyt(ix,iy,iz) = sjye(ix,iy,iz)
            end do
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              sjzt(ix,iy,iz) = sjze(ix,iy,iz)
            end do
          end do
        end do
      end if
!..
      do io = 1, lionspl
        if( lionidl(io) .le. 0 ) cycle
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              sjxt(ix,iy,iz) = sjxt(ix,iy,iz) + sjxi(ix,iy,iz,io)
            end do
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              sjyt(ix,iy,iz) = sjyt(ix,iy,iz) + sjyi(ix,iy,iz,io)
            end do
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              sjzt(ix,iy,iz) = sjzt(ix,iy,iz) + sjzi(ix,iy,iz,io)
            end do
          end do
        end do
      end do
!...
!$OMP END PARALLEL
#ifdef OHHELP
      end do
#endif
!....
      call fdebug ( 'c3fjt', 1 )
!....
      return
      end
