!----------------------------------------------------------------------
! Observe 3D Field Density Ion
!                          /
      subroutine o3fdi ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 25, ifn = 6
      integer :: kflag, i, io, iofdi, ilog, iso, i3d, icrxy, icryz, &
                 icrxz, ix, iy, iz, ixyz, iwdia
      real*8  :: woisov(loisox)
      real*8, allocatable :: wdia(:,:)
      character*20 clabel
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o3fdi', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
        if( lcfdi .eq. 0 ) call c3fdi
#ifdef OHHELP
        if( loxyzpl .gt. 0 ) then
#endif
        iwdia = iwdia + 1
        do io = 1, lionspl
          ixyz = 0
          do iz = lozps, lozpe, lozpi
            do iy = loyps, loype, loypi
              do ix = loxps, loxpe, loxpi
                ixyz = ixyz + 1
                wdia(ixyz,io) = wdia(ixyz,io) + sdi(ix,iy,iz,io)
              end do
            end do
          end do
        end do
#ifdef OHHELP
        end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do io = 1, lionspl
               do i = 1, loxyzpl
                  wdia(i,io) = wdia(i,io) / ( iwdia * snepm1 )
               end do
            end do
            if( iofdi .le. 4 ) then
               write(iun) sstcur,((wdia(i,io),i=1,loxyzpl),io=1,lionspl)
               flush(iun)
            end if
            if( iofdi .ge. 2 ) then
               do io = 1, lionspl
                 call o3ionlabel ( io, sionam(io), sionaz(io), clabel )
                 do i = 1, iso
                   woisov(i) = soisov(i) / sionaz(io)
                   if( ilog .ge. 1 ) woisov(i) = log10( woisov(i) )
                 end do
                 call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                   ifn, ilog, i3d, iso, 3, &
                   icrxy,sozcrs, icryz,soxcrs, icrxz,soycrs, woisov, &
                   wdia(1,io), loxpl, loypl, lozpl, sosltd, loslnu, &
                   soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                   'fdi'//clabel )
               end do
            end if
          end if
         else
!....
           if( loxyzpl .gt. 0 ) then
             if( .not. allocated(wdia) ) allocate( wdia(loxyzpl,lionspl) )
           end if
!....
           iofdi = mod( lofdi, 10 )
           ilog  = mod( lofdi/10, 10 )
           i3d   = mod( lofdi/100, 10 )
           iso   = i3d / 2
           i3d   = mod( i3d, 2 )
           icrxy = mod( lofdi/1000, 10 )
           icryz = mod( lofdi/10000, 10 )
           icrxz = mod( lofdi/100000, 10 )
!.
           if( iofdi .ge. 2 ) then
             if( iso+i3d+icrxy+icryz+icrxz .eq. 0 ) then
               write(0,*) '### ERROR: no plot for fdi', &
                           iso, i3d, icrxy, icryz, icrxz
               call s3ext_abort
             end if
             if( iso .gt. loisox ) then
               write(0,*) '### ERROR: iso is greater than loisox.',lofdi
               call s3ext_abort
             end if
           end if
!...
           if( iofdi .le. 4 ) then
              call fntpcnv ( bbifntp, lrank,iun, bident,'fdi', bfile )
              open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
              write(iun) 'fdi4', bident, loxyzpl, loxpl, loypl, lozpl, &
                       soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                        lionspl, (sionam(io),sionaz(io),io=1,lionspl)
#else
              write(iun) 'fdi5', bident, loxyzpl, loxpl, loypl, lozpl, &
                       soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                        lionspl, (sionam(io),sionaz(io),io=1,lionspl), &
                                           lrank, ldivx, ldivy, ldivz, &
                                         oh_loxal, oh_loxas, oh_loxae, &
                                         oh_loyal, oh_loyas, oh_loyae, &
                                         oh_lozal, oh_lozas, oh_lozae
#endif
              flush(iun)
           end if
           if( iofdi .ge. 2 ) then
              call fntpcnv ( bfrfntp, lrank,ifn, bident,'fdi', bfile )
              call frames_file ( bfile, ifn, iofdi )
           end if
         end if
         if( loxyzpl .gt. 0 ) then
           iwdia = 0
           do io = 1, lionspl
             do i = 1, loxyzpl
               wdia(i,io) = s0o1
             end do
           end do
         end if
      end if
!....
      call fdebug ( 'o3fdi', 1 )
!....
      return
      end
