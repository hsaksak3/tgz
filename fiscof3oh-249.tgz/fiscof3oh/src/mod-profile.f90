!----------------------------------------------------------------------
! plasma profile
!
module profile
      use parameter
      integer :: &
         lpprof, lxp0, lyp0, lzp0, lxps, lxpe, lyps, lype, lzps, lzpe, &
         lpppl, lpppis(lpppx), lpppty(lpppx), &
         lpphl, lppphf(lpppx), lpphty(lpphx)
      real*8 :: &
         spppbo(6,lpppx), &
         spppro(3,lpppx), sppprs(lpppx), spppre(lpppx), &
         spppns(lpppx), spppne(lpppx), spppsc(lpppx), &
         spphbo(6,lpphx), spphav(3,lpphx), &
         spppudxe(lpppx), spppudye(lpppx), spppudze(lpppx), &
         spppudxi(lpppx), spppudyi(lpppx), spppudzi(lpppx), &
         spppte(lpppx), spppti(lpppx)
      character :: bprffn*64
end module profile
