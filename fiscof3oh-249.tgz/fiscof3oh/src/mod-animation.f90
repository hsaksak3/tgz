!----------------------------------------------------------------------
! animation
!
module animation
      use parameter
      integer :: &
         latnxt, lagfl, lavpl, labol, labon(lawnx,lagfx), &
         lamode(lagfx), lagifw(lagfx), lagifh(lagfx), &
         lagifv(lavpx,lagfx), lavpc(lavpx,lagfx), &
         lapepxyl, lapepxy(3), lapepxygt(3), &
         lapepyzl, lapepyz(3), lapepyzgt(3), &
         lapepxzl, lapepxz(3), lapepxzgt(3)
      real*8 :: &
         satstr, satend, satint, satnxt, &
         savpxm(lavpx), savpxx(lavpx), savpym(lavpx), savpyx(lavpx), &
         saboxm(labox), saboxx(labox), saboym(labox), saboyx(labox), &
         sabozm(labox), sabozx(labox), &
         sawnxm(lawnx), sawnxx(lawnx), sawnym(lawnx), &
         sawnyx(lawnx), sawnzm(lawnx), sawnzx(lawnx), &
         sawnx0(lawnx), sawny0(lawnx), sawnz0(lawnx)
      character ::  banfntp(lagfx)*64
end module animation
