!----------------------------------------------------------------------
! Observe 3D Field magnetic(B) Raw
!                          /
      subroutine o3fbr ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 10/05/19
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 30, ifn = 11
      integer :: kflag, i, iofbr, incl, i3d, icrxy, icryz, icrxz, &
      			 ix, iy, iz, ixyz, iwbra, inst
      real*8, allocatable :: wbxa(:), wbya(:), wbza(:), &
                             wbxi(:), wbyi(:), wbzi(:)
      character(4) :: chead
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o3fbr', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
        iwbra = iwbra + 1
        ixyz = 0
        do iz = lozps, lozpe, lozpi
          do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
              ixyz = ixyz + 1
              wbxa(ixyz) = wbxa(ixyz) + &
                    ( sbx(ix,iy+1,iz  ) + sbx(ix,iy,iz  ) + &
                      sbx(ix,iy+1,iz+1) + sbx(ix,iy,iz+1) )*s1o4
              wbya(ixyz) = wbya(ixyz) + &
                    ( sby(ix+1,iy,iz  ) + sby(ix,iy,iz  ) + &
                      sby(ix+1,iy,iz+1) + sby(ix,iy,iz+1) )*s1o4
              wbza(ixyz) = wbza(ixyz) + &
                    ( sbz(ix+1,iy  ,iz) + sbz(ix,iy  ,iz) + &
                      sbz(ix+1,iy+1,iz) + sbz(ix,iy+1,iz) )*s1o4
              if( incl .ne. 0 ) then
                 wbxa(ixyz) = wbxa(ixyz) + sextbx
                 wbya(ixyz) = wbya(ixyz) + sextby
                 wbza(ixyz) = wbza(ixyz) + sextbz
              end if
            end do
          end do
        end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do i = 1, loxyzpl
               wbxa(i) = wbxa(i) / iwbra * scofb
               wbya(i) = wbya(i) / iwbra * scofb
               wbza(i) = wbza(i) / iwbra * scofb
            end do
!
            if( inst .ne. 0 ) then
              ixyz = 0
              do iz = lozps, lozpe, lozpi
                do iy = loyps, loype, loypi
                  do ix = loxps, loxpe, loxpi
                    ixyz = ixyz + 1
                    wbxi(ixyz) = &
                    ( sbx(ix,iy+1,iz  ) + sbx(ix,iy,iz  ) + &
                      sbx(ix,iy+1,iz+1) + sbx(ix,iy,iz+1) )*s1o4 * scofb
                    wbyi(ixyz) = &
                    ( sby(ix+1,iy,iz  ) + sby(ix,iy,iz  ) + &
                      sby(ix+1,iy,iz+1) + sby(ix,iy,iz+1) )*s1o4 * scofb
                    wbzi(ixyz) = &
                    ( sbz(ix+1,iy  ,iz) + sbz(ix,iy  ,iz) + &
                      sbz(ix+1,iy+1,iz) + sbz(ix,iy+1,iz) )*s1o4 * scofb
                    if( incl .ne. 0 ) then
                       wbxi(ixyz) = wbxi(ixyz) + sextbx * scofb 
                       wbyi(ixyz) = wbyi(ixyz) + sextby * scofb 
                       wbzi(ixyz) = wbzi(ixyz) + sextbz * scofb 
                    end if
                  end do
                end do
              end do
            end if
!
            if( iofbr .le. 4 ) then
              if( inst .eq. 0 ) then
                write(iun) sstcur, (wbxa(i),wbya(i),wbza(i),i=1,loxyzpl)
              else
                write(iun)sstcur,(wbxa(i),wbya(i),wbza(i),i=1,loxyzpl),&
                                 (wbxi(i),wbyi(i),wbzi(i),i=1,loxyzpl)
              end if
              flush(iun)
            end if
            if( iofbr .ge. 2 ) then
               call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wbxa,wbya,wbza, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fbxr[MG]', 'fbyr[MG]', 'fbzr[MG]' )
               if( inst .ne. 0 ) &
                 call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wbxi,wbyi,wbzi, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
              'fbxr(inst.)[MG]', 'fbyr(inst.)[MG]', 'fbzr(inst.)[MG]' )
            end if
          end if
         else
!....
            iofbr = mod( lofbr, 10 )
            incl  = mod( lofbr/10, 10 )
            i3d   = mod( lofbr/100, 10 )
            icrxy = mod( lofbr/1000, 10 )
            icryz = mod( lofbr/10000, 10 )
            icrxz = mod( lofbr/100000, 10 )
            inst  = lofbr / 1000000
!.
            if( iofbr .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fbr', & 
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
              if( .not. allocated(wbxa) ) &
                allocate( wbxa(loxyzpl), wbya(loxyzpl), wbza(loxyzpl) )
              if( inst .ne. 0 ) then
                if( .not. allocated(wbxi) ) &
                allocate( wbxi(loxyzpl), wbyi(loxyzpl), wbzi(loxyzpl) )
              end if
            end if
!....
            if( iofbr .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fbr', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
               chead = 'fbr4'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
               chead = 'fbr5'
               if( inst .ne. 0 ) chead(3:3) = 'R'
               write(iun) chead, bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                          lrank, ldivx, ldivy, ldivz, &
                                        oh_loxal, oh_loxas, oh_loxae, &
                                        oh_loyal, oh_loyas, oh_loyae, &
                                        oh_lozal, oh_lozas, oh_lozae
#endif
               flush(iun)
            end if
            if( iofbr .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fbr', bfile )
               call frames_file ( bfile, ifn, iofbr )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwbra = 0
            do i = 1, loxyzpl
               wbxa(i) = s0o1
               wbya(i) = s0o1
               wbza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fbr', 1 )
!....
      return
      end
