!!----------------------------------------------------------------------
! Set 3D EXTernal system PARAMeter
!                                /     /
      subroutine s3ext_param ( kflag, kps )
!
!   <arguments>
!     kflag : 1 = check & set electon position for transbound
!             2 = check & set ion position for transbound
!             3 = check & set p spec & subdomain for initial
!             4 = set nphgram from totalp
!     kps   : 0 = primary & secondary
!             1 = primary
!             2 = secondary
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!---------------------------------------------------------------------
#ifdef OHHELP
#include "spdat.macro"
#include "spdatoh.macro"
      use field
      use control
      use constant
      use particle
      use oh_param
      include "implicit.h"
      integer :: kflag, kps
      integer :: ips, i, io, pstr, pend, ix, iy, iz, ik
      integer :: m, oh3_map_particle_to_subdomain
      save
#endif
!....
      call fdebug ( 's3ext_param', 0 )
!....
#ifdef OHHELP
!...
      if( kps .eq. 0 ) then
        pstr = 1
        pend = 2
      else
        pstr = kps
        pend = kps
      end if
!....
      select case( kflag )
!...check & set electon position for transbound
      case( 1 )
        do ips = pstr, pend
          if( oh_sdid(ips) .lt. 0 ) cycle
          do i = oh_lnoes(ips), oh_lnoee(ips)
            if( sxe(i) .gt. oh_sdoms(1,1,oh_sdid(ips)+1) .and. &
                sxe(i) .lt. oh_sdoms(2,1,oh_sdid(ips)+1) .and. &
                sye(i) .gt. oh_sdoms(1,2,oh_sdid(ips)+1) .and. &
                sye(i) .lt. oh_sdoms(2,2,oh_sdid(ips)+1) .and. &
                sze(i) .gt. oh_sdoms(1,3,oh_sdid(ips)+1) .and. &
                sze(i) .lt. oh_sdoms(2,3,oh_sdid(ips)+1) &
                ) then
              cycle
            else
              m = oh3_map_particle_to_subdomain(sxe(i),sye(i),sze(i))
              if( lnide(i) .ne. m ) then
                oh_nphgram(lnide(i)+1,1,ips) = &
                                        oh_nphgram(lnide(i)+1,1,ips) - 1
                oh_nphgram(m+1,1,ips) = oh_nphgram(m+1,1,ips) + 1
                lnide(i) = m
              end if
            endif
          end do
        end do

!...check & set ion position for transbound
      case( 2 )
        do ips = pstr, pend
          do i = oh_lnois(ips), oh_lnoie(ips)
            if( sxi(i) .gt. oh_sdoms(1,1,oh_sdid(ips)+1) .and. &
                sxi(i) .lt. oh_sdoms(2,1,oh_sdid(ips)+1) .and. &
                syi(i) .gt. oh_sdoms(1,2,oh_sdid(ips)+1) .and. &
                syi(i) .lt. oh_sdoms(2,2,oh_sdid(ips)+1) .and. &
                szi(i) .gt. oh_sdoms(1,3,oh_sdid(ips)+1) .and. &
                szi(i) .lt. oh_sdoms(2,3,oh_sdid(ips)+1) &
                ) then
              cycle
            else
              m = oh3_map_particle_to_subdomain(sxi(i),syi(i),szi(i))
              if( lnidi(i) .ne. m ) then
                oh_nphgram(lnidi(i)+1,lspeci(i),ips) = &
                                oh_nphgram(lnidi(i)+1,lspeci(i),ips) - 1
                oh_nphgram(m+1,lspeci(i),ips) = &
                                oh_nphgram(m+1,lspeci(i),ips) + 1
                lnidi(i)= m
              end if
            endif
          end do
        end do
!...check & set particle spec & subdomain distribution for initial
      case( 3 )
        oh_nphgram = 0
        do ips = pstr, pend
          do i = oh_lnoes(ips), oh_lnoee(ips)
            lspece(i) = 1
            lnide(i)  = oh3_map_particle_to_subdomain(sxe(i),sye(i),sze(i))
         oh_nphgram(lnide(i)+1,1,ips) = oh_nphgram(lnide(i)+1,1,ips) + 1
          end do
          do io = 1, lionspl
            do i = oh_lionids(io,ips), oh_lionide(io,ips)
              lspeci(i) = io + 1
              lnidi(i)  = oh3_map_particle_to_subdomain(sxi(i),syi(i),szi(i))
              oh_nphgram(lnidi(i)+1,lspeci(i),ips) = &
                                oh_nphgram(lnidi(i)+1,lspeci(i),ips) + 1
            end do
          end do
        end do
!... make nphgram from totalp
      case( 4 )
        do ips = pstr, pend
          if( oh_sdid(ips) .lt. 0 ) cycle
          do io = 1, lionspl+1
            oh_nphgram(oh_sdid(ips)+1, io, ips) = oh_totalp(io,ips)
          end do
        end do
!...ERROR
      case default
         write(0,*) '### ERROR: invalid kflag in s3ext_param', kflag
         call s3ext_abort
      end select
#endif
!....
      call fdebug ( 's3ext_param', 1 )
!....
      return
      end
