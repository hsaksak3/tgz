!-------------------------------------------------------------------
! QSTaRT for VELocity with spherical random
!
      subroutine qstrtvrand ( fvx, fvy, fvz, kn )
!
!   <arguments>
!     fvx   :  o : array of x velocity
!     fvy   :  o : array of y velocity
!     fvz   :  o : array of z velocity
!     kn    : i  : size of array
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 10/07/17
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: kn, i
      real*8  :: fvx(kn), fvy(kn), fvz(kn), wran(2), wz, wfi
      save
!....
      do i = 1, kn
         call mt_drand3 ( wran, 2 )
         wz  = 2.0d0 * wran(1) - 1.0d0
         wfi = 2.0d0 * acos( -1.0d0 ) * wran(2)
         fvx(i) = sqrt( 1.0d0 - wz**2 ) * cos(wfi)
         fvy(i) = sqrt( 1.0d0 - wz**2 ) * sin(wfi)
         fvz(i) = wz
      end do
!....
      return
      end
