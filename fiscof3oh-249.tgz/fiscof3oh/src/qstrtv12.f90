!-------------------------------------------------------------------
! QSTaRT for VELocity with dodecahedron
!
      subroutine qstrtv12 ( fvx, fvy, fvz )
!
!   <arguments>
!     fvx   :  o : array of x velocity
!     fvy   :  o : array of y velocity
!     fvz   :  o : array of z velocity
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. ( NIFS ) 10/07/17
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: iran(120), init=0, i
      real*8  :: fvx(12), fvy(12), fvz(12)
      real*8  :: wxx(12), wyy(12), wzz(12), wran(12), &
                 ax, az, w11, w12, w13, w21, w22, w23, w31, w32, w33, &
                 wfi, wnx, wny, wnz, wof, wot, wph, &
                 wx1, wx2, wy1, wy2, wz, wz1, wz2
      save
!....
      if( init .eq. 0 ) then
         ax = sqrt( ( 1.0d0 - (1.0d0/sqrt(5.0d0)) ) / 2.0d0 )
         az = sqrt( ( 1.0d0 + (1.0d0/sqrt(5.0d0)) ) / 2.0d0 )
         wxx(1) = -ax
         wyy(1) = 0.0d0
         wzz(1) =  az
         wxx(2) =  ax
         wyy(2) = 0.0d0
         wzz(2) =  az
         wxx(3) = -ax
         wyy(3) = 0.0d0
         wzz(3) = -az
         wxx(4) =  ax
         wyy(4) = 0.0d0
         wzz(4) = -az
         wxx(5) = 0.0d0
         wyy(5) =  az
         wzz(5) =  ax
         wxx(6) = 0.0d0
         wyy(6) =  az
         wzz(6) = -ax
         wxx(7) = 0.0d0
         wyy(7) = -az
         wzz(7) =  ax
         wxx(8) = 0.0d0
         wyy(8) = -az
         wzz(8) = -ax
         wxx(9) =  az
         wyy(9) =  ax
         wzz(9) = 0.0d0
         wxx(10) = -az
         wyy(10) =  ax
         wzz(10) = 0.0d0
         wxx(11) =  az
         wyy(11) = -ax
         wzz(11) = 0.0d0
         wxx(12) = -az
         wyy(12) = -ax
         wzz(12) = 0.0d0
         init = 1
      end if
!....
      do i = 1, 12
         iran(i) = i
      end do
      call mt_drand3 ( wran, 12 )
      call qssorti ( wran, iran, 12 )
!..
      call mt_drand3 ( wran, 5 )
      wot = 2.0d0 * acos( sqrt( 1.0d0 - wran(1) ) )
      wof = 2.0d0 * acos( -1.0d0 ) * wran(2)
      wz = 2.0d0 * wran(3) - 1.0d0
      wfi = 2.0d0 * acos( -1.0d0 ) * wran(4)
      wnx = sqrt( 1.0d0 - wz**2 ) * cos(wfi)
      wny = sqrt( 1.0d0 - wz**2 ) * sin(wfi)
      wnz = wz
      wph = 2.0d0 * acos( -1.0d0 ) * wran(5)
      w11 = wnx * wnx * ( 1.0d0 - cos(wph) ) + cos(wph)
      w12 = wnx * wny * ( 1.0d0 - cos(wph) ) - wnz * sin(wph)
      w13 = wnx * wnz * ( 1.0d0 - cos(wph) ) + wny * sin(wph)
      w21 = wny * wnx * ( 1.0d0 - cos(wph) ) + wnz * sin(wph)
      w22 = wny * wny * ( 1.0d0 - cos(wph) ) + cos(wph)
      w23 = wny * wnz * ( 1.0d0 - cos(wph) ) - wnx * sin(wph)
      w31 = wnz * wnx * ( 1.0d0 - cos(wph) ) - wny * sin(wph)
      w32 = wnz * wny * ( 1.0d0 - cos(wph) ) + wnx * sin(wph)
      w33 = wnz * wnz * ( 1.0d0 - cos(wph) ) + cos(wph)
!...
      do i = 1, 12
!.                                               * random orientation *
         wx1 = cos(wot) * wxx(iran(i)) + sin(wot) * wzz(iran(i))
         wy1 = wyy(iran(i))
         wz1 = -sin(wot) * wxx(iran(i)) + cos(wot) * wzz(iran(i))
         wx2 = cos(wof) * wx1 - sin(wof) * wy1
         wy2 = sin(wof) * wx1 + cos(wof) * wy1
         wz2 = wz1
!.                                            * rotate arbitrary axis *
         fvx(i) =  w11 * wx2 + w12 * wy2 + w13 * wz2
         fvy(i) =  w21 * wx2 + w22 * wy2 + w23 * wz2
         fvz(i) =  w31 * wx2 + w32 * wy2 + w33 * wz2
      end do
!....
      return
      end
