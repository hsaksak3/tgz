!----------------------------------------------------------------------
! Set 3D EXTernal system BEGINning
!
      subroutine s3ext_begin
!
!   <arguments>
!     none
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 16/10/04
!----------------------------------------------------------------------
#ifdef OHHELP
       use parameter
       include "implicit.h"
       include "mpif.h"
       integer :: impierr
#include "../ohhelp/oh_config.h"
#endif
!....
      call fdebug ( 's3ext_begin', 0 )
!....
#ifdef OHHELP
      if( OH_DIMENSION .ne. 3 ) then
         write(0,*) '### ERROR: OH_DIMENSION must be defined with 3', &
                    OH_DIMENSION
         stop 88888
      end if
       call MPI_INIT ( impierr )
       if( impierr .ne. 0 ) then
          write(0,*) '### ERROR: MPI_INIT, impierr =', impierr
          stop 88888
       end if
       call MPI_COMM_SIZE ( MPI_COMM_WORLD, lsize, impierr )
       if( impierr .ne. 0 ) then
          write(0,*) '### ERROR: MPI_COMM_SIZE, impierr =', impierr
          call s3ext_abort
       end if
       call MPI_COMM_RANK ( MPI_COMM_WORLD, lrank, impierr )
       if( impierr .ne. 0 ) then
          write(0,*) '### ERROR: MPI_COMM_RANK, impierr =', impierr
          call s3ext_abort
       end if
#endif
!....
      call fdebug ( 's3ext_begin', 1 )
!....
      return
      end
