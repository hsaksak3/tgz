!----------------------------------------------------------------------
! particle
!
module particle
      use parameter
      use ptcltype
      integer :: &
         lnoe, lnoes, lnoee, lnoi, lnois, lnoie, &
         lionids(lionspx), lionide(lionspx), lionidl(lionspx)
      real*8 :: &
         spfen, spfex, spnoe, &
         spfin(lionspx), spfix(lionspx), spnoi(lionspx), &
         sionaf(lionspx), sionaz(lionspx), &
         sionam(lionspx), sionqm(lionspx), sionmm(lionspx), &
         spnoit
      type(ty1_particle), allocatable, save :: &
         spdat1(:)
      type(ty2_particle), allocatable, save :: &
         spdat2(:)
end module particle
