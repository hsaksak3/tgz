!----------------------------------------------------------------------
! Fast Particle parameters
!
      module fpprm
      use parameter
      integer :: &
         lopfeed, lopfeeda, lopfeedc, lopfeedty(lopfeedx), &
         lopfeedrl, lopfeedml, lopfeednl, lopfeeddl(2,lopfeedx), &
         lopfied, lopfieda, lopfiedc, lopfiedty(lopfiedx), &
         lopfiedrl, lopfiedml, lopfiednl, lopfieddl(2,lopfiedx)
      real*8 :: &
         sopfeedpo(5,lopfeedx), sopfeedr, sopfeedm, &
         sopfiedpo(5,lopfiedx), sopfiedr(lionspx), sopfiedm(lionspx)
      character :: bfpfntpe*64, bfpfntpi*64
end module fpprm
