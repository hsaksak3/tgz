!----------------------------------------------------------------------
! debug
!
module debug
#ifndef OHHELP
      integer, parameter :: lsubx = 32
#else
      integer, parameter :: lsubx = 35
#endif
      integer :: ldebug, lsubcn(lsubx)
      real*8 ::  dtotst, dsubst(lsubx), dsubsm(lsubx)
      character :: bsubnm(lsubx)*8
end module debug
