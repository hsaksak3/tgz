!-----------------------------------------------------------------------
! Boundary condition 3D Particle Ion Position
!                          /
      subroutine b3pip ( kmode )
!
!   <arguments>
!     kmode : mode = 1 : for periodic condition
!                  = 2 : for perfect reflection
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/11
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "pindexoh.macro"
      use oh_param
#endif
      use ieee_arithmetic
      use constant
      use control
      use particle
      include "implicit.h"
      integer :: i, ii, kmode
#ifdef OHHELP
      integer :: ips
#endif
      save
!....
!perio weps is needed. Run following program !!
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx
!peri stop
!peri end
!perio weps problem was solved by ieee_set_rounding_mode(ieee_down)
!peri Run following program !!
!peri use :: ieee_arithmetic
!peri call ieee_set_rounding_mode(ieee_down)
!peri x = 0.9999999
!peri ix = x
!peri xx = x + 1023
!peri ixx = xx
!peri write(*,*) x, ix, xx, ixx 
!peri stop
!peri end
!....
      call fdebug( 'b3pip', 0 )
!....
      call ieee_set_rounding_mode(ieee_down)
!....
#ifdef OHHELP
      do ips = 1, 2
      if( oh_lnoi(ips) .le. 0 ) cycle 
#endif
!$OMP PARALLEL DO SCHEDULE(STATIC) PRIVATE(ii)
      do i = lnois, lnoie
        if( lexlpi .eq. kmode ) then
          ii = sxi(i)
          if( ii .lt. 1 ) then
            select case( lexlpi )
            case( 1 )
               sxi(i) = sxi(i) + lssxm1
            case( 2 )
               sxi(i) = s2o1 - sxi(i)
               svxi(i) = - svxi(i)
               suxi(i) = - suxi(i)
            end select
          end if
        end if
!.
        if( lexupi .eq. kmode ) then
          ii = sxi(i)
          if ( ii .gt. lssxm1 ) then
            select case( lexupi )
            case( 1 )
               sxi(i) = sxi(i) - lssxm1
            case( 2 )
               sxi(i) = s2o1 * lssx - sxi(i)
               svxi(i) = - svxi(i)
               suxi(i) = - suxi(i)
            end select
          end if
        end if
!..
        if( leylpi .eq. kmode ) then
          ii = syi(i)
          if( ii .lt. 1 ) then
            select case( leylpi )
            case( 1 )
               syi(i) = syi(i) + lssym1
            case( 2 )
               syi(i) = s2o1 - syi(i)
               svyi(i) = - svyi(i)
               suyi(i) = - suyi(i)
            end select
          end if
        end if
!.
        if( leyupi .eq. kmode ) then
          ii = syi(i)
          if ( ii .gt. lssym1 ) then
            select case( leyupi )
            case( 1 )
               syi(i) = syi(i) - lssym1
            case( 2 )
               syi(i) = s2o1 * lssy - syi(i)
               svyi(i) = - svyi(i)
               suyi(i) = - suyi(i)
            end select
          end if
        end if
!..
        if( lezlpi .eq. kmode ) then
          ii = szi(i)
          if( ii .lt. 1 ) then
            select case( lezlpi )
            case( 1 )
               szi(i) = szi(i) + lsszm1
            case( 2 )
               szi(i) = s2o1 - szi(i)
               svzi(i) = - svzi(i)
               suzi(i) = - suzi(i)
            end select
          end if
        end if
!.
        if( lezupi .eq. kmode ) then
          ii = szi(i)
          if ( ii .gt. lsszm1 ) then
            select case( lezupi )
            case( 1 )
               szi(i) = szi(i) - lsszm1
            case( 2 )
               szi(i) = s2o1 * lssz - szi(i)
               svzi(i) = - svzi(i)
               suzi(i) = - suzi(i)
            end select
          end if
        end if
      end do
#ifdef OHHELP
      if( kmode .eq. 1 ) call s3ext_param( 2, ips )
      end do
#endif
!....
      call ieee_set_rounding_mode(default_round_type)
!....
      call fdebug( 'b3pip', 1 )
!....
      return
      end
