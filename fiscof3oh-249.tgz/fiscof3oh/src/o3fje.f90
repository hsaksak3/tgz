!----------------------------------------------------------------------
! Observe 3D Field Current Electron
!                          /
      subroutine o3fje ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/12/03
!----------------------------------------------------------------------
#include "sfield.macro"
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use observe
      use particle
      include "implicit.h"
      integer, parameter :: iun = 31, ifn = 12
      integer :: kflag, i, iofje, i3d, icrxy, icryz, icrxz, &
                 ix, iy, iz, ixyz, iwjea
      real*8, allocatable :: wjxa(:), wjya(:), wjza(:)
#ifdef OHHELP
      integer :: ips
      real*8, allocatable :: oh_wfje(:,:,:,:,:)
#endif
      save
!....
      call fdebug ( 'o3fje', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         iwjea = iwjea + 1
#ifndef OHHELP
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wjxa(ixyz) = wjxa(ixyz) + &
                          ( sjxe(ix,iy,iz) + sjxe(ix+1,iy,iz) )*s1o2
               wjya(ixyz) = wjya(ixyz) + &
                          ( sjye(ix,iy,iz) + sjye(ix,iy+1,iz) )*s1o2
               wjza(ixyz) = wjza(ixyz) + &
                          ( sjze(ix,iy,iz) + sjze(ix,iy,iz+1) )*s1o2
             end do
           end do
         end do
#else
         if( oh_pevflag .ne. 0 ) then
           call c3pev
           oh_pevflag = 0
         end if
         oh_wfje(:,:,:,:,:) = s0o1
!.
         do ips = 1, 2
            if( oh_lnoe(ips) .le. 0 ) cycle
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
            oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wfje), &
!$OMP          PRIVATE(ix,iy,iz)
            do i = oh_lnoes(ips), oh_lnoee(ips)
               ix = sxe(i) - oh_ixs
               iy = sye(i) - oh_iys
               iz = sze(i) - oh_izs
               oh_wfje(1,ix,iy,iz,ips) = oh_wfje(1,ix,iy,iz,ips) - &
                                            svxe(i) * spfe(i) 
               oh_wfje(2,ix,iy,iz,ips) = oh_wfje(2,ix,iy,iz,ips) - &
                                            svye(i) * spfe(i) 
               oh_wfje(3,ix,iy,iz,ips) = oh_wfje(3,ix,iy,iz,ips) - &
                                            svze(i) * spfe(i) 
            end do
         end do
!.
         call oh3_reduce_field &
                      ( oh_wfje(1,1,1,1,1), oh_wfje(1,1,1,1,2), OJE )
!..
         if( loxyzpl .gt. 0 ) then
           ixyz = 0
           do iz = lozps, lozpe, lozpi
             do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                 ixyz = ixyz + 1 
                 wjxa(ixyz) = wjxa(ixyz) + oh_wfje(1,ix,iy,iz,1)
                 wjya(ixyz) = wjya(ixyz) + oh_wfje(2,ix,iy,iz,1)
                 wjza(ixyz) = wjza(ixyz) + oh_wfje(3,ix,iy,iz,1)
               end do
             end do
           end do
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
           if( loxyzpl .gt. 0 ) then
             do i = 1, loxyzpl
                wjxa(i) = wjxa(i) /  ( iwjea * snepm1 * scfl )
                wjya(i) = wjya(i) /  ( iwjea * snepm1 * scfl )
                wjza(i) = wjza(i) /  ( iwjea * snepm1 * scfl )
             end do
             if( iofje .le. 4 ) then
               write(iun) sstcur, (wjxa(i),wjya(i),wjza(i),i=1,loxyzpl)
               flush(iun)
             end if
             if( iofje .ge. 2 ) then
               call o3fdraw3 ( bident, sstcur, ifn, i3d, 2, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, &
                 wjxa,wjya,wjza, loxpl,loypl,lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fjxe', 'fjye', 'fjze' )
             end if
           end if
!....
         else
            iofje = mod( lofje, 10 )
            i3d   = mod( lofje/100, 10 )
            icrxy = mod( lofje/1000, 10 )
            icryz = mod( lofje/10000, 10 )
            icrxz = mod( lofje/100000, 10 )
!.
            if( iofje .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fje', & 
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
               if( .not. allocated(wjxa) ) &
                 allocate( wjxa(loxyzpl), wjya(loxyzpl), wjza(loxyzpl) )
            end if
#ifdef OHHELP
            if( .not. allocated(oh_wfje) ) allocate( &
              oh_wfje(3,oh_alosizes(1,1,OJE):oh_alosizes(2,1,OJE), &
                        oh_alosizes(1,2,OJE):oh_alosizes(2,2,OJE), &
                        oh_alosizes(1,3,OJE):oh_alosizes(2,3,OJE),2) )
#endif
!....
            if( iofje .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fje', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
               write(iun) 'fje4', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
               write(iun) 'fje5', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                          lrank, ldivx, ldivy, ldivz, &
                                        oh_loxal, oh_loxas, oh_loxae, &
                                        oh_loyal, oh_loyas, oh_loyae, &
                                        oh_lozal, oh_lozas, oh_lozae
#endif
               flush(iun)
            end if
            if( iofje .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fje', bfile )
               call frames_file ( bfile, ifn, iofje )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwjea = 0
            do i = 1, loxyzpl
               wjxa(i) = s0o1
               wjya(i) = s0o1
               wjza(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fje', 1 )
!....
      return
      end
