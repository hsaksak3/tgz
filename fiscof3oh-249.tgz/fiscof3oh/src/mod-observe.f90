!----------------------------------------------------------------------
! observe
!
module observe
      use parameter
      integer :: &
         lstcur, lstend, lotnxt, &
         loxps, loxpe, loxpi, loxpl, loxp0, &
         loyps, loype, loypi, loypl, loyp0, &
         lozps, lozpe, lozpi, lozpl, lozp0, &         
         loxyzpl, loslnu(3), &
         loeng, loenga, &
         lopee, lopie, lopem, lopim, &
         lofde, lofdea, lofdi, lofdia, lofdc, lofdca, &
         lofea, lofeaa, lofer, lofera, lofba, lofbaa, lofbr, lofbra, &
         lofje, lofjea, lofji, lofjia, lofjt, lofjta, &
         lofte, loftea, lofede, lofedi, lofek, lofew, lopeph
      real*8 :: &
         soxps, soxpe, soxmic, soxp0m, soyps, soype, soymic, soyp0m, &
         sozps, sozpe, sozmic, sozp0m, &
         sstcur, sstend, sotstr, sotend, sotint, sotnxt, &
         sozcrs(locrsx), soxcrs(locrsx), soycrs(locrsx), sosltd(3), &
         soisov(loisox), &
         sofekxps(lofekx), sofekxpe(lofekx), &
         sofekyps(lofekx), sofekype(lofekx), &
         sofekzps(lofekx), sofekzpe(lofekx), &
         sofekmax, &
         sofewxp(lofewx), sofewyp(lofewx), sofewzp(lofewx), &
         sopemxps(lopemx), sopemxpe(lopemx), &
         sopemyps(lopemx), sopemype(lopemx), &
         sopemzps(lopemx), sopemzpe(lopemx), sopemfct(lopemx), &
         sopeexps(lopeex), sopeexpe(lopeex), &
         sopeeyps(lopeex), sopeeype(lopeex), &
         sopeezps(lopeex), sopeezpe(lopeex), sopeefct(lopeex), &
         sopimxps(lopimx), sopimxpe(lopimx), &
         sopimyps(lopimx), sopimype(lopimx), &
         sopimzps(lopimx), sopimzpe(lopimx), sopimfct(lopimx,lionspx), &
         sopiexps(lopiex), sopiexpe(lopiex), &
         sopieyps(lopiex), sopieype(lopiex), &
         sopiezps(lopiex), sopiezpe(lopiex), sopiefct(lopiex,lionspx), &
         sopephxps(lopephx), sopephxpe(lopephx), &
         sopephyps(lopephx), sopephype(lopephx), &
         sopephzps(lopephx), sopephzpe(lopephx), &
         sopephuxm(lopephx), sopephuxx(lopephx), &
         sopephuym(lopephx), sopephuyx(lopephx), &
         sopephuzm(lopephx), sopephuzx(lopephx)
      character :: bbifntp*64, bfrfntp*64
end module observe
