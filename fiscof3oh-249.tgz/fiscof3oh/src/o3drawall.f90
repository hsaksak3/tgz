!----------------------------------------------------------------------
! Observe 3D Field DRAW type 1
      subroutine o3fdraw1 ( eident, fstcur, fminlog, kminlog, &
                 kfn, klog, k3d, kso, kcol, &
                 kcrxy, fozcrs, kcryz, foxcrs, kcrxz, foycrs, foisov, &
                 fdat, koxpl, koypl, kozpl, fosltd, koslnu, &
                 foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i, ioxyzl
      integer :: kfn, klog, k3d, kso, kcol, kcrxy, kcryz, kcrxz, &
                 koxpl, koypl, kozpl, kminlog, koslnu(3)
      real*8  :: wminlog
      real*8  :: fstcur, fminlog
      real*8  :: foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, &
                 fdat(koxpl*koypl*kozpl), fosltd(3), foisov(kso), &
                 fozcrs(kcrxy), foxcrs(kcryz), foycrs(kcrxz)
      character*(*) :: eident, ettl
      save
!....
      ioxyzl = koxpl*koypl*kozpl
!....
      if( klog .ge. 1 ) then
          wminlog = 0.0d0
          do i = 1, ioxyzl
             wminlog = max( wminlog, fdat(i) )
          end do
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          do i = 1, ioxyzl
             fdat(i) = log10( max( fdat(i), wminlog) )
          end do
       end if
!..
       if( k3d .ge. 1 ) then
          call frames_body31 ( eident, fstcur, kfn, kcol, & 
                       fdat, koxpl, koypl, kozpl, fosltd, koslnu, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
!..
       if( kcrxy .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdat, koxpl, koypl, kozpl, 1, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
       if( kcryz .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdat, koxpl, koypl, kozpl, 2, kcryz, foxcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
       if( kcrxz .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdat, koxpl, koypl, kozpl, 3, kcrxz, foycrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
!..
       if( kcrxy .ge. 1 .and. kcrxz .ge. 1 ) then
          call frames_body34 ( eident, fstcur, kfn, klog, & 
                       fdat, koxpl, koypl, kozpl, 1, &
                       kcrxz, foycrs, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
       if( kcrxy .ge. 1 .and. kcryz .ge. 1 ) then
          call frames_body34 ( eident, fstcur, kfn, klog, & 
                       fdat, koxpl, koypl, kozpl, 2, &
                       kcryz, foxcrs, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
       if( kcrxz .ge. 1 .and. kcryz .ge. 1 ) then
          call frames_body34 ( eident, fstcur, kfn, klog, & 
                       fdat, koxpl, koypl, kozpl, 3, &
                       kcryz, foxcrs, kcrxz, foycrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
       if( kso .ge. 1 ) then
          call frames_body33 ( eident, fstcur, kfn, & 
                       fdat, koxpl, koypl, kozpl, foisov, kso, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettl )
       end if
!....
       return
       end
!----------------------------------------------------------------------
! Observe 3D Field DRAW type 3
      subroutine o3fdraw3 ( eident, fstcur, kfn, k3d, kcol, &
                 kcrxy, fozcrs, kcryz, foxcrs, kcrxz, foycrs, &
                 fdax,fday,fdaz, koxpl,koypl,kozpl, fosltd, koslnu, &
                 foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, &
                 ettlx, ettly, ettlz )
!
!   <remarks>
!     none
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: kfn, k3d, kcol, kcrxy, kcryz, kcrxz, &
                 koxpl, koypl, kozpl, koslnu(3)
      real*8  :: fstcur
      real*8  :: foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, &
                 fdax(koxpl*koypl*kozpl), fday(koxpl*koypl*kozpl), &
                 fdaz(koxpl*koypl*kozpl), fosltd(3), &
                 fozcrs(kcrxy), foxcrs(kcryz), foycrs(kcrxz)
      character*(*) :: eident, ettlx, ettly, ettlz
      save
!....
       if( k3d .ge. 1 ) then
          call frames_body31 ( eident, fstcur, kfn, kcol, & 
                       fdax, koxpl, koypl, kozpl, fosltd, koslnu, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlx )
          call frames_body31 ( eident, fstcur, kfn, kcol, & 
                       fday, koxpl, koypl, kozpl, fosltd, koslnu, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettly )
          call frames_body31 ( eident, fstcur, kfn, kcol, & 
                       fdaz, koxpl, koypl, kozpl, fosltd, koslnu, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlz )
       end if
!..
       if( kcrxy .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdax, koxpl, koypl, kozpl, 1, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlx )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fday, koxpl, koypl, kozpl, 1, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettly )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdaz, koxpl, koypl, kozpl, 1, kcrxy, fozcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlz )
       end if
       if( kcryz .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdax, koxpl, koypl, kozpl, 2, kcryz, foxcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlx )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fday, koxpl, koypl, kozpl, 2, kcryz, foxcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettly )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdaz, koxpl, koypl, kozpl, 2, kcryz, foxcrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlz )
       end if
       if( kcrxz .ge. 1 ) then
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdax, koxpl, koypl, kozpl, 3, kcrxz, foycrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlx )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fday, koxpl, koypl, kozpl, 3, kcrxz, foycrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettly )
          call frames_body32 ( eident, fstcur, kfn, kcol, & 
                       fdaz, koxpl, koypl, kozpl, 3, kcrxz, foycrs, &
                foxmic, foxp0m, foymic, foyp0m, fozmic, fozp0m, ettlz )
       end if
!....
       return
       end
!----------------------------------------------------------------------
! Observe 3D Particle DRAW type 1
      subroutine o3pdraw1 ( eident, fstcur, fminlog, kminlog, &
                 kfn, klog, fdat, kdl, fct, fxs,fys,fzs,fxe,fye,fze, &
                 eaxx, eaxy, ettl )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i
      integer :: kminlog, kfn, klog, kdl
      real*8  :: wminlog
      real*8  :: fstcur, fminlog
      real*8  :: fdat(kdl), fct, fxs, fys, fzs, fxe, fye, fze
      character*(*) :: eident, eaxx, eaxy, ettl
      character*48 :: crange
      save
!....
      if( klog .ge. 1 ) then
          wminlog = 0.0d0
          do i = 1, kdl
             wminlog = max( wminlog, fdat(i) )
          end do
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          do i = 1, kdl
             fdat(i) = log10( max( fdat(i), wminlog) )
          end do
       end if
!..
       crange = 'range(-xx.x,-xx.x,-xx.x)(-xx.x,-xx.x,-xx.x)'
       write( crange(7:11),  '(f5.1)' ) fxs
       write( crange(13:17), '(f5.1)' ) fys
       write( crange(19:23), '(f5.1)' ) fzs
       write( crange(26:30), '(f5.1)' ) fxe
       write( crange(32:36), '(f5.1)' ) fye
       write( crange(38:42), '(f5.1)' ) fze
       call frames_body28 ( eident, fstcur, kfn, klog, fdat, kdl, fct, &
                            eaxx, eaxy, ettl, crange )
!....
       return
       end
!----------------------------------------------------------------------
! Observe 3D Particle DRAW type 6
!     subroutine o3pdraw6 ( eident, fstcur, fminlog, kminlog, &
!                kfn, klog, fdax, fday, fdaz, fdaxy, fdayz, fdaxz, &
!                kdl, fct, fxs, fys, fzs, fxe, fye, fze, &
!                eaxx, eaxy, eaxz, eaxn, ettl )
      subroutine o3pdraw6 ( eident, fstcur, fminlog, kminlog, &
                 kfn, klog, fdn, fdw1, fdw2, &
                 kdl, fct, fxs, fys, fzs, fxe, fye, fze, &
                 eaxx, eaxy, eaxz, eaxn, ettl )
!
!   <remarks>
! !   if klog = 1, fdax, fday, fdaz, fdaxy, fdayz, fdaxz are destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i, ii
      integer :: kminlog, kfn, klog, kdl
      real*8  :: wminlog, wxm, wxx, wym, wyx
      real*8  :: fstcur, fminlog
!     real*8  :: fdax(kdl), fday(kdl), fdaz(kdl), &
!                fdaxy(kdl,kdl), fdayz(kdl,kdl), fdaxz(kdl,kdl), &
!                fct, fxs, fys, fzs, fxe, fye, fze
      real(8) :: fdn(kdl,kdl,kdl), fdw1(kdl), fdw2(kdl,kdl), &
                 fct, fxs, fys, fzs, fxe, fye, fze
      character*(*) :: eident, eaxx, eaxy, eaxz, eaxn, ettl
      character*48 :: crange
      save
!....
       crange = 'range(-xx.x,-xx.x,-xx.x)(-xx.x,-xx.x,-xx.x)'
       write( crange(7:11),  '(f5.1)' ) fxs
       write( crange(13:17), '(f5.1)' ) fys
       write( crange(19:23), '(f5.1)' ) fzs
       write( crange(26:30), '(f5.1)' ) fxe
       write( crange(32:36), '(f5.1)' ) fye
       write( crange(38:42), '(f5.1)' ) fze
       wxx = kdl / ( 2.0d0 * fct )
       wxm = - wxx 
       wyx = kdl / ( 2.0d0 * fct )
       wym = - wyx 
!..
       do i = 1, kdl
          fdw1(i) = sum( fdn(i,:,:) )
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw1(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw1(:) = log10( max( fdw1(:), wminlog) )
       end if
       call frames_body24 ( eident, fstcur, kfn, klog, &
                        fdw1, kdl, fct, &
                        eaxx, eaxn, ettl, crange )
!
       do i = 1, kdl
          fdw1(i) = sum( fdn(:,i,:) )
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw1(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw1(:) = log10( max( fdw1(:), wminlog) )
       end if
       call frames_body24 ( eident, fstcur, kfn, klog, &
                        fdw1, kdl, fct, &
                        eaxy, eaxn, ettl, crange )
!
       do i = 1, kdl
          fdw1(i) = sum( fdn(:,:,i) )
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw1(:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw1(:) = log10( max( fdw1(:), wminlog) )
       end if
       call frames_body24 ( eident,fstcur, kfn, klog, &
                        fdw1, kdl, fct, &
                        eaxz, eaxn, ettl, crange )
!
       do ii = 1, kdl
       do i = 1, kdl
          fdw2(i,ii) = sum( fdn(i,ii,:) )
       end do
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw2(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw2(:,:) = log10( max( fdw2(:,:), wminlog) )
       end if
       call frames_body22 ( eident, fstcur, kfn, 3, 0, & 
                        fdw2, kdl,kdl, wxm, wxx, wym, wyx, &
                        eaxx, eaxy, ettl, crange )
!
       do ii = 1, kdl
       do i = 1, kdl
          fdw2(i,ii) = sum( fdn(:,i,ii) )
       end do
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw2(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw2(:,:) = log10( max( fdw2(:,:), wminlog) )
       end if
       call frames_body22 ( eident, fstcur, kfn, 3, 0, & 
                        fdw2, kdl,kdl, wxm, wxx, wym, wyx, &
                        eaxy, eaxz, ettl, crange )
!
       do ii = 1, kdl
       do i = 1, kdl
          fdw2(i,ii) = sum( fdn(i,:,ii) )
       end do
       end do
       if( klog .ge. 1 ) then
          wminlog = maxval( fdw2(:,:) )
          if( wminlog .le. 0.0d0 ) then
             wminlog = fminlog
          else
             wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
          end if
          fdw2(:,:) = log10( max( fdw2(:,:), wminlog) )
       end if
       call frames_body22 ( eident, fstcur, kfn, 3, 0, & 
                        fdw2, kdl,kdl, wxm, wxx, wym, wyx, &
                        eaxx, eaxz, ettl, crange )
!....
       return
       end
!----------------------------------------------------------------------
! Observe 3D Particle DRAW type PHase
      subroutine o3pdrawph ( eident, fstcur, fminlog, kminlog, &
                             kfn, klog, kcol, fdat, kxl, kul, &
                             fxs, fys, fzs, fxe, fye, fze, fus, fue, &
                             ettlx, ettly, ettll )
!
!   <remarks>
!     if klog = 1, fdat is destoried.
!
!----------------------------------------------------------------------
      include "implicit.h"
      integer :: i
      integer :: kfn, klog, kcol, kxl, kul, kminlog
      real*8  :: wminlog 
      real*8  :: fstcur, fminlog, fxs, fys, fzs, fxe, fye, fze, fus, fue
      real*8  :: fdat(kxl,kul)
      character :: crange*43
      character*(*) :: eident, ettlx, ettly, ettll
      save    
!....
      if( klog .ge. 1 ) then
         wminlog = maxval( fdat(:,:) )
         if( wminlog .le. 0.0d0 ) then
            wminlog = fminlog 
         else
            wminlog = 10.0d0**( floor(log10(wminlog))-kminlog )
         end if
         fdat(:,:) = log10( max( fdat(:,:), wminlog) )
      end if
!...
      crange = 'range(-xx.x,-xx.x,-xx.x)(-xx.x,-xx.x,-xx.x)'
      write( crange(7:11),  '(f5.1)' ) fxs
      write( crange(13:17), '(f5.1)' ) fys
      write( crange(19:23), '(f5.1)' ) fzs
      write( crange(26:30), '(f5.1)' ) fxe
      write( crange(32:36), '(f5.1)' ) fye
      write( crange(38:42), '(f5.1)' ) fze
      call frames_body22 ( eident, fstcur, kfn, kcol, -1, & 
                           fdat, kxl, kul, fxs, fxe, fus, fue, &
                           ettlx, ettly, ettll, crange )
!....
      return
      end
