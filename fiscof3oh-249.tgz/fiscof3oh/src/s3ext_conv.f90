!----------------------------------------------------------------------
! Set 3D EXTernal system parameter CONVert
!                               /
      subroutine s3ext_conv ( kflag )
!
!   <arguments>
!     kflag : mode 0 = set index data for init(pml edge)
!                 10 = set index data for init(no edge )
!                  1 = check & set neighbor infomation of subdomain
!                  2 = set field index data
!                  3 = set particle index data
!                 13 = set particle index data for zero clear
!                  4 = clear PML variables
#ifdef DEBUGW
!                  5 = broadcast PML variables
#endif
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 21/04/07
!---------------------------------------------------------------------
#ifdef OHHELP
#include "spdat.macro"
      use parameter
      use oh_param
      use pml
      use control
      use constant
#ifdef DEBUGW
      use observe
#endif
      include "implicit.h"
      integer :: kflag, iflag, imode, ips, io, ipn
#ifdef DEBUGW
      include "mpif.h"
      integer :: ipc, isc
      real*8  :: oh_b1xl(2,2), oh_b1xu(2,2), oh_b1yl(2,2), &
                 oh_b1yu(2,2), oh_b1zl(2,2), oh_b1zu(2,2)
#endif
      save
#endif
!....
      call fdebug ( 's3ext_conv', 0 )
!....
#ifdef OHHELP
!...
      iflag = mod(kflag,10)
      imode = kflag / 10
!...
      select case( iflag )
!... init
      case( 0 ) 
        ips = 1
!.
        lssxl = 1
        lssxu = oh_sdoms(2,1,oh_sdid(ips)+1)-&
                oh_sdoms(1,1,oh_sdid(ips)+1)+1
        lssyl = 1
        lssyu = oh_sdoms(2,2,oh_sdid(ips)+1)-&
                oh_sdoms(1,2,oh_sdid(ips)+1)+1
        lsszl = 1
        lsszu = oh_sdoms(2,3,oh_sdid(ips)+1)-&
                oh_sdoms(1,3,oh_sdid(ips)+1)+1
        lblxl = lssxl
        lblxu = lssxu
        lblyl = lssyl
        lblyu = lssyu
        lblzl = lsszl
        lblzu = lsszu
!.
        if( imode .eq. 0 ) then
          if( lbxluf .eq. 4 ) then
            lblxl = 3
            lssxl = lblxl + lpmlxl
            lssxu = lblxu - lpmlxu - 1
          end if
          if( lbyluf .eq. 4 ) then
            lblyl = 3
            lssyl = lblyl + lpmlyl
            lssyu = lblyu - lpmlyu - 1
          end if
          if( lbzluf .eq. 4 ) then
            lblzl = 3
            lsszl = lblzl + lpmlzl
            lsszu = lblzu - lpmlzu - 1
          end if
        end if
!.
        lssxlm1 = lssxl - 1
        lssxlm2 = lssxl - 2
        lssxlp1 = lssxl + 1
        lssxlp2 = lssxl + 2
        lssxlp3 = lssxl + 3
        lssxum1 = lssxu - 1
        lssxum2 = lssxu - 2
        lssxup1 = lssxu + 1
        lssxup2 = lssxu + 2
        lssxup3 = lssxu + 3
        
        lssylm1 = lssyl - 1
        lssylm2 = lssyl - 2
        lssylp1 = lssyl + 1
        lssylp2 = lssyl + 2
        lssylp3 = lssyl + 3
        lssyum1 = lssyu - 1
        lssyum2 = lssyu - 2
        lssyup1 = lssyu + 1
        lssyup2 = lssyu + 2
        lssyup3 = lssyu + 3
        
        lsszlm1 = lsszl - 1
        lsszlm2 = lsszl - 2
        lsszlp1 = lsszl + 1
        lsszlp2 = lsszl + 2
        lsszlp3 = lsszl + 3
        lsszum1 = lsszu - 1
        lsszum2 = lsszu - 2
        lsszup1 = lsszu + 1
        lsszup2 = lsszu + 2
        lsszup3 = lsszu + 3
!.
        lblxlm1 = lblxl - 1
        lblxup1 = lblxu + 1
        lblylm1 = lblyl - 1
        lblyup1 = lblyu + 1
        lblzlm1 = lblzl - 1
        lblzup1 = lblzu + 1

!...check & set neighbor infomation of subdomain
      case( 1 ) 
        do ips = 1, 2
          oh_lexuf(ips)  = 0
          oh_lexlf(ips)  = 0
          oh_leyuf(ips)  = 0
          oh_leylf(ips)  = 0
          oh_lezuf(ips)  = 0
          oh_lezlf(ips)  = 0
          oh_lexlpe(ips) = 0
          oh_lexupe(ips) = 0
          oh_leylpe(ips) = 0
          oh_leyupe(ips) = 0
          oh_lezlpe(ips) = 0
          oh_lezupe(ips) = 0
          oh_lexlpi(ips) = 0
          oh_lexupi(ips) = 0
          oh_leylpi(ips) = 0
          oh_leyupi(ips) = 0
          oh_lezlpi(ips) = 0
          oh_lezupi(ips) = 0
!.
          if( oh_sdid(ips) .lt. 0 ) cycle
!.
          if( oh_sdoms(1,1,oh_sdid(ips)+1) .eq. oh_scoord(1,1) ) then
            if( lexlf .ne. 1 ) oh_lexlf(ips) = lexlf
            oh_lexlpe(ips) = lexlpe
            oh_lexlpi(ips) = lexlpi
          end if
          if( oh_sdoms(2,1,oh_sdid(ips)+1) .eq. oh_scoord(2,1) ) then
            if( lexuf .ne. 1 ) oh_lexuf(ips) = lexuf
            oh_lexupe(ips) = lexupe
            oh_lexupi(ips) = lexupi
          end if
          if( oh_sdoms(1,2,oh_sdid(ips)+1) .eq. oh_scoord(1,2) ) then
            if( leylf .ne. 1 ) oh_leylf(ips) = leylf
            oh_leylpe(ips) = leylpe
            oh_leylpi(ips) = leylpi
          end if
          if( oh_sdoms(2,2,oh_sdid(ips)+1) .eq. oh_scoord(2,2) ) then
            if( leyuf .ne. 1 ) oh_leyuf(ips) = leyuf
            oh_leyupe(ips) = leyupe
            oh_leyupi(ips) = leyupi
          end if
          if( oh_sdoms(1,3,oh_sdid(ips)+1) .eq. oh_scoord(1,3) ) then
            if( lezlf .ne. 1 ) oh_lezlf(ips) = lezlf
            oh_lezlpe(ips) = lezlpe
            oh_lezlpi(ips) = lezlpi
          end if
          if( oh_sdoms(2,3,oh_sdid(ips)+1) .eq. oh_scoord(2,3) ) then
            if( lezuf .ne. 1 ) oh_lezuf(ips) = lezuf
            oh_lezupe(ips) = lezupe
            oh_lezupi(ips) = lezupi
          end if
        end do

!...set new field index data
      case( 2 ) 
       do ips = 1, 2
        if( oh_sdid(ips) .lt. 0 ) cycle
!.
        oh_lssxl(ips) = 1
        oh_lssxu(ips) = oh_sdoms(2,1,oh_sdid(ips)+1)-&
                        oh_sdoms(1,1,oh_sdid(ips)+1)+1
        oh_lssyl(ips) = 1
        oh_lssyu(ips) = oh_sdoms(2,2,oh_sdid(ips)+1)-&
                        oh_sdoms(1,2,oh_sdid(ips)+1)+1
        oh_lsszl(ips) = 1
        oh_lsszu(ips) = oh_sdoms(2,3,oh_sdid(ips)+1)-&
                        oh_sdoms(1,3,oh_sdid(ips)+1)+1
        oh_lblxl(ips) = oh_lssxl(ips)
        oh_lblxu(ips) = oh_lssxu(ips)
        oh_lblyl(ips) = oh_lssyl(ips)
        oh_lblyu(ips) = oh_lssyu(ips)
        oh_lblzl(ips) = oh_lsszl(ips)
        oh_lblzu(ips) = oh_lsszu(ips)
!.
        if( lbxluf .eq. 4 ) then
          if( oh_sdoms(1,1,oh_sdid(ips)+1) .eq. oh_scoord(1,1) ) then
            oh_lblxl(ips) = 3
            oh_lssxl(ips) = oh_lblxl(ips) + lpmlxl
          end if
          if( oh_sdoms(2,1,oh_sdid(ips)+1) .eq. oh_scoord(2,1) ) then
            oh_lssxu(ips) = oh_lblxu(ips) - lpmlxu - 1 
          end if
        end if
        if( lbyluf .eq. 4 ) then
          if( oh_sdoms(1,2,oh_sdid(ips)+1) .eq. oh_scoord(1,2) ) then
            oh_lblyl(ips) = 3
            oh_lssyl(ips) = oh_lblyl(ips) + lpmlyl
          end if
          if( oh_sdoms(2,2,oh_sdid(ips)+1) .eq. oh_scoord(2,2) ) then
            oh_lssyu(ips) = oh_lblyu(ips) - lpmlyu - 1
          end if
        end if
        if( lbzluf .eq. 4 ) then
          if( oh_sdoms(1,3,oh_sdid(ips)+1) .eq. oh_scoord(1,3) ) then
            oh_lblzl(ips) = 3
            oh_lsszl(ips) = oh_lblzl(ips) + lpmlzl
          end if
          if( oh_sdoms(2,3,oh_sdid(ips)+1) .eq. oh_scoord(2,3) ) then
            oh_lsszu(ips) = oh_lblzu(ips) - lpmlzu - 1
          end if
        end if
!.
        oh_lssxlm1(ips) = oh_lssxl(ips) - 1
        oh_lssxlm2(ips) = oh_lssxl(ips) - 2
        oh_lssxlp1(ips) = oh_lssxl(ips) + 1
        oh_lssxlp2(ips) = oh_lssxl(ips) + 2
        oh_lssxlp3(ips) = oh_lssxl(ips) + 3
        oh_lssxum1(ips) = oh_lssxu(ips) - 1
        oh_lssxum2(ips) = oh_lssxu(ips) - 2
        oh_lssxup1(ips) = oh_lssxu(ips) + 1
        oh_lssxup2(ips) = oh_lssxu(ips) + 2
        oh_lssxup3(ips) = oh_lssxu(ips) + 3
        
        oh_lssylm1(ips) = oh_lssyl(ips) - 1
        oh_lssylm2(ips) = oh_lssyl(ips) - 2
        oh_lssylp1(ips) = oh_lssyl(ips) + 1
        oh_lssylp2(ips) = oh_lssyl(ips) + 2
        oh_lssylp3(ips) = oh_lssyl(ips) + 3
        oh_lssyum1(ips) = oh_lssyu(ips) - 1
        oh_lssyum2(ips) = oh_lssyu(ips) - 2
        oh_lssyup1(ips) = oh_lssyu(ips) + 1
        oh_lssyup2(ips) = oh_lssyu(ips) + 2
        oh_lssyup3(ips) = oh_lssyu(ips) + 3
        
        oh_lsszlm1(ips) = oh_lsszl(ips) - 1
        oh_lsszlm2(ips) = oh_lsszl(ips) - 2
        oh_lsszlp1(ips) = oh_lsszl(ips) + 1
        oh_lsszlp2(ips) = oh_lsszl(ips) + 2
        oh_lsszlp3(ips) = oh_lsszl(ips) + 3
        oh_lsszum1(ips) = oh_lsszu(ips) - 1
        oh_lsszum2(ips) = oh_lsszu(ips) - 2
        oh_lsszup1(ips) = oh_lsszu(ips) + 1
        oh_lsszup2(ips) = oh_lsszu(ips) + 2
        oh_lsszup3(ips) = oh_lsszu(ips) + 3
!.
        oh_lblxlm1(ips) = oh_lblxl(ips) - 1
        oh_lblxup1(ips) = oh_lblxu(ips) + 1
        oh_lblylm1(ips) = oh_lblyl(ips) - 1
        oh_lblyup1(ips) = oh_lblyu(ips) + 1
        oh_lblzlm1(ips) = oh_lblzl(ips) - 1
        oh_lblzup1(ips) = oh_lblzu(ips) + 1
      end do
!... set new particle index data
      case( 3 ) 
       do ips = 1, 2
!.
        if( oh_sdid(ips) .lt. 0 .or. imode .eq. 1 ) then
          oh_lnoe( ips) = 0
          oh_lnoes(ips) = 0
          oh_lnoee(ips) = -1
          oh_lnoi( ips) = 0
          oh_lnois(ips) = 0
          oh_lnoie(ips) = -1
          do io = 1, lionspl
            oh_lionidl(io,ips) = 0
            oh_lionids(io,ips) = 0
            oh_lionide(io,ips) = -1
          end do
          cycle
        end if
!.
        oh_lnoe(ips)  = oh_totalp(1,ips)
        oh_lnoes(ips) = oh_pbase(ips) + 1
        oh_lnoee(ips) = oh_pbase(ips) + oh_totalp(1,ips)
        oh_lnoi(ips)  = oh_pbase(ips+1) - oh_pbase(ips) - oh_lnoe(ips)
        oh_lnois(ips) = oh_pbase(ips) + oh_totalp(1,ips) + 1
        oh_lnoie(ips) = oh_pbase(ips+1)
        ipn = oh_pbase(ips)
!.
        do io = 1, lionspl
          ipn = ipn + oh_totalp(io,ips)
          oh_lionidl(io,ips) = oh_totalp(io+1,ips)
          oh_lionids(io,ips) = ipn + 1
          oh_lionide(io,ips) = ipn + oh_lionidl(io,ips)
        end do
      end do
!.
      oh_pevflag = 1
      oh_pivflag = 1
!... clear PML variables
      case( 4 ) 
!.
        do ips = 1, 2
          if( oh_sdid(ips) .lt. 0 ) cycle
          if( oh_lexlf(ips) .eq. 4 ) then
            oh_sebpmlxl(:,:,:,:,ips) = s0o1
          end if
          if( oh_lexuf(ips) .eq. 4 ) then
            oh_sebpmlxu(:,:,:,:,ips) = s0o1
          end if
!
          if( oh_leylf(ips) .eq. 4 ) then
            oh_sebpmlyl(:,:,:,:,ips) = s0o1
          end if
          if( oh_leyuf(ips) .eq. 4 ) then
            oh_sebpmlyu(:,:,:,:,ips) = s0o1
          end if
!
          if( oh_lezlf(ips) .eq. 4 ) then
            oh_sebpmlzl(:,:,:,:,ips) = s0o1
          end if
          if( oh_lezuf(ips) .eq. 4 ) then
            oh_sebpmlzu(:,:,:,:,ips) = s0o1
          end if
        end do
#ifdef DEBUGW
      case( 5 ) 
        write(6,*) 'oh1_broadcast', lstcur, oh_sdid
        oh_b1xl(:,1) = oh_sdid(1) + 100
        oh_b1xl(:,2) = -1
        oh_b1xu(:,1) = oh_sdid(1) + 200
        oh_b1xu(:,2) = -1
        oh_b1yl(:,1) = oh_sdid(1) + 300
        oh_b1yl(:,2) = -1
        oh_b1yu(:,1) = oh_sdid(1) + 400
        oh_b1yu(:,2) = -1
        oh_b1zl(:,1) = oh_sdid(1) + 500
        oh_b1zl(:,2) = -1
        oh_b1zu(:,1) = oh_sdid(1) + 600
        oh_b1zu(:,2) = -1
        ipc = 0
        isc = 0
        if( oh_lexlf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_lexlf(2) .eq. 4 ) isc = 2
        write(6,*) 'befxl', oh_b1xl
        call oh1_broadcast( oh_b1xl(1,1), oh_b1xl(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftxl', oh_b1xl
        ipc = 0
        isc = 0
        if( oh_lexuf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_lexuf(2) .eq. 4 ) isc = 2
        write(6,*) 'befxu', oh_b1xu
        call oh1_broadcast( oh_b1xu(1,1), oh_b1xu(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftxu', oh_b1xu
        ipc = 0
        isc = 0
        if( oh_leylf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_leylf(2) .eq. 4 ) isc = 2
        write(6,*) 'befyl', oh_b1yl
        call oh1_broadcast( oh_b1yl(1,1), oh_b1yl(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftyl', oh_b1yl
        ipc = 0
        isc = 0
        if( oh_leyuf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_leyuf(2) .eq. 4 ) isc = 2
        write(6,*) 'befyu', oh_b1yu
        call oh1_broadcast( oh_b1yu(1,1), oh_b1yu(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftyu', oh_b1yu
        ipc = 0
        isc = 0
        if( oh_lezlf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_lezlf(2) .eq. 4 ) isc = 2
        write(6,*) 'befzl', oh_b1zl
        call oh1_broadcast( oh_b1zl(1,1), oh_b1zl(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftzl', oh_b1zl
        ipc = 0
        isc = 0
        if( oh_lezuf(1) .eq. 4 ) ipc = 2
        if( oh_sdid(2) .ge. 0 .and. oh_lezuf(2) .eq. 4 ) isc = 2
        write(6,*) 'befzu', oh_b1zu
        call oh1_broadcast( oh_b1zu(1,1), oh_b1zu(1,2), ipc, isc, &
                            MPI_DOUBLE_PRECISION, MPI_DOUBLE_PRECISION )
        write(6,*) 'aftzu', oh_b1zu
#endif
      end select
#endif
!....
      call fdebug ( 's3ext_conv', 1 )
!....
      return
      end
