!----------------------------------------------------------------------
! Observe 3D Field magnetic(B) Amplitude
!                          /
      subroutine o3fba ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 09/04/16
!----------------------------------------------------------------------
#include "sfield.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use control
      use field
      use observe
      include "implicit.h"
      integer, parameter :: iun = 29, ifn = 10
      integer :: kflag, i, iofba, incl, i3d, icrxy, icryz, icrxz, &
                ix, iy, iz, ixyz, iwbaa
      real*8  :: wcofb2
      real*8, allocatable :: wbaa(:)
#ifdef OHHELP
      integer :: ips=1
#endif
      save      
!....
      call fdebug ( 'o3fba', 0 )
!....
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
        iwbaa = iwbaa + 1
        ixyz = 0
        do iz =lozps, lozpe, lozpi
          do iy = loyps, loype, loypi
            do ix = loxps, loxpe, loxpi
              ixyz = ixyz + 1
              if( incl .eq. 0 ) then
                wbaa(ixyz) = wbaa(ixyz) + sqrt( &
                ( ( sbx(ix,iy+1,iz  ) + sbx(ix,iy,iz  ) + &
                    sbx(ix,iy+1,iz+1) + sbx(ix,iy,iz+1) )*s1o4 )**2 + &
                ( ( sby(ix+1,iy,iz  ) + sby(ix,iy,iz  ) + &
                    sby(ix+1,iy,iz+1) + sby(ix,iy,iz+1) )*s1o4 )**2 + &
                ( ( sbz(ix+1,iy  ,iz) + sbz(ix,iy  ,iz) + &
                    sbz(ix+1,iy+1,iz) + sbz(ix,iy+1,iz) )*s1o4 )**2 ) 
              else
                wbaa(ixyz) = wbaa(ixyz) + sqrt( &
        ( ( sbx(ix,iy+1,iz  ) + sbx(ix,iy,iz  ) + &
            sbx(ix,iy+1,iz+1) + sbx(ix,iy,iz+1) )*s1o4 + sextbx)**2 + &
        ( ( sby(ix+1,iy,iz  ) + sby(ix,iy,iz  ) + &
            sby(ix+1,iy,iz+1) + sby(ix,iy,iz+1) )*s1o4 + sextby)**2 + &
        ( ( sbz(ix+1,iy,iz  ) + sbz(ix,iy,iz  ) + &
            sbz(ix+1,iy+1,iz) + sbz(ix,iy+1,iz) )*s1o4 + sextbz)**2 )
              end if
            end do
          end do
        end do
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
!unit       if( iwbaa .eq. 1 ) then
!unit          wcofb2 = scofb2h
!unit       else
!unit          wcofb2 = scofb2 / iwbaa
!unit       end if
            do i = 1, loxyzpl
!unit          wbaa(i) = wbaa(i) * wcofb2
               wbaa(i) = wbaa(i) / iwbaa * scofb
            end do
            if( iofba .le. 4 ) then
               write(iun) sstcur, ( wbaa(i),i=1,loxyzpl )
               flush(iun)
            end if
            if( iofba .ge. 2 ) then
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, 0, i3d, 0, 1, &
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wbaa, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fba[MG]' ) 
            end if
          end if
         else
!....
            iofba = mod( lofba, 10 )
            incl  = mod( lofba/10, 10 )
            i3d   = mod( lofba/100, 10 )
            icrxy = mod( lofba/1000, 10 )
            icryz = mod( lofba/10000, 10 )
            icrxz = mod( lofba/100000, 10 )
!.
            if( iofba .ge. 2 ) then
              if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
                write(0,*) '### ERROR: no plot for fba', &
                           i3d, icrxy, icryz, icrxz
                call s3ext_abort
              end if
            end if
!....
            if( loxyzpl .gt. 0 ) then
               if( .not. allocated(wbaa) ) allocate( wbaa(loxyzpl) )
            end if
!....
            if( iofba .le. 4 ) then
               call fntpcnv ( bbifntp, lrank,iun, bident,'fba', bfile )
               open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
               write(iun) 'fba4', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
               write(iun) 'fba5', bident, loxyzpl, loxpl,loypl,lozpl, &
                      soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                          lrank, ldivx, ldivy, ldivz, &
                                        oh_loxal, oh_loxas, oh_loxae, &
                                        oh_loyal, oh_loyas, oh_loyae, &
                                        oh_lozal, oh_lozas, oh_lozae
#endif
               flush(iun)
            end if
            if( iofba .ge. 2 ) then
               call fntpcnv ( bfrfntp, lrank,ifn, bident,'fba', bfile )
               call frames_file ( bfile, ifn, iofba )
            end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwbaa = 0
            do i = 1, loxyzpl
               wbaa(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fba', 1 )
!....
      return
      end
