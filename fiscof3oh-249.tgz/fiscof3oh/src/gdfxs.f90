!----------------------------------------------------------------------
! igdfx interface routines
!
module gdfxs_interface
   integer, parameter :: lhuen=12, llign=20
end module gdfxs_interface
!----------------------
      subroutine gdfxs_init
!....
      call igdfx_init
!....
      return
      end
!----------------------
      subroutine gdfxs_term
!....
      call igdfx_term
!....
      return
      end
!----------------------
      subroutine gdfxs_bodys
      use animation
      use gdfxs_interface
      include "implicit.h"
      integer :: ih, il, im, ic, i, ivp, ibo, iwn, itrf, igf, &
                 ir, ig, ib, iopen
      real*4  :: wls, wle, whs, whe, wh, wl, ws, wxm, wxx, wym, wyx
!....
      do im = 1, lagfl
!....
      call igdfx_inqgif ( im, iopen )
      if( iopen .eq. 0 ) then
!...
      call igdfx_opngif ( im, lagifw(im), lagifh(im) )
!...
      whs = 0.0
      whe = 310.0
      wls = 0.25
      wle = 0.75
      ws  = 1.0
!.
      do ih = 1, lhuen
         wh = whs + ( whe - whs ) * ( ih-1 ) / ( lhuen-1 )
         if( ih .eq. 3 ) wh = wh - 10.0
         if( ih .eq. 4 ) wh = wh - 20.0
         if( ih .eq. 5 ) wh = wh - 30.0
         do il = 1, llign
            wl = wls + ( wle - wls ) * ( il-1 ) / ( llign-1 )
            ic = 10 + ( ih-1 ) * llign + ( il-1 )
            call igdfx_hls2rgb ( wh, wl, ws, ir, ig, ib )
            call igdfx_defcol ( ic, ir, ig, ib )
         end do
      end do
!..
      do i = 1, lavpl
         wxm = savpxm(i)
         wxx = savpxx(i)
         wym = savpym(i)
         wyx = savpyx(i)
         call igdfx_defvwp ( i, wxm, wxx, wym, wyx )
      end do
!..
      itrf = 0
      iwn  = 0
      do i = 1, lavpl
         lagifv(i,im) = 0
         lavpc(i,im)  = 0
      end do
!...
      do i = 1, lapepxyl
         igf = mod( lapepxy(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapepxy(i) / 10, 10 )
            ibo = mod( lapepxy(i) / 100, 10 )
            wxm = sawnxm(ibo)
            wxx = sawnxx(ibo)
            wym = sawnym(ibo)
            wyx = sawnyx(ibo)
            iwn = iwn + 1
            call igdfx_defwin ( iwn, wxm, wxx, wym, wyx )
            labon(iwn,igf) = ibo
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapepxygt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapepyzl
         igf = mod( lapepyz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapepyz(i) / 10, 10 )
            ibo = mod( lapepyz(i) / 100, 10 )
            wxm = sawnym(ibo)
            wxx = sawnyx(ibo)
            wym = sawnzm(ibo)
            wyx = sawnzx(ibo)
            iwn = iwn + 1
            call igdfx_defwin ( iwn, wxm, wxx, wym, wyx )
            labon(iwn,igf) = ibo
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapepyzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!.
      do i = 1, lapepxzl
         igf = mod( lapepxz(i), 10 )
         if( igf .eq. im ) then
            ivp = mod( lapepxz(i) / 10, 10 )
            ibo = mod( lapepxz(i) / 100, 10 )
            wxm = sawnxm(ibo)
            wxx = sawnxx(ibo)
            wym = sawnzm(ibo)
            wyx = sawnzx(ibo)
            iwn = iwn + 1
            call igdfx_defwin ( iwn, wxm, wxx, wym, wyx )
            labon(iwn,igf) = ibo
            itrf = itrf + 1
            call igdfx_deftrf ( itrf, ivp, iwn )
            lapepxzgt(i) = igf + itrf * 10
            lagifv(ivp,im) = lagifv(ivp,im) + 1
         end if
      end do
!..
      else
         do i = 1, lavpl
            lagifv(i,im) = -1
            lavpc(i,im)  = -1
         end do
      end if
!....
      end do
!....
      return
      end
!----------------------
      subroutine gdfxs_body31 ( kno, fpdat1, kl, kint, kcrs, elab )
      use animation
      use gdfxs_interface
      include "implicit.h"
      type ty1_particle
         sequence
         real*8  :: fpv(6), fuu, fpf
         integer :: knid, kclfl
      end type ty1_particle
      type(ty1_particle) :: fpdat1(kl)
      integer :: kno, kl, kint, kcrs, ix, iy, iz, igf, itf, ivp, iwn, &
                 inum, i, il, ih, ic, ibo
      real*4  :: wx, wy, wwx0, wwy0, wvxm, wvxx, wvym, wvyx, &
                 wwxm, wwxx, wwym, wwyx, wwzm, wwzx, &
                 wtxm, wtxx, wtym, wtyx, wtzm, wtzx
      character :: elab*(*), cvalue*24
!....
      igf = mod( kno, 10 )
      itf = kno / 10
!..
      call igdfx_selgif ( igf )
      call igdfx_seltrf ( itf )
      call igdfx_inqtrf ( itf, ivp, iwn, wvxm, wvxx, wvym, wvyx, &
                                         wwxm, wwxx, wwym, wwyx )
      ibo = labon(iwn,igf)
!.
      select case( kcrs ) 
      case( 1 )
         ix = 1
         iy = 2
         iz = 3
         wwx0 = sawnx0(ibo)
         wwy0 = sawny0(ibo)
         wwzm = sawnzm(ibo)
         wwzx = sawnzx(ibo)
         wtxm = saboxm(ibo)
         wtxx = saboxx(ibo)
         wtym = saboym(ibo)
         wtyx = saboyx(ibo)
         wtzm = sabozm(ibo)
         wtzx = sabozx(ibo)
      case( 2 )
         ix = 2
         iy = 3
         iz = 1
         wwx0 = sawny0(ibo)
         wwy0 = sawnz0(ibo)
         wwzm = sawnxm(ibo)
         wwzx = sawnxx(ibo)
         wtxm = saboym(ibo)
         wtxx = saboyx(ibo)
         wtym = sabozm(ibo)
         wtyx = sabozx(ibo)
         wtzm = saboxm(ibo)
         wtzx = saboxx(ibo)
      case( 3 )
         ix = 1
         iy = 3
         iz = 2
         wwx0 = sawnx0(ibo)
         wwy0 = sawnz0(ibo)
         wwzm = sawnym(ibo)
         wwzx = sawnyx(ibo)
         wtxm = saboxm(ibo)
         wtxx = saboxx(ibo)
         wtym = sabozm(ibo)
         wtyx = sabozx(ibo)
         wtzm = saboym(ibo)
         wtzx = saboyx(ibo)
      case default 
         write(0,*) '### [gdfxs_body31] invalid kcrs :', kcrs
         go to 999
      end select
!..
      inum = 0
      do i = 1, kl, kint
         inum = inum + 1
         if( fpdat1(i)%fpv(1) .lt. sawnxm(ibo) ) cycle
         if( fpdat1(i)%fpv(1) .gt. sawnxx(ibo) ) cycle
         if( fpdat1(i)%fpv(2) .lt. sawnym(ibo) ) cycle
         if( fpdat1(i)%fpv(2) .gt. sawnyx(ibo) ) cycle
         if( fpdat1(i)%fpv(3) .lt. sawnzm(ibo) ) cycle
         if( fpdat1(i)%fpv(3) .gt. sawnzx(ibo) ) cycle
!..
         il = ( fpdat1(i)%fpv(iz) - wwzm ) / ( wwzx - wwzm ) * llign
         il = min( il, llign-1 )
         ih = mod( inum, lhuen )
         ic = 10 + ih * llign + il
         wx = fpdat1(i)%fpv(ix)
         wy = fpdat1(i)%fpv(iy)
         call igdfx_sellcl ( ic )
         call igdfx_drwpoi ( wx, wy )
      end do
!...
      if( elab(1:1) .ne. ' ' ) then
         call igdfx_sellcl ( 3 )
         call igdfx_drwlin ( wwxm, wwy0, wwxx, wwy0 )
         call igdfx_drwlin ( wwx0, wwym, wwx0, wwyx )
!.
         write( cvalue(1:10), '(e10.3)' ) wtxx
         cvalue(11:24) = '$'
         call igdfx_seltcl ( 2 )
         ix = lagifw(igf) *  wvxx - 60
         iy = lagifh(igf) * ( 1.0 - wvym ) - lavpc(ivp,igf)*10 - 15
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         write( cvalue(1:10), '(e10.3)' ) wtzm
         ix = lagifw(igf) *  ( wvxx+wvxm ) / 2.0d0 - 20
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         write( cvalue(1:10), '(e10.3)' ) wtym
         cvalue(11:11) = ','
         write( cvalue(12:21), '(e10.3)' ) wtxm
         cvalue(22:23) = '$'
         ix = lagifw(igf) * wvxm  + 2
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
         write( cvalue(1:10), '(e10.3)' ) wtyx
         iy = lagifh(igf) * ( 1.0 - wvyx ) + lavpc(ivp,igf)*10 + 2
         call igdfx_drwtxt ( ix, iy, 2, &
                           cvalue(1:10)//' '//trim(elab)//'$ ' )
         write( cvalue(1:10), '(e10.3)' ) wtzx
         cvalue(11:24) = '$'
         ix = lagifw(igf) *  ( wvxx+wvxm ) / 2.0d0 - 20
         call igdfx_drwtxt ( ix, iy, 2, cvalue )
!.
         lavpc(ivp,igf) = lavpc(ivp,igf) + 1
      end if
!....
  999 continue
      return
      end
!----------------------
      subroutine gdfxs_bodye
      use parameter
      use constant
      use observe
      use animation
      include "implicit.h"
      integer :: im, i, iapp
      character(16) :: ctime, ctimeo=' $ '
      save
!....
      write( ctime(1:8), '(f8.2)' ) sstcur
      ctime(9:16) = '$'
!....
      do im = 1, lagfl
!...
         iapp = lamode(im) / 10
!...
         call igdfx_selgif ( im )
!..
         do i = 1, lavpl
            if( lagifv(i,im) .gt. 0 ) call igdfx_drwvwp ( i )
         end do
!..
         if( iapp .eq. 1 ) then
            call igdfx_seltcl ( 1 )
            call igdfx_drwtxt ( lagifw(im)-60, 5, 3, ctimeo )
            ctimeo = ctime
         end if
         call igdfx_seltcl ( 2 )
         call igdfx_drwtxt ( lagifw(im)-60, 5, 3, ctime )
!..
         call fntpcnv ( banfntp(im), lrank,im, bident,'an', bfile )
         call igdfx_clsgif ( im, trim(bfile)//'$ ', lamode(im) )
!....
      end do
!....
      return
      end
