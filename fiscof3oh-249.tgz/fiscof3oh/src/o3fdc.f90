!----------------------------------------------------------------------
! Observe 3D Field Density Charge
!                          /
      subroutine o3fdc ( kflag )
!
!   <arguments>
!     kflag : mode 0 = clear and output header
!                  1 = output&clear
!                  2 = add and output&clear
!                  3 = add
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/11/05
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use field
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 26, ifn = 7
      integer :: kflag, i, io, iofdc, i3d, icrxy, icryz, &
                 icrxz, ix, iy, iz, ixyz, iwdca
      real*8 :: wminlog
      real*8, allocatable :: wdca(:)
#ifdef OHHELP
      integer :: ips=1
#endif
      save
!....
      call fdebug ( 'o3fdc', 0 )
!....
#ifndef OHHELP
      if( kflag .ge. 2 .and. loxyzpl .gt. 0 ) then
#else
      if( kflag .ge. 2 ) then
#endif
         if( lcfde .eq. 0 ) call c3fde
         if( lcfdi .eq. 0 ) call c3fdi
#ifdef OHHELP
         if( loxyzpl .gt. 0 ) then
#endif
         iwdca = iwdca + 1
         ixyz = 0
         do iz = lozps, lozpe, lozpi
           do iy = loyps, loype, loypi
             do ix = loxps, loxpe, loxpi
               ixyz = ixyz + 1
               wdca(ixyz) = wdca(ixyz) - sde(ix,iy,iz)
             end do
           end do
         end do
         if( lionspl .gt. 0 ) then
           do io = 1, lionspl
             ixyz = 0
             do iz = lozps, lozpe, lozpi
               do iy = loyps, loype, loypi
                 do ix = loxps, loxpe, loxpi
                   ixyz = ixyz + 1
                   wdca(ixyz) = wdca(ixyz) + sdi(ix,iy,iz,io)*sionaz(io)
                 end do
               end do
             end do
           end do
         else
           ixyz = 0
           do iz = lozps, lozpe, lozpi
             do iy = loyps, loype, loypi
               do ix = loxps, loxpe, loxpi
                 ixyz = ixyz + 1
                 wdca(ixyz) = wdca(ixyz) + sde0(ix,iy,iz)
               end do
             end do
           end do
         end if
#ifdef OHHELP
         end if
#endif
      end if
!....
      if( kflag .le. 2 ) then
         if( kflag .ge. 1 ) then
          if( loxyzpl .gt. 0 ) then
            do i = 1, loxyzpl
               wdca(i) = wdca(i) / ( iwdca * snepm1 )
            end do
            if( iofdc .le. 4 ) then
               write(iun) sstcur, ( wdca(i),i=1,loxyzpl )
               flush(iun)
            end if
            if( iofdc .ge. 2 ) then
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, 0, i3d, 0, 2, & 
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wdca, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fdc' ) 
            end if
          end if
         else
!....
           iofdc = mod( lofdc, 10 )
           i3d   = mod( lofdc/100, 10 )
           icrxy = mod( lofdc/1000, 10 )
           icryz = mod( lofdc/10000, 10 )
           icrxz = mod( lofdc/100000, 10 )
!.
           if( iofdc .ge. 2 ) then
             if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
               write(0,*) '### ERROR: no plot for fdc', & 
                           i3d, icrxy, icryz, icrxz
               call s3ext_abort
             end if
           end if

!...
           if( loxyzpl .gt. 0 ) then
              if( .not. allocated(wdca) ) allocate( wdca(loxyzpl) )
           end if
!..

           if( iofdc .le. 4 ) then
              call fntpcnv ( bbifntp, lrank,iun, bident,'fdc', bfile )
              open(iun, file=bfile, form='UNFORMATTED')
#ifndef OHHELP
              write(iun) 'fdc4', bident, loxyzpl, loxpl, loypl, lozpl, &
                       soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
              write(iun) 'fdc5', bident, loxyzpl, loxpl, loypl, lozpl, &
                       soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                           lrank, ldivx, ldivy, ldivz, &
                                         oh_loxal, oh_loxas, oh_loxae, &
                                         oh_loyal, oh_loyas, oh_loyae, &
                                         oh_lozal, oh_lozas, oh_lozae
#endif
              flush(iun)
           end if
           if( iofdc .ge. 2 ) then
              call fntpcnv ( bfrfntp, lrank,ifn, bident,'fdc', bfile )
              call frames_file ( bfile, ifn, iofdc )
           end if
         end if
         if( loxyzpl .gt. 0 ) then
            iwdca = 0
            do i = 1, loxyzpl
               wdca(i) = s0o1
            end do
         end if
      end if
!....
      call fdebug ( 'o3fdc', 1 )
!....
      return
      end
