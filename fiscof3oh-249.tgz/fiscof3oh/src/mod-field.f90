!----------------------------------------------------------------------
! field
!
module field
      integer :: lcfde, lcfdi
      real*8, allocatable, save :: &
        sde0(:,:,:), sdi(:,:,:,:)
#ifndef OHHELP
      real*8, allocatable, save :: &
        sde(:,:,:), &
        sebxyz(:,:,:,:), sjxyzt(:,:,:,:), &
        sdeyxdxy(:,:,:), sdezydyz(:,:,:), sdexzdzx(:,:,:), &
        sjxe(:,:,:), sjxi(:,:,:,:), sjye(:,:,:), sjyi(:,:,:,:), &
        sjze(:,:,:), sjzi(:,:,:,:)
#else
      real*8, allocatable, save :: &
        oh_sde(:,:,:,:), &
        oh_sexyz(:,:,:,:,:), oh_sbxyz(:,:,:,:,:), oh_sjxyzt(:,:,:,:,:), &
        oh_sdeyxdxy(:,:,:,:), oh_sdezydyz(:,:,:,:), oh_sdexzdzx(:,:,:,:), &
        oh_sjxe(:,:,:,:), oh_sjxi(:,:,:,:,:), oh_sjye(:,:,:,:), oh_sjyi(:,:,:,:,:),&
        oh_sjze(:,:,:,:), oh_sjzi(:,:,:,:,:)
#endif
end module field
