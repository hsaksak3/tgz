!----------------------------------------------------------------------
! parameter
!
module parameter
      integer :: lssx = 1200 + 1, lssy = 600 + 1, lssz = 600 + 1
      integer :: lssxp1, lssxm1, lssyp1, lssym1, lsszp1, lsszm1
      integer :: lssxl, lssxlp1, lssxlp2, lssxlp3, lssxlm1, lssxlm2
      integer :: lssxu, lssxup1, lssxup2, lssxup3, lssxum1, lssxum2
      integer :: lssyl, lssylp1, lssylp2, lssylp3, lssylm1, lssylm2
      integer :: lssyu, lssyup1, lssyup2, lssyup3, lssyum1, lssyum2
      integer :: lsszl, lsszlp1, lsszlp2, lsszlp3, lsszlm1, lsszlm2
      integer :: lsszu, lsszup1, lsszup2, lsszup3, lsszum1, lsszum2
      integer :: lpmlxl = 8, lpmlxu = 8, lpmlyl = 8, lpmlyu = 8, &
                 lpmlzl = 8, lpmlzu = 8
      integer :: lblxu, lblxup1, lblxl, lblxlm1
      integer :: lblyu, lblyup1, lblyl, lblylm1
      integer :: lblzu, lblzup1, lblzl, lblzlm1
      integer :: lnoex = 10000000, lnoix = 10000000
      integer :: lnox
      integer :: lsize = -1,lrank = -1,ldivx = -1,ldivy = -1,ldivz = -1
      integer :: lloadbf = 5
#ifndef VECTOR
      integer :: lvlen = -1
#else
      integer :: lvlen = VECTOR
#endif
      integer, parameter :: lionspx = 8, lpppx = 30, lpphx = 20
      integer, parameter :: llsrbx = 5
      integer, parameter :: lclflgex = 5
      integer, parameter :: lclflgix = 5
      integer, parameter :: ltimex = 16384
      integer, parameter :: locrsx = 9, loisox = 4
      integer, parameter :: lopemx = 9, lopeex = 9
      integer, parameter :: lopimx = 9, lopiex = 9
      integer, parameter :: lopephx = 9
      integer, parameter :: lofekx = 5, lofewx = 5
! Do not change "lopfeedx" and "lopfiedx".
! Changing these values causes unexpected Fortran file ERROR.
      integer, parameter :: lopfeedx = 5, lopfiedx = 5
      integer, parameter :: lavpx = 9, labox = 3, lawnx = 10, lagfx = 9
end module parameter
