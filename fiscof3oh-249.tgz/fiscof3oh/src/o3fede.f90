!----------------------------------------------------------------------
! Observe 3D Field Energy Density Electron
!                           /
      subroutine o3fede ( kflag )
!
!   <arguments>
!     kflag : mode 0 = output header
!                  1 = output
!
!   <remarks>
!     none
!
!    coded by Sakagami,H. (NIFS) 20/12/21
!----------------------------------------------------------------------
#include "spdat.macro"
#ifdef OHHELP
#include "sfieldoh.macro"
#include "oindexoh.macro"
      use oh_param
#endif
      use parameter
      use constant
      use particle
      use observe
      include "implicit.h"
      integer, parameter :: iun = 36, ifn = 17
      integer :: kflag, iofede, i3d, icrxy, icryz, icrxz, &
                 i, ix, iy, iz
      real*8, allocatable :: wfede(:,:,:)
#ifdef OHHELP
      real*8, allocatable :: oh_wfede(:,:,:,:)
      integer :: ips, ixx, iyy, izz
#endif
      save
!....
      call fdebug ( 'o3fede', 0 )
!....
      if( kflag .ge. 1 ) then
!...
#ifndef OHHELP
       if( loxyzpl .gt. 0 ) then
         wfede(:,:,:) = s0o1
!..
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:wfede), &
!$OMP          PRIVATE(ix,iy,iz)
         do i = lnoes, lnoee
            ix = sxe(i) + s1o2
            iy = sye(i) + s1o2
            iz = sze(i) + s1o2
!
            if( ix .lt. loxps .or. ix .gt. loxpe ) cycle
            if( iy .lt. loyps .or. iy .gt. loype ) cycle
            if( iz .lt. lozps .or. iz .gt. lozpe ) cycle
            if( mod(ix-loxps,loxpi) .ne. 0 ) cycle
            if( mod(iy-loyps,loypi) .ne. 0 ) cycle
            if( mod(iz-lozps,lozpi) .ne. 0 ) cycle
!
            ix = ( ix - loxps ) / loxpi + 1
            iy = ( iy - loyps ) / loypi + 1
            iz = ( iz - lozps ) / lozpi + 1
            wfede(ix,iy,iz) = wfede(ix,iy,iz) +  &
                      ( sqrt( s1o1+suue(i)**2*scg1 ) - s1o1 ) * spfe(i)
         end do
#else
         oh_wfede(:,:,:,:) = s0o1
!..
         do ips = 1, 2
            if( oh_lnoe(ips) .le. 0 ) cycle 
            oh_ixs = oh_sdoms(1,1,oh_sdid(ips)+1) - 1
            oh_iys = oh_sdoms(1,2,oh_sdid(ips)+1) - 1
            oh_izs = oh_sdoms(1,3,oh_sdid(ips)+1) - 1
!$OMP PARALLEL DO SCHEDULE(STATIC), REDUCTION(+:oh_wfede), &
!$OMP          PRIVATE(ix,iy,iz)
            do i = oh_lnoes(ips),oh_lnoee(ips)
               ix = sxe(i) - oh_ixs
               iy = sye(i) - oh_iys
               iz = sze(i) - oh_izs
               oh_wfede(ix,iy,iz,ips) = oh_wfede(ix,iy,iz,ips) + &
                      ( sqrt( s1o1+suue(i)**2*scg1 ) - s1o1 ) * spfe(i)
            end do
         end do  
!.
         call oh3_reduce_field &
                      ( oh_wfede(1,1,1,1), oh_wfede(1,1,1,2), FDE )
!..
       if( loxyzpl .gt. 0 ) then
!
         do iz = lozps, lozpe, lozpi
           izz = ( iz - lozps ) / lozpi + 1
           do iy = loyps, loype, loypi
             iyy = ( iy - loyps ) / loypi + 1
             do ix = loxps, loxpe, loxpi
               ixx = ( ix - loxps ) / loxpi + 1
               wfede(ixx,iyy,izz) = oh_wfede(ix,iy,iz,1)
             end do
           end do
         end do
#endif
!..
         wfede(:,:,:) = wfede(:,:,:) / snepm1
!..
         if( iofede .le. 4 ) then
            write(iun) sstcur, wfede(:,:,:)
            flush(iun)
         end if
         if( iofede .ge. 2 ) then
               call o3fdraw1 ( bident, sstcur, sminlog, lminlog, &
                 ifn, 0, i3d, 0, 1, & 
                 icrxy, sozcrs, icryz, soxcrs, icrxz, soycrs, soisov, &
                 wfede, loxpl, loypl, lozpl, sosltd, loslnu, &
                 soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                 'fede' ) 
         end if
       end if
!....
      else
!..
         iofede = mod( lofede, 10 )
         i3d    = mod( lofede/100, 10 )
         icrxy  = mod( lofede/1000, 10 )
         icryz  = mod( lofede/10000, 10 )
         icrxz  = mod( lofede/100000, 10 )
!.
         if( iofede .ge. 2 ) then
           if( i3d+icrxy+icryz+icrxz .eq. 0 ) then
             write(0,*) '### ERROR: no plot for fede', & 
                        i3d, icrxy, icryz, icrxz
             call s3ext_abort
           end if
         end if
!....
         if( loxyzpl .gt. 0 ) then
            if( .not. allocated(wfede) ) &
               allocate( wfede(loxpl,loypl,lozpl) )
         end if
#ifdef OHHELP
         if( .not. allocated(oh_wfede) ) allocate( oh_wfede( &
                     oh_alosizes(1,1,FDE):oh_alosizes(2,1,FDE), &
                     oh_alosizes(1,2,FDE):oh_alosizes(2,2,FDE), &
                     oh_alosizes(1,3,FDE):oh_alosizes(2,3,FDE), 2) )
#endif
!...
         if( iofede .le. 4 ) then
            call fntpcnv ( bbifntp, lrank,iun, bident,'fEe', bfile )
            open(iun, file=bfile, form='UNFORMATTED' )
#ifndef OHHELP
            write(iun) 'fEe4', bident, loxyzpl, loxpl, loypl, lozpl, &
                     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m
#else
            write(iun) 'fEe5', bident, loxyzpl, loxpl, loypl, lozpl, &
                     soxmic, soxp0m, soymic, soyp0m, sozmic, sozp0m, &
                                         lrank, ldivx, ldivy, ldivz, &
                                       oh_loxal, oh_loxas, oh_loxae, &
                                       oh_loyal, oh_loyas, oh_loyae, &
                                       oh_lozal, oh_lozas, oh_lozae
#endif
                      
            flush(iun)
         end if
         if( iofede .ge. 2 ) then
            call fntpcnv ( bfrfntp, lrank,ifn, bident,'fEe', bfile )
            call frames_file ( bfile, ifn, iofede )
         end if
      end if
!....
      call fdebug ( 'o3fede', 1 )
!....
      return
      end
