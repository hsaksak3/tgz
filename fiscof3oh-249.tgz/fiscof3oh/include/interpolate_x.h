   _INTERP1_(_x1,_dx)
   _INTERP2_(_x2,_dx)
   _INTERP3_(_x3,_dx)
   _INTERP4_(_x4,_dx)
