#define _iz izi
#define _dz wdd
#define _z1 wz1i
#define _z2 wz2i
#define _z3 wz3i
#define _z4 wz4i
