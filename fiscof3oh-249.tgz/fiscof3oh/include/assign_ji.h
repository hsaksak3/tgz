!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            sjxi(ix,iy,iz,io) = wjxi(ix,iy,iz) * sionaz(io)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            sjyi(ix,iy,iz,io) = wjyi(ix,iy,iz) * sionaz(io)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            sjzi(ix,iy,iz,io) = wjzi(ix,iy,iz) * sionaz(io)
          end do
        end do
      end do
