#ifndef _ZIGZAG32
   _iy = _sy
#endif
   _dy = _sy - _iy - s1o2
#ifdef _iyd
   _iyd = _iy - _iyo
#endif
#include "interpolate_y.h"
#include "interpolate_undefy.h"
