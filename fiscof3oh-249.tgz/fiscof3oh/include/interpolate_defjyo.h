#define _iy _iyo
#define _dy wyd
#define _y1 _fyo(2)
#define _y2 _fyo(3)
#define _y3 _fyo(4)
#define _y4 _fyo(5)
