!..
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup2
            wjxe(lssxlm2,iy,iz) = wjxe(lssxlm2,iy,iz) + &
                                                    wjxe(lssxum2,iy,iz)
            wjxe(lssxlm1,iy,iz) = wjxe(lssxlm1,iy,iz) + &
                                                    wjxe(lssxum1,iy,iz)
            wjxe(lssxl  ,iy,iz) = wjxe(lssxl  ,iy,iz) + &
                                                    wjxe(lssxu  ,iy,iz)
            wjxe(lssxlp1,iy,iz) = wjxe(lssxlp1,iy,iz) + &
                                                    wjxe(lssxup1,iy,iz)
            wjxe(lssxlp2,iy,iz) = wjxe(lssxlp2,iy,iz) + &
                                                    wjxe(lssxup2,iy,iz)
            wjxe(lssxlp3,iy,iz) = wjxe(lssxlp3,iy,iz) + &
                                                    wjxe(lssxup3,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup3
            wjye(lssxlm2,iy,iz) = wjye(lssxlm2,iy,iz) + &
                                                    wjye(lssxum2,iy,iz)
            wjye(lssxlm1,iy,iz) = wjye(lssxlm1,iy,iz) + &
                                                    wjye(lssxum1,iy,iz)
            wjye(lssxl  ,iy,iz) = wjye(lssxl  ,iy,iz) + &
                                                    wjye(lssxu  ,iy,iz)
            wjye(lssxlp1,iy,iz) = wjye(lssxlp1,iy,iz) + &
                                                    wjye(lssxup1,iy,iz)
            wjye(lssxlp2,iy,iz) = wjye(lssxlp2,iy,iz) + &
                                                    wjye(lssxup2,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do iy = lssylm2, lssyup2
            wjze(lssxlm2,iy,iz) = wjze(lssxlm2,iy,iz) + &
                                                    wjze(lssxum2,iy,iz)
            wjze(lssxlm1,iy,iz) = wjze(lssxlm1,iy,iz) + &
                                                    wjze(lssxum1,iy,iz)
            wjze(lssxl  ,iy,iz) = wjze(lssxl  ,iy,iz) + &
                                                    wjze(lssxu  ,iy,iz)
            wjze(lssxlp1,iy,iz) = wjze(lssxlp1,iy,iz) + &
                                                    wjze(lssxup1,iy,iz)
            wjze(lssxlp2,iy,iz) = wjze(lssxlp2,iy,iz) + &
                                                    wjze(lssxup2,iy,iz)
          end do
        end do
      end if
!
      if( lexuf .eq. 1 ) then
        if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup2
              wjxe(lssxum2,iy,iz) = wjxe(lssxlm2,iy,iz)
              wjxe(lssxum1,iy,iz) = wjxe(lssxlm1,iy,iz)
              wjxe(lssxu  ,iy,iz) = wjxe(lssxl  ,iy,iz)
              wjxe(lssxup1,iy,iz) = wjxe(lssxlp1,iy,iz)
              wjxe(lssxup2,iy,iz) = wjxe(lssxlp2,iy,iz)
              wjxe(lssxup3,iy,iz) = wjxe(lssxlp3,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup3
              wjye(lssxum2,iy,iz) = wjye(lssxlm2,iy,iz)
              wjye(lssxum1,iy,iz) = wjye(lssxlm1,iy,iz)
              wjye(lssxu  ,iy,iz) = wjye(lssxl  ,iy,iz)
              wjye(lssxup1,iy,iz) = wjye(lssxlp1,iy,iz)
              wjye(lssxup2,iy,iz) = wjye(lssxlp2,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do iy = lssylm2, lssyup2
              wjze(lssxum2,iy,iz) = wjze(lssxlm2,iy,iz)
              wjze(lssxum1,iy,iz) = wjze(lssxlm1,iy,iz)
              wjze(lssxu  ,iy,iz) = wjze(lssxl  ,iy,iz)
              wjze(lssxup1,iy,iz) = wjze(lssxlp1,iy,iz)
              wjze(lssxup2,iy,iz) = wjze(lssxlp2,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup2
              wjxe(lssxum2,iy,iz) = wjxe(lssxlm2,iy,iz) + &
                                                    wjxe(lssxum2,iy,iz)
              wjxe(lssxum1,iy,iz) = wjxe(lssxlm1,iy,iz) + &
                                                    wjxe(lssxum1,iy,iz)
              wjxe(lssxu  ,iy,iz) = wjxe(lssxl  ,iy,iz) + &
                                                    wjxe(lssxu  ,iy,iz)
              wjxe(lssxup1,iy,iz) = wjxe(lssxlp1,iy,iz) + &
                                                    wjxe(lssxup1,iy,iz)
              wjxe(lssxup2,iy,iz) = wjxe(lssxlp2,iy,iz) + &
                                                    wjxe(lssxup2,iy,iz)
              wjxe(lssxup3,iy,iz) = wjxe(lssxlp3,iy,iz) + &
                                                    wjxe(lssxup3,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup3
              wjye(lssxum2,iy,iz) = wjye(lssxlm2,iy,iz) + &
                                                    wjye(lssxum2,iy,iz)
              wjye(lssxum1,iy,iz) = wjye(lssxlm1,iy,iz) + &
                                                    wjye(lssxum1,iy,iz)
              wjye(lssxu  ,iy,iz) = wjye(lssxl  ,iy,iz) + &
                                                    wjye(lssxu  ,iy,iz)
              wjye(lssxup1,iy,iz) = wjye(lssxlp1,iy,iz) + &
                                                    wjye(lssxup1,iy,iz)
              wjye(lssxup2,iy,iz) = wjye(lssxlp2,iy,iz) + &
                                                    wjye(lssxup2,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do iy = lssylm2, lssyup2
              wjze(lssxum2,iy,iz) = wjze(lssxlm2,iy,iz) + &
                                                    wjze(lssxum2,iy,iz)
              wjze(lssxum1,iy,iz) = wjze(lssxlm1,iy,iz) + &
                                                    wjze(lssxum1,iy,iz)
              wjze(lssxu  ,iy,iz) = wjze(lssxl  ,iy,iz) + &
                                                    wjze(lssxu  ,iy,iz)
              wjze(lssxup1,iy,iz) = wjze(lssxlp1,iy,iz) + &
                                                    wjze(lssxup1,iy,iz)
              wjze(lssxup2,iy,iz) = wjze(lssxlp2,iy,iz) + &
                                                    wjze(lssxup2,iy,iz)
            end do
          end do
        end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do ix = lssxlm2, lssxup3
            wjxe(ix,lssylm2,iz) = wjxe(ix,lssylm2,iz) + &
                                                    wjxe(ix,lssyum2,iz)
            wjxe(ix,lssylm1,iz) = wjxe(ix,lssylm1,iz) + &
                                                    wjxe(ix,lssyum1,iz)
            wjxe(ix,lssyl  ,iz) = wjxe(ix,lssyl  ,iz) + &
                                                    wjxe(ix,lssyu  ,iz)
            wjxe(ix,lssylp1,iz) = wjxe(ix,lssylp1,iz) + &
                                                    wjxe(ix,lssyup1,iz)
            wjxe(ix,lssylp2,iz) = wjxe(ix,lssylp2,iz) + &
                                                    wjxe(ix,lssyup2,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do ix = lssxlm2, lssxup2
            wjye(ix,lssylm2,iz) = wjye(ix,lssylm2,iz) + &
                                                    wjye(ix,lssyum2,iz)
            wjye(ix,lssylm1,iz) = wjye(ix,lssylm1,iz) + &
                                                    wjye(ix,lssyum1,iz)
            wjye(ix,lssyl  ,iz) = wjye(ix,lssyl  ,iz) + &
                                                    wjye(ix,lssyu  ,iz)
            wjye(ix,lssylp1,iz) = wjye(ix,lssylp1,iz) + &
                                                    wjye(ix,lssyup1,iz)
            wjye(ix,lssylp2,iz) = wjye(ix,lssylp2,iz) + &
                                                    wjye(ix,lssyup2,iz)
            wjye(ix,lssylp3,iz) = wjye(ix,lssylp3,iz) + &
                                                    wjye(ix,lssyup3,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do ix = lssxlm2, lssxup2
            wjze(ix,lssylm2,iz) = wjze(ix,lssylm2,iz) + &
                                                    wjze(ix,lssyum2,iz)
            wjze(ix,lssylm1,iz) = wjze(ix,lssylm1,iz) + &
                                                    wjze(ix,lssyum1,iz)
            wjze(ix,lssyl  ,iz) = wjze(ix,lssyl  ,iz) + &
                                                    wjze(ix,lssyu  ,iz)
            wjze(ix,lssylp1,iz) = wjze(ix,lssylp1,iz) + &
                                                    wjze(ix,lssyup1,iz)
            wjze(ix,lssylp2,iz) = wjze(ix,lssylp2,iz) + &
                                                    wjze(ix,lssyup2,iz)
          end do
        end do
      end if
!
      if( leyuf .eq. 1 ) then
        if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup3
              wjxe(ix,lssyum2,iz) = wjxe(ix,lssylm2,iz)
              wjxe(ix,lssyum1,iz) = wjxe(ix,lssylm1,iz)
              wjxe(ix,lssyu  ,iz) = wjxe(ix,lssyl  ,iz)
              wjxe(ix,lssyup1,iz) = wjxe(ix,lssylp1,iz)
              wjxe(ix,lssyup2,iz) = wjxe(ix,lssylp2,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup2
              wjye(ix,lssyum2,iz) = wjye(ix,lssylm2,iz)
              wjye(ix,lssyum1,iz) = wjye(ix,lssylm1,iz)
              wjye(ix,lssyu  ,iz) = wjye(ix,lssyl  ,iz)
              wjye(ix,lssyup1,iz) = wjye(ix,lssylp1,iz)
              wjye(ix,lssyup2,iz) = wjye(ix,lssylp2,iz)
              wjye(ix,lssyup3,iz) = wjye(ix,lssylp3,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do ix = lssxlm2, lssxup2
              wjze(ix,lssyum2,iz) = wjze(ix,lssylm2,iz)
              wjze(ix,lssyum1,iz) = wjze(ix,lssylm1,iz)
              wjze(ix,lssyu  ,iz) = wjze(ix,lssyl  ,iz)
              wjze(ix,lssyup1,iz) = wjze(ix,lssylp1,iz)
              wjze(ix,lssyup2,iz) = wjze(ix,lssylp2,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup3
              wjxe(ix,lssyum2,iz) = wjxe(ix,lssylm2,iz) + &
                                                    wjxe(ix,lssyum2,iz)
              wjxe(ix,lssyum1,iz) = wjxe(ix,lssylm1,iz) + &
                                                    wjxe(ix,lssyum1,iz)
              wjxe(ix,lssyu  ,iz) = wjxe(ix,lssyl  ,iz) + &
                                                    wjxe(ix,lssyu  ,iz)
              wjxe(ix,lssyup1,iz) = wjxe(ix,lssylp1,iz) + &
                                                    wjxe(ix,lssyup1,iz)
              wjxe(ix,lssyup2,iz) = wjxe(ix,lssylp2,iz) + &
                                                    wjxe(ix,lssyup2,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup2
              wjye(ix,lssyum2,iz) = wjye(ix,lssylm2,iz) + &
                                                    wjye(ix,lssyum2,iz)
              wjye(ix,lssyum1,iz) = wjye(ix,lssylm1,iz) + &
                                                    wjye(ix,lssyum1,iz)
              wjye(ix,lssyu  ,iz) = wjye(ix,lssyl  ,iz) + &
                                                    wjye(ix,lssyu  ,iz)
              wjye(ix,lssyup1,iz) = wjye(ix,lssylp1,iz) + &
                                                    wjye(ix,lssyup1,iz)
              wjye(ix,lssyup2,iz) = wjye(ix,lssylp2,iz) + &
                                                    wjye(ix,lssyup2,iz)
              wjye(ix,lssyup3,iz) = wjye(ix,lssylp3,iz) + &
                                                    wjye(ix,lssyup3,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do ix = lssxlm2, lssxup2
              wjze(ix,lssyum2,iz) = wjze(ix,lssylm2,iz) + &
                                                    wjze(ix,lssyum2,iz)
              wjze(ix,lssyum1,iz) = wjze(ix,lssylm1,iz) + &
                                                    wjze(ix,lssyum1,iz)
              wjze(ix,lssyu  ,iz) = wjze(ix,lssyl  ,iz) + &
                                                    wjze(ix,lssyu  ,iz)
              wjze(ix,lssyup1,iz) = wjze(ix,lssylp1,iz) + &
                                                    wjze(ix,lssyup1,iz)
              wjze(ix,lssyup2,iz) = wjze(ix,lssylp2,iz) + &
                                                    wjze(ix,lssyup2,iz)
            end do
          end do
        end if
      end if
!..
      if( lezlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            wjxe(ix,iy,lsszlm2) = wjxe(ix,iy,lsszlm2) + &
                                                    wjxe(ix,iy,lsszum2)
            wjxe(ix,iy,lsszlm1) = wjxe(ix,iy,lsszlm1) + &
                                                    wjxe(ix,iy,lsszum1)
            wjxe(ix,iy,lsszl  ) = wjxe(ix,iy,lsszl  ) + &
                                                    wjxe(ix,iy,lsszu  )
            wjxe(ix,iy,lsszlp1) = wjxe(ix,iy,lsszlp1) + &
                                                    wjxe(ix,iy,lsszup1)
            wjxe(ix,iy,lsszlp2) = wjxe(ix,iy,lsszlp2) + &
                                                    wjxe(ix,iy,lsszup2)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            wjye(ix,iy,lsszlm2) = wjye(ix,iy,lsszlm2) + &
                                                    wjye(ix,iy,lsszum2)
            wjye(ix,iy,lsszlm1) = wjye(ix,iy,lsszlm1) + &
                                                    wjye(ix,iy,lsszum1)
            wjye(ix,iy,lsszl  ) = wjye(ix,iy,lsszl  ) + &
                                                    wjye(ix,iy,lsszu  )
            wjye(ix,iy,lsszlp1) = wjye(ix,iy,lsszlp1) + &
                                                    wjye(ix,iy,lsszup1)
            wjye(ix,iy,lsszlp2) = wjye(ix,iy,lsszlp2) + &
                                                    wjye(ix,iy,lsszup2)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            wjze(ix,iy,lsszlm2) = wjze(ix,iy,lsszlm2) + &
                                                    wjze(ix,iy,lsszum2)
            wjze(ix,iy,lsszlm1) = wjze(ix,iy,lsszlm1) + &
                                                    wjze(ix,iy,lsszum1)
            wjze(ix,iy,lsszl  ) = wjze(ix,iy,lsszl  ) + &
                                                    wjze(ix,iy,lsszu  )
            wjze(ix,iy,lsszlp1) = wjze(ix,iy,lsszlp1) + &
                                                    wjze(ix,iy,lsszup1)
            wjze(ix,iy,lsszlp2) = wjze(ix,iy,lsszlp2) + &
                                                    wjze(ix,iy,lsszup2)
            wjze(ix,iy,lsszlp3) = wjze(ix,iy,lsszlp3) + &
                                                    wjze(ix,iy,lsszup3)
          end do
        end do
      end if
!
      if( lezuf .eq. 1 ) then
        if( lezlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              wjxe(ix,iy,lsszum2) = wjxe(ix,iy,lsszlm2)
              wjxe(ix,iy,lsszum1) = wjxe(ix,iy,lsszlm1)
              wjxe(ix,iy,lsszu  ) = wjxe(ix,iy,lsszl  )
              wjxe(ix,iy,lsszup1) = wjxe(ix,iy,lsszlp1)
              wjxe(ix,iy,lsszup2) = wjxe(ix,iy,lsszlp2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              wjye(ix,iy,lsszum2) = wjye(ix,iy,lsszlm2)
              wjye(ix,iy,lsszum1) = wjye(ix,iy,lsszlm1)
              wjye(ix,iy,lsszu  ) = wjye(ix,iy,lsszl  )
              wjye(ix,iy,lsszup1) = wjye(ix,iy,lsszlp1)
              wjye(ix,iy,lsszup2) = wjye(ix,iy,lsszlp2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              wjze(ix,iy,lsszum2) = wjze(ix,iy,lsszlm2)
              wjze(ix,iy,lsszum1) = wjze(ix,iy,lsszlm1)
              wjze(ix,iy,lsszu  ) = wjze(ix,iy,lsszl  )
              wjze(ix,iy,lsszup1) = wjze(ix,iy,lsszlp1)
              wjze(ix,iy,lsszup2) = wjze(ix,iy,lsszlp2)
              wjze(ix,iy,lsszup3) = wjze(ix,iy,lsszlp3)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              wjxe(ix,iy,lsszum2) = wjxe(ix,iy,lsszlm2) + &
                                                    wjxe(ix,iy,lsszum2)
              wjxe(ix,iy,lsszum1) = wjxe(ix,iy,lsszlm1) + &
                                                    wjxe(ix,iy,lsszum1)
              wjxe(ix,iy,lsszu  ) = wjxe(ix,iy,lsszl  ) + &
                                                    wjxe(ix,iy,lsszu  )
              wjxe(ix,iy,lsszup1) = wjxe(ix,iy,lsszlp1) + &
                                                    wjxe(ix,iy,lsszup1)
              wjxe(ix,iy,lsszup2) = wjxe(ix,iy,lsszlp2) + &
                                                    wjxe(ix,iy,lsszup2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              wjye(ix,iy,lsszum2) = wjye(ix,iy,lsszlm2) + &
                                                    wjye(ix,iy,lsszum2)
              wjye(ix,iy,lsszum1) = wjye(ix,iy,lsszlm1) + &
                                                    wjye(ix,iy,lsszum1)
              wjye(ix,iy,lsszu  ) = wjye(ix,iy,lsszl  ) + &
                                                    wjye(ix,iy,lsszu  )
              wjye(ix,iy,lsszup1) = wjye(ix,iy,lsszlp1) + &
                                                    wjye(ix,iy,lsszup1)
              wjye(ix,iy,lsszup2) = wjye(ix,iy,lsszlp2) + &
                                                    wjye(ix,iy,lsszup2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              wjze(ix,iy,lsszum2) = wjze(ix,iy,lsszlm2) + &
                                                    wjze(ix,iy,lsszum2)
              wjze(ix,iy,lsszum1) = wjze(ix,iy,lsszlm1) + &
                                                    wjze(ix,iy,lsszum1)
              wjze(ix,iy,lsszu  ) = wjze(ix,iy,lsszl  ) + &
                                                    wjze(ix,iy,lsszu  )
              wjze(ix,iy,lsszup1) = wjze(ix,iy,lsszlp1) + &
                                                    wjze(ix,iy,lsszup1)
              wjze(ix,iy,lsszup2) = wjze(ix,iy,lsszlp2) + &
                                                    wjze(ix,iy,lsszup2)
              wjze(ix,iy,lsszup3) = wjze(ix,iy,lsszlp3) + &
                                                    wjze(ix,iy,lsszup3)
            end do
          end do
        end if
      end if
!..
