   _iy = _sy + s1o2
   _dy = _sy - _iy
#include "interpolate_y.h"
#include "interpolate_undefy.h"
