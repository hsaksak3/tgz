   _INTERP1_(_z1,_dz)
   _INTERP2_(_z2,_dz)
   _INTERP3_(_z3,_dz)
   _INTERP4_(_z4,_dz)
