#define _iz _izo
#define _dz wzd
#define _z1 _fzo(2)
#define _z2 _fzo(3)
#define _z3 _fzo(4)
#define _z4 _fzo(5)
