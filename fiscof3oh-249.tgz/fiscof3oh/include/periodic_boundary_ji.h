!..
      if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup2
            wjxi(lssxlm2,iy,iz) = wjxi(lssxlm2,iy,iz) + &
                                                    wjxi(lssxum2,iy,iz)
            wjxi(lssxlm1,iy,iz) = wjxi(lssxlm1,iy,iz) + &
                                                    wjxi(lssxum1,iy,iz)
            wjxi(lssxl  ,iy,iz) = wjxi(lssxl  ,iy,iz) + &
                                                    wjxi(lssxu  ,iy,iz)
            wjxi(lssxlp1,iy,iz) = wjxi(lssxlp1,iy,iz) + &
                                                    wjxi(lssxup1,iy,iz)
            wjxi(lssxlp2,iy,iz) = wjxi(lssxlp2,iy,iz) + &
                                                    wjxi(lssxup2,iy,iz)
            wjxi(lssxlp3,iy,iz) = wjxi(lssxlp3,iy,iz) + &
                                                    wjxi(lssxup3,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do iy = lssylm2, lssyup3
            wjyi(lssxlm2,iy,iz) = wjyi(lssxlm2,iy,iz) + &
                                                    wjyi(lssxum2,iy,iz)
            wjyi(lssxlm1,iy,iz) = wjyi(lssxlm1,iy,iz) + &
                                                    wjyi(lssxum1,iy,iz)
            wjyi(lssxl  ,iy,iz) = wjyi(lssxl  ,iy,iz) + &
                                                    wjyi(lssxu  ,iy,iz)
            wjyi(lssxlp1,iy,iz) = wjyi(lssxlp1,iy,iz) + &
                                                    wjyi(lssxup1,iy,iz)
            wjyi(lssxlp2,iy,iz) = wjyi(lssxlp2,iy,iz) + &
                                                    wjyi(lssxup2,iy,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do iy = lssylm2, lssyup2
            wjzi(lssxlm2,iy,iz) = wjzi(lssxlm2,iy,iz) + &
                                                    wjzi(lssxum2,iy,iz)
            wjzi(lssxlm1,iy,iz) = wjzi(lssxlm1,iy,iz) + &
                                                    wjzi(lssxum1,iy,iz)
            wjzi(lssxl  ,iy,iz) = wjzi(lssxl  ,iy,iz) + &
                                                    wjzi(lssxu  ,iy,iz)
            wjzi(lssxlp1,iy,iz) = wjzi(lssxlp1,iy,iz) + &
                                                    wjzi(lssxup1,iy,iz)
            wjzi(lssxlp2,iy,iz) = wjzi(lssxlp2,iy,iz) + &
                                                    wjzi(lssxup2,iy,iz)
          end do
        end do
      end if
!
      if( lexuf .eq. 1 ) then
        if( lexlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup2
              wjxi(lssxum2,iy,iz) = wjxi(lssxlm2,iy,iz)
              wjxi(lssxum1,iy,iz) = wjxi(lssxlm1,iy,iz)
              wjxi(lssxu  ,iy,iz) = wjxi(lssxl  ,iy,iz)
              wjxi(lssxup1,iy,iz) = wjxi(lssxlp1,iy,iz)
              wjxi(lssxup2,iy,iz) = wjxi(lssxlp2,iy,iz)
              wjxi(lssxup3,iy,iz) = wjxi(lssxlp3,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup3
              wjyi(lssxum2,iy,iz) = wjyi(lssxlm2,iy,iz)
              wjyi(lssxum1,iy,iz) = wjyi(lssxlm1,iy,iz)
              wjyi(lssxu  ,iy,iz) = wjyi(lssxl  ,iy,iz)
              wjyi(lssxup1,iy,iz) = wjyi(lssxlp1,iy,iz)
              wjyi(lssxup2,iy,iz) = wjyi(lssxlp2,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do iy = lssylm2, lssyup2
              wjzi(lssxum2,iy,iz) = wjzi(lssxlm2,iy,iz)
              wjzi(lssxum1,iy,iz) = wjzi(lssxlm1,iy,iz)
              wjzi(lssxu  ,iy,iz) = wjzi(lssxl  ,iy,iz)
              wjzi(lssxup1,iy,iz) = wjzi(lssxlp1,iy,iz)
              wjzi(lssxup2,iy,iz) = wjzi(lssxlp2,iy,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup2
              wjxi(lssxum2,iy,iz) = wjxi(lssxlm2,iy,iz) + &
                                                    wjxi(lssxum2,iy,iz)
              wjxi(lssxum1,iy,iz) = wjxi(lssxlm1,iy,iz) + &
                                                    wjxi(lssxum1,iy,iz)
              wjxi(lssxu  ,iy,iz) = wjxi(lssxl  ,iy,iz) + &
                                                    wjxi(lssxu  ,iy,iz)
              wjxi(lssxup1,iy,iz) = wjxi(lssxlp1,iy,iz) + &
                                                    wjxi(lssxup1,iy,iz)
              wjxi(lssxup2,iy,iz) = wjxi(lssxlp2,iy,iz) + &
                                                    wjxi(lssxup2,iy,iz)
              wjxi(lssxup3,iy,iz) = wjxi(lssxlp3,iy,iz) + &
                                                    wjxi(lssxup3,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do iy = lssylm2, lssyup3
              wjyi(lssxum2,iy,iz) = wjyi(lssxlm2,iy,iz) + &
                                                    wjyi(lssxum2,iy,iz)
              wjyi(lssxum1,iy,iz) = wjyi(lssxlm1,iy,iz) + &
                                                    wjyi(lssxum1,iy,iz)
              wjyi(lssxu  ,iy,iz) = wjyi(lssxl  ,iy,iz) + &
                                                    wjyi(lssxu  ,iy,iz)
              wjyi(lssxup1,iy,iz) = wjyi(lssxlp1,iy,iz) + &
                                                    wjyi(lssxup1,iy,iz)
              wjyi(lssxup2,iy,iz) = wjyi(lssxlp2,iy,iz) + &
                                                    wjyi(lssxup2,iy,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do iy = lssylm2, lssyup2
              wjzi(lssxum2,iy,iz) = wjzi(lssxlm2,iy,iz) + &
                                                    wjzi(lssxum2,iy,iz)
              wjzi(lssxum1,iy,iz) = wjzi(lssxlm1,iy,iz) + &
                                                    wjzi(lssxum1,iy,iz)
              wjzi(lssxu  ,iy,iz) = wjzi(lssxl  ,iy,iz) + &
                                                    wjzi(lssxu  ,iy,iz)
              wjzi(lssxup1,iy,iz) = wjzi(lssxlp1,iy,iz) + &
                                                    wjzi(lssxup1,iy,iz)
              wjzi(lssxup2,iy,iz) = wjzi(lssxlp2,iy,iz) + &
                                                    wjzi(lssxup2,iy,iz)
            end do
          end do
        end if
      end if
!..
      if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do ix = lssxlm2, lssxup3
            wjxi(ix,lssylm2,iz) = wjxi(ix,lssylm2,iz) + &
                                                    wjxi(ix,lssyum2,iz)
            wjxi(ix,lssylm1,iz) = wjxi(ix,lssylm1,iz) + &
                                                    wjxi(ix,lssyum1,iz)
            wjxi(ix,lssyl  ,iz) = wjxi(ix,lssyl  ,iz) + &
                                                    wjxi(ix,lssyu  ,iz)
            wjxi(ix,lssylp1,iz) = wjxi(ix,lssylp1,iz) + &
                                                    wjxi(ix,lssyup1,iz)
            wjxi(ix,lssylp2,iz) = wjxi(ix,lssylp2,iz) + &
                                                    wjxi(ix,lssyup2,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup2
          do ix = lssxlm2, lssxup2
            wjyi(ix,lssylm2,iz) = wjyi(ix,lssylm2,iz) + &
                                                    wjyi(ix,lssyum2,iz)
            wjyi(ix,lssylm1,iz) = wjyi(ix,lssylm1,iz) + &
                                                    wjyi(ix,lssyum1,iz)
            wjyi(ix,lssyl  ,iz) = wjyi(ix,lssyl  ,iz) + &
                                                    wjyi(ix,lssyu  ,iz)
            wjyi(ix,lssylp1,iz) = wjyi(ix,lssylp1,iz) + &
                                                    wjyi(ix,lssyup1,iz)
            wjyi(ix,lssylp2,iz) = wjyi(ix,lssylp2,iz) + &
                                                    wjyi(ix,lssyup2,iz)
            wjyi(ix,lssylp3,iz) = wjyi(ix,lssylp3,iz) + &
                                                    wjyi(ix,lssyup3,iz)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iz = lsszlm2, lsszup3
          do ix = lssxlm2, lssxup2
            wjzi(ix,lssylm2,iz) = wjzi(ix,lssylm2,iz) + &
                                                    wjzi(ix,lssyum2,iz)
            wjzi(ix,lssylm1,iz) = wjzi(ix,lssylm1,iz) + &
                                                    wjzi(ix,lssyum1,iz)
            wjzi(ix,lssyl  ,iz) = wjzi(ix,lssyl  ,iz) + &
                                                    wjzi(ix,lssyu  ,iz)
            wjzi(ix,lssylp1,iz) = wjzi(ix,lssylp1,iz) + &
                                                    wjzi(ix,lssyup1,iz)
            wjzi(ix,lssylp2,iz) = wjzi(ix,lssylp2,iz) + &
                                                    wjzi(ix,lssyup2,iz)
          end do
        end do
      end if
!
      if( leyuf .eq. 1 ) then
        if( leylf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup3
              wjxi(ix,lssyum2,iz) = wjxi(ix,lssylm2,iz)
              wjxi(ix,lssyum1,iz) = wjxi(ix,lssylm1,iz)
              wjxi(ix,lssyu  ,iz) = wjxi(ix,lssyl  ,iz)
              wjxi(ix,lssyup1,iz) = wjxi(ix,lssylp1,iz)
              wjxi(ix,lssyup2,iz) = wjxi(ix,lssylp2,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup2
              wjyi(ix,lssyum2,iz) = wjyi(ix,lssylm2,iz)
              wjyi(ix,lssyum1,iz) = wjyi(ix,lssylm1,iz)
              wjyi(ix,lssyu  ,iz) = wjyi(ix,lssyl  ,iz)
              wjyi(ix,lssyup1,iz) = wjyi(ix,lssylp1,iz)
              wjyi(ix,lssyup2,iz) = wjyi(ix,lssylp2,iz)
              wjyi(ix,lssyup3,iz) = wjyi(ix,lssylp3,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do ix = lssxlm2, lssxup2
              wjzi(ix,lssyum2,iz) = wjzi(ix,lssylm2,iz)
              wjzi(ix,lssyum1,iz) = wjzi(ix,lssylm1,iz)
              wjzi(ix,lssyu  ,iz) = wjzi(ix,lssyl  ,iz)
              wjzi(ix,lssyup1,iz) = wjzi(ix,lssylp1,iz)
              wjzi(ix,lssyup2,iz) = wjzi(ix,lssylp2,iz)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup3
              wjxi(ix,lssyum2,iz) = wjxi(ix,lssylm2,iz) + &
                                                    wjxi(ix,lssyum2,iz)
              wjxi(ix,lssyum1,iz) = wjxi(ix,lssylm1,iz) + &
                                                    wjxi(ix,lssyum1,iz)
              wjxi(ix,lssyu  ,iz) = wjxi(ix,lssyl  ,iz) + &
                                                    wjxi(ix,lssyu  ,iz)
              wjxi(ix,lssyup1,iz) = wjxi(ix,lssylp1,iz) + &
                                                    wjxi(ix,lssyup1,iz)
              wjxi(ix,lssyup2,iz) = wjxi(ix,lssylp2,iz) + &
                                                    wjxi(ix,lssyup2,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup2
            do ix = lssxlm2, lssxup2
              wjyi(ix,lssyum2,iz) = wjyi(ix,lssylm2,iz) + &
                                                    wjyi(ix,lssyum2,iz)
              wjyi(ix,lssyum1,iz) = wjyi(ix,lssylm1,iz) + &
                                                    wjyi(ix,lssyum1,iz)
              wjyi(ix,lssyu  ,iz) = wjyi(ix,lssyl  ,iz) + &
                                                    wjyi(ix,lssyu  ,iz)
              wjyi(ix,lssyup1,iz) = wjyi(ix,lssylp1,iz) + &
                                                    wjyi(ix,lssyup1,iz)
              wjyi(ix,lssyup2,iz) = wjyi(ix,lssylp2,iz) + &
                                                    wjyi(ix,lssyup2,iz)
              wjyi(ix,lssyup3,iz) = wjyi(ix,lssylp3,iz) + &
                                                    wjyi(ix,lssyup3,iz)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iz = lsszlm2, lsszup3
            do ix = lssxlm2, lssxup2
              wjzi(ix,lssyum2,iz) = wjzi(ix,lssylm2,iz) + &
                                                    wjzi(ix,lssyum2,iz)
              wjzi(ix,lssyum1,iz) = wjzi(ix,lssylm1,iz) + &
                                                    wjzi(ix,lssyum1,iz)
              wjzi(ix,lssyu  ,iz) = wjzi(ix,lssyl  ,iz) + &
                                                    wjzi(ix,lssyu  ,iz)
              wjzi(ix,lssyup1,iz) = wjzi(ix,lssylp1,iz) + &
                                                    wjzi(ix,lssyup1,iz)
              wjzi(ix,lssyup2,iz) = wjzi(ix,lssylp2,iz) + &
                                                    wjzi(ix,lssyup2,iz)
            end do
          end do
        end if
      end if
!..
      if( lezlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            wjxi(ix,iy,lsszlm2) = wjxi(ix,iy,lsszlm2) + &
                                                    wjxi(ix,iy,lsszum2)
            wjxi(ix,iy,lsszlm1) = wjxi(ix,iy,lsszlm1) + &
                                                    wjxi(ix,iy,lsszum1)
            wjxi(ix,iy,lsszl  ) = wjxi(ix,iy,lsszl  ) + &
                                                    wjxi(ix,iy,lsszu  )
            wjxi(ix,iy,lsszlp1) = wjxi(ix,iy,lsszlp1) + &
                                                    wjxi(ix,iy,lsszup1)
            wjxi(ix,iy,lsszlp2) = wjxi(ix,iy,lsszlp2) + &
                                                    wjxi(ix,iy,lsszup2)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            wjyi(ix,iy,lsszlm2) = wjyi(ix,iy,lsszlm2) + &
                                                    wjyi(ix,iy,lsszum2)
            wjyi(ix,iy,lsszlm1) = wjyi(ix,iy,lsszlm1) + &
                                                    wjyi(ix,iy,lsszum1)
            wjyi(ix,iy,lsszl  ) = wjyi(ix,iy,lsszl  ) + &
                                                    wjyi(ix,iy,lsszu  )
            wjyi(ix,iy,lsszlp1) = wjyi(ix,iy,lsszlp1) + &
                                                    wjyi(ix,iy,lsszup1)
            wjyi(ix,iy,lsszlp2) = wjyi(ix,iy,lsszlp2) + &
                                                    wjyi(ix,iy,lsszup2)
          end do
        end do
!$OMP DO SCHEDULE(STATIC)
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            wjzi(ix,iy,lsszlm2) = wjzi(ix,iy,lsszlm2) + &
                                                    wjzi(ix,iy,lsszum2)
            wjzi(ix,iy,lsszlm1) = wjzi(ix,iy,lsszlm1) + &
                                                    wjzi(ix,iy,lsszum1)
            wjzi(ix,iy,lsszl  ) = wjzi(ix,iy,lsszl  ) + &
                                                    wjzi(ix,iy,lsszu  )
            wjzi(ix,iy,lsszlp1) = wjzi(ix,iy,lsszlp1) + &
                                                    wjzi(ix,iy,lsszup1)
            wjzi(ix,iy,lsszlp2) = wjzi(ix,iy,lsszlp2) + &
                                                    wjzi(ix,iy,lsszup2)
            wjzi(ix,iy,lsszlp3) = wjzi(ix,iy,lsszlp3) + &
                                                    wjzi(ix,iy,lsszup3)
          end do
        end do
      end if
!
      if( lezuf .eq. 1 ) then
        if( lezlf .eq. 1 ) then
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              wjxi(ix,iy,lsszum2) = wjxi(ix,iy,lsszlm2)
              wjxi(ix,iy,lsszum1) = wjxi(ix,iy,lsszlm1)
              wjxi(ix,iy,lsszu  ) = wjxi(ix,iy,lsszl  )
              wjxi(ix,iy,lsszup1) = wjxi(ix,iy,lsszlp1)
              wjxi(ix,iy,lsszup2) = wjxi(ix,iy,lsszlp2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              wjyi(ix,iy,lsszum2) = wjyi(ix,iy,lsszlm2)
              wjyi(ix,iy,lsszum1) = wjyi(ix,iy,lsszlm1)
              wjyi(ix,iy,lsszu  ) = wjyi(ix,iy,lsszl  )
              wjyi(ix,iy,lsszup1) = wjyi(ix,iy,lsszlp1)
              wjyi(ix,iy,lsszup2) = wjyi(ix,iy,lsszlp2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              wjzi(ix,iy,lsszum2) = wjzi(ix,iy,lsszlm2)
              wjzi(ix,iy,lsszum1) = wjzi(ix,iy,lsszlm1)
              wjzi(ix,iy,lsszu  ) = wjzi(ix,iy,lsszl  )
              wjzi(ix,iy,lsszup1) = wjzi(ix,iy,lsszlp1)
              wjzi(ix,iy,lsszup2) = wjzi(ix,iy,lsszlp2)
              wjzi(ix,iy,lsszup3) = wjzi(ix,iy,lsszlp3)
            end do
          end do
        else
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup3
              wjxi(ix,iy,lsszum2) = wjxi(ix,iy,lsszlm2) + &
                                                    wjxi(ix,iy,lsszum2)
              wjxi(ix,iy,lsszum1) = wjxi(ix,iy,lsszlm1) + &
                                                    wjxi(ix,iy,lsszum1)
              wjxi(ix,iy,lsszu  ) = wjxi(ix,iy,lsszl  ) + &
                                                    wjxi(ix,iy,lsszu  )
              wjxi(ix,iy,lsszup1) = wjxi(ix,iy,lsszlp1) + &
                                                    wjxi(ix,iy,lsszup1)
              wjxi(ix,iy,lsszup2) = wjxi(ix,iy,lsszlp2) + &
                                                    wjxi(ix,iy,lsszup2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup3
            do ix = lssxlm2, lssxup2
              wjyi(ix,iy,lsszum2) = wjyi(ix,iy,lsszlm2) + &
                                                    wjyi(ix,iy,lsszum2)
              wjyi(ix,iy,lsszum1) = wjyi(ix,iy,lsszlm1) + &
                                                    wjyi(ix,iy,lsszum1)
              wjyi(ix,iy,lsszu  ) = wjyi(ix,iy,lsszl  ) + &
                                                    wjyi(ix,iy,lsszu  )
              wjyi(ix,iy,lsszup1) = wjyi(ix,iy,lsszlp1) + &
                                                    wjyi(ix,iy,lsszup1)
              wjyi(ix,iy,lsszup2) = wjyi(ix,iy,lsszlp2) + &
                                                    wjyi(ix,iy,lsszup2)
            end do
          end do
!$OMP DO SCHEDULE(STATIC)
          do iy = lssylm2, lssyup2
            do ix = lssxlm2, lssxup2
              wjzi(ix,iy,lsszum2) = wjzi(ix,iy,lsszlm2) + &
                                                    wjzi(ix,iy,lsszum2)
              wjzi(ix,iy,lsszum1) = wjzi(ix,iy,lsszlm1) + &
                                                    wjzi(ix,iy,lsszum1)
              wjzi(ix,iy,lsszu  ) = wjzi(ix,iy,lsszl  ) + &
                                                    wjzi(ix,iy,lsszu  )
              wjzi(ix,iy,lsszup1) = wjzi(ix,iy,lsszlp1) + &
                                                    wjzi(ix,iy,lsszup1)
              wjzi(ix,iy,lsszup2) = wjzi(ix,iy,lsszlp2) + &
                                                    wjzi(ix,iy,lsszup2)
              wjzi(ix,iy,lsszup3) = wjzi(ix,iy,lsszlp3) + &
                                                    wjzi(ix,iy,lsszup3)
            end do
          end do
        end if
      end if
!..
