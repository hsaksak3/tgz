   _INTERP1_(_y1,_dy)
   _INTERP2_(_y2,_dy)
   _INTERP3_(_y3,_dy)
   _INTERP4_(_y4,_dy)
