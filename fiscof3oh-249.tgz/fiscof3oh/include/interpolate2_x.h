   _INTER21_(_x1,_dx)
   _INTER22_(_x2,_dx)
   _INTER23_(_x3,_dx)
