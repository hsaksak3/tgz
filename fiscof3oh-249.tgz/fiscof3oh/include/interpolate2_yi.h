#ifndef _ZIGZAG32
   _iy = _sy
#endif
   _dy = _sy - _iy - s1o2
#include "interpolate2_y.h"
#include "interpolate_undefy.h"
