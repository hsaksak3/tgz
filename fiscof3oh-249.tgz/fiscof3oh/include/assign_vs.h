#undef __iz
#undef _z
#define __iz _iz-1
#define _z _z1
#include "assign_vs2.h"
#undef __iz
#undef _z
#define __iz _iz
#define _z _z2
#include "assign_vs2.h"
#undef __iz
#undef _z
#define __iz _iz+1
#define _z _z3
#include "assign_vs2.h"
#undef __iz
#undef _z
#define __iz _iz+2
#define _z _z4
#include "assign_vs2.h"
#include "interpolate_undefx.h"
#include "interpolate_undefy.h"
#include "interpolate_undefz.h"
