#define _iz izh
#define _dz wdd
#define _z1 wz1h
#define _z2 wz2h
#define _z3 wz3h
#define _z4 wz4h
