#define _iz izn
#define _dz wzd
#define _z1 _fzn(2+_izd)
#define _z2 _fzn(3+_izd)
#define _z3 _fzn(4+_izd)
#define _z4 _fzn(5+_izd)
