#ifndef _ZIGZAG32
   _ix = _sx
#endif
   _dx = _sx - _ix - s1o2
#include "interpolate2_x.h"
#include "interpolate_undefx.h"
