#ifndef _ZIGZAG32
   _iz = _sz
#endif
   _dz = _sz - _iz - s1o2
#ifdef _izd
   _izd = _iz - _izo
#endif
#include "interpolate_z.h"
#include "interpolate_undefz.h"
