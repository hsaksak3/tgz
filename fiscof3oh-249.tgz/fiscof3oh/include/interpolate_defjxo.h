#define _ix _ixo
#define _dx wxd
#define _x1 _fxo(2)
#define _x2 _fxo(3)
#define _x3 _fxo(4)
#define _x4 _fxo(5)
