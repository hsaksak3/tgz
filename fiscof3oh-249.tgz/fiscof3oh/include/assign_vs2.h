     _sv(_ix-1,_iy-1,__iz) = _sv(_ix-1,_iy-1,__iz) + _ss*_x1*_y1*_z
     _sv(_ix  ,_iy-1,__iz) = _sv(_ix  ,_iy-1,__iz) + _ss*_x2*_y1*_z
     _sv(_ix+1,_iy-1,__iz) = _sv(_ix+1,_iy-1,__iz) + _ss*_x3*_y1*_z
     _sv(_ix+2,_iy-1,__iz) = _sv(_ix+2,_iy-1,__iz) + _ss*_x4*_y1*_z
!
     _sv(_ix-1,_iy  ,__iz) = _sv(_ix-1,_iy  ,__iz) + _ss*_x1*_y2*_z
     _sv(_ix  ,_iy  ,__iz) = _sv(_ix  ,_iy  ,__iz) + _ss*_x2*_y2*_z
     _sv(_ix+1,_iy  ,__iz) = _sv(_ix+1,_iy  ,__iz) + _ss*_x3*_y2*_z
     _sv(_ix+2,_iy  ,__iz) = _sv(_ix+2,_iy  ,__iz) + _ss*_x4*_y2*_z
!
     _sv(_ix-1,_iy+1,__iz) = _sv(_ix-1,_iy+1,__iz) + _ss*_x1*_y3*_z
     _sv(_ix  ,_iy+1,__iz) = _sv(_ix  ,_iy+1,__iz) + _ss*_x2*_y3*_z
     _sv(_ix+1,_iy+1,__iz) = _sv(_ix+1,_iy+1,__iz) + _ss*_x3*_y3*_z
     _sv(_ix+2,_iy+1,__iz) = _sv(_ix+2,_iy+1,__iz) + _ss*_x4*_y3*_z
!
     _sv(_ix-1,_iy+2,__iz) = _sv(_ix-1,_iy+2,__iz) + _ss*_x1*_y4*_z
     _sv(_ix  ,_iy+2,__iz) = _sv(_ix  ,_iy+2,__iz) + _ss*_x2*_y4*_z
     _sv(_ix+1,_iy+2,__iz) = _sv(_ix+1,_iy+2,__iz) + _ss*_x3*_y4*_z
     _sv(_ix+2,_iy+2,__iz) = _sv(_ix+2,_iy+2,__iz) + _ss*_x4*_y4*_z
