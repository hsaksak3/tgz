#ifndef _ZIGZAG32
   _iz = _sz
#endif
   _dz = _sz - _iz - s1o2
#include "interpolate2_z.h"
#include "interpolate_undefz.h"
