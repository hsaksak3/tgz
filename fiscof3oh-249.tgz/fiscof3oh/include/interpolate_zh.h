   _iz = _sz + s1o2
   _dz = _sz - _iz
#include "interpolate_z.h"
#include "interpolate_undefz.h"
