!----------------------------------------------------------------------
! implicit
!
! implicit real*8(a, d, r), real*4(w, s, f), integer(i, l, k),
!          character(c, b, e)
!
      implicit none
