   _ix = _sx + s1o2
   _dx = _sx - _ix
#include "interpolate_x.h"
#include "interpolate_undefx.h"
