!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup3
            sjxe(ix,iy,iz) = wjxe(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup2
        do iy = lssylm2, lssyup3
          do ix = lssxlm2, lssxup2
            sjye(ix,iy,iz) = wjye(ix,iy,iz)
          end do
        end do
      end do
!$OMP DO SCHEDULE(STATIC)
      do iz = lsszlm2, lsszup3
        do iy = lssylm2, lssyup2
          do ix = lssxlm2, lssxup2
            sjze(ix,iy,iz) = wjze(ix,iy,iz)
          end do
        end do
      end do
