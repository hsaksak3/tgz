   _INTER21_(_z1,_dz)
   _INTER22_(_z2,_dz)
   _INTER23_(_z3,_dz)
