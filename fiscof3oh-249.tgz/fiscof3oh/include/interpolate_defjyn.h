#define _iy iyn
#define _dy wyd
#define _y1 _fyn(2+_iyd)
#define _y2 _fyn(3+_iyd)
#define _y3 _fyn(4+_iyd)
#define _y4 _fyn(5+_iyd)
