#ifndef _ZIGZAG32
   _ix = _sx
#endif
   _dx = _sx - _ix - s1o2
#ifdef _ixd
   _ixd = _ix - _ixo
#endif
#include "interpolate_x.h"
#include "interpolate_undefx.h"
