#define _ix ixn
#define _dx wxd
#define _x1 _fxn(2+_ixd)
#define _x2 _fxn(3+_ixd)
#define _x3 _fxn(4+_ixd)
#define _x4 _fxn(5+_ixd)
